# Fonoteka server learn/write observability — 2026-08-31

Diagnostic-only hygiene patch. Playback/discovery behavior is unchanged.

Unified Fonoteka BB now records every Worker request that can populate/learn Fonoteka with explicit markers:

- `FONOTEKA_LEARN_SEND` before the request leaves the app.
- `FONOTEKA_LEARN_OK` after a successful Worker response, including `imported`, `found`, `cached`, and HTTP code where available.
- `FONOTEKA_LEARN_FAIL` for HTTP failures, 503/backoff, malformed JSON, network errors, or exceptions.

Both targeted per-track translation and artist-page harvesting are covered.

These markers are diagnostics only and never gate, pause, seek, restart, or otherwise touch A/B playback.
