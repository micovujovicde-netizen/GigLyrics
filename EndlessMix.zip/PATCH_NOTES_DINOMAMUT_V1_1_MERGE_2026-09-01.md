# EndlessMix — Dinomamut v1.1 merge

- Replaced the embedded QEM local-vault seed with `KRDO_MAMUTA_I_TIRANOSAURUSA_v1.1.json`.
- Preserved all 1,635 track identities and 70 country labels from the previous Dinomamut seed.
- v1.1 adds schema-ready per-track `sources` and `bpm_cache` fields.
- `sources` is intended for stable source identities (for example YouTube video IDs/watch identities), never expiring resolved stream URLs.
- `bpm_cache` is intended for progressively learned BPM with source/confidence/authority metadata.
- Current v1.1 values are intentionally empty unless actually known; no video IDs or BPM values were invented.
- Existing QEM 3-key behavior, A/B playback, transition, Champagne/BPM and Deck Z code were not changed by this merge.
