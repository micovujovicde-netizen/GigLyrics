# BPM MIX LAW #0 — SINGLE STARTER COLD START — 2026-09-01

Observed symptom:
- QEM could wait close to a minute and Android displayed "EndlessMix isn't responding".
- Cause in cold-start policy: code still required TWO playable starters before first playback.

Fix:
- requiredStarters = 1
- one playable A is enough to START immediately
- B remains physically FREE and QEM/J fills it behind the curtain after A is playing
- no second URL/search/BPM/ENERGY requirement before first sound
- local BPM pensioner and branch gardener still cannot run until playback + READY_NEXT runway exists
- runtime breadcrumb: DECK_J_LAW0_START required=1 ... secondDeckDeferred=true

Prime directive:
START -> playable A -> safe buffer -> PLAY
then J prepares B and background enrichment.
