# Deck J lightning cold start

Goal: START NEW MIX must exploit the offline catalog instead of behaving like a network search.

Changes:
- Cold START uses Deck J offline candidates immediately.
- Up to 10 J-approved identities are resolved in parallel, each bounded to 2.2 s.
- The first two valid distinct-artist results become starter candidates.
- Cold START does not run F tempo analysis before first sound.
- Normal STRICT -> LOCAL RELAXED -> supplier is fallback only if the lightning batch cannot produce two starters.
- A/B resolution still happens in parallel.
- Playback begins as soon as deck A is READY with ~1.2 s safe buffer.
- Deck B is allowed to finish resolving/buffering in the background; START no longer waits for both decks.
- Normal refill, J authority, C/D passivity, ADD TO MIX and Deck Z are unchanged.

Important limitation:
The offline catalog contains rich identity/metadata for thousands of tracks but direct YouTube watch URLs for only a small subset. Therefore network transport lookup is still required for most tracks; this patch parallelizes that lookup instead of serializing it.
