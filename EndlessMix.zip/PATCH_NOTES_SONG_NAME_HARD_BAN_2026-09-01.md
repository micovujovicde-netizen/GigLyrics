# SONG NAME HARD BAN — 2026-09-01

Clean/protočni build only. No new watchdogs, waits, metadata calls or playback state.

- Existing persistent 20-play song ban now also rejects a candidate when its visible canonical title contains the canonical name of a recently played song.
- This catches alternate performers, live covers and instrumental versions of the same composition.
- Added ` ~ ` as an artist/song separator for title-key extraction.
- Added local noise words `uživo/uzivo`, `instrumental*`, `verzija` to song-key cleanup.
- Artist history and playback/discovery architecture otherwise unchanged.
