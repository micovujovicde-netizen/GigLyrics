# EndlessMix — Local Favorite Star

- Added a tiny gold `☆ / ★` favorite button above each contextual NEXT control.
- Only the star for the currently audible A/B deck is visible, preventing accidental favoriting of a waiting NEXT track.
- Tap `☆` -> `★`; tap again -> `☆`.
- Favorites are stored only in the private local file `endlessmix_user_history.json` through `UserHistoryStore`.
- No favorite/history data is sent to Fonoteka or any server.
- Favorite status is keyed by canonical credited artist(s) + canonical song identity, not raw URL.
- Favorites receive a small +40 automatic ranking preference only after all hard admission gates pass.
- Favorite status never bypasses REGION, STYLE, ERA, anti-repeat/history, non-song or playability rules.
- Added bounded BB markers `USER_FAVORITE_SET` / `USER_FAVORITE_UNSET`.
- A/B playback, transition timing, C/D discovery ownership and Deck Z were not changed.
