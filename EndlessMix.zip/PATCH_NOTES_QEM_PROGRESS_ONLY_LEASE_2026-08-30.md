# QEM progress-only lease fix — 2026-08-30

Problem confirmed by flight recorder: healthy QEM discovery was repeatedly killed by an absolute 24 s AGE lease even when a real progress heartbeat had occurred only milliseconds earlier (`idleMs` near zero). This recreated discovery thrash and left the opposite physical deck FREE for minutes.

Fix:
- Removed absolute QEM discovery age as a takeover condition.
- Discovery AGE is now diagnostic only.
- Normal QEM takeover requires >=14 s with no real progress heartbeat.
- DEAD AIR uses a shorter >=6 s no-progress threshold; it still never takes over solely because the flight is old.
- `abandonStuckQemDiscovery()` re-checks idle time at the actual takeover point, preventing a watchdog race from killing a flight that just made progress.
- Existing 10 s forced-restart throttle remains, so recovery cannot become a restart storm.
- Existing flight-token protection remains: abandoned/late results cannot publish into the current queue.
- Existing NewPipe 6/8/8/9 s connect/read/write/call timeouts remain unchanged.
- ACTIVE A/B playback is not stopped, sought, cleared or replaced by this fix.
