# PARTY / analyzer fossils physically removed — 2026-09-01
- LOVE / SLOW_DANCE_PARTY logic removed.
- JUST A PARTY / DANCE_PARTY / Champagne logic removed.
- Cloud PARTY BPM and local F BPM fallback removed.
- Automatic TempoAnalyzer calls removed.
- PARTY-specific ranking/discovery hints neutralized.
- SLOW / MEDIUM / FAST use Deck J BPM+ENERGY metadata only.
