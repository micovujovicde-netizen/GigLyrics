# LOVE ENERGY-only scheduled analysis — 2026-08-30

- 💚 LOVE final admission no longer uses BPM at all.
- LOVE title words (love/amor/ballad/etc.) are discovery radar only, not admission proof.
- Final gate is 100% ENERGY: every sampled window must be `low`.
- Added `EnergyAnalyzer`, which seeks directly to short 3.5 s windows and does no BPM work.
- Windows: about 8 s, 35 s, 55%, and 78% of the song (clamped safely near the end).
- One non-LOW window rejects immediately, so later loud/rock sections are caught without scanning the whole song.
- LOVE candidates are serialized with `loveEnergyGate = Semaphore(1)`.
- Each window separately uses/relinquishes the shared low-priority analysis slot and yields 180 ms between windows, preventing analyzer starvation.
- LOVE discovery now skips Cloud/Deezer BPM lookup entirely; JUST A PARTY BPM logic remains unchanged.
- Existing general non-song/type/repeat safety filters remain intact.
