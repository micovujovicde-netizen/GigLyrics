# QEM Engine extraction — phase 1

Incremental Music Hotel cleanup only; no intentional DJ behavior change.

- Added `QemEngine.kt` as the owner of QEM mutable session/backstage state.
- Moved QEM artist/style/era session state, candidate provenance maps, parked NEXT state, waiting-deck state, discovery lifecycle state, virtual C/D crates and QEM handoff jobs out of `MixerActivity`.
- Moved virtual C/D shelf storage/consumption mechanics into `QemEngine` while all admission callbacks remain in the existing QEM policy.
- `QemEngine` has no player reference and cannot pause, seek, load, fade or clear A/B.
- `MixerActivity` continues to own physical playback and transition routing.
- No BORDER, BPM, Fonoteka, Champagne, fade, anti-repeat or YouTube behavior was changed.

Validation performed here:
- New QEM engine/state source compiles in isolation against Kotlin coroutines + lightweight QemFonoteka stub.
- MixerActivity delimiter balance checked.
- Full Android Gradle build is not available in this source package because the Gradle wrapper is absent.
