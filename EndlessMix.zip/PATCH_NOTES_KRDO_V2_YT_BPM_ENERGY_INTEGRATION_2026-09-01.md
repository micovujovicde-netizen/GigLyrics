# EndlessMix — KRDO v2 YT + BPM + ENERGY integration

- Replaced `app/src/main/assets/qem_track_vault_seed.json` with the enriched 5,208-track KRDO v2 catalog.
- Preserved all existing identity/region/country/style/era/search fields.
- `QemTrackVault.Entry` now parses optional `youtube.youtube_url`, `bpm_cache.bpm/confidence`, and `energy_cache.energy/confidence`.
- Existing QEM discovery behavior is unchanged: the vault still resolves/searches candidates through the existing guards; direct YouTube URLs are data only and are not injected into A/B playback by this patch.
- Missing or unverified enrichment remains null.
