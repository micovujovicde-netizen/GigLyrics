# LAW #0 — FIRST COMPLETED HIT -> A -> START

Cold-start lightning no longer waits for awaitAll().

- J launches a small parallel URL/search race.
- Deferreds are consumed in completion order.
- The FIRST exact valid track immediately wins.
- Remaining lightning jobs are cancelled.
- Winner is committed directly to Deck A.
- A loads/starts immediately through the existing player path.
- Deck B is prepared only after A playback has begun.
- No BPM/ENERGY/FIRST_BEAT/SYNC or second starter may delay first sound.

BB:
- DECK_J_LIGHTNING_FIRST_HIT
- DECK_J_LAW0_COMMIT deck=A ... action=LOAD_AND_START
- DECK_J_LIGHTNING_RESULT ... immediate=true
