# LOVE ENERGY 3:1 — 2026-08-30

- 💚 LOVE / SLOW LOVE now uses ENERGY:BPM = 3:1.
- Other tempo/energy filters remain at their existing 2:1 weighting.
- LOVE LOW/MIDDLE energy contributes 3 votes; BPM <=103 contributes 1 vote.
- LOVE admission requires >=3/4 feel votes.
- Diagnostic marker: LOVE_3TO1.
- No playback, continuity, Fonoteka timing, or non-LOVE filter logic changed.
