# DINOTEKA 19 DIRECT STYLES — 2026-09-01

QEM STYLE UI now exposes exactly the 19 stored Dinoteka/Monster J tags, in this order:

1. ANY
2. POP
3. ROCK
4. HIP_HOP
5. DANCE_HOUSE
6. RNB_SOUL
7. RNB
8. FOLK
9. DANCE
10. SOUL
11. LATIN
12. JAZZ
13. REGGAE
14. COUNTRY
15. WORLD
16. METAL
17. RAP
18. CLASSICAL
19. REGGAE_CARIBBEAN

Rules:
- UI style key == J stored style tag.
- ANY is the real Dinoteka ANY tag.
- No MIXED pseudo-style.
- No POP_ROCK / HIP_HOP_RAP / RNB_HIP_HOP / POP_FOLK combined UI keys.
- No style family aliases or vocabulary translator.
- REGION / COUNTRY / ERA / TEMPO and all other behavior left unchanged.
