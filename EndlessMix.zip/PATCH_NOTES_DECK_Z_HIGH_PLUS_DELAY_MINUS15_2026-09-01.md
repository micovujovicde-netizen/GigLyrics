# Deck Z high-frequency lift + delay -15%

- Deck Z high-shelf EQ boost increased from +2.5 dB to +3.2 dB.
- Deck Z echo delay reduced by an additional 15% versus the previous setting: scale 0.90 -> 0.765.
- Echo delay clamp scaled with it: 153-387 ms -> 130-329 ms.
- A/B playback, crossfade, QEM, vault/Dinomamut, BPM admission and master gain are unchanged.
