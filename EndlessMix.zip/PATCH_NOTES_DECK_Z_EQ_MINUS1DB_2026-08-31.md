# Deck Z speech EQ + -1 dB — 2026-08-31

- Scope is Deck Z/TTS only. A/B players, master headroom, transition engine, QEM/BASIC discovery and Safety Belt are untouched.
- Deck Z rendered speech output is reduced by 1 dB (`0.89125` linear gain); the echo return is reduced by the same 1 dB ratio.
- Added a best-effort Android `Equalizer` on the Deck Z primary MediaPlayer session. It applies a modest presence/high-frequency lift: gentle from ~2 kHz, stronger from ~4 kHz, up to +2.5 dB from ~8 kHz where the device EQ exposes such bands.
- EQ failure is non-fatal and falls back to plain Deck Z playback. BB logs `DECK_Z_EQ_ON ...` or `DECK_Z_FX_SKIP effect=eq ...`.
