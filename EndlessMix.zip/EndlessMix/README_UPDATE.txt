EndlessMix update - startup/session continuity fix

- QUICK/ENDLESS never interrupts the song already playing.
- Current playing deck becomes protected ACTIVE and the crossfader is hard-aligned to it.
- One valid new candidate is enough to commit Endless; it becomes NEXT.
- A second QUICK candidate, when available, waits in the background queue.
- With no current playback, one valid candidate may start on A and Endless fills B in background.
- HOTEL and RESTAURANT default to ANGLO only; lower REGION/COUNTRY remains the user override.
- Fresh QUICK still starts A-only; B cannot autoplay before the real transition.
- AUTO/Endless UI is committed only with the actual playback owner/fader state.
