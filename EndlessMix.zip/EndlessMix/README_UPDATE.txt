- QUICK venue presets removed: HOTEL / RESTAURANT / CAFFE BAR / CLUB. Use REGION / COUNTRY / STYLE / ERA / TEMPO directly.
EndlessMix update - startup/session continuity fix

- QUICK/ENDLESS never interrupts the song already playing.
- Current playing deck becomes protected ACTIVE and the crossfader is hard-aligned to it.
- One valid new candidate is enough to commit Endless; it becomes NEXT.
- A second QUICK candidate, when available, waits in the background queue.
- With no current playback, one valid candidate may start on A and Endless fills B in background.
- Fresh QUICK still starts A-only; B cannot autoplay before the real transition.
- AUTO/Endless UI is committed only with the actual playback owner/fader state.

V4.5 BPM AUDIO UPDATE
- Real decoded-audio tempo estimation added (32 s shortlist/preload scan).
- Human tempo normalization + bands: SLOW <=84, MIDDLE 85-114, FAST 115-144, VERY FAST 145+.
- Manual tempo buttons are hard auto-candidate gates across the app.
- QUICK measures only a small shortlist (max 8) before starter selection; BPM is cached by track URL.
- NEXT deck buffers in parallel while BPM validation runs; it cannot become READY_NEXT until validated.
- Manual ADD TO MIX remains sacred and bypasses automatic BPM rejection.


QEM JSON UI UPDATE (2026-08-25)
- Basic Endless engine intentionally unchanged.
- QEM REGION buttons are generated from fonoteka.json / regions.
- COUNTRY picker is generated only from countries actually present in the selected fonoteka region pool(s).
- STYLE strip is generated from fonoteka.json: styles + combined_style_buttons + special_styles + attribute_filters.
- Added PIANO as a JSON attribute overlay; it implies instrumental and never broadens region/style/era.
- QEM still shares the same A/B decks with Basic Endless; ENTER changes automatic ownership without touching the ACTIVE track.
- Persistent playback history remains shared across Basic Endless/QEM and survives app restarts.
- QEM weighted random supports pools up to 100 while keeping nonzero probability for lower-ranked artists.

QEM AUDIO-FIRST UPDATE
- QEM remains JSON-driven (region/country/style/era/attributes) with the latest fonoteka.json.
- Removed remaining legacy HOTEL / RESTAURANT / CAFFE BAR / CLUB preset logic.
- ACTIVE playback has resource priority: waveform/tempo/intro decode work is capped to two concurrent jobs,
  runs at Android background thread priority, and waits briefly for player buffer headroom before heavy analysis.
- QEM discovery batches are limited to two parallel artist searches to reduce contention while music is playing.
- Basic Endless selection/refill rules are not changed; only shared background analysis scheduling is made safer.
