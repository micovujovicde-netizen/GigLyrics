- QUICK venue presets removed: HOTEL / RESTAURANT / CAFFE BAR / CLUB. Use REGION / COUNTRY / STYLE / ERA / TEMPO directly.
EndlessMix update - startup/session continuity fix

- QUICK/ENDLESS never interrupts the song already playing.
- Current playing deck becomes protected ACTIVE and the crossfader is hard-aligned to it.
- One valid new candidate is enough to commit Endless; it becomes NEXT.
- A second QUICK candidate, when available, waits in the background queue.
- With no current playback, one valid candidate may start on A and Endless fills B in background.
- Fresh QUICK still starts A-only; B cannot autoplay before the real transition.
- AUTO/Endless UI is committed only with the actual playback owner/fader state.

V4.5 BPM AUDIO UPDATE
- Real decoded-audio tempo estimation added (32 s shortlist/preload scan).
- Human tempo normalization + bands: SLOW <=84, MIDDLE 85-114, FAST 115-144, VERY FAST 145+.
- Manual tempo buttons are hard auto-candidate gates across the app.
- QUICK measures only a small shortlist (max 8) before starter selection; BPM is cached by track URL.
- NEXT deck buffers in parallel while BPM validation runs; it cannot become READY_NEXT until validated.
- Manual ADD TO MIX remains sacred and bypasses automatic BPM rejection.
