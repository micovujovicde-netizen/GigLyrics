ENDLESS MIX V1 CLEAN REBUILD

Goal:
- Start music quickly.
- Keep exactly one ACTIVE deck outside the crossfade.
- Prepare the opposite deck in the background.
- Never let a bad waiting candidate damage or clear the ACTIVE deck.
- Keep searching while AUTO is ON until a waiting deck is READY.
- Use one discovery loop, one deck-loader path, and one transition path.
- Accept messy/non-expert filter combinations without wedging the engine.

V1 ownership rules:
1. activeDeck is authoritative; ExoPlayer.isPlaying never decides which deck is free.
2. loadIntoDeck() is the only resolver/preload entry point.
3. discoveryJob is the only automatic search/refill loop.
4. transitionJob is the only owner-changing path.
5. A waiting-deck failure clears only that waiting deck.
6. Quick starts A as soon as it is playable; B is prepared while music is already running.
7. Instant NEXT appears only when the opposite deck is READY.
