package com.terafon.pausemix

import com.terafon.pausemix.model.TrackRef
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.StreamType

class SearchRepository {
    fun search(query: String): List<TrackRef> {
        val extractor = ServiceList.YouTube.getSearchExtractor(query)

        // NewPipe extractors must fetch the page before initialPage is read.
        // Without this call YouTube's response parser can hit null JSON data.
        extractor.fetchPage()

        return extractor.initialPage.items
            .filterIsInstance<StreamInfoItem>()
            .filter {
                it.streamType != StreamType.LIVE_STREAM &&
                    it.streamType != StreamType.AUDIO_LIVE_STREAM
            }
            .take(25)
            .map {
                TrackRef(
                    title = it.name,
                    uploader = it.uploaderName ?: "",
                    url = it.url,
                    durationSeconds = it.duration
                )
            }
    }
}
