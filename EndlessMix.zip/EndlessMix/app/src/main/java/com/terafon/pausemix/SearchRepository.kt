package com.terafon.pausemix

import com.terafon.pausemix.model.TrackRef
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.StreamType

class SearchRepository {
    fun search(query: String): List<TrackRef> {
        val extractor = ServiceList.YouTube.getSearchExtractor(query)

        // NewPipe extractors must fetch the page before initialPage is read.
        // Without this call YouTube's response parser can hit null JSON data.
        extractor.fetchPage()

        return extractor.initialPage.items
            .filterIsInstance<StreamInfoItem>()
            .filter {
                it.streamType != StreamType.LIVE_STREAM &&
                    it.streamType != StreamType.AUDIO_LIVE_STREAM
            }
            .take(30)
            .map { item ->
                TrackRef(
                    title = item.name,
                    uploader = item.uploaderName ?: "",
                    url = item.url,
                    durationSeconds = item.duration,
                    viewCount = readLongMetadata(item, "getViewCount"),
                    uploaderVerified = readBooleanMetadata(item, "isUploaderVerified", "getUploaderVerified")
                )
            }
    }

    // NewPipe has renamed a few metadata accessors across releases. Reflection keeps
    // EndlessMix compatible with the pinned extractor while still using metadata when available.
    private fun readLongMetadata(item: StreamInfoItem, vararg methodNames: String): Long {
        return methodNames.firstNotNullOfOrNull { name ->
            runCatching {
                val method = item.javaClass.methods.firstOrNull { it.name == name && it.parameterCount == 0 }
                    ?: return@runCatching null
                (method.invoke(item) as? Number)?.toLong()
            }.getOrNull()
        } ?: -1L
    }

    private fun readBooleanMetadata(item: StreamInfoItem, vararg methodNames: String): Boolean {
        return methodNames.firstNotNullOfOrNull { name ->
            runCatching {
                val method = item.javaClass.methods.firstOrNull { it.name == name && it.parameterCount == 0 }
                    ?: return@runCatching null
                method.invoke(item) as? Boolean
            }.getOrNull()
        } ?: false
    }
}
