package com.terafon.pausemix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.sin

/**
 * Compact stereo activity rail for the crossfader. It deliberately stays only about as tall
 * as the fader thumb and mirrors energy above/below the center line, like hardware metering.
 * The source energy follows the currently playing deck waveforms; a tiny phase motion keeps
 * the rail alive between waveform buckets without adding any audio processing load.
 */
class CrossSpectrumView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 2f }
    private var leftEnergy = 0f
    private var rightEnergy = 0f
    private var phase = 0f

    fun setEnergy(left: Float, right: Float, phaseValue: Float) {
        leftEnergy = left.coerceIn(0f, 1f)
        rightEnergy = right.coerceIn(0f, 1f)
        phase = phaseValue
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return
        val centerY = height / 2f
        val maxHalf = minOf(height * 0.25f, 15f * resources.displayMetrics.density)
        val bars = 42
        val usable = width - paddingLeft - paddingRight
        val step = usable.toFloat() / bars
        val palette = intArrayOf(
            Color.rgb(34, 197, 94),
            Color.rgb(244, 196, 48),
            Color.rgb(245, 124, 0),
            Color.rgb(215, 25, 32)
        )
        for (i in 0 until bars) {
            val x = paddingLeft + (i + 0.5f) * step
            val halfSide = i < bars / 2
            val base = if (halfSide) leftEnergy else rightEnergy
            val harmonic = 0.45f + 0.55f * abs(sin(phase + i * 0.71f)).toFloat()
            val h = maxHalf * (0.10f + 0.90f * base * harmonic)
            paint.color = palette[(i * palette.size / bars).coerceIn(0, palette.lastIndex)]
            paint.alpha = if (base > 0.02f) 210 else 70
            canvas.drawLine(x, centerY - h, x, centerY + h, paint)
        }
    }
}
