package com.terafon.pausemix

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max

/**
 * Decodes the remote audio stream to PCM and compresses the whole song into a small peak array.
 * The result is a genuine structure overview, not a decorative/random waveform.
 */
object WaveformAnalyzer {
    fun analyze(url: String, buckets: Int = 140): FloatArray {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(url, emptyMap())

            var trackIndex = -1
            var inputFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    trackIndex = i
                    inputFormat = f
                    break
                }
            }
            if (trackIndex < 0 || inputFormat == null) {
                throw IllegalStateException("Audio track not found")
            }

            extractor.selectTrack(trackIndex)
            val mime = inputFormat.getString(MediaFormat.KEY_MIME)
                ?: throw IllegalStateException("Audio format missing")
            val durationUs = if (inputFormat.containsKey(MediaFormat.KEY_DURATION)) {
                inputFormat.getLong(MediaFormat.KEY_DURATION).coerceAtLeast(1L)
            } else 1L

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(inputFormat, null, null, 0)
            codec.start()

            val peaks = FloatArray(buckets)
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var guard = 0

            while (!outputDone && guard < 250000) {
                guard++
                if (!inputDone) {
                    val inputIndex = codec.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        val inputBuffer = codec.getInputBuffer(inputIndex)
                        if (inputBuffer != null) {
                            val size = extractor.readSampleData(inputBuffer, 0)
                            if (size < 0) {
                                codec.queueInputBuffer(
                                    inputIndex, 0, 0, 0L,
                                    MediaCodec.BUFFER_FLAG_END_OF_STREAM
                                )
                                inputDone = true
                            } else {
                                codec.queueInputBuffer(
                                    inputIndex, 0, size, extractor.sampleTime, 0
                                )
                                extractor.advance()
                            }
                        }
                    }
                }

                val outputIndex = codec.dequeueOutputBuffer(info, 10_000)
                if (outputIndex >= 0) {
                    if (info.size > 0) {
                        val out = codec.getOutputBuffer(outputIndex)
                        if (out != null) {
                            out.position(info.offset)
                            out.limit(info.offset + info.size)
                            val pcm = out.slice().order(ByteOrder.LITTLE_ENDIAN)
                            var peak = 0
                            while (pcm.remaining() >= 2) {
                                val v = abs(pcm.short.toInt())
                                if (v > peak) peak = v
                            }
                            val bucket = ((info.presentationTimeUs.toDouble() / durationUs.toDouble()) * buckets)
                                .toInt().coerceIn(0, buckets - 1)
                            peaks[bucket] = max(peaks[bucket], peak / 32768f)
                        }
                    }
                    outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    codec.releaseOutputBuffer(outputIndex, false)
                }
            }

            // Fill tiny holes caused by sparse timestamps and normalize.
            for (i in 1 until peaks.size) {
                if (peaks[i] == 0f) peaks[i] = peaks[i - 1] * 0.92f
            }
            for (i in peaks.size - 2 downTo 0) {
                if (peaks[i] == 0f) peaks[i] = peaks[i + 1] * 0.92f
            }
            val maxPeak = peaks.maxOrNull()?.coerceAtLeast(0.001f) ?: 1f
            for (i in peaks.indices) {
                peaks[i] = (peaks[i] / maxPeak).coerceIn(0f, 1f)
            }
            return peaks
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }
}
