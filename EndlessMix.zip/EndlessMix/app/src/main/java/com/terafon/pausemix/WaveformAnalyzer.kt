package com.terafon.pausemix

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/** Decode a real remote audio stream into a compact whole-song peak overview. */
object WaveformAnalyzer {
    data class Analysis(val waveform: FloatArray, val rms: Float)

    fun analyze(
        url: String,
        buckets: Int = 160,
        onProgress: ((FloatArray, Float) -> Unit)? = null
    ): Analysis {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(url, emptyMap())

            var trackIndex = -1
            var inputFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    trackIndex = i
                    inputFormat = f
                    break
                }
            }
            if (trackIndex < 0 || inputFormat == null) error("Audio track not found")

            extractor.selectTrack(trackIndex)
            val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: error("Audio format missing")
            val durationUs = if (inputFormat.containsKey(MediaFormat.KEY_DURATION)) {
                inputFormat.getLong(MediaFormat.KEY_DURATION).coerceAtLeast(1L)
            } else 1L

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(inputFormat, null, null, 0)
            codec.start()

            val peaks = FloatArray(buckets)
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var guard = 0
            var lastReportedBucket = -1
            var sumSquares = 0.0
            var sampleCount = 0L

            while (!outputDone && guard < 250000) {
                guard++
                if (!inputDone) {
                    val inputIndex = codec.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        val inputBuffer = codec.getInputBuffer(inputIndex)
                        if (inputBuffer != null) {
                            val size = extractor.readSampleData(inputBuffer, 0)
                            if (size < 0) {
                                codec.queueInputBuffer(inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                codec.queueInputBuffer(inputIndex, 0, size, extractor.sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                }

                val outputIndex = codec.dequeueOutputBuffer(info, 10_000)
                if (outputIndex >= 0) {
                    if (info.size > 0) {
                        val out = codec.getOutputBuffer(outputIndex)
                        if (out != null) {
                            out.position(info.offset)
                            out.limit(info.offset + info.size)
                            val pcm = out.slice().order(ByteOrder.LITTLE_ENDIAN)
                            var peak = 0
                            while (pcm.remaining() >= 2) {
                                val raw = pcm.short.toInt()
                                val v = abs(raw)
                                if (v > peak) peak = v
                                val normalized = raw / 32768.0
                                sumSquares += normalized * normalized
                                sampleCount++
                            }
                            val bucket = ((info.presentationTimeUs.toDouble() / durationUs) * buckets)
                                .toInt().coerceIn(0, buckets - 1)
                            peaks[bucket] = max(peaks[bucket], peak / 32768f)

                            // Report every few rows so the column visibly fills at analysis speed.
                            if (bucket >= lastReportedBucket + 3) {
                                lastReportedBucket = bucket
                                val partial = normalizedCopy(peaks, bucket + 1)
                                onProgress?.invoke(partial, ((bucket + 1f) / buckets).coerceIn(0f, 1f))
                            }
                        }
                    }
                    outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    codec.releaseOutputBuffer(outputIndex, false)
                }
            }

            fillHoles(peaks)
            val finalWave = normalizedCopy(peaks, peaks.size)
            onProgress?.invoke(finalWave, 1f)
            val rms = if (sampleCount > 0L) sqrt(sumSquares / sampleCount).toFloat().coerceIn(0f, 1f) else 0f
            return Analysis(finalWave, rms)
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }

    private fun fillHoles(peaks: FloatArray) {
        for (i in 1 until peaks.size) if (peaks[i] == 0f) peaks[i] = peaks[i - 1] * 0.92f
        for (i in peaks.size - 2 downTo 0) if (peaks[i] == 0f) peaks[i] = peaks[i + 1] * 0.92f
    }

    private fun normalizedCopy(src: FloatArray, validCount: Int): FloatArray {
        val count = validCount.coerceIn(0, src.size)
        var maxPeak = 0.001f
        for (i in 0 until count) maxPeak = max(maxPeak, src[i])
        return FloatArray(src.size) { i ->
            if (i < count) (src[i] / maxPeak).coerceIn(0f, 1f) else 0f
        }
    }
}
