package com.terafon.pausemix

import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.terafon.pausemix.databinding.ActivityMainBinding
import com.terafon.pausemix.model.MixerStore
import com.terafon.pausemix.model.TrackRef
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val repo = SearchRepository()
    private var targetDeck: String? = null
    private var loadingTrack = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        targetDeck = intent.getStringExtra(EXTRA_TARGET_DECK)?.takeIf { it == "A" || it == "B" }
        if (targetDeck == null) {
            finish()
            return
        }

        fun resolveAndLoad(track: TrackRef) {
            val deck = targetDeck ?: return
            if (deck == "A") MixerStore.setA(track) else MixerStore.setB(track)
            // The deck already identifies the destination. Close search immediately;
            // stream resolution/buffering/waveform loading continues in the mixer.
            finish()
        }

        val adapter = SearchAdapter(
            targetDeck = targetDeck,
            onImportA = { resolveAndLoad(it) },
            onImportB = { resolveAndLoad(it) }
        )
        binding.results.layoutManager = LinearLayoutManager(this)
        binding.results.adapter = adapter

        fun doSearch() {
            if (loadingTrack) return
            val q = binding.searchInput.text.toString().trim()
            if (q.isBlank()) return
            binding.progress.visibility = View.VISIBLE
            binding.statusText.text = "Searching…"

            lifecycleScope.launch {
                runCatching {
                    withContext(Dispatchers.IO) { repo.search(q) }
                }.onSuccess { results ->
                    adapter.submit(results)
                    binding.statusText.text = "${results.size} results"
                }.onFailure {
                    binding.statusText.text = "Search error: ${it.message ?: "unknown"}"
                }
                binding.progress.visibility = View.GONE
            }
        }

        binding.searchButton.setOnClickListener { doSearch() }
        binding.searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                doSearch()
                true
            } else false
        }
    }

    companion object {
        const val EXTRA_TARGET_DECK = "target_deck"
    }
}
