package com.terafon.pausemix

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.terafon.pausemix.databinding.ActivityMainBinding
import com.terafon.pausemix.model.MixerStore
import com.terafon.pausemix.model.TrackRef
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val repo = SearchRepository()
    private var targetDeck: String? = null
    private var loadingTrack = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        targetDeck = intent.getStringExtra(EXTRA_TARGET_DECK)?.takeIf { it == "A" || it == "B" }

        if (targetDeck != null) {
            binding.modeText.text = "LOAD TO $targetDeck"
            binding.openMixer.text = "BACK TO MIXER"
        } else {
            binding.modeText.text = "SEARCH / BROWSER"
        }

        fun resolveAndLoad(track: TrackRef, deck: String) {
            if (loadingTrack) return
            loadingTrack = true
            binding.progress.visibility = View.VISIBLE
            binding.statusText.text = "Preparing ${track.title} for $deck…"

            lifecycleScope.launch {
                runCatching {
                    val direct = withContext(Dispatchers.IO) {
                        AudioResolver.resolveBestAudioUrl(track.url)
                    }
                    track.copy(streamUrl = direct)
                }.onSuccess { resolved ->
                    if (deck == "A") MixerStore.setA(resolved) else MixerStore.setB(resolved)
                    Toast.makeText(this@MainActivity, "Loaded to $deck", Toast.LENGTH_SHORT).show()
                    if (targetDeck != null) {
                        finish()
                    } else {
                        binding.statusText.text = "Loaded to $deck"
                    }
                }.onFailure {
                    binding.statusText.text = "Stream error: ${it.message ?: "unknown"}"
                }
                loadingTrack = false
                binding.progress.visibility = View.GONE
            }
        }

        val adapter = SearchAdapter(
            targetDeck = targetDeck,
            onImportA = { resolveAndLoad(it, "A") },
            onImportB = { resolveAndLoad(it, "B") }
        )

        binding.results.layoutManager = LinearLayoutManager(this)
        binding.results.adapter = adapter

        fun doSearch() {
            if (loadingTrack) return
            val q = binding.searchInput.text.toString().trim()
            if (q.isBlank()) return
            binding.progress.visibility = View.VISIBLE
            binding.statusText.text = "Searching…"

            lifecycleScope.launch {
                runCatching {
                    withContext(Dispatchers.IO) { repo.search(q) }
                }.onSuccess { results ->
                    adapter.submit(results)
                    binding.statusText.text = "${results.size} results${targetDeck?.let { " • tap one for $it" } ?: ""}"
                }.onFailure {
                    binding.statusText.text = "Search error: ${it.message ?: "unknown"}"
                }
                binding.progress.visibility = View.GONE
            }
        }

        binding.searchButton.setOnClickListener { doSearch() }
        binding.searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                doSearch()
                true
            } else false
        }

        binding.openMixer.setOnClickListener {
            if (targetDeck != null) {
                finish()
            } else {
                startActivity(Intent(this, MixerActivity::class.java))
            }
        }
    }

    companion object {
        const val EXTRA_TARGET_DECK = "target_deck"
    }
}
