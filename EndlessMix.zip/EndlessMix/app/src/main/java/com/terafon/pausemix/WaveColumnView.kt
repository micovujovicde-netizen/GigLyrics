package com.terafon.pausemix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.max

/**
 * Narrow, high-contrast full-track waveform.
 * Empty deck = one thin vertical line.
 * While analysis is running the real waveform fills from top to bottom.
 */
class WaveColumnView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val density = resources.displayMetrics.density
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = max(1.2f * density, 1.5f)
        strokeCap = Paint.Cap.ROUND
    }
    private val baselinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        alpha = 150
        strokeWidth = max(0.8f * density, 1f)
    }
    private val playheadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = max(2f * density, 2.5f)
    }

    private var samples: FloatArray? = null
    private var hasTrack = false
    private var playProgress = 0f
    private var loadProgress = 0f

    fun setEmpty() {
        hasTrack = false
        samples = null
        playProgress = 0f
        loadProgress = 0f
        invalidate()
    }

    fun setTrackPresent(present: Boolean) {
        hasTrack = present
        if (!present) setEmpty() else invalidate()
    }

    fun setWaveform(values: FloatArray?, loadedFraction: Float = 1f) {
        samples = values?.copyOf()
        hasTrack = values != null || hasTrack
        loadProgress = loadedFraction.coerceIn(0f, 1f)
        invalidate()
    }

    fun setLoadProgress(value: Float) {
        loadProgress = value.coerceIn(0f, 1f)
        invalidate()
    }

    fun setProgress(value: Float) {
        playProgress = value.coerceIn(0f, 1f)
        invalidate()
    }

    fun setTrackSeed(value: String?) = setTrackPresent(value != null)
    fun setRunning(value: Boolean) = Unit

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.BLACK)

        val midX = width / 2f
        val top = height * 0.03f
        val bottom = height * 0.97f
        val usableH = bottom - top

        if (!hasTrack) {
            canvas.drawLine(midX, top, midX, bottom, baselinePaint)
            return
        }

        // Unanalysed area remains a single thin line.
        canvas.drawLine(midX, top, midX, bottom, baselinePaint)

        val data = samples
        if (data != null && data.isNotEmpty()) {
            val halfW = width * 0.40f
            val loadedCount = (data.size * loadProgress).toInt().coerceIn(0, data.size)
            if (loadedCount > 0) {
                val denom = (data.size - 1).coerceAtLeast(1).toFloat()
                for (i in 0 until loadedCount) {
                    val y = top + (i.toFloat() / denom) * usableH
                    val amp = data[i].coerceIn(0.012f, 1f) * halfW
                    canvas.drawLine(midX - amp, y, midX + amp, y, wavePaint)
                }
            }
        }

        // Playback position runs top -> bottom.
        val py = top + playProgress * usableH
        canvas.drawLine(width * 0.08f, py, width * 0.92f, py, playheadPaint)
    }
}
