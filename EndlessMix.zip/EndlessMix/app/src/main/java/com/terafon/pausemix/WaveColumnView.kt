package com.terafon.pausemix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.max

/**
 * Slim full-track vertical waveform.
 * Empty deck = one thin vertical line.
 * Analysis fills top -> bottom.
 * A thick transparent green horizontal playhead follows playback and is seekable by touch.
 */
class WaveColumnView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val density = resources.displayMetrics.density
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(215, 174, 74)
        strokeWidth = max(1f * density, 1.3f)
        strokeCap = Paint.Cap.ROUND
    }
    private val baselinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(155, 158, 162)
        alpha = 115
        strokeWidth = max(0.7f * density, 1f)
    }
    private val playheadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0, 230, 70)
        alpha = 220
        strokeWidth = max(8f * density, 10f)
        strokeCap = Paint.Cap.ROUND
    }

    private var samples: FloatArray? = null
    private var hasTrack = false
    private var playProgress = 0f
    private var loadProgress = 0f

    var onSeekRequested: ((Float) -> Unit)? = null

    fun setEmpty() {
        hasTrack = false
        samples = null
        playProgress = 0f
        loadProgress = 0f
        invalidate()
    }

    fun setTrackPresent(present: Boolean) {
        hasTrack = present
        if (!present) setEmpty() else invalidate()
    }

    fun setWaveform(values: FloatArray?, loadedFraction: Float = 1f) {
        samples = values?.copyOf()
        hasTrack = values != null || hasTrack
        loadProgress = loadedFraction.coerceIn(0f, 1f)
        invalidate()
    }

    fun setLoadProgress(value: Float) {
        loadProgress = value.coerceIn(0f, 1f)
        invalidate()
    }

    fun setProgress(value: Float) {
        playProgress = value.coerceIn(0f, 1f)
        invalidate()
    }

    fun setTrackSeed(value: String?) = setTrackPresent(value != null)
    fun setRunning(value: Boolean) = Unit

    private fun progressFromY(y: Float): Float {
        val top = height * 0.03f
        val bottom = height * 0.97f
        val usable = (bottom - top).coerceAtLeast(1f)
        return ((y - top) / usable).coerceIn(0f, 1f)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!hasTrack || !isEnabled) return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val p = progressFromY(event.y)
                playProgress = p
                invalidate()
                onSeekRequested?.invoke(p)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                if (event.actionMasked == MotionEvent.ACTION_UP) performClick()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.BLACK)

        wavePaint.color = if (id == R.id.waveA) Color.rgb(215, 174, 74) else Color.rgb(216, 220, 224)
        val midX = width / 2f
        val top = height * 0.03f
        val bottom = height * 0.97f
        val usableH = bottom - top

        if (!hasTrack) {
            canvas.drawLine(midX, top, midX, bottom, baselinePaint)
            return
        }

        canvas.drawLine(midX, top, midX, bottom, baselinePaint)

        val data = samples
        if (data != null && data.isNotEmpty()) {
            val halfW = width * 0.34f
            val loadedCount = (data.size * loadProgress).toInt().coerceIn(0, data.size)
            if (loadedCount > 0) {
                val denom = (data.size - 1).coerceAtLeast(1).toFloat()
                for (i in 0 until loadedCount) {
                    val y = top + (i.toFloat() / denom) * usableH
                    val amp = data[i].coerceIn(0.012f, 1f) * halfW
                    canvas.drawLine(midX - amp, y, midX + amp, y, wavePaint)
                }
            }
        }

        val py = top + playProgress * usableH
        canvas.drawLine(width * 0.03f, py, width * 0.97f, py, playheadPaint)
    }
}
