package com.terafon.pausemix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.max

/**
 * High contrast full-track waveform.
 * Empty deck = one thin white line.
 * Loaded deck = real decoded amplitude overview + playhead.
 */
class WaveColumnView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val density = resources.displayMetrics.density
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = max(1.5f * density, 2f)
        strokeCap = Paint.Cap.ROUND
    }
    private val baselinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = max(1f * density, 1f)
    }
    private val playheadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = max(2.5f * density, 3f)
    }

    private var samples: FloatArray? = null
    private var hasTrack = false
    private var progress = 0f

    fun setEmpty() {
        hasTrack = false
        samples = null
        progress = 0f
        invalidate()
    }

    fun setTrackPresent(present: Boolean) {
        hasTrack = present
        if (!present) {
            samples = null
            progress = 0f
        }
        invalidate()
    }

    fun setWaveform(values: FloatArray?) {
        samples = values?.copyOf()
        hasTrack = values != null || hasTrack
        invalidate()
    }

    fun setProgress(value: Float) {
        progress = value.coerceIn(0f, 1f)
        invalidate()
    }

    // Kept for source compatibility with the earlier build.
    fun setTrackSeed(value: String?) = setTrackPresent(value != null)
    fun setRunning(value: Boolean) = Unit

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.BLACK)

        val midX = width / 2f
        val data = samples

        if (!hasTrack || data == null || data.isEmpty()) {
            // Empty deck: one clean vertical line.
            canvas.drawLine(midX, height * 0.08f, midX, height * 0.92f, baselinePaint)
            return
        }

        val halfW = width * 0.42f
        val count = data.size
        if (count == 1) {
            val amp = data[0].coerceIn(0.02f, 1f) * halfW
            canvas.drawLine(midX - amp, height / 2f, midX + amp, height / 2f, wavePaint)
        } else {
            for (i in data.indices) {
                val y = (i.toFloat() / (count - 1).toFloat()) * height
                val amp = data[i].coerceIn(0.015f, 1f) * halfW
                canvas.drawLine(midX - amp, y, midX + amp, y, wavePaint)
            }
        }

        // Song runs top -> bottom. The horizontal playhead shows current position.
        val py = progress * height
        canvas.drawLine(width * 0.06f, py, width * 0.94f, py, playheadPaint)
    }
}
