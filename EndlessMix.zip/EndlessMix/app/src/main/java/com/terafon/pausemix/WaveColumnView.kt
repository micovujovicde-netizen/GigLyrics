package com.terafon.pausemix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.max

/**
 * High contrast full-track waveform.
 * Empty deck = one thin white line.
 * Loaded deck = real decoded amplitude overview + playhead.
 */
class WaveColumnView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val density = resources.displayMetrics.density
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = max(1.5f * density, 2f)
        strokeCap = Paint.Cap.ROUND
    }
    private val baselinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = max(1f * density, 1f)
    }
    private val playheadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = max(2.5f * density, 3f)
    }

    private var samples: FloatArray? = null
    private var hasTrack = false
    private var progress = 0f

    fun setEmpty() {
        hasTrack = false
        samples = null
        progress = 0f
        invalidate()
    }

    fun setTrackPresent(present: Boolean) {
        hasTrack = present
        if (!present) {
            samples = null
            progress = 0f
        }
        invalidate()
    }

    fun setWaveform(values: FloatArray?) {
        samples = values?.copyOf()
        hasTrack = values != null || hasTrack
        invalidate()
    }

    fun setProgress(value: Float) {
        progress = value.coerceIn(0f, 1f)
        invalidate()
    }

    // Kept for source compatibility with the earlier build.
    fun setTrackSeed(value: String?) = setTrackPresent(value != null)
    fun setRunning(value: Boolean) = Unit

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.BLACK)

        val midY = height / 2f
        val data = samples

        if (!hasTrack || data == null || data.isEmpty()) {
            // User requested a single line when nothing is loaded (and while analysis is pending).
            canvas.drawLine(width * 0.12f, midY, width * 0.88f, midY, baselinePaint)
            return
        }

        val usableTop = height * 0.08f
        val halfH = height * 0.40f
        val count = data.size
        if (count == 1) {
            val amp = data[0].coerceIn(0.02f, 1f) * halfH
            canvas.drawLine(width / 2f, midY - amp, width / 2f, midY + amp, wavePaint)
        } else {
            for (i in data.indices) {
                val x = (i.toFloat() / (count - 1).toFloat()) * width
                val amp = data[i].coerceIn(0.015f, 1f) * halfH
                canvas.drawLine(x, midY - amp, x, midY + amp, wavePaint)
            }
        }

        // Position marker makes intros, breaks and remaining structure obvious while playing.
        val px = progress * width
        canvas.drawLine(px, usableTop, px, height - usableTop, playheadPaint)
    }
}
