package com.terafon.pausemix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.max

/** Large black/white vertical volume fader, easier to hit than a rotated SeekBar. */
class VerticalFaderView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val density = resources.displayMetrics.density
    private val railPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = max(2f * density, 2f)
        strokeCap = Paint.Cap.ROUND
    }
    private val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = context.getColor(R.color.green_translucent)
        style = Paint.Style.FILL
    }

    var progress: Int = 100
        set(value) {
            field = value.coerceIn(0, 100)
            invalidate()
        }

    var onProgressChanged: ((Int) -> Unit)? = null

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.BLACK)
        val cx = width / 2f
        val top = height * 0.08f
        val bottom = height * 0.92f
        canvas.drawLine(cx, top, cx, bottom, railPaint)
        val y = bottom - (progress / 100f) * (bottom - top)
        val radius = minOf(width, height) * 0.085f
        canvas.drawCircle(cx, y, radius, knobPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!isEnabled) return false
        if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
            val top = height * 0.08f
            val bottom = height * 0.92f
            val y = event.y.coerceIn(top, bottom)
            progress = (((bottom - y) / (bottom - top)) * 100f).toInt()
            onProgressChanged?.invoke(progress)
            parent?.requestDisallowInterceptTouchEvent(true)
            return true
        }
        if (event.action == MotionEvent.ACTION_UP || event.action == MotionEvent.ACTION_CANCEL) {
            parent?.requestDisallowInterceptTouchEvent(false)
            performClick()
            return true
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
