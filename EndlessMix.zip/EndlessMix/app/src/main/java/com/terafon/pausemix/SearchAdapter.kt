package com.terafon.pausemix

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.terafon.pausemix.databinding.ItemSearchResultBinding
import com.terafon.pausemix.model.TrackRef

class SearchAdapter(
    private val targetDeck: String?,
    private val onImportA: (TrackRef) -> Unit,
    private val onImportB: (TrackRef) -> Unit
) : RecyclerView.Adapter<SearchAdapter.VH>() {

    private val items = mutableListOf<TrackRef>()

    fun submit(newItems: List<TrackRef>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    class VH(val binding: ItemSearchResultBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH = VH(
        ItemSearchResultBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.binding.title.text = item.title
        val mins = item.durationSeconds / 60
        val secs = item.durationSeconds % 60
        holder.binding.meta.text = "${item.uploader}   %d:%02d".format(mins, secs)

        when (targetDeck) {
            "A" -> {
                holder.binding.importA.visibility = View.VISIBLE
                holder.binding.importA.text = "LOAD A"
                holder.binding.importB.visibility = View.GONE
                holder.binding.root.setOnClickListener { onImportA(item) }
            }
            "B" -> {
                holder.binding.importA.visibility = View.GONE
                holder.binding.importB.visibility = View.VISIBLE
                holder.binding.importB.text = "LOAD B"
                holder.binding.root.setOnClickListener { onImportB(item) }
            }
            else -> {
                holder.binding.importA.visibility = View.VISIBLE
                holder.binding.importB.visibility = View.VISIBLE
                holder.binding.importA.text = "A"
                holder.binding.importB.text = "B"
                holder.binding.root.setOnClickListener(null)
            }
        }

        holder.binding.importA.setOnClickListener { onImportA(item) }
        holder.binding.importB.setOnClickListener { onImportB(item) }
    }
}
