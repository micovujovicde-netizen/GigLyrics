package com.terafon.pausemix

import android.content.Context
import org.json.JSONObject
import java.text.Normalizer
import java.util.Locale

/**
 * Read-only QEM library backed by assets/fonoteka.json.
 * JSON is the source of truth for QEM controls and artist intersections.
 */
class QemFonoteka(context: Context) {
    data class ArtistChoice(
        val id: String,
        val name: String,
        val rank: Int,
        val region: String,
        val style: String,
        val era: String,
        val countries: List<String>
    )

    data class UiOption(val key: String, val label: String, val kind: String = "style")

    private val root: JSONObject = context.assets.open("fonoteka.json").bufferedReader().use { reader ->
        JSONObject(reader.readText())
    }
    private val artists = root.getJSONObject("artists")
    private val pools = root.getJSONObject("pools")

    val availableRegions: Set<String> by lazy { jsonKeys(pools).toSet() }
    val availableStyles: Set<String> by lazy {
        root.optJSONObject("styles")?.let(::jsonKeys)?.toSet().orEmpty()
    }
    val availableEras: Set<String> by lazy {
        root.optJSONObject("eras")?.let(::jsonKeys)?.toSet().orEmpty()
    }

    fun regionOptions(): List<UiOption> {
        val meta = root.optJSONObject("regions")
        val keys = orderedKeys("regions", meta ?: pools)
        return keys.map { key ->
            UiOption(key, meta?.optJSONObject(key)?.optString("label")?.takeIf { it.isNotBlank() } ?: prettify(key), "region")
        }
    }

    fun styleOptions(regionKeys: Set<String>): List<UiOption> {
        val normal = root.optJSONObject("styles")
        val selectedRegions = if (regionKeys.isEmpty()) availableRegions else regionKeys.filter { it in availableRegions }.toSet()
        val out = mutableListOf<UiOption>()
        if (normal != null) {
            orderedKeys("styles", normal).forEach { key ->
                if (styleHasData(key, selectedRegions)) {
                    val label = normal.optJSONObject(key)?.optString("label")?.takeIf { it.isNotBlank() } ?: prettify(key)
                    out += UiOption(key, label, "style")
                }
            }
        }
        val combined = root.optJSONObject("combined_style_buttons")
        if (combined != null) {
            orderedKeys("combined_styles", combined).forEach { key ->
                val parts = combined.optJSONObject(key)?.optJSONArray("combine")
                val components = (0 until (parts?.length() ?: 0)).mapNotNull { i -> parts?.optString(i)?.takeIf { it.isNotBlank() } }
                if (components.isNotEmpty() && components.any { styleHasData(it, selectedRegions) }) {
                    out += UiOption(key, combinedLabel(key), "combined")
                }
            }
        }
        val special = root.optJSONObject("special_styles")
        if (special != null) {
            orderedKeys("special_styles", special).forEach { key ->
                val label = special.optJSONObject(key)?.optString("label")?.takeIf { it.isNotBlank() } ?: prettify(key)
                out += UiOption(key, label, "special")
            }
        }
        val attrs = root.optJSONObject("attribute_filters")
        if (attrs != null) {
            orderedKeys("attributes", attrs).forEach { key ->
                val label = attrs.optJSONObject(key)?.optString("label")?.takeIf { it.isNotBlank() } ?: prettify(key)
                out += UiOption(key, label, "attribute")
            }
        }
        return out
    }

    fun combinedComponents(key: String): Set<String> {
        val arr = root.optJSONObject("combined_style_buttons")?.optJSONObject(key)?.optJSONArray("combine") ?: return emptySet()
        return (0 until arr.length()).mapNotNull { i -> arr.optString(i).takeIf { it.isNotBlank() } }.toSet()
    }

    fun availableCountries(regionKeys: Set<String>): List<String> {
        val regions = if (regionKeys.isEmpty()) availableRegions else regionKeys.filter { it in availableRegions }.toSet()
        val ids = linkedSetOf<String>()
        for (regionKey in regions) {
            val region = pools.optJSONObject(regionKey) ?: continue
            for (styleKey in jsonKeys(region)) {
                val style = region.optJSONObject(styleKey) ?: continue
                for (eraKey in jsonKeys(style)) {
                    val arr = style.optJSONArray(eraKey) ?: continue
                    for (i in 0 until arr.length()) arr.optString(i).takeIf { it.isNotBlank() }?.let(ids::add)
                }
            }
        }
        val countries = linkedSetOf<String>()
        ids.forEach { id ->
            val arr = artists.optJSONObject(id)?.optJSONArray("countries") ?: return@forEach
            for (i in 0 until arr.length()) {
                arr.optString(i).split('/', ',', ';').map { it.trim() }.filter { it.isNotBlank() }.forEach(countries::add)
            }
        }
        return countries.sortedBy { normal(it) }
    }

    fun buildArtistPool(
        regionKeys: Set<String>,
        country: String?,
        styleKeys: Set<String>,
        eraKeys: Set<String>,
        includeClassical: Boolean
    ): List<ArtistChoice> {
        val regions = if (regionKeys.isEmpty()) availableRegions else regionKeys.filter { it in availableRegions }.toSet()
        val styles = when {
            styleKeys.isNotEmpty() -> styleKeys.filter { it in availableStyles }.toSet()
            includeClassical -> emptySet()
            else -> availableStyles
        }
        val eras = if (eraKeys.isEmpty()) availableEras else eraKeys.filter { it in availableEras }.toSet()
        if (regions.isEmpty() || (styles.isEmpty() && !includeClassical) || eras.isEmpty()) return emptyList()

        val best = linkedMapOf<String, ArtistChoice>()
        for (regionKey in regions) {
            val region = pools.optJSONObject(regionKey) ?: continue
            for (styleKey in styles) {
                val style = region.optJSONObject(styleKey) ?: continue
                for (eraKey in eras) {
                    val ids = style.optJSONArray(eraKey) ?: continue
                    for (i in 0 until ids.length()) {
                        val id = ids.optString(i)
                        if (id.isBlank()) continue
                        val artist = artists.optJSONObject(id) ?: continue
                        val countries = artist.optJSONArray("countries")?.let { arr ->
                            (0 until arr.length()).mapNotNull { idx -> arr.optString(idx).takeIf(String::isNotBlank) }
                        }.orEmpty()
                        if (!country.isNullOrBlank() && countries.none { countryMatches(it, country) }) continue
                        val choice = ArtistChoice(
                            id = id,
                            name = artist.optString("name", id),
                            rank = i + 1,
                            region = regionKey,
                            style = styleKey,
                            era = eraKey,
                            countries = countries
                        )
                        val existing = best[id]
                        if (existing == null || choice.rank < existing.rank) best[id] = choice
                    }
                }
            }
        }
        if (includeClassical) addClassical(best, country, eraKeys)
        return best.values.sortedWith(compareBy<ArtistChoice> { it.rank }.thenBy { it.name })
    }

    private fun styleHasData(styleKey: String, regions: Set<String>): Boolean {
        return regions.any { regionKey ->
            val style = pools.optJSONObject(regionKey)?.optJSONObject(styleKey) ?: return@any false
            jsonKeys(style).any { eraKey -> (style.optJSONArray(eraKey)?.length() ?: 0) > 0 }
        }
    }

    private fun addClassical(target: MutableMap<String, ArtistChoice>, country: String?, eraKeys: Set<String>) {
        val classical = root.optJSONObject("special_styles")?.optJSONObject("CLASSICAL") ?: return
        val periods = classical.optJSONObject("periods") ?: return
        val selectedEras = if (eraKeys.isEmpty()) availableEras else eraKeys
        val periodKeys = if (selectedEras.any { it != "EVERGREEN" }) setOf("CONTEMPORARY") else jsonKeys(periods).toSet()
        periodKeys.forEach { periodKey ->
            val arr = periods.optJSONArray(periodKey) ?: return@forEach
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val name = item.optString("composer")
                if (name.isBlank()) continue
                val composerCountry = item.optString("country")
                if (!country.isNullOrBlank() && !countryMatches(composerCountry, country)) continue
                val id = "classical_${normal(name).replace(' ', '_')}"
                val rank = item.optInt("rank", i + 1)
                val choice = ArtistChoice(id, name, rank, "CLASSICAL", "CLASSICAL", selectedEras.firstOrNull() ?: "EVERGREEN", listOfNotNull(composerCountry.takeIf(String::isNotBlank)))
                val existing = target[id]
                if (existing == null || choice.rank < existing.rank) target[id] = choice
            }
        }
    }

    private fun countryMatches(stored: String, requested: String): Boolean {
        val q = normal(requested)
        if (normal(stored) == q) return true
        return stored.split('/', ',', ';').any { normal(it) == q }
    }

    private fun combinedLabel(key: String): String = when (key) {
        "POP_ROCK" -> "Pop-Rock"
        "HIP_HOP_RAP" -> "Hip-Hop / Rap"
        "RNB_HIP_HOP" -> "R&B / Hip-Hop"
        else -> prettify(key)
    }

    private fun prettify(key: String): String = key.replace('_', ' ').lowercase(Locale.ROOT)
        .split(' ').joinToString(" ") { w -> w.replaceFirstChar { c -> c.uppercaseChar() } }

    private fun normal(value: String): String {
        val decomposed = Normalizer.normalize(value, Normalizer.Form.NFD)
        return decomposed.replace("\\p{Mn}+".toRegex(), "")
            .lowercase(Locale.ROOT).replace("đ", "dj")
            .replace("[^a-z0-9]+".toRegex(), " ").trim().replace("\\s+".toRegex(), " ")
    }

    private fun orderedKeys(orderName: String, obj: JSONObject): List<String> {
        val order = root.optJSONObject("ui_order")?.optJSONArray(orderName)
        val preferred = if (order == null) emptyList() else (0 until order.length()).mapNotNull { i -> order.optString(i).takeIf { it.isNotBlank() && obj.has(it) } }
        val remaining = jsonKeys(obj).filter { it !in preferred }.sorted()
        return preferred + remaining
    }

    private fun jsonKeys(obj: JSONObject): List<String> {
        val result = mutableListOf<String>()
        val it = obj.keys()
        while (it.hasNext()) result += it.next()
        return result
    }
}
