package com.terafon.pausemix

import android.content.Context
import org.json.JSONObject
import java.text.Normalizer
import java.util.Locale

/**
 * Read-only QEM artist library backed by assets/fonoteka.json.
 *
 * QEM owns filtering/discovery only. Playback/decks stay in MixerActivity's existing Endless engine.
 * The JSON is the source of truth: if an intersection is empty, this class returns an empty list.
 */
class QemFonoteka(context: Context) {
    data class ArtistChoice(
        val id: String,
        val name: String,
        val rank: Int,
        val region: String,
        val style: String,
        val era: String,
        val countries: List<String>
    )

    private val root: JSONObject = context.assets.open("fonoteka.json").bufferedReader().use { reader ->
        JSONObject(reader.readText())
    }
    private val artists = root.getJSONObject("artists")
    private val pools = root.getJSONObject("pools")

    val availableRegions: Set<String> by lazy { jsonKeys(pools).toSet() }
    val availableStyles: Set<String> by lazy {
        root.optJSONObject("styles")?.let(::jsonKeys)?.toSet().orEmpty()
    }
    val availableEras: Set<String> by lazy {
        root.optJSONObject("eras")?.let(::jsonKeys)?.toSet().orEmpty()
    }

    fun buildArtistPool(
        regionKeys: Set<String>,
        country: String?,
        styleKeys: Set<String>,
        eraKeys: Set<String>,
        includeClassical: Boolean
    ): List<ArtistChoice> {
        val regions = if (regionKeys.isEmpty()) availableRegions else regionKeys.filter { it in availableRegions }.toSet()
        val styles = when {
            styleKeys.isNotEmpty() -> styleKeys.filter { it in availableStyles }.toSet()
            includeClassical -> emptySet()
            else -> availableStyles
        }
        val eras = if (eraKeys.isEmpty()) availableEras else eraKeys.filter { it in availableEras }.toSet()
        if (regions.isEmpty() || (styles.isEmpty() && !includeClassical) || eras.isEmpty()) return emptyList()

        val best = linkedMapOf<String, ArtistChoice>()
        for (regionKey in regions) {
            val region = pools.optJSONObject(regionKey) ?: continue
            for (styleKey in styles) {
                val style = region.optJSONObject(styleKey) ?: continue
                for (eraKey in eras) {
                    val ids = style.optJSONArray(eraKey) ?: continue
                    for (i in 0 until ids.length()) {
                        val id = ids.optString(i)
                        if (id.isBlank()) continue
                        val artist = artists.optJSONObject(id) ?: continue
                        val countries = artist.optJSONArray("countries")?.let { arr ->
                            (0 until arr.length()).mapNotNull { idx -> arr.optString(idx).takeIf(String::isNotBlank) }
                        }.orEmpty()
                        if (!country.isNullOrBlank() && countries.none { countryMatches(it, country) }) continue
                        val choice = ArtistChoice(
                            id = id,
                            name = artist.optString("name", id),
                            rank = i + 1,
                            region = regionKey,
                            style = styleKey,
                            era = eraKey,
                            countries = countries
                        )
                        val existing = best[id]
                        if (existing == null || choice.rank < existing.rank) best[id] = choice
                    }
                }
            }
        }

        if (includeClassical) {
            addClassical(best, country, eraKeys)
        }
        return best.values.sortedWith(compareBy<ArtistChoice> { it.rank }.thenBy { it.name })
    }

    private fun addClassical(
        target: MutableMap<String, ArtistChoice>,
        country: String?,
        eraKeys: Set<String>
    ) {
        val classical = root.optJSONObject("special_styles")?.optJSONObject("CLASSICAL") ?: return
        val periods = classical.optJSONObject("periods") ?: return
        val selectedEras = if (eraKeys.isEmpty()) availableEras else eraKeys
        val periodKeys = if (selectedEras.any { it != "EVERGREEN" }) {
            setOf("CONTEMPORARY")
        } else {
            jsonKeys(periods).toSet()
        }
        periodKeys.forEach { periodKey ->
            val arr = periods.optJSONArray(periodKey) ?: return@forEach
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val name = item.optString("composer")
                if (name.isBlank()) continue
                val composerCountry = item.optString("country")
                if (!country.isNullOrBlank() && !countryMatches(composerCountry, country)) continue
                val id = "classical_${normal(name).replace(' ', '_')}"
                val rank = item.optInt("rank", i + 1)
                val choice = ArtistChoice(
                    id = id,
                    name = name,
                    rank = rank,
                    region = "CLASSICAL",
                    style = "CLASSICAL",
                    era = selectedEras.firstOrNull() ?: "EVERGREEN",
                    countries = listOfNotNull(composerCountry.takeIf(String::isNotBlank))
                )
                val existing = target[id]
                if (existing == null || choice.rank < existing.rank) target[id] = choice
            }
        }
    }

    private fun countryMatches(stored: String, requested: String): Boolean {
        val q = normal(requested)
        if (normal(stored) == q) return true
        return stored.split('/', ',', ';').any { part -> normal(part) == q }
    }

    private fun normal(value: String): String {
        val decomposed = Normalizer.normalize(value, Normalizer.Form.NFD)
        return decomposed.replace("\\p{Mn}+".toRegex(), "")
            .lowercase(Locale.ROOT)
            .replace("đ", "dj")
            .replace("[^a-z0-9]+".toRegex(), " ")
            .trim()
            .replace("\\s+".toRegex(), " ")
    }

    private fun jsonKeys(obj: JSONObject): List<String> {
        val result = mutableListOf<String>()
        val it = obj.keys()
        while (it.hasNext()) result += it.next()
        return result
    }
}
