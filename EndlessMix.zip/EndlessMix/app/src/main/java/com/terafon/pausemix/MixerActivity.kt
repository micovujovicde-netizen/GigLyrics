package com.terafon.pausemix

import android.content.Intent
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Bundle
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.terafon.pausemix.databinding.ActivityMixerBinding
import com.terafon.pausemix.model.MixerStore
import com.terafon.pausemix.model.TrackRef
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class MixerActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMixerBinding
    private lateinit var playerA: ExoPlayer
    private lateinit var playerB: ExoPlayer

    private var userVolA = 1f
    private var userVolB = 1f
    private var cross = 0.5f

    private var lastTrackAUrl: String? = null
    private var lastTrackBUrl: String? = null
    private var analyzingA: String? = null
    private var analyzingB: String? = null

    private val tapA = TapTempo()
    private val tapB = TapTempo()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMixerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        playerA = ExoPlayer.Builder(this).build()
        playerB = ExoPlayer.Builder(this).build()

        binding.backToSearch.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

        binding.loadA.setOnClickListener { openSearchFor("A") }
        binding.loadB.setOnClickListener { openSearchFor("B") }
        binding.playA.setOnClickListener {
            val track = MixerStore.deckA
            if (track == null) {
                Toast.makeText(this, "Press A to load a song", Toast.LENGTH_SHORT).show()
            } else toggleDeck(true, track)
        }
        binding.playB.setOnClickListener {
            val track = MixerStore.deckB
            if (track == null) {
                Toast.makeText(this, "Press B to load a song", Toast.LENGTH_SHORT).show()
            } else toggleDeck(false, track)
        }

        binding.bpmA.setOnClickListener {
            tapA.tap()?.let { binding.bpmA.text = "$it BPM" }
        }
        binding.bpmA.setOnLongClickListener {
            tapA.reset()
            binding.bpmA.text = "-- BPM • TAP"
            true
        }
        binding.bpmB.setOnClickListener {
            tapB.tap()?.let { binding.bpmB.text = "$it BPM" }
        }
        binding.bpmB.setOnLongClickListener {
            tapB.reset()
            binding.bpmB.text = "-- BPM • TAP"
            true
        }

        binding.volumeA.progress = 100
        binding.volumeA.onProgressChanged = { p ->
            userVolA = p / 100f
            applyVolumes()
        }
        binding.volumeB.progress = 100
        binding.volumeB.onProgressChanged = { p ->
            userVolB = p / 100f
            applyVolumes()
        }
        binding.crossfader.setOnSeekBarChangeListener(simpleSeek { p ->
            cross = p / 100f
            applyVolumes()
        })

        refreshDecks(force = true)
        updateOutputIndicator()
        applyVolumes()

        // Keep the white playhead synchronized with the current position.
        lifecycleScope.launch {
            while (isActive) {
                updateWaveProgress(playerA, true)
                updateWaveProgress(playerB, false)
                delay(120)
            }
        }
    }

    private fun openSearchFor(deck: String) {
        startActivity(
            Intent(this, MainActivity::class.java)
                .putExtra(MainActivity.EXTRA_TARGET_DECK, deck)
        )
    }

    private fun simpleSeek(onProgress: (Int) -> Unit) =
        object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                onProgress(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        }

    private fun toggleDeck(isA: Boolean, track: TrackRef) {
        val player = if (isA) playerA else playerB
        val button = if (isA) binding.playA else binding.playB

        if (player.mediaItemCount > 0) {
            if (player.isPlaying) {
                player.pause()
                button.text = "▶ PLAY"
            } else {
                player.play()
                button.text = "II PAUSE"
            }
            return
        }

        button.text = "LOADING"
        lifecycleScope.launch {
            runCatching {
                val direct = track.streamUrl ?: withContext(Dispatchers.IO) {
                    AudioResolver.resolveBestAudioUrl(track.url)
                }
                direct
            }.onSuccess { direct ->
                // Keep the freshly resolved URL so the waveform and player use the same stream.
                val updated = track.copy(streamUrl = direct)
                if (isA) MixerStore.deckA = updated else MixerStore.deckB = updated

                player.setMediaItem(MediaItem.fromUri(direct))
                player.prepare()
                player.play()
                button.text = "II PAUSE"
                analyzeWaveform(isA, updated)
            }.onFailure {
                button.text = "▶ PLAY"
                Toast.makeText(
                    this@MixerActivity,
                    "Stream error: ${it.message ?: "unknown"}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun refreshDecks(force: Boolean = false) {
        val a = MixerStore.deckA
        val b = MixerStore.deckB

        if (force || a?.url != lastTrackAUrl) {
            if (!force && lastTrackAUrl != null) {
                playerA.stop()
                playerA.clearMediaItems()
            }
            lastTrackAUrl = a?.url
            binding.titleA.text = a?.title ?: "EMPTY"
            binding.playA.text = "▶ PLAY"
            if (a == null) {
                binding.waveA.setEmpty()
            } else {
                binding.waveA.setTrackPresent(true)
                val cached = MixerStore.waveA
                if (cached != null) binding.waveA.setWaveform(cached) else analyzeWaveform(true, a)
            }
        }

        if (force || b?.url != lastTrackBUrl) {
            if (!force && lastTrackBUrl != null) {
                playerB.stop()
                playerB.clearMediaItems()
            }
            lastTrackBUrl = b?.url
            binding.titleB.text = b?.title ?: "EMPTY"
            binding.playB.text = "▶ PLAY"
            if (b == null) {
                binding.waveB.setEmpty()
            } else {
                binding.waveB.setTrackPresent(true)
                val cached = MixerStore.waveB
                if (cached != null) binding.waveB.setWaveform(cached) else analyzeWaveform(false, b)
            }
        }
    }

    private fun analyzeWaveform(isA: Boolean, track: TrackRef) {
        val direct = track.streamUrl ?: return
        val key = track.url
        if (isA) {
            if (MixerStore.waveA != null || analyzingA == key) return
            analyzingA = key
        } else {
            if (MixerStore.waveB != null || analyzingB == key) return
            analyzingB = key
        }

        lifecycleScope.launch {
            val wave = runCatching {
                withContext(Dispatchers.IO) { WaveformAnalyzer.analyze(direct) }
            }.getOrNull()

            if (isA) {
                analyzingA = null
                if (MixerStore.deckA?.url == key && wave != null) {
                    MixerStore.waveA = wave
                    binding.waveA.setWaveform(wave)
                }
            } else {
                analyzingB = null
                if (MixerStore.deckB?.url == key && wave != null) {
                    MixerStore.waveB = wave
                    binding.waveB.setWaveform(wave)
                }
            }
        }
    }

    private fun updateWaveProgress(player: ExoPlayer, isA: Boolean) {
        val duration = player.duration
        val p = if (duration > 0) {
            (player.currentPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
        } else 0f
        if (isA) binding.waveA.setProgress(p) else binding.waveB.setProgress(p)
    }

    private fun applyVolumes() {
        // Equal-power crossfade avoids a deep volume dip in the center.
        val aGain = cos(cross * PI / 2.0).toFloat()
        val bGain = sin(cross * PI / 2.0).toFloat()
        playerA.volume = (userVolA * aGain).coerceIn(0f, 1f)
        playerB.volume = (userVolB * bGain).coerceIn(0f, 1f)
    }

    private fun updateOutputIndicator() {
        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        val outputs = audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val bt = outputs.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                it.type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
                it.type == AudioDeviceInfo.TYPE_BLE_SPEAKER
        }
        binding.outputIndicator.text = if (bt != null) "BT" else "DEVICE"
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized) {
            refreshDecks()
            updateOutputIndicator()
        }
    }

    override fun onDestroy() {
        playerA.release()
        playerB.release()
        super.onDestroy()
    }
}
