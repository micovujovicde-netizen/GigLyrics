package com.terafon.pausemix

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Bundle
import android.os.SystemClock
import android.speech.RecognizerIntent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.recyclerview.widget.LinearLayoutManager
import com.terafon.pausemix.databinding.ActivityMixerBinding
import com.terafon.pausemix.model.MixerStore
import com.terafon.pausemix.model.TrackRef
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import kotlin.math.roundToInt

/**
 * EndlessMix V1.
 *
 * Design rule: there is one owner for every operation.
 * - DeckSlot owns one deck's lifecycle.
 * - discoveryJob is the only automatic search loop.
 * - transitionJob is the only automatic/manual mix transition.
 * - ACTIVE is never inferred from ExoPlayer.isPlaying; activeDeck is authoritative.
 *
 * The goal is robustness for non-expert users, not maximum cleverness.
 */
class MixerActivity : AppCompatActivity() {

    private enum class Deck { A, B;
        fun other(): Deck = if (this == A) B else A
    }

    private enum class DeckState { EMPTY, LOADING, READY, PLAYING }

    private data class DeckSlot(
        var state: DeckState = DeckState.EMPTY,
        var track: TrackRef? = null,
        var generation: Long = 0L,
        var loadJob: Job? = null
    )

    private data class SessionProfile(
        val regions: Set<String> = emptySet(),
        val styles: Set<String> = emptySet(),
        val eras: Set<String> = emptySet(),
        val tempo: String? = null,
        val allowLive: Boolean = false,
        val allowCover: Boolean = false,
        val onlyOfficial: Boolean = false
    )

    private lateinit var binding: ActivityMixerBinding
    private lateinit var playerA: ExoPlayer
    private lateinit var playerB: ExoPlayer
    private lateinit var audioManager: AudioManager
    private lateinit var audioFocusRequest: AudioFocusRequest

    private val searchRepo = SearchRepository()
    private val slotA = DeckSlot()
    private val slotB = DeckSlot()

    private var activeDeck: Deck? = null
    private var autoEnabled = false
    private var controlsLocked = false
    private var sessionGeneration = 0L
    private var currentProfile = SessionProfile()

    private var discoveryJob: Job? = null
    private var transitionJob: Job? = null
    private var uiJob: Job? = null

    private val usedUrls = linkedSetOf<String>()
    private val failedUrls = linkedSetOf<String>()

    private var userVolA = 1f
    private var userVolB = 1f
    private var masterVolume = 1f
    private var masterMuted = false
    private var cross = 0f // 0=A, 1=B

    private var allowLive = false
    private var allowCover = false
    private var onlyOfficial = false
    private var tempoBand: String? = null

    private val quickRegions = linkedSetOf<String>()
    private val quickStyles = linkedSetOf<String>()
    private val quickEras = linkedSetOf<String>()
    private var quickCountry: String? = null
    private var quickTempo: String? = null
    private var quickOpen = false
    private var quickStartJob: Job? = null

    private val autoMixAtMs = 12_000L
    private val crossfadeMs = 3_000L

    private var lastStoreAUrl: String? = null
    private var lastStoreBUrl: String? = null

    private val speechLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != RESULT_OK || !::binding.isInitialized) return@registerForActivityResult
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.trim().orEmpty()
        if (spoken.isNotBlank()) {
            binding.endlessSearchInput.setText(spoken)
            binding.endlessSearchInput.setSelection(spoken.length)
            runBrowserSearch()
        }
    }

    private val micPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchSpeechRecognizer()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMixerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        playerA = ExoPlayer.Builder(this).build()
        playerB = ExoPlayer.Builder(this).build()
        setupAudioFocus()
        setupPlayers()
        setupUi()
        setupQuickControls()
        setupBrowserPanel()
        restoreManualStoreTracks()
        startUiLoop()
        renderAll()
    }

    override fun onResume() {
        super.onResume()
        restoreManualStoreTracks()
    }

    override fun onDestroy() {
        sessionGeneration++
        discoveryJob?.cancel()
        transitionJob?.cancel()
        quickStartJob?.cancel()
        uiJob?.cancel()
        slotA.loadJob?.cancel()
        slotB.loadJob?.cancel()
        runCatching { playerA.release() }
        runCatching { playerB.release() }
        super.onDestroy()
    }

    // ------------------------------------------------------------------------
    // Player ownership
    // ------------------------------------------------------------------------

    private fun setupPlayers() {
        playerA.addListener(playerListener(Deck.A))
        playerB.addListener(playerListener(Deck.B))
    }

    private fun playerListener(deck: Deck) = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_ENDED && activeDeck == deck) {
                lifecycleScope.launch { handleActiveEnded(deck) }
            }
        }

        override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
            lifecycleScope.launch { handlePlayerFailure(deck) }
        }
    }

    private suspend fun handlePlayerFailure(deck: Deck) {
        val slot = slot(deck)
        if (activeDeck == deck && slot.state == DeckState.PLAYING) {
            // Never erase the other deck because ACTIVE failed. If a safe NEXT exists, use it.
            val other = deck.other()
            if (slot(other).state == DeckState.READY) {
                startTransition(immediate = true)
            } else {
                clearDeck(deck)
                activeDeck = null
                if (autoEnabled) bootstrapFromSilence()
            }
        } else {
            // Waiting-deck failure is local-only.
            clearDeck(deck)
            if (autoEnabled) ensureWaitingDeck()
        }
    }

    private suspend fun handleActiveEnded(deck: Deck) {
        val other = deck.other()
        if (slot(other).state == DeckState.READY) {
            startTransition(immediate = true, fadeMs = 350L)
        } else {
            clearDeck(deck)
            activeDeck = null
            if (autoEnabled) bootstrapFromSilence()
        }
    }

    private fun slot(deck: Deck): DeckSlot = if (deck == Deck.A) slotA else slotB
    private fun player(deck: Deck): ExoPlayer = if (deck == Deck.A) playerA else playerB

    private fun clearDeck(deck: Deck, keepStore: Boolean = false) {
        val s = slot(deck)
        s.generation++
        s.loadJob?.cancel()
        s.loadJob = null
        s.state = DeckState.EMPTY
        s.track = null
        runCatching {
            player(deck).stop()
            player(deck).clearMediaItems()
        }
        if (!keepStore) {
            if (deck == Deck.A) {
                MixerStore.deckA = null
                MixerStore.waveA = null
            } else {
                MixerStore.deckB = null
                MixerStore.waveB = null
            }
        }
        renderDeck(deck)
        updateInstantNextVisibility()
    }

    /**
     * The only function allowed to resolve + prepare a track into a deck.
     * Stale jobs cannot commit because each deck has a generation token.
     */
    private suspend fun loadIntoDeck(deck: Deck, track: TrackRef): Boolean {
        // ACTIVE is immutable. Every caller must pick the waiting deck.
        if (activeDeck == deck && slot(deck).state == DeckState.PLAYING) return false

        val s = slot(deck)
        s.generation++
        val myGeneration = s.generation
        s.loadJob?.cancel()
        s.state = DeckState.LOADING
        s.track = track
        renderDeck(deck)
        updateInstantNextVisibility()

        val resolved = withContext(Dispatchers.IO) {
            runCatching {
                val stream = track.streamUrl?.takeIf { it.isNotBlank() } ?: AudioResolver.resolveBestAudioUrl(track.url)
                track.copy(streamUrl = stream)
            }.getOrNull()
        }

        if (s.generation != myGeneration) return false
        if (resolved?.streamUrl.isNullOrBlank()) {
            failedUrls += track.url
            if (activeDeck != deck) clearDeck(deck)
            return false
        }

        val p = player(deck)
        runCatching {
            p.stop()
            p.clearMediaItems()
            p.setMediaItem(MediaItem.fromUri(resolved!!.streamUrl!!))
            p.prepare()
        }.onFailure {
            failedUrls += track.url
            if (activeDeck != deck) clearDeck(deck)
            return false
        }

        val ready = withTimeoutOrNull(15_000L) {
            while (isActive && s.generation == myGeneration) {
                if (p.playbackState == Player.STATE_READY) return@withTimeoutOrNull true
                if (p.playerError != null) return@withTimeoutOrNull false
                delay(80)
            }
            false
        } == true

        if (s.generation != myGeneration) return false
        if (!ready) {
            failedUrls += track.url
            if (activeDeck != deck) clearDeck(deck)
            return false
        }

        s.track = resolved
        s.state = DeckState.READY
        if (deck == Deck.A) {
            MixerStore.setA(resolved)
            lastStoreAUrl = resolved.url
        } else {
            MixerStore.setB(resolved)
            lastStoreBUrl = resolved.url
        }
        usedUrls += resolved.url
        renderDeck(deck)
        updateInstantNextVisibility()
        return true
    }

    private fun startDeck(deck: Deck) {
        val s = slot(deck)
        if (s.state != DeckState.READY && s.state != DeckState.PLAYING) return

        // Exactly one playback owner outside a crossfade.
        activeDeck = deck
        s.state = DeckState.PLAYING
        val other = deck.other()
        if (slot(other).state == DeckState.PLAYING) slot(other).state = DeckState.READY

        cross = if (deck == Deck.A) 0f else 1f
        binding.crossfader.progress = (cross * 100).roundToInt()
        runCatching { player(deck).play() }
        if (transitionJob?.isActive != true) runCatching { player(other).pause() }
        applyVolumes()
        renderDeck(deck)
        renderDeck(other)
        updateInstantNextVisibility()
        if (autoEnabled) ensureWaitingDeck()
    }

    // ------------------------------------------------------------------------
    // One discovery loop
    // ------------------------------------------------------------------------

    private fun ensureWaitingDeck() {
        if (!autoEnabled) return
        val owner = activeDeck ?: return
        val target = owner.other()
        val targetSlot = slot(target)
        if (targetSlot.state == DeckState.READY || targetSlot.state == DeckState.LOADING) return
        if (discoveryJob?.isActive == true) return

        val mySession = sessionGeneration
        discoveryJob = lifecycleScope.launch {
            while (isActive && autoEnabled && sessionGeneration == mySession) {
                val currentOwner = activeDeck ?: break
                val waiting = currentOwner.other()
                if (slot(waiting).state == DeckState.READY) break
                if (slot(waiting).state == DeckState.PLAYING) break

                val pool = searchCandidatePool(currentProfile)
                if (pool.isEmpty()) {
                    delay(2_500)
                    continue
                }

                var loaded = false
                for (candidate in pool) {
                    if (!isActive || !autoEnabled || sessionGeneration != mySession) break
                    if (activeDeck != currentOwner) break
                    if (!candidateAllowed(candidate, currentProfile, hard = true)) continue
                    if (candidate.url in usedUrls || candidate.url in failedUrls) continue
                    if (candidate.url == slot(currentOwner).track?.url) continue

                    loaded = loadIntoDeck(waiting, candidate)
                    if (loaded) break
                }

                if (loaded) break
                delay(1_200)
            }
            discoveryJob = null
            if (autoEnabled && activeDeck != null && slot(activeDeck!!.other()).state == DeckState.EMPTY) {
                // No dead terminal state: re-kick after a short pause.
                lifecycleScope.launch {
                    delay(2_000)
                    ensureWaitingDeck()
                }
            }
        }
    }

    private suspend fun bootstrapFromSilence() {
        if (!autoEnabled || activeDeck != null) return
        val mySession = sessionGeneration
        val pool = searchCandidatePool(currentProfile)
        for (candidate in pool) {
            if (!autoEnabled || sessionGeneration != mySession || activeDeck != null) return
            if (!candidateAllowed(candidate, currentProfile, hard = true)) continue
            if (candidate.url in failedUrls) continue
            if (loadIntoDeck(Deck.A, candidate)) {
                startDeck(Deck.A)
                ensureWaitingDeck()
                return
            }
        }
    }

    /**
     * Search is deliberately forgiving. It tries the user's exact request first, then progressively
     * simpler queries so contradictory amateur input cannot permanently wedge the app.
     */
    private suspend fun searchCandidatePool(profile: SessionProfile): List<TrackRef> = withContext(Dispatchers.IO) {
        val queries = buildQueryLadder(profile)
        val out = linkedMapOf<String, TrackRef>()
        for (q in queries) {
            val results = runCatching { searchRepo.search(q) }.getOrElse { emptyList() }
            for (track in results) {
                if (track.url.isNotBlank()) out.putIfAbsent(track.url, track)
            }
            if (out.size >= 24) break
        }
        out.values.toList().shuffled()
    }

    private fun buildQueryLadder(profile: SessionProfile): List<String> {
        val region = (profile.regions + listOfNotNull(quickCountry)).joinToString(" ")
        val style = profile.styles.joinToString(" ")
        val era = profile.eras.joinToString(" ")
        val tempo = profile.tempo.orEmpty()
        val official = if (profile.onlyOfficial) "official" else ""

        fun q(vararg parts: String): String = parts.filter { it.isNotBlank() }.joinToString(" ").trim()

        return linkedSetOf(
            q(region, style, era, tempo, official, "music"),
            q(region, style, era, official, "songs"),
            q(region, style, official, "music"),
            q(style, era, official, "music"),
            q(region, official, "popular music"),
            q(style, official, "popular songs"),
            q("popular music", official)
        ).filter { it.isNotBlank() }
    }

    private fun candidateAllowed(track: TrackRef, profile: SessionProfile, hard: Boolean): Boolean {
        val text = "${track.title} ${track.uploader}".lowercase(Locale.ROOT)
        val junk = listOf(
            "interview", "podcast", "news", "reaction", "documentary", "trailer",
            "compilation", "greatest hits", "top 50", "top 100", "playlist", "dj mix", "medley",
            "karaoke", "tutorial", "lesson"
        )
        if (junk.any { it in text }) return false
        if (!profile.allowLive && Regex("\\blive\\b|concert|festival|uživo|uzivo").containsMatchIn(text)) return false
        if (!profile.allowCover && Regex("\\bcover\\b|tribute").containsMatchIn(text)) return false
        if (track.durationSeconds in 1..74) return false
        if (track.durationSeconds > 25 * 60) return false

        // V1 never lets imperfect metadata create a dead end. Exact semantics are expressed by search
        // queries; these lightweight checks remove obvious contradictions only.
        if (hard && profile.onlyOfficial) {
            val looksOfficial = track.uploaderVerified || "official" in text || "vevo" in text || "records" in text
            if (!looksOfficial) return false
        }
        return true
    }

    // ------------------------------------------------------------------------
    // Quick start: music first, refinement second
    // ------------------------------------------------------------------------

    private fun startQuick() {
        if (quickStartJob?.isActive == true) return
        val profile = snapshotQuickProfile()
        currentProfile = profile
        sessionGeneration++
        val mySession = sessionGeneration
        failedUrls.clear()
        usedUrls.clear()

        setQuickBusy(true, "STARTING…")
        quickStartJob = lifecycleScope.launch {
            // If music is already playing, preserve it and only prepare the other deck.
            val existing = activeDeck
            if (existing != null && slot(existing).state == DeckState.PLAYING) {
                autoEnabled = true
                renderAuto()
                closeQuickDrawer()
                setQuickBusy(false)
                ensureWaitingDeck()
                return@launch
            }

            // Clean V1 startup without calling the public STOP path (which would cancel this job).
            discoveryJob?.cancel()
            discoveryJob = null
            transitionJob?.cancel()
            transitionJob = null
            autoEnabled = false
            clearDeck(Deck.A)
            clearDeck(Deck.B)
            activeDeck = null
            autoEnabled = true
            renderAuto()

            val pool = searchCandidatePool(profile)
            if (pool.isEmpty()) {
                autoEnabled = false
                renderAuto()
                setQuickBusy(false)
                Toast.makeText(this@MixerActivity, "No songs found. Try another combination.", Toast.LENGTH_SHORT).show()
                return@launch
            }

            // Resolve A first. As soon as A is playable, music starts; B can take its time.
            var started = false
            for (candidate in pool) {
                if (!isActive || sessionGeneration != mySession) return@launch
                if (!candidateAllowed(candidate, profile, hard = false)) continue
                if (loadIntoDeck(Deck.A, candidate)) {
                    startDeck(Deck.A)
                    started = true
                    break
                }
            }

            if (!started) {
                autoEnabled = false
                renderAuto()
                setQuickBusy(false)
                Toast.makeText(this@MixerActivity, "Stream source unavailable. Try again.", Toast.LENGTH_SHORT).show()
                return@launch
            }

            closeQuickDrawer()
            setQuickBusy(false)

            // Strict filtering/refinement for NEXT now happens in the normal discovery loop while A plays.
            ensureWaitingDeck()
        }
    }

    private fun snapshotQuickProfile(): SessionProfile = SessionProfile(
        regions = quickRegions.toSet(),
        styles = quickStyles.toSet(),
        eras = quickEras.toSet(),
        tempo = quickTempo,
        allowLive = allowLive,
        allowCover = allowCover,
        onlyOfficial = onlyOfficial
    )

    // ------------------------------------------------------------------------
    // One transition loop
    // ------------------------------------------------------------------------

    private fun startTransition(immediate: Boolean, fadeMs: Long = crossfadeMs) {
        if (transitionJob?.isActive == true) return
        val from = activeDeck ?: return
        val to = from.other()
        if (slot(from).state != DeckState.PLAYING || slot(to).state != DeckState.READY) return

        transitionJob = lifecycleScope.launch {
            if (!immediate) {
                // Caller already decided timing; kept for a single transition API.
            }
            updateInstantNextVisibility(forceHide = true)
            slot(to).state = DeckState.PLAYING
            runCatching { player(to).play() }

            val startCross = cross
            val endCross = if (to == Deck.B) 1f else 0f
            val startedAt = SystemClock.elapsedRealtime()
            while (isActive) {
                val elapsed = SystemClock.elapsedRealtime() - startedAt
                val t = (elapsed.toFloat() / fadeMs.coerceAtLeast(1L)).coerceIn(0f, 1f)
                cross = startCross + (endCross - startCross) * t
                binding.crossfader.progress = (cross * 100).roundToInt()
                applyVolumes()
                if (t >= 1f) break
                delay(40)
            }

            // Ownership changes exactly once, here.
            val old = from
            activeDeck = to
            slot(to).state = DeckState.PLAYING
            clearDeck(old)
            cross = endCross
            binding.crossfader.progress = (cross * 100).roundToInt()
            applyVolumes()
            transitionJob = null
            renderAll()
            if (autoEnabled) ensureWaitingDeck()
        }
    }

    private fun monitorAutoTransition() {
        if (!autoEnabled || transitionJob?.isActive == true) return
        val owner = activeDeck ?: return
        val waiting = owner.other()
        if (slot(owner).state != DeckState.PLAYING || slot(waiting).state != DeckState.READY) return
        val p = player(owner)
        val duration = p.duration
        if (duration == C.TIME_UNSET || duration <= 0L) return
        val remaining = duration - p.currentPosition
        if (remaining in 1..autoMixAtMs) startTransition(immediate = false)
    }

    // ------------------------------------------------------------------------
    // User actions / UI
    // ------------------------------------------------------------------------

    private fun setupUi() {
        binding.loadA.setOnClickListener { if (!controlsLocked) openManualBrowser(Deck.A) }
        binding.loadB.setOnClickListener { if (!controlsLocked) openManualBrowser(Deck.B) }

        binding.playA.setOnClickListener { if (!controlsLocked) manualPlayPause(Deck.A) }
        binding.playB.setOnClickListener { if (!controlsLocked) manualPlayPause(Deck.B) }

        binding.instantNextFromA.setOnClickListener { startTransition(immediate = true) }
        binding.instantNextFromB.setOnClickListener { startTransition(immediate = true) }

        binding.autoMix.setOnClickListener {
            if (controlsLocked) return@setOnClickListener
            if (autoEnabled) {
                stopAutomationOnly(clearWaiting = false)
            } else {
                autoEnabled = true
                sessionGeneration++
                currentProfile = SessionProfile(
                    tempo = tempoBand,
                    allowLive = allowLive,
                    allowCover = allowCover,
                    onlyOfficial = onlyOfficial
                )
                renderAuto()
                when {
                    activeDeck != null -> ensureWaitingDeck()
                    slotA.state == DeckState.READY -> startDeck(Deck.A)
                    slotB.state == DeckState.READY -> startDeck(Deck.B)
                    else -> openQuickDrawer()
                }
            }
        }

        binding.endlessAction.setOnClickListener {
            if (controlsLocked) return@setOnClickListener
            if (autoEnabled) stopAutomationOnly(clearWaiting = true) else openQuickDrawer()
        }

        binding.quickEndlessButton.setOnClickListener {
            if (!controlsLocked) {
                if (quickOpen) closeQuickDrawer() else openQuickDrawer()
            }
        }

        binding.addToMix.setOnClickListener { if (!controlsLocked) openManualBrowser(activeDeck?.other() ?: Deck.A) }
        binding.lockedAddToMix.setOnClickListener { openManualBrowser(activeDeck?.other() ?: Deck.A) }

        binding.mixLock.setOnClickListener { setLocked(true) }
        binding.lockedUnlock.setOnClickListener { setLocked(false) }

        setupMasterControls()
        setupDeckVolumes()
        setupCrossfader()
        setupGlobalFilters()

        binding.waveA.onSeekRequested = { progress -> if (!controlsLocked) seekDeck(Deck.A, progress) }
        binding.waveB.onSeekRequested = { progress -> if (!controlsLocked) seekDeck(Deck.B, progress) }
    }

    private fun manualPlayPause(deck: Deck) {
        val s = slot(deck)
        val p = player(deck)
        when {
            activeDeck == deck && s.state == DeckState.PLAYING -> {
                if (p.isPlaying) p.pause() else p.play()
            }
            s.state == DeckState.READY -> {
                autoEnabled = false
                renderAuto()
                val old = activeDeck
                if (old != null && old != deck) {
                    player(old).pause()
                    slot(old).state = DeckState.READY
                }
                startDeck(deck)
            }
        }
        renderAll()
    }

    private fun openManualBrowser(deck: Deck) {
        if (activeDeck == deck && slot(deck).state == DeckState.PLAYING) {
            Toast.makeText(this, "Active deck is protected", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_TARGET_DECK, deck.name))
    }

    private fun restoreManualStoreTracks() {
        val a = MixerStore.deckA
        if (a != null && a.url != lastStoreAUrl && !(activeDeck == Deck.A && slotA.state == DeckState.PLAYING)) {
            lastStoreAUrl = a.url
            lifecycleScope.launch { loadIntoDeck(Deck.A, a) }
        }
        val b = MixerStore.deckB
        if (b != null && b.url != lastStoreBUrl && !(activeDeck == Deck.B && slotB.state == DeckState.PLAYING)) {
            lastStoreBUrl = b.url
            lifecycleScope.launch { loadIntoDeck(Deck.B, b) }
        }
    }

    private fun stopAutomationOnly(clearWaiting: Boolean) {
        autoEnabled = false
        sessionGeneration++
        discoveryJob?.cancel()
        discoveryJob = null
        quickStartJob?.cancel()
        quickStartJob = null
        transitionJob?.cancel()
        transitionJob = null
        if (clearWaiting) {
            val owner = activeDeck
            if (owner != null) clearDeck(owner.other())
        }
        renderAuto()
        updateInstantNextVisibility()
    }

    private fun seekDeck(deck: Deck, fraction: Float) {
        val p = player(deck)
        val duration = p.duration
        if (duration != C.TIME_UNSET && duration > 0) p.seekTo((duration * fraction.coerceIn(0f, 1f)).toLong())
    }

    // ------------------------------------------------------------------------
    // Filters / Quick controls
    // ------------------------------------------------------------------------

    private fun setupGlobalFilters() {
        fun toggleTempo(button: Button, value: String) {
            tempoBand = if (tempoBand == value) null else value
            renderTempoButtons()
        }
        binding.tempoSlow.setOnClickListener { if (!controlsLocked) toggleTempo(binding.tempoSlow, "slow") }
        binding.tempoMiddle.setOnClickListener { if (!controlsLocked) toggleTempo(binding.tempoMiddle, "mid tempo") }
        binding.tempoFast.setOnClickListener { if (!controlsLocked) toggleTempo(binding.tempoFast, "fast") }
        binding.tempoVeryFast.setOnClickListener { if (!controlsLocked) toggleTempo(binding.tempoVeryFast, "very fast") }

        binding.filterLive.setOnClickListener {
            if (!controlsLocked) { allowLive = !allowLive; renderGlobalFilters() }
        }
        binding.filterCover.setOnClickListener {
            if (!controlsLocked) { allowCover = !allowCover; renderGlobalFilters() }
        }
        binding.filterOfficial.setOnClickListener {
            if (!controlsLocked) { onlyOfficial = !onlyOfficial; renderGlobalFilters() }
        }
    }

    private fun setupQuickControls() {
        val regions = listOf(
            binding.quickRegionExYu to "EX-YU",
            binding.quickRegionItaly to "Italy",
            binding.quickRegionLatin to "Latin",
            binding.quickRegionAnglo to "Anglo",
            binding.quickRegionFrance to "France",
            binding.quickRegionDach to "DACH",
            binding.quickRegionTurkey to "Turkey",
            binding.quickRegionArabic to "Arabic",
            binding.quickRegionBrazil to "Brazil",
            binding.quickRegionJapan to "Japan",
            binding.quickRegionKorea to "Korea"
        )
        regions.forEach { (button, value) ->
            button.setOnClickListener {
                if (!controlsLocked) {
                    toggleSet(quickRegions, value)
                    if (value.isNotBlank()) quickCountry = null
                    renderQuickSelections()
                }
            }
        }

        val styles = listOf(
            binding.quickStylePop to "pop",
            binding.quickStylePopFolk to "pop folk",
            binding.quickStyleFolk to "folk",
            binding.quickStyleRock to "rock",
            binding.quickStyleHardRock to "hard rock",
            binding.quickStyleDance to "dance",
            binding.quickStyleHouse to "house",
            binding.quickStyleTechno to "techno",
            binding.quickStyleLounge to "lounge",
            binding.quickStyleJazz to "jazz",
            binding.quickStyleInstrumental to "instrumental",
            binding.quickStylePiano to "piano",
            binding.quickStyleClassic to "classical",
            binding.quickStyleCountry to "country",
            binding.quickStyleSoul to "soul",
            binding.quickStyleRap to "rap",
            binding.quickStyleHipHop to "hip hop"
        )
        styles.forEach { (button, value) ->
            button.setOnClickListener { if (!controlsLocked) { toggleSet(quickStyles, value); renderQuickSelections() } }
        }

        val eras = listOf(
            binding.quickEraEvergreen to "evergreen",
            binding.quickEra70 to "1970s",
            binding.quickEra80 to "1980s",
            binding.quickEra90 to "1990s",
            binding.quickEra2000 to "2000s",
            binding.quickEra2010 to "2010s",
            binding.quickEra2020 to "2020s"
        )
        eras.forEach { (button, value) ->
            button.setOnClickListener { if (!controlsLocked) { toggleSet(quickEras, value); renderQuickSelections() } }
        }

        val tempos = listOf(
            binding.quickTempoSlow to "slow",
            binding.quickTempoMiddle to "mid tempo",
            binding.quickTempoFast to "fast",
            binding.quickTempoVeryFast to "very fast"
        )
        tempos.forEach { (button, value) ->
            button.setOnClickListener {
                if (!controlsLocked) {
                    quickTempo = if (quickTempo == value) null else value
                    renderQuickSelections()
                }
            }
        }

        binding.quickCountryButton.setOnClickListener {
            if (!controlsLocked) showCountryPicker()
        }
        binding.quickDrawerEnter.setOnClickListener { if (!controlsLocked) startQuick() }
        binding.quickDrawerReset.setOnClickListener { if (!controlsLocked) resetQuickSelections() }
    }

    private fun <T> toggleSet(set: MutableSet<T>, value: T) {
        if (!set.add(value)) set.remove(value)
    }

    private fun showCountryPicker() {
        val countries = Locale.getISOCountries().mapNotNull { code ->
            runCatching { Locale("", code).displayCountry.takeIf { it.isNotBlank() } }.getOrNull()
        }.distinct().sorted()
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("COUNTRY")
            .setItems(countries.toTypedArray()) { dialog, which ->
                quickCountry = countries[which]
                quickRegions.clear()
                binding.quickCountryButton.text = quickCountry
                renderQuickSelections()
                dialog.dismiss()
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun resetQuickSelections() {
        quickRegions.clear()
        quickStyles.clear()
        quickEras.clear()
        quickCountry = null
        quickTempo = null
        binding.quickCountryButton.text = "COUNTRY ▾"
        renderQuickSelections()
    }

    private fun openQuickDrawer() {
        quickOpen = true
        binding.quickDrawer.visibility = View.VISIBLE
        binding.endlessSearchPanel.visibility = View.GONE
        binding.endlessLowerSpacer.visibility = View.GONE
        binding.endlessAction.visibility = View.GONE
        renderQuickSelections()
    }

    private fun closeQuickDrawer() {
        quickOpen = false
        binding.quickDrawer.visibility = View.GONE
        binding.endlessLowerSpacer.visibility = View.VISIBLE
        binding.endlessAction.visibility = if (autoEnabled) View.VISIBLE else View.GONE
    }

    private fun setQuickBusy(busy: Boolean, text: String = "") {
        binding.quickSearchingRow.visibility = if (busy) View.VISIBLE else View.GONE
        binding.quickSearchingText.text = text
        binding.quickDrawerEnter.isEnabled = !busy
    }

    // ------------------------------------------------------------------------
    // Optional text search panel (manual user fallback)
    // ------------------------------------------------------------------------

    private fun setupBrowserPanel() {
        val adapter = SearchAdapter(
            targetDeck = null,
            onImportA = {},
            onImportB = {},
            onSelect = { track ->
                val target = activeDeck?.other() ?: if (slotA.state == DeckState.EMPTY) Deck.A else Deck.B
                lifecycleScope.launch {
                    if (loadIntoDeck(target, track) && activeDeck == null) startDeck(target)
                }
                binding.endlessSearchPanel.visibility = View.GONE
            }
        )
        binding.endlessResults.layoutManager = LinearLayoutManager(this)
        binding.endlessResults.adapter = adapter
        binding.endlessSearchButton.setOnClickListener { runBrowserSearch() }
        binding.endlessVoiceButton.setOnClickListener { requestVoiceSearch() }
        binding.endlessSearchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { runBrowserSearch(); true } else false
        }
    }

    private fun runBrowserSearch() {
        val q = binding.endlessSearchInput.text.toString().trim()
        if (q.isBlank()) return
        binding.endlessStatus.text = "SEARCHING…"
        lifecycleScope.launch {
            val results = withContext(Dispatchers.IO) { runCatching { searchRepo.search(q) }.getOrElse { emptyList() } }
            (binding.endlessResults.adapter as? SearchAdapter)?.submit(results)
            binding.endlessStatus.text = if (results.isEmpty()) "NO RESULTS" else "${results.size} RESULTS"
        }
    }

    private fun requestVoiceSearch() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            launchSpeechRecognizer()
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun launchSpeechRecognizer() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Search music")
        }
        runCatching { speechLauncher.launch(intent) }
    }

    // ------------------------------------------------------------------------
    // Audio controls
    // ------------------------------------------------------------------------

    private fun setupAudioFocus() {
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
        ).setOnAudioFocusChangeListener { change ->
            if (change == AudioManager.AUDIOFOCUS_LOSS) {
                playerA.pause(); playerB.pause()
            }
        }.build()
        runCatching { audioManager.requestAudioFocus(audioFocusRequest) }
    }

    private fun setupMasterControls() {
        binding.masterVolume.progress = 100
        binding.masterVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                masterVolume = progress.coerceIn(0, 100) / 100f
                applyVolumes()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
        binding.masterMute.setOnClickListener {
            masterMuted = !masterMuted
            applyVolumes()
            binding.masterMute.alpha = if (masterMuted) 0.55f else 1f
        }
    }

    private fun setupDeckVolumes() {
        binding.volumeA.progress = 100
        binding.volumeB.progress = 100
        binding.volumeA.onProgressChanged = { userVolA = it / 100f; applyVolumes() }
        binding.volumeB.onProgressChanged = { userVolB = it / 100f; applyVolumes() }
    }

    private fun setupCrossfader() {
        binding.crossfader.progress = 0
        binding.crossfader.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser && transitionJob?.isActive != true && !controlsLocked) {
                    cross = progress.coerceIn(0, 100) / 100f
                    applyVolumes()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
    }

    private fun applyVolumes() {
        val master = if (masterMuted) 0f else masterVolume
        val aGain = (1f - cross).coerceIn(0f, 1f)
        val bGain = cross.coerceIn(0f, 1f)
        playerA.volume = userVolA * master * aGain
        playerB.volume = userVolB * master * bGain
    }

    // ------------------------------------------------------------------------
    // Lock
    // ------------------------------------------------------------------------

    private fun setLocked(locked: Boolean) {
        controlsLocked = locked
        binding.lockedControlsPanel.visibility = if (locked) View.VISIBLE else View.GONE
        binding.endlessLockActionRow.visibility = if (!locked && autoEnabled) View.VISIBLE else View.GONE
        binding.tempoFilterRow.visibility = if (!locked && autoEnabled) View.VISIBLE else View.GONE
        binding.endlessFilterRow.visibility = if (!locked && autoEnabled) View.VISIBLE else View.GONE
        binding.quickEndlessButton.visibility = if (locked) View.GONE else View.VISIBLE
        binding.loadA.isEnabled = !locked
        binding.loadB.isEnabled = !locked
        binding.playA.isEnabled = !locked
        binding.playB.isEnabled = !locked
        binding.crossfader.isEnabled = !locked
        binding.volumeA.isEnabled = !locked
        binding.volumeB.isEnabled = !locked
        binding.waveA.isEnabled = !locked
        binding.waveB.isEnabled = !locked
        updateInstantNextVisibility()
    }

    // ------------------------------------------------------------------------
    // Rendering
    // ------------------------------------------------------------------------

    private fun startUiLoop() {
        uiJob = lifecycleScope.launch {
            var phase = 0f
            while (isActive) {
                renderDeck(Deck.A)
                renderDeck(Deck.B)
                monitorAutoTransition()
                updateInstantNextVisibility()
                val aEnergy = if (playerA.isPlaying) 0.8f else 0.03f
                val bEnergy = if (playerB.isPlaying) 0.8f else 0.03f
                binding.crossSpectrum.setEnergy(aEnergy, bEnergy, phase)
                phase += 0.25f
                delay(250)
            }
        }
    }

    private fun renderAll() {
        renderDeck(Deck.A)
        renderDeck(Deck.B)
        renderAuto()
        renderTempoButtons()
        renderGlobalFilters()
        renderQuickSelections()
        updateInstantNextVisibility()
    }

    private fun renderDeck(deck: Deck) {
        val s = slot(deck)
        val p = player(deck)
        val title = s.track?.title?.takeIf { it.isNotBlank() } ?: "EMPTY"
        val stateText = when (s.state) {
            DeckState.EMPTY -> "PLAY"
            DeckState.LOADING -> "LOADING"
            DeckState.READY -> "PLAY"
            DeckState.PLAYING -> if (p.isPlaying) "PAUSE" else "PLAY"
        }
        val time = if (s.track != null && p.duration != C.TIME_UNSET && p.duration > 0) {
            formatRemaining((p.duration - p.currentPosition).coerceAtLeast(0L))
        } else ""
        val progress = if (p.duration != C.TIME_UNSET && p.duration > 0) {
            (p.currentPosition.toFloat() / p.duration).coerceIn(0f, 1f)
        } else 0f

        if (deck == Deck.A) {
            binding.titleA.text = title
            binding.timeA.text = time
            binding.playA.text = stateText
            if (s.track == null) binding.waveA.setEmpty() else binding.waveA.setTrackPresent(true)
            binding.waveA.setProgress(progress)
            binding.playA.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, if (s.state == DeckState.PLAYING && p.isPlaying) R.color.yellow_control else R.color.blue_control))
        } else {
            binding.titleB.text = title
            binding.timeB.text = time
            binding.playB.text = stateText
            if (s.track == null) binding.waveB.setEmpty() else binding.waveB.setTrackPresent(true)
            binding.waveB.setProgress(progress)
            binding.playB.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, if (s.state == DeckState.PLAYING && p.isPlaying) R.color.yellow_control else R.color.blue_control))
        }
    }

    private fun renderAuto() {
        binding.autoMix.text = if (autoEnabled) "AUTO IS ON" else "AUTO IS OFF"
        binding.autoMix.backgroundTintList = ColorStateList.valueOf(
            ContextCompat.getColor(this, if (autoEnabled) R.color.orange_control else R.color.white)
        )
        binding.endlessAction.text = if (autoEnabled) "STOP ENDLESS MIX" else "LOAD TWO SIMILAR SONGS\nAND MAKE ENDLESS MIX"
        binding.endlessAction.visibility = if (quickOpen) View.GONE else View.VISIBLE
        binding.endlessLockActionRow.visibility = if (autoEnabled && !controlsLocked) View.VISIBLE else View.GONE
        binding.tempoFilterRow.visibility = if (autoEnabled && !controlsLocked) View.VISIBLE else View.GONE
        binding.endlessFilterRow.visibility = if (autoEnabled && !controlsLocked) View.VISIBLE else View.GONE
    }

    private fun updateInstantNextVisibility(forceHide: Boolean = false) {
        if (forceHide) {
            binding.instantNextFromA.visibility = View.INVISIBLE
            binding.instantNextFromB.visibility = View.INVISIBLE
            return
        }
        val owner = activeDeck
        val showA = owner == Deck.A && slotA.state == DeckState.PLAYING && slotB.state == DeckState.READY && transitionJob?.isActive != true
        val showB = owner == Deck.B && slotB.state == DeckState.PLAYING && slotA.state == DeckState.READY && transitionJob?.isActive != true
        binding.instantNextFromA.visibility = if (showA) View.VISIBLE else View.INVISIBLE
        binding.instantNextFromB.visibility = if (showB) View.VISIBLE else View.INVISIBLE
        // Instant NEXT remains intentionally usable under LOCK.
        binding.instantNextFromA.isEnabled = showA
        binding.instantNextFromB.isEnabled = showB
    }

    private fun renderGlobalFilters() {
        binding.filterLive.text = "LIVE ${if (allowLive) "ON" else "OFF"}"
        binding.filterCover.text = "COVER ${if (allowCover) "ON" else "OFF"}"
        binding.filterOfficial.text = "ONLY OFFICIAL ${if (onlyOfficial) "ON" else "OFF"}"
        tintToggle(binding.filterLive, allowLive)
        tintToggle(binding.filterCover, allowCover)
        tintToggle(binding.filterOfficial, onlyOfficial)
    }

    private fun renderTempoButtons() {
        tintSelected(binding.tempoSlow, tempoBand == "slow")
        tintSelected(binding.tempoMiddle, tempoBand == "mid tempo")
        tintSelected(binding.tempoFast, tempoBand == "fast")
        tintSelected(binding.tempoVeryFast, tempoBand == "very fast")
    }

    private fun renderQuickSelections() {
        val regionMap = listOf(
            binding.quickRegionExYu to "EX-YU", binding.quickRegionItaly to "Italy", binding.quickRegionLatin to "Latin",
            binding.quickRegionAnglo to "Anglo", binding.quickRegionFrance to "France", binding.quickRegionDach to "DACH",
            binding.quickRegionTurkey to "Turkey", binding.quickRegionArabic to "Arabic", binding.quickRegionBrazil to "Brazil",
            binding.quickRegionJapan to "Japan", binding.quickRegionKorea to "Korea"
        )
        regionMap.forEach { (b, v) -> tintSelected(b, v in quickRegions) }

        val styleMap = listOf(
            binding.quickStylePop to "pop", binding.quickStylePopFolk to "pop folk", binding.quickStyleFolk to "folk",
            binding.quickStyleRock to "rock", binding.quickStyleHardRock to "hard rock", binding.quickStyleDance to "dance",
            binding.quickStyleHouse to "house", binding.quickStyleTechno to "techno", binding.quickStyleLounge to "lounge",
            binding.quickStyleJazz to "jazz", binding.quickStyleInstrumental to "instrumental", binding.quickStylePiano to "piano",
            binding.quickStyleClassic to "classical", binding.quickStyleCountry to "country", binding.quickStyleSoul to "soul",
            binding.quickStyleRap to "rap", binding.quickStyleHipHop to "hip hop"
        )
        styleMap.forEach { (b, v) -> tintSelected(b, v in quickStyles) }

        val eraMap = listOf(
            binding.quickEraEvergreen to "evergreen", binding.quickEra70 to "1970s", binding.quickEra80 to "1980s",
            binding.quickEra90 to "1990s", binding.quickEra2000 to "2000s", binding.quickEra2010 to "2010s",
            binding.quickEra2020 to "2020s"
        )
        eraMap.forEach { (b, v) -> tintSelected(b, v in quickEras) }

        tintSelected(binding.quickTempoSlow, quickTempo == "slow")
        tintSelected(binding.quickTempoMiddle, quickTempo == "mid tempo")
        tintSelected(binding.quickTempoFast, quickTempo == "fast")
        tintSelected(binding.quickTempoVeryFast, quickTempo == "very fast")
    }

    private fun tintSelected(button: Button, selected: Boolean) {
        button.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, if (selected) R.color.red_control else R.color.white))
    }

    private fun tintToggle(button: Button, selected: Boolean) {
        button.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, if (selected) R.color.green_control else R.color.white))
    }

    private fun formatRemaining(ms: Long): String {
        val total = ms / 1000L
        val min = total / 60L
        val sec = total % 60L
        return "-%d:%02d".format(min, sec)
    }
}
