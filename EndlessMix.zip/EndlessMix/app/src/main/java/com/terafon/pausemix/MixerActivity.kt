package com.terafon.pausemix

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.recyclerview.widget.LinearLayoutManager
import com.terafon.pausemix.databinding.ActivityMixerBinding
import com.terafon.pausemix.model.MixerStore
import com.terafon.pausemix.model.TrackRef
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.roundToInt

class MixerActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMixerBinding
    private lateinit var playerA: ExoPlayer
    private lateinit var playerB: ExoPlayer
    private lateinit var endlessAdapter: SearchAdapter

    private val searchRepo = SearchRepository()

    private var userVolA = 1f
    private var userVolB = 1f
    private var measuredRmsA: Float? = null
    private var measuredRmsB: Float? = null
    private val loudnessTargetRms = 0.18f
    private var cross = 0.5f

    private var lastTrackAUrl: String? = null
    private var lastTrackBUrl: String? = null
    private var analyzingA: String? = null
    private var analyzingB: String? = null
    private var resolvingA: String? = null
    private var resolvingB: String? = null
    private var autoEnabled = false
    private var autoFadeJob: Job? = null
    private val autoTriggerMs = 8_000L
    private val autoFadeMs = 3_000L

    private var controlsLocked = false
    private var masterDuck = 1f
    private var resumeAAfterFocus = false
    private var resumeBAfterFocus = false
    private lateinit var audioManager: AudioManager
    private lateinit var audioFocusRequest: AudioFocusRequest

    private var endlessSeedMode = false
    private var endlessActive = false
    private var pendingEndlessStart = false
    private val endlessSeeds = mutableListOf<TrackRef>()
    private val endlessUsedUrls = linkedSetOf<String>()
    private val endlessUsedTrackKeys = linkedSetOf<String>()
    private val endlessSeedArtistKeys = linkedSetOf<String>()
    private var endlessNonSeedSelections = 0
    private var endlessArtistOnlyMode = false
    private var endlessArtistOnlySeed: TrackRef? = null
    private val endlessArtistReplayQueue = ArrayDeque<TrackRef>()
    private val endlessRecent = mutableListOf<TrackRef>()
    private val endlessRecentArtists = mutableListOf<String>()
    private var endlessQueued: TrackRef? = null
    private var endlessWaitingFreeDeck: Boolean? = null
    private var endlessDiscoveryJob: Job? = null
    private var lastContinuityGuardAt = 0L

    private val speechLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != RESULT_OK || !::binding.isInitialized) return@registerForActivityResult
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
            ?.trim()
            .orEmpty()
        if (spoken.isNotBlank()) {
            binding.endlessSearchInput.setText(spoken)
            binding.endlessSearchInput.setSelection(spoken.length)
            runEndlessSearch()
        }
    }

    private val micPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchSpeechRecognizer()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMixerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val loadControlA = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 40_000, 2_500, 2_500)
            .setBackBuffer(20_000, true)
            .build()
        val loadControlB = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 40_000, 2_500, 2_500)
            .setBackBuffer(20_000, true)
            .build()
        playerA = ExoPlayer.Builder(this).setLoadControl(loadControlA).build()
        playerB = ExoPlayer.Builder(this).setLoadControl(loadControlB).build()
        playerA.setWakeMode(C.WAKE_MODE_NETWORK)
        playerB.setWakeMode(C.WAKE_MODE_NETWORK)
        setupAudioFocusProtection()
        addPlayerListener(playerA, true)
        addPlayerListener(playerB, false)

        endlessAdapter = SearchAdapter(
            targetDeck = null,
            onImportA = {},
            onImportB = {},
            onSelect = { selectEndlessSeed(it) }
        )
        binding.endlessResults.layoutManager = LinearLayoutManager(this)
        binding.endlessResults.adapter = endlessAdapter

        binding.loadA.setOnClickListener { openSearchFor("A") }
        binding.loadB.setOnClickListener { openSearchFor("B") }

        binding.playA.setOnClickListener {
            cancelAutoFadeForManualControl()
            MixerStore.deckA?.let { toggleDeck(true, it) }
                ?: Toast.makeText(this, "Press A to load a song", Toast.LENGTH_SHORT).show()
        }
        binding.playB.setOnClickListener {
            cancelAutoFadeForManualControl()
            MixerStore.deckB?.let { toggleDeck(false, it) }
                ?: Toast.makeText(this, "Press B to load a song", Toast.LENGTH_SHORT).show()
        }

        binding.autoMix.setOnClickListener {
            if (endlessActive) {
                Toast.makeText(this, "Endless Mix controls AUTO", Toast.LENGTH_SHORT).show()
            } else {
                autoEnabled = !autoEnabled
                updateAutoButton()
            }
        }

        binding.waveA.onSeekRequested = { fraction ->
            seekDeck(playerA, fraction)
        }
        binding.waveB.onSeekRequested = { fraction ->
            seekDeck(playerB, fraction)
        }

        binding.volumeA.progress = 100
        binding.volumeA.onProgressChanged = { p ->
            userVolA = p / 100f
            applyVolumes()
        }
        binding.volumeB.progress = 100
        binding.volumeB.onProgressChanged = { p ->
            userVolB = p / 100f
            applyVolumes()
        }

        binding.crossfader.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    cancelAutoFadeForManualControl()
                    cross = progress / 100f
                    applyVolumes()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                cancelAutoFadeForManualControl()
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        binding.endlessAction.setOnClickListener { onEndlessAction() }
        binding.endlessSearchButton.setOnClickListener { runEndlessSearch() }
        binding.endlessVoiceButton.setOnClickListener { requestEndlessVoiceSearch() }
        binding.mixLock.setOnClickListener { toggleControlLock() }
        binding.endlessSearchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                runEndlessSearch()
                true
            } else false
        }

        refreshDecks(force = true)
        syncSeedsFromCurrentDecks()
        updateOutputIndicator()
        updateAutoButton()
        updateEndlessAction()
        updateControlLockUi()
        applyVolumes()

        lifecycleScope.launch {
            while (isActive) {
                updateDeckUi(playerA, true)
                updateDeckUi(playerB, false)
                checkAutoMix()
                protectEndlessContinuity()
                delay(100)
            }
        }
    }

    private fun addPlayerListener(player: ExoPlayer, isA: Boolean) {
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                val button = if (isA) binding.playA else binding.playB
                when (playbackState) {
                    Player.STATE_BUFFERING -> {
                        button.text = "LOADING"
                        setPlayColor(button, false)
                    }
                    Player.STATE_READY -> {
                        updatePlayButton(isA)
                        if (endlessActive && pendingEndlessStart && isA) {
                            pendingEndlessStart = false
                            player.play()
                        }
                    }
                    Player.STATE_ENDED -> {
                        button.text = "PLAY"
                        setPlayColor(button, false)
                        updateLoadButtons()
                    }
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                updatePlayButton(isA)
                updateLoadButtons()
            }
        })
    }

    private fun openSearchFor(deck: String) {
        startActivity(Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_TARGET_DECK, deck))
    }

    private fun prepareDeck(isA: Boolean, track: TrackRef) {
        val player = if (isA) playerA else playerB
        val button = if (isA) binding.playA else binding.playB
        val direct = track.streamUrl ?: return

        button.text = "LOADING"
        button.isEnabled = false
        setPlayColor(button, false)
        player.setMediaItem(MediaItem.fromUri(direct))
        player.prepare()
    }

    private fun toggleDeck(isA: Boolean, track: TrackRef) {
        if (::audioFocusRequest.isInitialized) audioManager.requestAudioFocus(audioFocusRequest)
        val player = if (isA) playerA else playerB
        if (player.mediaItemCount == 0) {
            resolvePrepareAnalyze(isA, track)
            return
        }
        if (player.playbackState == Player.STATE_READY || player.playbackState == Player.STATE_BUFFERING) {
            if (player.isPlaying) player.pause() else player.play()
        }
    }

    private fun refreshDecks(force: Boolean = false) {
        val a = MixerStore.deckA
        val b = MixerStore.deckB

        if (force || a?.url != lastTrackAUrl) {
            playerA.stop(); playerA.clearMediaItems()
            lastTrackAUrl = a?.url
            measuredRmsA = null
            userVolA = 1f
            binding.volumeA.progress = 100
            binding.titleA.text = a?.title ?: "EMPTY"
            binding.playA.text = "PLAY"
            binding.playA.isEnabled = a != null
            setPlayColor(binding.playA, false)
            if (a == null) {
                binding.waveA.setEmpty()
                binding.timeA.text = ""
            } else {
                binding.waveA.setTrackPresent(true)
                val cached = MixerStore.waveA
                if (cached != null) binding.waveA.setWaveform(cached, 1f)
                resolvePrepareAnalyze(true, a)
            }
        }

        if (force || b?.url != lastTrackBUrl) {
            playerB.stop(); playerB.clearMediaItems()
            lastTrackBUrl = b?.url
            measuredRmsB = null
            userVolB = 1f
            binding.volumeB.progress = 100
            binding.titleB.text = b?.title ?: "EMPTY"
            binding.playB.text = "PLAY"
            binding.playB.isEnabled = b != null
            setPlayColor(binding.playB, false)
            if (b == null) {
                binding.waveB.setEmpty()
                binding.timeB.text = ""
            } else {
                binding.waveB.setTrackPresent(true)
                val cached = MixerStore.waveB
                if (cached != null) binding.waveB.setWaveform(cached, 1f)
                resolvePrepareAnalyze(false, b)
            }
        }
    }

    private fun resolvePrepareAnalyze(isA: Boolean, track: TrackRef) {
        val key = track.url
        val player = if (isA) playerA else playerB
        val button = if (isA) binding.playA else binding.playB

        if (player.mediaItemCount > 0) {
            if ((if (isA) MixerStore.waveA else MixerStore.waveB) == null) analyzeWaveform(isA, track)
            return
        }

        val existing = track.streamUrl
        if (existing != null) {
            prepareDeck(isA, track)
            if ((if (isA) MixerStore.waveA else MixerStore.waveB) == null) analyzeWaveform(isA, track)
            return
        }

        if ((if (isA) resolvingA else resolvingB) == key) return
        if (isA) resolvingA = key else resolvingB = key
        button.text = "LOADING"
        button.isEnabled = false
        setPlayColor(button, false)

        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) { AudioResolver.resolveBestAudioUrl(track.url) }
            }
            if (isA) resolvingA = null else resolvingB = null

            result.onSuccess { direct ->
                val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                if (!sameTrack) return@onSuccess
                val updated = track.copy(streamUrl = direct)
                if (isA) MixerStore.deckA = updated else MixerStore.deckB = updated
                prepareDeck(isA, updated)
                analyzeWaveform(isA, updated)
            }.onFailure {
                val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                if (sameTrack) {
                    button.isEnabled = true
                    button.text = "PLAY"
                    setPlayColor(button, false)
                    Toast.makeText(this@MixerActivity, "Stream error: ${it.message ?: "unknown"}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun analyzeWaveform(isA: Boolean, track: TrackRef) {
        val direct = track.streamUrl ?: return
        val key = track.url
        if (isA) {
            if (MixerStore.waveA != null || analyzingA == key) return
            analyzingA = key
        } else {
            if (MixerStore.waveB != null || analyzingB == key) return
            analyzingB = key
        }

        lifecycleScope.launch {
            val analysis = runCatching {
                withContext(Dispatchers.IO) {
                    WaveformAnalyzer.analyze(direct) { partial, fraction ->
                        runOnUiThread {
                            val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                            if (sameTrack) {
                                if (isA) binding.waveA.setWaveform(partial, fraction)
                                else binding.waveB.setWaveform(partial, fraction)
                            }
                        }
                    }
                }
            }.getOrNull()

            if (isA) {
                analyzingA = null
                if (MixerStore.deckA?.url == key && analysis != null) {
                    MixerStore.waveA = analysis.waveform
                    measuredRmsA = analysis.rms
                    binding.waveA.setWaveform(analysis.waveform, 1f)
                    applyAutoLoudness(true, analysis.rms)
                }
            } else {
                analyzingB = null
                if (MixerStore.deckB?.url == key && analysis != null) {
                    MixerStore.waveB = analysis.waveform
                    measuredRmsB = analysis.rms
                    binding.waveB.setWaveform(analysis.waveform, 1f)
                    applyAutoLoudness(false, analysis.rms)
                }
            }
        }
    }

    private fun updateDeckUi(player: ExoPlayer, isA: Boolean) {
        val duration = player.duration
        val position = player.currentPosition.coerceAtLeast(0L)
        val p = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f
        val remaining = if (duration > 0) (duration - position).coerceAtLeast(0L) else -1L

        if (isA) {
            binding.waveA.setProgress(p)
            binding.timeA.text = if (remaining >= 0) "-${formatTime(remaining)}" else ""
        } else {
            binding.waveB.setProgress(p)
            binding.timeB.text = if (remaining >= 0) "-${formatTime(remaining)}" else ""
        }
    }

    private fun seekDeck(player: ExoPlayer, fraction: Float) {
        if (player.mediaItemCount == 0) return
        val duration = player.duration
        if (duration > 0) player.seekTo((duration * fraction.coerceIn(0f, 1f)).toLong())
    }

    private fun checkAutoMix() {
        if (!autoEnabled || autoFadeJob?.isActive == true) return
        val aRemaining = remainingMs(playerA)
        val bRemaining = remainingMs(playerB)

        if (playerA.isPlaying && aRemaining in 1..autoTriggerMs && deckReadyForAuto(playerB)) {
            startAutoFade(fromA = true)
        } else if (playerB.isPlaying && bRemaining in 1..autoTriggerMs && deckReadyForAuto(playerA)) {
            startAutoFade(fromA = false)
        }
    }

    private fun protectEndlessContinuity() {
        if (!endlessActive) return
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastContinuityGuardAt < 8_000L) return

        fun guard(source: ExoPlayer, target: ExoPlayer) {
            val remaining = remainingMs(source)
            if (!source.isPlaying || remaining > 1_500L || deckReadyForAuto(target)) return
            val duration = source.duration
            if (duration > 15_000L) {
                // Emergency fallback: replay the last 12 s from the retained back-buffer
                // instead of letting the mix fall silent while discovery/stream resolving retries.
                source.seekTo((duration - 12_000L).coerceAtLeast(0L))
                source.play()
                lastContinuityGuardAt = now
                endlessQueued = null
                discoverQueuedCandidate()
            }
        }

        guard(playerA, playerB)
        guard(playerB, playerA)
    }

    private fun deckReadyForAuto(player: ExoPlayer): Boolean {
        if (player.mediaItemCount == 0 || player.playbackState != Player.STATE_READY) return false
        val d = player.duration
        return d <= 0 || player.currentPosition < d - 1_000L
    }

    private fun remainingMs(player: ExoPlayer): Long {
        val d = player.duration
        return if (d > 0) (d - player.currentPosition).coerceAtLeast(0L) else Long.MAX_VALUE
    }

    private fun startAutoFade(fromA: Boolean) {
        val source = if (fromA) playerA else playerB
        val target = if (fromA) playerB else playerA
        if (!deckReadyForAuto(target)) return

        target.play()
        val startCross = cross
        val endCross = if (fromA) 1f else 0f

        autoFadeJob = lifecycleScope.launch {
            val steps = 50
            for (i in 0..steps) {
                if (!isActive) return@launch
                val t = i / steps.toFloat()
                cross = startCross + (endCross - startCross) * t
                binding.crossfader.progress = (cross * 100f).roundToInt().coerceIn(0, 100)
                applyVolumes()
                delay(autoFadeMs / steps)
            }
            source.pause()
            cross = endCross
            binding.crossfader.progress = (cross * 100f).roundToInt()
            applyVolumes()
            autoFadeJob = null
            if (endlessActive) onEndlessTransitionComplete(freedIsA = fromA)
        }
    }

    private fun cancelAutoFadeForManualControl() {
        if (endlessActive) stopEndlessForManualControl()
        if (autoFadeJob?.isActive == true) {
            autoFadeJob?.cancel()
            autoFadeJob = null
            autoEnabled = false
            updateAutoButton()
        }
    }

    private fun applyAutoLoudness(isA: Boolean, rms: Float) {
        if (rms <= 0.001f) return
        // Never boost above the clean 100% deck level; only tame louder tracks.
        val normalized = (loudnessTargetRms / rms).coerceIn(0.55f, 1f)
        val progress = (normalized * 100f).roundToInt().coerceIn(55, 100)
        if (isA) {
            userVolA = progress / 100f
            binding.volumeA.progress = progress
        } else {
            userVolB = progress / 100f
            binding.volumeB.progress = progress
        }
        applyVolumes()
    }

    private fun applyVolumes() {
        val headroom = 0.82f
        val aGain = (1f - cross) * headroom
        val bGain = cross * headroom
        playerA.volume = (userVolA * aGain * masterDuck).coerceIn(0f, 1f)
        playerB.volume = (userVolB * bGain * masterDuck).coerceIn(0f, 1f)
    }

    private fun updatePlayButton(isA: Boolean) {
        val player = if (isA) playerA else playerB
        val button = if (isA) binding.playA else binding.playB
        button.isEnabled = !controlsLocked && player.mediaItemCount > 0 && player.playbackState != Player.STATE_IDLE
        if (player.isPlaying) {
            button.text = "PAUSE"
            setPlayColor(button, true)
        } else if (player.playbackState == Player.STATE_BUFFERING) {
            button.text = "LOADING"
            setPlayColor(button, false)
        } else {
            button.text = "PLAY"
            setPlayColor(button, false)
        }
    }

    private fun updateLoadButtons() {
        val aLocked = playerA.isPlaying
        val bLocked = playerB.isPlaying

        binding.loadA.isEnabled = !controlsLocked && !aLocked
        binding.loadA.alpha = if (controlsLocked || aLocked) 0.35f else 1f
        binding.loadB.isEnabled = !controlsLocked && !bLocked
        binding.loadB.alpha = if (controlsLocked || bLocked) 0.35f else 1f
    }

    private fun setPlayColor(button: Button, pausedState: Boolean) {
        val color = if (pausedState) R.color.yellow_control else R.color.blue_control
        button.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, color))
        button.setTextColor(ContextCompat.getColor(this, if (pausedState) R.color.black else R.color.white))
    }

    private fun updateAutoButton() {
        val color = if (autoEnabled) R.color.orange_control else R.color.white
        binding.autoMix.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, color))
        binding.autoMix.setTextColor(ContextCompat.getColor(this, R.color.black))
        binding.autoMix.text = if (autoEnabled) "AUTO IS ON" else "AUTO IS OFF"
        binding.autoMix.isEnabled = !controlsLocked
    }

    // ---------------- ENDLESS MIX ----------------

    private fun onEndlessAction() {
        if (endlessActive) {
            stopEndlessMix()
            return
        }

        syncSeedsFromCurrentDecks()
        if (endlessSeeds.size >= 2) {
            startEndlessMix()
        } else {
            endlessSeedMode = true
            showEndlessSearch(true)
            binding.endlessStatus.text = if (endlessSeeds.size == 1) {
                "1/2 loaded — choose a similar second song"
            } else {
                "Choose the first seed song"
            }
            updateEndlessAction()
        }
    }

    private fun syncSeedsFromCurrentDecks() {
        if (endlessActive) return
        endlessSeeds.clear()
        MixerStore.deckA?.let { endlessSeeds.add(it) }
        MixerStore.deckB?.let { b -> if (endlessSeeds.none { it.url == b.url }) endlessSeeds.add(b) }
        updateEndlessAction()
    }

    private fun updateEndlessAction() {
        binding.endlessAction.text = when {
            endlessActive -> "STOP ENDLESS MIX"
            endlessSeeds.size >= 2 -> "PLAY ENDLESS MIX"
            else -> "LOAD TWO SIMILAR SONGS\nAND MAKE ENDLESS MIX"
        }
    }

    private fun showEndlessSearch(show: Boolean) {
        binding.endlessSearchPanel.visibility = if (show) View.VISIBLE else View.GONE
        // During seed loading the search gets the lower workspace without leaving the mixer window.
        binding.autoMix.visibility = if (show) View.GONE else View.VISIBLE
        binding.crossLabels.visibility = if (show) View.GONE else View.VISIBLE
        binding.crossfader.visibility = if (show) View.GONE else View.VISIBLE
        if (!show) endlessAdapter.submit(emptyList())
    }

    private fun runEndlessSearch() {
        val q = binding.endlessSearchInput.text.toString().trim()
        if (q.isBlank()) return
        binding.endlessStatus.text = "Searching…"
        lifecycleScope.launch {
            runCatching {
                withContext(Dispatchers.IO) { searchRepo.search(q) }
            }.onSuccess { results ->
                endlessAdapter.submit(results)
                binding.endlessStatus.text = when (endlessSeeds.size) {
                    0 -> "Choose the first song — ${results.size} results"
                    else -> "Choose a similar second song — ${results.size} results"
                }
            }.onFailure {
                binding.endlessStatus.text = "Search error: ${it.message ?: "unknown"}"
            }
        }
    }

    private fun selectEndlessSeed(track: TrackRef) {
        if (endlessSeeds.any { it.url == track.url }) {
            Toast.makeText(this, "Choose a different second song", Toast.LENGTH_SHORT).show()
            return
        }

        when {
            MixerStore.deckA == null -> MixerStore.setA(track)
            MixerStore.deckB == null -> MixerStore.setB(track)
            endlessSeeds.isEmpty() -> MixerStore.setA(track)
            endlessSeeds.size == 1 -> {
                val first = endlessSeeds.first()
                if (MixerStore.deckA?.url == first.url) MixerStore.setB(track) else MixerStore.setA(track)
            }
            else -> return
        }

        refreshDecks()
        syncSeedsFromCurrentDecks()
        if (endlessSeeds.size >= 2) {
            endlessSeedMode = false
            showEndlessSearch(false)
            binding.endlessSearchInput.setText("")
            updateEndlessAction()
        } else {
            binding.endlessStatus.text = "1/2 loaded — choose a similar second song"
        }
    }

    private fun startEndlessMix() {
        syncSeedsFromCurrentDecks()
        if (endlessSeeds.size < 2) {
            showEndlessSearch(true)
            return
        }

        if (::audioFocusRequest.isInitialized) audioManager.requestAudioFocus(audioFocusRequest)
        endlessActive = true
        endlessSeedMode = false
        autoEnabled = true
        controlsLocked = false
        endlessUsedUrls.clear()
        endlessUsedTrackKeys.clear()
        endlessSeedArtistKeys.clear()
        endlessNonSeedSelections = 0
        endlessArtistReplayQueue.clear()
        endlessArtistOnlyMode = isSameArtistFamily(endlessSeeds[0], endlessSeeds[1])
        endlessArtistOnlySeed = if (endlessArtistOnlyMode) endlessSeeds[0] else null
        endlessRecent.clear()
        endlessRecentArtists.clear()
        endlessSeeds.take(2).forEach {
            endlessUsedUrls.add(it.url)
            endlessUsedTrackKeys.add(endlessTrackKey(it))
            endlessSeedArtistKeys.add(endlessArtistKey(it))
            endlessRecent.add(it)
            rememberEndlessArtist(it)
        }
        endlessQueued = null
        endlessWaitingFreeDeck = null
        showEndlessSearch(false)
        updateAutoButton()
        updateEndlessAction()
        updateControlLockUi()

        // Endless Mix always starts from deck A; B is already prepared as the next song.
        cross = 0f
        binding.crossfader.progress = 0
        applyVolumes()
        if (playerA.mediaItemCount > 0) {
            playerA.play()
        } else {
            pendingEndlessStart = true
            MixerStore.deckA?.let { resolvePrepareAnalyze(true, it) }
        }
        discoverQueuedCandidate()
    }

    private fun stopEndlessMix() {
        endlessActive = false
        endlessSeedMode = false
        autoEnabled = false
        controlsLocked = false
        pendingEndlessStart = false
        endlessDiscoveryJob?.cancel()
        endlessDiscoveryJob = null
        endlessQueued = null
        endlessWaitingFreeDeck = null
        endlessSeeds.clear()
        endlessUsedUrls.clear()
        endlessUsedTrackKeys.clear()
        endlessSeedArtistKeys.clear()
        endlessNonSeedSelections = 0
        endlessArtistOnlyMode = false
        endlessArtistOnlySeed = null
        endlessArtistReplayQueue.clear()
        endlessRecent.clear()
        endlessRecentArtists.clear()
        showEndlessSearch(false)
        updateAutoButton()
        updateEndlessAction()
        updateControlLockUi()
        // Do not stop the song that is already playing.
    }

    private fun stopEndlessForManualControl() {
        endlessActive = false
        endlessSeedMode = false
        autoEnabled = false
        controlsLocked = false
        pendingEndlessStart = false
        endlessDiscoveryJob?.cancel()
        endlessDiscoveryJob = null
        endlessQueued = null
        endlessWaitingFreeDeck = null
        endlessSeeds.clear()
        endlessUsedUrls.clear()
        endlessUsedTrackKeys.clear()
        endlessSeedArtistKeys.clear()
        endlessNonSeedSelections = 0
        endlessArtistOnlyMode = false
        endlessArtistOnlySeed = null
        endlessArtistReplayQueue.clear()
        endlessRecent.clear()
        endlessRecentArtists.clear()
        showEndlessSearch(false)
        updateAutoButton()
        updateEndlessAction()
        updateControlLockUi()
    }

    private fun onEndlessTransitionComplete(freedIsA: Boolean) {
        if (!endlessActive) return
        val queued = endlessQueued
        if (queued != null) {
            endlessQueued = null
            loadEndlessTrackIntoDeck(freedIsA, queued)
            discoverQueuedCandidate()
        } else {
            endlessWaitingFreeDeck = freedIsA
            discoverQueuedCandidate()
        }
    }

    private fun loadEndlessTrackIntoDeck(isA: Boolean, track: TrackRef) {
        if (!endlessActive) return
        lifecycleScope.launch {
            val resolved = withContext(Dispatchers.IO) {
                runCatching {
                    if (track.streamUrl != null) track
                    else track.copy(streamUrl = AudioResolver.resolveBestAudioUrl(track.url))
                }.getOrNull()
            }
            if (!endlessActive) return@launch
            if (resolved == null) {
                // Keep the old/free deck intact and immediately search another candidate.
                endlessWaitingFreeDeck = isA
                endlessQueued = null
                delay(1_000)
                discoverQueuedCandidate()
                return@launch
            }

            if (isA) MixerStore.setA(resolved) else MixerStore.setB(resolved)
            endlessRecent.add(resolved)
            while (endlessRecent.size > 8) endlessRecent.removeAt(0)
            rememberEndlessArtist(resolved)
            endlessUsedTrackKeys.add(endlessTrackKey(resolved))
            if (endlessArtistKey(resolved) !in endlessSeedArtistKeys) endlessNonSeedSelections++
            refreshDecks()
        }
    }

    private fun discoverQueuedCandidate() {
        if (!endlessActive || endlessQueued != null || endlessDiscoveryJob?.isActive == true) return

        // Artist-only mode: after the catalogue is exhausted, replay the two original
        // seeds in order, then begin a fresh pass through that artist's catalogue.
        if (endlessArtistOnlyMode && endlessArtistReplayQueue.isNotEmpty()) {
            val replay = endlessArtistReplayQueue.removeFirst()
            endlessUsedUrls.add(replay.url)
            endlessUsedTrackKeys.add(endlessTrackKey(replay))
            val waiting = endlessWaitingFreeDeck
            if (waiting != null) {
                endlessWaitingFreeDeck = null
                loadEndlessTrackIntoDeck(waiting, replay)
                discoverQueuedCandidate()
            } else {
                endlessQueued = replay
            }
            return
        }

        val queries = buildEndlessQueries()
        endlessDiscoveryJob = lifecycleScope.launch {
            val candidate = withContext(Dispatchers.IO) {
                var found: TrackRef? = null
                for (query in queries) {
                    val results = runCatching { searchRepo.search(query) }.getOrElse { emptyList() }
                    found = chooseEndlessCandidate(results)
                    if (found != null) break
                }
                found
            }
            endlessDiscoveryJob = null
            if (!endlessActive) return@launch

            if (candidate == null) {
                if (endlessArtistOnlyMode && endlessSeeds.size >= 2) {
                    // Fresh artist-only cycle. The first two songs must be the user's seeds.
                    endlessUsedUrls.clear()
                    endlessUsedTrackKeys.clear()
                    endlessRecentArtists.clear()
                    endlessArtistReplayQueue.clear()
                    endlessArtistReplayQueue.addLast(endlessSeeds[0])
                    endlessArtistReplayQueue.addLast(endlessSeeds[1])
                    discoverQueuedCandidate()
                } else {
                    delay(1_500)
                    discoverQueuedCandidate()
                }
                return@launch
            }

            endlessUsedUrls.add(candidate.url)
            endlessUsedTrackKeys.add(endlessTrackKey(candidate))
            val waiting = endlessWaitingFreeDeck
            if (waiting != null) {
                endlessWaitingFreeDeck = null
                loadEndlessTrackIntoDeck(waiting, candidate)
                discoverQueuedCandidate()
            } else {
                endlessQueued = candidate
            }
        }
    }

    private fun buildEndlessQueries(): List<String> {
        val a = endlessSeeds.getOrNull(0) ?: return emptyList()
        val b = endlessSeeds.getOrNull(1) ?: return emptyList()
        val artistA = endlessArtistKey(a)
        val artistB = endlessArtistKey(b)

        if (endlessArtistOnlyMode) {
            val artist = endlessArtistKey(endlessArtistOnlySeed ?: a).ifBlank { artistA }
            return listOf(
                "$artist songs",
                "$artist official audio",
                "$artist music"
            ).map { it.trim() }.filter { it.isNotBlank() }.distinct()
        }

        val recent = endlessRecent.takeLast(3)
        val recentArtists = recent.map { endlessArtistKey(it) }.filter { it.isNotBlank() }.distinct()
        val recentTitles = recent.map { it.title }.filter { it.isNotBlank() }

        val queries = mutableListOf<String>()
        if (recentArtists.size >= 2) queries += "${recentArtists.joinToString(" ")} similar songs"
        if (recentTitles.size >= 2) queries += "${recentTitles.takeLast(2).joinToString(" ")} similar songs"
        if (recentArtists.isNotEmpty()) queries += "${recentArtists.last()} related artists songs"
        queries += "$artistA $artistB related artists"
        queries += "music like $artistA $artistB"
        queries += "$artistA $artistB similar songs"
        return queries.map { it.trim() }.filter { it.isNotBlank() }.distinct()
    }

    private fun chooseEndlessCandidate(items: List<TrackRef>): TrackRef? {
        val blockedWords = listOf("karaoke", "reaction", "tutorial", "full album", "playlist")
        val artistOnlySeed = endlessArtistOnlySeed
        return items.firstOrNull { track ->
            val title = track.title.lowercase(Locale.getDefault())
            val artist = endlessArtistKey(track)
            val trackKey = endlessTrackKey(track)
            val correctArtistForArtistOnly = !endlessArtistOnlyMode ||
                (artistOnlySeed != null && isSameArtistFamily(artistOnlySeed, track))
            val seedArtistBlocked = !endlessArtistOnlyMode &&
                endlessNonSeedSelections < 5 &&
                endlessSeeds.take(2).any { seed -> isSameArtistFamily(seed, track) }
            val recentArtistBlocked = !endlessArtistOnlyMode && endlessRecentArtists.any { recent ->
                recent.isNotBlank() && artist.isNotBlank() &&
                    (artist == recent || artist.contains(recent) || recent.contains(artist))
            }
            track.url !in endlessUsedUrls &&
                trackKey !in endlessUsedTrackKeys &&
                correctArtistForArtistOnly &&
                !recentArtistBlocked &&
                !seedArtistBlocked &&
                (track.durationSeconds <= 0 || track.durationSeconds in 75..480) &&
                blockedWords.none { it in title }
        }
    }

    private fun isSameArtistFamily(seed: TrackRef, candidate: TrackRef): Boolean {
        val stop = setOf(
            "official", "music", "video", "audio", "lyrics", "lyric", "records", "recordings",
            "topic", "channel", "band", "grupa", "the", "and", "feat", "ft"
        )
        fun words(text: String): Set<String> = text
            .lowercase(Locale.getDefault())
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .split(' ')
            .map { it.trim() }
            .filter { it.length >= 4 && it !in stop }
            .toSet()

        val seedArtistWords = words(endlessArtistKey(seed))
        if (seedArtistWords.isEmpty()) return false
        val candidateWords = words(endlessArtistKey(candidate)) + words(candidate.uploader) + words(candidate.title)
        return seedArtistWords.any { it in candidateWords }
    }

    private fun rememberEndlessArtist(track: TrackRef) {
        val key = endlessArtistKey(track)
        if (key.isBlank()) return
        endlessRecentArtists.remove(key)
        endlessRecentArtists.add(key)
        while (endlessRecentArtists.size > 5) endlessRecentArtists.removeAt(0)
    }

    private fun endlessArtistKey(track: TrackRef): String {
        // Prefer the artist prefix from common "Artist - Song" titles. This avoids
        // treating a label uploader as if it were the performer.
        val separators = listOf(" - ", " – ", " — ", " | ")
        val titleArtist = separators
            .mapNotNull { sep ->
                val index = track.title.indexOf(sep)
                if (index > 0) track.title.substring(0, index) else null
            }
            .minByOrNull { it.length }
            .orEmpty()
            .lowercase(Locale.getDefault())
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .trim()
        if (titleArtist.length >= 2) return titleArtist

        return track.uploader
            .lowercase(Locale.getDefault())
            .replace(Regex("\\b(official|music|vevo|records|recordings|topic|channel)\\b"), " ")
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .trim()
    }

    private fun endlessTrackKey(track: TrackRef): String {
        val separators = listOf(" - ", " – ", " — ", " | ")
        var songPart = track.title
        for (sep in separators) {
            val i = songPart.indexOf(sep)
            if (i > 0 && i + sep.length < songPart.length) {
                songPart = songPart.substring(i + sep.length)
                break
            }
        }
        return songPart
            .lowercase(Locale.getDefault())
            .replace(Regex("\\([^)]*\\)|\\[[^]]*]"), " ")
            .replace(Regex("\\b(official|video|audio|lyrics|lyric|hd|hq|remastered|remaster|live|version)\\b"), " ")
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .trim()
    }

    private fun requestEndlessVoiceSearch() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            launchSpeechRecognizer()
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun setupAudioFocusProtection() {
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setWillPauseWhenDucked(false)
            .setOnAudioFocusChangeListener { change ->
                when (change) {
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                        masterDuck = 0.35f
                        applyVolumes()
                    }
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                        resumeAAfterFocus = playerA.isPlaying
                        resumeBAfterFocus = playerB.isPlaying
                        masterDuck = 0.12f
                        applyVolumes()
                    }
                    AudioManager.AUDIOFOCUS_GAIN -> {
                        masterDuck = 1f
                        applyVolumes()
                        if (resumeAAfterFocus && !playerA.isPlaying && playerA.playbackState == Player.STATE_READY) playerA.play()
                        if (resumeBAfterFocus && !playerB.isPlaying && playerB.playbackState == Player.STATE_READY) playerB.play()
                        resumeAAfterFocus = false
                        resumeBAfterFocus = false
                    }
                    AudioManager.AUDIOFOCUS_LOSS -> {
                        resumeAAfterFocus = playerA.isPlaying
                        resumeBAfterFocus = playerB.isPlaying
                        masterDuck = 0.12f
                        applyVolumes()
                    }
                }
            }
            .build()
        audioManager.requestAudioFocus(audioFocusRequest)
    }

    private fun toggleControlLock() {
        if (!controlsLocked) {
            controlsLocked = true
            updateControlLockUi()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("ARE YOU SURE?")
            .setMessage("Unlock mixer controls?")
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("UNLOCK") { _, _ ->
                controlsLocked = false
                updateControlLockUi()
            }
            .show()
    }

    private fun updateControlLockUi() {
        binding.mixLock.visibility = if (endlessActive) View.VISIBLE else View.GONE
        binding.lockText.text = if (controlsLocked) "UNLOCK" else "LOCK"
        binding.lockText.setTextColor(ContextCompat.getColor(this, if (controlsLocked) R.color.white else R.color.black))
        binding.lockIcon.setImageResource(if (controlsLocked) R.drawable.ic_lock_closed else R.drawable.ic_lock_open)
        binding.mixLock.setBackgroundColor(ContextCompat.getColor(this, if (controlsLocked) R.color.red_control else R.color.green_control))

        binding.playA.isEnabled = !controlsLocked && playerA.mediaItemCount > 0
        binding.playB.isEnabled = !controlsLocked && playerB.mediaItemCount > 0
        binding.autoMix.isEnabled = !controlsLocked
        binding.crossfader.isEnabled = !controlsLocked
        binding.volumeA.isEnabled = !controlsLocked
        binding.volumeB.isEnabled = !controlsLocked
        binding.waveA.isEnabled = !controlsLocked
        binding.waveB.isEnabled = !controlsLocked
        binding.endlessAction.isEnabled = !controlsLocked
        binding.endlessSearchInput.isEnabled = !controlsLocked
        binding.endlessSearchButton.isEnabled = !controlsLocked
        binding.endlessVoiceButton.isEnabled = !controlsLocked
        updateLoadButtons()
    }

    private fun launchSpeechRecognizer() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Search music")
        }
        runCatching { speechLauncher.launch(intent) }
            .onFailure { binding.endlessStatus.text = "Voice search unavailable" }
    }

    private fun formatTime(ms: Long): String {
        val total = (ms / 1000L).coerceAtLeast(0L)
        val m = total / 60
        val s = total % 60
        return "%d:%02d".format(m, s)
    }

    private fun updateOutputIndicator() {
        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        val outputs = audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val bt = outputs.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                it.type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
                it.type == AudioDeviceInfo.TYPE_BLE_SPEAKER
        }
        binding.outputIndicator.text = if (bt != null) "BT" else "DEVICE"
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized) {
            refreshDecks()
            if (!endlessActive && !endlessSeedMode) syncSeedsFromCurrentDecks()
            updateOutputIndicator()
        }
    }

    override fun onDestroy() {
        autoFadeJob?.cancel()
        endlessDiscoveryJob?.cancel()
        if (::audioFocusRequest.isInitialized) audioManager.abandonAudioFocusRequest(audioFocusRequest)
        playerA.release()
        playerB.release()
        super.onDestroy()
    }
}
