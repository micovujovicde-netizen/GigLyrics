package com.terafon.pausemix

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.media.AudioManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.recyclerview.widget.LinearLayoutManager
import com.terafon.pausemix.databinding.ActivityMixerBinding
import com.terafon.pausemix.model.MixerStore
import com.terafon.pausemix.model.TrackRef
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.text.Normalizer
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.random.Random

class MixerActivity : AppCompatActivity() {
    private enum class EndlessGenreProfile { POP, POP_FOLK, FOLK }
    private enum class EndlessDeckState { FREE, LOADING_NEXT, READY_NEXT, PLAYING }
    private enum class EndlessSceneProfile {
        GLOBAL, EX_YU, ANGLO, FRANCOPHONE, HISPANIC, LUSOPHONE, DACH, ITALIAN,
        GREEK, TURKISH, ARABIC, SOUTH_ASIAN, EAST_SLAVIC, KOREAN, JAPANESE
    }

    private lateinit var binding: ActivityMixerBinding
    private lateinit var playerA: ExoPlayer
    private lateinit var playerB: ExoPlayer
    private lateinit var endlessAdapter: SearchAdapter

    private val searchRepo = SearchRepository()

    private var userVolA = 1f
    private var userVolB = 1f
    private var measuredRmsA: Float? = null
    private var measuredRmsB: Float? = null
    private val loudnessTargetRms = 0.18f
    private val minimumEndlessRms = 0.15f
    private var allowLive = false
    private var allowCover = false
    private var onlyOfficial = false
    private var cross = 0f

    private var lastTrackAUrl: String? = null
    private var lastTrackBUrl: String? = null
    private var analyzingA: String? = null
    private var analyzingB: String? = null
    private var resolvingA: String? = null
    private var resolvingB: String? = null
    private var autoEnabled = false
    private var autoFadeJob: Job? = null
    private val autoTriggerMs = 12_000L
    private val autoFadeMs = 3_000L

    private var controlsLocked = false
    private var masterDuck = 1f
    private var masterVolume = 1f
    private var masterMuted = false
    private var resumeAAfterFocus = false
    private var resumeBAfterFocus = false
    private lateinit var audioManager: AudioManager
    private lateinit var audioFocusRequest: AudioFocusRequest

    private var endlessSeedMode = false
    private var endlessActive = false
    private var pendingEndlessStart = false
    private var pendingEndlessStartIsA: Boolean? = null
    private val endlessSeeds = mutableListOf<TrackRef>()
    private val endlessUsedUrls = linkedSetOf<String>()
    private val endlessUsedTrackKeys = linkedSetOf<String>()
    private val endlessSeedArtistKeys = linkedSetOf<String>()
    private var endlessNonSeedSelections = 0
    private val endlessPlayedAutoUrls = linkedSetOf<String>()
    private var endlessGenreProfile = EndlessGenreProfile.POP
    private var endlessSceneProfile = EndlessSceneProfile.GLOBAL
    private var endlessArtistOnlyMode = false
    private var endlessArtistOnlySeed: TrackRef? = null
    private var endlessArtistAllowLongTracks = false
    private val endlessArtistReplayQueue = ArrayDeque<TrackRef>()
    private val endlessRecent = mutableListOf<TrackRef>()
    private val endlessRecentArtists = mutableListOf<String>()
    private var endlessQueued: TrackRef? = null
    private var endlessWaitingFreeDeck: Boolean? = null
    private var endlessDiscoveryJob: Job? = null
    private var endlessLoadJobA: Job? = null
    private var endlessLoadJobB: Job? = null
    private var endlessSessionGeneration = 0L
    private val endlessAnchorTracks = mutableListOf<TrackRef>()
    private val endlessPendingAnchorTracks = ArrayDeque<TrackRef>()
    private var endlessDiscoveriesSinceAnchorExpansion = 0
    private var lastContinuityGuardAt = 0L
    private var lastRecoveryAttemptAt = 0L
    private var endlessRecoveryDeck: Boolean? = null
    private var endlessModeLocked = false
    private val endlessPrefetchMs = 60_000L
    private val endlessReadyDeadlineMs = 15_000L
    private val endlessNextFreezeMs = 40_000L
    private val endlessEarlySearchAtMs = 3_000L
    private var endlessDeckHasPlayedA = false
    private var endlessDeckHasPlayedB = false
    private var endlessDeckStateA = EndlessDeckState.FREE
    private var endlessDeckStateB = EndlessDeckState.FREE
    private var endlessSeedProtectedA = false
    private var endlessSeedProtectedB = false
    private var endlessManualProtectedA = false
    private var endlessManualProtectedB = false
    private var endlessPendingNextUrlA: String? = null
    private var endlessPendingNextUrlB: String? = null
    private var endlessAddMode = false
    private val endlessManualUrls = linkedSetOf<String>()
    private var mixInMsA = 0L
    private var mixInMsB = 0L
    private var mixOutMsA = 0L
    private var mixOutMsB = 0L

    private var quickDrawerOpen = false
    private val quickRegions = linkedSetOf<String>()
    private val quickEras = linkedSetOf<String>()
    private val quickStyles = linkedSetOf<String>()
    private var quickVenuePreset: String? = null
    private var quickSceneOverride: EndlessSceneProfile? = null
    private var quickSessionAnchorTerms = ""
    private var quickSessionStyleTerms = ""
    private var quickLongFormDuration = false
    private var quickSessionActive = false
    private var quickStartJob: Job? = null

    private val speechLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != RESULT_OK || !::binding.isInitialized) return@registerForActivityResult
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
            ?.trim()
            .orEmpty()
        if (spoken.isNotBlank()) {
            binding.endlessSearchInput.setText(spoken)
            binding.endlessSearchInput.setSelection(spoken.length)
            runEndlessSearch()
        }
    }

    private val micPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchSpeechRecognizer()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMixerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val loadControlA = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 40_000, 2_500, 2_500)
            .setBackBuffer(20_000, true)
            .build()
        val loadControlB = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 40_000, 2_500, 2_500)
            .setBackBuffer(20_000, true)
            .build()
        playerA = ExoPlayer.Builder(this).setLoadControl(loadControlA).build()
        playerB = ExoPlayer.Builder(this).setLoadControl(loadControlB).build()
        playerA.setWakeMode(C.WAKE_MODE_NETWORK)
        playerB.setWakeMode(C.WAKE_MODE_NETWORK)
        setupAudioFocusProtection()
        addPlayerListener(playerA, true)
        addPlayerListener(playerB, false)

        endlessAdapter = SearchAdapter(
            targetDeck = null,
            onImportA = {},
            onImportB = {},
            onSelect = { selectEndlessSeed(it) }
        )
        binding.endlessResults.layoutManager = LinearLayoutManager(this)
        binding.endlessResults.adapter = endlessAdapter

        binding.loadA.setOnClickListener { openSearchFor("A") }
        binding.loadB.setOnClickListener { openSearchFor("B") }

        binding.playA.setOnClickListener {
            cancelAutoFadeForManualControl()
            MixerStore.deckA?.let { toggleDeck(true, it) }
                ?: Toast.makeText(this, "Press A to load a song", Toast.LENGTH_SHORT).show()
        }
        binding.playB.setOnClickListener {
            cancelAutoFadeForManualControl()
            MixerStore.deckB?.let { toggleDeck(false, it) }
                ?: Toast.makeText(this, "Press B to load a song", Toast.LENGTH_SHORT).show()
        }

        binding.autoMix.setOnClickListener {
            if (endlessActive) {
                Toast.makeText(this, "Endless Mix controls AUTO", Toast.LENGTH_SHORT).show()
            } else {
                autoEnabled = !autoEnabled
                updateAutoButton()
            }
        }

        binding.waveA.onSeekRequested = { fraction ->
            seekDeck(playerA, fraction)
        }
        binding.waveB.onSeekRequested = { fraction ->
            seekDeck(playerB, fraction)
        }

        binding.volumeA.progress = 100
        binding.volumeA.onProgressChanged = { p ->
            userVolA = p / 100f
            applyVolumes()
        }
        binding.volumeB.progress = 100
        binding.volumeB.onProgressChanged = { p ->
            userVolB = p / 100f
            applyVolumes()
        }

        binding.masterVolume.progress = 100
        binding.masterVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                masterVolume = progress / 100f
                applyVolumes()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        binding.masterMute.setOnClickListener {
            masterMuted = !masterMuted
            updateMasterMuteUi()
            applyVolumes()
        }
        updateMasterMuteUi()

        // App startup always begins hard-left on deck A. Do not restore a stale crossfader
        // position from an earlier session; both the UI thumb and volume engine start on A.
        cross = 0f
        binding.crossfader.progress = 0
        applyVolumes()

        binding.crossfader.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    cancelAutoFadeForManualControl()
                    cross = progress / 100f
                    applyVolumes()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                cancelAutoFadeForManualControl()
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        binding.endlessAction.setOnClickListener { onEndlessAction() }
        binding.endlessSearchButton.setOnClickListener { runEndlessSearch() }
        binding.endlessVoiceButton.setOnClickListener { requestEndlessVoiceSearch() }
        binding.mixLock.setOnClickListener { toggleControlLock() }
        binding.addToMix.setOnClickListener { requestAddToMix() }
        setupQuickEndlessUi()
        binding.filterLive.setOnClickListener {
            if (!controlsLocked) {
                allowLive = !allowLive
                updateEndlessFilterButtons()
            }
        }
        binding.filterCover.setOnClickListener {
            if (!controlsLocked) {
                allowCover = !allowCover
                updateEndlessFilterButtons()
            }
        }
        binding.filterOfficial.setOnClickListener {
            if (!controlsLocked) {
                onlyOfficial = !onlyOfficial
                updateEndlessFilterButtons()
            }
        }
        binding.endlessSearchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                runEndlessSearch()
                true
            } else false
        }

        refreshDecks(force = true)
        syncSeedsFromCurrentDecks()
        updateAutoButton()
        updateEndlessAction()
        updateControlLockUi()
        updateEndlessFilterButtons()
        applyVolumes()

        lifecycleScope.launch {
            while (isActive) {
                updateDeckUi(playerA, true)
                updateDeckUi(playerB, false)
                checkAutoMix()
                if (quickSessionActive && !endlessActive && MixerStore.deckA != null && MixerStore.deckB != null) {
                    syncSeedsFromCurrentDecks()
                    if (endlessSeeds.size >= 2) startEndlessMix()
                }
                protectEndlessContinuity()
                updateCrossSpectrum()
                delay(100)
            }
        }
    }

    private fun addPlayerListener(player: ExoPlayer, isA: Boolean) {
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                val button = if (isA) binding.playA else binding.playB
                when (playbackState) {
                    Player.STATE_BUFFERING -> {
                        button.text = "LOADING"
                        setPlayColor(button, false)
                    }
                    Player.STATE_READY -> {
                        updatePlayButton(isA)
                        if (endlessActive && !player.isPlaying) {
                            val state = if (isA) endlessDeckStateA else endlessDeckStateB
                            // Only a deck we explicitly loaded as NEXT may become READY_NEXT.
                            // A spent paused deck can remain ExoPlayer STATE_READY at -0:04; FREE
                            // must remain FREE even if ExoPlayer reports READY again.
                            if (state == EndlessDeckState.LOADING_NEXT) {
                                if (isA) endlessDeckStateA = EndlessDeckState.READY_NEXT
                                else endlessDeckStateB = EndlessDeckState.READY_NEXT
                            }
                        }
                        if (endlessActive && pendingEndlessStart && pendingEndlessStartIsA == isA) {
                            pendingEndlessStart = false
                            pendingEndlessStartIsA = null
                            player.play()
                        }
                        if (endlessActive && endlessRecoveryDeck == isA && !playerA.isPlaying && !playerB.isPlaying) {
                            cross = if (isA) 0f else 1f
                            binding.crossfader.progress = if (isA) 0 else 100
                            applyVolumes()
                            applyEndlessMixInPoint(player, targetIsA = isA)
                            player.play()
                            (if (isA) MixerStore.deckA else MixerStore.deckB)?.let { markEndlessAutoPlayed(it) }
                            endlessRecoveryDeck = null
                            endlessWaitingFreeDeck = null
                            discoverQueuedCandidate()
                        }
                    }
                    Player.STATE_ENDED -> {
                        if ((isA && endlessSeedProtectedA) || (!isA && endlessSeedProtectedB)) return
                        if (isA) endlessDeckStateA = EndlessDeckState.FREE else endlessDeckStateB = EndlessDeckState.FREE
                        button.text = "PLAY"
                        setPlayColor(button, false)
                        updateLoadButtons()
                        if (endlessActive && autoFadeJob?.isActive != true) {
                            // Do not wait for the 100 ms watchdog loop. An ended deck is immediately
                            // available for the next candidate; if both are stopped this also arms
                            // the recovery autostart path.
                            endlessWaitingFreeDeck = isA
                            if (!playerA.isPlaying && !playerB.isPlaying) endlessRecoveryDeck = isA
                            endlessQueued?.let { queued ->
                                endlessQueued = null
                                endlessWaitingFreeDeck = null
                                loadEndlessTrackIntoDeck(isA, queued)
                            } ?: discoverQueuedCandidate()
                        }
                    }
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (endlessActive && isPlaying) {
                    val state = if (isA) endlessDeckStateA else endlessDeckStateB
                    val crossfadeRunning = autoFadeJob?.isActive == true

                    // HARD single-owner playback rule. A prepared NEXT deck is not allowed to
                    // promote itself to PLAYING just because ExoPlayer received a stale/delayed
                    // play request. Only a deck already explicitly granted PLAYING state may run.
                    // The sole exception is the intentional crossfade window, when both decks
                    // are allowed to be audible at the same time.
                    if (state != EndlessDeckState.PLAYING && !crossfadeRunning) {
                        player.pause()
                        updatePlayButton(isA)
                        updateLoadButtons()
                        return
                    }

                    if (isA) {
                        endlessSeedProtectedA = false
                        endlessDeckHasPlayedA = true
                    } else {
                        endlessSeedProtectedB = false
                        endlessDeckHasPlayedB = true
                    }
                }
                updatePlayButton(isA)
                updateLoadButtons()
            }
        })
    }

    private fun openSearchFor(deck: String) {
        startActivity(Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_TARGET_DECK, deck))
    }

    private fun prepareDeck(isA: Boolean, track: TrackRef) {
        val player = if (isA) playerA else playerB
        val button = if (isA) binding.playA else binding.playB
        val direct = track.streamUrl ?: return

        button.text = "LOADING"
        button.isEnabled = false
        setPlayColor(button, false)
        player.setMediaItem(MediaItem.fromUri(direct))
        player.prepare()
    }

    private fun toggleDeck(isA: Boolean, track: TrackRef) {
        if (::audioFocusRequest.isInitialized) audioManager.requestAudioFocus(audioFocusRequest)
        val player = if (isA) playerA else playerB
        if (player.mediaItemCount == 0) {
            resolvePrepareAnalyze(isA, track)
            return
        }
        if (player.playbackState == Player.STATE_READY || player.playbackState == Player.STATE_BUFFERING) {
            if (player.isPlaying) player.pause() else player.play()
        }
    }

    private fun refreshDecks(force: Boolean = false) {
        val a = MixerStore.deckA
        val b = MixerStore.deckB

        if (force || a?.url != lastTrackAUrl) {
            playerA.stop(); playerA.clearMediaItems()
            lastTrackAUrl = a?.url
            measuredRmsA = null
            mixInMsA = 0L
            mixOutMsA = 0L
            endlessDeckHasPlayedA = false
            userVolA = 1f
            binding.volumeA.progress = 100
            binding.titleA.text = a?.title ?: "EMPTY"
            binding.playA.text = "PLAY"
            binding.playA.isEnabled = a != null
            setPlayColor(binding.playA, false)
            if (a == null) {
                binding.waveA.setEmpty()
                binding.timeA.text = ""
            } else {
                binding.waveA.setTrackPresent(true)
                val cached = MixerStore.waveA
                if (cached != null) binding.waveA.setWaveform(cached, 1f)
                resolvePrepareAnalyze(true, a)
            }
        }

        if (force || b?.url != lastTrackBUrl) {
            playerB.stop(); playerB.clearMediaItems()
            lastTrackBUrl = b?.url
            measuredRmsB = null
            mixInMsB = 0L
            mixOutMsB = 0L
            endlessDeckHasPlayedB = false
            userVolB = 1f
            binding.volumeB.progress = 100
            binding.titleB.text = b?.title ?: "EMPTY"
            binding.playB.text = "PLAY"
            binding.playB.isEnabled = b != null
            setPlayColor(binding.playB, false)
            if (b == null) {
                binding.waveB.setEmpty()
                binding.timeB.text = ""
            } else {
                binding.waveB.setTrackPresent(true)
                val cached = MixerStore.waveB
                if (cached != null) binding.waveB.setWaveform(cached, 1f)
                resolvePrepareAnalyze(false, b)
            }
        }
    }

    private fun resolvePrepareAnalyze(isA: Boolean, track: TrackRef) {
        val key = track.url
        val player = if (isA) playerA else playerB
        val button = if (isA) binding.playA else binding.playB

        if (player.mediaItemCount > 0) {
            if (!endlessActive && (if (isA) MixerStore.waveA else MixerStore.waveB) == null) analyzeWaveform(isA, track)
            return
        }

        val existing = track.streamUrl
        if (existing != null) {
            prepareDeck(isA, track)
            // Endless preloads prioritize ExoPlayer buffering; their analysis is scheduled a few
            // seconds later by loadEndlessTrackIntoDeck so it cannot steal bandwidth from READY.
            if (!endlessActive && (if (isA) MixerStore.waveA else MixerStore.waveB) == null) analyzeWaveform(isA, track)
            return
        }

        if ((if (isA) resolvingA else resolvingB) == key) return
        if (isA) resolvingA = key else resolvingB = key
        button.text = "LOADING"
        button.isEnabled = false
        setPlayColor(button, false)

        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) { AudioResolver.resolveBestAudioUrl(track.url) }
            }
            if (isA) resolvingA = null else resolvingB = null

            result.onSuccess { direct ->
                val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                if (!sameTrack) return@onSuccess
                val updated = track.copy(streamUrl = direct)
                if (isA) MixerStore.deckA = updated else MixerStore.deckB = updated
                prepareDeck(isA, updated)
                analyzeWaveform(isA, updated)
            }.onFailure {
                val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                if (sameTrack) {
                    button.isEnabled = true
                    button.text = "PLAY"
                    setPlayColor(button, false)
                    Toast.makeText(this@MixerActivity, "Stream error: ${it.message ?: "unknown"}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun analyzeWaveform(isA: Boolean, track: TrackRef) {
        val direct = track.streamUrl ?: return
        val key = track.url
        if (isA) {
            if (MixerStore.waveA != null || analyzingA == key) return
            analyzingA = key
        } else {
            if (MixerStore.waveB != null || analyzingB == key) return
            analyzingB = key
        }

        lifecycleScope.launch {
            val analysis = runCatching {
                withContext(Dispatchers.IO) {
                    WaveformAnalyzer.analyze(direct) { partial, fraction ->
                        runOnUiThread {
                            val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                            if (sameTrack) {
                                if (isA) binding.waveA.setWaveform(partial, fraction)
                                else binding.waveB.setWaveform(partial, fraction)
                            }
                        }
                    }
                }
            }.getOrNull()

            if (isA) {
                analyzingA = null
                if (MixerStore.deckA?.url == key && analysis != null) {
                    if (endlessActive && !playerA.isPlaying && analysis.rms >= 0.001f && analysis.rms < minimumEndlessRms) {
                        endlessUsedUrls.add(track.url)
                        endlessUsedTrackKeys.add(endlessTrackKey(track))
                        freePausedEndlessDeck(true, force = true)
                        return@launch
                    }
                    MixerStore.waveA = analysis.waveform
                    measuredRmsA = analysis.rms
                    mixInMsA = maxOf(mixInMsA, detectMixInPointMs(analysis.waveform, track.durationSeconds * 1000L))
                    mixOutMsA = detectMixOutPointMs(analysis.waveform, track.durationSeconds * 1000L)
                    binding.waveA.setWaveform(analysis.waveform, 1f)
                    applyAutoLoudness(true, analysis.rms)
                }
            } else {
                analyzingB = null
                if (MixerStore.deckB?.url == key && analysis != null) {
                    if (endlessActive && !playerB.isPlaying && analysis.rms >= 0.001f && analysis.rms < minimumEndlessRms) {
                        endlessUsedUrls.add(track.url)
                        endlessUsedTrackKeys.add(endlessTrackKey(track))
                        freePausedEndlessDeck(false, force = true)
                        return@launch
                    }
                    MixerStore.waveB = analysis.waveform
                    measuredRmsB = analysis.rms
                    mixInMsB = maxOf(mixInMsB, detectMixInPointMs(analysis.waveform, track.durationSeconds * 1000L))
                    mixOutMsB = detectMixOutPointMs(analysis.waveform, track.durationSeconds * 1000L)
                    binding.waveB.setWaveform(analysis.waveform, 1f)
                    applyAutoLoudness(false, analysis.rms)
                }
            }
        }
    }

    private fun updateDeckUi(player: ExoPlayer, isA: Boolean) {
        val duration = player.duration
        val position = player.currentPosition.coerceAtLeast(0L)
        val p = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f
        val remaining = if (duration > 0) (duration - position).coerceAtLeast(0L) else -1L

        if (isA) {
            binding.waveA.setProgress(p)
            binding.timeA.text = if (remaining >= 0) "-${formatTime(remaining)}" else ""
        } else {
            binding.waveB.setProgress(p)
            binding.timeB.text = if (remaining >= 0) "-${formatTime(remaining)}" else ""
        }
    }

    private fun seekDeck(player: ExoPlayer, fraction: Float) {
        if (player.mediaItemCount == 0) return
        val duration = player.duration
        if (duration > 0) player.seekTo((duration * fraction.coerceIn(0f, 1f)).toLong())
    }

    private fun checkAutoMix() {
        if (!autoEnabled || autoFadeJob?.isActive == true) return
        val aDuration = playerA.duration
        val bDuration = playerB.duration
        val aDefaultTrigger = if (aDuration > 0L) (aDuration - autoTriggerMs).coerceAtLeast(0L) else Long.MAX_VALUE
        val bDefaultTrigger = if (bDuration > 0L) (bDuration - autoTriggerMs).coerceAtLeast(0L) else Long.MAX_VALUE
        val aTriggerAt = if (mixOutMsA > 0L) minOf(aDefaultTrigger, mixOutMsA) else aDefaultTrigger
        val bTriggerAt = if (mixOutMsB > 0L) minOf(bDefaultTrigger, mixOutMsB) else bDefaultTrigger

        if (playerA.isPlaying && playerA.currentPosition >= aTriggerAt && deckReadyForAuto(playerB)) {
            startAutoFade(fromA = true)
        } else if (playerB.isPlaying && playerB.currentPosition >= bTriggerAt && deckReadyForAuto(playerA)) {
            startAutoFade(fromA = false)
        }
    }

    private fun freePausedEndlessDeck(isA: Boolean, force: Boolean = false) {
        if (!endlessActive) return
        if ((isA && endlessSeedProtectedA) || (!isA && endlessSeedProtectedB)) return
        // A user-inserted ADD TO MIX track is sacred until it has actually played.
        // Never reclaim/refresh its deck merely because it is paused while waiting.
        if ((isA && endlessManualProtectedA) || (!isA && endlessManualProtectedB)) return
        val hasPlayed = if (isA) endlessDeckHasPlayedA else endlessDeckHasPlayedB
        if (!force && !hasPlayed) return
        if (isA) {
            endlessDeckHasPlayedA = false
            endlessDeckStateA = EndlessDeckState.FREE
        } else {
            endlessDeckHasPlayedB = false
            endlessDeckStateB = EndlessDeckState.FREE
        }

        // Mark the physical deck as the destination before touching discovery. If a discovery
        // job is already running, it will see this waiting slot when it completes and load the
        // candidate directly here instead of leaving it merely queued.
        endlessWaitingFreeDeck = isA
        val queued = endlessQueued
        if (queued != null) {
            endlessQueued = null
            endlessWaitingFreeDeck = null
            loadEndlessTrackIntoDeck(isA, queued)
        } else {
            // Safe even if a discovery job is already active: that job keeps running and will
            // consume endlessWaitingFreeDeck on completion. If none is active, this starts one.
            discoverQueuedCandidate()
        }
    }

    private fun protectEndlessContinuity() {
        if (!endlessActive) return
        val now = android.os.SystemClock.elapsedRealtime()

        // Endless rule: once a deck that has actually played is PAUSED/not playing, it is spent.
        // Reclaim it immediately for the next track; do not wait for STATE_ENDED or remaining time.
        if (endlessDeckHasPlayedA && !playerA.isPlaying && autoFadeJob?.isActive != true) {
            freePausedEndlessDeck(true)
        }
        if (endlessDeckHasPlayedB && !playerB.isPlaying && autoFadeJob?.isActive != true) {
            freePausedEndlessDeck(false)
        }

        // Pipeline rule: give a newly started song only about three seconds to stabilize,
        // then start finding the song AFTER the already-loaded opposite deck. Keep it queued
        // until a played deck becomes free. This gives search/resolution almost a full song.
        val active = when {
            playerA.isPlaying -> playerA
            playerB.isPlaying -> playerB
            else -> null
        }
        if (active != null && active.currentPosition >= endlessEarlySearchAtMs &&
            endlessQueued == null && endlessDiscoveryJob?.isActive != true && endlessWaitingFreeDeck == null) {
            discoverQueuedCandidate()
        }

        fun ensureNextDeck(source: ExoPlayer, sourceIsA: Boolean, target: ExoPlayer) {
            if (!source.isPlaying) return
            val remaining = remainingMs(source)
            val targetIsA = !sourceIsA
            if ((targetIsA && endlessSeedProtectedA) || (!targetIsA && endlessSeedProtectedB)) return

            // Start preparing the next deck a full minute before the transition. If a candidate
            // is already queued, load it immediately into the non-playing deck instead of waiting
            // for the current song to end.
            if (remaining <= endlessPrefetchMs && !deckReadyForAuto(target)) {
                if (endlessWaitingFreeDeck == null) endlessWaitingFreeDeck = targetIsA
                val queued = endlessQueued
                if (queued != null && endlessWaitingFreeDeck == targetIsA) {
                    endlessQueued = null
                    endlessWaitingFreeDeck = null
                    loadEndlessTrackIntoDeck(targetIsA, queued)
                } else {
                    discoverQueuedCandidate()
                }
            }

            // By 15 seconds the target must be READY. Keep hammering discovery/resolution.
            if (remaining <= endlessReadyDeadlineMs && !deckReadyForAuto(target)) {
                endlessWaitingFreeDeck = targetIsA
                discoverQueuedCandidate()
            }

        }

        ensureNextDeck(playerA, true, playerB)
        ensureNextDeck(playerB, false, playerA)

        if (!playerA.isPlaying && !playerB.isPlaying && autoFadeJob?.isActive != true) {
            // FINAL DEAD-AIR KILLER: after long runtimes an event can occasionally be missed even
            // though one deck is already READY_NEXT and the opposite deck has reached the end.
            // In that exact state, do not wait for search/recovery bookkeeping: start READY_NEXT now.
            val aReadyNext = endlessDeckStateA == EndlessDeckState.READY_NEXT &&
                playerA.mediaItemCount > 0 && playerA.playbackState == Player.STATE_READY
            val bReadyNext = endlessDeckStateB == EndlessDeckState.READY_NEXT &&
                playerB.mediaItemCount > 0 && playerB.playbackState == Player.STATE_READY
            val aEnded = playerA.mediaItemCount == 0 || playerA.playbackState == Player.STATE_ENDED || remainingMs(playerA) <= 1_000L
            val bEnded = playerB.mediaItemCount == 0 || playerB.playbackState == Player.STATE_ENDED || remainingMs(playerB) <= 1_000L
            if (aReadyNext && bEnded) {
                cross = 0f
                binding.crossfader.progress = 0
                applyVolumes()
                applyEndlessMixInPoint(playerA, targetIsA = true)
                endlessDeckStateA = EndlessDeckState.PLAYING
                playerA.play()
                MixerStore.deckA?.let { markEndlessAutoPlayed(it) }
                endlessRecoveryDeck = null
                endlessWaitingFreeDeck = false
                discoverQueuedCandidate()
                return
            }
            if (bReadyNext && aEnded) {
                cross = 1f
                binding.crossfader.progress = 100
                applyVolumes()
                applyEndlessMixInPoint(playerB, targetIsA = false)
                endlessDeckStateB = EndlessDeckState.PLAYING
                playerB.play()
                MixerStore.deckB?.let { markEndlessAutoPlayed(it) }
                endlessRecoveryDeck = null
                endlessWaitingFreeDeck = true
                discoverQueuedCandidate()
                return
            }

            if (now - lastRecoveryAttemptAt < 750L) return
            lastRecoveryAttemptAt = now
            val aPlayable = deckReadyForAuto(playerA) && remainingMs(playerA) > 2_000L
            val bPlayable = deckReadyForAuto(playerB) && remainingMs(playerB) > 2_000L
            when {
                aPlayable -> {
                    cross = 0f
                    binding.crossfader.progress = 0
                    applyVolumes()
                    applyEndlessMixInPoint(playerA, targetIsA = true)
                    endlessDeckStateA = EndlessDeckState.PLAYING
                    playerA.play()
                    MixerStore.deckA?.let { markEndlessAutoPlayed(it) }
                    endlessRecoveryDeck = null
                    endlessWaitingFreeDeck = false
                    discoverQueuedCandidate()
                }
                bPlayable -> {
                    cross = 1f
                    binding.crossfader.progress = 100
                    applyVolumes()
                    applyEndlessMixInPoint(playerB, targetIsA = false)
                    endlessDeckStateB = EndlessDeckState.PLAYING
                    playerB.play()
                    MixerStore.deckB?.let { markEndlessAutoPlayed(it) }
                    endlessRecoveryDeck = null
                    endlessWaitingFreeDeck = true
                    discoverQueuedCandidate()
                }
                else -> {
                    // Prefer an ended/empty deck for recovery. Keep retrying until one becomes READY.
                    val recoverA = playerA.playbackState == Player.STATE_ENDED || playerA.mediaItemCount == 0 ||
                        (playerB.playbackState != Player.STATE_ENDED && remainingMs(playerA) <= remainingMs(playerB))
                    endlessRecoveryDeck = recoverA
                    endlessWaitingFreeDeck = recoverA
                    endlessQueued = null
                    discoverQueuedCandidate()
                }
            }
        }
    }

    private fun deckReadyForAuto(player: ExoPlayer): Boolean {
        if (player.mediaItemCount == 0 || player.playbackState != Player.STATE_READY) return false
        if (endlessActive) {
            val state = if (player === playerA) endlessDeckStateA else endlessDeckStateB
            // ExoPlayer may remain STATE_READY on the old paused track (often around -0:04).
            // FREE is authoritative: a spent deck can never masquerade as the next ready deck.
            if (state != EndlessDeckState.READY_NEXT && state != EndlessDeckState.PLAYING) return false
        }
        val d = player.duration
        return d <= 0 || player.currentPosition < d - 1_000L
    }

    private fun remainingMs(player: ExoPlayer): Long {
        val d = player.duration
        return if (d > 0) (d - player.currentPosition).coerceAtLeast(0L) else Long.MAX_VALUE
    }

    private fun startAutoFade(fromA: Boolean) {
        val source = if (fromA) playerA else playerB
        val target = if (fromA) playerB else playerA
        if (!deckReadyForAuto(target)) return

        applyEndlessMixInPoint(target, targetIsA = !fromA)
        if (endlessActive) {
            if (fromA) endlessDeckStateB = EndlessDeckState.PLAYING else endlessDeckStateA = EndlessDeckState.PLAYING
        }
        target.play()
        val startCross = cross
        val endCross = if (fromA) 1f else 0f

        autoFadeJob = lifecycleScope.launch {
            val steps = 50
            for (i in 0..steps) {
                if (!isActive) return@launch
                val t = i / steps.toFloat()
                cross = startCross + (endCross - startCross) * t
                binding.crossfader.progress = (cross * 100f).roundToInt().coerceIn(0, 100)
                applyVolumes()
                delay(autoFadeMs / steps)
            }
            source.pause()
            cross = endCross
            binding.crossfader.progress = (cross * 100f).roundToInt()
            applyVolumes()
            autoFadeJob = null
            if (endlessActive) onEndlessTransitionComplete(freedIsA = fromA)
        }
    }

    private fun cancelAutoFadeForManualControl() {
        if (endlessActive) stopEndlessForManualControl()
        if (autoFadeJob?.isActive == true) {
            autoFadeJob?.cancel()
            autoFadeJob = null
            autoEnabled = false
            updateAutoButton()
        }
    }

    private fun detectMixInPointMs(waveform: FloatArray, durationMs: Long): Long {
        if (durationMs <= 0L || waveform.isEmpty()) return 0L
        val maxSkipMs = minOf(20_000L, durationMs / 8)
        val maxBucket = ((maxSkipMs.toDouble() / durationMs) * waveform.size)
            .toInt().coerceIn(1, waveform.lastIndex.coerceAtLeast(1))
        // If the opening is already clearly audible, keep the true beginning.
        if (waveform.take(minOf(3, waveform.size)).any { it >= 0.20f }) return 0L
        for (i in 0 until maxBucket) {
            val end = minOf(i + 4, waveform.size)
            if (end - i >= 3 && waveform.sliceArray(i until end).count { it >= 0.22f } >= 3) {
                return ((i.toDouble() / waveform.size) * durationMs).toLong().coerceIn(0L, maxSkipMs)
            }
        }
        return 0L
    }

    private fun detectMixOutPointMs(waveform: FloatArray, durationMs: Long): Long {
        if (durationMs <= 0L || waveform.size < 8) return 0L
        // Look only near the tail. If a sustained quiet tail begins before the normal 12 s
        // trigger, transition at the start of that tail rather than fading through silence.
        val scanStart = (waveform.size * 0.72f).toInt().coerceIn(0, waveform.lastIndex)
        var quietRun = 0
        var quietStart = -1
        for (i in scanStart until waveform.size) {
            if (waveform[i] < 0.10f) {
                if (quietRun == 0) quietStart = i
                quietRun++
                if (quietRun >= 4) {
                    val t = ((quietStart.toDouble() / waveform.size) * durationMs).toLong()
                    return t.coerceIn(0L, durationMs)
                }
            } else {
                quietRun = 0
                quietStart = -1
            }
        }
        return 0L
    }

    private fun updateMasterMuteUi() {
        binding.masterMute.setImageResource(if (masterMuted) R.drawable.ic_unmute else R.drawable.ic_mute)
        binding.masterMute.contentDescription = if (masterMuted) "Unmute master" else "Mute master"
        binding.masterMute.backgroundTintList = ColorStateList.valueOf(
            ContextCompat.getColor(this, if (masterMuted) R.color.red_control else R.color.yellow_control)
        )
    }

    private fun waveformEnergy(isA: Boolean): Float {
        val player = if (isA) playerA else playerB
        if (player.mediaItemCount == 0 || player.duration <= 0L) return 0f
        val wave = if (isA) MixerStore.waveA else MixerStore.waveB
        val gain = if (isA) (1f - cross) else cross
        if (wave == null || wave.isEmpty()) return if (player.isPlaying) 0.28f * gain else 0f
        val fraction = (player.currentPosition.toFloat() / player.duration).coerceIn(0f, 0.999f)
        val index = (fraction * wave.size).toInt().coerceIn(0, wave.lastIndex)
        val local = wave[index]
        return (local * gain).coerceIn(0f, 1f)
    }

    private fun updateCrossSpectrum() {
        val phase = ((playerA.currentPosition + playerB.currentPosition) % 4000L) / 4000f * 6.283185f
        binding.crossSpectrum.setEnergy(waveformEnergy(true), waveformEnergy(false), phase)
    }

    private fun applyEndlessMixInPoint(player: ExoPlayer, targetIsA: Boolean) {
        if (!endlessActive || player.currentPosition > 1_000L) return
        val mixIn = if (targetIsA) mixInMsA else mixInMsB
        if (mixIn > 750L) player.seekTo(mixIn)
    }

    private fun applyAutoLoudness(isA: Boolean, rms: Float) {
        if (rms <= 0.001f) return
        // Never boost above the clean 100% deck level; only tame louder tracks.
        val normalized = (loudnessTargetRms / rms).coerceIn(0.55f, 1f)
        val progress = (normalized * 100f).roundToInt().coerceIn(55, 100)
        if (isA) {
            userVolA = progress / 100f
            binding.volumeA.progress = progress
        } else {
            userVolB = progress / 100f
            binding.volumeB.progress = progress
        }
        applyVolumes()
    }

    private fun applyVolumes() {
        val headroom = 0.82f
        val aGain = (1f - cross) * headroom
        val bGain = cross * headroom
        val muteGain = if (masterMuted) 0f else 1f
        playerA.volume = (userVolA * aGain * masterVolume * masterDuck * muteGain).coerceIn(0f, 1f)
        playerB.volume = (userVolB * bGain * masterVolume * masterDuck * muteGain).coerceIn(0f, 1f)
    }

    private fun updatePlayButton(isA: Boolean) {
        val player = if (isA) playerA else playerB
        val button = if (isA) binding.playA else binding.playB
        button.isEnabled = !controlsLocked && player.mediaItemCount > 0 && player.playbackState != Player.STATE_IDLE
        if (player.isPlaying) {
            button.text = "PAUSE"
            setPlayColor(button, true)
        } else if (player.playbackState == Player.STATE_BUFFERING) {
            button.text = "LOADING"
            setPlayColor(button, false)
        } else {
            button.text = "PLAY"
            setPlayColor(button, false)
        }
    }

    private fun updateLoadButtons() {
        val aLocked = playerA.isPlaying
        val bLocked = playerB.isPlaying

        binding.loadA.isEnabled = !controlsLocked && !aLocked
        binding.loadA.alpha = if (controlsLocked || aLocked) 0.35f else 1f
        binding.loadB.isEnabled = !controlsLocked && !bLocked
        binding.loadB.alpha = if (controlsLocked || bLocked) 0.35f else 1f
    }

    private fun setPlayColor(button: Button, pausedState: Boolean) {
        val color = if (pausedState) R.color.yellow_control else R.color.blue_control
        button.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, color))
        button.setTextColor(ContextCompat.getColor(this, if (pausedState) R.color.black else R.color.white))
    }

    private fun updateAutoButton() {
        val color = if (autoEnabled) R.color.orange_control else R.color.white
        binding.autoMix.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, color))
        binding.autoMix.setTextColor(ContextCompat.getColor(this, R.color.black))
        binding.autoMix.text = if (autoEnabled) "AUTO IS ON" else "AUTO IS OFF"
        binding.autoMix.isEnabled = !controlsLocked
    }

    // ---------------- ENDLESS MIX ----------------

    private fun onEndlessAction() {
        if (endlessActive) {
            stopEndlessMix()
            return
        }

        syncSeedsFromCurrentDecks()
        if (endlessSeeds.size >= 2) {
            startEndlessMix()
        } else {
            endlessSeedMode = true
            showEndlessSearch(true)
            binding.endlessStatus.text = if (endlessSeeds.size == 1) {
                "1/2 loaded — choose a similar second song"
            } else {
                "Choose the first seed song"
            }
            updateEndlessAction()
        }
    }

    private fun syncSeedsFromCurrentDecks() {
        if (endlessActive) return
        endlessSeeds.clear()
        MixerStore.deckA?.let { endlessSeeds.add(it) }
        MixerStore.deckB?.let { b -> if (endlessSeeds.none { it.url == b.url }) endlessSeeds.add(b) }
        updateEndlessAction()
    }

    private fun updateEndlessAction() {
        binding.endlessAction.text = when {
            endlessActive -> "STOP ENDLESS MIX"
            endlessSeeds.size >= 2 -> "PLAY ENDLESS MIX"
            else -> "LOAD TWO SIMILAR SONGS\nAND MAKE ENDLESS MIX"
        }
    }

    private fun showEndlessSearch(show: Boolean) {
        if (show && quickDrawerOpen) closeQuickDrawer()
        binding.endlessSearchPanel.visibility = if (show) View.VISIBLE else View.GONE
        binding.quickEndlessButton.visibility = if (show) View.GONE else View.VISIBLE
        binding.endlessLowerSpacer.visibility = if (show || quickDrawerOpen) View.GONE else View.VISIBLE
        // During seed loading the search gets the lower workspace without leaving the mixer window.
        binding.autoMix.visibility = if (show) View.GONE else View.VISIBLE
        binding.crossLabels.visibility = if (show) View.GONE else View.VISIBLE
        binding.crossfader.visibility = if (show) View.GONE else View.VISIBLE
        if (!show) endlessAdapter.submit(emptyList())
    }

    private fun runEndlessSearch() {
        val q = binding.endlessSearchInput.text.toString().trim()
        if (q.isBlank()) return
        binding.endlessStatus.text = "Searching…"
        lifecycleScope.launch {
            runCatching {
                withContext(Dispatchers.IO) { searchRepo.search(q) }
            }.onSuccess { results ->
                endlessAdapter.submit(results)
                binding.endlessStatus.text = if (endlessActive && endlessAddMode) {
                    "Choose a song to add — ${results.size} results"
                } else when (endlessSeeds.size) {
                    0 -> "Choose the first song — ${results.size} results"
                    else -> "Choose a similar second song — ${results.size} results"
                }
            }.onFailure {
                binding.endlessStatus.text = "Search error: ${it.message ?: "unknown"}"
            }
        }
    }

    private fun selectEndlessSeed(track: TrackRef) {
        if (endlessActive && endlessAddMode) {
            endlessAddMode = false
            endlessManualUrls.add(track.url)
            showEndlessSearch(false)
            binding.endlessSearchInput.setText("")
            binding.endlessStatus.text = "Added to mix"
            // A deliberate user choice outranks an automatically preloaded NEXT track, but it
            // can never overwrite the currently playing deck or either still-reserved seed.
            val safeTarget: Boolean? = when {
                playerA.isPlaying && !playerB.isPlaying && !endlessSeedProtectedB -> false
                playerB.isPlaying && !playerA.isPlaying && !endlessSeedProtectedA -> true
                endlessWaitingFreeDeck != null -> endlessWaitingFreeDeck
                else -> null
            }
            if (safeTarget != null) {
                endlessQueued = null
                endlessWaitingFreeDeck = null
                if (safeTarget) endlessLoadJobA?.cancel() else endlessLoadJobB?.cancel()
                loadEndlessTrackIntoDeck(safeTarget, track)
            } else {
                endlessQueued = track
            }
            return
        }
        if (endlessSeeds.any { it.url == track.url }) {
            Toast.makeText(this, "Choose a different second song", Toast.LENGTH_SHORT).show()
            return
        }

        when {
            MixerStore.deckA == null -> MixerStore.setA(track)
            MixerStore.deckB == null -> MixerStore.setB(track)
            endlessSeeds.isEmpty() -> MixerStore.setA(track)
            endlessSeeds.size == 1 -> {
                val first = endlessSeeds.first()
                if (MixerStore.deckA?.url == first.url) MixerStore.setB(track) else MixerStore.setA(track)
            }
            else -> return
        }

        refreshDecks()
        syncSeedsFromCurrentDecks()
        if (endlessSeeds.size >= 2) {
            endlessSeedMode = false
            showEndlessSearch(false)
            binding.endlessSearchInput.setText("")
            updateEndlessAction()
        } else {
            binding.endlessStatus.text = "1/2 loaded — choose a similar second song"
        }
    }

    private fun startEndlessMix() {
        syncSeedsFromCurrentDecks()
        if (endlessSeeds.size < 2) {
            showEndlessSearch(true)
            return
        }

        // A new Endless press is a NEW session, but it adopts whatever is already playing.
        // Nothing queued/resolving from the previous session may survive and overwrite the
        // user's newly chosen A/B tracks.
        endlessSessionGeneration++
        endlessDiscoveryJob?.cancel()
        endlessDiscoveryJob = null
        endlessLoadJobA?.cancel()
        endlessLoadJobB?.cancel()
        endlessLoadJobA = null
        endlessLoadJobB = null
        endlessQueued = null
        endlessWaitingFreeDeck = null
        endlessRecoveryDeck = null
        endlessManualProtectedA = false
        endlessManualProtectedB = false
        endlessPendingNextUrlA = null
        endlessPendingNextUrlB = null
        endlessManualUrls.clear()
        endlessAnchorTracks.clear()
        endlessPendingAnchorTracks.clear()
        endlessDiscoveriesSinceAnchorExpansion = 0
        autoFadeJob?.cancel()
        autoFadeJob = null
        // A stale prepare callback from a previous/manual deck must never auto-start A after
        // Endless has selected B (or vice versa). Start permission belongs to exactly one deck.
        pendingEndlessStart = false
        pendingEndlessStartIsA = null

        if (::audioFocusRequest.isInitialized) audioManager.requestAudioFocus(audioFocusRequest)
        endlessActive = true
        endlessSeedMode = false
        autoEnabled = true
        controlsLocked = false
        endlessUsedUrls.clear()
        endlessUsedTrackKeys.clear()
        endlessSeedArtistKeys.clear()
        endlessNonSeedSelections = 0
        endlessPlayedAutoUrls.clear()
        endlessArtistReplayQueue.clear()
        endlessModeLocked = false
        endlessArtistOnlyMode = sameArtistConfidence(endlessSeeds[0], endlessSeeds[1])
        endlessGenreProfile = classifyEndlessGenre(endlessSeeds[0], endlessSeeds[1])
        endlessSceneProfile = quickSceneOverride ?: classifyEndlessScene(endlessSeeds[0], endlessSeeds[1])
        endlessModeLocked = true
        endlessArtistOnlySeed = if (endlessArtistOnlyMode) endlessSeeds[0] else null
        endlessArtistAllowLongTracks = false
        endlessRecent.clear()
        endlessRecentArtists.clear()
        endlessSeeds.take(2).forEach {
            endlessUsedUrls.add(it.url)
            endlessUsedTrackKeys.add(endlessTrackKey(it))
            endlessSeedArtistKeys.add(endlessArtistKey(it))
            endlessRecent.add(it)
            rememberEndlessArtist(it)
            endlessAnchorTracks.add(it)
        }
        endlessDeckHasPlayedA = playerA.isPlaying
        endlessDeckHasPlayedB = playerB.isPlaying
        showEndlessSearch(false)
        updateAutoButton()
        updateEndlessAction()
        updateControlLockUi()

        // Adopt the LIVE mixer instead of forcing deck A from 0:00.
        // Preserve playback positions and the user's current crossfader. The non-playing loaded
        // deck becomes READY_NEXT; if both are playing, the louder side is treated as current.
        val activeIsA = when {
            playerA.isPlaying && !playerB.isPlaying -> true
            playerB.isPlaying && !playerA.isPlaying -> false
            playerA.isPlaying && playerB.isPlaying -> cross <= 0.5f
            playerA.mediaItemCount > 0 && playerB.mediaItemCount == 0 -> true
            playerB.mediaItemCount > 0 && playerA.mediaItemCount == 0 -> false
            else -> cross <= 0.5f
        }

        if (activeIsA) {
            // One source deck only. The opposite seed is prepared NEXT but must not run in parallel.
            if (playerB.isPlaying) playerB.pause()
            endlessDeckStateA = EndlessDeckState.PLAYING
            endlessDeckStateB = when {
                playerB.mediaItemCount == 0 -> EndlessDeckState.FREE
                playerB.playbackState == Player.STATE_READY -> EndlessDeckState.READY_NEXT
                else -> EndlessDeckState.LOADING_NEXT
            }
            endlessSeedProtectedA = playerA.mediaItemCount > 0
            endlessSeedProtectedB = playerB.mediaItemCount > 0
            if (!playerA.isPlaying) {
                if (playerA.mediaItemCount > 0) playerA.play()
                else {
                    pendingEndlessStart = true
                    pendingEndlessStartIsA = true
                    MixerStore.deckA?.let { resolvePrepareAnalyze(true, it) }
                }
            }
        } else {
            // Symmetric B start: clear/pause A and grant deferred autoplay only to B.
            if (playerA.isPlaying) playerA.pause()
            endlessDeckStateB = EndlessDeckState.PLAYING
            endlessDeckStateA = when {
                playerA.mediaItemCount == 0 -> EndlessDeckState.FREE
                playerA.playbackState == Player.STATE_READY -> EndlessDeckState.READY_NEXT
                else -> EndlessDeckState.LOADING_NEXT
            }
            endlessSeedProtectedA = playerA.mediaItemCount > 0
            endlessSeedProtectedB = playerB.mediaItemCount > 0
            if (!playerB.isPlaying) {
                if (playerB.mediaItemCount > 0) playerB.play()
                else {
                    pendingEndlessStart = true
                    pendingEndlessStartIsA = false
                    MixerStore.deckB?.let { resolvePrepareAnalyze(false, it) }
                }
            }
        }

        // If one physical deck is already free, arm it immediately. Otherwise the early-search
        // guard will begin discovery about three seconds into the adopted/current song.
        if (endlessDeckStateA == EndlessDeckState.FREE) endlessWaitingFreeDeck = true
        else if (endlessDeckStateB == EndlessDeckState.FREE) endlessWaitingFreeDeck = false
    }

    private fun stopEndlessMix() {
        // Invalidate every asynchronous result from this session BEFORE clearing state. A stale
        // English/USA candidate from an old session must never arrive later and replace new seeds.
        endlessSessionGeneration++
        quickSessionActive = false
        endlessActive = false
        endlessSeedMode = false
        autoEnabled = false
        controlsLocked = false
        pendingEndlessStart = false
        pendingEndlessStartIsA = null
        endlessDiscoveryJob?.cancel()
        endlessDiscoveryJob = null
        endlessLoadJobA?.cancel()
        endlessLoadJobB?.cancel()
        endlessLoadJobA = null
        endlessLoadJobB = null
        autoFadeJob?.cancel()
        autoFadeJob = null
        endlessQueued = null
        endlessWaitingFreeDeck = null
        endlessDeckHasPlayedA = false
        endlessDeckHasPlayedB = false
        endlessDeckStateA = EndlessDeckState.FREE
        endlessDeckStateB = EndlessDeckState.FREE
        endlessSeedProtectedA = false
        endlessSeedProtectedB = false
        endlessManualProtectedA = false
        endlessManualProtectedB = false
        endlessPendingNextUrlA = null
        endlessPendingNextUrlB = null
        endlessAddMode = false
        endlessManualUrls.clear()
        quickSceneOverride = null
        quickSessionAnchorTerms = ""
        quickSessionStyleTerms = ""
        quickLongFormDuration = false
        endlessSeeds.clear()
        endlessUsedUrls.clear()
        endlessUsedTrackKeys.clear()
        endlessSeedArtistKeys.clear()
        endlessNonSeedSelections = 0
        endlessPlayedAutoUrls.clear()
        endlessGenreProfile = EndlessGenreProfile.POP
        endlessSceneProfile = EndlessSceneProfile.GLOBAL
        endlessArtistOnlyMode = false
        endlessModeLocked = false
        endlessRecoveryDeck = null
        endlessArtistOnlySeed = null
        endlessArtistAllowLongTracks = false
        endlessArtistReplayQueue.clear()
        endlessRecent.clear()
        endlessRecentArtists.clear()
        endlessAnchorTracks.clear()
        endlessPendingAnchorTracks.clear()
        endlessDiscoveriesSinceAnchorExpansion = 0
        showEndlessSearch(false)
        updateAutoButton()
        updateEndlessAction()
        updateControlLockUi()
        // Deliberately do not pause/seek either player: current music continues uninterrupted.
    }

    private fun stopEndlessForManualControl() {
        endlessSessionGeneration++
        quickSessionActive = false
        endlessActive = false
        endlessSeedMode = false
        autoEnabled = false
        controlsLocked = false
        pendingEndlessStart = false
        pendingEndlessStartIsA = null
        endlessDiscoveryJob?.cancel()
        endlessDiscoveryJob = null
        endlessLoadJobA?.cancel()
        endlessLoadJobB?.cancel()
        endlessLoadJobA = null
        endlessLoadJobB = null
        endlessQueued = null
        endlessWaitingFreeDeck = null
        endlessDeckHasPlayedA = false
        endlessDeckHasPlayedB = false
        endlessDeckStateA = EndlessDeckState.FREE
        endlessDeckStateB = EndlessDeckState.FREE
        endlessSeedProtectedA = false
        endlessSeedProtectedB = false
        endlessManualProtectedA = false
        endlessManualProtectedB = false
        endlessPendingNextUrlA = null
        endlessPendingNextUrlB = null
        endlessAddMode = false
        endlessManualUrls.clear()
        quickSceneOverride = null
        quickSessionAnchorTerms = ""
        quickSessionStyleTerms = ""
        quickLongFormDuration = false
        endlessSeeds.clear()
        endlessUsedUrls.clear()
        endlessUsedTrackKeys.clear()
        endlessSeedArtistKeys.clear()
        endlessNonSeedSelections = 0
        endlessPlayedAutoUrls.clear()
        endlessGenreProfile = EndlessGenreProfile.POP
        endlessSceneProfile = EndlessSceneProfile.GLOBAL
        endlessArtistOnlyMode = false
        endlessModeLocked = false
        endlessRecoveryDeck = null
        endlessArtistOnlySeed = null
        endlessArtistAllowLongTracks = false
        endlessArtistReplayQueue.clear()
        endlessRecent.clear()
        endlessRecentArtists.clear()
        endlessAnchorTracks.clear()
        endlessPendingAnchorTracks.clear()
        endlessDiscoveriesSinceAnchorExpansion = 0
        showEndlessSearch(false)
        updateAutoButton()
        updateEndlessAction()
        updateControlLockUi()
    }

    private fun onEndlessTransitionComplete(freedIsA: Boolean) {
        if (!endlessActive) return
        val nowPlaying = if (freedIsA) MixerStore.deckB else MixerStore.deckA
        nowPlaying?.let { markEndlessAutoPlayed(it) }

        // Crossfade completion is authoritative: an original seed is protected only until it
        // has actually had its first turn. Once that seed was the source of a completed fade,
        // release its reservation and reclaim the deck immediately.
        if (freedIsA) endlessSeedProtectedA = false else endlessSeedProtectedB = false

        // A manually added track is protected only until it has had its guaranteed turn.
        // Once it finishes as the source of a completed transition, release that protection
        // and allow the physical deck to become FREE for normal Endless discovery again.
        val finished = if (freedIsA) MixerStore.deckA else MixerStore.deckB
        if (finished?.url in endlessManualUrls) {
            finished?.url?.let { endlessManualUrls.remove(it) }
            if (freedIsA) endlessManualProtectedA = false else endlessManualProtectedB = false
        }
        freePausedEndlessDeck(freedIsA, force = true)
    }

    private fun isNextSelectionFrozen(targetIsA: Boolean, proposedUrl: String): Boolean {
        if (!endlessActive) return false
        val source = if (targetIsA) playerB else playerA
        if (!source.isPlaying) return false
        val remaining = remainingMs(source)
        if (remaining < 0L || remaining > endlessNextFreezeMs) return false

        // In the final 40 seconds, an already chosen NEXT is immutable.
        // This includes a candidate that is still resolving/loading. If no NEXT exists yet,
        // filling the empty deck is still allowed to protect continuity.
        val pendingUrl = if (targetIsA) endlessPendingNextUrlA else endlessPendingNextUrlB
        val state = if (targetIsA) endlessDeckStateA else endlessDeckStateB
        val loadedUrl = if (state == EndlessDeckState.LOADING_NEXT || state == EndlessDeckState.READY_NEXT) {
            if (targetIsA) MixerStore.deckA?.url else MixerStore.deckB?.url
        } else null
        val chosenUrl = pendingUrl ?: loadedUrl
        return chosenUrl != null && chosenUrl != proposedUrl
    }

    private fun loadEndlessTrackIntoDeck(isA: Boolean, track: TrackRef) {
        if (!endlessActive) return
        if (isNextSelectionFrozen(isA, track.url)) {
            // Keep the late candidate for a later slot; never swap NEXT inside the final 40 s.
            if (endlessQueued == null) endlessQueued = track
            return
        }
        // The currently audible deck is sacred until the configured mix-out window.
        // Discovery may prepare only the waiting/free deck; never overwrite a track that is playing.
        val targetPlayer = if (isA) playerA else playerB
        if (targetPlayer.isPlaying) {
            if (endlessQueued == null) endlessQueued = track
            return
        }
        val isManualTrack = track.url in endlessManualUrls
        if ((isA && endlessSeedProtectedA) || (!isA && endlessSeedProtectedB)) {
            endlessQueued = track
            return
        }
        // Manual ADD TO MIX is law for itself: once a user-selected track owns a NEXT deck,
        // no automatic candidate, rerank, refresh, recovery or late async result may replace it.
        // The only permitted write into a manually protected deck is that same manual track.
        val manualProtected = if (isA) endlessManualProtectedA else endlessManualProtectedB
        if (manualProtected && !isManualTrack) {
            if (endlessQueued == null) endlessQueued = track
            return
        }
        if (isManualTrack) {
            if (isA) endlessManualProtectedA = true else endlessManualProtectedB = true
        }
        val session = endlessSessionGeneration
        if (isA) {
            endlessPendingNextUrlA = track.url
            endlessDeckStateA = EndlessDeckState.LOADING_NEXT
        } else {
            endlessPendingNextUrlB = track.url
            endlessDeckStateB = EndlessDeckState.LOADING_NEXT
        }
        val job = lifecycleScope.launch {
            val resolved = withTimeoutOrNull(8_000L) {
                withContext(Dispatchers.IO) {
                    runCatching {
                        if (track.streamUrl != null) track
                        else track.copy(streamUrl = AudioResolver.resolveBestAudioUrl(track.url))
                    }.getOrNull()
                }
            }
            if (!endlessActive || session != endlessSessionGeneration) return@launch
            // Hard freeze: once the opposite/current song is inside its final 40 seconds,
            // a late async completion may commit only if it is still the chosen NEXT URL.
            val chosenPending = if (isA) endlessPendingNextUrlA else endlessPendingNextUrlB
            if (chosenPending != track.url || isNextSelectionFrozen(isA, track.url)) return@launch
            // A stale automatic load may have started before the user pressed ADD TO MIX.
            // Re-check protection after resolve so that late async completion can never overwrite
            // the user's manually inserted NEXT track or mark its deck FREE.
            val protectedNow = if (isA) endlessManualProtectedA else endlessManualProtectedB
            if (!isManualTrack && protectedNow) return@launch
            if (resolved == null) {
                if (isManualTrack) {
                    endlessManualUrls.remove(track.url)
                    if (isA) endlessManualProtectedA = false else endlessManualProtectedB = false
                }
                if (isA) {
                    endlessPendingNextUrlA = null
                    endlessDeckStateA = EndlessDeckState.FREE
                } else {
                    endlessPendingNextUrlB = null
                    endlessDeckStateB = EndlessDeckState.FREE
                }
                endlessWaitingFreeDeck = isA
                endlessQueued = null
                delay(500)
                if (session == endlessSessionGeneration) discoverQueuedCandidate()
                return@launch
            }

            if (isA) {
                MixerStore.setA(resolved)
                endlessPendingNextUrlA = null
            } else {
                MixerStore.setB(resolved)
                endlessPendingNextUrlB = null
            }
            endlessRecent.add(resolved)
            while (endlessRecent.size > 8) endlessRecent.removeAt(0)
            rememberEndlessArtist(resolved)
            endlessUsedTrackKeys.add(endlessTrackKey(resolved))
            refreshDecks()

            val direct = resolved.streamUrl ?: return@launch
            val key = resolved.url
            launch {
                delay(1_500)
                if (!endlessActive || session != endlessSessionGeneration) return@launch
                val intro = withContext(Dispatchers.IO) {
                    runCatching { WaveformAnalyzer.analyzeIntro(direct) }.getOrNull()
                } ?: return@launch
                val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                if (!endlessActive || session != endlessSessionGeneration || !sameTrack) return@launch
                if (isA) mixInMsA = maxOf(mixInMsA, intro.mixInMs)
                else mixInMsB = maxOf(mixInMsB, intro.mixInMs)
            }

            launch {
                delay(5_000)
                if (!endlessActive || session != endlessSessionGeneration) return@launch
                val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                if (sameTrack) analyzeWaveform(isA, resolved)
            }
        }
        if (isA) {
            endlessLoadJobA?.cancel()
            endlessLoadJobA = job
        } else {
            endlessLoadJobB?.cancel()
            endlessLoadJobB = job
        }
    }

    private fun discoverQueuedCandidate() {
        if (!endlessActive || endlessQueued != null || endlessDiscoveryJob?.isActive == true) return
        val session = endlessSessionGeneration

        // Artist-only mode: after the catalogue is exhausted, replay the two original
        // seeds in order, then begin a fresh pass through that artist's catalogue.
        if (endlessArtistOnlyMode && endlessArtistReplayQueue.isNotEmpty()) {
            val replay = endlessArtistReplayQueue.removeFirst()
            endlessUsedUrls.add(replay.url)
            endlessUsedTrackKeys.add(endlessTrackKey(replay))
            val waiting = endlessWaitingFreeDeck
            if (waiting != null) {
                endlessWaitingFreeDeck = null
                loadEndlessTrackIntoDeck(waiting, replay)
                discoverQueuedCandidate()
            } else {
                endlessQueued = replay
            }
            return
        }

        val queries = buildEndlessQueries()
        endlessDiscoveryJob = lifecycleScope.launch {
            // Continuity beats building a perfect global pool. Try seed-anchored queries one by
            // one and accept the first query that yields a candidate passing every hard guard.
            // Each query has a deadline so one wedged NewPipe fetch cannot own the pipeline forever.
            var candidate: TrackRef? = null
            for (query in queries.take(3)) {
                if (!endlessActive || session != endlessSessionGeneration || candidate != null) break
                val results = withTimeoutOrNull(6_000L) {
                    withContext(Dispatchers.IO) {
                        runCatching { searchRepo.search(query) }.getOrElse { emptyList() }
                    }
                } ?: emptyList()
                candidate = chooseEndlessCandidate(results)
            }

            // If the narrow seed-anchored pool is exhausted by hard filters, do NOT relax
            // region/genre/content guards. Broaden only the SEARCH wording so the engine can
            // escape a pool dominated by the two seed artists or recent/cooldown artists.
            if (candidate == null && !endlessArtistOnlyMode && endlessActive && session == endlessSessionGeneration) {
                for (query in buildEndlessFallbackQueries()) {
                    if (!endlessActive || session != endlessSessionGeneration || candidate != null) break
                    val results = withTimeoutOrNull(6_000L) {
                        withContext(Dispatchers.IO) {
                            runCatching { searchRepo.search(query) }.getOrElse { emptyList() }
                        }
                    } ?: emptyList()
                    candidate = chooseEndlessCandidate(results)
                }
            }
            if (session != endlessSessionGeneration) return@launch
            endlessDiscoveryJob = null
            if (!endlessActive) return@launch

            if (candidate == null) {
                if (endlessArtistOnlyMode && endlessSeeds.size >= 2) {
                    if (!endlessArtistAllowLongTracks) {
                        // First exhaust normal-length songs. Only then relax the 8-minute limit.
                        endlessArtistAllowLongTracks = true
                        discoverQueuedCandidate()
                    } else {
                        // The artist catalogue is exhausted even with long tracks allowed.
                        // Start a fresh artist-only cycle with the two original seeds first.
                        endlessArtistAllowLongTracks = false
                        endlessUsedUrls.clear()
                        endlessUsedTrackKeys.clear()
                        endlessRecentArtists.clear()
                        endlessArtistReplayQueue.clear()
                        endlessArtistReplayQueue.addLast(endlessSeeds[0])
                        endlessArtistReplayQueue.addLast(endlessSeeds[1])
                        discoverQueuedCandidate()
                    }
                } else {
                    delay(500)
                    discoverQueuedCandidate()
                }
                return@launch
            }

            endlessDiscoveriesSinceAnchorExpansion++
            maybePromoteEndlessAnchor()
            endlessUsedUrls.add(candidate.url)
            endlessUsedTrackKeys.add(endlessTrackKey(candidate))
            val waiting = endlessWaitingFreeDeck
            if (waiting != null) {
                endlessWaitingFreeDeck = null
                loadEndlessTrackIntoDeck(waiting, candidate)
                discoverQueuedCandidate()
            } else {
                endlessQueued = candidate
            }
        }
    }

    private fun buildEndlessQueries(): List<String> {
        val a = endlessSeeds.getOrNull(0) ?: return emptyList()
        val b = endlessSeeds.getOrNull(1) ?: return emptyList()
        val artistA = endlessArtistKey(a)
        val artistB = endlessArtistKey(b)

        if (endlessArtistOnlyMode) {
            val artist = endlessArtistKey(endlessArtistOnlySeed ?: a).ifBlank { artistA }
            return listOf(
                "$artist official audio",
                "$artist official music video",
                "$artist songs"
            ).map { it.trim() }.filter { it.isNotBlank() }.distinct()
        }

        val genreAnchor = if (quickSessionStyleTerms.isNotBlank()) {
            quickSessionStyleTerms
        } else when (endlessGenreProfile) {
            EndlessGenreProfile.POP -> "pop pop rock"
            EndlessGenreProfile.POP_FOLK -> "pop folk folk"
            EndlessGenreProfile.FOLK -> "folk pop folk"
        }
        val sceneAnchor = sceneSearchAnchor(endlessSceneProfile)
        val quickAnchor = quickSessionAnchorTerms

        // Progressive widening: the first two discoveries are STRICTLY tied to the original
        // two songs. Only after two candidate discoveries may a successfully PLAYED in-lane
        // auto track become an additional anchor. Then we run another two discoveries, promote
        // one more confirmed track, and repeat. Region/genre themselves never widen.
        val promoted = endlessAnchorTracks.drop(2).takeLast(3)
        val progressive = promoted.joinToString(" ") { t ->
            val artist = endlessArtistKey(t)
            val title = canonicalCompareText(t.title).take(80)
            "$artist $title"
        }
        val seedSongs = "${a.title} ${b.title}"
        return listOf(
            "$seedSongs $progressive $sceneAnchor $genreAnchor $quickAnchor similar songs official",
            "$artistA $artistB $progressive $sceneAnchor $genreAnchor $quickAnchor related artists music",
            "music like $seedSongs $progressive $sceneAnchor $genreAnchor $quickAnchor"
        ).map { it.trim().replace(Regex("\\s+"), " ") }.filter { it.isNotBlank() }.distinct()
    }

    private fun buildEndlessFallbackQueries(): List<String> {
        val genreAnchor = if (quickSessionStyleTerms.isNotBlank()) {
            quickSessionStyleTerms
        } else when (endlessGenreProfile) {
            EndlessGenreProfile.POP -> "pop pop rock"
            EndlessGenreProfile.POP_FOLK -> "pop folk folk"
            EndlessGenreProfile.FOLK -> "folk pop folk"
        }
        val sceneAnchor = sceneSearchAnchor(endlessSceneProfile)
        val quickAnchor = quickSessionAnchorTerms

        // No seed names here on purpose. The hard guards still enforce the locked scene/genre,
        // seed-artist block, recent-artist cooldown, used-track block and content rules.
        // This only widens discovery when seed-heavy result pages keep returning unusable items.
        val localSceneTerms = when (endlessSceneProfile) {
            EndlessSceneProfile.EX_YU -> listOf("ex yu muzika", "balkan muzika", "regionalni hitovi")
            EndlessSceneProfile.ITALIAN -> listOf("musica italiana", "canzoni italiane", "cantanti italiani", "italian pop hits")
            EndlessSceneProfile.FRANCOPHONE -> listOf("chanson francaise", "pop francais", "artistes francophones")
            EndlessSceneProfile.HISPANIC -> listOf("musica en espanol", "pop latino", "artistas latinos")
            EndlessSceneProfile.LUSOPHONE -> listOf("musica portuguesa", "musica brasileira", "pop portugues")
            EndlessSceneProfile.DACH -> listOf("deutsche musik", "deutsch pop", "german pop")
            EndlessSceneProfile.GREEK -> listOf("greek music", "ellinika tragoudia")
            EndlessSceneProfile.TURKISH -> listOf("turkce muzik", "turkish pop")
            EndlessSceneProfile.ARABIC -> listOf("arabic music", "arab pop")
            EndlessSceneProfile.SOUTH_ASIAN -> listOf("hindi music", "bollywood songs", "urdu pop")
            EndlessSceneProfile.EAST_SLAVIC -> listOf("russian music", "ukrainian music", "east slavic pop")
            EndlessSceneProfile.KOREAN -> listOf("korean music", "k pop")
            EndlessSceneProfile.JAPANESE -> listOf("japanese music", "j pop")
            EndlessSceneProfile.ANGLO -> listOf("english pop", "uk us pop", "english rock")
            EndlessSceneProfile.GLOBAL -> listOf("popular music")
        }
        val queries = mutableListOf(
            "$sceneAnchor $genreAnchor $quickAnchor official music",
            "$sceneAnchor $genreAnchor $quickAnchor popular songs official",
            "$sceneAnchor $genreAnchor $quickAnchor related artists music",
            "$sceneAnchor $genreAnchor $quickAnchor hits music video",
            "$sceneAnchor $genreAnchor $quickAnchor songs"
        )
        localSceneTerms.forEach { term ->
            queries += "$term $genreAnchor $quickAnchor official music"
            queries += "$term $genreAnchor $quickAnchor popular songs"
        }
        return queries.map { it.trim().replace(Regex("\\s+"), " ") }.filter { it.isNotBlank() }.distinct()
    }

    private fun chooseEndlessCandidate(items: List<TrackRef>): TrackRef? {
        val hardBlockedWords = listOf(
            "karaoke", "reaction", "tutorial", "full album", "playlist", "instrumental karaoke",
            "interview", "intervju", "podcast", "talk", "conversation", "gostovanje", "gost u",
            "emisija", "behind the scenes", "documentary", "dokumentar", "press conference", "press",
            "q&a", "q & a", "review", "recenzija", "priča", "prica", "razgovor",
            "radio interview", "tv interview", "radio emisija", "tv emisija", "dnevnik", "vesti", "vijesti",
            "news", "breaking", "reportaza", "reportaža", "podcast clip", "shorts interview"
        )
        val softPenaltyWords = listOf(
            "acoustic", "unplugged", "remix", "concert", "session",
            "sped up", "slowed", "nightcore", "extended", "edit", "remastered"
        )
        val artistOnlySeed = endlessArtistOnlySeed

        val candidates = items.mapIndexedNotNull { index, track ->
            val title = track.title.lowercase(Locale.getDefault())
            val artist = endlessArtistKey(track)
            val trackKey = endlessTrackKey(track)
            val correctArtistForArtistOnly = !endlessArtistOnlyMode ||
                (artistOnlySeed != null && isSameArtistFamily(artistOnlySeed, track))
            val seedArtistBlocked = !endlessArtistOnlyMode &&
                endlessNonSeedSelections < 5 &&
                isOriginalSeedArtist(track)
            val recentArtistBlocked = !endlessArtistOnlyMode && endlessRecent.takeLast(5).any { recentTrack ->
                isSameArtistFamily(recentTrack, track)
            }
            val consecutiveArtistBlocked = !endlessArtistOnlyMode && endlessRecent.lastOrNull()?.let { recentTrack ->
                isSameArtistFamily(recentTrack, track)
            } == true
            val durationAllowed = when {
                track.durationSeconds <= 0 -> true
                track.durationSeconds < 75 -> false
                endlessArtistOnlyMode && endlessArtistAllowLongTracks -> true
                else -> track.durationSeconds <= if (quickLongFormDuration) 1500 else 480
            }

            val uploaderText = track.uploader.lowercase(Locale.getDefault())
            val isLive = listOf(" live", "live ", "concert", "koncert", "unplugged").any { it in title }
            val isCover = listOf("cover", "tribute", "obrada").any { it in title }
            val looksOfficial = track.uploaderVerified || "official" in title || "official" in uploaderText || "vevo" in uploaderText || "topic" in uploaderText
            val narrativeNonSong = looksLikeNarrativeNonSong(track)
            val formatNonSong = looksLikeProgramOrCompilation(track)
            val wrongScene = !endlessArtistOnlyMode && violatesLockedScene(track)
            val wrongGenre = !endlessArtistOnlyMode && violatesLockedGenre(track)

            val passes = track.url !in endlessUsedUrls &&
                trackKey !in endlessUsedTrackKeys &&
                correctArtistForArtistOnly &&
                !recentArtistBlocked &&
                !consecutiveArtistBlocked &&
                !seedArtistBlocked &&
                durationAllowed &&
                hardBlockedWords.none { it in title } &&
                !narrativeNonSong &&
                !formatNonSong &&
                !wrongScene &&
                !wrongGenre &&
                (allowLive || !isLive) &&
                (allowCover || !isCover) &&
                (!onlyOfficial || looksOfficial)

            if (!passes) return@mapIndexedNotNull null

            // Ranking happens only AFTER every hard rule above has passed.
            // Search relevance matters, but popularity is deliberately logarithmic: 100M views
            // should beat 100k when all else is equal, without steamrolling a much better match.
            var score = 1000 - index * 5
            softPenaltyWords.forEach { word -> if (word in title) score -= 140 }
            if (allowLive && ("live" in title || "concert" in title || "koncert" in title)) score -= 70
            if (allowCover && ("cover" in title || "tribute" in title || "obrada" in title)) score -= 70

            val cleanSongShape = listOf(" - ", " – ", " — ").any { sep ->
                val pos = track.title.indexOf(sep)
                pos >= 2 && pos < track.title.length - sep.length - 1
            }
            if (cleanSongShape) score += 70
            if ("official audio" in title) score += 110
            if ("official video" in title) score += 85
            if ("vevo" in uploaderText || "topic" in uploaderText) score += 80
            if (track.uploaderVerified) score += 90
            if (track.durationSeconds in 150..330) score += 35

            if (track.viewCount > 0L) {
                val popularity = kotlin.math.log10(track.viewCount.toDouble().coerceAtLeast(1.0))
                score += (popularity * 55.0).roundToInt()
                if (track.viewCount >= 1_000_000L) score += 25
                if (track.viewCount >= 10_000_000L) score += 25
                if (track.viewCount >= 100_000_000L) score += 20
            }
            score to track
        }

        if (candidates.isEmpty()) return null
        val top = candidates.sortedByDescending { it.first }.take(4)
        // Keep a little variety, but make the highest-quality / highest-popularity result clearly
        // more likely than before. Hard filters still outrank popularity absolutely.
        val weights = listOf(60, 24, 11, 5).take(top.size)
        val roll = Random.nextInt(weights.sum())
        var cursor = 0
        for (i in top.indices) {
            cursor += weights[i]
            if (roll < cursor) return top[i].second
        }
        return top.first().second
    }

    private fun canonicalCompareText(text: String): String {
        val lowered = text.lowercase(Locale.ROOT)
            .replace("đ", "dj")
            .replace("ð", "d")
        val decomposed = Normalizer.normalize(lowered, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
        return decomposed
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun normalizeArtistText(text: String): String = canonicalCompareText(text)
        .replace(Regex("\\b(official|music|vevo|records|recordings|topic|channel|band|grupa)\\b"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()


    private fun titleSides(track: TrackRef): Set<String> {
        val separators = listOf(" - ", " – ", " — ", " | ")
        for (sep in separators) {
            val i = track.title.indexOf(sep)
            if (i > 0 && i + sep.length < track.title.length) {
                return setOf(
                    normalizeArtistText(track.title.substring(0, i)),
                    normalizeArtistText(track.title.substring(i + sep.length))
                ).filter { it.length >= 3 }.toSet()
            }
        }
        return emptySet()
    }

    private fun artistAliases(track: TrackRef): Set<String> {
        // Artist identity must never include the song-title side of "Artist - Song".
        return primaryArtistAliases(track).filter { alias ->
            alias.split(' ').any { it.length >= 3 }
        }.toSet()
    }

    private fun titleArtistPrefix(track: TrackRef): String {
        val separators = listOf(" - ", " – ", " — ", " | ")
        for (sep in separators) {
            val i = track.title.indexOf(sep)
            if (i > 0) return normalizeArtistText(track.title.substring(0, i))
        }
        return ""
    }

    private fun sameArtistConfidence(a: TrackRef, b: TrackRef): Boolean {
        // If both titles expose an "Artist - Song" prefix, trust that over uploader channels.
        // Two different performers on the same label/channel must never create artist-only mode.
        val prefixA = titleArtistPrefix(a)
        val prefixB = titleArtistPrefix(b)
        if (prefixA.length >= 3 && prefixB.length >= 3) {
            return prefixA == prefixB || prefixA.contains(prefixB) || prefixB.contains(prefixA)
        }

        val uploaderA = normalizeArtistText(a.uploader)
        val uploaderB = normalizeArtistText(b.uploader)
        val genericUploaderWords = listOf("records", "recordings", "label", "music", "channel", "topic", "official")
        val uploaderLooksGeneric = genericUploaderWords.any { it in uploaderA || it in uploaderB }
        if (!uploaderLooksGeneric && uploaderA.length >= 3 && uploaderB.length >= 3 && uploaderA == uploaderB) return true

        val aliasesA = artistAliases(a)
        val aliasesB = artistAliases(b)
        return aliasesA.any { aa ->
            aliasesB.any { bb ->
                aa.length >= 4 && bb.length >= 4 && (aa == bb || aa.contains(bb) || bb.contains(aa))
            }
        }
    }

    private fun isSameArtistFamily(seed: TrackRef, candidate: TrackRef): Boolean {
        val seedAliases = artistAliases(seed)
        val candidateAliases = artistAliases(candidate)
        if (seedAliases.any { sa -> candidateAliases.any { ca ->
                sa.length >= 4 && ca.length >= 4 && (sa == ca || sa.contains(ca) || ca.contains(sa))
            } }) return true

        val stop = setOf(
            "official", "music", "video", "audio", "lyrics", "lyric", "records", "recordings",
            "topic", "channel", "band", "grupa", "the", "and", "feat", "ft"
        )
        fun words(text: String): Set<String> = canonicalCompareText(text)
            .split(' ')
            .map { it.trim() }
            .filter { it.length >= 4 && it !in stop }
            .toSet()

        val seedArtistWords = words(endlessArtistKey(seed))
        if (seedArtistWords.isEmpty()) return false
        val candidateWords = words(endlessArtistKey(candidate)) + words(candidate.uploader) + words(candidate.title)
        return seedArtistWords.any { it in candidateWords }
    }

    private fun primaryArtistAliases(track: TrackRef): Set<String> {
        val aliases = linkedSetOf<String>()
        val uploader = normalizeArtistText(track.uploader)
        if (uploader.length >= 3) aliases += uploader
        val separators = listOf(" - ", " – ", " — ", " | ")
        for (sep in separators) {
            val i = track.title.indexOf(sep)
            if (i > 0) {
                val prefix = normalizeArtistText(track.title.substring(0, i))
                if (prefix.length >= 3) aliases += prefix
                break
            }
        }
        return aliases
    }

    private fun isOriginalSeedArtist(candidate: TrackRef): Boolean {
        val candidateTitle = canonicalCompareText(candidate.title)
        val candidateAliases = primaryArtistAliases(candidate)
        return endlessSeeds.take(2).any { seed ->
            val seedAliases = primaryArtistAliases(seed) + endlessArtistKey(seed)
            seedAliases.filter { it.length >= 3 }.any { seedAlias ->
                candidateAliases.any { ca ->
                    ca == seedAlias || ca.contains(seedAlias) || seedAlias.contains(ca)
                } || candidateTitle == seedAlias || candidateTitle.startsWith("$seedAlias ")
            }
        }
    }

    private fun markEndlessAutoPlayed(track: TrackRef) {
        if (!endlessActive) return
        if (endlessSeeds.take(2).any { seed -> seed.url == track.url }) return
        if (endlessPlayedAutoUrls.add(track.url)) {
            endlessNonSeedSelections++
            if (track.url in endlessManualUrls) return
            // Only a track that really played AND still passes the locked region/genre gates may
            // influence future discovery. A stray wrong-region result can never contaminate anchors.
            if (hasPositiveLockedSceneEvidence(track) && !violatesLockedGenre(track) &&
                endlessPendingAnchorTracks.none { it.url == track.url } &&
                endlessAnchorTracks.none { it.url == track.url }) {
                endlessPendingAnchorTracks.addLast(track)
            }
            maybePromoteEndlessAnchor()
        }
    }

    private fun maybePromoteEndlessAnchor() {
        if (endlessDiscoveriesSinceAnchorExpansion < 2) return
        val next = if (endlessPendingAnchorTracks.isEmpty()) return else endlessPendingAnchorTracks.removeFirst()
        if (hasPositiveLockedSceneEvidence(next) && !violatesLockedGenre(next)) {
            endlessAnchorTracks.add(next)
            while (endlessAnchorTracks.size > 7) endlessAnchorTracks.removeAt(2)
            endlessDiscoveriesSinceAnchorExpansion = 0
        }
    }

    private fun sceneSearchAnchor(scene: EndlessSceneProfile): String = when (scene) {
        EndlessSceneProfile.EX_YU -> "ex yu balkan"
        EndlessSceneProfile.ANGLO -> "english"
        EndlessSceneProfile.FRANCOPHONE -> "francophone french"
        EndlessSceneProfile.HISPANIC -> "spanish latin"
        EndlessSceneProfile.LUSOPHONE -> "portuguese brazil portugal"
        EndlessSceneProfile.DACH -> "german deutsch"
        EndlessSceneProfile.ITALIAN -> "italian italiano"
        EndlessSceneProfile.GREEK -> "greek"
        EndlessSceneProfile.TURKISH -> "turkish"
        EndlessSceneProfile.ARABIC -> "arabic"
        EndlessSceneProfile.SOUTH_ASIAN -> "hindi urdu indian"
        EndlessSceneProfile.EAST_SLAVIC -> "russian ukrainian"
        EndlessSceneProfile.KOREAN -> "korean"
        EndlessSceneProfile.JAPANESE -> "japanese"
        EndlessSceneProfile.GLOBAL -> ""
    }

    private fun classifyEndlessScene(a: TrackRef, b: TrackRef): EndlessSceneProfile {
        val sa = classifyTrackScene(a)
        val sb = classifyTrackScene(b)
        return when {
            sa == sb && sa != EndlessSceneProfile.GLOBAL -> sa
            sa == EndlessSceneProfile.GLOBAL -> sb
            sb == EndlessSceneProfile.GLOBAL -> sa
            else -> EndlessSceneProfile.GLOBAL
        }
    }

    private fun classifyTrackScene(track: TrackRef): EndlessSceneProfile {
        val raw = "${track.title} ${track.uploader}".lowercase(Locale.ROOT)
        val text = canonicalCompareText(raw)

        // Strong regional metadata/artist signals. This is intentionally used before the generic
        // lexical classifier so common EX-YU seeds with short titles still lock the correct basin.
        val strongSceneSignals = listOf(
            EndlessSceneProfile.EX_YU to listOf(
                "dino merlin", "dzenan loncarevic", "zeljko joksimovic", "tony cetinski", "lexington",
                "miligram", "colonia", "hari mata hari", "crvena jabuka", "bijelo dugme", "parni valjak",
                "zdravko colic", "severina", "gibonni", "petar graso", "aco pejovic", "sasa matic",
                "aleksandra prijovic", "lepa brena", "ceca", "barbara bobak", "andrijana cekic",
                "grand production", "croatia records", "idjvideos", "city records", "hayat production",
                "pgp rts", "jugoton", "diskoton"
            ),
            EndlessSceneProfile.ITALIAN to listOf(
                "eros ramazzotti", "toto cutugno", "laura pausini", "zucchero", "nek", "tiziano ferro",
                "gianna nannini", "umberto tozzi", "adriano celentano", "al bano", "romina power",
                "ricchi e poveri", "raffaella carra", "marco mengoni", "mahmood", "annalisa", "giorgia"
            ),
            EndlessSceneProfile.ANGLO to listOf(
                "bon jovi", "the calling", "coldplay", "blur", "oasis", "u2", "queen", "elton john",
                "ed sheeran", "dua lipa", "adele", "taylor swift", "bruno mars", "maroon 5", "the weeknd"
            ),
            EndlessSceneProfile.FRANCOPHONE to listOf(
                "stromae", "indila", "celine dion", "mylene farmer", "edith piaf", "joe dassin",
                "francis cabrel", "zaz", "kendji girac", "christophe mae"
            ),
            EndlessSceneProfile.HISPANIC to listOf(
                "shakira", "enrique iglesias", "luis miguel", "alejandro sanz", "maluma", "bad bunny",
                "karol g", "daddy yankee", "rosalia", "juan luis guerra"
            ),
            EndlessSceneProfile.LUSOPHONE to listOf(
                "roberto carlos", "mariza", "ana moura", "ivete sangalo", "jorge e mateus",
                "gusttavo lima", "marilia mendonca", "caetano veloso", "gilberto gil"
            ),
            EndlessSceneProfile.DACH to listOf(
                "herbert gronemeyer", "nena", "udo lindenberg", "helene fischer", "sarah connor",
                "mark forster", "peter maffay", "rammstein"
            ),
            EndlessSceneProfile.TURKISH to listOf(
                "tarkan", "sezen aksu", "mustafa sandal", "sertab erener", "hadise", "kenan dogulu"
            ),
            EndlessSceneProfile.GREEK to listOf(
                "anna vissi", "sakis rouvas", "despina vandi", "nikos vertis", "antonis remos"
            ),
            EndlessSceneProfile.ARABIC to listOf(
                "amr diab", "nancy ajram", "elissa", "ragheb alama", "kadim al sahir", "fairuz"
            ),
            EndlessSceneProfile.SOUTH_ASIAN to listOf(
                "arijit singh", "shreya ghoshal", "sonu nigam", "atif aslam", "neha kakkar", "badshah"
            ),
            EndlessSceneProfile.EAST_SLAVIC to listOf(
                "alla pugacheva", "dima bilan", "sergey lazarev", "ani lorak", "loboda", "monatik"
            ),
            EndlessSceneProfile.KOREAN to listOf(
                "bts", "blackpink", "twice", "exo", "iu", "newjeans", "stray kids"
            ),
            EndlessSceneProfile.JAPANESE to listOf(
                "hikaru utada", "ayumi hamasaki", "yoasobi", "kenshi yonezu", "arashi", "one ok rock"
            )
        )
        strongSceneSignals.firstOrNull { (_, signals) -> signals.any { it in text } }?.let { return it.first }
        if (Regex("[đć]").containsMatchIn(raw)) return EndlessSceneProfile.EX_YU

        fun score(words: List<String>): Int = words.count { w ->
            Regex("(^|\\s)${Regex.escape(w)}(\\s|$)").containsMatchIn(text)
        }

        // Script is a very strong signal and avoids trying to maintain a country database.
        if (Regex("[\\u3040-\\u30ff\\u31f0-\\u31ff]").containsMatchIn(raw)) return EndlessSceneProfile.JAPANESE
        if (Regex("[\\uac00-\\ud7af]").containsMatchIn(raw)) return EndlessSceneProfile.KOREAN
        if (Regex("[\\u0600-\\u06ff]").containsMatchIn(raw)) return EndlessSceneProfile.ARABIC
        if (Regex("[\\u0370-\\u03ff]").containsMatchIn(raw)) return EndlessSceneProfile.GREEK
        if (Regex("[\\u0900-\\u097f]").containsMatchIn(raw)) return EndlessSceneProfile.SOUTH_ASIAN

        val dictionaries = listOf(
            EndlessSceneProfile.EX_YU to listOf(
                "miligram", "bulevari", "ljubav", "srce", "sreca", "zivot", "noc", "moja", "moje", "moj",
                "tvoja", "tvoje", "tvoj", "dodji", "dodi", "pjesma", "pesma", "pjeva", "peva", "kafana",
                "samo", "tebe", "meni", "zelim", "volim", "nikad", "zauvijek", "zauvek", "balkan", "ex yu"
            ),
            EndlessSceneProfile.FRANCOPHONE to listOf(
                "amour", "chanson", "coeur", "avec", "pour", "sans", "toujours", "jamais", "mon", "ma", "mes", "toi", "moi", "dans", "une", "des"
            ),
            EndlessSceneProfile.HISPANIC to listOf(
                "amor", "corazon", "contigo", "quiero", "vida", "noche", "beso", "besame", "siempre", "nunca", "para", "conmigo", "cancion", "latino"
            ),
            EndlessSceneProfile.LUSOPHONE to listOf(
                "amor", "coracao", "voce", "saudade", "beijo", "noite", "vida", "meu", "minha", "brasil", "portugal", "sertanejo"
            ),
            EndlessSceneProfile.DACH to listOf(
                "liebe", "herz", "nacht", "leben", "immer", "niemals", "mein", "meine", "dein", "deine", "deutsch", "schlager"
            ),
            EndlessSceneProfile.ITALIAN to listOf(
                "amore", "cuore", "vita", "notte", "sempre", "mai", "mio", "mia", "tuo", "tua", "italiano", "canzone"
            ),
            EndlessSceneProfile.TURKISH to listOf(
                "ask", "aşk", "kalp", "gece", "hayat", "seni", "benim", "senin", "turk", "turkish"
            ),
            EndlessSceneProfile.EAST_SLAVIC to listOf(
                "любовь", "сердце", "песня", "ночь", "жизнь", "моя", "тебя", "россия", "украина", "russian", "ukrainian"
            ),
            EndlessSceneProfile.ANGLO to listOf(
                "girls", "boys", "love", "heart", "night", "baby", "forever", "never", "you", "your", "english", "uk", "british"
            )
        )

        var best = EndlessSceneProfile.GLOBAL
        var bestScore = 0
        for ((scene, words) in dictionaries) {
            val s = score(words)
            if (s > bestScore) {
                bestScore = s
                best = scene
            }
        }
        // Require two lexical hits so a single universal word such as "amor" cannot lock a scene.
        return if (bestScore >= 2) best else EndlessSceneProfile.GLOBAL
    }

    private fun hasPositiveLockedSceneEvidence(track: TrackRef): Boolean {
        if (endlessSceneProfile == EndlessSceneProfile.GLOBAL) return true
        val candidateScene = classifyTrackScene(track)
        if (candidateScene == endlessSceneProfile) return true
        if (candidateScene != EndlessSceneProfile.GLOBAL) return false

        // REGION IS CANON: fallback may broaden artists, never the language/scene basin.
        // An exact/family artist match to an already-confirmed in-lane anchor is valid positive
        // evidence; otherwise unknown metadata is rejected rather than guessed into the session.
        if (endlessAnchorTracks.any { isSameArtistFamily(it, track) }) return true

        val raw = "${track.title} ${track.uploader}".lowercase(Locale.ROOT)
        val text = canonicalCompareText(raw)
        val sceneLabels = when (endlessSceneProfile) {
            EndlessSceneProfile.ITALIAN -> listOf(
                "italia", "italian", "italiano", "italiana", "musica italiana", "canzone italiana",
                "warner music italy", "sony music italy", "universal music italia", "rai", "sanremo"
            )
            EndlessSceneProfile.FRANCOPHONE -> listOf("france", "francais", "francaise", "chanson francaise", "francophone")
            EndlessSceneProfile.HISPANIC -> listOf("latin", "latino", "latina", "espanol", "mexico", "argentina", "colombia", "spain")
            EndlessSceneProfile.LUSOPHONE -> listOf("brasil", "brazil", "portugal", "portugues", "portuguese")
            EndlessSceneProfile.DACH -> listOf("deutsch", "deutsche", "germany", "austria", "schweiz", "switzerland")
            EndlessSceneProfile.GREEK -> listOf("greek", "greece", "ellinika")
            EndlessSceneProfile.TURKISH -> listOf("turkish", "turkiye", "turkce")
            EndlessSceneProfile.ARABIC -> listOf("arabic", "arab", "middle east")
            EndlessSceneProfile.SOUTH_ASIAN -> listOf("hindi", "urdu", "bollywood", "india", "pakistan")
            EndlessSceneProfile.EAST_SLAVIC -> listOf("russian", "ukrainian", "russia", "ukraine")
            EndlessSceneProfile.KOREAN -> listOf("korean", "korea", "k-pop", "kpop")
            EndlessSceneProfile.JAPANESE -> listOf("japanese", "japan", "j-pop", "jpop")
            EndlessSceneProfile.ANGLO -> listOf("uk", "british", "usa", "american", "english")
            else -> emptyList()
        }
        if (sceneLabels.any { it in text }) return true

        if (endlessSceneProfile == EndlessSceneProfile.EX_YU) {
            if (Regex("[čćžšđ]").containsMatchIn(raw)) return true
            val regionalLabels = listOf(
                "croatia records", "grand production", "grand online", "idjvideos", "idj tunes",
                "city records", "hayat production", "bn music", "bn televizija", "pink music",
                "pgp rts", "jugoton", "diskoton", "sarajevo", "beograd", "belgrade", "zagreb",
                "podgorica", "split", "novi sad", "balkan", "ex yu"
            )
            if (regionalLabels.any { it in text }) return true
        }
        return false
    }

    private fun violatesLockedScene(track: TrackRef): Boolean = !hasPositiveLockedSceneEvidence(track)

    private fun classifyEndlessGenre(a: TrackRef, b: TrackRef): EndlessGenreProfile {
        val text = canonicalCompareText("${a.title} ${a.uploader} ${b.title} ${b.uploader}")
        val popFolkSignals = listOf(
            "pop folk", "folk pop", "popfolk", "cajka", "cajke", "turbofolk", "turbo folk",
            "miligram", "aco pejovic", "sasa matic", "tanja savic", "aleksandra prijovic", "ceca",
            "dragana mirkovic", "seka aleksic", "dara bubamara", "ana bekuta", "lepa brena"
        )
        val folkSignals = listOf(
            "folk", "narodna", "narodne", "narodni", "izvorna", "izvorne", "sevdah", "sevdalinka",
            "tambura", "tamburica", "kolo", "gusle", "ganga", "etno", "kafana", "kafanska"
        )
        return when {
            popFolkSignals.any { it in text } -> EndlessGenreProfile.POP_FOLK
            folkSignals.any { it in text } -> EndlessGenreProfile.FOLK
            else -> EndlessGenreProfile.POP
        }
    }

    private fun looksLikeNarrativeNonSong(track: TrackRef): Boolean {
        val text = canonicalCompareText(track.title)
        val narrativePhrases = listOf(
            "otkrio", "otkrila", "otkriva", "rekao", "rekla", "kaze", "kazao", "kazala",
            "govori", "govorio", "govorila", "pricao", "pricala", "prica o", "ispricao", "ispricala",
            "objasnio", "objasnila", "priznao", "priznala", "progovorio", "progovorila",
            "reveals", "revealed", "says", "said", "talks about", "speaks about", "explains",
            "admits", "confesses", "interview", "intervju", "gostovanje", "razgovor"
        )
        return narrativePhrases.any { phrase ->
            Regex("(^|\\s)${Regex.escape(phrase)}(\\s|$)").containsMatchIn(text)
        }
    }

    private fun looksLikeProgramOrCompilation(track: TrackRef): Boolean {
        // Global content-format guard: Endless Mix wants ONE SONG, not a quiz/show/playlist/mix package.
        // Canonical matching makes this work across accents (e.g. MUZIČKI -> muzicki).
        val text = canonicalCompareText("${track.title} ${track.uploader}")
        val exactFormats = listOf(
            "muzicki kviz", "music quiz", "quiz show", "kviz",
            "kompilacija", "compilation", "playlist", "plejlista",
            "top hits", "greatest hits", "best of", "hitovi", "najveci hitovi",
            "radio show", "radio emisija", "tv show", "tv emisija", "countdown",
            "non stop", "nonstop", "continuous mix", "full mix", "dj mix",
            "megamixt", "megamix", "medley", "mix compilation"
        )
        if (exactFormats.any { phrase ->
                Regex("(^|\\s)${Regex.escape(phrase)}(\\s|$)").containsMatchIn(text)
            }) return true

        // Numbered/best-of packages are especially common in QUICK searches and must never
        // masquerade as one long song (e.g. "Top 50 Ex Yu Rock Songs" or
        // "50 najboljih Ex-YU rock pesama").
        val numberedPackage = listOf(
            Regex("\\btop\\s+\\d{1,3}\\b"),
            Regex("\\b\\d{1,3}\\s+(najboljih|najbolje|najvecih|best)\\b"),
            Regex("\\b(best|top)\\s+(songs|pesama|pjesama|hitova|tracks)\\b"),
            Regex("\\b\\d{1,3}\\s+(songs|pesama|pjesama|hitova|tracks)\\b")
        ).any { it.containsMatchIn(text) }
        if (numberedPackage) return true

        // Generic MIX is ambiguous (a real song can be a remix), so reject it only when the
        // surrounding title clearly describes a package/era/collection rather than Artist - Song.
        val hasArtistSongShape = listOf(" - ", " – ", " — ").any { sep ->
            val i = track.title.indexOf(sep)
            i >= 2 && i < track.title.length - sep.length - 1
        }
        val packageSignals = listOf(
            "80", "90", "2000", "2020", "2021", "2022", "2023", "2024", "2025", "2026",
            "ex yu", "balkan mix", "summer mix", "party mix", "dance mix", "rock mix",
            "pop mix", "folk mix", "hour mix", "1 hour", "2 hour", "mix songs", "mix pesama", "mix pjesama"
        )
        return !hasArtistSongShape && " mix" in " $text " && packageSignals.any { it in text }
    }

    private fun violatesLockedGenre(track: TrackRef): Boolean {
        val text = canonicalCompareText("${track.title} ${track.uploader}")
        val folkLean = listOf(
            "folk", "narodna", "narodne", "narodni", "izvorna", "izvorne", "sevdah", "sevdalinka",
            "tambura", "tamburica", "gusle", "ganga", "kafana", "kafanska", "turbofolk", "turbo folk",
            "cajka", "cajke",
            // POP / POP-ROCK must not silently drift into folk just because a normal song title
            // contains no genre word. These are strong artist/uploader signals, not ranking hints.
            "aco pejovic", "sasa matic", "tanja savic", "aleksandra prijovic", "ceca",
            "dragana mirkovic", "seka aleksic", "dara bubamara", "ana bekuta", "lepa brena",
            "barbara bobak", "andrijana cekic", "mile kitic", "sinan sakic", "saban saulic",
            "halid beslic", "halid muslimovic", "haris dzinovic", "jana todorovic", "rasta folk"
        )
        val nationalistOrWar = listOf(
            "patriotska", "patriotske", "patriotic", "rodoljubiva", "rodoljubive", "rodoljubna",
            "nacionalisticka", "nacionalisticke", "nationalist", "nationalistic",
            "cetnik", "cetnici", "cetnicka", "ustasa", "ustase", "ustaska", "ratna pjesma", "ratne pjesme",
            "vojna pjesma", "vojne pjesme", "mars na", "bojna pjesma"
        )
        return when (endlessGenreProfile) {
            EndlessGenreProfile.POP -> folkLean.any { it in text } || nationalistOrWar.any { it in text }
            EndlessGenreProfile.POP_FOLK -> false // Friendly with FOLK by design.
            EndlessGenreProfile.FOLK -> false // Friendly with POP/FOLK by design.
        }
    }

    private fun rememberEndlessArtist(track: TrackRef) {
        val key = endlessArtistKey(track)
        if (key.isBlank()) return
        endlessRecentArtists.remove(key)
        endlessRecentArtists.add(key)
        while (endlessRecentArtists.size > 5) endlessRecentArtists.removeAt(0)
    }

    private fun endlessArtistKey(track: TrackRef): String {
        // Prefer the artist prefix from common "Artist - Song" titles. Comparison keys
        // are always Unicode-canonical so Ž/Z, accents and punctuation cannot bypass blocks.
        val separators = listOf(" - ", " – ", " — ", " | ")
        val titleArtist = separators
            .mapNotNull { sep ->
                val index = track.title.indexOf(sep)
                if (index > 0) track.title.substring(0, index) else null
            }
            .minByOrNull { it.length }
            .orEmpty()
        val normalizedTitleArtist = normalizeArtistText(titleArtist)
        if (normalizedTitleArtist.length >= 2) return normalizedTitleArtist

        return normalizeArtistText(track.uploader)
    }

    private fun endlessTrackKey(track: TrackRef): String {
        val separators = listOf(" - ", " – ", " — ", " | ")
        var songPart = track.title
        val uploader = normalizeArtistText(track.uploader)
        for (sep in separators) {
            val i = track.title.indexOf(sep)
            if (i > 0 && i + sep.length < track.title.length) {
                val leftRaw = track.title.substring(0, i)
                val rightRaw = track.title.substring(i + sep.length)
                val left = normalizeArtistText(leftRaw)
                val right = normalizeArtistText(rightRaw)
                songPart = when {
                    uploader.length >= 3 && (uploader.contains(left) || left.contains(uploader)) -> rightRaw
                    uploader.length >= 3 && (uploader.contains(right) || right.contains(uploader)) -> leftRaw
                    else -> rightRaw
                }
                break
            }
        }
        return songPart
            .lowercase(Locale.getDefault())
            .replace(Regex("\\([^)]*\\)|\\[[^]]*]"), " ")
            .replace(
                Regex("\\b(official|video|audio|lyrics|lyric|hd|hq|remastered|remaster|live|version|acoustic|unplugged|remix|mix|cover|concert|session|extended|edit|radio|sped|slowed|nightcore)\\b"),
                " "
            )
            .replace(Regex("\\b(19|20)\\d{2}\\b"), " ")
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .trim()
    }

    private fun updateEndlessFilterButtons() {
        fun style(button: Button, on: Boolean, label: String) {
            val color = if (on) R.color.orange_control else R.color.white
            button.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, color))
            button.setTextColor(ContextCompat.getColor(this, R.color.black))
            button.text = "$label ${if (on) "ON" else "OFF"}"
            button.isEnabled = !controlsLocked
        }
        style(binding.filterLive, allowLive, "LIVE")
        style(binding.filterCover, allowCover, "COVER")
        style(binding.filterOfficial, onlyOfficial, "ONLY OFFICIAL")
    }

    private fun requestEndlessVoiceSearch() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            launchSpeechRecognizer()
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun setupAudioFocusProtection() {
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setWillPauseWhenDucked(false)
            .setOnAudioFocusChangeListener { change ->
                when (change) {
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                        masterDuck = 0.35f
                        applyVolumes()
                    }
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                        resumeAAfterFocus = playerA.isPlaying
                        resumeBAfterFocus = playerB.isPlaying
                        masterDuck = 0.12f
                        applyVolumes()
                    }
                    AudioManager.AUDIOFOCUS_GAIN -> {
                        masterDuck = 1f
                        applyVolumes()
                        if (resumeAAfterFocus && !playerA.isPlaying && playerA.playbackState == Player.STATE_READY) playerA.play()
                        if (resumeBAfterFocus && !playerB.isPlaying && playerB.playbackState == Player.STATE_READY) playerB.play()
                        resumeAAfterFocus = false
                        resumeBAfterFocus = false
                    }
                    AudioManager.AUDIOFOCUS_LOSS -> {
                        resumeAAfterFocus = playerA.isPlaying
                        resumeBAfterFocus = playerB.isPlaying
                        masterDuck = 0.12f
                        applyVolumes()
                    }
                }
            }
            .build()
        audioManager.requestAudioFocus(audioFocusRequest)
    }

    private fun toggleControlLock() {
        if (!controlsLocked) {
            controlsLocked = true
            updateControlLockUi()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("ARE YOU SURE?")
            .setMessage("Unlock mixer controls?")
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("UNLOCK") { _, _ ->
                controlsLocked = false
                updateControlLockUi()
            }
            .show()
    }

    private fun requestAddToMix() {
        if (!endlessActive) return
        AlertDialog.Builder(this)
            .setTitle("ARE YOU SURE?")
            .setMessage("Add a song manually to the current Endless Mix?")
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("ADD TO MIX") { _, _ ->
                endlessAddMode = true
                showEndlessSearch(true)
                binding.endlessSearchInput.isEnabled = true
                binding.endlessSearchButton.isEnabled = true
                binding.endlessVoiceButton.isEnabled = true
                binding.endlessStatus.text = "Search a song to add to this mix"
                binding.endlessSearchInput.requestFocus()
            }
            .show()
    }

    private fun updateControlLockUi() {
        val lockedHardwareView = endlessActive && controlsLocked && !quickDrawerOpen && !endlessAddMode
        binding.lockedControlsPanel.visibility = if (lockedHardwareView) View.VISIBLE else View.GONE
        binding.endlessLockActionRow.visibility = if (endlessActive && !lockedHardwareView) View.VISIBLE else View.GONE
        binding.mixLock.visibility = View.VISIBLE
        binding.addToMix.visibility = View.VISIBLE
        binding.addToMix.isEnabled = endlessActive
        binding.lockText.text = if (controlsLocked) "UNLOCK" else "LOCK"
        binding.lockText.setTextColor(ContextCompat.getColor(this, if (controlsLocked) R.color.white else R.color.black))
        binding.lockIcon.setImageResource(if (controlsLocked) R.drawable.ic_lock_closed else R.drawable.ic_lock_open)
        binding.mixLock.setBackgroundColor(ContextCompat.getColor(this, if (controlsLocked) R.color.red_control else R.color.green_control))

        if (lockedHardwareView) {
            binding.endlessAction.visibility = View.GONE
            binding.endlessFilterRow.visibility = View.GONE
            binding.quickEndlessButton.visibility = View.VISIBLE
        } else if (!quickDrawerOpen && !endlessAddMode) {
            binding.endlessAction.visibility = View.VISIBLE
            binding.endlessFilterRow.visibility = View.VISIBLE
            binding.quickEndlessButton.visibility = View.VISIBLE
        }

        binding.playA.isEnabled = !controlsLocked && playerA.mediaItemCount > 0
        binding.playB.isEnabled = !controlsLocked && playerB.mediaItemCount > 0
        binding.autoMix.isEnabled = !controlsLocked
        binding.crossfader.isEnabled = !controlsLocked
        binding.volumeA.isEnabled = !controlsLocked
        binding.volumeB.isEnabled = !controlsLocked
        binding.masterVolume.isEnabled = true
        binding.masterVolumeIcon.alpha = 1f
        binding.masterMute.isEnabled = true
        binding.masterMute.alpha = 1f
        binding.waveA.isEnabled = !controlsLocked
        binding.waveB.isEnabled = !controlsLocked
        binding.endlessAction.isEnabled = !controlsLocked
        val addSearchAllowed = endlessActive && endlessAddMode
        binding.endlessSearchInput.isEnabled = !controlsLocked || addSearchAllowed
        binding.endlessSearchButton.isEnabled = !controlsLocked || addSearchAllowed
        binding.endlessVoiceButton.isEnabled = !controlsLocked || addSearchAllowed
        updateEndlessFilterButtons()
        updateLoadButtons()
    }

    private fun setupQuickEndlessUi() {
        binding.lockedAddToMix.setOnClickListener { requestAddToMix() }
        binding.lockedUnlock.setOnClickListener { toggleControlLock() }
        binding.quickEndlessButton.setOnClickListener {
            if (controlsLocked && !quickDrawerOpen) {
                AlertDialog.Builder(this)
                    .setTitle("ARE YOU SURE?")
                    .setMessage("Open Quick Endless Mix while controls are locked?")
                    .setNegativeButton("CANCEL", null)
                    .setPositiveButton("QUICK MIX") { _, _ -> openQuickDrawer() }
                    .show()
            } else {
                if (quickDrawerOpen) closeQuickDrawer() else openQuickDrawer()
            }
        }
        binding.quickDrawerEnter.setOnClickListener {
            if (quickRegions.isEmpty() && quickEras.isEmpty() && quickStyles.isEmpty() && quickVenuePreset == null) closeQuickDrawer()
            else startQuickEndlessMix()
        }
        binding.quickDrawerReset.setOnClickListener {
            resetQuickSelections()
        }

        val regionPale = "#B9D9F2"
        val regionStrong = "#FF0000"
        val eraPale = "#F2DEAD"
        val eraStrong = "#FF0000"
        val stylePale = "#BFE6CD"
        val styleStrong = "#FF0000"

        bindQuickVenuePreset(binding.quickVenueHotel, "hotel")
        bindQuickVenuePreset(binding.quickVenueRestaurant, "restaurant")
        bindQuickVenuePreset(binding.quickVenueCaffeBar, "caffe bar")
        bindQuickVenuePreset(binding.quickVenueClub, "club")

        bindQuickChoice(binding.quickRegionExYu, quickRegions, "ex yu", regionPale, regionStrong)
        bindQuickChoice(binding.quickRegionItaly, quickRegions, "italian", regionPale, regionStrong)
        bindQuickChoice(binding.quickRegionLatin, quickRegions, "latin", regionPale, regionStrong)
        bindQuickChoice(binding.quickRegionAnglo, quickRegions, "english uk us", regionPale, regionStrong)
        bindQuickChoice(binding.quickRegionFrance, quickRegions, "french francophone", regionPale, regionStrong)
        bindQuickChoice(binding.quickRegionDach, quickRegions, "german dach", regionPale, regionStrong)
        bindQuickChoice(binding.quickRegionTurkey, quickRegions, "turkish", regionPale, regionStrong)
        bindQuickChoice(binding.quickRegionArabic, quickRegions, "arabic", regionPale, regionStrong)
        bindQuickChoice(binding.quickRegionBrazil, quickRegions, "brazilian portuguese", regionPale, regionStrong)
        bindQuickChoice(binding.quickRegionJapan, quickRegions, "japanese", regionPale, regionStrong)
        bindQuickChoice(binding.quickRegionKorea, quickRegions, "korean", regionPale, regionStrong)

        bindQuickChoice(binding.quickEraEvergreen, quickEras, "evergreen classics", eraPale, eraStrong)
        bindQuickChoice(binding.quickEra70, quickEras, "1970s", eraPale, eraStrong)
        bindQuickChoice(binding.quickEra80, quickEras, "1980s", eraPale, eraStrong)
        bindQuickChoice(binding.quickEra90, quickEras, "1990s", eraPale, eraStrong)
        bindQuickChoice(binding.quickEra2000, quickEras, "2000s", eraPale, eraStrong)
        bindQuickChoice(binding.quickEra2010, quickEras, "2010s", eraPale, eraStrong)
        bindQuickChoice(binding.quickEra2020, quickEras, "2020s", eraPale, eraStrong)

        bindQuickChoice(binding.quickStylePop, quickStyles, "pop", stylePale, styleStrong)
        bindQuickChoice(binding.quickStylePopFolk, quickStyles, "pop folk", stylePale, styleStrong)
        bindQuickChoice(binding.quickStyleFolk, quickStyles, "folk", stylePale, styleStrong)
        bindQuickChoice(binding.quickStyleRock, quickStyles, "rock", stylePale, styleStrong)
        bindQuickChoice(binding.quickStyleHardRock, quickStyles, "hard rock", stylePale, styleStrong)
        bindQuickChoice(binding.quickStyleDance, quickStyles, "dance", stylePale, styleStrong)
        bindQuickChoice(binding.quickStyleHouse, quickStyles, "house", stylePale, styleStrong)
        bindQuickChoice(binding.quickStyleTechno, quickStyles, "techno", stylePale, styleStrong)
        bindQuickChoice(binding.quickStyleLounge, quickStyles, "lounge", stylePale, styleStrong)
        bindQuickChoice(binding.quickStyleJazz, quickStyles, "jazz", stylePale, styleStrong)
        bindQuickChoice(binding.quickStyleInstrumental, quickStyles, "instrumental", stylePale, styleStrong)
        bindQuickChoice(binding.quickStylePiano, quickStyles, "solo piano instrumental", stylePale, styleStrong)
        bindQuickChoice(binding.quickStyleClassic, quickStyles, "classical music", stylePale, styleStrong)
        bindQuickChoice(binding.quickStyleCountry, quickStyles, "country", stylePale, styleStrong)
        bindQuickChoice(binding.quickStyleSoul, quickStyles, "soul", stylePale, styleStrong)
        bindQuickChoice(binding.quickStyleRap, quickStyles, "rap", stylePale, styleStrong)
        bindQuickChoice(binding.quickStyleHipHop, quickStyles, "hip hop", stylePale, styleStrong)
        updateQuickVenueUi()
        updateQuickEnterUi()
    }

    private fun bindQuickVenuePreset(button: Button, value: String) {
        button.setOnClickListener {
            if (quickVenuePreset == value) {
                quickVenuePreset = null
            } else if (quickVenuePreset == null) {
                quickVenuePreset = value
            }
            updateQuickVenueUi()
            updateQuickEnterUi()
        }
    }

    private fun updateQuickVenueUi() {
        val buttons = listOf(
            binding.quickVenueHotel to "hotel",
            binding.quickVenueRestaurant to "restaurant",
            binding.quickVenueCaffeBar to "caffe bar",
            binding.quickVenueClub to "club"
        )
        val selected = quickVenuePreset
        buttons.forEach { (button, value) ->
            val isSelected = selected == value
            button.isEnabled = selected == null || isSelected
            button.alpha = if (selected != null && !isSelected) 0.42f else 1f
            button.backgroundTintList = ColorStateList.valueOf(
                android.graphics.Color.parseColor(if (isSelected) "#FF0000" else "#E6E6E6")
            )
            button.setTextColor(android.graphics.Color.parseColor(if (isSelected) "#FFFFFF" else "#000000"))
        }
    }

    private fun bindQuickChoice(button: Button, set: MutableSet<String>, value: String, pale: String, strong: String) {
        fun paint() {
            val color = if (value in set) strong else pale
            button.backgroundTintList = ColorStateList.valueOf(android.graphics.Color.parseColor(color))
        }
        paint()
        button.setOnClickListener {
            if (value in set) set.remove(value) else set.add(value)
            paint()
            updateQuickEnterUi()
        }
    }

    private fun updateQuickEnterUi() {
        val hasAny = quickRegions.isNotEmpty() || quickEras.isNotEmpty() || quickStyles.isNotEmpty() || quickVenuePreset != null
        binding.quickDrawerEnter.text = if (hasAny) "ENTER" else "▼"
        binding.quickDrawerEnter.backgroundTintList = ColorStateList.valueOf(
            android.graphics.Color.parseColor(if (hasAny) "#D8D8D8" else "#202020")
        )
        binding.quickDrawerEnter.setTextColor(
            android.graphics.Color.parseColor(if (hasAny) "#000000" else "#FFFFFF")
        )
    }

    private fun resetQuickSelections() {
        quickRegions.clear()
        quickStyles.clear()
        quickEras.clear()
        quickVenuePreset = null
        val buttons = listOf(
            binding.quickRegionExYu, binding.quickRegionItaly, binding.quickRegionLatin, binding.quickRegionAnglo,
            binding.quickRegionFrance, binding.quickRegionDach, binding.quickRegionTurkey, binding.quickRegionArabic,
            binding.quickRegionBrazil, binding.quickRegionJapan, binding.quickRegionKorea,
            binding.quickStylePop, binding.quickStylePopFolk, binding.quickStyleFolk, binding.quickStyleRock,
            binding.quickStyleHardRock, binding.quickStyleDance, binding.quickStyleHouse, binding.quickStyleTechno,
            binding.quickStyleLounge, binding.quickStyleJazz, binding.quickStyleInstrumental, binding.quickStylePiano,
            binding.quickStyleClassic, binding.quickStyleCountry, binding.quickStyleSoul, binding.quickStyleRap,
            binding.quickStyleHipHop,
            binding.quickEraEvergreen, binding.quickEra70, binding.quickEra80, binding.quickEra90,
            binding.quickEra2000, binding.quickEra2010, binding.quickEra2020
        )
        // Rebuild the standard pale row colors.
        listOf(binding.quickRegionExYu, binding.quickRegionItaly, binding.quickRegionLatin, binding.quickRegionAnglo,
            binding.quickRegionFrance, binding.quickRegionDach, binding.quickRegionTurkey, binding.quickRegionArabic,
            binding.quickRegionBrazil, binding.quickRegionJapan, binding.quickRegionKorea).forEach {
            it.backgroundTintList = ColorStateList.valueOf(android.graphics.Color.parseColor("#B9D9F2"))
        }
        listOf(binding.quickStylePop, binding.quickStylePopFolk, binding.quickStyleFolk, binding.quickStyleRock,
            binding.quickStyleHardRock, binding.quickStyleDance, binding.quickStyleHouse, binding.quickStyleTechno,
            binding.quickStyleLounge, binding.quickStyleJazz, binding.quickStyleInstrumental, binding.quickStylePiano,
            binding.quickStyleClassic, binding.quickStyleCountry, binding.quickStyleSoul, binding.quickStyleRap,
            binding.quickStyleHipHop).forEach {
            it.backgroundTintList = ColorStateList.valueOf(android.graphics.Color.parseColor("#BFE6CD"))
        }
        listOf(binding.quickEraEvergreen, binding.quickEra70, binding.quickEra80, binding.quickEra90,
            binding.quickEra2000, binding.quickEra2010, binding.quickEra2020).forEach {
            it.backgroundTintList = ColorStateList.valueOf(android.graphics.Color.parseColor("#F2DEAD"))
        }
        updateQuickVenueUi()
        updateQuickEnterUi()
    }

    private fun quickAllowsLongForm(): Boolean {
        if (quickStyles.isEmpty()) return false
        val allowed = setOf("lounge", "jazz", "instrumental", "only piano", "classic")
        return quickStyles.all { style -> allowed.any { token -> style.contains(token) } }
    }

    private fun openQuickDrawer() {
        if (endlessAddMode) return
        quickDrawerOpen = true
        // QUICK MIX becomes a full lower hardware drawer: from the bottom edge up to the crossfader.
        binding.endlessAction.visibility = View.GONE
        binding.endlessLockActionRow.visibility = View.GONE
        binding.lockedControlsPanel.visibility = View.GONE
        binding.endlessFilterRow.visibility = View.GONE
        binding.endlessSearchPanel.visibility = View.GONE
        binding.endlessLowerSpacer.visibility = View.GONE
        binding.quickEndlessButton.visibility = View.GONE
        binding.quickSearchingRow.visibility = View.GONE
        binding.quickDrawer.visibility = View.VISIBLE
        binding.quickDrawer.alpha = 0f
        binding.quickDrawer.translationY = 180f
        binding.quickDrawer.animate().alpha(1f).translationY(0f).setDuration(180L).start()
    }

    private fun closeQuickDrawer() {
        quickDrawerOpen = false
        binding.quickSearchingRow.visibility = View.GONE
        binding.quickDrawerEnter.isEnabled = true
        binding.quickDrawer.visibility = View.GONE
        binding.quickDrawer.translationY = 0f
        binding.endlessAction.visibility = View.VISIBLE
        binding.endlessFilterRow.visibility = View.VISIBLE
        binding.quickEndlessButton.visibility = View.VISIBLE
        binding.endlessSearchPanel.visibility = View.GONE
        binding.endlessLowerSpacer.visibility = View.VISIBLE
        updateEndlessAction()
        updateControlLockUi()
    }

    private fun quickVenueStyleTerms(): String = when (quickVenuePreset) {
        "hotel" -> "lounge soft pop soul jazz instrumental elegant background music"
        "restaurant" -> "soft pop soul jazz acoustic lounge melodic dinner music"
        "caffe bar" -> "pop pop rock soul funk dance upbeat popular hits"
        "club" -> "dance house techno hip hop rap club hits high energy"
        else -> ""
    }

    /**
     * One-touch venue presets still obey the session hard-region DNA. If the user has not
     * explicitly touched REGION, choose exactly one default scene for the whole session using
     * the agreed 6:2:1 weighting: ANGLO 66.7%, LATINO 22.2%, ITALO 11.1%.
     */
    private fun chooseVenueDefaultRegion(): String {
        return when (Random.nextInt(9)) {
            in 0..5 -> "english uk us"
            in 6..7 -> "latin"
            else -> "italian"
        }
    }

    private fun sceneForQuickRegion(region: String): EndlessSceneProfile? = when (region) {
        "ex yu" -> EndlessSceneProfile.EX_YU
        "italian" -> EndlessSceneProfile.ITALIAN
        "latin" -> EndlessSceneProfile.HISPANIC
        "english uk us" -> EndlessSceneProfile.ANGLO
        "french francophone" -> EndlessSceneProfile.FRANCOPHONE
        "german dach" -> EndlessSceneProfile.DACH
        "turkish" -> EndlessSceneProfile.TURKISH
        "arabic" -> EndlessSceneProfile.ARABIC
        "brazilian portuguese" -> EndlessSceneProfile.LUSOPHONE
        "japanese" -> EndlessSceneProfile.JAPANESE
        "korean" -> EndlessSceneProfile.KOREAN
        else -> null
    }

    private fun selectedQuickSceneOverride(): EndlessSceneProfile? {
        if (quickRegions.size != 1) return null
        return sceneForQuickRegion(quickRegions.first())
    }

    private fun startQuickEndlessMix() {
        // Lower REGION is an explicit user override. Otherwise a one-touch VENUE preset chooses
        // one hard scene for this session with the default 6:2:1 ANGLO/LATINO/ITALO weighting.
        val venueDefaultRegion = if (quickVenuePreset != null && quickRegions.isEmpty()) chooseVenueDefaultRegion() else null
        val effectiveRegions = if (quickRegions.isNotEmpty()) quickRegions.toList() else listOfNotNull(venueDefaultRegion)
        val venueTerms = quickVenueStyleTerms()
        val terms = (effectiveRegions + quickStyles + quickEras + listOfNotNull(quickVenuePreset, venueTerms.takeIf { it.isNotBlank() }))
            .joinToString(" ").replace(Regex("\\s+"), " ").trim()
        if (terms.isBlank()) return
        val sceneOverride = if (quickRegions.isNotEmpty()) selectedQuickSceneOverride() else venueDefaultRegion?.let(::sceneForQuickRegion)
        quickStartJob?.cancel()
        quickStartJob = lifecycleScope.launch {
            // Keep the drawer visible and show a real indeterminate wait state. QUICK is allowed
            // to keep discovering until two usable starters are actually ready.
            binding.quickDrawerEnter.isEnabled = false
            binding.quickSearchingRow.visibility = View.VISIBLE
            binding.quickSearchingText.text = "SEARCHING…"
            if (endlessActive) stopEndlessMix()
            // stopEndlessMix() restores normal lower controls; keep QUICK as the only lower drawer
            // while its discovery spinner is running.
            binding.endlessAction.visibility = View.GONE
            binding.endlessLockActionRow.visibility = View.GONE
            binding.endlessFilterRow.visibility = View.GONE
            binding.endlessSearchPanel.visibility = View.GONE
            binding.endlessLowerSpacer.visibility = View.GONE
            binding.quickEndlessButton.visibility = View.GONE
            binding.quickDrawer.visibility = View.VISIBLE

            val queryVariants = linkedSetOf<String>().apply {
                add("$terms official music songs")
                add("$terms popular songs official")
                add("$terms official music video")
                add("$terms official audio track")
                add("$terms artists songs")
                if (quickStyles.isNotEmpty()) {
                    val styles = quickStyles.joinToString(" ")
                    add("$styles $terms music official")
                    add("$styles popular tracks $terms")
                }
                if (effectiveRegions.isNotEmpty()) {
                    val regions = effectiveRegions.joinToString(" ")
                    add("$regions $terms popular music")
                    add("$regions $terms official songs")
                }
            }.map { it.replace(Regex("\\s+"), " ").trim() }

            val pool = mutableListOf<TrackRef>()
            val quickMaxSeconds = if (quickAllowsLongForm()) 1500 else 480
            val targetStarterPoolSize = 50
            val minimumSearchPassesBeforePick = queryVariants.size * 2
            var attempt = 0
            var found: List<TrackRef> = emptyList()
            while (isActive && found.size < 2) {
                val base = queryVariants[attempt % queryVariants.size]
                val cycle = attempt / queryVariants.size
                val query = when (cycle % 4) {
                    1 -> "$base popular"
                    2 -> "$base related"
                    3 -> "$base hits"
                    else -> base
                }
                val batch = withTimeoutOrNull(8_000L) {
                    withContext(Dispatchers.IO) {
                        runCatching { searchRepo.search(query) }.getOrDefault(emptyList())
                    }
                }.orEmpty()

                pool += batch.filter { t ->
                    t.durationSeconds <= 0 || t.durationSeconds in 75..quickMaxSeconds
                }.filter { t -> quickStarterPassesHardGuards(t, sceneOverride) }

                val rankedValidPool = pool
                    .distinctBy { endlessTrackKey(it) }
                    .sortedByDescending { t ->
                        // Quality/popularity decides who gets INTO the candidate pool. It does not
                        // deterministically decide the two starters anymore.
                        val views = kotlin.math.ln(1.0 + t.viewCount.coerceAtLeast(0L).toDouble())
                        views +
                            (if (t.uploaderVerified) 3.0 else 0.0) +
                            (if ("official" in t.title.lowercase(Locale.getDefault())) 2.0 else 0.0)
                    }
                    .take(targetStarterPoolSize)

                attempt++
                val enoughVariety = rankedValidPool.size >= targetStarterPoolSize
                val enoughSearchCoverage = attempt >= minimumSearchPassesBeforePick && rankedValidPool.size >= 2
                if (enoughVariety || enoughSearchCoverage) {
                    val shuffled = rankedValidPool.shuffled(Random.Default)
                    val first = shuffled.first()
                    val second = shuffled.drop(1).firstOrNull { !isSameArtistFamily(first, it) }
                        ?: shuffled.drop(1).firstOrNull()
                    if (second != null) found = listOf(first, second)
                }

                if (found.size < 2) {
                    if (attempt % queryVariants.size == 0) {
                        binding.quickSearchingText.text = "STILL SEARCHING… ${rankedValidPool.size}/$targetStarterPoolSize"
                    }
                    delay(300L)
                }
            }

            if (!isActive || found.size < 2) return@launch

            quickSceneOverride = sceneOverride
            quickSessionAnchorTerms = terms
            quickSessionStyleTerms = if (quickStyles.isNotEmpty()) quickStyles.joinToString(" ") else venueTerms
            quickLongFormDuration = quickAllowsLongForm()
            quickSessionActive = true
            MixerStore.setA(found[0])
            MixerStore.setB(found[1])
            refreshDecks(force = true)

            binding.quickSearchingText.text = "LOADING…"
            // Playback preparation has its own bounded wait, but a slow prepare does not throw away
            // the successfully discovered pair. The user sees the hardware wait state until ready.
            while (isActive && (playerA.mediaItemCount == 0 || playerB.mediaItemCount == 0)) {
                delay(100L)
            }
            if (!isActive) return@launch

            syncSeedsFromCurrentDecks()
            closeQuickDrawer()
            startEndlessMix()
        }
    }


    private fun quickStarterPassesHardGuards(track: TrackRef, sceneOverride: EndlessSceneProfile?): Boolean {
        if (looksLikeNarrativeNonSong(track) || looksLikeProgramOrCompilation(track)) return false
        val text = canonicalCompareText("${track.title} ${track.uploader}")
        val hardBlockedWords = listOf(
            "karaoke", "reaction", "tutorial", "full album", "playlist", "instrumental karaoke",
            "interview", "intervju", "podcast", "talk", "conversation", "gostovanje", "gost u",
            "emisija", "behind the scenes", "documentary", "dokumentar", "press conference",
            "q a", "review", "recenzija", "razgovor", "radio emisija", "tv emisija", "dnevnik",
            "vesti", "vijesti", "news", "breaking", "reportaza", "reportaža"
        )
        if (hardBlockedWords.any { it in text }) return false

        // QUICK REGION is a hard gate exactly like Endless region DNA. Unknown/global evidence is
        // rejected when a concrete region was selected; it may not sneak through on popularity.
        if (sceneOverride != null) {
            val candidateScene = classifyTrackScene(track)
            if (candidateScene != sceneOverride) return false
        }

        // Reuse the Endless POP/POP-FOLK/FOLK hard genre behavior for starter selection too.
        // Other QUICK style tokens remain search constraints and become the seed DNA once started.
        val selected = quickStyles.map { canonicalCompareText(it) }
        if (selected.isNotEmpty()) {
            val oldProfile = endlessGenreProfile
            val profile = when {
                selected.any { it == "folk" } && selected.none { "pop folk" in it } -> EndlessGenreProfile.FOLK
                selected.any { "pop folk" in it } -> EndlessGenreProfile.POP_FOLK
                selected.any { it == "pop" || it == "rock" || it == "hard rock" } -> EndlessGenreProfile.POP
                else -> null
            }
            if (profile != null) {
                endlessGenreProfile = profile
                val rejected = violatesLockedGenre(track)
                endlessGenreProfile = oldProfile
                if (rejected) return false
            }
        }
        return true
    }

    private fun launchSpeechRecognizer() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Search music")
        }
        runCatching { speechLauncher.launch(intent) }
            .onFailure { binding.endlessStatus.text = "Voice search unavailable" }
    }

    private fun formatTime(ms: Long): String {
        val total = (ms / 1000L).coerceAtLeast(0L)
        val m = total / 60
        val s = total % 60
        return "%d:%02d".format(m, s)
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized) {
            refreshDecks()
            if (!endlessActive && !endlessSeedMode) syncSeedsFromCurrentDecks()
        }
    }

    override fun onDestroy() {
        autoFadeJob?.cancel()
        endlessDiscoveryJob?.cancel()
        if (::audioFocusRequest.isInitialized) audioManager.abandonAudioFocusRequest(audioFocusRequest)
        playerA.release()
        playerB.release()
        super.onDestroy()
    }
}
