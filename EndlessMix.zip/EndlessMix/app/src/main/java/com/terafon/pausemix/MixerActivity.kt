package com.terafon.pausemix

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.media.AudioManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.recyclerview.widget.LinearLayoutManager
import com.terafon.pausemix.databinding.ActivityMixerBinding
import com.terafon.pausemix.model.MixerStore
import com.terafon.pausemix.model.TrackRef
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.text.Normalizer
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.random.Random

class MixerActivity : AppCompatActivity() {
    private enum class EndlessGenreProfile { POP, POP_FOLK, FOLK }
    private enum class EndlessDeckState { FREE, LOADING_NEXT, READY_NEXT, PLAYING }
    private enum class EndlessSceneProfile {
        GLOBAL, EX_YU, ANGLO, FRANCOPHONE, HISPANIC, LUSOPHONE, DACH, ITALIAN,
        GREEK, TURKISH, ARABIC, SOUTH_ASIAN, EAST_SLAVIC, KOREAN, JAPANESE
    }

    private lateinit var binding: ActivityMixerBinding
    private lateinit var playerA: ExoPlayer
    private lateinit var playerB: ExoPlayer
    private lateinit var endlessAdapter: SearchAdapter

    private val searchRepo = SearchRepository()

    private var userVolA = 1f
    private var userVolB = 1f
    private var measuredRmsA: Float? = null
    private var measuredRmsB: Float? = null
    private val loudnessTargetRms = 0.18f
    private val minimumEndlessRms = 0.15f
    private var allowLive = false
    private var allowCover = false
    private var onlyOfficial = false
    private var cross = 0.5f

    private var lastTrackAUrl: String? = null
    private var lastTrackBUrl: String? = null
    private var analyzingA: String? = null
    private var analyzingB: String? = null
    private var resolvingA: String? = null
    private var resolvingB: String? = null
    private var autoEnabled = false
    private var autoFadeJob: Job? = null
    private val autoTriggerMs = 8_000L
    private val autoFadeMs = 3_000L

    private var controlsLocked = false
    private var masterDuck = 1f
    private var masterVolume = 1f
    private var resumeAAfterFocus = false
    private var resumeBAfterFocus = false
    private lateinit var audioManager: AudioManager
    private lateinit var audioFocusRequest: AudioFocusRequest

    private var endlessSeedMode = false
    private var endlessActive = false
    private var pendingEndlessStart = false
    private val endlessSeeds = mutableListOf<TrackRef>()
    private val endlessUsedUrls = linkedSetOf<String>()
    private val endlessUsedTrackKeys = linkedSetOf<String>()
    private val endlessSeedArtistKeys = linkedSetOf<String>()
    private var endlessNonSeedSelections = 0
    private val endlessPlayedAutoUrls = linkedSetOf<String>()
    private var endlessGenreProfile = EndlessGenreProfile.POP
    private var endlessSceneProfile = EndlessSceneProfile.GLOBAL
    private var endlessArtistOnlyMode = false
    private var endlessArtistOnlySeed: TrackRef? = null
    private var endlessArtistAllowLongTracks = false
    private val endlessArtistReplayQueue = ArrayDeque<TrackRef>()
    private val endlessRecent = mutableListOf<TrackRef>()
    private val endlessRecentArtists = mutableListOf<String>()
    private var endlessQueued: TrackRef? = null
    private var endlessWaitingFreeDeck: Boolean? = null
    private var endlessDiscoveryJob: Job? = null
    private var lastContinuityGuardAt = 0L
    private var lastRecoveryAttemptAt = 0L
    private var endlessRecoveryDeck: Boolean? = null
    private var endlessModeLocked = false
    private val endlessPrefetchMs = 60_000L
    private val endlessReadyDeadlineMs = 15_000L
    private val endlessEarlySearchAtMs = 3_000L
    private var endlessDeckHasPlayedA = false
    private var endlessDeckHasPlayedB = false
    private var endlessDeckStateA = EndlessDeckState.FREE
    private var endlessDeckStateB = EndlessDeckState.FREE
    private var mixInMsA = 0L
    private var mixInMsB = 0L

    private val speechLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != RESULT_OK || !::binding.isInitialized) return@registerForActivityResult
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
            ?.trim()
            .orEmpty()
        if (spoken.isNotBlank()) {
            binding.endlessSearchInput.setText(spoken)
            binding.endlessSearchInput.setSelection(spoken.length)
            runEndlessSearch()
        }
    }

    private val micPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchSpeechRecognizer()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMixerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val loadControlA = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 40_000, 2_500, 2_500)
            .setBackBuffer(20_000, true)
            .build()
        val loadControlB = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 40_000, 2_500, 2_500)
            .setBackBuffer(20_000, true)
            .build()
        playerA = ExoPlayer.Builder(this).setLoadControl(loadControlA).build()
        playerB = ExoPlayer.Builder(this).setLoadControl(loadControlB).build()
        playerA.setWakeMode(C.WAKE_MODE_NETWORK)
        playerB.setWakeMode(C.WAKE_MODE_NETWORK)
        setupAudioFocusProtection()
        addPlayerListener(playerA, true)
        addPlayerListener(playerB, false)

        endlessAdapter = SearchAdapter(
            targetDeck = null,
            onImportA = {},
            onImportB = {},
            onSelect = { selectEndlessSeed(it) }
        )
        binding.endlessResults.layoutManager = LinearLayoutManager(this)
        binding.endlessResults.adapter = endlessAdapter

        binding.loadA.setOnClickListener { openSearchFor("A") }
        binding.loadB.setOnClickListener { openSearchFor("B") }

        binding.playA.setOnClickListener {
            cancelAutoFadeForManualControl()
            MixerStore.deckA?.let { toggleDeck(true, it) }
                ?: Toast.makeText(this, "Press A to load a song", Toast.LENGTH_SHORT).show()
        }
        binding.playB.setOnClickListener {
            cancelAutoFadeForManualControl()
            MixerStore.deckB?.let { toggleDeck(false, it) }
                ?: Toast.makeText(this, "Press B to load a song", Toast.LENGTH_SHORT).show()
        }

        binding.autoMix.setOnClickListener {
            if (endlessActive) {
                Toast.makeText(this, "Endless Mix controls AUTO", Toast.LENGTH_SHORT).show()
            } else {
                autoEnabled = !autoEnabled
                updateAutoButton()
            }
        }

        binding.waveA.onSeekRequested = { fraction ->
            seekDeck(playerA, fraction)
        }
        binding.waveB.onSeekRequested = { fraction ->
            seekDeck(playerB, fraction)
        }

        binding.volumeA.progress = 100
        binding.volumeA.onProgressChanged = { p ->
            userVolA = p / 100f
            applyVolumes()
        }
        binding.volumeB.progress = 100
        binding.volumeB.onProgressChanged = { p ->
            userVolB = p / 100f
            applyVolumes()
        }

        binding.masterVolume.progress = 100
        binding.masterVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                masterVolume = progress / 100f
                applyVolumes()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        binding.crossfader.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    cancelAutoFadeForManualControl()
                    cross = progress / 100f
                    applyVolumes()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                cancelAutoFadeForManualControl()
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        binding.endlessAction.setOnClickListener { onEndlessAction() }
        binding.endlessSearchButton.setOnClickListener { runEndlessSearch() }
        binding.endlessVoiceButton.setOnClickListener { requestEndlessVoiceSearch() }
        binding.mixLock.setOnClickListener { toggleControlLock() }
        binding.filterLive.setOnClickListener {
            if (!controlsLocked) {
                allowLive = !allowLive
                updateEndlessFilterButtons()
            }
        }
        binding.filterCover.setOnClickListener {
            if (!controlsLocked) {
                allowCover = !allowCover
                updateEndlessFilterButtons()
            }
        }
        binding.filterOfficial.setOnClickListener {
            if (!controlsLocked) {
                onlyOfficial = !onlyOfficial
                updateEndlessFilterButtons()
            }
        }
        binding.endlessSearchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                runEndlessSearch()
                true
            } else false
        }

        refreshDecks(force = true)
        syncSeedsFromCurrentDecks()
        updateAutoButton()
        updateEndlessAction()
        updateControlLockUi()
        updateEndlessFilterButtons()
        applyVolumes()

        lifecycleScope.launch {
            while (isActive) {
                updateDeckUi(playerA, true)
                updateDeckUi(playerB, false)
                checkAutoMix()
                protectEndlessContinuity()
                delay(100)
            }
        }
    }

    private fun addPlayerListener(player: ExoPlayer, isA: Boolean) {
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                val button = if (isA) binding.playA else binding.playB
                when (playbackState) {
                    Player.STATE_BUFFERING -> {
                        button.text = "LOADING"
                        setPlayColor(button, false)
                    }
                    Player.STATE_READY -> {
                        updatePlayButton(isA)
                        if (endlessActive && !player.isPlaying) {
                            val state = if (isA) endlessDeckStateA else endlessDeckStateB
                            // Only a deck we explicitly loaded as NEXT may become READY_NEXT.
                            // A spent paused deck can remain ExoPlayer STATE_READY at -0:04; FREE
                            // must remain FREE even if ExoPlayer reports READY again.
                            if (state == EndlessDeckState.LOADING_NEXT) {
                                if (isA) endlessDeckStateA = EndlessDeckState.READY_NEXT
                                else endlessDeckStateB = EndlessDeckState.READY_NEXT
                            }
                        }
                        if (endlessActive && pendingEndlessStart && isA) {
                            pendingEndlessStart = false
                            player.play()
                        }
                        if (endlessActive && endlessRecoveryDeck == isA && !playerA.isPlaying && !playerB.isPlaying) {
                            cross = if (isA) 0f else 1f
                            binding.crossfader.progress = if (isA) 0 else 100
                            applyVolumes()
                            applyEndlessMixInPoint(player, targetIsA = isA)
                            player.play()
                            (if (isA) MixerStore.deckA else MixerStore.deckB)?.let { markEndlessAutoPlayed(it) }
                            endlessRecoveryDeck = null
                            endlessWaitingFreeDeck = null
                            discoverQueuedCandidate()
                        }
                    }
                    Player.STATE_ENDED -> {
                        if (isA) endlessDeckStateA = EndlessDeckState.FREE else endlessDeckStateB = EndlessDeckState.FREE
                        button.text = "PLAY"
                        setPlayColor(button, false)
                        updateLoadButtons()
                        if (endlessActive && autoFadeJob?.isActive != true) {
                            // Do not wait for the 100 ms watchdog loop. An ended deck is immediately
                            // available for the next candidate; if both are stopped this also arms
                            // the recovery autostart path.
                            endlessWaitingFreeDeck = isA
                            if (!playerA.isPlaying && !playerB.isPlaying) endlessRecoveryDeck = isA
                            endlessQueued?.let { queued ->
                                endlessQueued = null
                                endlessWaitingFreeDeck = null
                                loadEndlessTrackIntoDeck(isA, queued)
                            } ?: discoverQueuedCandidate()
                        }
                    }
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (endlessActive && isPlaying) {
                    if (isA) {
                        endlessDeckHasPlayedA = true
                        endlessDeckStateA = EndlessDeckState.PLAYING
                    } else {
                        endlessDeckHasPlayedB = true
                        endlessDeckStateB = EndlessDeckState.PLAYING
                    }
                }
                updatePlayButton(isA)
                updateLoadButtons()
            }
        })
    }

    private fun openSearchFor(deck: String) {
        startActivity(Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_TARGET_DECK, deck))
    }

    private fun prepareDeck(isA: Boolean, track: TrackRef) {
        val player = if (isA) playerA else playerB
        val button = if (isA) binding.playA else binding.playB
        val direct = track.streamUrl ?: return

        button.text = "LOADING"
        button.isEnabled = false
        setPlayColor(button, false)
        player.setMediaItem(MediaItem.fromUri(direct))
        player.prepare()
    }

    private fun toggleDeck(isA: Boolean, track: TrackRef) {
        if (::audioFocusRequest.isInitialized) audioManager.requestAudioFocus(audioFocusRequest)
        val player = if (isA) playerA else playerB
        if (player.mediaItemCount == 0) {
            resolvePrepareAnalyze(isA, track)
            return
        }
        if (player.playbackState == Player.STATE_READY || player.playbackState == Player.STATE_BUFFERING) {
            if (player.isPlaying) player.pause() else player.play()
        }
    }

    private fun refreshDecks(force: Boolean = false) {
        val a = MixerStore.deckA
        val b = MixerStore.deckB

        if (force || a?.url != lastTrackAUrl) {
            playerA.stop(); playerA.clearMediaItems()
            lastTrackAUrl = a?.url
            measuredRmsA = null
            mixInMsA = 0L
            endlessDeckHasPlayedA = false
            userVolA = 1f
            binding.volumeA.progress = 100
            binding.titleA.text = a?.title ?: "EMPTY"
            binding.playA.text = "PLAY"
            binding.playA.isEnabled = a != null
            setPlayColor(binding.playA, false)
            if (a == null) {
                binding.waveA.setEmpty()
                binding.timeA.text = ""
            } else {
                binding.waveA.setTrackPresent(true)
                val cached = MixerStore.waveA
                if (cached != null) binding.waveA.setWaveform(cached, 1f)
                resolvePrepareAnalyze(true, a)
            }
        }

        if (force || b?.url != lastTrackBUrl) {
            playerB.stop(); playerB.clearMediaItems()
            lastTrackBUrl = b?.url
            measuredRmsB = null
            mixInMsB = 0L
            endlessDeckHasPlayedB = false
            userVolB = 1f
            binding.volumeB.progress = 100
            binding.titleB.text = b?.title ?: "EMPTY"
            binding.playB.text = "PLAY"
            binding.playB.isEnabled = b != null
            setPlayColor(binding.playB, false)
            if (b == null) {
                binding.waveB.setEmpty()
                binding.timeB.text = ""
            } else {
                binding.waveB.setTrackPresent(true)
                val cached = MixerStore.waveB
                if (cached != null) binding.waveB.setWaveform(cached, 1f)
                resolvePrepareAnalyze(false, b)
            }
        }
    }

    private fun resolvePrepareAnalyze(isA: Boolean, track: TrackRef) {
        val key = track.url
        val player = if (isA) playerA else playerB
        val button = if (isA) binding.playA else binding.playB

        if (player.mediaItemCount > 0) {
            if (!endlessActive && (if (isA) MixerStore.waveA else MixerStore.waveB) == null) analyzeWaveform(isA, track)
            return
        }

        val existing = track.streamUrl
        if (existing != null) {
            prepareDeck(isA, track)
            // Endless preloads prioritize ExoPlayer buffering; their analysis is scheduled a few
            // seconds later by loadEndlessTrackIntoDeck so it cannot steal bandwidth from READY.
            if (!endlessActive && (if (isA) MixerStore.waveA else MixerStore.waveB) == null) analyzeWaveform(isA, track)
            return
        }

        if ((if (isA) resolvingA else resolvingB) == key) return
        if (isA) resolvingA = key else resolvingB = key
        button.text = "LOADING"
        button.isEnabled = false
        setPlayColor(button, false)

        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) { AudioResolver.resolveBestAudioUrl(track.url) }
            }
            if (isA) resolvingA = null else resolvingB = null

            result.onSuccess { direct ->
                val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                if (!sameTrack) return@onSuccess
                val updated = track.copy(streamUrl = direct)
                if (isA) MixerStore.deckA = updated else MixerStore.deckB = updated
                prepareDeck(isA, updated)
                analyzeWaveform(isA, updated)
            }.onFailure {
                val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                if (sameTrack) {
                    button.isEnabled = true
                    button.text = "PLAY"
                    setPlayColor(button, false)
                    Toast.makeText(this@MixerActivity, "Stream error: ${it.message ?: "unknown"}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun analyzeWaveform(isA: Boolean, track: TrackRef) {
        val direct = track.streamUrl ?: return
        val key = track.url
        if (isA) {
            if (MixerStore.waveA != null || analyzingA == key) return
            analyzingA = key
        } else {
            if (MixerStore.waveB != null || analyzingB == key) return
            analyzingB = key
        }

        lifecycleScope.launch {
            val analysis = runCatching {
                withContext(Dispatchers.IO) {
                    WaveformAnalyzer.analyze(direct) { partial, fraction ->
                        runOnUiThread {
                            val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                            if (sameTrack) {
                                if (isA) binding.waveA.setWaveform(partial, fraction)
                                else binding.waveB.setWaveform(partial, fraction)
                            }
                        }
                    }
                }
            }.getOrNull()

            if (isA) {
                analyzingA = null
                if (MixerStore.deckA?.url == key && analysis != null) {
                    if (endlessActive && !playerA.isPlaying && analysis.rms >= 0.001f && analysis.rms < minimumEndlessRms) {
                        endlessUsedUrls.add(track.url)
                        endlessUsedTrackKeys.add(endlessTrackKey(track))
                        freePausedEndlessDeck(true, force = true)
                        return@launch
                    }
                    MixerStore.waveA = analysis.waveform
                    measuredRmsA = analysis.rms
                    mixInMsA = maxOf(mixInMsA, detectMixInPointMs(analysis.waveform, track.durationSeconds * 1000L))
                    binding.waveA.setWaveform(analysis.waveform, 1f)
                    applyAutoLoudness(true, analysis.rms)
                }
            } else {
                analyzingB = null
                if (MixerStore.deckB?.url == key && analysis != null) {
                    if (endlessActive && !playerB.isPlaying && analysis.rms >= 0.001f && analysis.rms < minimumEndlessRms) {
                        endlessUsedUrls.add(track.url)
                        endlessUsedTrackKeys.add(endlessTrackKey(track))
                        freePausedEndlessDeck(false, force = true)
                        return@launch
                    }
                    MixerStore.waveB = analysis.waveform
                    measuredRmsB = analysis.rms
                    mixInMsB = maxOf(mixInMsB, detectMixInPointMs(analysis.waveform, track.durationSeconds * 1000L))
                    binding.waveB.setWaveform(analysis.waveform, 1f)
                    applyAutoLoudness(false, analysis.rms)
                }
            }
        }
    }

    private fun updateDeckUi(player: ExoPlayer, isA: Boolean) {
        val duration = player.duration
        val position = player.currentPosition.coerceAtLeast(0L)
        val p = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f
        val remaining = if (duration > 0) (duration - position).coerceAtLeast(0L) else -1L

        if (isA) {
            binding.waveA.setProgress(p)
            binding.timeA.text = if (remaining >= 0) "-${formatTime(remaining)}" else ""
        } else {
            binding.waveB.setProgress(p)
            binding.timeB.text = if (remaining >= 0) "-${formatTime(remaining)}" else ""
        }
    }

    private fun seekDeck(player: ExoPlayer, fraction: Float) {
        if (player.mediaItemCount == 0) return
        val duration = player.duration
        if (duration > 0) player.seekTo((duration * fraction.coerceIn(0f, 1f)).toLong())
    }

    private fun checkAutoMix() {
        if (!autoEnabled || autoFadeJob?.isActive == true) return
        val aRemaining = remainingMs(playerA)
        val bRemaining = remainingMs(playerB)

        if (playerA.isPlaying && aRemaining in 1..autoTriggerMs && deckReadyForAuto(playerB)) {
            startAutoFade(fromA = true)
        } else if (playerB.isPlaying && bRemaining in 1..autoTriggerMs && deckReadyForAuto(playerA)) {
            startAutoFade(fromA = false)
        }
    }

    private fun freePausedEndlessDeck(isA: Boolean, force: Boolean = false) {
        if (!endlessActive) return
        val hasPlayed = if (isA) endlessDeckHasPlayedA else endlessDeckHasPlayedB
        if (!force && !hasPlayed) return
        if (isA) {
            endlessDeckHasPlayedA = false
            endlessDeckStateA = EndlessDeckState.FREE
        } else {
            endlessDeckHasPlayedB = false
            endlessDeckStateB = EndlessDeckState.FREE
        }

        // Mark the physical deck as the destination before touching discovery. If a discovery
        // job is already running, it will see this waiting slot when it completes and load the
        // candidate directly here instead of leaving it merely queued.
        endlessWaitingFreeDeck = isA
        val queued = endlessQueued
        if (queued != null) {
            endlessQueued = null
            endlessWaitingFreeDeck = null
            loadEndlessTrackIntoDeck(isA, queued)
        } else {
            // Safe even if a discovery job is already active: that job keeps running and will
            // consume endlessWaitingFreeDeck on completion. If none is active, this starts one.
            discoverQueuedCandidate()
        }
    }

    private fun protectEndlessContinuity() {
        if (!endlessActive) return
        val now = android.os.SystemClock.elapsedRealtime()

        // Endless rule: once a deck that has actually played is PAUSED/not playing, it is spent.
        // Reclaim it immediately for the next track; do not wait for STATE_ENDED or remaining time.
        if (endlessDeckHasPlayedA && !playerA.isPlaying && autoFadeJob?.isActive != true) {
            freePausedEndlessDeck(true)
        }
        if (endlessDeckHasPlayedB && !playerB.isPlaying && autoFadeJob?.isActive != true) {
            freePausedEndlessDeck(false)
        }

        // Pipeline rule: give a newly started song only about three seconds to stabilize,
        // then start finding the song AFTER the already-loaded opposite deck. Keep it queued
        // until a played deck becomes free. This gives search/resolution almost a full song.
        val active = when {
            playerA.isPlaying -> playerA
            playerB.isPlaying -> playerB
            else -> null
        }
        if (active != null && active.currentPosition >= endlessEarlySearchAtMs &&
            endlessQueued == null && endlessDiscoveryJob?.isActive != true && endlessWaitingFreeDeck == null) {
            discoverQueuedCandidate()
        }

        fun ensureNextDeck(source: ExoPlayer, sourceIsA: Boolean, target: ExoPlayer) {
            if (!source.isPlaying) return
            val remaining = remainingMs(source)
            val targetIsA = !sourceIsA

            // Start preparing the next deck a full minute before the transition. If a candidate
            // is already queued, load it immediately into the non-playing deck instead of waiting
            // for the current song to end.
            if (remaining <= endlessPrefetchMs && !deckReadyForAuto(target)) {
                if (endlessWaitingFreeDeck == null) endlessWaitingFreeDeck = targetIsA
                val queued = endlessQueued
                if (queued != null && endlessWaitingFreeDeck == targetIsA) {
                    endlessQueued = null
                    endlessWaitingFreeDeck = null
                    loadEndlessTrackIntoDeck(targetIsA, queued)
                } else {
                    discoverQueuedCandidate()
                }
            }

            // By 15 seconds the target must be READY. Keep hammering discovery/resolution.
            if (remaining <= endlessReadyDeadlineMs && !deckReadyForAuto(target)) {
                endlessWaitingFreeDeck = targetIsA
                discoverQueuedCandidate()
            }

        }

        ensureNextDeck(playerA, true, playerB)
        ensureNextDeck(playerB, false, playerA)

        if (!playerA.isPlaying && !playerB.isPlaying && autoFadeJob?.isActive != true) {
            if (now - lastRecoveryAttemptAt < 750L) return
            lastRecoveryAttemptAt = now
            val aPlayable = deckReadyForAuto(playerA) && remainingMs(playerA) > 2_000L
            val bPlayable = deckReadyForAuto(playerB) && remainingMs(playerB) > 2_000L
            when {
                aPlayable -> {
                    cross = 0f
                    binding.crossfader.progress = 0
                    applyVolumes()
                    applyEndlessMixInPoint(playerA, targetIsA = true)
                    endlessDeckStateA = EndlessDeckState.PLAYING
                    playerA.play()
                    MixerStore.deckA?.let { markEndlessAutoPlayed(it) }
                    endlessRecoveryDeck = null
                    endlessWaitingFreeDeck = false
                    discoverQueuedCandidate()
                }
                bPlayable -> {
                    cross = 1f
                    binding.crossfader.progress = 100
                    applyVolumes()
                    applyEndlessMixInPoint(playerB, targetIsA = false)
                    endlessDeckStateB = EndlessDeckState.PLAYING
                    playerB.play()
                    MixerStore.deckB?.let { markEndlessAutoPlayed(it) }
                    endlessRecoveryDeck = null
                    endlessWaitingFreeDeck = true
                    discoverQueuedCandidate()
                }
                else -> {
                    // Prefer an ended/empty deck for recovery. Keep retrying until one becomes READY.
                    val recoverA = playerA.playbackState == Player.STATE_ENDED || playerA.mediaItemCount == 0 ||
                        (playerB.playbackState != Player.STATE_ENDED && remainingMs(playerA) <= remainingMs(playerB))
                    endlessRecoveryDeck = recoverA
                    endlessWaitingFreeDeck = recoverA
                    endlessQueued = null
                    discoverQueuedCandidate()
                }
            }
        }
    }

    private fun deckReadyForAuto(player: ExoPlayer): Boolean {
        if (player.mediaItemCount == 0 || player.playbackState != Player.STATE_READY) return false
        if (endlessActive) {
            val state = if (player === playerA) endlessDeckStateA else endlessDeckStateB
            // ExoPlayer may remain STATE_READY on the old paused track (often around -0:04).
            // FREE is authoritative: a spent deck can never masquerade as the next ready deck.
            if (state != EndlessDeckState.READY_NEXT && state != EndlessDeckState.PLAYING) return false
        }
        val d = player.duration
        return d <= 0 || player.currentPosition < d - 1_000L
    }

    private fun remainingMs(player: ExoPlayer): Long {
        val d = player.duration
        return if (d > 0) (d - player.currentPosition).coerceAtLeast(0L) else Long.MAX_VALUE
    }

    private fun startAutoFade(fromA: Boolean) {
        val source = if (fromA) playerA else playerB
        val target = if (fromA) playerB else playerA
        if (!deckReadyForAuto(target)) return

        applyEndlessMixInPoint(target, targetIsA = !fromA)
        if (endlessActive) {
            if (fromA) endlessDeckStateB = EndlessDeckState.PLAYING else endlessDeckStateA = EndlessDeckState.PLAYING
        }
        target.play()
        val startCross = cross
        val endCross = if (fromA) 1f else 0f

        autoFadeJob = lifecycleScope.launch {
            val steps = 50
            for (i in 0..steps) {
                if (!isActive) return@launch
                val t = i / steps.toFloat()
                cross = startCross + (endCross - startCross) * t
                binding.crossfader.progress = (cross * 100f).roundToInt().coerceIn(0, 100)
                applyVolumes()
                delay(autoFadeMs / steps)
            }
            source.pause()
            cross = endCross
            binding.crossfader.progress = (cross * 100f).roundToInt()
            applyVolumes()
            autoFadeJob = null
            if (endlessActive) onEndlessTransitionComplete(freedIsA = fromA)
        }
    }

    private fun cancelAutoFadeForManualControl() {
        if (endlessActive) stopEndlessForManualControl()
        if (autoFadeJob?.isActive == true) {
            autoFadeJob?.cancel()
            autoFadeJob = null
            autoEnabled = false
            updateAutoButton()
        }
    }

    private fun detectMixInPointMs(waveform: FloatArray, durationMs: Long): Long {
        if (durationMs <= 0L || waveform.isEmpty()) return 0L
        val maxSkipMs = minOf(20_000L, durationMs / 8)
        val maxBucket = ((maxSkipMs.toDouble() / durationMs) * waveform.size)
            .toInt().coerceIn(1, waveform.lastIndex.coerceAtLeast(1))
        // If the opening is already clearly audible, keep the true beginning.
        if (waveform.take(minOf(3, waveform.size)).any { it >= 0.20f }) return 0L
        for (i in 0 until maxBucket) {
            val end = minOf(i + 4, waveform.size)
            if (end - i >= 3 && waveform.sliceArray(i until end).count { it >= 0.22f } >= 3) {
                return ((i.toDouble() / waveform.size) * durationMs).toLong().coerceIn(0L, maxSkipMs)
            }
        }
        return 0L
    }

    private fun applyEndlessMixInPoint(player: ExoPlayer, targetIsA: Boolean) {
        if (!endlessActive || player.currentPosition > 1_000L) return
        val mixIn = if (targetIsA) mixInMsA else mixInMsB
        if (mixIn > 750L) player.seekTo(mixIn)
    }

    private fun applyAutoLoudness(isA: Boolean, rms: Float) {
        if (rms <= 0.001f) return
        // Never boost above the clean 100% deck level; only tame louder tracks.
        val normalized = (loudnessTargetRms / rms).coerceIn(0.55f, 1f)
        val progress = (normalized * 100f).roundToInt().coerceIn(55, 100)
        if (isA) {
            userVolA = progress / 100f
            binding.volumeA.progress = progress
        } else {
            userVolB = progress / 100f
            binding.volumeB.progress = progress
        }
        applyVolumes()
    }

    private fun applyVolumes() {
        val headroom = 0.82f
        val aGain = (1f - cross) * headroom
        val bGain = cross * headroom
        playerA.volume = (userVolA * aGain * masterVolume * masterDuck).coerceIn(0f, 1f)
        playerB.volume = (userVolB * bGain * masterVolume * masterDuck).coerceIn(0f, 1f)
    }

    private fun updatePlayButton(isA: Boolean) {
        val player = if (isA) playerA else playerB
        val button = if (isA) binding.playA else binding.playB
        button.isEnabled = !controlsLocked && player.mediaItemCount > 0 && player.playbackState != Player.STATE_IDLE
        if (player.isPlaying) {
            button.text = "PAUSE"
            setPlayColor(button, true)
        } else if (player.playbackState == Player.STATE_BUFFERING) {
            button.text = "LOADING"
            setPlayColor(button, false)
        } else {
            button.text = "PLAY"
            setPlayColor(button, false)
        }
    }

    private fun updateLoadButtons() {
        val aLocked = playerA.isPlaying
        val bLocked = playerB.isPlaying

        binding.loadA.isEnabled = !controlsLocked && !aLocked
        binding.loadA.alpha = if (controlsLocked || aLocked) 0.35f else 1f
        binding.loadB.isEnabled = !controlsLocked && !bLocked
        binding.loadB.alpha = if (controlsLocked || bLocked) 0.35f else 1f
    }

    private fun setPlayColor(button: Button, pausedState: Boolean) {
        val color = if (pausedState) R.color.yellow_control else R.color.blue_control
        button.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, color))
        button.setTextColor(ContextCompat.getColor(this, if (pausedState) R.color.black else R.color.white))
    }

    private fun updateAutoButton() {
        val color = if (autoEnabled) R.color.orange_control else R.color.white
        binding.autoMix.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, color))
        binding.autoMix.setTextColor(ContextCompat.getColor(this, R.color.black))
        binding.autoMix.text = if (autoEnabled) "AUTO IS ON" else "AUTO IS OFF"
        binding.autoMix.isEnabled = !controlsLocked
    }

    // ---------------- ENDLESS MIX ----------------

    private fun onEndlessAction() {
        if (endlessActive) {
            stopEndlessMix()
            return
        }

        syncSeedsFromCurrentDecks()
        if (endlessSeeds.size >= 2) {
            startEndlessMix()
        } else {
            endlessSeedMode = true
            showEndlessSearch(true)
            binding.endlessStatus.text = if (endlessSeeds.size == 1) {
                "1/2 loaded — choose a similar second song"
            } else {
                "Choose the first seed song"
            }
            updateEndlessAction()
        }
    }

    private fun syncSeedsFromCurrentDecks() {
        if (endlessActive) return
        endlessSeeds.clear()
        MixerStore.deckA?.let { endlessSeeds.add(it) }
        MixerStore.deckB?.let { b -> if (endlessSeeds.none { it.url == b.url }) endlessSeeds.add(b) }
        updateEndlessAction()
    }

    private fun updateEndlessAction() {
        binding.endlessAction.text = when {
            endlessActive -> "STOP ENDLESS MIX"
            endlessSeeds.size >= 2 -> "PLAY ENDLESS MIX"
            else -> "LOAD TWO SIMILAR SONGS\nAND MAKE ENDLESS MIX"
        }
    }

    private fun showEndlessSearch(show: Boolean) {
        binding.endlessSearchPanel.visibility = if (show) View.VISIBLE else View.GONE
        // During seed loading the search gets the lower workspace without leaving the mixer window.
        binding.autoMix.visibility = if (show) View.GONE else View.VISIBLE
        binding.crossLabels.visibility = if (show) View.GONE else View.VISIBLE
        binding.crossfader.visibility = if (show) View.GONE else View.VISIBLE
        if (!show) endlessAdapter.submit(emptyList())
    }

    private fun runEndlessSearch() {
        val q = binding.endlessSearchInput.text.toString().trim()
        if (q.isBlank()) return
        binding.endlessStatus.text = "Searching…"
        lifecycleScope.launch {
            runCatching {
                withContext(Dispatchers.IO) { searchRepo.search(q) }
            }.onSuccess { results ->
                endlessAdapter.submit(results)
                binding.endlessStatus.text = when (endlessSeeds.size) {
                    0 -> "Choose the first song — ${results.size} results"
                    else -> "Choose a similar second song — ${results.size} results"
                }
            }.onFailure {
                binding.endlessStatus.text = "Search error: ${it.message ?: "unknown"}"
            }
        }
    }

    private fun selectEndlessSeed(track: TrackRef) {
        if (endlessSeeds.any { it.url == track.url }) {
            Toast.makeText(this, "Choose a different second song", Toast.LENGTH_SHORT).show()
            return
        }

        when {
            MixerStore.deckA == null -> MixerStore.setA(track)
            MixerStore.deckB == null -> MixerStore.setB(track)
            endlessSeeds.isEmpty() -> MixerStore.setA(track)
            endlessSeeds.size == 1 -> {
                val first = endlessSeeds.first()
                if (MixerStore.deckA?.url == first.url) MixerStore.setB(track) else MixerStore.setA(track)
            }
            else -> return
        }

        refreshDecks()
        syncSeedsFromCurrentDecks()
        if (endlessSeeds.size >= 2) {
            endlessSeedMode = false
            showEndlessSearch(false)
            binding.endlessSearchInput.setText("")
            updateEndlessAction()
        } else {
            binding.endlessStatus.text = "1/2 loaded — choose a similar second song"
        }
    }

    private fun startEndlessMix() {
        syncSeedsFromCurrentDecks()
        if (endlessSeeds.size < 2) {
            showEndlessSearch(true)
            return
        }

        if (::audioFocusRequest.isInitialized) audioManager.requestAudioFocus(audioFocusRequest)
        endlessActive = true
        endlessSeedMode = false
        autoEnabled = true
        controlsLocked = false
        endlessUsedUrls.clear()
        endlessUsedTrackKeys.clear()
        endlessSeedArtistKeys.clear()
        endlessNonSeedSelections = 0
        endlessPlayedAutoUrls.clear()
        endlessArtistReplayQueue.clear()
        endlessModeLocked = false
        endlessArtistOnlyMode = sameArtistConfidence(endlessSeeds[0], endlessSeeds[1])
        endlessGenreProfile = classifyEndlessGenre(endlessSeeds[0], endlessSeeds[1])
        endlessSceneProfile = classifyEndlessScene(endlessSeeds[0], endlessSeeds[1])
        endlessModeLocked = true
        endlessArtistOnlySeed = if (endlessArtistOnlyMode) endlessSeeds[0] else null
        endlessArtistAllowLongTracks = false
        endlessRecent.clear()
        endlessRecentArtists.clear()
        endlessSeeds.take(2).forEach {
            endlessUsedUrls.add(it.url)
            endlessUsedTrackKeys.add(endlessTrackKey(it))
            endlessSeedArtistKeys.add(endlessArtistKey(it))
            endlessRecent.add(it)
            rememberEndlessArtist(it)
        }
        endlessQueued = null
        endlessWaitingFreeDeck = null
        endlessDeckHasPlayedA = false
        endlessDeckHasPlayedB = false
        endlessDeckStateA = EndlessDeckState.PLAYING
        endlessDeckStateB = EndlessDeckState.READY_NEXT
        showEndlessSearch(false)
        updateAutoButton()
        updateEndlessAction()
        updateControlLockUi()

        // Endless Mix always starts from deck A; B is already prepared as the next song.
        cross = 0f
        binding.crossfader.progress = 0
        applyVolumes()
        if (playerA.mediaItemCount > 0) {
            endlessDeckStateA = EndlessDeckState.PLAYING
            endlessDeckStateB = EndlessDeckState.READY_NEXT
            playerA.play()
        } else {
            pendingEndlessStart = true
            MixerStore.deckA?.let { resolvePrepareAnalyze(true, it) }
        }
        // The third track is searched after the active deck has played for ~3 seconds.
        // Deck B is already the second seed, so there is no reason to burn network/resolver work earlier.
    }

    private fun stopEndlessMix() {
        endlessActive = false
        endlessSeedMode = false
        autoEnabled = false
        controlsLocked = false
        pendingEndlessStart = false
        endlessDiscoveryJob?.cancel()
        endlessDiscoveryJob = null
        endlessQueued = null
        endlessWaitingFreeDeck = null
        endlessDeckHasPlayedA = false
        endlessDeckHasPlayedB = false
        endlessDeckStateA = EndlessDeckState.FREE
        endlessDeckStateB = EndlessDeckState.FREE
        endlessSeeds.clear()
        endlessUsedUrls.clear()
        endlessUsedTrackKeys.clear()
        endlessSeedArtistKeys.clear()
        endlessNonSeedSelections = 0
        endlessPlayedAutoUrls.clear()
        endlessGenreProfile = EndlessGenreProfile.POP
        endlessSceneProfile = EndlessSceneProfile.GLOBAL
        endlessArtistOnlyMode = false
        endlessModeLocked = false
        endlessRecoveryDeck = null
        endlessArtistOnlySeed = null
        endlessArtistAllowLongTracks = false
        endlessArtistReplayQueue.clear()
        endlessRecent.clear()
        endlessRecentArtists.clear()
        showEndlessSearch(false)
        updateAutoButton()
        updateEndlessAction()
        updateControlLockUi()
        // Do not stop the song that is already playing.
    }

    private fun stopEndlessForManualControl() {
        endlessActive = false
        endlessSeedMode = false
        autoEnabled = false
        controlsLocked = false
        pendingEndlessStart = false
        endlessDiscoveryJob?.cancel()
        endlessDiscoveryJob = null
        endlessQueued = null
        endlessWaitingFreeDeck = null
        endlessDeckHasPlayedA = false
        endlessDeckHasPlayedB = false
        endlessDeckStateA = EndlessDeckState.FREE
        endlessDeckStateB = EndlessDeckState.FREE
        endlessSeeds.clear()
        endlessUsedUrls.clear()
        endlessUsedTrackKeys.clear()
        endlessSeedArtistKeys.clear()
        endlessNonSeedSelections = 0
        endlessPlayedAutoUrls.clear()
        endlessGenreProfile = EndlessGenreProfile.POP
        endlessSceneProfile = EndlessSceneProfile.GLOBAL
        endlessArtistOnlyMode = false
        endlessModeLocked = false
        endlessRecoveryDeck = null
        endlessArtistOnlySeed = null
        endlessArtistAllowLongTracks = false
        endlessArtistReplayQueue.clear()
        endlessRecent.clear()
        endlessRecentArtists.clear()
        showEndlessSearch(false)
        updateAutoButton()
        updateEndlessAction()
        updateControlLockUi()
    }

    private fun onEndlessTransitionComplete(freedIsA: Boolean) {
        if (!endlessActive) return
        val nowPlaying = if (freedIsA) MixerStore.deckB else MixerStore.deckA
        nowPlaying?.let { markEndlessAutoPlayed(it) }

        // Crossfade completion is authoritative: the source deck has just been paused by us,
        // therefore it is free NOW. Do not depend on position, STATE_ENDED, or a played flag.
        freePausedEndlessDeck(freedIsA, force = true)
    }

    private fun loadEndlessTrackIntoDeck(isA: Boolean, track: TrackRef) {
        if (!endlessActive) return
        if (isA) endlessDeckStateA = EndlessDeckState.LOADING_NEXT else endlessDeckStateB = EndlessDeckState.LOADING_NEXT
        lifecycleScope.launch {
            // Continuity first: resolve only. Never wait for whole-song waveform analysis before
            // assigning/preparing the free deck. The user should see the next track within the
            // first 10-15 seconds of the current song whenever the network allows it.
            val resolved = withTimeoutOrNull(8_000L) {
                withContext(Dispatchers.IO) {
                    runCatching {
                        if (track.streamUrl != null) track
                        else track.copy(streamUrl = AudioResolver.resolveBestAudioUrl(track.url))
                    }.getOrNull()
                }
            }
            if (!endlessActive) return@launch
            if (resolved == null) {
                if (isA) endlessDeckStateA = EndlessDeckState.FREE else endlessDeckStateB = EndlessDeckState.FREE
                endlessWaitingFreeDeck = isA
                endlessQueued = null
                delay(500)
                discoverQueuedCandidate()
                return@launch
            }

            if (isA) MixerStore.setA(resolved) else MixerStore.setB(resolved)
            endlessRecent.add(resolved)
            while (endlessRecent.size > 8) endlessRecent.removeAt(0)
            rememberEndlessArtist(resolved)
            endlessUsedTrackKeys.add(endlessTrackKey(resolved))
            refreshDecks()
            // refreshDecks -> prepareDeck starts ExoPlayer buffering immediately. Analysis is now
            // background-only and therefore cannot hold continuity hostage.

            val direct = resolved.streamUrl ?: return@launch
            val key = resolved.url

            // Fast intro scan runs in parallel with ExoPlayer buffering. It catches creator ads,
            // dead air, countdown-like silence and very quiet openings, and stores a safe mix-in
            // point without requiring a whole-song decode first.
            launch {
                delay(1_500)
                val intro = withContext(Dispatchers.IO) {
                    runCatching { WaveformAnalyzer.analyzeIntro(direct) }.getOrNull()
                } ?: return@launch
                val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                if (!endlessActive || !sameTrack) return@launch
                if (isA) mixInMsA = maxOf(mixInMsA, intro.mixInMs)
                else mixInMsB = maxOf(mixInMsB, intro.mixInMs)
            }

            // Give ExoPlayer first claim on the network/buffer. Full waveform/RMS starts later
            // and remains non-blocking. If it is slow, the deck is still READY and playable.
            launch {
                delay(5_000)
                val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                if (endlessActive && sameTrack) analyzeWaveform(isA, resolved)
            }
        }
    }

    private fun discoverQueuedCandidate() {
        if (!endlessActive || endlessQueued != null || endlessDiscoveryJob?.isActive == true) return

        // Artist-only mode: after the catalogue is exhausted, replay the two original
        // seeds in order, then begin a fresh pass through that artist's catalogue.
        if (endlessArtistOnlyMode && endlessArtistReplayQueue.isNotEmpty()) {
            val replay = endlessArtistReplayQueue.removeFirst()
            endlessUsedUrls.add(replay.url)
            endlessUsedTrackKeys.add(endlessTrackKey(replay))
            val waiting = endlessWaitingFreeDeck
            if (waiting != null) {
                endlessWaitingFreeDeck = null
                loadEndlessTrackIntoDeck(waiting, replay)
                discoverQueuedCandidate()
            } else {
                endlessQueued = replay
            }
            return
        }

        val queries = buildEndlessQueries()
        endlessDiscoveryJob = lifecycleScope.launch {
            // Continuity beats building a perfect global pool. Try seed-anchored queries one by
            // one and accept the first query that yields a candidate passing every hard guard.
            // Each query has a deadline so one wedged NewPipe fetch cannot own the pipeline forever.
            var candidate: TrackRef? = null
            for (query in queries.take(3)) {
                if (!endlessActive || candidate != null) break
                val results = withTimeoutOrNull(6_000L) {
                    withContext(Dispatchers.IO) {
                        runCatching { searchRepo.search(query) }.getOrElse { emptyList() }
                    }
                } ?: emptyList()
                candidate = chooseEndlessCandidate(results)
            }
            endlessDiscoveryJob = null
            if (!endlessActive) return@launch

            if (candidate == null) {
                if (endlessArtistOnlyMode && endlessSeeds.size >= 2) {
                    if (!endlessArtistAllowLongTracks) {
                        // First exhaust normal-length songs. Only then relax the 8-minute limit.
                        endlessArtistAllowLongTracks = true
                        discoverQueuedCandidate()
                    } else {
                        // The artist catalogue is exhausted even with long tracks allowed.
                        // Start a fresh artist-only cycle with the two original seeds first.
                        endlessArtistAllowLongTracks = false
                        endlessUsedUrls.clear()
                        endlessUsedTrackKeys.clear()
                        endlessRecentArtists.clear()
                        endlessArtistReplayQueue.clear()
                        endlessArtistReplayQueue.addLast(endlessSeeds[0])
                        endlessArtistReplayQueue.addLast(endlessSeeds[1])
                        discoverQueuedCandidate()
                    }
                } else {
                    delay(500)
                    discoverQueuedCandidate()
                }
                return@launch
            }

            endlessUsedUrls.add(candidate.url)
            endlessUsedTrackKeys.add(endlessTrackKey(candidate))
            val waiting = endlessWaitingFreeDeck
            if (waiting != null) {
                endlessWaitingFreeDeck = null
                loadEndlessTrackIntoDeck(waiting, candidate)
                discoverQueuedCandidate()
            } else {
                endlessQueued = candidate
            }
        }
    }

    private fun buildEndlessQueries(): List<String> {
        val a = endlessSeeds.getOrNull(0) ?: return emptyList()
        val b = endlessSeeds.getOrNull(1) ?: return emptyList()
        val artistA = endlessArtistKey(a)
        val artistB = endlessArtistKey(b)

        if (endlessArtistOnlyMode) {
            val artist = endlessArtistKey(endlessArtistOnlySeed ?: a).ifBlank { artistA }
            return listOf(
                "$artist official audio",
                "$artist official music video",
                "$artist songs"
            ).map { it.trim() }.filter { it.isNotBlank() }.distinct()
        }

        val genreAnchor = when (endlessGenreProfile) {
            EndlessGenreProfile.POP -> "pop pop rock"
            EndlessGenreProfile.POP_FOLK -> "pop folk folk"
            EndlessGenreProfile.FOLK -> "folk pop folk"
        }
        val sceneAnchor = sceneSearchAnchor(endlessSceneProfile)

        // IMPORTANT: discovery always stays anchored to the ORIGINAL two seeds.
        // Recent auto-selected tracks never become the new center of gravity; that was the
        // source of the old POP -> folk -> unrelated-country chain drift.
        return listOf(
            "$artistA $artistB $sceneAnchor $genreAnchor similar songs official",
            "$artistA $artistB $sceneAnchor $genreAnchor related artists music",
            "music like $artistA $artistB $sceneAnchor $genreAnchor"
        ).map { it.trim() }.filter { it.isNotBlank() }.distinct()
    }

    private fun chooseEndlessCandidate(items: List<TrackRef>): TrackRef? {
        val hardBlockedWords = listOf(
            "karaoke", "reaction", "tutorial", "full album", "playlist", "instrumental karaoke",
            "interview", "intervju", "podcast", "talk", "conversation", "gostovanje", "gost u",
            "emisija", "behind the scenes", "documentary", "dokumentar", "press conference", "press",
            "q&a", "q & a", "review", "recenzija", "priča", "prica", "razgovor",
            "radio interview", "tv interview", "radio emisija", "tv emisija", "dnevnik", "vesti", "vijesti",
            "news", "breaking", "reportaza", "reportaža", "podcast clip", "shorts interview"
        )
        val softPenaltyWords = listOf(
            "acoustic", "unplugged", "remix", "concert", "session",
            "sped up", "slowed", "nightcore", "extended", "edit", "remastered"
        )
        val artistOnlySeed = endlessArtistOnlySeed

        val candidates = items.mapIndexedNotNull { index, track ->
            val title = track.title.lowercase(Locale.getDefault())
            val artist = endlessArtistKey(track)
            val trackKey = endlessTrackKey(track)
            val correctArtistForArtistOnly = !endlessArtistOnlyMode ||
                (artistOnlySeed != null && isSameArtistFamily(artistOnlySeed, track))
            val seedArtistBlocked = !endlessArtistOnlyMode &&
                endlessNonSeedSelections < 5 &&
                isOriginalSeedArtist(track)
            val recentArtistBlocked = !endlessArtistOnlyMode && endlessRecent.takeLast(5).any { recentTrack ->
                isSameArtistFamily(recentTrack, track)
            }
            val consecutiveArtistBlocked = !endlessArtistOnlyMode && endlessRecent.lastOrNull()?.let { recentTrack ->
                isSameArtistFamily(recentTrack, track)
            } == true
            val durationAllowed = when {
                track.durationSeconds <= 0 -> true
                track.durationSeconds < 75 -> false
                endlessArtistOnlyMode && endlessArtistAllowLongTracks -> true
                else -> track.durationSeconds <= 480
            }

            val uploaderText = track.uploader.lowercase(Locale.getDefault())
            val isLive = listOf(" live", "live ", "concert", "koncert", "unplugged").any { it in title }
            val isCover = listOf("cover", "tribute", "obrada").any { it in title }
            val looksOfficial = track.uploaderVerified || "official" in title || "official" in uploaderText || "vevo" in uploaderText || "topic" in uploaderText
            val narrativeNonSong = looksLikeNarrativeNonSong(track)
            val wrongScene = !endlessArtistOnlyMode && violatesLockedScene(track)
            val wrongGenre = !endlessArtistOnlyMode && violatesLockedGenre(track)

            val passes = track.url !in endlessUsedUrls &&
                trackKey !in endlessUsedTrackKeys &&
                correctArtistForArtistOnly &&
                !recentArtistBlocked &&
                !consecutiveArtistBlocked &&
                !seedArtistBlocked &&
                durationAllowed &&
                hardBlockedWords.none { it in title } &&
                !narrativeNonSong &&
                !wrongScene &&
                !wrongGenre &&
                (allowLive || !isLive) &&
                (allowCover || !isCover) &&
                (!onlyOfficial || looksOfficial)

            if (!passes) return@mapIndexedNotNull null

            // Ranking happens only AFTER every hard rule above has passed.
            // Search relevance matters, but popularity is deliberately logarithmic: 100M views
            // should beat 100k when all else is equal, without steamrolling a much better match.
            var score = 1000 - index * 5
            softPenaltyWords.forEach { word -> if (word in title) score -= 140 }
            if (allowLive && ("live" in title || "concert" in title || "koncert" in title)) score -= 70
            if (allowCover && ("cover" in title || "tribute" in title || "obrada" in title)) score -= 70

            val cleanSongShape = listOf(" - ", " – ", " — ").any { sep ->
                val pos = track.title.indexOf(sep)
                pos >= 2 && pos < track.title.length - sep.length - 1
            }
            if (cleanSongShape) score += 70
            if ("official audio" in title) score += 110
            if ("official video" in title) score += 85
            if ("vevo" in uploaderText || "topic" in uploaderText) score += 80
            if (track.uploaderVerified) score += 90
            if (track.durationSeconds in 150..330) score += 35

            if (track.viewCount > 0L) {
                val popularity = kotlin.math.log10(track.viewCount.toDouble().coerceAtLeast(1.0))
                score += (popularity * 55.0).roundToInt()
                if (track.viewCount >= 1_000_000L) score += 25
                if (track.viewCount >= 10_000_000L) score += 25
                if (track.viewCount >= 100_000_000L) score += 20
            }
            score to track
        }

        if (candidates.isEmpty()) return null
        val top = candidates.sortedByDescending { it.first }.take(4)
        // Keep a little variety, but make the highest-quality / highest-popularity result clearly
        // more likely than before. Hard filters still outrank popularity absolutely.
        val weights = listOf(60, 24, 11, 5).take(top.size)
        val roll = Random.nextInt(weights.sum())
        var cursor = 0
        for (i in top.indices) {
            cursor += weights[i]
            if (roll < cursor) return top[i].second
        }
        return top.first().second
    }

    private fun canonicalCompareText(text: String): String {
        val lowered = text.lowercase(Locale.ROOT)
            .replace("đ", "dj")
            .replace("ð", "d")
        val decomposed = Normalizer.normalize(lowered, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
        return decomposed
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun normalizeArtistText(text: String): String = canonicalCompareText(text)
        .replace(Regex("\\b(official|music|vevo|records|recordings|topic|channel|band|grupa)\\b"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()


    private fun titleSides(track: TrackRef): Set<String> {
        val separators = listOf(" - ", " – ", " — ", " | ")
        for (sep in separators) {
            val i = track.title.indexOf(sep)
            if (i > 0 && i + sep.length < track.title.length) {
                return setOf(
                    normalizeArtistText(track.title.substring(0, i)),
                    normalizeArtistText(track.title.substring(i + sep.length))
                ).filter { it.length >= 3 }.toSet()
            }
        }
        return emptySet()
    }

    private fun artistAliases(track: TrackRef): Set<String> {
        // Artist identity must never include the song-title side of "Artist - Song".
        return primaryArtistAliases(track).filter { alias ->
            alias.split(' ').any { it.length >= 3 }
        }.toSet()
    }

    private fun titleArtistPrefix(track: TrackRef): String {
        val separators = listOf(" - ", " – ", " — ", " | ")
        for (sep in separators) {
            val i = track.title.indexOf(sep)
            if (i > 0) return normalizeArtistText(track.title.substring(0, i))
        }
        return ""
    }

    private fun sameArtistConfidence(a: TrackRef, b: TrackRef): Boolean {
        // If both titles expose an "Artist - Song" prefix, trust that over uploader channels.
        // Two different performers on the same label/channel must never create artist-only mode.
        val prefixA = titleArtistPrefix(a)
        val prefixB = titleArtistPrefix(b)
        if (prefixA.length >= 3 && prefixB.length >= 3) {
            return prefixA == prefixB || prefixA.contains(prefixB) || prefixB.contains(prefixA)
        }

        val uploaderA = normalizeArtistText(a.uploader)
        val uploaderB = normalizeArtistText(b.uploader)
        val genericUploaderWords = listOf("records", "recordings", "label", "music", "channel", "topic", "official")
        val uploaderLooksGeneric = genericUploaderWords.any { it in uploaderA || it in uploaderB }
        if (!uploaderLooksGeneric && uploaderA.length >= 3 && uploaderB.length >= 3 && uploaderA == uploaderB) return true

        val aliasesA = artistAliases(a)
        val aliasesB = artistAliases(b)
        return aliasesA.any { aa ->
            aliasesB.any { bb ->
                aa.length >= 4 && bb.length >= 4 && (aa == bb || aa.contains(bb) || bb.contains(aa))
            }
        }
    }

    private fun isSameArtistFamily(seed: TrackRef, candidate: TrackRef): Boolean {
        val seedAliases = artistAliases(seed)
        val candidateAliases = artistAliases(candidate)
        if (seedAliases.any { sa -> candidateAliases.any { ca ->
                sa.length >= 4 && ca.length >= 4 && (sa == ca || sa.contains(ca) || ca.contains(sa))
            } }) return true

        val stop = setOf(
            "official", "music", "video", "audio", "lyrics", "lyric", "records", "recordings",
            "topic", "channel", "band", "grupa", "the", "and", "feat", "ft"
        )
        fun words(text: String): Set<String> = canonicalCompareText(text)
            .split(' ')
            .map { it.trim() }
            .filter { it.length >= 4 && it !in stop }
            .toSet()

        val seedArtistWords = words(endlessArtistKey(seed))
        if (seedArtistWords.isEmpty()) return false
        val candidateWords = words(endlessArtistKey(candidate)) + words(candidate.uploader) + words(candidate.title)
        return seedArtistWords.any { it in candidateWords }
    }

    private fun primaryArtistAliases(track: TrackRef): Set<String> {
        val aliases = linkedSetOf<String>()
        val uploader = normalizeArtistText(track.uploader)
        if (uploader.length >= 3) aliases += uploader
        val separators = listOf(" - ", " – ", " — ", " | ")
        for (sep in separators) {
            val i = track.title.indexOf(sep)
            if (i > 0) {
                val prefix = normalizeArtistText(track.title.substring(0, i))
                if (prefix.length >= 3) aliases += prefix
                break
            }
        }
        return aliases
    }

    private fun isOriginalSeedArtist(candidate: TrackRef): Boolean {
        val candidateTitle = canonicalCompareText(candidate.title)
        val candidateAliases = primaryArtistAliases(candidate)
        return endlessSeeds.take(2).any { seed ->
            val seedAliases = primaryArtistAliases(seed) + endlessArtistKey(seed)
            seedAliases.filter { it.length >= 3 }.any { seedAlias ->
                candidateAliases.any { ca ->
                    ca == seedAlias || ca.contains(seedAlias) || seedAlias.contains(ca)
                } || candidateTitle == seedAlias || candidateTitle.startsWith("$seedAlias ")
            }
        }
    }

    private fun markEndlessAutoPlayed(track: TrackRef) {
        if (!endlessActive) return
        if (endlessSeeds.take(2).any { seed -> seed.url == track.url }) return
        if (endlessPlayedAutoUrls.add(track.url)) {
            endlessNonSeedSelections++
        }
    }

    private fun sceneSearchAnchor(scene: EndlessSceneProfile): String = when (scene) {
        EndlessSceneProfile.EX_YU -> "ex yu balkan"
        EndlessSceneProfile.ANGLO -> "english"
        EndlessSceneProfile.FRANCOPHONE -> "francophone french"
        EndlessSceneProfile.HISPANIC -> "spanish latin"
        EndlessSceneProfile.LUSOPHONE -> "portuguese brazil portugal"
        EndlessSceneProfile.DACH -> "german deutsch"
        EndlessSceneProfile.ITALIAN -> "italian italiano"
        EndlessSceneProfile.GREEK -> "greek"
        EndlessSceneProfile.TURKISH -> "turkish"
        EndlessSceneProfile.ARABIC -> "arabic"
        EndlessSceneProfile.SOUTH_ASIAN -> "hindi urdu indian"
        EndlessSceneProfile.EAST_SLAVIC -> "russian ukrainian"
        EndlessSceneProfile.KOREAN -> "korean"
        EndlessSceneProfile.JAPANESE -> "japanese"
        EndlessSceneProfile.GLOBAL -> ""
    }

    private fun classifyEndlessScene(a: TrackRef, b: TrackRef): EndlessSceneProfile {
        val sa = classifyTrackScene(a)
        val sb = classifyTrackScene(b)
        return when {
            sa == sb && sa != EndlessSceneProfile.GLOBAL -> sa
            sa == EndlessSceneProfile.GLOBAL -> sb
            sb == EndlessSceneProfile.GLOBAL -> sa
            else -> EndlessSceneProfile.GLOBAL
        }
    }

    private fun classifyTrackScene(track: TrackRef): EndlessSceneProfile {
        val raw = "${track.title} ${track.uploader}".lowercase(Locale.ROOT)
        val text = canonicalCompareText(raw)
        fun score(words: List<String>): Int = words.count { w ->
            Regex("(^|\\s)${Regex.escape(w)}(\\s|$)").containsMatchIn(text)
        }

        // Script is a very strong signal and avoids trying to maintain a country database.
        if (Regex("[\\u3040-\\u30ff\\u31f0-\\u31ff]").containsMatchIn(raw)) return EndlessSceneProfile.JAPANESE
        if (Regex("[\\uac00-\\ud7af]").containsMatchIn(raw)) return EndlessSceneProfile.KOREAN
        if (Regex("[\\u0600-\\u06ff]").containsMatchIn(raw)) return EndlessSceneProfile.ARABIC
        if (Regex("[\\u0370-\\u03ff]").containsMatchIn(raw)) return EndlessSceneProfile.GREEK
        if (Regex("[\\u0900-\\u097f]").containsMatchIn(raw)) return EndlessSceneProfile.SOUTH_ASIAN

        val dictionaries = listOf(
            EndlessSceneProfile.EX_YU to listOf(
                "miligram", "bulevari", "ljubav", "srce", "sreca", "zivot", "noc", "moja", "moje", "moj",
                "tvoja", "tvoje", "tvoj", "dodji", "dodi", "pjesma", "pesma", "pjeva", "peva", "kafana",
                "samo", "tebe", "meni", "zelim", "volim", "nikad", "zauvijek", "zauvek", "balkan", "ex yu"
            ),
            EndlessSceneProfile.FRANCOPHONE to listOf(
                "amour", "chanson", "coeur", "avec", "pour", "sans", "toujours", "jamais", "mon", "ma", "mes", "toi", "moi", "dans", "une", "des"
            ),
            EndlessSceneProfile.HISPANIC to listOf(
                "amor", "corazon", "contigo", "quiero", "vida", "noche", "beso", "besame", "siempre", "nunca", "para", "conmigo", "cancion", "latino"
            ),
            EndlessSceneProfile.LUSOPHONE to listOf(
                "amor", "coracao", "voce", "saudade", "beijo", "noite", "vida", "meu", "minha", "brasil", "portugal", "sertanejo"
            ),
            EndlessSceneProfile.DACH to listOf(
                "liebe", "herz", "nacht", "leben", "immer", "niemals", "mein", "meine", "dein", "deine", "deutsch", "schlager"
            ),
            EndlessSceneProfile.ITALIAN to listOf(
                "amore", "cuore", "vita", "notte", "sempre", "mai", "mio", "mia", "tuo", "tua", "italiano", "canzone"
            ),
            EndlessSceneProfile.TURKISH to listOf(
                "ask", "aşk", "kalp", "gece", "hayat", "seni", "benim", "senin", "turk", "turkish"
            ),
            EndlessSceneProfile.EAST_SLAVIC to listOf(
                "любовь", "сердце", "песня", "ночь", "жизнь", "моя", "тебя", "россия", "украина", "russian", "ukrainian"
            ),
            EndlessSceneProfile.ANGLO to listOf(
                "girls", "boys", "love", "heart", "night", "baby", "forever", "never", "you", "your", "english", "uk", "british"
            )
        )

        var best = EndlessSceneProfile.GLOBAL
        var bestScore = 0
        for ((scene, words) in dictionaries) {
            val s = score(words)
            if (s > bestScore) {
                bestScore = s
                best = scene
            }
        }
        // Require two lexical hits so a single universal word such as "amor" cannot lock a scene.
        return if (bestScore >= 2) best else EndlessSceneProfile.GLOBAL
    }

    private fun violatesLockedScene(track: TrackRef): Boolean {
        if (endlessSceneProfile == EndlessSceneProfile.GLOBAL) return false
        val candidateScene = classifyTrackScene(track)
        // Unknown metadata is allowed because many official uploads are only "Artist - Title".
        // A positively identified DIFFERENT language/scene is a hard reject before popularity.
        return candidateScene != EndlessSceneProfile.GLOBAL && candidateScene != endlessSceneProfile
    }

    private fun classifyEndlessGenre(a: TrackRef, b: TrackRef): EndlessGenreProfile {
        val text = canonicalCompareText("${a.title} ${a.uploader} ${b.title} ${b.uploader}")
        val popFolkSignals = listOf(
            "pop folk", "folk pop", "popfolk", "cajka", "cajke", "turbofolk", "turbo folk",
            "miligram", "aco pejovic", "sasa matic", "tanja savic", "aleksandra prijovic", "ceca",
            "dragana mirkovic", "seka aleksic", "dara bubamara", "ana bekuta", "lepa brena"
        )
        val folkSignals = listOf(
            "folk", "narodna", "narodne", "narodni", "izvorna", "izvorne", "sevdah", "sevdalinka",
            "tambura", "tamburica", "kolo", "gusle", "ganga", "etno", "kafana", "kafanska"
        )
        return when {
            popFolkSignals.any { it in text } -> EndlessGenreProfile.POP_FOLK
            folkSignals.any { it in text } -> EndlessGenreProfile.FOLK
            else -> EndlessGenreProfile.POP
        }
    }

    private fun looksLikeNarrativeNonSong(track: TrackRef): Boolean {
        val text = canonicalCompareText(track.title)
        val narrativePhrases = listOf(
            "otkrio", "otkrila", "otkriva", "rekao", "rekla", "kaze", "kazao", "kazala",
            "govori", "govorio", "govorila", "pricao", "pricala", "prica o", "ispricao", "ispricala",
            "objasnio", "objasnila", "priznao", "priznala", "progovorio", "progovorila",
            "reveals", "revealed", "says", "said", "talks about", "speaks about", "explains",
            "admits", "confesses", "interview", "intervju", "gostovanje", "razgovor"
        )
        return narrativePhrases.any { phrase ->
            Regex("(^|\\s)${Regex.escape(phrase)}(\\s|$)").containsMatchIn(text)
        }
    }

    private fun violatesLockedGenre(track: TrackRef): Boolean {
        val text = canonicalCompareText("${track.title} ${track.uploader}")
        val folkLean = listOf(
            "folk", "narodna", "narodne", "narodni", "izvorna", "izvorne", "sevdah", "sevdalinka",
            "tambura", "tamburica", "gusle", "ganga", "kafana", "kafanska", "turbofolk", "turbo folk",
            "cajka", "cajke"
        )
        val nationalistOrWar = listOf(
            "patriotska", "patriotske", "patriotic", "rodoljubiva", "rodoljubive", "rodoljubna",
            "nacionalisticka", "nacionalisticke", "nationalist", "nationalistic",
            "cetnik", "cetnici", "cetnicka", "ustasa", "ustase", "ustaska", "ratna pjesma", "ratne pjesme",
            "vojna pjesma", "vojne pjesme", "mars na", "bojna pjesma"
        )
        return when (endlessGenreProfile) {
            EndlessGenreProfile.POP -> folkLean.any { it in text } || nationalistOrWar.any { it in text }
            EndlessGenreProfile.POP_FOLK -> false // Friendly with FOLK by design.
            EndlessGenreProfile.FOLK -> false // Friendly with POP/FOLK by design.
        }
    }

    private fun rememberEndlessArtist(track: TrackRef) {
        val key = endlessArtistKey(track)
        if (key.isBlank()) return
        endlessRecentArtists.remove(key)
        endlessRecentArtists.add(key)
        while (endlessRecentArtists.size > 5) endlessRecentArtists.removeAt(0)
    }

    private fun endlessArtistKey(track: TrackRef): String {
        // Prefer the artist prefix from common "Artist - Song" titles. Comparison keys
        // are always Unicode-canonical so Ž/Z, accents and punctuation cannot bypass blocks.
        val separators = listOf(" - ", " – ", " — ", " | ")
        val titleArtist = separators
            .mapNotNull { sep ->
                val index = track.title.indexOf(sep)
                if (index > 0) track.title.substring(0, index) else null
            }
            .minByOrNull { it.length }
            .orEmpty()
        val normalizedTitleArtist = normalizeArtistText(titleArtist)
        if (normalizedTitleArtist.length >= 2) return normalizedTitleArtist

        return normalizeArtistText(track.uploader)
    }

    private fun endlessTrackKey(track: TrackRef): String {
        val separators = listOf(" - ", " – ", " — ", " | ")
        var songPart = track.title
        val uploader = normalizeArtistText(track.uploader)
        for (sep in separators) {
            val i = track.title.indexOf(sep)
            if (i > 0 && i + sep.length < track.title.length) {
                val leftRaw = track.title.substring(0, i)
                val rightRaw = track.title.substring(i + sep.length)
                val left = normalizeArtistText(leftRaw)
                val right = normalizeArtistText(rightRaw)
                songPart = when {
                    uploader.length >= 3 && (uploader.contains(left) || left.contains(uploader)) -> rightRaw
                    uploader.length >= 3 && (uploader.contains(right) || right.contains(uploader)) -> leftRaw
                    else -> rightRaw
                }
                break
            }
        }
        return songPart
            .lowercase(Locale.getDefault())
            .replace(Regex("\\([^)]*\\)|\\[[^]]*]"), " ")
            .replace(
                Regex("\\b(official|video|audio|lyrics|lyric|hd|hq|remastered|remaster|live|version|acoustic|unplugged|remix|mix|cover|concert|session|extended|edit|radio|sped|slowed|nightcore)\\b"),
                " "
            )
            .replace(Regex("\\b(19|20)\\d{2}\\b"), " ")
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .trim()
    }

    private fun updateEndlessFilterButtons() {
        fun style(button: Button, on: Boolean, label: String) {
            val color = if (on) R.color.orange_control else R.color.white
            button.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, color))
            button.setTextColor(ContextCompat.getColor(this, R.color.black))
            button.text = "$label ${if (on) "ON" else "OFF"}"
            button.isEnabled = !controlsLocked
        }
        style(binding.filterLive, allowLive, "LIVE")
        style(binding.filterCover, allowCover, "COVER")
        style(binding.filterOfficial, onlyOfficial, "ONLY OFFICIAL")
    }

    private fun requestEndlessVoiceSearch() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            launchSpeechRecognizer()
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun setupAudioFocusProtection() {
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setWillPauseWhenDucked(false)
            .setOnAudioFocusChangeListener { change ->
                when (change) {
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                        masterDuck = 0.35f
                        applyVolumes()
                    }
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                        resumeAAfterFocus = playerA.isPlaying
                        resumeBAfterFocus = playerB.isPlaying
                        masterDuck = 0.12f
                        applyVolumes()
                    }
                    AudioManager.AUDIOFOCUS_GAIN -> {
                        masterDuck = 1f
                        applyVolumes()
                        if (resumeAAfterFocus && !playerA.isPlaying && playerA.playbackState == Player.STATE_READY) playerA.play()
                        if (resumeBAfterFocus && !playerB.isPlaying && playerB.playbackState == Player.STATE_READY) playerB.play()
                        resumeAAfterFocus = false
                        resumeBAfterFocus = false
                    }
                    AudioManager.AUDIOFOCUS_LOSS -> {
                        resumeAAfterFocus = playerA.isPlaying
                        resumeBAfterFocus = playerB.isPlaying
                        masterDuck = 0.12f
                        applyVolumes()
                    }
                }
            }
            .build()
        audioManager.requestAudioFocus(audioFocusRequest)
    }

    private fun toggleControlLock() {
        if (!controlsLocked) {
            controlsLocked = true
            updateControlLockUi()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("ARE YOU SURE?")
            .setMessage("Unlock mixer controls?")
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("UNLOCK") { _, _ ->
                controlsLocked = false
                updateControlLockUi()
            }
            .show()
    }

    private fun updateControlLockUi() {
        binding.mixLock.visibility = if (endlessActive) View.VISIBLE else View.GONE
        binding.lockText.text = if (controlsLocked) "UNLOCK" else "LOCK"
        binding.lockText.setTextColor(ContextCompat.getColor(this, if (controlsLocked) R.color.white else R.color.black))
        binding.lockIcon.setImageResource(if (controlsLocked) R.drawable.ic_lock_closed else R.drawable.ic_lock_open)
        binding.mixLock.setBackgroundColor(ContextCompat.getColor(this, if (controlsLocked) R.color.red_control else R.color.green_control))

        binding.playA.isEnabled = !controlsLocked && playerA.mediaItemCount > 0
        binding.playB.isEnabled = !controlsLocked && playerB.mediaItemCount > 0
        binding.autoMix.isEnabled = !controlsLocked
        binding.crossfader.isEnabled = !controlsLocked
        binding.volumeA.isEnabled = !controlsLocked
        binding.volumeB.isEnabled = !controlsLocked
        // MASTER VOLUME is a safety/operational control and must remain available even while locked.
        binding.masterVolume.isEnabled = true
        binding.masterVolumeIcon.alpha = 1f
        binding.waveA.isEnabled = !controlsLocked
        binding.waveB.isEnabled = !controlsLocked
        binding.endlessAction.isEnabled = !controlsLocked
        binding.endlessSearchInput.isEnabled = !controlsLocked
        binding.endlessSearchButton.isEnabled = !controlsLocked
        binding.endlessVoiceButton.isEnabled = !controlsLocked
        updateEndlessFilterButtons()
        updateLoadButtons()
    }

    private fun launchSpeechRecognizer() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Search music")
        }
        runCatching { speechLauncher.launch(intent) }
            .onFailure { binding.endlessStatus.text = "Voice search unavailable" }
    }

    private fun formatTime(ms: Long): String {
        val total = (ms / 1000L).coerceAtLeast(0L)
        val m = total / 60
        val s = total % 60
        return "%d:%02d".format(m, s)
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized) {
            refreshDecks()
            if (!endlessActive && !endlessSeedMode) syncSeedsFromCurrentDecks()
        }
    }

    override fun onDestroy() {
        autoFadeJob?.cancel()
        endlessDiscoveryJob?.cancel()
        if (::audioFocusRequest.isInitialized) audioManager.abandonAudioFocusRequest(audioFocusRequest)
        playerA.release()
        playerB.release()
        super.onDestroy()
    }
}
