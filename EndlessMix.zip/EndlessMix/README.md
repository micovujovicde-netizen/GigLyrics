# EndlessMix

Two-deck Android mixer prototype.

Current functional build:
- A/B opens search directly; selecting a result loads that deck and closes search.
- Real narrow vertical waveform fills top-to-bottom while the stream is analysed.
- PLAY becomes available when ExoPlayer has enough buffer; PLAY is blue, PAUSE yellow.
- A/B load buttons are red.
- Independent volume faders and a simple L-R crossfader with no progress-fill effect.
- Time remaining per deck.
- CUE marker: tap to set first cue / return to cue; long-press to replace cue.
- AUTO MIX: white = off, orange = on; fixed 5-second crossfade when both decks are ready.
- Manual control cancels an active auto transition.
- Existing clean audio headroom is preserved.
