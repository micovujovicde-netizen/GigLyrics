# EndlessMix 2.1

- Mixer opens directly.
- Tap A or B to open Search for that deck.
- Choosing a result resolves the stream, loads it, and closes Search automatically.
- Real waveform runs vertically from top to bottom; empty deck is one vertical line.
- Vertical volume faders and bottom L-R crossfader.
- Linear crossfade with output headroom to reduce clipping/distortion.
