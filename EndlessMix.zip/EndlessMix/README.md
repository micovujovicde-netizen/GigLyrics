# EndlessMix

Simple two-deck live mixer for Android.

Current build:
- A / B opens search for that deck; selecting a result returns directly to the mixer.
- Slim vertical real waveform, progressively filled while analysis loads.
- Thick transparent green playhead follows playback and can be dragged/tapped to seek in PLAY or PAUSE.
- Separate vertical volume faders.
- AUTO MIX: fixed 5 second crossfade; white = OFF, orange = ON.
- Manual play/pause, seek, or crossfader movement interrupts an active auto fade.
- A/B buttons red, PLAY blue, PAUSE yellow.
- No BPM/TAP or CUE controls.
- Crossfader is kept high above Android navigation controls.
- Custom EM musical-note app icon.


## Build 2.4
- Web LOAD A/B controls with globe icon
- AUTO IS OFF / AUTO IS ON state labels
- Automix starts at the final 5 seconds and crossfades for 5 seconds
- More visible green seek/playhead on both decks
- Mixer controls remain in the upper half; lower half reserved for Endless Mix
