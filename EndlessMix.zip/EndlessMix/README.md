# EndlessMix

Black/white two-deck Android mixer prototype.

- Press A or B in the mixer to search directly for that deck.
- Search resolves a playable stream before returning to the mixer.
- Compact real waveform overview shows the song structure.
- Empty deck shows only a single line.
- Large vertical volume faders plus bottom crossfader.
