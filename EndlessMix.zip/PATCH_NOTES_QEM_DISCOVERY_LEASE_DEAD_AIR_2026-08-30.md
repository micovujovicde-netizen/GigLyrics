# QEM discovery lease + dead-air continuity fix — 2026-08-30

Observed failure: a FREE deck waited for several minutes while `qemDiscoveryJob.isActive == true`; NewPipe/OkHttp could remain blocked and the watchdog trusted `isActive` forever. When ACTIVE ended, Hotel Manager repeatedly armed recovery but no credible NEXT path appeared.

Fixes:
- Added QEM discovery start/progress heartbeat and bounded lease: 14 s idle / 24 s hard age.
- Added flight token separate from QEM filter generation. A stale/blocked flight can be invalidated without invalidating already prepared QEM candidates; late results are ignored and cannot clear the replacement job.
- Continuous Play Guard keeps healthy single-flight behavior but takes over a stale flight instead of waiting forever.
- Dead air gets a shorter 6 s takeover lease, with 10 s forced-restart throttle to prevent restart storms.
- Hotel Manager no longer treats stale `isActive` as a credible continuation path.
- Dead-air recovery no longer clears a candidate that arrives during recovery; it loads the queued candidate immediately.
- Reduced repeated WAIT / RED_ALERT / ARM log spam to roughly 5 s while recovery logic continues to run.
- NewPipe downloader is physically bounded: connect 6 s, read/write 8 s, whole call 9 s (instead of 30 s read wait).
- Added progress heartbeats around serialized artist-search passes.

Safety:
- Never stops/seeks/replaces healthy ACTIVE A/B.
- JUST A PARTY and LOVE filtering logic unchanged by this continuity patch.
- Existing Gordian single-flight principle retained; stale replacement is lease-based, not an 11-second blind cancel loop.
