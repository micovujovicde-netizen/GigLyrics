# QEM RELAXED watchdog completion fix — 2026-09-01

- Keep the first QEM FREE-deck discovery attempt STRICT.
- At exactly 10 seconds FREE, promote once to RELAXED discovery.
- Do not cancel/restart an active RELAXED discovery every later 10-second watchdog tick.
- Later watchdog ticks only request NEXT/recheck; the existing 18-second QEM discovery liveness guard remains responsible for genuinely stalled jobs.
- REGION remains hard in RELAXED mode.
- No A/B playback, transition, BPM, Deck Z, history, or admission-policy changes in this patch.
