# Deck J — single authority / proven C-D transport discipline

- Deck J remains the ONLY QEM candidate/metadata authority.
- C/D remain passive parking only; no A/B rights, ranking, filtering or metadata authority.
- Reused the old reliable C/D transport discipline: select -> resolve -> validate -> atomic FREE claim -> A/B.
- Added one global Deck-J transport mutex. Only one J->resolver->A/B handoff may run at once.
- FREE-deck watchdog treats an active J transport as healthy work and cannot spawn competing serials.
- J now keeps a small reserve batch of already-approved candidates; a failed resolve retries the next reserve before a fresh discovery.
- STRICT miss gets one LOCAL RELAXED Deck-J pass before server/live fallback.
- RELAXED keeps REGION and STYLE hard; only country/era may broaden.
- Server/live is supplier-only fallback after J local exhaustion.
- A/B playback, manual ADD TO MIX protection, Deck Z and transition code remain untouched.
