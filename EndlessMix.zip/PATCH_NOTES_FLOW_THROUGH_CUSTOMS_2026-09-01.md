# FLOW-THROUGH CUSTOMS — 2026-09-01

Base: clean EndlessMix-1.zip.

Minimal change only. No new discovery motor, state machine, watchdog, polling loop, recovery loop or network dependency.

Candidate admission now passes a pure local customs gate in this order:

REGION/COUNTRY -> STYLE -> DECADE

- REGION/COUNTRY reuses the existing locked scene evidence.
- STYLE reuses the existing locked genre evidence.
- DECADE is hard only when both seed and candidate already contain explicit year evidence; unknown year never launches metadata work and never blocks playback.
- BPM/ENERGY remain downstream/advisory and can never stall A/B.
- ACTIVE playback path is unchanged.
- Fonoteka/discovery timing is unchanged.
