# BASIC / 1 ARTIST physical removal — 2026-09-01
- AutoDiscoveryMotor now has only NONE and QEM.
- Basic queued-discovery engine body removed.
- 1 ARTIST popup/known/legacy discovery family removed.
- EMPTY-deck continuity routes only to QEM/Deck J.
- Hidden legacy views remain GONE only for ViewBinding compatibility and have no click listeners.
