# FREE deck cleanup + continuity-first QEM handoff — 2026-08-31

- Finished FREE deck no longer visually keeps the old ADD TO MIX title/waveform while waiting for QEM.
- Shows `PREPARING NEXT…` immediately after the deck is freed.
- Champagne/Fonoteka/F enrichment is capped at 4 seconds on the physical handoff path.
- If enrichment exceeds that budget, playable NEXT is installed for continuity and enrichment continues asynchronously; SYNC remains unsafe until evidence is available.
- Existing A/B fade/transition ownership was not changed.
