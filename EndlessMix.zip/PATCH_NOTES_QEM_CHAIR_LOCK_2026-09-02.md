# QEM physical chair lock hotfix — 2026-09-02

- Removed the 2-second repeated FREE-deck refill loop (the "army auditions").
- After transition, a FREE deck asks NEXT PLEASE exactly once.
- Added per-physical-deck QEM chair ownership (`qemPhysicalOwnerA/B`).
- The first accepted automatic QEM candidate claims that deck immediately, before async prepare/UI timing can race.
- Any later automatic QEM candidate for the same deck is parked/queued and logged as `QEM_CHAIR_OCCUPIED`; it cannot overwrite the owner.
- Chair ownership is released only when the deck is genuinely freed or that exact candidate genuinely fails.
- Manual USER ADD TO MIX remains superior and clears automatic QEM chair ownership for its target deck.
