# Gordian continuity fix — 2026-08-30

- Removed the 11-second QEM watchdog cancel/restart loop that could repeatedly kill valid LOVE discovery before it completed.
- Continuous Play Guard is now single-flight: if QEM discovery is alive, it waits/observes; it only kicks when no discovery exists or a queued candidate is ready.
- Hotel Manager dead-air branch now actively guarantees a continuation path: load an already queued candidate immediately into the expected free deck, or start the current discovery motor if no search is alive.
- ACTIVE A/B playback remains untouched by these watchdog actions.
- Added diagnostics: CONTINUOUS_PLAY_GUARD_WAIT_QEM, HOTEL_MANAGER_DEAD_AIR_LOAD_QUEUED, HOTEL_MANAGER_DEAD_AIR_KICK_QEM/BASIC.
