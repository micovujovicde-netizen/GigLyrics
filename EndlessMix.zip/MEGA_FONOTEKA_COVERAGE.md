# EndlessMix Mega Fonoteka — coverage report

Generated: 2026-09-01T06:49:58+00:00

- Total track seeds: **1600**
- QEM top-level regions: **16**
- Target: **100 unique tracks per top-level region**
- Exact artist matches to current app `fonoteka.json`: **1177/1600 (73.6%)**
- Tracks with inherited country tags: **1177**
- Tracks with inherited style tags: **1177**
- Tracks with inherited era tags: **1177**

## Per-region coverage

| Region | Seeds | Exact artist match | Country tags | Style tags | Era tags |
|---|---:|---:|---:|---:|---:|
| EX_YU | 100 | 83 | 83 | 83 | 83 |
| ANGLO | 100 | 77 | 77 | 77 | 77 |
| LATINO_SPANISH | 100 | 74 | 74 | 74 | 74 |
| PORTUGUESE | 100 | 84 | 84 | 84 | 84 |
| FRANCOPHONE | 100 | 57 | 57 | 57 | 57 |
| GERMAN | 100 | 77 | 77 | 77 | 77 |
| ITALIAN | 100 | 78 | 78 | 78 | 78 |
| GREEK | 100 | 80 | 80 | 80 | 80 |
| TURKISH | 100 | 90 | 90 | 90 | 90 |
| SCANDINAVIA | 100 | 70 | 70 | 70 | 70 |
| EASTERN_EUROPE | 100 | 78 | 78 | 78 | 78 |
| ARABIC | 100 | 77 | 77 | 77 | 77 |
| INDIA_SOUTH_ASIA | 100 | 96 | 96 | 96 | 96 |
| JAPAN | 100 | 59 | 59 | 59 | 59 |
| KOREA | 100 | 26 | 26 | 26 | 26 |
| AFRICA_SUBSAHARAN | 100 | 71 | 71 | 71 | 71 |

## Important scope note

This v1 is **100 tracks per top-level QEM REGION**, with COUNTRY / STYLE / ERA tags inherited from the app’s current artist Fonoteka wherever the artist matched exactly.

It is **not yet 100 tracks for every individual COUNTRY sub-filter**. Expanding every country to 100 tracks is a larger phase-2 catalog (roughly several thousand additional track identities, depending on which country choices are actually selectable).

No stream URL is stored. A future runtime integration should still resolve the stream live and re-check current HistoryGuard, BORDER/identity and playability before handoff. This file is a seed library, not played history.

## Validation

- Exactly 100 unique artist/title identities per top-level QEM region.
- JSON parses successfully.
- No duplicate `(region, normalized artist, normalized title)` keys.
- Current app filter snapshot is embedded in the catalog for integration/version checks.
