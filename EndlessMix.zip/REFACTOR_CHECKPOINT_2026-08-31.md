# EndlessMix — Music Hotel Cleanup Checkpoint 1

Goal: reorganize responsibilities without changing playback/discovery behavior.

## Extracted from MixerActivity

### HistoryGuard
Owns only:
- persistent actually-played history
- 20-track song hard ban
- 15-track credited-performer hard ban
- canonical text normalization
- featured/duet/collaboration performer splitting

It has no player, deck, QEM, BASIC, UI, or transition access.

### DeckZController
Owns only Deck Z audio machinery:
- Android TTS lifecycle
- voice selection
- speech render-to-file
- primary voice MediaPlayer
- reverb + BPM-derived echo
- busy/ready state
- duck animation

It cannot access A/B ExoPlayers. MixerActivity supplies current BPM and receives a scalar duck value.

### AidjSyncEngine
Pure decision/math layer for Champagne sync:
- validates BPM/grid evidence
- speed-delta gate
- beat phase
- pre-roll wait
- cue lead
- SYNC_READY vs SYNC_SKIP decision

It cannot play, pause, seek, or alter a deck.

### TransitionEngine
Pure transition policy:
- normal vs Champagne fade duration
- fade direction
- crossfader interpolation
- step count

Physical playback commands remain in MixerActivity for now.

## Intentionally NOT moved in this checkpoint

BASIC discovery, QEM discovery/virtual crates, and the physical A/B recovery state machine remain in MixerActivity until this checkpoint gets a green Android build. Those areas contain the continuity-critical ownership loops and should be extracted only from a confirmed buildable base.

## Next safe extraction order

1. PlaybackController — A/B prepare/play/pause/deck-state ownership only.
2. TransitionEngine phase 2 — move actual transition orchestration after PlaybackController exists.
3. BasicDiscoveryEngine — BASIC candidate search/queue/anchor logic.
4. QemEngine — QEM session filters, candidate discovery, virtual C/D crates and atomic handoff.
5. UI glue — leave MixerActivity as lifecycle + binding + event routing.

Target final role of MixerActivity: Android lifecycle, binding, permissions/activity results, and delegation only.
