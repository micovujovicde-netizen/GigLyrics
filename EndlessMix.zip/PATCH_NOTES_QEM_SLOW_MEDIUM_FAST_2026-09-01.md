# QEM SLOW / MEDIUM / FAST

- Removed the visible LOVE SONGS and JUST A PARTY controls.
- QEM drawer now has three equal musical-speed controls: SLOW, MEDIUM, FAST.
- The old quick-drawer CROSSFADE button is hidden; normal mixer crossfade control remains.
- SLOW/MEDIUM/FAST are wired to the existing tempoBand session state.
- Deck J local candidates are filtered from already-known BPM + ENERGY metadata.
- No local audio BPM/energy analysis is started by these buttons.
- Unknown BPM+ENERGY entries are skipped while a speed band is selected.
- REGION / COUNTRY / STYLE / ERA remain independent QEM filters.
