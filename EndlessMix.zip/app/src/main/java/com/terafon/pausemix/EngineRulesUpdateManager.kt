package com.terafon.pausemix

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/**
 * Conservative remote compatibility updater.
 * Downloads JSON rules only; never executable Kotlin/Java/native code or codec binaries.
 * New rules are last-known-good for the NEXT app session and never touch ACTIVE playback.
 */
class EngineRulesUpdateManager(private val context: Context) {
    companion object {
        const val ACTIVE_FILE = "engine_rules_active.json"
        private const val TEMP_FILE = "engine_rules_download.tmp"
        private const val PREFS = "engine_rules_update"
        private const val LAST_CHECK = "last_check_ms"
        private const val CHECK_INTERVAL_MS = 24L * 60L * 60L * 1000L
        private const val MAX_RULES_BYTES = 128 * 1024
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    suspend fun checkDaily(): Boolean = withContext(Dispatchers.IO) {
        val manifestUrl = BuildConfig.ENGINE_RULES_MANIFEST_URL.trim()
        if (manifestUrl.isBlank()) return@withContext false

        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (now - prefs.getLong(LAST_CHECK, 0L) < CHECK_INTERVAL_MS) return@withContext false
        prefs.edit().putLong(LAST_CHECK, now).apply()

        runCatching {
            val manifestBytes = getBytes(manifestUrl, 32 * 1024) ?: return@runCatching false
            val manifest = JSONObject(manifestBytes.toString(Charsets.UTF_8))
            val schema = manifest.optString("schema_version")
            val expectedSha = manifest.optString("sha256").lowercase()
            val expectedSize = manifest.optLong("size_bytes", -1L)
            val downloadUrl = manifest.optString("download_url").ifBlank {
                manifestUrl.substringBeforeLast('/') + "/engine_rules.json"
            }
            if (schema != "1" || expectedSha.length != 64) return@runCatching false
            if (expectedSize !in 1..MAX_RULES_BYTES.toLong()) return@runCatching false

            val bytes = getBytes(downloadUrl, MAX_RULES_BYTES) ?: return@runCatching false
            if (bytes.size.toLong() != expectedSize || sha256(bytes) != expectedSha) return@runCatching false
            val parsed = JSONObject(bytes.toString(Charsets.UTF_8))
            if (parsed.optString("schema_version") != "1") return@runCatching false

            // Whitelist-only schema. Unknown fields are harmless; these are the only currently
            // executable knobs. No field can alter deck/state-machine behavior.
            parsed.optBoolean("youtube_source_enabled", true)
            parsed.optBoolean("allow_muxed_fallback", true)
            parsed.optJSONArray("preferred_audio_mime_order")
            parsed.optJSONArray("disabled_audio_mime_types")
            parsed.optInt("min_engine_version", 0)

            val active = File(context.filesDir, ACTIVE_FILE)
            if (active.isFile && sha256(active.readBytes()) == expectedSha) return@runCatching false
            val tmp = File(context.filesDir, TEMP_FILE)
            tmp.writeBytes(bytes)
            if (!tmp.renameTo(active)) {
                active.writeBytes(bytes)
                tmp.delete()
            }
            true
        }.getOrDefault(false)
    }

    private fun getBytes(url: String, maxBytes: Int): ByteArray? {
        val req = Request.Builder().url(url).header("User-Agent", "EndlessMix-EngineRules/1.0").build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return null
            val bytes = r.body?.bytes() ?: return null
            return if (bytes.size <= maxBytes) bytes else null
        }
    }

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(bytes).joinToString("") { "%02x".format(it) }
}
