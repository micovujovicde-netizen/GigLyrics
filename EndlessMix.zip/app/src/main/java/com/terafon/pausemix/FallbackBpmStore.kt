package com.terafon.pausemix

import android.content.Context
import java.io.File
import java.util.LinkedHashMap

/**
 * F-lane BPM fallback cache.
 *
 * This store is intentionally separate from Cloudflare/D1/Deezer metadata.
 * It is written only by the on-device TempoAnalyzer after the server BPM lane
 * has failed to return a BPM. Values from here are informational fallback only.
 */
class FallbackBpmStore(context: Context) {
    data class Entry(val bpm: Float, val confidence: Float)

    private val file = File(context.filesDir, "endlessmix_f_bpm_fallback.tsv")
    private val lock = Any()
    private val rows = LinkedHashMap<String, Entry>(512, 0.75f, true)
    private var loaded = false
    private val maxRows = 4000

    private fun key(artistKey: String, titleKey: String): String = "$artistKey\t$titleKey"

    private fun ensureLoaded() {
        if (loaded) return
        loaded = true
        if (!file.exists()) return
        runCatching {
            file.forEachLine { line ->
                val p = line.split('\t')
                if (p.size >= 4) {
                    val bpm = p[2].toFloatOrNull()
                    val confidence = p[3].toFloatOrNull()
                    if (bpm != null && confidence != null && bpm in 30f..300f) {
                        rows[key(p[0], p[1])] = Entry(bpm, confidence)
                    }
                }
            }
        }
    }

    fun get(artistKey: String, titleKey: String): Entry? = synchronized(lock) {
        ensureLoaded()
        rows[key(artistKey, titleKey)]
    }

    fun put(artistKey: String, titleKey: String, bpm: Float, confidence: Float) = synchronized(lock) {
        if (artistKey.isBlank() || titleKey.isBlank() || bpm !in 30f..300f) return@synchronized
        ensureLoaded()
        rows[key(artistKey, titleKey)] = Entry(bpm, confidence)
        while (rows.size > maxRows) {
            val first = rows.entries.iterator()
            if (first.hasNext()) {
                first.next()
                first.remove()
            } else break
        }
        runCatching {
            file.bufferedWriter().use { out ->
                for ((k, v) in rows) {
                    val split = k.indexOf('\t')
                    if (split <= 0) continue
                    out.append(k.substring(0, split)).append('\t')
                    out.append(k.substring(split + 1)).append('\t')
                    out.append(v.bpm.toString()).append('\t')
                    out.append(v.confidence.toString()).append('\n')
                }
            }
        }
    }
}
