package com.terafon.pausemix

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/**
 * Safe, playback-independent fonoteka updater.
 *
 * GitHub Actions automatically provides GITHUB_REPOSITORY/GITHUB_REF_NAME at build time,
 * so BuildConfig.FONOTEKA_MANIFEST_URL points at the manifest in the same repository.
 * If a local/non-GitHub build has no URL, this silently stays on the bundled database.
 *
 * The updater never mutates a live QEM object or either audio deck. A validated download becomes
 * the last-known-good file for the next Activity/app session.
 */
class FonotekaUpdateManager(private val context: Context) {
    companion object {
        const val ACTIVE_FILE = "fonoteka_active.json"
        private const val TEMP_FILE = "fonoteka_download.tmp"
        private const val PREFS = "fonoteka_update"
        private const val LAST_CHECK = "last_check_ms"
        private const val CHECK_INTERVAL_MS = 24L * 60L * 60L * 1000L
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    suspend fun checkDaily(): Boolean = withContext(Dispatchers.IO) {
        val manifestUrl = BuildConfig.FONOTEKA_MANIFEST_URL.trim()
        if (manifestUrl.isBlank()) return@withContext false

        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (now - prefs.getLong(LAST_CHECK, 0L) < CHECK_INTERVAL_MS) return@withContext false
        // Throttle immediately; a network failure must never create a retry storm during playback.
        prefs.edit().putLong(LAST_CHECK, now).apply()

        runCatching {
            val manifestText = getText(manifestUrl) ?: return@runCatching false
            val manifest = JSONObject(manifestText)
            val downloadUrl = manifest.optString("download_url").ifBlank {
                manifestUrl.substringBeforeLast('/') + "/fonoteka.json"
            }
            val expectedSha = manifest.optString("sha256").lowercase()
            val expectedSize = manifest.optLong("size_bytes", -1L)
            val expectedSchema = manifest.optString("schema_version")
            if (expectedSha.length != 64 || expectedSchema.isBlank()) return@runCatching false

            val bundledSchema = context.assets.open("fonoteka.json").bufferedReader().use {
                JSONObject(it.readText()).optString("schema_version")
            }
            if (bundledSchema.isNotBlank() && bundledSchema != expectedSchema) return@runCatching false

            val bytes = getBytes(downloadUrl) ?: return@runCatching false
            if (expectedSize >= 0L && bytes.size.toLong() != expectedSize) return@runCatching false
            if (sha256(bytes) != expectedSha) return@runCatching false
            val parsed = JSONObject(bytes.toString(Charsets.UTF_8))
            if (parsed.optString("schema_version") != expectedSchema) return@runCatching false
            if (parsed.optJSONObject("artists") == null || parsed.optJSONObject("pools") == null) return@runCatching false

            val active = File(context.filesDir, ACTIVE_FILE)
            if (active.isFile && sha256(active.readBytes()) == expectedSha) return@runCatching false
            val tmp = File(context.filesDir, TEMP_FILE)
            tmp.writeBytes(bytes)
            if (!tmp.renameTo(active)) {
                active.writeBytes(bytes)
                tmp.delete()
            }
            true
        }.getOrDefault(false)
    }

    private fun getText(url: String): String? = getBytes(url)?.toString(Charsets.UTF_8)

    private fun getBytes(url: String): ByteArray? {
        val req = Request.Builder().url(url).header("User-Agent", "EndlessMix-Fonoteka/1.0").build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return null
            return r.body?.bytes()
        }
    }

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(bytes).joinToString("") { "%02x".format(it) }
}
