package com.terafon.pausemix

import android.content.Context
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.LoadControl

/** Process-lifetime holder for the two physical audio decks.
 *  The Activity is only a UI/controller attachment; opening another app must not destroy playback.
 */
object PlaybackRuntime {
    @Volatile private var playerA: ExoPlayer? = null
    @Volatile private var playerB: ExoPlayer? = null

    @Synchronized
    fun acquire(context: Context, loadControlA: LoadControl, loadControlB: LoadControl): Pair<ExoPlayer, ExoPlayer> {
        val app = context.applicationContext
        val a = playerA ?: ExoPlayer.Builder(app).setLoadControl(loadControlA).build().also { playerA = it }
        val b = playerB ?: ExoPlayer.Builder(app).setLoadControl(loadControlB).build().also { playerB = it }
        return a to b
    }

    @Synchronized
    fun releaseAll() {
        playerA?.release()
        playerB?.release()
        playerA = null
        playerB = null
    }
}
