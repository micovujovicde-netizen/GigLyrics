package com.terafon.pausemix

import android.content.Context
import android.os.SystemClock
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Persistent crash-flight recorder. Diagnostics only: it never touches A/B playback or DJ state.
 */
object CrashFlightRecorder {
    private const val PREFS = "endlessmix_crash_flight"
    private const val KEY_SESSION_OPEN = "session_open"
    private const val KEY_SESSION_START = "session_start"
    private const val KEY_LATEST_CRASH = "latest_crash"
    private const val KEY_LATEST_CRASH_EPOCH = "latest_crash_epoch"
    private const val KEY_ACK_CRASH = "ack_crash"
    private val installed = AtomicBoolean(false)
    @Volatile private var latestState: String = "state=unavailable"

    fun install(context: Context) {
        val app = context.applicationContext
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val previousStart = prefs.getLong(KEY_SESSION_START, 0L)
        val previousOpen = prefs.getBoolean(KEY_SESSION_OPEN, false)
        val lastCrashEpoch = prefs.getLong(KEY_LATEST_CRASH_EPOCH, 0L)

        if (previousOpen && previousStart > 0L && lastCrashEpoch < previousStart) {
            appendPlaybackLine(app, "UNCLEAN_PROCESS_DEATH previousSessionStart=$previousStart detectedAt=$now")
        }

        prefs.edit()
            .putBoolean(KEY_SESSION_OPEN, true)
            .putLong(KEY_SESSION_START, now)
            .apply()

        val latestCrash = prefs.getString(KEY_LATEST_CRASH, null)
        val ackCrash = prefs.getString(KEY_ACK_CRASH, null)
        if (!latestCrash.isNullOrBlank() && latestCrash != ackCrash && File(app.filesDir, latestCrash).exists()) {
            appendPlaybackLine(app, "PREVIOUS_CRASH_FOUND file=$latestCrash")
        }

        if (!installed.compareAndSet(false, true)) return
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                freezeCrashSnapshot(app, thread, error)
            } catch (_: Throwable) {
                // The recorder must never replace or swallow the real crash.
            }
            previous?.uncaughtException(thread, error)
        }
    }

    fun updateState(summary: String) {
        latestState = summary
    }

    fun markNormalClose(context: Context, reason: String) {
        val app = context.applicationContext
        appendPlaybackLine(app, "NORMAL_CLOSE reason=$reason")
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_SESSION_OPEN, false).apply()
    }

    fun latestCrashFile(context: Context): File? {
        val app = context.applicationContext
        val name = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_LATEST_CRASH, null)
            ?.takeIf { it.isNotBlank() }
            ?: return null
        return File(app.filesDir, name).takeIf { it.exists() }
    }

    fun acknowledgeLatestCrash(context: Context) {
        val app = context.applicationContext
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val latest = prefs.getString(KEY_LATEST_CRASH, null) ?: return
        prefs.edit().putString(KEY_ACK_CRASH, latest).apply()
    }

    fun clearLatestCrash(context: Context) {
        val app = context.applicationContext
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val latest = prefs.getString(KEY_LATEST_CRASH, null)
        if (!latest.isNullOrBlank()) runCatching { File(app.filesDir, latest).delete() }
        prefs.edit().remove(KEY_LATEST_CRASH).remove(KEY_ACK_CRASH).apply()
    }

    private fun freezeCrashSnapshot(context: Context, thread: Thread, error: Throwable) {
        val now = System.currentTimeMillis()
        val sw = StringWriter()
        error.printStackTrace(PrintWriter(sw))
        appendPlaybackLine(context, "FATAL thread=${thread.name} ${error.javaClass.name}: ${error.message}")

        data class BbLine(val epoch: Long, val source: String, val raw: String)
        val sources = listOf(
            "PLAYBACK/QEM" to "endlessmix_flight.txt",
            "FONOTEKA" to "endlessmix_fonoteka_flight.txt",
            "BPM" to "endlessmix_bpm_flight.txt",
            "AIDJ/DECK-Z" to "endlessmix_aidj_flight.txt"
        )
        val tail = sources.flatMap { (source, fileName) ->
            val file = File(context.filesDir, fileName)
            if (!file.exists()) emptyList() else file.readLines().takeLast(250).mapNotNull { line ->
                val epoch = line.substringBefore(" | ").trim().toLongOrNull() ?: return@mapNotNull null
                BbLine(epoch, source, line)
            }
        }.sortedBy { it.epoch }.takeLast(700)

        val fileName = "endlessmix_crash_$now.txt"
        val out = File(context.filesDir, fileName)
        out.writeText(buildString {
            appendLine("ENDLESSMIX CRASH_SNAPSHOT")
            appendLine("epoch=$now elapsed=${SystemClock.elapsedRealtime()}")
            appendLine("thread=${thread.name}")
            appendLine("exception=${error.javaClass.name}")
            appendLine("message=${error.message}")
            appendLine("STATE")
            appendLine(latestState)
            appendLine()
            appendLine("STACK TRACE")
            appendLine(sw.toString())
            appendLine("RECENT BB TAIL")
            tail.forEach { appendLine("[${it.source}] ${it.raw}") }
        })

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_LATEST_CRASH, fileName)
            .putLong(KEY_LATEST_CRASH_EPOCH, now)
            .remove(KEY_ACK_CRASH)
            .apply()
    }

    private fun appendPlaybackLine(context: Context, event: String) {
        runCatching {
            val file = File(context.filesDir, "endlessmix_flight.txt")
            val line = "${System.currentTimeMillis()} | ${SystemClock.elapsedRealtime()} | $event\n"
            file.appendText(line)
            if (file.length() > 64 * 1024) {
                file.writeText(file.readLines().takeLast(180).joinToString("\n", postfix = "\n"))
            }
        }
    }
}
