package com.terafon.pausemix

import android.content.Context
import org.json.JSONObject
import java.io.File

/**
 * Read-only runtime view of the remotely updateable compatibility/rules layer.
 * It intentionally cannot alter deck state, transitions, or executable code.
 */
object EngineRulesStore {
    @Volatile var allowMuxedFallback: Boolean = true
        private set
    @Volatile var sourceEnabled: Boolean = true
        private set

    fun initialize(context: Context) {
        val active = File(context.filesDir, EngineRulesUpdateManager.ACTIVE_FILE)
        val text = runCatching {
            if (active.isFile) active.readText()
            else context.assets.open("engine_rules.json").bufferedReader().use { it.readText() }
        }.getOrNull() ?: return
        runCatching {
            val root = JSONObject(text)
            if (root.optString("schema_version") != "1") return@runCatching
            sourceEnabled = root.optBoolean("youtube_source_enabled", true)
            allowMuxedFallback = root.optBoolean("allow_muxed_fallback", true)
        }
    }
}
