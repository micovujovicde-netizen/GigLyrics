package com.terafon.pausemix

/** Pure transition timing/curve policy. Physical player commands stay outside this class. */
class TransitionEngine(
    private val normalFadeMs: Long,
    private val champagneFadeMs: Long,
    val steps: Int = 50
) {
    data class Plan(val durationMs: Long, val startCross: Float, val endCross: Float, val steps: Int)

    fun plan(fromA: Boolean, champagne: Boolean, currentCross: Float): Plan = Plan(
        durationMs = if (champagne) champagneFadeMs else normalFadeMs,
        startCross = currentCross,
        endCross = if (fromA) 1f else 0f,
        steps = steps
    )

    fun crossAt(plan: Plan, step: Int): Float {
        val t = step.coerceIn(0, plan.steps) / plan.steps.toFloat()
        return plan.startCross + (plan.endCross - plan.startCross) * t
    }
}
