package com.terafon.pausemix

import android.content.Context
import com.terafon.pausemix.model.TrackRef

/**
 * DECK J — Jurassic/KRDO logical authority.
 *
 * J is NOT a physical player. A/B remain the only playback decks.
 * J owns QEM track identity, primary offline metadata and candidate admission.
 *
 * C/D are passive parking shelves only:
 * they may hold candidates already admitted by J, but they cannot choose,
 * reject, rerank, retarget, replace or otherwise command A/B.
 */
internal class DeckJ(context: Context) {
    private val vault = QemTrackVault(context)

    fun metadata(artist: String, title: String): QemTrackVault.Metadata? =
        vault.findMetadata(artist, title)

    fun candidates(
        regionKeys: Set<String>,
        country: String?,
        styleKeys: Set<String>,
        eraKeys: Set<String>,
        relaxedRegionOnly: Boolean,
        artistPool: List<QemFonoteka.ArtistChoice>,
        limit: Int
    ): List<QemTrackVault.Pick> = vault.pick(
        regionKeys = regionKeys,
        country = country,
        styleKeys = styleKeys,
        eraKeys = eraKeys,
        relaxedRegionOnly = relaxedRegionOnly,
        artistPool = artistPool,
        limit = limit
    )

    fun learnValidated(
        tracks: List<TrackRef>,
        artist: QemFonoteka.ArtistChoice,
        sessionCountry: String?
    ): Int = vault.learnValidated(tracks, artist, sessionCountry)
}
