package com.terafon.pausemix

class TapTempo {
    private val taps = ArrayDeque<Long>()

    fun tap(now: Long = System.currentTimeMillis()): Int? {
        taps.addLast(now)
        while (taps.size > 6) taps.removeFirst()
        if (taps.size < 3) return null

        val values = taps.toList()
        val intervals = values.zipWithNext { a, b -> b - a }
            .filter { it in 250L..2000L }
        if (intervals.size < 2) return null

        val avgMs = intervals.average()
        return (60000.0 / avgMs).toInt().coerceIn(30, 240)
    }

    fun reset() = taps.clear()
}
