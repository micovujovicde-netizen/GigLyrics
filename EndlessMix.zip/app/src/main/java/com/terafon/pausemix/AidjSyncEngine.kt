package com.terafon.pausemix

import kotlin.math.abs
import kotlin.math.roundToInt

/** Pure 🍾 beat/tempo decision logic. No Android player, UI or coroutine ownership. */
class AidjSyncEngine(
    private val gridConfidenceFloor: Float,
    private val maxSpeedDelta: Float
) {
    sealed interface Decision {
        data class Ready(
            val targetSpeed: Float,
            val preRollWaitMs: Long,
            val cueLeadMs: Long,
            val targetCueMs: Long,
            val targetFirstBeatMs: Long
        ) : Decision

        data class Skip(val reason: String, val rawSpeed: Float? = null) : Decision
    }

    fun plan(
        sourceBpm: Float?,
        targetBpm: Float?,
        sourceSyncSafe: Boolean,
        targetSyncSafe: Boolean,
        sourceGrid: BeatGridAnalyzer.Grid?,
        targetGrid: BeatGridAnalyzer.Grid?,
        sourcePositionMs: Long
    ): Decision {
        if (sourceBpm == null || targetBpm == null) return Decision.Skip("missing_bpm_evidence")
        if (!sourceSyncSafe || !targetSyncSafe) return Decision.Skip("uncertain_f_bpm")
        if (sourceGrid == null || targetGrid == null) return Decision.Skip("grid_not_ready")
        if (sourceGrid.confidence < gridConfidenceFloor || targetGrid.confidence < gridConfidenceFloor) {
            return Decision.Skip("low_grid_confidence")
        }

        val rawSpeed = sourceBpm / targetBpm
        if (abs(rawSpeed - 1f) > maxSpeedDelta) return Decision.Skip("speed_delta", rawSpeed)

        val sourcePeriod = (60_000f / sourceBpm).roundToInt().toLong().coerceAtLeast(250L)
        val sourcePos = sourcePositionMs.coerceAtLeast(0L)
        val sinceGrid = sourcePos - sourceGrid.firstBeatMs
        val phase = positiveModulo(sinceGrid, sourcePeriod)
        var waitMs = (sourcePeriod - phase) % sourcePeriod
        if (waitMs <= 35L || waitMs >= sourcePeriod - 35L) waitMs = 0L

        val speed = rawSpeed.coerceIn(1f - maxSpeedDelta, 1f + maxSpeedDelta)
        val cueLeadMs = (targetGrid.firstBeatMs - targetGrid.cueMs).coerceIn(0L, 160L)
        if (waitMs < cueLeadMs + 20L) waitMs += sourcePeriod
        val preRollWaitMs = (waitMs - cueLeadMs).coerceAtLeast(0L)

        return Decision.Ready(
            targetSpeed = speed,
            preRollWaitMs = preRollWaitMs,
            cueLeadMs = cueLeadMs,
            targetCueMs = targetGrid.cueMs.coerceAtLeast(0L),
            targetFirstBeatMs = targetGrid.firstBeatMs
        )
    }

    private fun positiveModulo(value: Long, mod: Long): Long {
        if (mod <= 0L) return 0L
        val r = value % mod
        return if (r < 0L) r + mod else r
    }
}
