package com.terafon.pausemix

import android.app.Application
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization

class PauseMixApp : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashFlightRecorder.install(this)
        NewPipe.init(
            SimpleDownloader(),
            Localization("en", "GB"),
            ContentCountry("GB")
        )
    }
}
