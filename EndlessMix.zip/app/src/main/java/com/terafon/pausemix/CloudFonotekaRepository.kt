package com.terafon.pausemix

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Low-priority E/F "balcony" harvester.
 * It asks the Worker to import one artist's canonical MusicBrainz recording titles into D1.
 * It never owns a player, deck, transition, READY_NEXT gate, or discovery decision.
 */
class CloudFonotekaRepository {
    private val baseUrl = BuildConfig.BPM_API_BASE_URL.trim().trimEnd('/')
    private val enabled = baseUrl.isNotBlank()
    private val client = OkHttpClient.Builder()
        .connectTimeout(2500, TimeUnit.MILLISECONDS)
        .readTimeout(6000, TimeUnit.MILLISECONDS)
        .callTimeout(7000, TimeUnit.MILLISECONDS)
        .build()

    companion object {
        private val syncedThisProcess = ConcurrentHashMap.newKeySet<String>()
        private val syncMutex = Mutex()
        private const val MAX_PAGES_PER_ARTIST = 20 // 2,000 recordings safety ceiling
        private const val MUSICBRAINZ_PACE_MS = 1100L
    }

    suspend fun ensureArtist(
        artist: String,
        artistKey: String,
        diagnostic: ((String) -> Unit)? = null
    ) {
        if (!enabled || artist.isBlank() || artistKey.isBlank()) return
        if (syncedThisProcess.contains(artistKey)) {
            diagnostic?.invoke("FONOTEKA_SKIP artist=$artist reason=already_synced_process")
            return
        }
        syncMutex.withLock {
            if (syncedThisProcess.contains(artistKey)) return@withLock
            diagnostic?.invoke("FONOTEKA_SYNC_START artist=$artist")
            var offset = 0
            var pages = 0
            var imported = 0
            try {
                while (pages < MAX_PAGES_PER_ARTIST) {
                    val result = fetchPage(artist, artistKey, offset, diagnostic) ?: break
                    imported += result.imported
                    pages++
                    if (result.cached || result.nextOffset == null) break
                    offset = result.nextOffset
                    delay(MUSICBRAINZ_PACE_MS)
                }
                syncedThisProcess += artistKey
                diagnostic?.invoke("FONOTEKA_SYNC_DONE artist=$artist pages=$pages imported=$imported")
            } catch (t: Throwable) {
                diagnostic?.invoke("FONOTEKA_SYNC_ERROR artist=$artist ${t.javaClass.simpleName}: ${t.message}")
            }
        }
    }

    private data class Page(val imported: Int, val nextOffset: Int?, val cached: Boolean)

    private suspend fun fetchPage(
        artist: String,
        artistKey: String,
        offset: Int,
        diagnostic: ((String) -> Unit)?
    ): Page? = withContext(Dispatchers.IO) {
        val root = baseUrl.toHttpUrlOrNull() ?: return@withContext null
        val url = root.newBuilder()
            .addPathSegments("api/v1/fonoteka/artist")
            .addQueryParameter("artist", artist)
            .addQueryParameter("artist_key", artistKey)
            .addQueryParameter("offset", offset.toString())
            .build()
        diagnostic?.invoke("FONOTEKA_REQUEST artist=$artist offset=$offset")
        val req = Request.Builder().url(url).get().build()
        client.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            diagnostic?.invoke("FONOTEKA_HTTP artist=$artist offset=$offset code=${r.code}")
            if (!r.isSuccessful) return@withContext null
            val j = runCatching { JSONObject(body) }.getOrNull() ?: return@withContext null
            val imported = j.optInt("imported", 0)
            val cached = j.optBoolean("cached", false)
            val next = if (j.isNull("next_offset")) null else j.optInt("next_offset", -1).takeIf { it >= 0 }
            diagnostic?.invoke("FONOTEKA_PAGE artist=$artist imported=$imported total=${j.optInt("total_count", 0)} next=${next ?: "END"} cached=$cached")
            Page(imported, next, cached)
        }
    }
}
