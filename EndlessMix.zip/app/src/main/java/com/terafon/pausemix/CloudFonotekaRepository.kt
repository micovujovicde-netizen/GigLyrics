package com.terafon.pausemix

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Low-priority E/F "balcony" harvester.
 * It asks the Worker to import one artist's canonical MusicBrainz recording titles into D1.
 * It never owns a player, deck, transition, READY_NEXT gate, or discovery decision.
 */
class CloudFonotekaRepository {
    private val baseUrl = BuildConfig.BPM_API_BASE_URL.trim().trimEnd('/')
    private val enabled = baseUrl.isNotBlank()
    private val client = OkHttpClient.Builder()
        .connectTimeout(2500, TimeUnit.MILLISECONDS)
        .readTimeout(6000, TimeUnit.MILLISECONDS)
        .callTimeout(7000, TimeUnit.MILLISECONDS)
        .build()

    companion object {
        private val syncedThisProcess = ConcurrentHashMap.newKeySet<String>()
        private val syncMutex = Mutex()
        private const val MAX_PAGES_PER_ARTIST = 20 // 2,000 recordings safety ceiling
        private const val MUSICBRAINZ_PACE_MS = 2500L
        private const val MUSICBRAINZ_503_BACKOFF_MS = 30000L
        @Volatile private var lastWorkerRequestMs = 0L
        @Volatile private var musicBrainzBlockedUntilMs = 0L
        private val resumeOffsets = ConcurrentHashMap<String, Int>()
        // Do not let several E/F jobs immediately requeue the same artist after a miss/503.
        // This is process-local only; it never blocks playback and never changes D1 data.
        private val recentAttemptUntil = ConcurrentHashMap<String, Long>()
        private const val RECENT_ATTEMPT_GUARD_MS = 60000L
    }

    suspend fun ensureArtist(
        artist: String,
        artistKey: String,
        diagnostic: ((String) -> Unit)? = null
    ) {
        if (!enabled || artist.isBlank() || artistKey.isBlank()) return
        if (syncedThisProcess.contains(artistKey)) {
            diagnostic?.invoke("FONOTEKA_SKIP artist=$artist reason=already_synced_process")
            return
        }
        val beforeLockNow = System.currentTimeMillis()
        val beforeLockUntil = recentAttemptUntil[artistKey] ?: 0L
        if (beforeLockUntil > beforeLockNow) {
            diagnostic?.invoke("FONOTEKA_SKIP artist=$artist reason=recent_attempt wait_ms=${beforeLockUntil - beforeLockNow}")
            return
        }
        syncMutex.withLock {
            if (syncedThisProcess.contains(artistKey)) return@withLock
            val now = System.currentTimeMillis()
            val blockedUntil = recentAttemptUntil[artistKey] ?: 0L
            if (blockedUntil > now) {
                diagnostic?.invoke("FONOTEKA_SKIP artist=$artist reason=recent_attempt wait_ms=${blockedUntil - now}")
                return@withLock
            }
            recentAttemptUntil[artistKey] = now + RECENT_ATTEMPT_GUARD_MS
            diagnostic?.invoke("FONOTEKA_SYNC_START artist=$artist")
            var offset = resumeOffsets[artistKey] ?: 0
            var pages = 0
            var imported = 0
            var completed = false
            try {
                while (pages < MAX_PAGES_PER_ARTIST) {
                    val result = fetchPage(artist, artistKey, offset, diagnostic) ?: break
                    imported += result.imported
                    pages++
                    if (result.cached || result.nextOffset == null) {
                        completed = true
                        break
                    }
                    offset = result.nextOffset
                    resumeOffsets[artistKey] = offset
                }
                if (completed) {
                    resumeOffsets.remove(artistKey)
                    syncedThisProcess += artistKey
                    diagnostic?.invoke("FONOTEKA_SYNC_DONE artist=$artist pages=$pages imported=$imported complete=true")
                } else {
                    resumeOffsets[artistKey] = offset
                    diagnostic?.invoke("FONOTEKA_SYNC_DEFER artist=$artist pages=$pages imported=$imported resume_offset=$offset")
                }
            } catch (t: Throwable) {
                diagnostic?.invoke("FONOTEKA_SYNC_ERROR artist=$artist ${t.javaClass.simpleName}: ${t.message}")
            }
        }
    }

    /**
     * Targeted live translator on the proven V3 /fonoteka/artist route.
     * Supplying title makes the Worker resolve ONE recording identity; no artist pagination.
     */
    suspend fun ensureTrack(
        artist: String,
        artistKey: String,
        title: String,
        titleKey: String,
        diagnostic: ((String) -> Unit)? = null
    ): Boolean = syncMutex.withLock {
        if (!enabled || artist.isBlank() || artistKey.isBlank() || title.isBlank() || titleKey.isBlank()) return@withLock false
        val now = System.currentTimeMillis()
        val paceUntil = lastWorkerRequestMs + MUSICBRAINZ_PACE_MS
        val allowedAt = maxOf(paceUntil, musicBrainzBlockedUntilMs)
        val waitMs = (allowedAt - now).coerceAtLeast(0L)
        if (waitMs > 0L) { diagnostic?.invoke("FONOTEKA_WAIT ms=$waitMs"); delay(waitMs) }
        lastWorkerRequestMs = System.currentTimeMillis()
        withContext(Dispatchers.IO) {
            val root = baseUrl.toHttpUrlOrNull() ?: return@withContext false
            val url = root.newBuilder()
                .addPathSegments("api/v1/fonoteka/artist")
                .addQueryParameter("artist", artist)
                .addQueryParameter("artist_key", artistKey)
                .addQueryParameter("title", title)
                .addQueryParameter("title_key", titleKey)
                .build()
            diagnostic?.invoke("FONOTEKA_TRACK_REQUEST artist=$artist title=$title")
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { r ->
                val body = r.body?.string().orEmpty()
                diagnostic?.invoke("FONOTEKA_TRACK_HTTP artist=$artist code=${r.code}")
                if (r.code == 503) {
                    musicBrainzBlockedUntilMs = System.currentTimeMillis() + MUSICBRAINZ_503_BACKOFF_MS
                    diagnostic?.invoke("FONOTEKA_BACKOFF reason=503 ms=$MUSICBRAINZ_503_BACKOFF_MS")
                    return@withContext false
                }
                if (!r.isSuccessful) return@withContext false
                val j = runCatching { JSONObject(body) }.getOrNull() ?: return@withContext false
                val found = j.optBoolean("found", false)
                diagnostic?.invoke("FONOTEKA_TRACK_DONE artist=$artist found=$found")
                found
            }
        }
    }

    private data class Page(val imported: Int, val nextOffset: Int?, val cached: Boolean)

    private suspend fun fetchPage(
        artist: String,
        artistKey: String,
        offset: Int,
        diagnostic: ((String) -> Unit)?
    ): Page? = withContext(Dispatchers.IO) {
        // Worker endpoint now performs exactly ONE MusicBrainz request per page.
        // Pace every page globally so artist changes cannot create a burst.
        // Conservative 2.5 s client-side throttle: protects MusicBrainz from 503 rate-limit bursts without touching the Worker.
        val now = System.currentTimeMillis()
        val paceUntil = lastWorkerRequestMs + MUSICBRAINZ_PACE_MS
        val allowedAt = maxOf(paceUntil, musicBrainzBlockedUntilMs)
        val waitMs = (allowedAt - now).coerceAtLeast(0L)
        if (waitMs > 0L) {
            diagnostic?.invoke("FONOTEKA_WAIT ms=$waitMs")
            delay(waitMs)
        }
        lastWorkerRequestMs = System.currentTimeMillis()
        val root = baseUrl.toHttpUrlOrNull() ?: return@withContext null
        val url = root.newBuilder()
            .addPathSegments("api/v1/fonoteka/artist")
            .addQueryParameter("artist", artist)
            .addQueryParameter("artist_key", artistKey)
            .addQueryParameter("offset", offset.toString())
            .build()
        diagnostic?.invoke("FONOTEKA_REQUEST artist=$artist offset=$offset")
        val req = Request.Builder().url(url).get().build()
        client.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            diagnostic?.invoke("FONOTEKA_HTTP artist=$artist offset=$offset code=${r.code}")
            if (r.code == 503) {
                musicBrainzBlockedUntilMs = System.currentTimeMillis() + MUSICBRAINZ_503_BACKOFF_MS
                diagnostic?.invoke("FONOTEKA_BACKOFF reason=503 ms=$MUSICBRAINZ_503_BACKOFF_MS")
                return@withContext null
            }
            if (!r.isSuccessful) return@withContext null
            val j = runCatching { JSONObject(body) }.getOrNull() ?: return@withContext null
            val imported = j.optInt("imported", 0)
            val cached = j.optBoolean("cached", false)
            val next = if (j.isNull("next_offset")) null else j.optInt("next_offset", -1).takeIf { it >= 0 }
            diagnostic?.invoke("FONOTEKA_PAGE artist=$artist imported=$imported total=${j.optInt("total_count", 0)} next=${next ?: "END"} cached=$cached")
            Page(imported, next, cached)
        }
    }
}
