package com.terafon.pausemix

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Low-priority AIDJ beat-phase analyzer used ONLY by 🍾 JUST A PARTY.
 *
 * It never decides playback eligibility and never touches A/B directly. The caller supplies the
 * final BPM authority (Deezer first, F only as last resort). We decode only the opening slice,
 * build a 25 ms onset envelope, then find the strongest repeating phase for that known BPM.
 */
object BeatGridAnalyzer {
    data class Grid(
        val bpm: Float,
        val firstBeatMs: Long,
        val beatPeriodMs: Float,
        val confidence: Float,
        val analyzedMs: Long
    )

    private val cache = ConcurrentHashMap<String, Grid>()

    fun cached(key: String): Grid? = cache[key]

    fun analyze(url: String, bpm: Float, cacheKey: String, scanMs: Long = 24_000L): Grid? {
        if (bpm !in 60f..220f) return null
        cache[cacheKey]?.let { if (kotlin.math.abs(it.bpm - bpm) < 0.05f) return it }

        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(url, emptyMap())
            var trackIndex = -1
            var inputFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    trackIndex = i
                    inputFormat = f
                    break
                }
            }
            if (trackIndex < 0 || inputFormat == null) return null

            extractor.selectTrack(trackIndex)
            val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: return null
            val sampleRate = if (inputFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44_100
            val channels = if (inputFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1) else 2
            val frameSamples = max(1, (sampleRate * 0.025f).toInt()) * channels

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(inputFormat, null, null, 0)
            codec.start()

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var guard = 0
            var blockSq = 0.0
            var blockCount = 0
            var previousEnergy = 0f
            val onset = ArrayList<Float>(1200)

            while (!outputDone && guard++ < 80_000) {
                if (!inputDone) {
                    val inputIndex = codec.dequeueInputBuffer(8_000)
                    if (inputIndex >= 0) {
                        val inputBuffer = codec.getInputBuffer(inputIndex)
                        if (inputBuffer != null) {
                            val t = extractor.sampleTime
                            if (t < 0L || t > scanMs * 1000L) {
                                codec.queueInputBuffer(inputIndex, 0, 0, max(0L, t), MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                val size = extractor.readSampleData(inputBuffer, 0)
                                if (size < 0) {
                                    codec.queueInputBuffer(inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                    inputDone = true
                                } else {
                                    codec.queueInputBuffer(inputIndex, 0, size, t, 0)
                                    extractor.advance()
                                }
                            }
                        }
                    }
                }

                val outputIndex = codec.dequeueOutputBuffer(info, 8_000)
                if (outputIndex >= 0) {
                    if (info.size > 0 && info.presentationTimeUs <= scanMs * 1000L) {
                        val out = codec.getOutputBuffer(outputIndex)
                        if (out != null) {
                            out.position(info.offset)
                            out.limit(info.offset + info.size)
                            val pcm = out.slice().order(ByteOrder.LITTLE_ENDIAN)
                            while (pcm.remaining() >= 2) {
                                val n = pcm.short.toInt() / 32768.0
                                blockSq += n * n
                                blockCount++
                                if (blockCount >= frameSamples) {
                                    val energy = sqrt(blockSq / blockCount).toFloat()
                                    onset.add(max(0f, energy - previousEnergy))
                                    previousEnergy = energy
                                    blockSq = 0.0
                                    blockCount = 0
                                }
                            }
                        }
                    }
                    outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0 || info.presentationTimeUs > scanMs * 1000L
                    codec.releaseOutputBuffer(outputIndex, false)
                }
            }

            if (onset.size < 120) return null
            val values = onset.toFloatArray()
            val mean = values.average().toFloat()
            for (i in values.indices) values[i] = max(0f, values[i] - mean * 0.55f)

            val beatPeriodMs = 60_000f / bpm
            val periodFrames = beatPeriodMs / 25f
            if (periodFrames < 8f || periodFrames > 40f) return null

            // Search phase at 25 ms resolution. At each expected beat, allow ±1 frame because
            // compressed streams and live drummers are not sample-perfect grids.
            val phaseCount = max(1, periodFrames.toInt())
            var bestPhase = 0
            var best = 0.0
            var second = 0.0
            for (phase in 0 until phaseCount) {
                var score = 0.0
                var expected = phase.toFloat()
                var hits = 0
                while (expected < values.size) {
                    val center = expected.toInt().coerceIn(0, values.lastIndex)
                    var local = 0f
                    for (j in max(0, center - 1)..min(values.lastIndex, center + 1)) local = max(local, values[j])
                    score += local
                    hits++
                    expected += periodFrames
                }
                if (hits > 0) score /= hits.toDouble()
                if (score > best) {
                    second = best
                    best = score
                    bestPhase = phase
                } else if (score > second) {
                    second = score
                }
            }
            if (best <= 0.0001) return null

            // Move to the first reasonably strong beat on this phase so intros with silence do not
            // become the cue point. Cap the cue inside the opening 12 seconds.
            val strong = values.sortedArray().let { it[(it.size * 0.72f).toInt().coerceIn(0, it.lastIndex)] }
            var cueFrame = bestPhase.toFloat()
            var firstBeatFrame = bestPhase
            while (cueFrame < values.size && cueFrame * 25f <= 12_000f) {
                val c = cueFrame.toInt().coerceIn(0, values.lastIndex)
                val local = max(values[c], max(values[max(0, c - 1)], values[min(values.lastIndex, c + 1)]))
                if (local >= strong) {
                    firstBeatFrame = c
                    break
                }
                cueFrame += periodFrames
            }

            val separation = ((best - second) / best).coerceIn(0.0, 1.0)
            val confidence = (0.35 + 0.65 * separation).toFloat().coerceIn(0f, 1f)
            val grid = Grid(
                bpm = bpm,
                firstBeatMs = firstBeatFrame * 25L,
                beatPeriodMs = beatPeriodMs,
                confidence = confidence,
                analyzedMs = scanMs
            )
            cache[cacheKey] = grid
            return grid
        } catch (_: Throwable) {
            return null
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }
}
