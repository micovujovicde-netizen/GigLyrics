package com.terafon.pausemix

import com.terafon.pausemix.model.TrackRef
import java.text.Normalizer
import java.util.Locale

/**
 * Universal passport layer for messy public music metadata.
 *
 * This code is deliberately language/region agnostic. It does not assume an English
 * `Artist - Title` spelling. It preserves every Unicode letter/digit, folds harmless
 * diacritics for comparisons, understands common collaboration markers and YouTube
 * decoration, and leaves cross-script alias resolution to the server/MusicBrainz layer.
 */
object CanonicalIdentityResolver {
    data class Identity(
        val artistCredits: Set<String>,
        val catalogArtist: String,
        val catalogTitle: String
    )

    private val separators = listOf(" || ", " - ", " – ", " — ", " | ", " • ", " :: ")
    private val hardNegatives = listOf(
        "tribute", "type beat", "dance fitness", "fitness dance", "tutorial", "choreography",
        "coreografia", "coreografía", "dance class", "line dance", "reaction", "karaoke",
        "fan made", "fanmade", "zumba", "workout", "how to dance",
        "full video crowd", "crowd dancing", "dance chart history", "tribute night"
    )

    // Verified historical/short-name identities only. Never fuzzy-match unrelated artists.
    private val verifiedAliasGroups = listOf(
        setOf("the beat fleet", "tbf"),
        setOf("djogani", "djogani fantastico"),
        setOf("hiljson mandela", "hilj on mandela", "hilj on"),
        setOf("voodoo popeye", "vudu popaj", "woodoo popeye")
    ).map { group -> group.map(::normalize).toSet() }

    // Names that are also ordinary words/titles/acronyms need corroboration. This is deliberately
    // a tiny verified list, not a heuristic that makes all short artists harder to find.
    private val ambiguousArtistKeys = setOf(
        "moby dick", "models", "connect", "et", "vip", "luna"
    ).map(::normalize).toSet()

    private fun equivalentArtistKeys(raw: String): Set<String> {
        val key = normalize(raw)
        val group = verifiedAliasGroups.firstOrNull { key in it }
        return group ?: setOf(key)
    }

    fun normalize(raw: String): String {
        val lowered = raw.lowercase(Locale.ROOT)
            .replace("đ", "dj")
            .replace("ð", "d")
        val decomposed = Normalizer.normalize(lowered, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
        return decomposed
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun cleanArtistDisplay(raw: String): String = raw
        .replace(Regex("(?i)\\b(official(?:\\s+channel)?|vevo|topic|records?|recordings?|music\\s+channel)\\b"), " ")
        .replace(Regex("\\s+"), " ")
        .trim(' ', '-', '_', '|', '•')

    fun cleanCatalogTitle(raw: String): String {
        var value = raw.trim()
        value = value.replace(Regex("(?i)\\s*[\\[(]\\s*(official\\b|from\\b|lyrics?\\b|lyric\\s+video\\b|music\\s+video\\b|audio\\b|visuali[sz]er\\b|live\\b|remaster(?:ed)?\\b|hd\\b|hq\\b|4k\\b).*?$"), "")
        value = value.replace(Regex("(?i)\\s*[-–—|]\\s*(?:official\\s+)?(?:music\\s+)?(?:video(?:\\s+clip)?|audio|visuali[sz]er|lyrics?|lyric\\s+video)(?:\\s+.*)?$"), "")
        return value.replace(Regex("\\s+"), " ").trim(' ', '-', '_', '|', '•')
    }

    private fun splitFirstTitlePair(title: String): Pair<String, String>? {
        // Use the earliest real separator in the title, not the first separator type in our list.
        // Otherwise a later year range like "(2012 - 2025)" can steal the split from an earlier " | ".
        val hit = separators.mapNotNull { sep ->
            val i = title.indexOf(sep)
            if (i > 0 && i + sep.length < title.length) i to sep else null
        }.minByOrNull { it.first } ?: return null
        val (i, sep) = hit
        return title.substring(0, i).trim() to title.substring(i + sep.length).trim()
    }

    fun splitCredits(raw: String): Set<String> {
        if (raw.isBlank()) return emptySet()
        val expanded = raw
            .replace(Regex("(?i)\\b(feat(?:uring)?|ft|with|duet|vs)\\.?\\b"), " & ")
            .replace(Regex("(?i)\\s+[x×]\\s+"), " & ")
            .replace(Regex("(?i)\\s+(and|i|y|e)\\s+"), " & ")
        return expanded.split('&', ',', ';')
            .map(::normalize)
            .map { it.trim() }
            .filter { it.length >= 2 }
            .toSet()
    }

    /** Extract featured/collaboration names even when they live on the song-title side. */
    private fun embeddedFeatureCredits(title: String): Set<String> {
        val out = linkedSetOf<String>()
        val rx = Regex("(?i)\\b(?:feat(?:uring)?|ft|with|duet|vs)\\.?\\s+([^\\])|/]+)")
        rx.findAll(title).forEach { match -> out += splitCredits(match.groupValues[1]) }
        return out
    }

    fun resolve(track: TrackRef): Identity {
        val pair = splitFirstTitlePair(track.title)
        val uploaderClean = cleanArtistDisplay(track.uploader)
        val uploaderNorm = normalize(uploaderClean)
        val genericUploader = uploaderNorm.isBlank() || listOf("release", "records", "recordings", "label", "music", "channel").any { it in uploaderNorm }

        // Most public titles are "Artist - Song", but some official uploads are reversed
        // (for example "#SELFIE (Official Music Video) - The Chainsmokers").  When the
        // trusted uploader strongly identifies the RIGHT side, flip the passport before any
        // BPM/Fonoteka request.  This avoids sending song-as-artist zombie identities upstream.
        val reversePair = if (pair != null && !genericUploader) {
            val left = normalize(cleanArtistDisplay(cleanCatalogTitle(pair.first)))
            val right = normalize(cleanArtistDisplay(cleanCatalogTitle(pair.second)))
            val uploaderCredits = splitCredits(uploaderClean)
            val rightCredits = splitCredits(pair.second)
            val leftCredits = splitCredits(pair.first)
            val rightMatches = uploaderNorm == right || uploaderNorm in rightCredits || right in uploaderCredits
            val leftMatches = uploaderNorm == left || uploaderNorm in leftCredits || left in uploaderCredits
            rightMatches && !leftMatches
        } else false

        val artistSide = when {
            pair == null -> ""
            reversePair -> pair.second
            else -> pair.first
        }
        val titleSide = when {
            pair == null -> track.title
            reversePair -> pair.first
            else -> pair.second
        }

        val credits = linkedSetOf<String>()
        if (artistSide.isNotBlank()) credits += splitCredits(artistSide)
        credits += embeddedFeatureCredits(track.title)
        if (credits.isEmpty() && !genericUploader) credits += splitCredits(uploaderClean)

        val catalogArtist = when {
            artistSide.isNotBlank() -> cleanArtistDisplay(cleanCatalogTitle(artistSide))
            !genericUploader -> uploaderClean
            else -> ""
        }
        return Identity(
            artistCredits = credits,
            catalogArtist = catalogArtist,
            catalogTitle = cleanCatalogTitle(titleSide.substringBefore('|').trim())
        )
    }

    fun hasHardNegative(track: TrackRef): Boolean {
        val text = normalize("${track.title} ${track.uploader}")
        return hardNegatives.any { normalize(it) in text }
    }

    fun matchesWantedArtist(track: TrackRef, wantedDisplay: String): Boolean {
        if (hasHardNegative(track)) return false
        val wanted = normalize(wantedDisplay)
        if (wanted.length < 2) return false
        val wantedKeys = equivalentArtistKeys(wantedDisplay)
        val ambiguous = wantedKeys.any { it in ambiguousArtistKeys }
        val id = resolve(track)

        // Evidence is categorical, not fuzzy. Multiple hits from the same category are counted once.
        // This keeps generic identities such as Moby Dick/Luna from passing merely because their
        // words occur in an unrelated title, while explicit feat./ft./& credits remain strong.
        var score = 0
        val evidence = linkedSetOf<String>()
        fun addEvidence(kind: String, points: Int) {
            if (evidence.add(kind)) score += points
        }
        fun equivalent(raw: String): Boolean =
            equivalentArtistKeys(raw).any { it in wantedKeys }

        // Canonical/featured credits parsed from the artist side and from title-side feat/ft/with.
        if (id.artistCredits.any(::equivalent)) addEvidence("credit", 100)

        val pair = splitFirstTitlePair(track.title)
        if (pair != null) {
            if (equivalent(pair.first) || equivalent(pair.second)) addEvidence("pair", 95)
            val pairCredits = splitCredits(pair.first) + splitCredits(pair.second) + embeddedFeatureCredits(track.title)
            if (pairCredits.any(::equivalent)) addEvidence("participant", 100)
        } else if (embeddedFeatureCredits(track.title).any(::equivalent)) {
            addEvidence("participant", 100)
        }

        // Colon is also a common Artist: Song separator. Keep it exact and multi-token.
        val rawLower = track.title.lowercase(Locale.ROOT).trim()
        val wantedLower = wantedDisplay.lowercase(Locale.ROOT).trim()
        if (wanted.split(' ').size >= 2 &&
            (rawLower.startsWith("$wantedLower:") || rawLower.startsWith("$wantedLower :"))) {
            addEvidence("structured_title", 90)
        }

        // YouTube commonly writes Artist-Song without spaces. Exact prefix only, never fuzzy.
        val rawTitle = track.title.trim()
        if (wanted.split(' ').size >= 2) {
            val prefix = rawTitle.substringBefore('-', missingDelimiterValue = "").trim()
            if (prefix.isNotBlank() && equivalent(prefix)) addEvidence("structured_title", 90)
        }

        // Strong uploader/channel identity is independent corroboration. cleanArtistDisplay strips
        // VEVO/Topic/Official decoration before the exact comparison.
        val uploader = normalize(cleanArtistDisplay(track.uploader))
        if (equivalentArtistKeys(uploader).any { it in wantedKeys }) addEvidence("uploader", 90)
        if (uploader.startsWith("$wanted ") && uploader.removePrefix("$wanted ").trim() in setOf("official", "vevo", "topic")) {
            addEvidence("uploader", 90)
        }
        if (track.uploaderVerified && ("credit" in evidence || "pair" in evidence || "participant" in evidence || "structured_title" in evidence)) {
            addEvidence("verified_channel", 20)
        }

        // Strong multi-token prefix is useful for normal artist names, but ambiguous identities do
        // not get this single-signal shortcut. Example: a random whale video titled Moby Dick ...
        // must not become an EX-YU artist passport.
        val titleNorm = normalize(track.title)
        val wantedTokens = wanted.split(' ').filter { it.isNotBlank() }
        val titleTokens = titleNorm.split(' ').filter { it.isNotBlank() }
        if (!ambiguous && wantedTokens.size >= 2 && titleNorm.startsWith("$wanted ") &&
            titleTokens.size >= wantedTokens.size + 2) {
            addEvidence("title_prefix", 90)
        }

        return if (ambiguous) {
            // Generic/ambiguous stage names require two independent signals. Typical passes:
            // `Moby Dick - Song` + `Moby Dick - Topic`, or exact structured title + verified channel.
            evidence.size >= 2 && score >= 110
        } else {
            score >= 90
        }
    }

}
