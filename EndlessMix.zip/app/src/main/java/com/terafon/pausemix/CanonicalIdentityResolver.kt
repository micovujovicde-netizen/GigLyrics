package com.terafon.pausemix

import com.terafon.pausemix.model.TrackRef
import java.text.Normalizer
import java.util.Locale

/**
 * Universal passport layer for messy public music metadata.
 *
 * This code is deliberately language/region agnostic. It does not assume an English
 * `Artist - Title` spelling. It preserves every Unicode letter/digit, folds harmless
 * diacritics for comparisons, understands common collaboration markers and YouTube
 * decoration, and leaves cross-script alias resolution to the server/MusicBrainz layer.
 */
object CanonicalIdentityResolver {
    data class Identity(
        val artistCredits: Set<String>,
        val catalogArtist: String,
        val catalogTitle: String
    )

    private val separators = listOf(" || ", " - ", " – ", " — ", " | ", " • ", " :: ")
    private val hardNegatives = listOf(
        "tribute", "type beat", "dance fitness", "fitness dance", "tutorial", "choreography",
        "coreografia", "coreografía", "dance class", "line dance", "reaction", "karaoke",
        "fan made", "fanmade", "zumba", "workout", "how to dance"
    )

    fun normalize(raw: String): String {
        val lowered = raw.lowercase(Locale.ROOT)
            .replace("đ", "dj")
            .replace("ð", "d")
        val decomposed = Normalizer.normalize(lowered, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
        return decomposed
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun cleanArtistDisplay(raw: String): String = raw
        .replace(Regex("(?i)\\b(official(?:\\s+channel)?|vevo|topic|records?|recordings?|music\\s+channel)\\b"), " ")
        .replace(Regex("\\s+"), " ")
        .trim(' ', '-', '_', '|', '•')

    fun cleanCatalogTitle(raw: String): String {
        var value = raw.trim()
        value = value.replace(Regex("(?i)\\s*[\\[(]\\s*(official\\b|from\\b|lyrics?\\b|lyric\\s+video\\b|music\\s+video\\b|audio\\b|visuali[sz]er\\b|live\\b|remaster(?:ed)?\\b|hd\\b|hq\\b|4k\\b).*?$"), "")
        value = value.replace(Regex("(?i)\\s*[-–—|]\\s*(?:official\\s+)?(?:music\\s+)?(?:video(?:\\s+clip)?|audio|visuali[sz]er|lyrics?|lyric\\s+video)(?:\\s+.*)?$"), "")
        return value.replace(Regex("\\s+"), " ").trim(' ', '-', '_', '|', '•')
    }

    private fun splitFirstTitlePair(title: String): Pair<String, String>? {
        for (sep in separators) {
            val i = title.indexOf(sep)
            if (i > 0 && i + sep.length < title.length) {
                return title.substring(0, i).trim() to title.substring(i + sep.length).trim()
            }
        }
        return null
    }

    fun splitCredits(raw: String): Set<String> {
        if (raw.isBlank()) return emptySet()
        val expanded = raw
            .replace(Regex("(?i)\\b(feat(?:uring)?|ft|with|duet|vs)\\.?\\b"), " & ")
            .replace(Regex("(?i)\\s+[x×]\\s+"), " & ")
            .replace(Regex("(?i)\\s+(and|i|y|e)\\s+"), " & ")
        return expanded.split('&', ',', ';')
            .map(::normalize)
            .map { it.trim() }
            .filter { it.length >= 2 }
            .toSet()
    }

    /** Extract featured/collaboration names even when they live on the song-title side. */
    private fun embeddedFeatureCredits(title: String): Set<String> {
        val out = linkedSetOf<String>()
        val rx = Regex("(?i)\\b(?:feat(?:uring)?|ft|with|duet|vs)\\.?\\s+([^\\])|/]+)")
        rx.findAll(title).forEach { match -> out += splitCredits(match.groupValues[1]) }
        return out
    }

    fun resolve(track: TrackRef): Identity {
        val pair = splitFirstTitlePair(track.title)
        val prefix = pair?.first.orEmpty()
        val body = pair?.second ?: track.title
        val credits = linkedSetOf<String>()
        if (prefix.isNotBlank()) credits += splitCredits(prefix)
        credits += embeddedFeatureCredits(track.title)

        val uploaderClean = cleanArtistDisplay(track.uploader)
        val uploaderNorm = normalize(uploaderClean)
        val genericUploader = uploaderNorm.isBlank() || listOf("release", "records", "recordings", "label", "music", "channel").any { it in uploaderNorm }
        if (credits.isEmpty() && !genericUploader) credits += splitCredits(uploaderClean)

        val catalogArtist = when {
            prefix.isNotBlank() -> cleanArtistDisplay(prefix)
            !genericUploader -> uploaderClean
            else -> ""
        }
        return Identity(
            artistCredits = credits,
            catalogArtist = catalogArtist,
            catalogTitle = cleanCatalogTitle(body.substringBefore('|').trim())
        )
    }

    fun hasHardNegative(track: TrackRef): Boolean {
        val text = normalize("${track.title} ${track.uploader}")
        return hardNegatives.any { normalize(it) in text }
    }

    fun matchesWantedArtist(track: TrackRef, wantedDisplay: String): Boolean {
        if (hasHardNegative(track)) return false
        val wanted = normalize(wantedDisplay)
        if (wanted.length < 2) return false
        val id = resolve(track)
        if (wanted in id.artistCredits) return true

        // Exact side identity in either Artist—Song or Song—Artist forms.
        // Colon is also a common Artist: Song separator, but require a multi-token wanted artist
        // so generic one-word titles do not become false passports.
        if (wanted.split(' ').size >= 2) {
            val rawLower = track.title.lowercase(Locale.ROOT).trim()
            val wantedLower = wantedDisplay.lowercase(Locale.ROOT).trim()
            if (rawLower.startsWith("$wantedLower:") || rawLower.startsWith("$wantedLower :")) return true
        }

        val pair = splitFirstTitlePair(track.title)
        if (pair != null) {
            val left = normalize(pair.first)
            val right = normalize(pair.second)
            if (left == wanted || right == wanted) return true
            if (wanted in splitCredits(pair.first) || wanted in splitCredits(pair.second)) return true
        }

        // Strong uploader identity is an independent passport.
        val uploader = normalize(cleanArtistDisplay(track.uploader))
        if (uploader == wanted) return true
        if (uploader.startsWith("$wanted ") && uploader.removePrefix("$wanted ").trim() in setOf("official", "vevo", "topic")) return true

        // A multi-token artist written verbatim at the beginning of a title is useful evidence,
        // but only when the uploader also names that artist. This prevents same-name song collisions.
        val titleNorm = normalize(track.title)
        if (wanted.split(' ').size >= 2 && titleNorm.startsWith("$wanted ") && wanted in uploader) return true
        return false
    }
}
