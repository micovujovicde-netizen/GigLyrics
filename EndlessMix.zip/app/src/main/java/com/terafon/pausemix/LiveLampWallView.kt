package com.terafon.pausemix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.roundToInt

/**
 * Passive back-wall lamp layer.
 *
 * Draws a very faint bank of old electronic VU-style lamps behind the whole mixer.
 * It never receives input, owns no timers and touches no playback state. MixerActivity only
 * feeds it the already-computed MASTER VU envelope; drawing is therefore purely cosmetic.
 */
class LiveLampWallView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val dp = resources.displayMetrics.density
    private val bulbPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 0.8f * dp
        color = 0x305E5648
    }

    private var targetLevel = 0f
    private var shownLevel = 0f
    private var phase = 0f

    init {
        isClickable = false
        isFocusable = false
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
        alpha = 1f
        setWillNotDraw(false)
    }

    fun setLevel(level: Float) {
        // Make the visual lamps react more readily to the existing MASTER VU envelope.
        // Cosmetic only: no audio/playback value is changed.
        targetLevel = (level * 1.35f).coerceIn(0f, 1f)
        // Slightly quicker attack keeps quieter musical pulses visible while retaining
        // the soft incandescent release.
        shownLevel += (targetLevel - shownLevel) * if (targetLevel > shownLevel) 0.52f else 0.18f
        phase += 0.19f
        if (phase > 1000f) phase = 0f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        // Keep the lamp field away from the header and make it strongest in the lower hardware area.
        val top = height * 0.28f
        val bottom = height * 0.965f
        val rows = 18
        val radius = (5.2f * dp).coerceAtMost(width * 0.012f)
        val leftX = width * 0.075f
        val rightX = width * 0.925f
        val centerLeftX = width * 0.455f
        val centerRightX = width * 0.545f

        for (i in 0 until rows) {
            val t = if (rows == 1) 0f else i.toFloat() / (rows - 1)
            val y = top + (bottom - top) * t
            val threshold = (i + 1f) / rows
            val active = ((shownLevel - threshold) * rows).coerceIn(0f, 1f)

            // Tiny natural incandescent shimmer; visual only, never used as meter data.
            val shimmer = (0.93f + 0.07f * kotlin.math.sin(phase + i * 0.73f)).coerceIn(0.86f, 1f)
            val intensity = (0.035f + active * 0.39f) * shimmer

            drawLamp(canvas, leftX, y, radius, intensity, i)
            drawLamp(canvas, rightX, y, radius, intensity, i)

            // Two much fainter inner strings make the old-electronics wall read across wide tablets
            // without competing with controls.
            val innerIntensity = intensity * 0.42f
            drawLamp(canvas, centerLeftX, y, radius * 0.72f, innerIntensity, i)
            drawLamp(canvas, centerRightX, y, radius * 0.72f, innerIntensity, i)
        }
    }

    private fun drawLamp(canvas: Canvas, x: Float, y: Float, radius: Float, intensity: Float, index: Int) {
        val hot = index >= 14
        val core = if (hot) 0xFFFF6338.toInt() else 0xFFFFB847.toInt()
        // 10% less transparent than before, without changing lamp geometry or colour.
        val alpha = (255f * intensity.coerceIn(0f, 0.46f) * 1.10f).roundToInt().coerceIn(0, 129)
        val glowAlpha = (alpha * 0.43f).roundToInt().coerceIn(0, 62)

        bulbPaint.shader = RadialGradient(
            x, y, radius * 2.7f,
            intArrayOf((core and 0x00FFFFFF) or (glowAlpha shl 24), (core and 0x00FFFFFF) or (alpha shl 24), 0x00000000),
            floatArrayOf(0f, 0.36f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(x, y, radius * 2.7f, bulbPaint)
        bulbPaint.shader = null

        bulbPaint.color = (core and 0x00FFFFFF) or (alpha shl 24)
        canvas.drawCircle(x, y, radius, bulbPaint)
        canvas.drawCircle(x, y, radius, rimPaint)
    }
}
