package com.terafon.pausemix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.max

/** Large black/white vertical volume fader, easier to hit than a rotated SeekBar. */
class VerticalFaderView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val density = resources.displayMetrics.density
    private val railShadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(28, 30, 33)
        strokeWidth = max(6f * density, 6f)
        strokeCap = Paint.Cap.ROUND
    }
    private val railMetalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(126, 132, 138)
        strokeWidth = max(3.6f * density, 3.6f)
        strokeCap = Paint.Cap.ROUND
    }
    private val railHighlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(220, 223, 225)
        strokeWidth = max(1.0f * density, 1.0f)
        strokeCap = Paint.Cap.ROUND
    }
    private val knobShadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(30, 32, 34); style = Paint.Style.FILL }
    private val knobMetalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(132, 137, 141); style = Paint.Style.FILL }
    private val knobHighlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(225, 227, 228); strokeWidth = 1.0f * density; style = Paint.Style.STROKE }
    private val knobIndicatorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = context.getColor(R.color.green_translucent); strokeWidth = 1.4f * density; strokeCap = Paint.Cap.ROUND }

    var progress: Int = 100
        set(value) {
            field = value.coerceIn(0, 100)
            invalidate()
        }

    var onProgressChanged: ((Int) -> Unit)? = null

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.BLACK)
        val cx = width / 2f
        val top = height * 0.08f
        val bottom = height * 0.92f
        canvas.drawLine(cx + 1.5f * density, top, cx + 1.5f * density, bottom, railShadowPaint)
        canvas.drawLine(cx, top, cx, bottom, railMetalPaint)
        canvas.drawLine(cx - 1.2f * density, top, cx - 1.2f * density, bottom, railHighlightPaint)
        val y = bottom - (progress / 100f) * (bottom - top)
        // Compact physical mixer fader cap: narrower/thinner than the crossfader handle.
        val capW = minOf(width * 0.30f, 18f * density)
        val capH = 8f * density
        canvas.drawRoundRect(cx-capW/2+1.2f*density, y-capH/2+1.4f*density, cx+capW/2+1.2f*density, y+capH/2+1.4f*density, 2.2f*density, 2.2f*density, knobShadowPaint)
        canvas.drawRoundRect(cx-capW/2, y-capH/2, cx+capW/2, y+capH/2, 2.2f*density, 2.2f*density, knobMetalPaint)
        canvas.drawRoundRect(cx-capW/2, y-capH/2, cx+capW/2, y+capH/2, 2.2f*density, 2.2f*density, knobHighlightPaint)
        canvas.drawLine(cx-capW*0.28f, y, cx+capW*0.28f, y, knobIndicatorPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!isEnabled) return false
        if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
            val top = height * 0.08f
            val bottom = height * 0.92f
            val y = event.y.coerceIn(top, bottom)
            progress = (((bottom - y) / (bottom - top)) * 100f).toInt()
            onProgressChanged?.invoke(progress)
            parent?.requestDisallowInterceptTouchEvent(true)
            return true
        }
        if (event.action == MotionEvent.ACTION_UP || event.action == MotionEvent.ACTION_CANCEL) {
            parent?.requestDisallowInterceptTouchEvent(false)
            performClick()
            return true
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
