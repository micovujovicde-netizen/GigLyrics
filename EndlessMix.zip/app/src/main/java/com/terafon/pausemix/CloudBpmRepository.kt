package com.terafon.pausemix

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Read-only client for the EndlessMix Cloudflare/D1 track metadata service.
 *
 * Safety rules:
 * - An empty BuildConfig.BPM_API_BASE_URL disables the repository completely.
 * - Lookups are never allowed to block playback or READY_NEXT.
 * - PARTY may use returned BPM as a background candidate preference; the retired on-device analyzer stays off.
 * - Misses/errors are cached briefly so a dead network cannot create repeated work.
 */
class CloudBpmRepository {
    data class Metadata(val bpm: Float?, val energy: Float?, val source: String? = null)

    private data class CacheEntry(val value: Metadata?, val expiresAtMs: Long)

    private val baseUrl = BuildConfig.BPM_API_BASE_URL.trim().trimEnd('/')
    private val enabled = baseUrl.isNotBlank()
    private val cache = ConcurrentHashMap<String, CacheEntry>()
    private val client = OkHttpClient.Builder()
        .connectTimeout(1800, TimeUnit.MILLISECONDS)
        .readTimeout(3200, TimeUnit.MILLISECONDS)
        .callTimeout(4200, TimeUnit.MILLISECONDS)
        .build()

    companion object {
        @Volatile private var circuitOpen = false
        @Volatile private var lastProbeMs = 0L
        private const val PROBE_INTERVAL_MS = 60_000L
    }

    private suspend fun serviceRoadOpen(diagnostic: ((String) -> Unit)?): Boolean {
        if (!circuitOpen) return true
        val now = System.currentTimeMillis()
        if (now - lastProbeMs < PROBE_INTERVAL_MS) {
            diagnostic?.invoke("BPM_CIRCUIT_OPEN normal_request_blocked")
            return false
        }
        lastProbeMs = now
        return withContext(Dispatchers.IO) {
            val root = baseUrl.toHttpUrlOrNull() ?: return@withContext false
            val health = root.newBuilder().addPathSegment("health").build()
            diagnostic?.invoke("BPM_PROBE start")
            val ok = runCatching {
                client.newCall(Request.Builder().url(health).get().build()).execute().use { it.isSuccessful }
            }.getOrDefault(false)
            if (ok) {
                circuitOpen = false
                diagnostic?.invoke("BPM_PROBE road_open")
            } else {
                diagnostic?.invoke("BPM_PROBE road_still_closed")
            }
            ok
        }
    }

    suspend fun lookup(
        artistKey: String,
        titleKey: String,
        version: String = "",
        artist: String? = null,
        title: String? = null,
        diagnostic: ((String) -> Unit)? = null,
        allowCachedMiss: Boolean = true
    ): Metadata? {
        if (!enabled) {
            diagnostic?.invoke("BPM_DISABLED baseUrl=blank")
            return null
        }
        if (artistKey.isBlank() || titleKey.isBlank()) {
            diagnostic?.invoke("BPM_SKIP blank_key artistKey=${artistKey.isNotBlank()} titleKey=${titleKey.isNotBlank()}")
            return null
        }
        if (!serviceRoadOpen(diagnostic)) return null
        val cacheKey = "$artistKey\u0000$titleKey\u0000$version"
        val now = System.currentTimeMillis()
        cache[cacheKey]?.let {
            if (it.expiresAtMs > now) {
                if (it.value != null) {
                    diagnostic?.invoke("BPM_CACHE HIT bpm=${it.value.bpm}")
                    return it.value
                }
                if (allowCachedMiss) {
                    diagnostic?.invoke("BPM_CACHE MISS")
                    return null
                }
                diagnostic?.invoke("BPM_CACHE MISS_BYPASS_RESET")
                cache.remove(cacheKey)
            } else cache.remove(cacheKey)
        }

        return withContext(Dispatchers.IO) {
            val root = baseUrl.toHttpUrlOrNull() ?: run {
                diagnostic?.invoke("BPM_BAD_BASE_URL $baseUrl")
                return@withContext null
            }
            val url = root.newBuilder()
                .addPathSegments("api/v1/track")
                .addQueryParameter("artist_key", artistKey)
                .addQueryParameter("title_key", titleKey)
                .addQueryParameter("version", version)
                .apply {
                    artist?.trim()?.takeIf { it.isNotBlank() }?.let { addQueryParameter("artist", it) }
                    title?.trim()?.takeIf { it.isNotBlank() }?.let { addQueryParameter("title", it) }
                }
                .build()
            val request = Request.Builder().url(url).get().build()
            diagnostic?.invoke("BPM_REQUEST artist=${artist ?: artistKey} title=${title ?: titleKey}")
            val result = runCatching {
                client.newCall(request).execute().use { response ->
                    if (response.code == 404) {
                        diagnostic?.invoke("BPM_HTTP 404")
                        return@use null
                    }
                    if (!response.isSuccessful) {
                        diagnostic?.invoke("BPM_HTTP ${response.code}")
                        if (response.code >= 500 || response.code == 408 || response.code == 429) {
                            circuitOpen = true
                            diagnostic?.invoke("BPM_CIRCUIT_TRIP http=${response.code}")
                        }
                        return@use null
                    }
                    val body = response.body.string()
                    val json = JSONObject(body)
                    if (!json.optBoolean("found", false)) {
                        diagnostic?.invoke("BPM_FOUND_FALSE")
                        return@use null
                    }
                    val bpm = if (json.has("bpm") && !json.isNull("bpm")) json.optDouble("bpm").toFloat() else null
                    val energy = if (json.has("energy") && !json.isNull("energy")) json.optDouble("energy").toFloat() else null
                    val source = json.optString("source").takeIf { it.isNotBlank() }
                    Metadata(
                        bpm = bpm?.takeIf { it in 30f..300f },
                        energy = energy?.takeIf { it in 0f..1f },
                        source = source
                    ).also { diagnostic?.invoke("BPM_OK bpm=${it.bpm} energy=${it.energy} source=${it.source}") }
                }
            }.onFailure {
                circuitOpen = true
                diagnostic?.invoke("BPM_ERROR ${it.javaClass.simpleName}: ${it.message}")
                diagnostic?.invoke("BPM_CIRCUIT_TRIP network_error")
            }.getOrNull()

            // Hits: 24 h in-memory. Background candidate misses are cached briefly.
            // A real deck/display lookup (allowCachedMiss=false) never stores a negative result,
            // so its retry loop can keep asking the Worker until BPM arrives or the track changes.
            if (result != null) {
                cache[cacheKey] = CacheEntry(result, now + 86_400_000L)
            } else if (allowCachedMiss) {
                cache[cacheKey] = CacheEntry(null, now + 600_000L)
            } else {
                cache.remove(cacheKey)
            }
            result
        }
    }
}
