package com.terafon.pausemix

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Read-only client for the EndlessMix Cloudflare/D1 track metadata service.
 *
 * Safety rules:
 * - An empty BuildConfig.BPM_API_BASE_URL disables the repository completely.
 * - Lookups are never allowed to block playback or READY_NEXT.
 * - PARTY may use returned BPM as a background candidate preference; the retired on-device analyzer stays off.
 * - Misses/errors are cached briefly so a dead network cannot create repeated work.
 */
class CloudBpmRepository {
    data class Metadata(val bpm: Float?, val energy: Float?, val source: String? = null)

    private data class CacheEntry(val value: Metadata?, val expiresAtMs: Long)

    private val baseUrl = BuildConfig.BPM_API_BASE_URL.trim().trimEnd('/')
    private val enabled = baseUrl.isNotBlank()
    private val cache = ConcurrentHashMap<String, CacheEntry>()
    private val client = OkHttpClient.Builder()
        .connectTimeout(1800, TimeUnit.MILLISECONDS)
        .readTimeout(3200, TimeUnit.MILLISECONDS)
        .callTimeout(4200, TimeUnit.MILLISECONDS)
        .build()

    suspend fun lookup(
        artistKey: String,
        titleKey: String,
        version: String = "",
        artist: String? = null,
        title: String? = null
    ): Metadata? {
        if (!enabled || artistKey.isBlank() || titleKey.isBlank()) return null
        val cacheKey = "$artistKey\u0000$titleKey\u0000$version"
        val now = System.currentTimeMillis()
        cache[cacheKey]?.let { if (it.expiresAtMs > now) return it.value else cache.remove(cacheKey) }

        return withContext(Dispatchers.IO) {
            val root = baseUrl.toHttpUrlOrNull() ?: return@withContext null
            val url = root.newBuilder()
                .addPathSegments("api/v1/track")
                .addQueryParameter("artist_key", artistKey)
                .addQueryParameter("title_key", titleKey)
                .addQueryParameter("version", version)
                .apply {
                    artist?.trim()?.takeIf { it.isNotBlank() }?.let { addQueryParameter("artist", it) }
                    title?.trim()?.takeIf { it.isNotBlank() }?.let { addQueryParameter("title", it) }
                }
                .build()
            val request = Request.Builder().url(url).get().build()
            val result = runCatching {
                client.newCall(request).execute().use { response ->
                    if (response.code == 404) return@use null
                    if (!response.isSuccessful) return@use null
                    val body = response.body.string()
                    val json = JSONObject(body)
                    if (!json.optBoolean("found", false)) return@use null
                    val bpm = if (json.has("bpm") && !json.isNull("bpm")) json.optDouble("bpm").toFloat() else null
                    val energy = if (json.has("energy") && !json.isNull("energy")) json.optDouble("energy").toFloat() else null
                    val source = json.optString("source").takeIf { it.isNotBlank() }
                    Metadata(
                        bpm = bpm?.takeIf { it in 30f..300f },
                        energy = energy?.takeIf { it in 0f..1f },
                        source = source
                    )
                }
            }.getOrNull()

            // Hits: 24 h in-memory. Miss/network failure: 10 min to avoid hammering Worker.
            cache[cacheKey] = CacheEntry(result, now + if (result != null) 86_400_000L else 600_000L)
            result
        }
    }
}
