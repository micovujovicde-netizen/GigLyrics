package com.terafon.pausemix

import android.os.Build
import android.graphics.Color

import android.Manifest
import android.util.DisplayMetrics
import android.content.res.Configuration
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.media.AudioManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.os.Bundle
import android.os.SystemClock
import android.os.Process
import android.speech.RecognizerIntent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Space
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.widget.ImageButton
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.view.Gravity
import android.webkit.WebView
import android.webkit.WebViewClient
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.recyclerview.widget.LinearLayoutManager
import com.terafon.pausemix.databinding.ActivityMixerBinding
import com.terafon.pausemix.model.MixerStore
import com.terafon.pausemix.model.TrackRef
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt
import kotlin.random.Random

class MixerActivity : AppCompatActivity() {
    companion object {
        private const val STATE_CROSS = "em.cross"
        private const val STATE_ENDLESS_ACTIVE = "em.endless"
        private const val STATE_AUTO_ENABLED = "em.auto"
        private const val STATE_CONTROLS_LOCKED = "em.locked"
        private const val STATE_ONE_ARTIST = "em.oneartist"
        private const val STATE_QUICK_ACTIVE = "em.quick"
        private const val STATE_MOTOR = "em.motor"
        private const val STATE_DANCE_MODE = "em.dance"
        private const val STATE_QEM_STYLES = "em.qstyles"
        private const val STATE_QEM_ERAS = "em.qeras"
        private const val STATE_QEM_INSTRUMENTAL = "em.qinst"
        private const val STATE_QEM_PIANO = "em.qpiano"
        private const val STATE_QEM_FINGERPRINT = "em.qfp"
        private const val STATE_QEM_TEMPO_BAND = "em.qtempo"
        private const val STATE_QEM_ANCHOR = "em.qanchor"
        private const val STATE_QEM_STYLE_TERMS = "em.qstyleterms"
        private const val STATE_QEM_LONG_FORM = "em.qlong"
        private const val STATE_QUICK_COUNTRY = "em.qcountry"
        private const val STATE_QUICK_SCENE = "em.qscene"
        private const val STATE_QUICK_GUARD_A = "em.qguarda"
        private const val STATE_SEED_PROTECTED_A = "em.seedpa"
        private const val STATE_SEED_PROTECTED_B = "em.seedpb"
        private const val STATE_MANUAL_PROTECTED_A = "em.manpa"
        private const val STATE_MANUAL_PROTECTED_B = "em.manpb"
        private const val STATE_HAS_PLAYED_A = "em.playeda"
        private const val STATE_HAS_PLAYED_B = "em.playedb"
        private const val STATE_MANUAL_URLS = "em.manurls"
        private const val STATE_ENDLESS_SEEDS = "em.seeds"
        private const val STATE_QEM_POOL = "em.qpool"
        private const val STATE_AI_DJ_ENABLED = "em.aidjvoice"
        private const val STATE_AI_DJ_MIX_COUNTER = "em.aidjvoicecount"
    }
    /**
     * PHONE = same mixer canvas as TABLET.
     * On narrow phones we lower only this Activity's logical density so the exact same
     * mixer window/layout fits on screen instead of crushing fixed controls.
     * No playback/discovery logic is changed.
     */
    override fun attachBaseContext(newBase: Context) {
        val baseRes = newBase.resources
        val baseConfig = baseRes.configuration
        if (baseConfig.smallestScreenWidthDp < 600) {
            val config = Configuration(baseConfig)
            val widthPx = baseRes.displayMetrics.widthPixels.coerceAtLeast(1)
            val targetCanvasWidthDp = 600f
            val density = widthPx / targetCanvasWidthDp
            config.densityDpi = (density * DisplayMetrics.DENSITY_DEFAULT)
                .roundToInt()
                .coerceIn(120, 320)
            super.attachBaseContext(newBase.createConfigurationContext(config))
        } else {
            super.attachBaseContext(newBase)
        }
    }

    private enum class EndlessGenreProfile { POP, POP_FOLK, FOLK }
    private enum class EndlessDeckState { FREE, LOADING_NEXT, READY_NEXT, PLAYING }
    private enum class AutoDiscoveryMotor { NONE, BASIC, QEM }
    private enum class QemDanceMode { NONE, SLOW_DANCE_PARTY, DANCE_PARTY }
    private enum class EndlessSceneProfile {
        GLOBAL, EX_YU, ANGLO, FRANCOPHONE, HISPANIC, LUSOPHONE, DACH, ITALIAN,
        GREEK, TURKISH, ARABIC, SOUTH_ASIAN, EAST_SLAVIC, KOREAN, JAPANESE
    }

    private lateinit var binding: ActivityMixerBinding
    private lateinit var playerA: ExoPlayer
    private lateinit var playerB: ExoPlayer
    private var playerListenerA: Player.Listener? = null
    private var playerListenerB: Player.Listener? = null
    private lateinit var endlessAdapter: SearchAdapter

    private val searchRepo = SearchRepository()
    private val qemFonoteka by lazy { QemFonoteka(this) }
    private val artistArtworkRepository by lazy { ArtistArtworkRepository(this) }
    private val cloudBpmRepository by lazy { CloudBpmRepository() }
    private val cloudFonotekaRepository by lazy { CloudFonotekaRepository() }
    private val fallbackBpmStore by lazy { FallbackBpmStore(this) }

    private data class BpmEvidence(
        val bpm: Float,
        val source: String,
        val confidence: Float = 1f,
        val syncSafe: Boolean = true
    )
    private val bpmEvidenceByUrl = java.util.concurrent.ConcurrentHashMap<String, BpmEvidence>()
    private val aidjGridByUrl = java.util.concurrent.ConcurrentHashMap<String, BeatGridAnalyzer.Grid>()
    private val aidjGridJobs = java.util.concurrent.ConcurrentHashMap<String, Job>()
    private var bpmLookupJobA: Job? = null
    private var bpmTrackGenerationA = 0L
    private var bpmTrackGenerationB = 0L
    private var bpmLookupJobB: Job? = null
    private var artistArtworkJobA: Job? = null
    private var artistArtworkJobB: Job? = null
    private var artistArtworkTrackA: String? = null
    private var artistArtworkTrackB: String? = null
    private var artistArtworkShownA = false
    private var artistArtworkShownB = false

    // PLAYBACK PRIORITY LADDER:
    // ACTIVE audio > READY_NEXT preparation > discovery/refill > waveform/BPM analysis > UI.
    // Heavy analysis remains capped, but it must never starve the waiting deck long enough
    // to create dead air. Basic Endless selection behavior is unchanged.
    private val analysisSlots = Semaphore(2)

    private var userVolA = 1f
    private var userVolB = 1f
    private var measuredRmsA: Float? = null
    private var measuredRmsB: Float? = null
    private val loudnessTargetRms = 0.18f
    // Only genuinely near-silent/broken sources are rejected. Validation happens during early preload.
    private val minimumEndlessRms = 0.035f
    private var allowLive = false
    private var allowCover = false
    private var onlyOfficial = false
    private var crossfadeEnabled = true
    private var qemDanceMode = QemDanceMode.NONE
    private var qemSessionDanceMode = QemDanceMode.NONE
    private var cross = 0f

    // DECK Z — dedicated spoken AI-DJ layer. It never owns, pauses, seeks or gates A/B.
    private var aiDjVoiceEnabled = true
    private var deckZMixCounter = 0
    private var deckZDuck = 1f
    private val deckZAnnouncementRouter = DeckZAnnouncementRouter()
    private val deckZController by lazy {
        DeckZController(
            activity = this,
            scope = lifecycleScope,
            cacheDir = cacheDir,
            currentBpm = { currentDeckZBpm() },
            onDuckChanged = { value ->
                deckZDuck = value
                applyVolumes()
            },
            onStateChanged = { updateDeckZButton() },
            log = ::aidjFlight
        )
    }
    private var addToMixOverlayDialog: android.app.Dialog? = null
    private var addToMixOverlayInput: EditText? = null
    private var addToMixOverlayStatus: TextView? = null
    private var addToMixOverlayAdapter: SearchAdapter? = null

    private var lastTrackAUrl: String? = null
    private var lastTrackBUrl: String? = null
    private var analyzingA: String? = null
    private var analyzingB: String? = null
    private var waveformAnalysisJobA: Job? = null
    private var waveformAnalysisJobB: Job? = null
    private var resolvingA: String? = null
    private var resolvingB: String? = null
    private var autoEnabled = false
    private var autoFadeJob: Job? = null
    private val autoTriggerMs = 12_000L
    // Global physical blend policy: every automatic mode uses the same forgiving 12 s crossfade.
    private val autoFadeMs = AudioMixPolicy.GLOBAL_CROSSFADE_MS
    private val champagneFadeMs = AudioMixPolicy.GLOBAL_CROSSFADE_MS
    private val champagneTriggerMs = 21_000L
    private val champagneFConfidenceFloor = 0.35f
    private val champagneSyncGridConfidenceFloor = 0.42f
    private val champagneSyncMaxSpeedDelta = 0.04f
    private val transitionEngine by lazy { TransitionEngine(autoFadeMs, champagneFadeMs) }
    private val aidjSyncEngine by lazy {
        AidjSyncEngine(champagneSyncGridConfidenceFloor, champagneSyncMaxSpeedDelta)
    }

    private var controlsLocked = false

    // VIDEO SCREENSAVER: visual-only layer. It never owns, pauses, seeks or replaces A/B audio.
    private var videoScreensaverJob: Job? = null
    private var videoScreensaverWatcherJob: Job? = null
    private var videoScreensaverOverlay: FrameLayout? = null
    private var videoScreensaverWebView: WebView? = null
    private var videoScreensaverTrackUrl: String? = null
    private val videoScreensaverDelayMs = 25_000L
    private var masterDuck = 1f
    private var masterVolume = 0.89125f
    private var masterMuted = false
    // LOCK safety: MUTE reveals PAUSE; PAUSE preserves the loaded mix and becomes PLAY.
    private var lockedSafetyStopped = false
    private var lockedSafetyResumeA = false
    private var lockedSafetyResumeB = false
    private var lockedSafetyAutoWasEnabled = false
    private var resumeAAfterFocus = false
    private var resumeBAfterFocus = false
    private lateinit var audioManager: AudioManager
    private lateinit var audioFocusRequest: AudioFocusRequest

    private var endlessSeedMode = false
    private var endlessActive = false
    private var pendingEndlessStart = false
    private var pendingEndlessStartIsA: Boolean? = null
    private val endlessSeeds = mutableListOf<TrackRef>()
    private val endlessUsedUrls = linkedSetOf<String>()
    private val endlessUsedTrackKeys = linkedSetOf<String>()
    private val endlessSeedArtistKeys = linkedSetOf<String>()
    private var endlessNonSeedSelections = 0
    private val endlessPlayedAutoUrls = linkedSetOf<String>()
    private var endlessGenreProfile = EndlessGenreProfile.POP
    private var endlessSceneProfile = EndlessSceneProfile.GLOBAL
    private var endlessArtistOnlyMode = false
    private var endlessArtistOnlySeed: TrackRef? = null
    private var endlessArtistAllowLongTracks = false
    private val endlessArtistReplayQueue = ArrayDeque<TrackRef>()
    private val endlessRecent = mutableListOf<TrackRef>()
    private val endlessRecentArtists = mutableListOf<String>()
    // Authoritative anti-repeat history. ONLY tracks that actually become audible are recorded.
    // The history is persistent across mixes/app restarts and is shared by BASIC and QEM.
    // HARD rules: same song blocked for the next 20 played tracks; every credited performer
    // blocked for the next 15 played tracks. Search hits, rejected tracks and preload-only tracks
    // never enter this history. 1 ARTIST MIX bypasses only the artist ban (never the song ban).
    private val playedSongHardWindow = 20
    private val playedArtistHardWindow = 15
    private val playedHistoryRetention = 64
    private val historyGuard by lazy {
        HistoryGuard(this, playedSongHardWindow, playedArtistHardWindow, playedHistoryRetention)
    }

    // Small in-session list remains only for anchor/diagnostic compatibility. It is NOT an
    // independent cooldown authority; all repeat decisions come from persistentPlayedHistory.
    private val endlessPlayedArtistHistory = mutableListOf<TrackRef>()

    // BASIC and QEM discovery are deliberately isolated. They share only the physical A/B
    // playback/transition infrastructure; candidates/jobs may never cross a mode boundary.
    private var autoDiscoveryMotor = AutoDiscoveryMotor.NONE
    private var endlessQueued: TrackRef? = null // BASIC Slot 2 only
    private val qemEngine = QemEngine()
    private var basicWaitingFreeDeck: Boolean? = null
    /** Destination ownership is motor-local. BASIC and QEM can never share a waiting-deck marker. */
    private var activeWaitingFreeDeck: Boolean?
        get() = when (autoDiscoveryMotor) {
            AutoDiscoveryMotor.BASIC -> basicWaitingFreeDeck
            AutoDiscoveryMotor.QEM -> qemEngine.waitingFreeDeck
            AutoDiscoveryMotor.NONE -> null
        }
        set(value) {
            when (autoDiscoveryMotor) {
                AutoDiscoveryMotor.BASIC -> basicWaitingFreeDeck = value
                AutoDiscoveryMotor.QEM -> qemEngine.waitingFreeDeck = value
                AutoDiscoveryMotor.NONE -> if (value == null) {
                    basicWaitingFreeDeck = null
                    qemEngine.waitingFreeDeck = null
                }
            }
        }
    // QEM live-mode handoff: suppress the shared Basic Endless initial refill race until
    // QEM has adopted the live ACTIVE deck and explicitly loaded its validated NEXT.
    private var suppressInitialEndlessDiscovery = false
    // True only while QEM is taking ownership from another AUTO mode. Basic discovery is forbidden
    // during this window so a stale/global candidate can never cross the new hard QEM gates.
    private var endlessDiscoveryJob: Job? = null // BASIC discovery only
    private var lastDeadAirRecoveryLogAt = 0L
    private lateinit var qemFreeDeckWatchdog: QemFreeDeckWatchdog

    // VIRTUAL C / D CRATES. A and B are playback-only physical decks; these queues do the
    // slow discovery work while both physical decks are already occupied. C feeds A, D feeds B.
    // Nothing in these crates owns/stops/seeks a player. They are disposable metadata shelves.
    // QEM backstage runtime (queued candidate, discovery lifecycle, C/D crates and handoff jobs)
    // lives in QemEngine. MixerActivity only coordinates it with the physical A/B layer.
    private var endlessLoadJobA: Job? = null
    private var endlessLoadJobB: Job? = null
    private var endlessSessionGeneration = 0L
    private val endlessAnchorTracks = mutableListOf<TrackRef>()
    private val endlessPendingAnchorTracks = ArrayDeque<TrackRef>()
    private var endlessDiscoveriesSinceAnchorExpansion = 0
    private var lastContinuityGuardAt = 0L
    private var lastRecoveryAttemptAt = 0L
    private var endlessRecoveryDeck: Boolean? = null
    private var endlessModeLocked = false
    private val endlessPrefetchMs = 60_000L
    private val endlessReadyDeadlineMs = 15_000L
    private val endlessNextFreezeMs = 30_000L
    // FINAL 30 s = continuity sanctuary. If NEXT is physically playable, play it;
    // no late validation/ranking/cooldown decision may create dead air.
    private val endlessFinalSanctuaryMs = 30_000L
    private val endlessEarlySearchAtMs = 3_000L
    private var endlessDeckHasPlayedA = false
    private var endlessDeckHasPlayedB = false
    private var endlessDeckStateA = EndlessDeckState.FREE
    private var endlessDeckStateB = EndlessDeckState.FREE
    private var endlessSeedProtectedA = false
    private var endlessSeedProtectedB = false
    private var endlessManualProtectedA = false
    private var endlessManualProtectedB = false
    private var endlessPendingNextUrlA: String? = null
    private var endlessPendingNextUrlB: String? = null
    private var endlessAddMode = false
    private val endlessManualUrls = linkedSetOf<String>()
    private var mixInMsA = 0L
    private var mixInMsB = 0L
    private var mixOutMsA = 0L
    private var mixOutMsB = 0L

    private var quickDrawerOpen = false
    private val quickRegions = linkedSetOf<String>()
    private val quickEras = linkedSetOf<String>()
    private val quickStyles = linkedSetOf<String>()
    private var quickSceneOverride: EndlessSceneProfile? = null
    private var quickSessionAnchorTerms = ""
    private var quickSessionStyleTerms = ""
    private var quickLongFormDuration = false
    private var quickSessionActive = false
    private var oneArtistMixActive = false
    // QEM session/backstage state lives in QemEngine. MixerActivity retains only UI routing,
    // physical A/B ownership and the calls into discovery/admission policy during this phase.

    private fun markQemCandidate(track: TrackRef, artistId: String) {
        if (autoDiscoveryMotor != AutoDiscoveryMotor.QEM || qemEngine.filterFingerprint.isBlank()) return
        val artist = qemEngine.sessionArtistPool.firstOrNull { it.id == artistId } ?: return
        // Never trust the search query as proof of identity. A YouTube search for an EX-YU artist
        // may contain recommendations by unrelated artists. Only stamp a result after the result
        // itself proves the expected artist identity.
        if (!qemTrackMatchesArtist(track, artist)) return
        val key = endlessTrackKey(track)
        qemEngine.trackArtistIds[key] = artistId
        qemEngine.candidateStamps[key] = QemCandidateStamp(
            generation = qemEngine.discoveryGeneration,
            filterFingerprint = qemEngine.filterFingerprint,
            artistId = artistId
        )
    }

    private fun isCurrentQemCandidate(track: TrackRef): Boolean {
        if (autoDiscoveryMotor != AutoDiscoveryMotor.QEM) return false
        val stamp = qemEngine.candidateStamps[endlessTrackKey(track)] ?: return false
        if (stamp.generation != qemEngine.discoveryGeneration) return false
        if (stamp.filterFingerprint != qemEngine.filterFingerprint || qemEngine.filterFingerprint.isBlank()) return false
        val artist = qemEngine.sessionArtistPool.firstOrNull { it.id == stamp.artistId } ?: return false
        // FINAL identity airlock: re-check the actual returned track, not merely its old stamp.
        return qemTrackMatchesArtist(track, artist)
    }
    // Venue profile frozen for the active QUICK session; lower manual tempo overrides it.
    private var quickSessionTempoBand: String? = null
    private var quickStartJob: Job? = null

    private data class QemQuickRollbackSnapshot(
        val regions: Set<String>,
        val country: String?,
        val eras: Set<String>,
        val styles: Set<String>,
        val tempo: String?,
        val danceMode: QemDanceMode,
        val sessionArtistPool: List<QemFonoteka.ArtistChoice>,
        val sessionStyleKeys: Set<String>,
        val sessionEraKeys: Set<String>,
        val sessionInstrumental: Boolean,
        val sessionPiano: Boolean,
        val sessionDanceMode: QemDanceMode,
        val filterFingerprint: String,
        val sessionTempoBand: String?,
        val longForm: Boolean,
        val queued: TrackRef?,
        val candidateStamps: Map<String, QemCandidateStamp>,
        val trackArtistIds: Map<String, String>,
        val recentArtistIds: List<String>,
        val virtualC: List<TrackRef>,
        val virtualD: List<TrackRef>
    )
    private var qemQuickRollbackSnapshot: QemQuickRollbackSnapshot? = null

    // QUICK startup invariant: A is the sole playback owner until the first real A→B transition.
    // Any delayed/stale play request on B is rejected while this guard is armed.
    private var quickStartupGuardA = false
    // Universal human-friendly tempo preference. Null means unrestricted.
    private var tempoBand: String? = null
    // A NEXT deck may become READY only after real-audio BPM validation when a tempo profile is active.
    private var tempoValidatedA = true
    private var tempoValidatedB = true
    private var measuredBpmA: Float? = null
    private var measuredBpmB: Float? = null
    // Optional precise country refinement for QUICK. REGION buttons override/clear this value.
    private var quickCountry: String? = null
    private var endlessActiveOwnerIsA: Boolean? = null
    private var endlessOwnerStartedAtMs = 0L
    private var endlessLastRefillKickAtMs = 0L
    // Rare transport hiccup guard: while LOCK + AUTO are active, an established ACTIVE deck
    // that unexpectedly stops mid-song gets a short grace period before any recovery action.
    // This is intentionally conservative so buffering/transient callbacks cannot trigger a mix.
    private var unexpectedActiveStopSinceA = 0L
    private var unexpectedActiveStopSinceB = 0L
    private val unexpectedActiveStopGraceMs = 3_000L

    private fun queuedForActiveMotor(): TrackRef? = when (autoDiscoveryMotor) {
        AutoDiscoveryMotor.QEM -> qemEngine.queued
        AutoDiscoveryMotor.BASIC -> endlessQueued
        AutoDiscoveryMotor.NONE -> null
    }

    private fun queueForActiveMotor(track: TrackRef) {
        when (autoDiscoveryMotor) {
            AutoDiscoveryMotor.QEM -> if (qemEngine.queued == null) qemEngine.queued = track
            AutoDiscoveryMotor.BASIC -> if (endlessQueued == null) endlessQueued = track
            AutoDiscoveryMotor.NONE -> Unit
        }
    }

    private fun clearQueuedForActiveMotor() {
        when (autoDiscoveryMotor) {
            AutoDiscoveryMotor.QEM -> qemEngine.queued = null
            AutoDiscoveryMotor.BASIC -> endlessQueued = null
            AutoDiscoveryMotor.NONE -> Unit
        }
    }

    private fun discoveryActiveForMotor(): Boolean = when (autoDiscoveryMotor) {
        AutoDiscoveryMotor.QEM -> qemEngine.discoveryJob?.isActive == true
        AutoDiscoveryMotor.BASIC -> endlessDiscoveryJob?.isActive == true
        AutoDiscoveryMotor.NONE -> false
    }

    /**
     * AUTO owner is authoritative. Session/UI booleans are mirrors only and are never allowed
     * to silently demote QEM to BASIC during NEXT transitions or a hot QEM filter change.
     */
    private fun enforceAutoOwnerInvariant() {
        if (!endlessActive) return
        when (autoDiscoveryMotor) {
            AutoDiscoveryMotor.QEM -> {
                quickSessionActive = true
                autoEnabled = true
            }
            AutoDiscoveryMotor.BASIC -> {
                if (!oneArtistMixActive) quickSessionActive = false
            }
            AutoDiscoveryMotor.NONE -> Unit
        }
    }

    private fun switchDiscoveryMotor(newMotor: AutoDiscoveryMotor) {
        if (autoDiscoveryMotor == newMotor) return
        // NEXT loader jobs belong to the old discovery motor. They are never ACTIVE playback jobs,
        // so cancelling them at the ownership boundary cannot interrupt the song that is audible.
        endlessLoadJobA?.cancel(); endlessLoadJobA = null
        endlessLoadJobB?.cancel(); endlessLoadJobB = null
        // Cancel and invalidate the OLD motor completely. ACTIVE audio is not touched.
        when (autoDiscoveryMotor) {
            AutoDiscoveryMotor.BASIC -> {
                endlessDiscoveryJob?.cancel(); endlessDiscoveryJob = null
                endlessQueued = null
                basicWaitingFreeDeck = null
            }
            AutoDiscoveryMotor.QEM -> {
                qemEngine.discoveryGeneration++
                qemEngine.discoveryJob?.cancel(); qemEngine.discoveryJob = null
                qemEngine.queued = null
                qemEngine.waitingFreeDeck = null
                qemEngine.candidateStamps.clear()
            }
            AutoDiscoveryMotor.NONE -> Unit
        }
        autoDiscoveryMotor = newMotor
        when (newMotor) {
            AutoDiscoveryMotor.BASIC -> {
                qemEngine.discoveryGeneration++; qemEngine.discoveryJob?.cancel(); qemEngine.discoveryJob = null; qemEngine.queued = null
                qemEngine.waitingFreeDeck = null; qemEngine.candidateStamps.clear(); qemEngine.filterFingerprint = ""
            }
            AutoDiscoveryMotor.QEM -> {
                endlessDiscoveryJob?.cancel(); endlessDiscoveryJob = null; endlessQueued = null; basicWaitingFreeDeck = null
                qemEngine.discoveryGeneration++; qemEngine.waitingFreeDeck = null; qemEngine.candidateStamps.clear()
            }
            AutoDiscoveryMotor.NONE -> {
                endlessDiscoveryJob?.cancel(); endlessDiscoveryJob = null; endlessQueued = null; basicWaitingFreeDeck = null
                qemEngine.discoveryGeneration++; qemEngine.discoveryJob?.cancel(); qemEngine.discoveryJob = null; qemEngine.queued = null
                qemEngine.waitingFreeDeck = null; qemEngine.candidateStamps.clear(); qemEngine.filterFingerprint = ""
            }
        }
    }

    private val speechLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != RESULT_OK || !::binding.isInitialized) return@registerForActivityResult
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
            ?.trim()
            .orEmpty()
        if (spoken.isNotBlank()) {
            val overlay = addToMixOverlayInput
            if (overlay != null) {
                overlay.setText(spoken)
                overlay.setSelection(spoken.length)
                runAddToMixOverlaySearch()
            } else {
                binding.endlessSearchInput.setText(spoken)
                binding.endlessSearchInput.setSelection(spoken.length)
                runEndlessSearch()
            }
        }
    }

    private val micPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchSpeechRecognizer()
    }

    // BLACK BOX: tiny persistent flight recorder for the deterministic transition blackout.
    // It records only local engine events and survives a process crash. No network, no analytics.
    private val flightLock = Any()
    private fun flight(event: String) {
        try {
            val line = "${System.currentTimeMillis()} | ${SystemClock.elapsedRealtime()} | $event\n"
            synchronized(flightLock) {
                val f = File(filesDir, "endlessmix_flight.txt")
                f.appendText(line)
                // Keep the recorder bounded so it can never become its own problem.
                if (f.length() > 64 * 1024) {
                    val tail = f.readLines().takeLast(180).joinToString("\n", postfix = "\n")
                    f.writeText(tail)
                }
            }
        } catch (_: Throwable) { /* recorder must never affect playback */ }
    }

    // BB 3: MusicBrainz -> D1 Fonoteka harvester. Completely isolated from playback/crash/BPM logs.
    private val fonotekaFlightLock = Any()
    private fun fonotekaFlight(event: String) {
        try {
            val line = "${System.currentTimeMillis()} | ${SystemClock.elapsedRealtime()} | $event\n"
            synchronized(fonotekaFlightLock) {
                val f = File(filesDir, "endlessmix_fonoteka_flight.txt")
                f.appendText(line)
                if (f.length() > 48 * 1024) {
                    val tail = f.readLines().takeLast(160).joinToString("\n", postfix = "\n")
                    f.writeText(tail)
                }
            }
        } catch (_: Throwable) { }
    }

    // BB 4: AI DJ / Champagne selection + future beat-grid/sync diagnostics.
    // Kept isolated so experimental DJ logic can never bury BPM, Fonoteka, or crash evidence.
    private val aidjFlightLock = Any()
    private fun aidjFlight(event: String) {
        try {
            val line = "${System.currentTimeMillis()} | ${SystemClock.elapsedRealtime()} | $event\n"
            synchronized(aidjFlightLock) {
                val f = File(filesDir, "endlessmix_aidj_flight.txt")
                f.appendText(line)
                if (f.length() > 48 * 1024) {
                    val tail = f.readLines().takeLast(160).joinToString("\n", postfix = "\n")
                    f.writeText(tail)
                }
            }
        } catch (_: Throwable) { }
    }

    // Separate BPM black box: network/catalog diagnostics must never bury crash/playback evidence.
    private val bpmFlightLock = Any()
    private fun bpmFlight(event: String) {
        try {
            val line = "${System.currentTimeMillis()} | ${SystemClock.elapsedRealtime()} | $event\n"
            synchronized(bpmFlightLock) {
                val f = File(filesDir, "endlessmix_bpm_flight.txt")
                f.appendText(line)
                if (f.length() > 48 * 1024) {
                    val tail = f.readLines().takeLast(160).joinToString("\n", postfix = "\n")
                    f.writeText(tail)
                }
            }
        } catch (_: Throwable) { }
    }

    private fun installFlightCrashRecorder() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                val sw = StringWriter()
                error.printStackTrace(PrintWriter(sw))
                flight("FATAL thread=${thread.name} ${error.javaClass.name}: ${error.message}\\n${sw}")
            } catch (_: Throwable) { }
            previous?.uncaughtException(thread, error)
        }
    }


    private fun showRecorder(fileName: String, title: String, emptyText: String, clipboardLabel: String, lock: Any) {
        try {
            val f = File(filesDir, fileName)
            val text = if (f.exists()) f.readLines().takeLast(140).joinToString("\n").ifBlank { emptyText } else emptyText
            val pad = dp(14)
            val logView = TextView(this).apply {
                setBackgroundColor(Color.BLACK); setTextColor(Color.WHITE); textSize = 16f
                typeface = android.graphics.Typeface.MONOSPACE; setPadding(pad, pad, pad, pad)
                setTextIsSelectable(true); this.text = text
            }
            val scroll = ScrollView(this).apply {
                setBackgroundColor(Color.BLACK)
                addView(logView, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            AlertDialog.Builder(this)
                .setTitle(title).setView(scroll).setPositiveButton("CLOSE", null)
                .setNegativeButton("COPY ALL") { _, _ ->
                    try {
                        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText(clipboardLabel, text))
                        Toast.makeText(this, "BB COPIED", Toast.LENGTH_SHORT).show()
                    } catch (_: Throwable) { Toast.makeText(this, "COPY FAILED", Toast.LENGTH_SHORT).show() }
                }
                .setNeutralButton("CLEAR") { _, _ ->
                    try { synchronized(lock) { File(filesDir, fileName).writeText("") }; Toast.makeText(this, "BLACK BOX CLEARED", Toast.LENGTH_SHORT).show() } catch (_: Throwable) { }
                }.show()
        } catch (_: Throwable) { Toast.makeText(this, "BLACK BOX UNAVAILABLE", Toast.LENGTH_SHORT).show() }
    }

    private fun showCrashBlackBox() {
        flight("BB_CRASH_OPEN")
        showRecorder("endlessmix_flight.txt", "BB 2 — CRASH LANDING", "CRASH BLACK BOX EMPTY", "EndlessMix Crash Landing", flightLock)
    }

    private fun showBpmBlackBox() {
        bpmFlight("BB_BPM_OPEN")
        showRecorder("endlessmix_bpm_flight.txt", "BB 1 — BPM", "BPM BLACK BOX EMPTY", "EndlessMix BPM", bpmFlightLock)
    }

    private fun showFonotekaBlackBox() {
        fonotekaFlight("BB_FONOTEKA_OPEN")
        showRecorder("endlessmix_fonoteka_flight.txt", "BB 3 — FONOTEKA", "FONOTEKA BLACK BOX EMPTY", "EndlessMix Fonoteka", fonotekaFlightLock)
    }


    private fun showAidjBlackBox() {
        aidjFlight("BB_AIDJ_OPEN")
        showRecorder("endlessmix_aidj_flight.txt", "BB 4 — AIDJ", "AIDJ BLACK BOX EMPTY", "EndlessMix AIDJ", aidjFlightLock)
    }

    // Unified rolling BB: one compact report across all existing recorders.
    // This is deliberately read-only with respect to the DJ engines: it only merges recent evidence.
    private fun showUnifiedBlackBox() {
        try {
            val cutoff = System.currentTimeMillis() - 5L * 60L * 1000L
            data class BbLine(val epoch: Long, val source: String, val raw: String)
            val sources = listOf(
                "PLAYBACK/QEM" to "endlessmix_flight.txt",
                "FONOTEKA" to "endlessmix_fonoteka_flight.txt",
                "BPM" to "endlessmix_bpm_flight.txt",
                "AIDJ/DECK-Z" to "endlessmix_aidj_flight.txt"
            )
            val recent = sources.flatMap { (source, fileName) ->
                val f = File(filesDir, fileName)
                if (!f.exists()) emptyList() else f.readLines().mapNotNull { line ->
                    val epoch = line.substringBefore(" | ").trim().toLongOrNull() ?: return@mapNotNull null
                    if (epoch < cutoff) null else BbLine(epoch, source, line)
                }
            }.sortedBy { it.epoch }.takeLast(260)

            val header = "ENDLESSMIX UNIFIED BB — LAST ~5 MIN\n" +
                "A/B + QEM/BASIC + C/D/HANDOFF + TRANSITION + FONOTEKA + BPM/AIDJ + DECK Z + CRASH\n\n"
            val text = if (recent.isEmpty()) header + "NO EVENTS IN THE LAST ~5 MIN" else
                header + recent.joinToString("\n") { "[${it.source}] ${it.raw}" }

            val pad = dp(14)
            val logView = TextView(this).apply {
                setBackgroundColor(Color.BLACK); setTextColor(Color.WHITE); textSize = 15f
                typeface = android.graphics.Typeface.MONOSPACE; setPadding(pad, pad, pad, pad)
                setTextIsSelectable(true); this.text = text
            }
            val scroll = ScrollView(this).apply {
                setBackgroundColor(Color.BLACK)
                addView(logView, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            AlertDialog.Builder(this)
                .setTitle("BLACK BOX — LAST 5 MIN")
                .setView(scroll)
                .setPositiveButton("CLOSE", null)
                .setNegativeButton("COPY ALL") { _, _ ->
                    try {
                        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("EndlessMix Unified BB", text))
                        Toast.makeText(this, "BB COPIED", Toast.LENGTH_SHORT).show()
                    } catch (_: Throwable) { Toast.makeText(this, "COPY FAILED", Toast.LENGTH_SHORT).show() }
                }
                .setNeutralButton("CLEAR ALL") { _, _ ->
                    try {
                        synchronized(flightLock) { File(filesDir, "endlessmix_flight.txt").writeText("") }
                        synchronized(fonotekaFlightLock) { File(filesDir, "endlessmix_fonoteka_flight.txt").writeText("") }
                        synchronized(bpmFlightLock) { File(filesDir, "endlessmix_bpm_flight.txt").writeText("") }
                        synchronized(aidjFlightLock) { File(filesDir, "endlessmix_aidj_flight.txt").writeText("") }
                        Toast.makeText(this, "BLACK BOX CLEARED", Toast.LENGTH_SHORT).show()
                    } catch (_: Throwable) { }
                }
                .show()
        } catch (_: Throwable) {
            Toast.makeText(this, "BLACK BOX UNAVAILABLE", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showPreviousFlightIfNeeded() {
        try {
            val f = File(filesDir, "endlessmix_flight.txt")
            if (!f.exists()) return
            val lines = f.readLines().takeLast(24)
            val fatal = lines.indexOfLast { it.contains(" | FATAL ") }
            if (fatal < 0) return
            val prefs = getSharedPreferences("flight_recorder", MODE_PRIVATE)
            val signature = lines.drop(fatal).joinToString("\n").hashCode()
            if (prefs.getInt("shown", 0) == signature) return
            prefs.edit().putInt("shown", signature).apply()
            AlertDialog.Builder(this)
                .setTitle("ENDLESSMIX BLACK BOX")
                .setMessage(lines.drop(fatal).joinToString("\n").take(6000))
                .setPositiveButton("OK", null)
                .show()
        } catch (_: Throwable) { }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installFlightCrashRecorder()
        flight("ACTIVITY_ON_CREATE saved=${savedInstanceState != null}")
        showPreviousFlightIfNeeded()
        binding = ActivityMixerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // MUSIC HOTEL: FREE-deck continuity monitoring lives in a tiny coordinator instead of
        // MixerActivity owning another long-lived timing loop. The helper sees snapshots only and
        // can do nothing except ask the existing NEXT PLEASE path to run again.
        qemFreeDeckWatchdog = QemFreeDeckWatchdog(
            scope = lifecycleScope,
            snapshot = { isA ->
                QemFreeDeckWatchdog.Snapshot(
                    endlessActive = endlessActive,
                    autoEnabled = autoEnabled,
                    deckFree = if (isA) endlessDeckStateA == EndlessDeckState.FREE else endlessDeckStateB == EndlessDeckState.FREE,
                    deckPlaying = if (isA) playerA.isPlaying else playerB.isPlaying,
                    qemQueued = qemEngine.queued != null,
                    discoveryActive = qemEngine.discoveryJob?.isActive == true,
                )
            },
            requestNext = { isA -> requestNextPlease(isA) },
            restartStalledDiscovery = { isA, elapsedMs -> restartQemDiscoveryForFreeDeck(isA, elapsedMs) },
            log = ::flight,
        )

        // LUX BACK WALL SPLIT: the gold jukebox mesh belongs only BELOW the crossfader.
        // Above the crossfader the live valve/electronics board must remain unobstructed.
        binding.mixerRoot.post {
            // crossFaderArea.bottom is local to its LinearLayout parent. The mesh is a direct child
            // of mixerRoot, so calculate the crossfader bottom in root coordinates.
            val rootLocation = IntArray(2)
            val crossfaderLocation = IntArray(2)
            binding.mixerRoot.getLocationOnScreen(rootLocation)
            binding.crossFaderArea.getLocationOnScreen(crossfaderLocation)
            val meshTop = crossfaderLocation[1] - rootLocation[1] + binding.crossFaderArea.height
            val rootHeight = binding.mixerRoot.height
            if (meshTop > 0 && rootHeight > meshTop) {
                binding.jukeboxMeshBackWall.y = meshTop.toFloat()
                binding.jukeboxMeshBackWall.layoutParams = binding.jukeboxMeshBackWall.layoutParams.apply {
                    height = rootHeight - meshTop
                }
            }
        }

        initDeckZ()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        loadPersistentPlaybackHistory()
        // Fonoteka refresh is completely outside the audio engine. It can never touch ACTIVE/NEXT.
        lifecycleScope.launch { FonotekaUpdateManager(this@MixerActivity).checkDaily() }
        EngineRulesStore.initialize(this)
        lifecycleScope.launch { EngineRulesUpdateManager(this@MixerActivity).checkDaily() }

        val loadControlA = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 40_000, 2_500, 2_500)
            .setBackBuffer(20_000, true)
            .build()
        val loadControlB = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 40_000, 2_500, 2_500)
            .setBackBuffer(20_000, true)
            .build()
        val runtimePlayers = PlaybackRuntime.acquire(this, loadControlA, loadControlB)
        playerA = runtimePlayers.first
        playerB = runtimePlayers.second
        playerA.setWakeMode(C.WAKE_MODE_NETWORK)
        playerB.setWakeMode(C.WAKE_MODE_NETWORK)
        setupAudioFocusProtection()
        playerListenerA = addPlayerListener(playerA, true)
        playerListenerB = addPlayerListener(playerB, false)

        // Activity recreation must NEVER be allowed to reset the process-lifetime audio chassis.
        // The two ExoPlayers survive in PlaybackRuntime while the foreground guard is alive.
        // If Android rebuilds this Activity (memory/configuration/window event), adopt those live
        // players and restore the controller snapshot instead of treating onCreate as a cold launch.
        val restoringLiveRuntime = savedInstanceState != null &&
            (playerA.mediaItemCount > 0 || playerB.mediaItemCount > 0 || playerA.isPlaying || playerB.isPlaying)

        endlessAdapter = SearchAdapter(
            targetDeck = null,
            onImportA = {},
            onImportB = {},
            onSelect = { selectEndlessSeed(it) }
        )
        binding.endlessResults.layoutManager = LinearLayoutManager(this)
        binding.endlessResults.adapter = endlessAdapter

        binding.loadA.setOnClickListener { openSearchFor("A") }
        binding.loadB.setOnClickListener { openSearchFor("B") }

        binding.playA.setOnClickListener {
            cancelAutoFadeForManualControl()
            MixerStore.deckA?.let { toggleDeck(true, it) }
                ?: Toast.makeText(this, "Press A to load a song", Toast.LENGTH_SHORT).show()
        }
        binding.playB.setOnClickListener {
            cancelAutoFadeForManualControl()
            MixerStore.deckB?.let { toggleDeck(false, it) }
                ?: Toast.makeText(this, "Press B to load a song", Toast.LENGTH_SHORT).show()
        }

        binding.autoMix.setOnClickListener {
            if (endlessActive) {
                Toast.makeText(this, "Endless Mix controls AUTO", Toast.LENGTH_SHORT).show()
            } else {
                autoEnabled = !autoEnabled
                updateAutoButton()
            }
        }

        binding.aiDjMode.setOnClickListener {
            if (controlsLocked) { showLockedControlNotice(); return@setOnClickListener }
            aiDjVoiceEnabled = !aiDjVoiceEnabled
            if (aiDjVoiceEnabled) deckZMixCounter = 0
            updateDeckZButton()
        }

        binding.waveA.onSeekRequested = { fraction ->
            seekDeck(playerA, fraction)
        }
        binding.waveB.onSeekRequested = { fraction ->
            seekDeck(playerB, fraction)
        }

        binding.volumeA.progress = 100
        binding.volumeA.onProgressChanged = { p ->
            userVolA = p / 100f
            applyVolumes()
        }
        binding.volumeB.progress = 100
        binding.volumeB.onProgressChanged = { p ->
            userVolB = p / 100f
            applyVolumes()
        }

        binding.masterVolume.progress = 89
        binding.masterVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                masterVolume = progress / 100f
                applyVolumes()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        binding.masterMute.setOnClickListener {
            masterMuted = !masterMuted
            updateMasterMuteUi()
            applyVolumes()
        }
        updateMasterMuteUi()

        // Cold launch begins hard-left. Activity RECREATION is different: the live mixer already
        // has an audible owner, so restoring at A would instantly mute/cross-eye a surviving B deck.
        cross = if (restoringLiveRuntime) {
            savedInstanceState?.getFloat(STATE_CROSS, if (playerA.isPlaying) 0f else 1f) ?: 0f
        } else 0f
        binding.crossfader.progress = (cross * 100f).roundToInt().coerceIn(0, 100)
        applyVolumes()

        binding.crossfader.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    cancelAutoFadeForManualControl()
                    cross = progress / 100f
                    applyVolumes()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                cancelAutoFadeForManualControl()
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        binding.endlessAction.setOnClickListener { onEndlessAction() }
        binding.endlessSearchButton.setOnClickListener { runEndlessSearch() }
        binding.endlessVoiceButton.setOnClickListener { requestEndlessVoiceSearch() }
        binding.mixLock.setOnClickListener { toggleControlLock() }
        binding.quickAddToMix.setOnClickListener { requestAddToMix() }
        binding.mainAddToMix.setOnClickListener { requestAddToMix() }
        binding.unifiedBlackBox.setOnClickListener { showUnifiedBlackBox() }
        setupQuickEndlessUi()
        binding.basicEndlessButton.setOnClickListener {
            if (controlsLocked) { showLockedControlNotice(); return@setOnClickListener }
            val alreadyBasic = endlessActive && !quickSessionActive && !oneArtistMixActive
            if (alreadyBasic) {
                stopEndlessMix()
                updateModeButtons()
                return@setOnClickListener
            }
            if (endlessActive) stopEndlessMix()
            oneArtistMixActive = false
            quickSessionActive = false
            switchDiscoveryMotor(AutoDiscoveryMotor.BASIC)
            onEndlessAction()
            updateModeButtons()
        }
        binding.oneArtistMixButton.setOnClickListener {
            if (controlsLocked) { showLockedControlNotice(); return@setOnClickListener }
            if (endlessActive && oneArtistMixActive) {
                stopEndlessMix()
                updateModeButtons()
            } else {
                showOneArtistMixPopup()
            }
        }
        binding.startEndlessAutoMix.setOnClickListener {
            if (!endlessActive && MixerStore.deckA != null && MixerStore.deckB != null) {
                oneArtistMixActive = false
                quickSessionActive = false
                switchDiscoveryMotor(AutoDiscoveryMotor.BASIC)
                onEndlessAction()
                updateModeButtons()
            }
        }
        binding.instantNextA.setOnClickListener { if (canInstantNext(fromA = true)) startAutoTransition(fromA = true) }
        binding.instantNextB.setOnClickListener { if (canInstantNext(fromA = false)) startAutoTransition(fromA = false) }

        fun toggleLiveFilter() {
            if (!controlsLocked) {
                allowLive = !allowLive
                updateEndlessFilterButtons()
            }
        }
        fun toggleCoverFilter() {
            if (!controlsLocked) {
                allowCover = !allowCover
                updateEndlessFilterButtons()
            }
        }
        fun toggleOfficialFilter() {
            if (!controlsLocked) {
                onlyOfficial = !onlyOfficial
                updateEndlessFilterButtons()
            }
        }

        binding.filterLive.setOnClickListener { toggleLiveFilter() }
        binding.filterCover.setOnClickListener { toggleCoverFilter() }
        binding.filterOfficial.setOnClickListener { toggleOfficialFilter() }
        binding.quickFilterLive.setOnClickListener { toggleLiveFilter() }
        binding.quickFilterCover.setOnClickListener { toggleCoverFilter() }
        binding.quickFilterOfficial.setOnClickListener { toggleOfficialFilter() }

        fun toggleCrossfade() {
            crossfadeEnabled = !crossfadeEnabled
            updateCrossfadeButton()
        }
        binding.crossfadeMode.setOnClickListener { toggleCrossfade() }
        binding.lockedCrossfadeMode.setOnClickListener { toggleCrossfade() }
        binding.quickCrossfadeMode.setOnClickListener { toggleCrossfade() }
        binding.endlessSearchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                runEndlessSearch()
                true
            } else false
        }

        if (restoringLiveRuntime) {
            restoreMixerControllerState(savedInstanceState!!)
            bindDeckUiToSurvivingRuntime()
            // A recreated Activity has no running discovery coroutine of its own. Re-arm only the
            // controller work; never reload/seek/stop the surviving ACTIVE or READY_NEXT players.
            if (endlessActive && autoEnabled) {
                enforceAutoOwnerInvariant()
                scheduleContinuityCheck(150L)
            }
        } else {
            refreshDecks(force = true)
            syncSeedsFromCurrentDecks()
        }
        updateAutoButton()
        updateEndlessAction()
        updateControlLockUi()
        updateEndlessFilterButtons()
        updateCrossfadeButton()
        applyVolumes()

        lifecycleScope.launch {
            while (isActive) {
                updateDeckUi(playerA, true)
                updateDeckUi(playerB, false)
                updateArtistArtworkUi()
                checkAutoMix()
                // QUICK owns its own strict two-seed start barrier. Never auto-start merely
                // because both MixerStore slots are non-null; one/both players may still be
                // resolving or buffering, and a stale deck must never become audible.
                protectEndlessContinuity()
                updateCrossSpectrum()
                updateMasterVuMeters()
                updateContextualModeUi()
                updateInstantNextButtons()
                delay(100)
            }
        }
    }

    private fun addPlayerListener(player: ExoPlayer, isA: Boolean): Player.Listener {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                val button = if (isA) binding.playA else binding.playB
                when (playbackState) {
                    Player.STATE_BUFFERING -> {
                        button.text = "LOADING"
                        setPlayColor(button, false)
                    }
                    Player.STATE_READY -> {
                        updatePlayButton(isA)
                        if (endlessActive && !player.isPlaying) {
                            val state = if (isA) endlessDeckStateA else endlessDeckStateB
                            // Only a deck we explicitly loaded as NEXT may become READY_NEXT.
                            // A spent paused deck can remain ExoPlayer STATE_READY at -0:04; FREE
                            // must remain FREE even if ExoPlayer reports READY again.
                            val tempoOk = if (isA) tempoValidatedA else tempoValidatedB
                            if (state == EndlessDeckState.LOADING_NEXT && tempoOk) {
                                if (isA) endlessDeckStateA = EndlessDeckState.READY_NEXT
                                else endlessDeckStateB = EndlessDeckState.READY_NEXT
                            }
                        }
                        if (endlessActive && pendingEndlessStart && pendingEndlessStartIsA == isA) {
                            pendingEndlessStart = false
                            pendingEndlessStartIsA = null
                            player.play()
                        }
                        if (endlessActive && endlessRecoveryDeck == isA && !playerA.isPlaying && !playerB.isPlaying) {
                            cross = if (isA) 0f else 1f
                            binding.crossfader.progress = if (isA) 0 else 100
                            applyVolumes()
                            applyEndlessMixInPoint(player, targetIsA = isA)
                            player.play()
                            (if (isA) MixerStore.deckA else MixerStore.deckB)?.let { markEndlessAutoPlayed(it) }
                            endlessRecoveryDeck = null
                            activeWaitingFreeDeck = null
                            discoverQueuedCandidate()
                        }
                    }
                    Player.STATE_ENDED -> {
                        if (isA) unexpectedActiveStopSinceA = 0L else unexpectedActiveStopSinceB = 0L
                        if ((isA && endlessSeedProtectedA) || (!isA && endlessSeedProtectedB)) return
                        if (isA) endlessDeckStateA = EndlessDeckState.FREE else endlessDeckStateB = EndlessDeckState.FREE
                        button.text = "PLAY"
                        setPlayColor(button, false)
                        updateLoadButtons()
                        if (endlessActive && autoFadeJob?.isActive != true) {
                            // STRICT A/B ALTERNATION: when the ACTIVE deck reaches END, the next
                            // physical owner is the OPPOSITE deck. The spent deck is FREE for the
                            // song after that, but it must never nominate itself for immediate
                            // recovery (the old behavior caused A→A when NEXT preparation was late).
                            val endedWasOwner = endlessActiveOwnerIsA == isA
                            val nextIsA = if (endedWasOwner) !isA else endlessActiveOwnerIsA?.not()
                            if (nextIsA != null) {
                                activeWaitingFreeDeck = nextIsA
                                if (!playerA.isPlaying && !playerB.isPlaying) endlessRecoveryDeck = nextIsA
                                val nextState = if (nextIsA) endlessDeckStateA else endlessDeckStateB
                                if (nextState == EndlessDeckState.FREE) {
                                    // Use the same physical NEXT PLEASE path used after a normal
                                    // transition. For QEM this consumes parked qemEngine.queued / C-D first
                                    // and only searches when nothing prepared exists.
                                    requestNextPlease(nextIsA)
                                } else {
                                    // READY_NEXT/LOADING_NEXT on the opposite deck is already the
                                    // correct successor. Let the watchdog/start callback promote it;
                                    // never overwrite it with a queued candidate.
                                    discoverQueuedCandidate()
                                }
                                flight("END_ALTERNATION ended=${if (isA) "A" else "B"} owner=$endedWasOwner next=${if (nextIsA) "A" else "B"}")
                            } else {
                                // No established owner (startup/manual edge). Preserve continuity
                                // without inventing same-deck ownership; discovery will re-read the
                                // physical A/B state on its next watchdog pass.
                                discoverQueuedCandidate()
                            }
                        }
                    }
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                val liveTrack = if (isA) MixerStore.deckA else MixerStore.deckB
                flight("PLAYER_STATE deck=${if (isA) "A" else "B"} isPlaying=$isPlaying state=${player.playbackState} title=${liveTrack?.title?.take(100) ?: "EMPTY"}")
                if (endlessActive && isPlaying) {
                    if (isA) unexpectedActiveStopSinceA = 0L else unexpectedActiveStopSinceB = 0L
                    // Absolute QUICK start gate: until the first intentional A→B crossfade begins,
                    // B may NEVER become audible. This catches stale ExoPlayer autoplay callbacks,
                    // late prepare completions and manual state races at session startup.
                    if (quickStartupGuardA && !isA) {
                        player.pause()
                        updatePlayButton(isA)
                        updateLoadButtons()
                        return
                    }
                    var state = if (isA) endlessDeckStateA else endlessDeckStateB
                    val crossfadeRunning = autoFadeJob?.isActive == true

                    // During an intentional crossfade the transport is authoritative: the incoming
                    // deck was explicitly granted PLAYING immediately before target.play(). A late
                    // preload/refresh callback must never demote that live deck back to LOADING_NEXT
                    // or READY_NEXT. Repair only inside the known crossfade window; outside it the
                    // hard single-owner rule below still catches stale/autoplay callbacks.
                    if (crossfadeRunning && state != EndlessDeckState.PLAYING) {
                        flight("STATE_REPAIR deck=${if (isA) "A" else "B"} from=$state to=PLAYING reason=intentional_crossfade")
                        if (isA) endlessDeckStateA = EndlessDeckState.PLAYING else endlessDeckStateB = EndlessDeckState.PLAYING
                        state = EndlessDeckState.PLAYING
                    }

                    // HARD single-owner playback rule. A prepared NEXT deck is not allowed to
                    // promote itself to PLAYING just because ExoPlayer received a stale/delayed
                    // play request. Only a deck already explicitly granted PLAYING state may run.
                    // The sole exception is the intentional crossfade window, when both decks
                    // are allowed to be audible at the same time.
                    if (state != EndlessDeckState.PLAYING && !crossfadeRunning) {
                        player.pause()
                        updatePlayButton(isA)
                        updateLoadButtons()
                        return
                    }

                    if (isA) {
                        endlessSeedProtectedA = false
                        endlessDeckHasPlayedA = true
                    } else {
                        endlessSeedProtectedB = false
                        endlessDeckHasPlayedB = true
                    }
                    // Playback itself is authoritative. Search/load events do not enter history.
                    (if (isA) MixerStore.deckA else MixerStore.deckB)?.let { rememberActuallyPlayedTrack(it) }
                }
                updatePlayButton(isA)
                updateLoadButtons()
                syncPlaybackProtectionService()
            }
        }
        player.addListener(listener)
        return listener
    }

    private fun openSearchFor(deck: String) {
        startActivity(Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_TARGET_DECK, deck))
    }

    private fun prepareDeck(isA: Boolean, track: TrackRef) {
        val deck = if (isA) "A" else "B"
        val player = if (isA) playerA else playerB
        val button = if (isA) binding.playA else binding.playB
        val direct = track.streamUrl
        flight("TRACK_PREPARE_ENTER deck=$deck title=${track.title.take(100)} stream=${direct != null}")
        if (direct == null) {
            flight("TRACK_PREPARE_SKIP deck=$deck reason=no_stream")
            return
        }

        button.text = "LOADING"
        button.isEnabled = false
        setPlayColor(button, false)
        // Never let a previous deck's playWhenReady leak into a newly prepared track.
        // Playback permission is granted explicitly by the deck state machine only.
        player.pause()
        player.playWhenReady = false
        player.setMediaItem(MediaItem.fromUri(direct))
        player.prepare()
        flight("TRACK_PREPARE_SENT deck=$deck mediaItems=${player.mediaItemCount}")

        // Canonical cloud-BPM trigger: every successfully prepared physical deck gets metadata
        // enrichment, including initial QEM/BASIC seeds and manual loads. Previously the trigger
        // lived only in the automatic NEXT-loading path, so startup tracks could play forever
        // without ever asking the Worker for BPM. This remains asynchronous and playback-neutral.
        prefetchCloudTrackMetadata(isA, track)
    }

    private fun toggleDeck(isA: Boolean, track: TrackRef) {
        if (::audioFocusRequest.isInitialized) audioManager.requestAudioFocus(audioFocusRequest)
        val player = if (isA) playerA else playerB
        if (player.mediaItemCount == 0) {
            resolvePrepareAnalyze(isA, track)
            return
        }
        if (player.playbackState == Player.STATE_READY || player.playbackState == Player.STATE_BUFFERING) {
            if (player.isPlaying) player.pause() else player.play()
        }
    }

    private fun refreshDecks(force: Boolean = false, onlyIsA: Boolean? = null) {
        val a = MixerStore.deckA
        val b = MixerStore.deckB

        if (onlyIsA != false && !playerA.isPlaying && (force || a?.url != lastTrackAUrl)) {
            // ABSOLUTE PLAYBACK FIREWALL: no refresh caller is ever allowed to stop/clear
            // the currently audible transport, even if it carries a stale force=true snapshot.
            playerA.stop(); playerA.clearMediaItems()
            lastTrackAUrl = a?.url
            measuredRmsA = null
            measuredBpmA = null
            updateBpmLabel(true, null)
            tempoValidatedA = !requiresMeasuredTempoFilter()
            mixInMsA = 0L
            mixOutMsA = 0L
            endlessDeckHasPlayedA = false
            userVolA = 1f
            binding.volumeA.progress = 100
            binding.titleA.text = a?.title ?: "EMPTY"
            binding.playA.text = "PLAY"
            binding.playA.isEnabled = a != null
            setPlayColor(binding.playA, false)
            if (a == null) {
                binding.waveA.setEmpty()
                binding.timeA.text = ""
            } else {
                binding.waveA.setTrackPresent(true)
                val cached = MixerStore.waveA
                if (cached != null) binding.waveA.setWaveform(cached, 1f)
                flight("TRACK_REFRESH deck=A title=${a.title.take(100)} stream=${a.streamUrl != null}")
                resolvePrepareAnalyze(true, a)
                prefetchArtistArtwork(a)
            }
        }

        if (onlyIsA != true && !playerB.isPlaying && (force || b?.url != lastTrackBUrl)) {
            // ABSOLUTE PLAYBACK FIREWALL: no refresh caller is ever allowed to stop/clear
            // the currently audible transport, even if it carries a stale force=true snapshot.
            playerB.stop(); playerB.clearMediaItems()
            lastTrackBUrl = b?.url
            measuredRmsB = null
            measuredBpmB = null
            updateBpmLabel(false, null)
            tempoValidatedB = !requiresMeasuredTempoFilter()
            mixInMsB = 0L
            mixOutMsB = 0L
            endlessDeckHasPlayedB = false
            userVolB = 1f
            binding.volumeB.progress = 100
            binding.titleB.text = b?.title ?: "EMPTY"
            binding.playB.text = "PLAY"
            binding.playB.isEnabled = b != null
            setPlayColor(binding.playB, false)
            if (b == null) {
                binding.waveB.setEmpty()
                binding.timeB.text = ""
            } else {
                binding.waveB.setTrackPresent(true)
                val cached = MixerStore.waveB
                if (cached != null) binding.waveB.setWaveform(cached, 1f)
                flight("TRACK_REFRESH deck=B title=${b.title.take(100)} stream=${b.streamUrl != null}")
                resolvePrepareAnalyze(false, b)
                prefetchArtistArtwork(b)
            }
        }
    }

    private fun resolvePrepareAnalyze(isA: Boolean, track: TrackRef) {
        val deck = if (isA) "A" else "B"
        val key = track.url
        val player = if (isA) playerA else playerB
        val button = if (isA) binding.playA else binding.playB
        flight("TRACK_RESOLVE_ENTER deck=$deck title=${track.title.take(100)} stream=${track.streamUrl != null} mediaItems=${player.mediaItemCount} endless=$endlessActive motor=$autoDiscoveryMotor")

        if (player.mediaItemCount > 0) {
            flight("TRACK_RESOLVE_SKIP deck=$deck reason=media_already_attached")
            if (!endlessActive && (if (isA) MixerStore.waveA else MixerStore.waveB) == null) analyzeWaveform(isA, track)
            return
        }

        val existing = track.streamUrl
        if (existing != null) {
            flight("TRACK_STREAM_READY deck=$deck source=existing")
            prepareDeck(isA, track)
            // Endless preloads prioritize ExoPlayer buffering; their analysis is scheduled a few
            // seconds later by loadEndlessTrackIntoDeck so it cannot steal bandwidth from READY.
            if (!endlessActive && (if (isA) MixerStore.waveA else MixerStore.waveB) == null) analyzeWaveform(isA, track)
            return
        }

        if ((if (isA) resolvingA else resolvingB) == key) {
            flight("TRACK_RESOLVE_SKIP deck=$deck reason=already_resolving")
            return
        }
        if (isA) resolvingA = key else resolvingB = key
        flight("TRACK_RESOLVE_START deck=$deck url=${key.take(140)}")
        button.text = "LOADING"
        button.isEnabled = false
        setPlayColor(button, false)

        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) { AudioResolver.resolveBestAudioUrl(track.url) }
            }
            if (isA) resolvingA = null else resolvingB = null

            result.onSuccess { direct ->
                val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                if (!sameTrack) return@onSuccess
                val updated = track.copy(streamUrl = direct)
                if (isA) MixerStore.deckA = updated else MixerStore.deckB = updated
                flight("TRACK_RESOLVE_OK deck=$deck direct=${direct.take(90)}")
                prepareDeck(isA, updated)
                analyzeWaveform(isA, updated)
            }.onFailure {
                flight("TRACK_RESOLVE_ERROR deck=$deck ${it.javaClass.simpleName}: ${it.message}")
                val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                if (sameTrack) {
                    button.isEnabled = true
                    button.text = "PLAY"
                    setPlayColor(button, false)
                    Toast.makeText(this@MixerActivity, "Stream error: ${it.message ?: "unknown"}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private suspend fun awaitAudioHeadroom(maxWaitMs: Long = 1_500L) {
        // Protect genuinely endangered ACTIVE buffering, but do not hold analysis/search
        // for several seconds: the NEXT deck must keep being prepared promptly.
        val started = SystemClock.elapsedRealtime()
        while (SystemClock.elapsedRealtime() - started < maxWaitMs) {
            val aCritical = playerA.isPlaying && (playerA.bufferedPosition - playerA.currentPosition) < 6_000L
            val bCritical = playerB.isPlaying && (playerB.bufferedPosition - playerB.currentPosition) < 6_000L
            if (!aCritical && !bCritical) return
            delay(150L)
        }
    }

    private suspend fun <T> runLowPriorityAnalysis(block: () -> T): T {
        awaitAudioHeadroom()
        return analysisSlots.withPermit {
            withContext(Dispatchers.IO) {
                val tid = Process.myTid()
                val oldPriority = runCatching { Process.getThreadPriority(tid) }.getOrDefault(Process.THREAD_PRIORITY_DEFAULT)
                try {
                    runCatching { Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND) }
                    block()
                } finally {
                    runCatching { Process.setThreadPriority(oldPriority) }
                }
            }
        }
    }

    private fun analyzeWaveform(isA: Boolean, track: TrackRef) {
        val direct = track.streamUrl ?: return
        val key = track.url
        if (isA) {
            if (MixerStore.waveA != null || analyzingA == key) return
            analyzingA = key
        } else {
            if (MixerStore.waveB != null || analyzingB == key) return
            analyzingB = key
        }

        val waveformJob = lifecycleScope.launch {
            val analysis = runCatching {
                runLowPriorityAnalysis {
                    WaveformAnalyzer.analyze(direct) { partial, fraction ->
                        runOnUiThread {
                            val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                            if (sameTrack) {
                                if (isA) binding.waveA.setWaveform(partial, fraction)
                                else binding.waveB.setWaveform(partial, fraction)
                            }
                        }
                    }
                }
            }.getOrNull()

            if (isA) {
                analyzingA = null
                if (MixerStore.deckA?.url == key && analysis != null) {
                    MixerStore.waveA = analysis.waveform
                    measuredRmsA = analysis.rms
                    mixInMsA = maxOf(mixInMsA, detectMixInPointMs(analysis.waveform, track.durationSeconds * 1000L))
                    mixOutMsA = detectMixOutPointMs(analysis.waveform, track.durationSeconds * 1000L)
                    binding.waveA.setWaveform(analysis.waveform, 1f)
                    applyAutoLoudness(true, analysis.rms)
                }
            } else {
                analyzingB = null
                if (MixerStore.deckB?.url == key && analysis != null) {
                    MixerStore.waveB = analysis.waveform
                    measuredRmsB = analysis.rms
                    mixInMsB = maxOf(mixInMsB, detectMixInPointMs(analysis.waveform, track.durationSeconds * 1000L))
                    mixOutMsB = detectMixOutPointMs(analysis.waveform, track.durationSeconds * 1000L)
                    binding.waveB.setWaveform(analysis.waveform, 1f)
                    applyAutoLoudness(false, analysis.rms)
                }
            }
        }
        if (isA) {
            waveformAnalysisJobA?.cancel()
            waveformAnalysisJobA = waveformJob
        } else {
            waveformAnalysisJobB?.cancel()
            waveformAnalysisJobB = waveformJob
        }
    }

    private fun updateDeckUi(player: ExoPlayer, isA: Boolean) {
        val duration = player.duration
        val position = player.currentPosition.coerceAtLeast(0L)
        val p = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f
        val remaining = if (duration > 0) (duration - position).coerceAtLeast(0L) else -1L

        if (isA) {
            binding.waveA.setProgress(p)
            binding.timeA.text = if (endlessDeckStateA == EndlessDeckState.FREE) "" else if (remaining >= 0) "-${formatTime(remaining)}" else ""
        } else {
            binding.waveB.setProgress(p)
            binding.timeB.text = if (endlessDeckStateB == EndlessDeckState.FREE) "" else if (remaining >= 0) "-${formatTime(remaining)}" else ""
        }
    }

    private fun seekDeck(player: ExoPlayer, fraction: Float) {
        if (player.mediaItemCount == 0) return
        val duration = player.duration
        if (duration > 0) player.seekTo((duration * fraction.coerceIn(0f, 1f)).toLong())
    }

    private fun checkAutoMix() {
        if (!autoEnabled || autoFadeJob?.isActive == true) return

        if (!crossfadeEnabled) {
            if (playerA.playbackState == Player.STATE_ENDED && deckReadyForAuto(playerB)) {
                startSequentialNext(fromA = true)
            } else if (playerB.playbackState == Player.STATE_ENDED && deckReadyForAuto(playerA)) {
                startSequentialNext(fromA = false)
            }
            return
        }

        val aDuration = playerA.duration
        val bDuration = playerB.duration
        // 🍾 AIDJ gets a deliberately wider runway: begin exactly 21 s before the outgoing
        // track ends, with a 12 s blend. Other modes keep their old trigger/mix-out behavior unchanged.
        val champagne = effectiveQemDanceMode() == QemDanceMode.DANCE_PARTY
        val triggerWindowMs = if (champagne) champagneTriggerMs else autoTriggerMs
        val aDefaultTrigger = if (aDuration > 0L) (aDuration - triggerWindowMs).coerceAtLeast(0L) else Long.MAX_VALUE
        val bDefaultTrigger = if (bDuration > 0L) (bDuration - triggerWindowMs).coerceAtLeast(0L) else Long.MAX_VALUE
        val aTriggerAt = if (champagne) aDefaultTrigger else if (mixOutMsA > 0L) minOf(aDefaultTrigger, mixOutMsA) else aDefaultTrigger
        val bTriggerAt = if (champagne) bDefaultTrigger else if (mixOutMsB > 0L) minOf(bDefaultTrigger, mixOutMsB) else bDefaultTrigger

        // FINAL 30 s SANCTUARY: continuity outranks every late selector/gate. A track that has
        // already reached the physical NEXT deck and is ExoPlayer READY must be allowed to play,
        // even if a late artist/repeat/ranking validation would otherwise demote it. Selection
        // rules belong BEFORE this window; silence is never an acceptable late rejection.
        val aFinal = playerA.isPlaying && remainingMs(playerA) <= endlessFinalSanctuaryMs
        val bFinal = playerB.isPlaying && remainingMs(playerB) <= endlessFinalSanctuaryMs
        val bSanctuaryReady = aFinal && deckPlayableInFinalSanctuary(playerB)
        val aSanctuaryReady = bFinal && deckPlayableInFinalSanctuary(playerA)

        if (playerA.isPlaying && playerA.currentPosition >= aTriggerAt &&
            (deckReadyForAuto(playerB) || bSanctuaryReady)) {
            if (champagne) aidjFlight("CHAMPAGNE_TRIGGER from=A remainingMs=${remainingMs(playerA)} triggerMs=$champagneTriggerMs fadeMs=$champagneFadeMs")
            startAutoFade(fromA = true, finalSanctuary = bSanctuaryReady)
        } else if (playerB.isPlaying && playerB.currentPosition >= bTriggerAt &&
            (deckReadyForAuto(playerA) || aSanctuaryReady)) {
            if (champagne) aidjFlight("CHAMPAGNE_TRIGGER from=B remainingMs=${remainingMs(playerB)} triggerMs=$champagneTriggerMs fadeMs=$champagneFadeMs")
            startAutoFade(fromA = false, finalSanctuary = aSanctuaryReady)
        }
    }

    private fun freePausedEndlessDeck(isA: Boolean, force: Boolean = false, requestNextImmediately: Boolean = true) {
        if (!endlessActive) return
        if ((isA && endlessSeedProtectedA) || (!isA && endlessSeedProtectedB)) return
        // A user-inserted ADD TO MIX track is sacred until it has actually played.
        // Never reclaim/refresh its deck merely because it is paused while waiting.
        if ((isA && endlessManualProtectedA) || (!isA && endlessManualProtectedB)) return
        val hasPlayed = if (isA) endlessDeckHasPlayedA else endlessDeckHasPlayedB
        if (!force && !hasPlayed) return
        if (isA) {
            endlessDeckHasPlayedA = false
            endlessDeckStateA = EndlessDeckState.FREE
            if (force) {
                endlessLoadJobA?.cancel(); endlessLoadJobA = null
                waveformAnalysisJobA?.cancel(); waveformAnalysisJobA = null
                analyzingA = null
            }
        } else {
            endlessDeckHasPlayedB = false
            endlessDeckStateB = EndlessDeckState.FREE
            if (force) {
                endlessLoadJobB?.cancel(); endlessLoadJobB = null
                waveformAnalysisJobB?.cancel(); waveformAnalysisJobB = null
                analyzingB = null
            }
        }

        // FREE means the previous track no longer owns the visible deck. Do not leave its
        // title/waveform sitting on-screen for a minute while backstage QEM prepares NEXT.
        // This is UI-only: the transport/store are left untouched until the atomic NEXT swap.
        if (isA) {
            binding.titleA.text = "PREPARING NEXT…"
            binding.waveA.setEmpty()
            binding.timeA.text = ""
        } else {
            binding.titleB.text = "PREPARING NEXT…"
            binding.waveB.setEmpty()
            binding.timeB.text = ""
        }

        // Mark the physical deck as the destination before touching discovery. If a discovery
        // job is already running, it will see this waiting slot when it completes and load the
        // candidate directly here instead of leaving it merely queued.
        activeWaitingFreeDeck = isA
        // Physical A/B do not run discovery policy. They only announce that a slot is free:
        // NEXT PLEASE. The preparation layer chooses/resolves the candidate and hands back one
        // ready TrackRef. This keeps search/ranking/network work out of the playback chassis.
        if (requestNextImmediately) {
            requestNextPlease(isA)
            if (::qemFreeDeckWatchdog.isInitialized) qemFreeDeckWatchdog.start(isA)
        }
    }

    /**
     * TRANSITION SEDATIVE ("Bensedin").
     *
     * The fade-complete callback is playback-critical: it may only publish FREE and return.
     * Discovery / resolve / C-D refill is deliberately deferred to a separate coroutine so no
     * network, queue or load work can execute on the crossfader's 100% completion frame.
     */
    private fun requestNextPleaseAfterTransition(isA: Boolean) {
        lifecycleScope.launch {
            delay(900L)
            flight("SEDATIVE_WAKE target=${if (isA) "A" else "B"} endless=$endlessActive auto=$autoEnabled Aplay=${playerA.isPlaying} Bplay=${playerB.isPlaying}")
            if (!endlessActive || !autoEnabled) return@launch
            val state = if (isA) endlessDeckStateA else endlessDeckStateB
            val player = if (isA) playerA else playerB
            if (state != EndlessDeckState.FREE || player.isPlaying) return@launch
            flight("SEDATIVE_NEXT_PLEASE target=${if (isA) "A" else "B"}")
            requestNextPlease(isA)

            // FREE-DECK REFILL WATCHDOG is deliberately outside MixerActivity now. It keeps the
            // exact same NEXT PLEASE contract, but owns its timing/cancellation independently.
            qemFreeDeckWatchdog.start(isA)
        }
    }


    /**
     * PLAYBACK / PREPARATION FIREWALL.
     *
     * A/B are deliberately dumb transports. A freed physical deck only says NEXT PLEASE here.
     * QEM's C/D preparation layer owns selection and just-in-time stream resolution; the physical
     * deck receives only the resulting TrackRef. BASIC keeps its existing motor-local queue path.
     */
    private fun requestNextPlease(isA: Boolean) {
        if (!endlessActive || !autoEnabled) return
        activeWaitingFreeDeck = isA

        if (autoDiscoveryMotor == AutoDiscoveryMotor.QEM && quickSessionActive) {
            qemEngine.waitingFreeDeck = isA
            // Slot-2 candidate was already selected while both physical decks were occupied.
            // Consume it before touching the network; otherwise fall through to C/D.
            val parked = qemEngine.queued?.takeIf {
                isCurrentQemCandidate(it) &&
                    !persistentHardRepeatBlocked(it, bypassArtistBan = oneArtistMixActive)
            }
            if (parked != null) {
                qemEngine.queued = null
                prepareQemHandoffForDeck(isA, parked)
                return
            } else if (qemEngine.queued != null) {
                qemEngine.queued = null
            }

            val cached = takeVirtualQemForDeck(isA)
            if (cached != null) {
                prepareQemHandoffForDeck(isA, cached)
            } else {
                // No prepared candidate: the QEM preparation motor may search, but A/B stay dumb.
                // If an old search is only "active" on paper, restart that backstage attempt.
                if (!ensureQemDiscoveryLiveness("next_please_${if (isA) "A" else "B"}")) {
                    discoverQemCandidate()
                }
            }
            return
        }

        val queued = queuedForActiveMotor()
        if (queued != null) {
            clearQueuedForActiveMotor()
            activeWaitingFreeDeck = null
            loadEndlessTrackIntoDeck(isA, queued)
        } else {
            discoverQueuedCandidate()
        }
    }

    /**
     * Resolve a QEM crate candidate outside the playback layer, then hand a stream-ready TrackRef
     * to A/B. Failure simply asks the preparation motor for another candidate; the ACTIVE player
     * is never stopped, cleared, sought or inspected by this job.
     */
    private fun prepareQemHandoffForDeck(isA: Boolean, track: TrackRef) {
        if (!endlessActive || autoDiscoveryMotor != AutoDiscoveryMotor.QEM || !quickSessionActive) return
        val existing = if (isA) qemEngine.handoffJobA else qemEngine.handoffJobB
        if (existing?.isActive == true) return

        val session = endlessSessionGeneration
        val generation = qemEngine.discoveryGeneration
        val fingerprint = qemEngine.filterFingerprint
        val job = lifecycleScope.launch {
            val prepared = withTimeoutOrNull(8_000L) {
                withContext(Dispatchers.IO) {
                    runCatching {
                        if (track.streamUrl != null) track
                        else track.copy(streamUrl = AudioResolver.resolveBestAudioUrl(track.url))
                    }.getOrNull()
                }
            }

            if (isA) qemEngine.handoffJobA = null else qemEngine.handoffJobB = null
            if (!endlessActive || !autoEnabled || session != endlessSessionGeneration ||
                generation != qemEngine.discoveryGeneration || fingerprint != qemEngine.filterFingerprint ||
                autoDiscoveryMotor != AutoDiscoveryMotor.QEM || !quickSessionActive) return@launch

            // CONTINUITY FIRST: a playable QEM NEXT must not leave the FREE deck empty while
            // Champagne/Fonoteka/F enrichment spends tens of seconds backstage. Give the final
            // BPM gate a short budget. If enrichment is not ready in time, park the playable
            // candidate now and finish evidence asynchronously; missing evidence only disables
            // SYNC, never music. A completed BPM result inside the budget keeps the normal gate.
            val champagneBpmOk = if (prepared?.streamUrl != null) {
                withTimeoutOrNull(4_000L) { champagnePreparedBpmAllowed(prepared) } ?: run {
                    aidjFlight("CHAMPAGNE_ENRICH_DEFER title=${trackDisplayTitle(prepared).take(70)} reason=next_continuity")
                    bpmEvidenceByUrl[prepared.url] = BpmEvidence(0f, "deferred", 0f, false)
                    lifecycleScope.launch(Dispatchers.IO) {
                        runCatching { champagnePreparedBpmAllowed(prepared) }
                    }
                    true
                }
            } else false
            if (prepared?.streamUrl == null || !isCurrentQemCandidate(prepared) || !champagneBpmOk ||
                persistentHardRepeatBlocked(prepared, bypassArtistBan = oneArtistMixActive)) {
                endlessUsedUrls.remove(track.url)
                endlessUsedTrackKeys.remove(endlessTrackKey(track))
                qemEngine.waitingFreeDeck = isA
                delay(120L)
                discoverQemCandidate()
                return@launch
            }

            // Re-read the chassis after resolve. QEM may cross C/D -> A/B only while the target
            // is STILL physically FREE. "Not playing" is not enough: LOADING_NEXT and READY_NEXT
            // already have an owner and are sticky. A late result is parked instead of touching A/B.
            val targetNow = if (isA) playerA else playerB
            val targetStateNow = if (isA) endlessDeckStateA else endlessDeckStateB
            if (targetNow.isPlaying || targetStateNow != EndlessDeckState.FREE) {
                flight("QEM_HANDOFF_PARK deck=${if (isA) "A" else "B"} state=$targetStateNow playing=${targetNow.isPlaying} title=${prepared.title.take(80)}")
                qemEngine.waitingFreeDeck = null
                activeWaitingFreeDeck = null
                qemEngine.queued = prepared
                return@launch
            }
            endlessUsedUrls.add(prepared.url)
            endlessUsedTrackKeys.add(endlessTrackKey(prepared))
            if (effectiveQemDanceMode() == QemDanceMode.DANCE_PARTY) prepareAidjGrid(prepared)
            qemEngine.waitingFreeDeck = null
            activeWaitingFreeDeck = null

            // HOTEL OWNERSHIP HANDSHAKE: the instant a validated candidate crosses C/D -> A/B,
            // claim the physical room before refresh/prepare work starts. This closes the race in
            // which TRACK_PREPARE was already underway while the continuity watchdog still saw
            // FREE and requested another candidate, causing Zedd -> One Kiss style churn.
            if (isA) {
                endlessPendingNextUrlA = prepared.url
                endlessDeckStateA = EndlessDeckState.LOADING_NEXT
            } else {
                endlessPendingNextUrlB = prepared.url
                endlessDeckStateB = EndlessDeckState.LOADING_NEXT
            }
            if (::qemFreeDeckWatchdog.isInitialized) qemFreeDeckWatchdog.stop(isA)
            flight("QEM_HANDOFF_CLAIM deck=${if (isA) "A" else "B"} state=LOADING_NEXT title=${prepared.title.take(80)}")

            // This is the only point where the preparation side touches the physical transport:
            // hand it one already-selected, already-resolved NEXT.
            loadEndlessTrackIntoDeck(isA, prepared)
            lifecycleScope.launch { delay(1_500L); kickQemVirtualCrates() }
        }
        if (isA) qemEngine.handoffJobA = job else qemEngine.handoffJobB = job
    }

    /**
     * QEM waiting-deck replacement gate.
     *
     * IMPORTANT: this function NEVER empties a physical deck. QEM discovery must finish first.
     * Once a concrete resolved/validated candidate exists, the caller may replace the parked
     * automatic NEXT in one step. Manual ADD TO MIX remains sacred.
     */
    private fun prepareQemWaitingDeckForAtomicSwap(isA: Boolean): Boolean {
        if (!endlessActive || autoDiscoveryMotor != AutoDiscoveryMotor.QEM) return false
        val targetPlayer = if (isA) playerA else playerB
        if (targetPlayer.isPlaying) return false
        val waitingTrack = if (isA) MixerStore.deckA else MixerStore.deckB
        val trulyManualProtected = waitingTrack?.url?.let { it in endlessManualUrls } == true
        if (trulyManualProtected) return false

        // Cancel only stale automatic work. Do NOT stop/clear the player and do NOT null MixerStore.
        if (isA) {
            endlessLoadJobA?.cancel(); endlessLoadJobA = null
            endlessSeedProtectedA = false
            endlessPendingNextUrlA = null
            endlessDeckHasPlayedA = false
            endlessManualProtectedA = false
            tempoValidatedA = true
        } else {
            endlessLoadJobB?.cancel(); endlessLoadJobB = null
            endlessSeedProtectedB = false
            endlessPendingNextUrlB = null
            endlessDeckHasPlayedB = false
            endlessManualProtectedB = false
            tempoValidatedB = true
        }
        qemEngine.waitingFreeDeck = null
        return true
    }

    /**
     * Install a QEM candidate only after discovery/resolve/validation has completed off-deck.
     * This is the actual swap moment: the old parked track remains visible/playable until here.
     */
    private fun installPreparedQemTrackIntoWaitingDeck(isA: Boolean, prepared: TrackRef): Boolean {
        if (prepared.streamUrl == null || !isCurrentQemCandidate(prepared)) return false
        if (!prepareQemWaitingDeckForAtomicSwap(isA)) return false

        if (isA) {
            MixerStore.setA(prepared)
            MixerStore.waveA = null
            endlessPendingNextUrlA = null
            endlessDeckStateA = EndlessDeckState.LOADING_NEXT
            lastTrackAUrl = "__QEM_ATOMIC_SWAP_A__"
            resolvingA = null
        } else {
            MixerStore.setB(prepared)
            MixerStore.waveB = null
            endlessPendingNextUrlB = null
            endlessDeckStateB = EndlessDeckState.LOADING_NEXT
            lastTrackBUrl = "__QEM_ATOMIC_SWAP_B__"
            resolvingB = null
        }
        // refreshDecks now performs the single real replacement. There is no search-time EMPTY gap.
        refreshDecks(onlyIsA = isA)
        return true
    }


    /**
     * FIRST COMMANDMENT / SUPREME CONTINUITY LAW.
     * While AUTO is active, exactly one audible deck + one physically EMPTY opposite deck is the
     * highest-priority fault in the app. Nothing else (ranking, prefetch, sticky NEXT bookkeeping,
     * filter retries, old protection flags) may run ahead of repairing it. ACTIVE is sacred.
     *
     * Returns true while the emergency EMPTY condition exists so the normal continuity pass can
     * stop for this tick and avoid fighting the repair. The next 100 ms tick re-checks the physical
     * deck and keeps hammering until it is no longer empty.
     */
    private fun enforceSupremeNoEmptyLaw(): Boolean {
        if (!endlessActive || !autoEnabled) return false

        val activeIsA: Boolean = when {
            playerA.isPlaying && !playerB.isPlaying -> true
            playerB.isPlaying && !playerA.isPlaying -> false
            else -> return false
        }
        val targetIsA = !activeIsA
        val targetPlayer = if (targetIsA) playerA else playerB
        val targetTrack = if (targetIsA) MixerStore.deckA else MixerStore.deckB
        val physicallyEmpty = targetTrack == null || targetPlayer.mediaItemCount == 0
        if (!physicallyEmpty) return false

        // Physical reality wins over every stale logical flag. Never touch the ACTIVE player.
        if (targetIsA) {
            endlessDeckStateA = EndlessDeckState.FREE
            endlessSeedProtectedA = false
            endlessManualProtectedA = false
            endlessPendingNextUrlA = null
            tempoValidatedA = true
        } else {
            endlessDeckStateB = EndlessDeckState.FREE
            endlessSeedProtectedB = false
            endlessManualProtectedB = false
            endlessPendingNextUrlB = null
            tempoValidatedB = true
        }

        // The CURRENT motor owns the empty physical destination directly. Do not use a shared
        // proxy that can be rewritten by the other discovery engine during a handoff.
        when (autoDiscoveryMotor) {
            AutoDiscoveryMotor.QEM -> {
                // CONSTITUTION: EMPTY HAS NO QEM OWNER. A physically empty deck is chassis space,
                // never a QEM reservation. Only a concrete queued track may claim it, and then it
                // must be loaded immediately. Otherwise QEM may search, but it does not own the
                // empty deck while searching.
                basicWaitingFreeDeck = null
                qemEngine.waitingFreeDeck = null

                // If a handoff left the QEM session flag down for a tick but its session universe
                // still exists, repair the flag rather than allowing one-deck AUTO.
                if (!quickSessionActive && qemEngine.sessionArtistPool.isNotEmpty()) quickSessionActive = true

                val queued = qemEngine.queued
                if (queued != null) {
                    qemEngine.queued = null
                    loadEndlessTrackIntoDeck(targetIsA, queued)
                } else {
                    // Search is engine work, not deck ownership. When a result returns,
                    // discoverQemCandidate() re-reads physical A/B reality and loads whichever
                    // opposite deck is still truly EMPTY.
                    discoverQemCandidate()
                }
            }
            AutoDiscoveryMotor.BASIC -> {
                qemEngine.waitingFreeDeck = null
                basicWaitingFreeDeck = targetIsA
                val queued = endlessQueued
                if (queued != null) {
                    endlessQueued = null
                    basicWaitingFreeDeck = null
                    loadEndlessTrackIntoDeck(targetIsA, queued)
                } else {
                    discoverQueuedCandidate()
                }
            }
            AutoDiscoveryMotor.NONE -> {
                // AUTO ON with no discovery owner is itself an invalid state. Adopt the motor that
                // has a real live session; otherwise fall back to Basic rather than accept EMPTY.
                val owner = if (quickSessionActive && qemEngine.sessionArtistPool.isNotEmpty()) {
                    AutoDiscoveryMotor.QEM
                } else {
                    AutoDiscoveryMotor.BASIC
                }
                switchDiscoveryMotor(owner)
                if (owner == AutoDiscoveryMotor.QEM) qemEngine.waitingFreeDeck = targetIsA
                else basicWaitingFreeDeck = targetIsA
                discoverQueuedCandidate()
            }
        }

        endlessLastRefillKickAtMs = android.os.SystemClock.elapsedRealtime()
        return true
    }

    private fun protectEndlessContinuity() {
        if (!endlessActive) return
        enforceAutoOwnerInvariant()

        val now = android.os.SystemClock.elapsedRealtime()
        // POST-TRANSITION QUIET ZONE. The 100 ms watchdog must respect the same sedative as the
        // deferred NEXT PLEASE path; otherwise it can bypass the delay and refill on the very next tick.
        // A/B keep playing; C/D/E/F may work elsewhere, but no physical refill is initiated here.
        if (autoDiscoveryMotor == AutoDiscoveryMotor.QEM && now < qemEngine.searchNotBeforeMs) return

        // FIRST COMMANDMENT: while AUTO is alive, EMPTY opposite ACTIVE is handled before every
        // other continuity/ranking/prefetch rule. Keep this at the very top of the watchdog outside
        // the short post-transition quiet zone.
        if (enforceSupremeNoEmptyLaw()) return

        // RARE ACTIVE-STOP GUARD. We saw a very occasional case where ExoPlayer stopped in the
        // middle of an ACTIVE song while the logical owner stayed PLAYING and the opposite deck
        // was already READY_NEXT. Do not aggressively "fix" every isPlaying=false callback: that
        // would turn ordinary buffering or a deliberate unlocked pause into a surprise transition.
        // Recovery is therefore allowed only under LOCK + AUTO, only for the established ACTIVE
        // owner, only well before the real end, and only after a 3 s grace period. If the opposite
        // deck is READY_NEXT, perform the same safe ownership handoff as the user's instant-next,
        // but hard-switch the crossfader because the source is already silent.
        fun guardUnexpectedActiveStop(isA: Boolean): Boolean {
            val source = if (isA) playerA else playerB
            val target = if (isA) playerB else playerA
            val sourceState = if (isA) endlessDeckStateA else endlessDeckStateB
            val hasPlayed = if (isA) endlessDeckHasPlayedA else endlessDeckHasPlayedB
            val sourceIsEstablishedOwner = endlessActiveOwnerIsA == isA
            val qualifies = autoEnabled && controlsLocked && sourceIsEstablishedOwner && hasPlayed &&
                sourceState == EndlessDeckState.PLAYING && !source.isPlaying &&
                autoFadeJob?.isActive != true && source.mediaItemCount > 0 &&
                source.playbackState != Player.STATE_ENDED && remainingMs(source) > endlessFinalSanctuaryMs

            if (!qualifies) {
                if (isA) unexpectedActiveStopSinceA = 0L else unexpectedActiveStopSinceB = 0L
                return false
            }

            var since = if (isA) unexpectedActiveStopSinceA else unexpectedActiveStopSinceB
            if (since == 0L) {
                since = now
                if (isA) unexpectedActiveStopSinceA = since else unexpectedActiveStopSinceB = since
                flight("ACTIVE_STOP_GUARD_ARM deck=${if (isA) "A" else "B"} remainingMs=${remainingMs(source)} state=${source.playbackState}")
                return true
            }
            if (now - since < unexpectedActiveStopGraceMs) return true

            val targetState = if (isA) endlessDeckStateB else endlessDeckStateA
            val targetReady = targetState == EndlessDeckState.READY_NEXT &&
                target.mediaItemCount > 0 && target.playbackState == Player.STATE_READY && !target.isPlaying
            if (targetReady) {
                flight("ACTIVE_STOP_RECOVERY from=${if (isA) "A" else "B"} to=${if (isA) "B" else "A"} stoppedMs=${now - since} remainingMs=${remainingMs(source)}")
                // The user proved the existing NEXT-arrow transition is the safest recovery path.
                // After the 3 s grace period, reuse that exact crossfade machinery instead of
                // maintaining a second emergency handoff/state path. canInstantNext() itself
                // intentionally requires source.isPlaying, so the watchdog performs the same
                // READY_NEXT safety check above and then invokes the arrow's transition action.
                if (isA) unexpectedActiveStopSinceA = 0L else unexpectedActiveStopSinceB = 0L
                flight("ACTIVE_STOP_NEXT_ARROW from=${if (isA) "A" else "B"} to=${if (isA) "B" else "A"}")
                startAutoTransition(fromA = isA)
                return true
            }

            // No safe NEXT yet: keep the stopped ACTIVE slot intact and only kick preparation.
            // Never overwrite/recycle the source deck just because it hiccupped mid-song.
            if (now - endlessLastRefillKickAtMs >= 2_000L) {
                endlessLastRefillKickAtMs = now
                activeWaitingFreeDeck = !isA
                discoverQueuedCandidate()
            }
            return true
        }

        val guardingA = guardUnexpectedActiveStop(true)
        val guardingB = guardUnexpectedActiveStop(false)

        // Normal reclaim remains unchanged for genuine spent/non-owner decks. The guarded ACTIVE
        // owner above is deliberately excluded so a rare mid-song stop cannot recycle itself.
        if (!guardingA && endlessDeckHasPlayedA && !playerA.isPlaying && endlessDeckStateA == EndlessDeckState.PLAYING &&
            autoFadeJob?.isActive != true) {
            freePausedEndlessDeck(true)
        }
        if (!guardingB && endlessDeckHasPlayedB && !playerB.isPlaying && endlessDeckStateB == EndlessDeckState.PLAYING &&
            autoFadeJob?.isActive != true) {
            freePausedEndlessDeck(false)
        }

        // Pipeline rule: give a newly started song only about three seconds to stabilize,
        // then start finding the song AFTER the already-loaded opposite deck. Keep it queued
        // until a played deck becomes free. This gives search/resolution almost a full song.
        val active = when {
            playerA.isPlaying -> playerA
            playerB.isPlaying -> playerB
            else -> null
        }

        // Every new ACTIVE track must re-arm refill. This applies equally to normal Endless and
        // every QUICK combination. If the pipeline has no queue/load/search 10 s into a song,
        // kick discovery again instead of discovering the failure at the end of the track.
        val activeOwnerIsA = when {
            playerA.isPlaying && !playerB.isPlaying -> true
            playerB.isPlaying && !playerA.isPlaying -> false
            else -> null
        }
        if (activeOwnerIsA != null && activeOwnerIsA != endlessActiveOwnerIsA) {
            endlessActiveOwnerIsA = activeOwnerIsA
            endlessOwnerStartedAtMs = now
            endlessLastRefillKickAtMs = 0L
        }

        // PHYSICAL EMPTY is authoritative. Async/state flags may occasionally survive a cleared
        // MixerStore/player slot; never let READY/PROTECTED/WAITING fiction suppress refill.
        fun normalizePhysicallyEmptyDeck(isA: Boolean) {
            val player = if (isA) playerA else playerB
            val storeTrack = if (isA) MixerStore.deckA else MixerStore.deckB
            val state = if (isA) endlessDeckStateA else endlessDeckStateB
            val physicallyEmpty = storeTrack == null || player.mediaItemCount == 0
            if (!physicallyEmpty) return
            if (state == EndlessDeckState.PLAYING && player.isPlaying) return

            if (isA) {
                endlessDeckStateA = EndlessDeckState.FREE
                endlessSeedProtectedA = false
                endlessManualProtectedA = false
                endlessPendingNextUrlA = null
            } else {
                endlessDeckStateB = EndlessDeckState.FREE
                endlessSeedProtectedB = false
                endlessManualProtectedB = false
                endlessPendingNextUrlB = null
            }
            // BASIC may remember a free destination. QEM may not reserve an EMPTY deck:
            // physical emptiness itself is the destination signal.
            if (autoDiscoveryMotor == AutoDiscoveryMotor.BASIC &&
                (basicWaitingFreeDeck == null || basicWaitingFreeDeck == isA)) {
                basicWaitingFreeDeck = isA
            } else if (autoDiscoveryMotor == AutoDiscoveryMotor.QEM) {
                qemEngine.waitingFreeDeck = null
            }
        }
        normalizePhysicallyEmptyDeck(true)
        normalizePhysicallyEmptyDeck(false)

        // QEM continuity owns its physical NEXT deck explicitly. Do not route this first-refill
        // decision through the shared BASIC/QEM waiting proxy. If exactly one deck is ACTIVE and
        // the opposite deck is physically empty/FREE, QEM must keep that deck armed until a real
        // candidate reaches LOADING_NEXT/READY_NEXT. This mirrors the state that manual ADD TO MIX
        // accidentally created in the successful Madonna test, but without requiring a manual track.
        if (autoDiscoveryMotor == AutoDiscoveryMotor.QEM && quickSessionActive) {
            val qemTargetIsA: Boolean? = when {
                playerA.isPlaying && !playerB.isPlaying &&
                    (MixerStore.deckB == null || playerB.mediaItemCount == 0 || endlessDeckStateB == EndlessDeckState.FREE) -> false
                playerB.isPlaying && !playerA.isPlaying &&
                    (MixerStore.deckA == null || playerA.mediaItemCount == 0 || endlessDeckStateA == EndlessDeckState.FREE) -> true
                else -> null
            }
            if (qemTargetIsA != null) {
                basicWaitingFreeDeck = null
                qemEngine.waitingFreeDeck = null
                val readyQueued = qemEngine.queued
                if (readyQueued != null) {
                    qemEngine.queued = null
                    loadEndlessTrackIntoDeck(qemTargetIsA, readyQueued)
                } else if (qemEngine.discoveryJob?.isActive != true) {
                    endlessLastRefillKickAtMs = now
                    discoverQemCandidate()
                }
            }
        }

        // A waiting FREE deck is NOT refill activity; it is only a destination marker.
        // If no query/load/queue is actually alive, discovery must start even when
        // activeWaitingFreeDeck already points at that deck.
        val aIsFreeTarget = endlessDeckStateA == EndlessDeckState.FREE && !playerA.isPlaying
        val bIsFreeTarget = endlessDeckStateB == EndlessDeckState.FREE && !playerB.isPlaying
        val expectedNextIsA = endlessActiveOwnerIsA?.not()
        val freeTargetIsA: Boolean? = when {
            // If both chassis slots are FREE (typically after an ACTIVE track ended before NEXT
            // was ready), preserve alternation instead of falling through to A merely because it
            // appears first in this when-expression.
            aIsFreeTarget && bIsFreeTarget && expectedNextIsA != null -> expectedNextIsA
            aIsFreeTarget -> true
            bIsFreeTarget -> false
            else -> null
        }
        val hasPhysicalEmptyTarget = freeTargetIsA != null

        // CORE CONTINUITY LAW: a FREE physical deck must never wait for the active song to enter
        // a prefetch window. If a candidate is already buffered in endlessQueued, consume it NOW.
        // Otherwise arm discovery NOW. This removes the deadlock where endlessQueued != null blocked
        // new search while the queued song itself waited until <=60 s before being loaded.
        if (freeTargetIsA != null) {
            // BASIC can reserve FREE. QEM cannot reserve EMPTY/FREE; its result must re-check
            // the physical deck when it arrives. This prevents stale QEM ownership from making
            // an empty deck untouchable.
            if (autoDiscoveryMotor == AutoDiscoveryMotor.BASIC) basicWaitingFreeDeck = freeTargetIsA
            else if (autoDiscoveryMotor == AutoDiscoveryMotor.QEM) qemEngine.waitingFreeDeck = null
            val queuedNow = queuedForActiveMotor()
            if (queuedNow != null) {
                clearQueuedForActiveMotor()
                if (autoDiscoveryMotor == AutoDiscoveryMotor.BASIC) basicWaitingFreeDeck = null
                loadEndlessTrackIntoDeck(freeTargetIsA, queuedNow)
            } else if (!discoveryActiveForMotor()) {
                endlessLastRefillKickAtMs = now
                discoverQueuedCandidate()
            }
        } else if (active != null && active.currentPosition >= endlessEarlySearchAtMs &&
            queuedForActiveMotor() == null && !discoveryActiveForMotor()) {
            // ACTIVE + prepared NEXT is healthy. READY_NEXT is STICKY: stop discovery here.
            // Search resumes only when the transition creates a real FREE deck, or when the
            // existing NEXT is explicitly invalidated/unplayable by recovery logic.
        }

        // Healthy means real work/data exists. Never count activeWaitingFreeDeck by itself: doing
        // so can leave AUTO ON with an EMPTY deck for an entire song while no search is running.
        val refillHealthy = queuedForActiveMotor() != null ||
            discoveryActiveForMotor() ||
            (activeOwnerIsA == true && (endlessDeckStateB == EndlessDeckState.LOADING_NEXT || endlessDeckStateB == EndlessDeckState.READY_NEXT)) ||
            (activeOwnerIsA == false && (endlessDeckStateA == EndlessDeckState.LOADING_NEXT || endlessDeckStateA == EndlessDeckState.READY_NEXT))
        if (activeOwnerIsA != null && now - endlessOwnerStartedAtMs >= 10_000L && !refillHealthy &&
            now - endlessLastRefillKickAtMs >= 2_000L) {
            endlessLastRefillKickAtMs = now
            discoverQueuedCandidate()
        }

        fun ensureNextDeck(source: ExoPlayer, sourceIsA: Boolean, target: ExoPlayer) {
            if (!source.isPlaying) return
            val remaining = remainingMs(source)
            val targetIsA = !sourceIsA
            if ((targetIsA && endlessSeedProtectedA) || (!targetIsA && endlessSeedProtectedB)) return

            // Start preparing the next deck a full minute before the transition. If a candidate
            // is already queued, load it immediately into the non-playing deck instead of waiting
            // for the current song to end.
            if (remaining <= endlessPrefetchMs && !deckReadyForAuto(target)) {
                if (activeWaitingFreeDeck == null) activeWaitingFreeDeck = targetIsA
                val queued = queuedForActiveMotor()
                if (queued != null && activeWaitingFreeDeck == targetIsA) {
                    clearQueuedForActiveMotor()
                    activeWaitingFreeDeck = null
                    loadEndlessTrackIntoDeck(targetIsA, queued)
                } else {
                    discoverQueuedCandidate()
                }
            }

            // By 15 seconds the target must be READY. Keep hammering discovery/resolution.
            if (remaining <= endlessReadyDeadlineMs && !deckReadyForAuto(target)) {
                activeWaitingFreeDeck = targetIsA
                discoverQueuedCandidate()
            }

        }

        ensureNextDeck(playerA, true, playerB)
        ensureNextDeck(playerB, false, playerA)

        if (!playerA.isPlaying && !playerB.isPlaying && autoFadeJob?.isActive != true) {
            // FINAL DEAD-AIR KILLER: after long runtimes an event can occasionally be missed even
            // though one deck is already READY_NEXT and the opposite deck has reached the end.
            // In that exact state, do not wait for search/recovery bookkeeping: start READY_NEXT now.
            val aReadyNext = endlessDeckStateA == EndlessDeckState.READY_NEXT &&
                playerA.mediaItemCount > 0 && playerA.playbackState == Player.STATE_READY
            val bReadyNext = endlessDeckStateB == EndlessDeckState.READY_NEXT &&
                playerB.mediaItemCount > 0 && playerB.playbackState == Player.STATE_READY
            val aEnded = playerA.mediaItemCount == 0 || playerA.playbackState == Player.STATE_ENDED || remainingMs(playerA) <= 1_000L
            val bEnded = playerB.mediaItemCount == 0 || playerB.playbackState == Player.STATE_ENDED || remainingMs(playerB) <= 1_000L
            if (aReadyNext && bEnded) {
                cross = 0f
                binding.crossfader.progress = 0
                applyVolumes()
                applyEndlessMixInPoint(playerA, targetIsA = true)
                endlessDeckStateA = EndlessDeckState.PLAYING
                playerA.play()
                MixerStore.deckA?.let { markEndlessAutoPlayed(it) }
                endlessRecoveryDeck = null
                activeWaitingFreeDeck = false
                discoverQueuedCandidate()
                return
            }
            if (bReadyNext && aEnded) {
                cross = 1f
                binding.crossfader.progress = 100
                applyVolumes()
                applyEndlessMixInPoint(playerB, targetIsA = false)
                endlessDeckStateB = EndlessDeckState.PLAYING
                playerB.play()
                MixerStore.deckB?.let { markEndlessAutoPlayed(it) }
                endlessRecoveryDeck = null
                activeWaitingFreeDeck = true
                discoverQueuedCandidate()
                return
            }

            if (now - lastRecoveryAttemptAt < 750L) return
            lastRecoveryAttemptAt = now
            val aPlayable = deckReadyForAuto(playerA) && remainingMs(playerA) > 2_000L
            val bPlayable = deckReadyForAuto(playerB) && remainingMs(playerB) > 2_000L
            fun startRecoveryDeck(targetIsA: Boolean) {
                val target = if (targetIsA) playerA else playerB
                cross = if (targetIsA) 0f else 1f
                binding.crossfader.progress = if (targetIsA) 0 else 100
                applyVolumes()
                applyEndlessMixInPoint(target, targetIsA = targetIsA)
                if (targetIsA) endlessDeckStateA = EndlessDeckState.PLAYING else endlessDeckStateB = EndlessDeckState.PLAYING
                target.play()
                (if (targetIsA) MixerStore.deckA else MixerStore.deckB)?.let { markEndlessAutoPlayed(it) }
                endlessRecoveryDeck = null
                activeWaitingFreeDeck = !targetIsA
                flight("DEAD_AIR_RECOVERY_START deck=${if (targetIsA) "A" else "B"} expected=${expectedNextIsA?.let { if (it) "A" else "B" } ?: "NONE"}")
                discoverQueuedCandidate()
            }

            when {
                // When both are technically playable, the last ACTIVE owner decides the successor.
                // This closes the second A-first loophole that could otherwise recreate A→A.
                aPlayable && bPlayable && expectedNextIsA == false -> startRecoveryDeck(false)
                aPlayable && bPlayable && expectedNextIsA == true -> startRecoveryDeck(true)
                aPlayable -> startRecoveryDeck(true)
                bPlayable -> startRecoveryDeck(false)
                else -> {
                    // If both are stopped and neither is ready yet, arm discovery for the expected
                    // opposite deck. Only fall back to the old physical heuristic when there has
                    // never been an established ACTIVE owner (startup/manual edge).
                    val recoverA = expectedNextIsA ?: (
                        playerA.playbackState == Player.STATE_ENDED || playerA.mediaItemCount == 0 ||
                            (playerB.playbackState != Player.STATE_ENDED && remainingMs(playerA) <= remainingMs(playerB))
                        )
                    endlessRecoveryDeck = recoverA
                    activeWaitingFreeDeck = recoverA
                    // Never erase a parked/prepared NEXT at the exact moment continuity needs it.
                    // NEXT PLEASE consumes qemEngine.queued / C-D first and falls back to discovery only
                    // when there is genuinely nothing prepared.
                    val recoveryNow = SystemClock.elapsedRealtime()
                    val restarted = ensureQemDiscoveryLiveness("dead_air")
                    if (restarted || recoveryNow - lastDeadAirRecoveryLogAt >= 5_000L) {
                        lastDeadAirRecoveryLogAt = recoveryNow
                        flight("DEAD_AIR_RECOVERY_ARM deck=${if (recoverA) "A" else "B"} expected=${expectedNextIsA?.let { if (it) "A" else "B" } ?: "NONE"} queued=${queuedForActiveMotor() != null} discovery=${qemEngine.discoveryJob?.isActive == true} restarted=$restarted")
                    }
                    if (!restarted) requestNextPlease(recoverA)
                }
            }
        }
    }

    private fun deckReadyForAuto(player: ExoPlayer): Boolean {
        if (player.mediaItemCount == 0 || player.playbackState != Player.STATE_READY) return false
        if (endlessActive) {
            val state = if (player === playerA) endlessDeckStateA else endlessDeckStateB
            // ExoPlayer may remain STATE_READY on the old paused track (often around -0:04).
            // FREE is authoritative: a spent deck can never masquerade as the next ready deck.
            if (state != EndlessDeckState.READY_NEXT && state != EndlessDeckState.PLAYING) return false
        }
        val d = player.duration
        return d <= 0 || player.currentPosition < d - 1_000L
    }

    private fun remainingMs(player: ExoPlayer): Long {
        val d = player.duration
        return if (d > 0) (d - player.currentPosition).coerceAtLeast(0L) else Long.MAX_VALUE
    }

    private fun deckPlayableInFinalSanctuary(player: ExoPlayer): Boolean {
        if (player.mediaItemCount == 0 || player.playbackState != Player.STATE_READY) return false
        val state = if (player === playerA) endlessDeckStateA else endlessDeckStateB
        // Never resurrect a spent FREE deck. Sanctuary applies only to a candidate already parked
        // as NEXT (including one whose late validation never promoted LOADING_NEXT to READY_NEXT).
        if (state != EndlessDeckState.LOADING_NEXT && state != EndlessDeckState.READY_NEXT) return false
        val d = player.duration
        return d <= 0L || player.currentPosition < d - 1_000L
    }

    private fun startAutoTransition(fromA: Boolean) {
        if (crossfadeEnabled) startAutoFade(fromA) else startSequentialNext(fromA)
    }

    private fun startSequentialNext(fromA: Boolean) {
        val source = if (fromA) playerA else playerB
        val target = if (fromA) playerB else playerA
        if (!deckReadyForAuto(target)) return

        if (quickStartupGuardA && fromA) quickStartupGuardA = false

        target.seekTo(0L)
        if (endlessActive) {
            if (fromA) endlessDeckStateB = EndlessDeckState.PLAYING else endlessDeckStateA = EndlessDeckState.PLAYING
        }

        source.pause()
        cross = if (fromA) 1f else 0f
        binding.crossfader.progress = if (fromA) 100 else 0
        applyVolumes()
        target.play()

        if (endlessActive) onEndlessTransitionComplete(freedIsA = fromA)
        updateInstantNextButtons()
    }

    private fun startAutoFade(fromA: Boolean, finalSanctuary: Boolean = false) {
        flight("FADE_START from=${if (fromA) "A" else "B"} Aplay=${playerA.isPlaying} Bplay=${playerB.isPlaying} cross=$cross")
        val source = if (fromA) playerA else playerB
        val target = if (fromA) playerB else playerA
        if (!deckReadyForAuto(target) && !(finalSanctuary && deckPlayableInFinalSanctuary(target))) return

        // Transition timing may differ by mode, but the physical blend duration is global.
        val champagne = effectiveQemDanceMode() == QemDanceMode.DANCE_PARTY
        val transitionPlan = transitionEngine.plan(fromA, champagne, cross)
        val fadeMs = transitionPlan.durationMs
        val sourceTrack = if (fromA) MixerStore.deckA else MixerStore.deckB
        val targetTrack = if (fromA) MixerStore.deckB else MixerStore.deckA
        val fadeWallStartMs = android.os.SystemClock.elapsedRealtime()
        if (champagne) aidjFlight("CHAMPAGNE_FADE_START from=${if (fromA) "A" else "B"} remainingMs=${remainingMs(source)} durationMs=$fadeMs")

        // Deck Z is an observer of a real A/B mix, never a prerequisite for it.
        maybeSpeakAutomaticDeckZ(targetTrack)

        if (quickStartupGuardA && fromA) quickStartupGuardA = false
        if (endlessActive) {
            if (fromA) endlessDeckStateB = EndlessDeckState.PLAYING else endlessDeckStateA = EndlessDeckState.PLAYING
        }

        autoFadeJob = lifecycleScope.launch {
            var syncApplied = false
            var targetSpeed = 1f

            if (champagne && sourceTrack != null && targetTrack != null) {
                val sourceEvidence = bpmEvidenceByUrl[sourceTrack.url]
                val targetEvidence = bpmEvidenceByUrl[targetTrack.url]
                val sourceGrid = aidjGridByUrl[sourceTrack.url]
                val targetGrid = aidjGridByUrl[targetTrack.url]

                when (val decision = aidjSyncEngine.plan(
                    sourceBpm = sourceEvidence?.bpm,
                    targetBpm = targetEvidence?.bpm,
                    sourceSyncSafe = sourceEvidence?.syncSafe ?: false,
                    targetSyncSafe = targetEvidence?.syncSafe ?: false,
                    sourceGrid = sourceGrid,
                    targetGrid = targetGrid,
                    sourcePositionMs = source.currentPosition
                )) {
                    is AidjSyncEngine.Decision.Ready -> {
                        targetSpeed = decision.targetSpeed
                        target.playbackParameters = PlaybackParameters(targetSpeed)
                        target.seekTo(decision.targetCueMs)
                        aidjFlight("SYNC_READY from=${if (fromA) "A" else "B"} sourceBpm=${sourceEvidence!!.bpm} targetBpm=${targetEvidence!!.bpm} speed=$targetSpeed waitMs=${decision.preRollWaitMs} cueLeadMs=${decision.cueLeadMs} targetCue=${decision.targetCueMs} firstBeat=${decision.targetFirstBeatMs}")

                        // ACTIVE remains at full volume during the tiny pre-roll wait: no dead air.
                        if (decision.preRollWaitMs > 0L) delay(decision.preRollWaitMs)
                        target.play()
                        syncApplied = true
                        aidjFlight("SYNC_START from=${if (fromA) "A" else "B"} speed=$targetSpeed sourcePos=${source.currentPosition} targetPos=${target.currentPosition}")
                    }
                    is AidjSyncEngine.Decision.Skip -> {
                        if (decision.reason == "speed_delta") {
                            aidjFlight("SYNC_SKIP reason=speed_delta sourceBpm=${sourceEvidence!!.bpm} targetBpm=${targetEvidence!!.bpm} rawSpeed=${decision.rawSpeed}")
                        } else {
                            aidjFlight("SYNC_SKIP reason=${decision.reason} from=${if (fromA) "A" else "B"}")
                        }
                    }
                }
            }

            if (!syncApplied) {
                // Safe old path: no phase delay, no speed correction, no dependency on AIDJ.
                target.playbackParameters = PlaybackParameters(1f)
                applyEndlessMixInPoint(target, targetIsA = !fromA)
                target.play()
            }

            // Exactly `fadeMs` of blend time: equal intervals, no extra trailing delay.
            for (i in 1..transitionPlan.steps) {
                if (!isActive) return@launch
                delay(fadeMs / transitionPlan.steps)
                cross = transitionEngine.crossAt(transitionPlan, i)
                binding.crossfader.progress = (cross * 100f).roundToInt().coerceIn(0, 100)
                applyVolumes()
            }
            flight("FADE_100_PRE_PAUSE from=${if (fromA) "A" else "B"} Aplay=${playerA.isPlaying} Bplay=${playerB.isPlaying}")
            source.pause()
            source.playbackParameters = PlaybackParameters(1f)
            flight("FADE_100_POST_PAUSE from=${if (fromA) "A" else "B"} Aplay=${playerA.isPlaying} Bplay=${playerB.isPlaying}")
            cross = transitionPlan.endCross
            binding.crossfader.progress = (cross * 100f).roundToInt()
            applyVolumes()

            // Pitch/tempo correction exists only through the 🍾 blend. Restore natural speed after
            // the outgoing deck is gone. The correction is capped at ±4%, so this handoff is mild.
            if (syncApplied) {
                target.playbackParameters = PlaybackParameters(1f)
                aidjFlight("SYNC_RELEASE target=${if (fromA) "B" else "A"} previousSpeed=$targetSpeed")
            }

            autoFadeJob = null
            if (champagne) aidjFlight("CHAMPAGNE_FADE_COMPLETE from=${if (fromA) "A" else "B"} actualMs=${android.os.SystemClock.elapsedRealtime() - fadeWallStartMs} expectedMs=$fadeMs")
            flight("FADE_100_UI_DONE from=${if (fromA) "A" else "B"} endless=$endlessActive auto=$autoEnabled fadeMs=$fadeMs")
            if (endlessActive) onEndlessTransitionComplete(freedIsA = fromA)
            flight("FADE_COMPLETE_RETURN from=${if (fromA) "A" else "B"} Aplay=${playerA.isPlaying} Bplay=${playerB.isPlaying}")
        }
    }

    private fun scheduleContinuityCheck(delayMs: Long = 120L) {
        lifecycleScope.launch {
            delay(delayMs.coerceAtLeast(0L))
            if (endlessActive) protectEndlessContinuity()
        }
    }

    private fun cancelAutoFadeForManualControl() {
        // Manual crossfader movement may interrupt only the in-progress fade. It must NEVER end
        // an Endless/QEM session or set AUTO OFF. Discovery/refill remains alive and the currently
        // audible deck stays protected.
        if (autoFadeJob?.isActive == true) {
            autoFadeJob?.cancel()
            autoFadeJob = null
            playerA.playbackParameters = PlaybackParameters(1f)
            playerB.playbackParameters = PlaybackParameters(1f)
            if (effectiveQemDanceMode() == QemDanceMode.DANCE_PARTY) aidjFlight("SYNC_RELEASE reason=manual_control")
        }
        if (endlessActive) {
            autoEnabled = true
            updateAutoButton()
            scheduleContinuityCheck(120L)
        }
    }

    private fun detectMixInPointMs(waveform: FloatArray, durationMs: Long): Long {
        if (durationMs <= 0L || waveform.isEmpty()) return 0L
        val maxSkipMs = minOf(20_000L, durationMs / 8)
        val maxBucket = ((maxSkipMs.toDouble() / durationMs) * waveform.size)
            .toInt().coerceIn(1, waveform.lastIndex.coerceAtLeast(1))
        // If the opening is already clearly audible, keep the true beginning.
        if (waveform.take(minOf(3, waveform.size)).any { it >= 0.20f }) return 0L
        for (i in 0 until maxBucket) {
            val end = minOf(i + 4, waveform.size)
            if (end - i >= 3 && waveform.sliceArray(i until end).count { it >= 0.22f } >= 3) {
                return ((i.toDouble() / waveform.size) * durationMs).toLong().coerceIn(0L, maxSkipMs)
            }
        }
        return 0L
    }

    private fun detectMixOutPointMs(waveform: FloatArray, durationMs: Long): Long {
        if (durationMs <= 0L || waveform.size < 8) return 0L
        // Look only near the tail. If a sustained quiet tail begins before the normal 12 s
        // trigger, transition at the start of that tail rather than fading through silence.
        val scanStart = (waveform.size * 0.72f).toInt().coerceIn(0, waveform.lastIndex)
        var quietRun = 0
        var quietStart = -1
        for (i in scanStart until waveform.size) {
            if (waveform[i] < 0.10f) {
                if (quietRun == 0) quietStart = i
                quietRun++
                if (quietRun >= 4) {
                    val t = ((quietStart.toDouble() / waveform.size) * durationMs).toLong()
                    return t.coerceIn(0L, durationMs)
                }
            } else {
                quietRun = 0
                quietStart = -1
            }
        }
        return 0L
    }

    private fun updateMasterMuteUi() {
        binding.masterMute.setImageResource(if (masterMuted) R.drawable.ic_unmute else R.drawable.ic_mute)
        binding.masterMute.contentDescription = if (masterMuted) "Unmute master" else "Mute master"
        binding.masterMute.backgroundTintList = ColorStateList.valueOf(
            ContextCompat.getColor(this, if (masterMuted) R.color.red_control else R.color.yellow_control)
        )
        if (::binding.isInitialized) {
            binding.lockedMute.setImageResource(if (masterMuted) R.drawable.ic_unmute else R.drawable.ic_mute)
            binding.lockedMute.contentDescription = if (masterMuted) "Unmute master" else "Mute master"
            binding.lockedMute.backgroundTintList = ColorStateList.valueOf(
                ContextCompat.getColor(this, if (masterMuted) R.color.red_control else R.color.yellow_control)
            )
            updateLockedSafetyActionUi()
        }
    }

    private fun updateLockedSafetyActionUi() {
        if (!::binding.isInitialized) return
        val showAction = lockedSafetyStopped || masterMuted
        binding.lockedStop.visibility = if (showAction) View.VISIBLE else View.GONE
        if (lockedSafetyStopped) {
            binding.lockedStop.text = "▶"
            binding.lockedStop.contentDescription = "Resume playback"
            binding.lockedStop.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, R.color.green_control))
            binding.lockedStop.setTextColor(ContextCompat.getColor(this, R.color.black))
        } else {
            binding.lockedStop.text = "Ⅱ"
            binding.lockedStop.contentDescription = "Pause playback"
            binding.lockedStop.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, R.color.yellow_control))
            binding.lockedStop.setTextColor(ContextCompat.getColor(this, R.color.black))
        }
    }

    private fun toggleLockedSafetyStopResume() {
        if (!lockedSafetyStopped) {
            // Second safety step after MUTE: pause transport without destroying either deck.
            // This intentionally preserves the current mix, parking track and QEM/BASIC state.
            lockedSafetyResumeA = playerA.isPlaying
            lockedSafetyResumeB = playerB.isPlaying
            lockedSafetyAutoWasEnabled = autoEnabled
            autoFadeJob?.cancel()
            playerA.pause()
            playerB.pause()
            autoEnabled = false
            lockedSafetyStopped = true
        } else {
            // PLAY restores exactly the transport that was running before the safety pause.
            lockedSafetyStopped = false
            autoEnabled = lockedSafetyAutoWasEnabled && endlessActive
            if (lockedSafetyResumeA && playerA.mediaItemCount > 0) playerA.play()
            if (lockedSafetyResumeB && playerB.mediaItemCount > 0) playerB.play()
            lockedSafetyResumeA = false
            lockedSafetyResumeB = false
            lockedSafetyAutoWasEnabled = false
        }
        applyVolumes()
        updateAutoButton()
        updateLockedSafetyActionUi()
    }

    private fun waveformEnergy(isA: Boolean): Float {
        val player = if (isA) playerA else playerB
        if (player.mediaItemCount == 0 || player.duration <= 0L) return 0f
        val wave = if (isA) MixerStore.waveA else MixerStore.waveB
        val gain = if (isA) (1f - cross) else cross
        if (wave == null || wave.isEmpty()) return if (player.isPlaying) 0.28f * gain else 0f
        val fraction = (player.currentPosition.toFloat() / player.duration).coerceIn(0f, 0.999f)
        val index = (fraction * wave.size).toInt().coerceIn(0, wave.lastIndex)
        val local = wave[index]
        return (local * gain).coerceIn(0f, 1f)
    }

    private fun updateCrossSpectrum() {
        val phase = ((playerA.currentPosition + playerB.currentPosition) % 4000L) / 4000f * 6.283185f
        binding.crossSpectrum.setEnergy(waveformEnergy(true), waveformEnergy(false), phase)
    }

    private fun updateMasterVuMeters() {
        // Lightweight MASTER L/R simulation from the same playback envelope already used by
        // the mixer UI. It never touches the audio path. Slight channel decorrelation keeps
        // the stereo needles natural while both still follow final master gain/mute state.
        val base = (waveformEnergy(true) * userVolA + waveformEnergy(false) * userVolB)
            .coerceIn(0f, 1f) * masterVolume * masterDuck * if (masterMuted) 0f else 1f
        val t = ((playerA.currentPosition + playerB.currentPosition) % 2400L) / 2400f * 6.283185f
        val l = (base * (0.92f + 0.08f * kotlin.math.sin(t))).coerceIn(0f, 1f)
        val r = (base * (0.92f + 0.08f * kotlin.math.sin(t + 1.35f))).coerceIn(0f, 1f)
        binding.masterVuLeft.setLevel(l)
        binding.masterVuRight.setLevel(r)
        // Passive visual back wall only: it follows the already-computed MASTER envelope and
        // never participates in playback, discovery, touch handling or mixer state.
        binding.liveLampWall.setLevel((l + r) * 0.5f)
    }

    private fun applyEndlessMixInPoint(player: ExoPlayer, targetIsA: Boolean) {
        if (!endlessActive || player.currentPosition > 1_000L) return
        val mixIn = if (targetIsA) mixInMsA else mixInMsB
        if (mixIn > 750L) player.seekTo(mixIn)
    }

    private fun applyAutoLoudness(isA: Boolean, rms: Float) {
        if (rms <= 0.001f) return
        // Never boost above the clean 100% deck level; only tame louder tracks.
        val normalized = (loudnessTargetRms / rms).coerceIn(0.55f, 1f)
        val progress = (normalized * 100f).roundToInt().coerceIn(55, 100)
        if (isA) {
            userVolA = progress / 100f
            binding.volumeA.progress = progress
        } else {
            userVolB = progress / 100f
            binding.volumeB.progress = progress
        }
        applyVolumes()
    }

    private fun applyVolumes() {
        // Central output policy: MASTER 100% still leaves 3 dB of clean mix-bus headroom.
        // Keep this reserve global so BASIC/QEM/Champagne cannot diverge or double-apply it.
        val headroom = AudioMixPolicy.OUTPUT_HEADROOM_GAIN
        val aGain = (1f - cross) * headroom
        val bGain = cross * headroom
        val muteGain = if (masterMuted) 0f else 1f
        playerA.volume = (userVolA * aGain * masterVolume * masterDuck * deckZDuck * muteGain).coerceIn(0f, 1f)
        playerB.volume = (userVolB * bGain * masterVolume * masterDuck * deckZDuck * muteGain).coerceIn(0f, 1f)
    }

    private fun updatePlayButton(isA: Boolean) {
        val player = if (isA) playerA else playerB
        val button = if (isA) binding.playA else binding.playB
        button.isEnabled = !controlsLocked && player.mediaItemCount > 0 && player.playbackState != Player.STATE_IDLE
        if (player.isPlaying) {
            button.text = "PAUSE"
            setPlayColor(button, true)
        } else if (player.playbackState == Player.STATE_BUFFERING) {
            button.text = "LOADING"
            setPlayColor(button, false)
        } else {
            button.text = "PLAY"
            setPlayColor(button, false)
        }
    }

    /**
     * BPM catalog input: ARTIST + SONG only. YouTube decoration is stripped before
     * the request because it hurts catalog matching and is irrelevant to BPM.
     */
    private fun bpmCleanArtist(raw: String): String {
        return raw
            .replace(Regex("(?i)\\s*[\\[(]\\s*(official|vevo|topic).*?[\\])]\\s*"), " ")
            .replace(Regex("(?i)\\b(official|vevo|topic)\\b"), " ")
            .replace(Regex("\\s+"), " ")
            .trim(' ', '-', '_', '|')
    }

    private fun bpmCleanTitle(raw: String): String {
        var v = raw
        // Bracketed YouTube/catalog decoration.
        v = v.replace(Regex("(?i)\\s*[\\[(]\\s*(official\\b|from\\b|lyrics?\\b|lyric\\s+video\\b|music\\s+video\\b|audio\\b|visuali[sz]er\\b|live\\b|remaster(?:ed)?\\b|hd\\b|hq\\b|4k\\b).*?$"), "")
        // Unbracketed suffixes: e.g. "KABANES - Official Visualizer".
        v = v.replace(Regex("(?i)\\s*[-–—|]\\s*(?:official\\s+)?(?:music\\s+)?(?:video(?:\\s+clip)?|audio|visuali[sz]er|lyrics?|lyric\\s+video)(?:\\s+.*)?$"), "")
        v = v.replace(Regex("(?i)\\s+(?:ft\\.?|feat\\.?|featuring|with)\\s+.+$"), "")
        v = v.replace(Regex("(?i)\\s*[\\[(]\\s*(?:ft\\.?|feat\\.?|featuring|with)\\b.*?[\\])]\\s*$"), "")
        return v.replace(Regex("\\s+"), " ").trim(' ', '-', '_', '|')
    }


    /**
     * Fonoteka must not ask MusicBrainz for a whole composite credit as if it were one artist.
     * Keep display names for the request, but use the same canonical artist normalizer for keys.
     * Example: "SEVERINA FEAT. MINISTARKE" -> Severina + Ministarke.
     */
    private fun fonotekaArtistParts(raw: String): List<Pair<String, String>> {
        if (raw.isBlank()) return emptyList()
        val split = raw
            .replace(Regex("(?i)\\b(feat(?:uring)?|ft|with|duet|vs)\\.?\\b"), " & ")
            .replace(Regex("(?i)\\s+[x×]\\s+"), " & ")
            .replace(Regex("(?i)\\s+(and|i)\\s+"), " & ")
            .split('&', ',', ';')
            .map { it.trim().trimStart('.', ':', '-', '_', '|').trim() }
            .filter { it.length >= 2 }

        val parts = if (split.size > 1) split else listOf(raw.trim())
        return parts.mapNotNull { display ->
            val key = normalizeArtistText(display).trim()
            if (key.length < 2) null else display to key
        }.distinctBy { it.second }
    }

    private suspend fun ensureFonotekaCredit(rawArtist: String, rawTitle: String) {
        val parts = fonotekaArtistParts(rawArtist)
        if (parts.size > 1) {
            fonotekaFlight("FONOTEKA_CREDIT_SPLIT raw=$rawArtist parts=${parts.joinToString(" + ") { it.first }}")
        }
        val title = bpmCleanTitle(rawTitle)
        val titleKey = normalizeArtistText(title)
        for ((artist, key) in parts) {
            cloudFonotekaRepository.ensureTrack(
                artist = artist,
                artistKey = key,
                title = title,
                titleKey = titleKey,
                diagnostic = { fonotekaFlight(it) }
            )
        }
    }

    /** Live 404 translator: resolve only this track, never crawl the whole artist catalog. */
    private fun artistDisplayName(track: TrackRef): String {
        val universal = CanonicalIdentityResolver.resolve(track).catalogArtist
        if (universal.length >= 2) return bpmCleanArtist(universal)
        return bpmCleanArtist(track.uploader)
    }

    /**
     * One clean display/catalog title only. There is deliberately NO first-word fallback.
     * On a genuine 404, the second BPM attempt happens only after the shared Cloud Fonoteka
     * has translated the dirty YouTube identity into canonical MusicBrainz song names in D1.
     */
    private fun bpmTitleCandidates(track: TrackRef): List<String> {
        val resolved = CanonicalIdentityResolver.resolve(track).catalogTitle
        val primary = bpmCleanTitle(resolved)
        return if (primary.isBlank()) emptyList() else listOf(primary)
    }

    private fun trackDisplayTitle(track: TrackRef): String =
        bpmTitleCandidates(track).firstOrNull().orEmpty()

    private fun updateBpmLabel(isA: Boolean, bpm: Float?, fallback: Boolean = false) {
        val label = if (isA) binding.bpmA else binding.bpmB
        label.text = bpm?.takeIf { it in 30f..300f }?.let {
            if (fallback) "(${it.roundToInt()} BPM)" else "${it.roundToInt()} BPM"
        }.orEmpty()
    }

    /**
     * F balcony fallback. It is allowed to run only after Deezer/server BPM did not
     * produce a value. It never writes Cloud/D1 metadata and never gates playback.
     * Parentheses in the UI deliberately distinguish locally measured fallback BPM.
     */
    private suspend fun applyFBpmFallback(
        isA: Boolean,
        track: TrackRef,
        artistKey: String,
        titleKey: String,
        expectedUrl: String,
        expectedGeneration: Long,
        reason: String
    ) {
        val deck = if (isA) "A" else "B"
        fun generationMatches(): Boolean = if (isA) bpmTrackGenerationA == expectedGeneration else bpmTrackGenerationB == expectedGeneration
        fun trackMatches(): Boolean =
            generationMatches() && (if (isA) MixerStore.deckA?.url == expectedUrl else MixerStore.deckB?.url == expectedUrl)
        if (!trackMatches()) {
            bpmFlight("BPM_F_DROP deck=$deck reason=track_changed phase=before_cache")
            return
        }

        val cached = withContext(Dispatchers.IO) { fallbackBpmStore.get(artistKey, titleKey) }
        if (cached != null) {
            if (!trackMatches()) {
                bpmFlight("BPM_F_DROP deck=$deck reason=track_changed phase=cache_hit")
                return
            }
            if (isA) measuredBpmA = cached.bpm else measuredBpmB = cached.bpm
            bpmEvidenceByUrl[expectedUrl] = BpmEvidence(cached.bpm, "F", cached.confidence, cached.confidence >= champagneFConfidenceFloor)
            if (effectiveQemDanceMode() == QemDanceMode.DANCE_PARTY) prepareAidjGrid(track)
            updateBpmLabel(isA, cached.bpm, fallback = true)
            bpmFlight("BPM_F_CACHE_HIT deck=$deck bpm=${cached.bpm} confidence=${cached.confidence} reason=$reason")
            return
        }

        val direct = track.streamUrl
        if (direct.isNullOrBlank()) {
            bpmFlight("BPM_F_SKIP deck=$deck reason=no_stream serverReason=$reason")
            return
        }

        bpmFlight("BPM_F_ANALYZE_START deck=$deck generation=$expectedGeneration reason=$reason")
        val result = runCatching {
            runLowPriorityAnalysis { TempoAnalyzer.analyze(direct, cacheKey = "F|$expectedUrl", scanMs = 24_000L) }
        }.getOrNull()

        if (!trackMatches()) {
            bpmFlight("BPM_F_DROP deck=$deck reason=track_changed phase=after_analysis generation=$expectedGeneration")
            return
        }
        val bpm = result?.bpm?.takeIf { it in 30f..300f }
        if (bpm == null) {
            bpmFlight("BPM_F_NO_RESULT deck=$deck reason=$reason")
            return
        }

        if (!trackMatches()) {
            bpmFlight("BPM_F_DROP deck=$deck reason=track_changed phase=before_store generation=$expectedGeneration")
            return
        }
        withContext(Dispatchers.IO) { fallbackBpmStore.put(artistKey, titleKey, bpm, result.confidence) }
        if (!trackMatches()) {
            bpmFlight("BPM_F_DROP deck=$deck reason=track_changed phase=before_ui generation=$expectedGeneration")
            return
        }
        if (isA) measuredBpmA = bpm else measuredBpmB = bpm
        bpmEvidenceByUrl[expectedUrl] = BpmEvidence(bpm, "F", result.confidence, result.confidence >= champagneFConfidenceFloor)
        if (effectiveQemDanceMode() == QemDanceMode.DANCE_PARTY) prepareAidjGrid(track)
        updateBpmLabel(isA, bpm, fallback = true)
        bpmFlight("BPM_F_UI deck=$deck bpm=$bpm confidence=${result.confidence} generation=$expectedGeneration reason=$reason")
    }

    private fun prefetchCloudTrackMetadata(isA: Boolean, track: TrackRef) {
        val deck = if (isA) "A" else "B"
        bpmFlight("BPM_PREFETCH_ENTER deck=$deck rawTitle=${track.title.take(100)}")
        // Cloud/D1 enrichment is deliberately outside every playback gate. A slow or unavailable
        // Worker must have zero effect on READY_NEXT, crossfade, discovery, or continuity.
        val artistKey = endlessArtistKey(track)
        val titleKey = endlessTrackKey(track)
        if (artistKey.isBlank() || titleKey.isBlank()) {
            bpmFlight("BPM_PREFETCH_SKIP deck=$deck reason=blank_key artistKey=${artistKey.isNotBlank()} titleKey=${titleKey.isNotBlank()}")
            return
        }
        val expectedUrl = track.url
        val bpmGeneration = if (isA) {
            bpmTrackGenerationA += 1L
            bpmTrackGenerationA
        } else {
            bpmTrackGenerationB += 1L
            bpmTrackGenerationB
        }

        val previous = if (isA) bpmLookupJobA else bpmLookupJobB
        previous?.cancel()
        val job = lifecycleScope.launch {
            val lookupTitle = bpmTitleCandidates(track).firstOrNull().orEmpty()
            if (lookupTitle.isBlank()) {
                bpmFlight("BPM_RETRY_STOP deck=$deck reason=blank_clean_title")
                return@launch
            }

            suspend fun sameTrack(): Boolean {
                val sameGeneration = if (isA) bpmTrackGenerationA == bpmGeneration else bpmTrackGenerationB == bpmGeneration
                val sameUrl = if (isA) MixerStore.deckA?.url == expectedUrl else MixerStore.deckB?.url == expectedUrl
                return sameGeneration && sameUrl
            }

            // Attempt 1: normal cleaned title, immediately. Fonoteka never delays the first shot.
            if (!sameTrack()) return@launch
            var httpCode = 0
            bpmFlight("BPM_PREFETCH deck=$deck attempt=1 artist=${artistDisplayName(track)} title=$lookupTitle")
            var metadata = cloudBpmRepository.lookup(
                artistKey = artistKey,
                titleKey = titleKey,
                artist = artistDisplayName(track),
                title = lookupTitle,
                diagnostic = { bpmFlight("BPM deck=$deck $it") },
                allowCachedMiss = false,
                httpStatus = { httpCode = it }
            )
            if (!sameTrack()) {
                bpmFlight("BPM_RETRY_STOP deck=$deck reason=track_changed_after_lookup")
                return@launch
            }
            var bpm = metadata?.bpm?.takeIf { it in 30f..300f }
            if (bpm != null) {
                if (isA) measuredBpmA = bpm else measuredBpmB = bpm
                bpmEvidenceByUrl[expectedUrl] = BpmEvidence(bpm, "deezer", 1f, true)
                if (effectiveQemDanceMode() == QemDanceMode.DANCE_PARTY) prepareAidjGrid(track)
                updateBpmLabel(isA, bpm)
                bpmFlight("BPM_UI deck=$deck bpm=$bpm attempt=1")
                return@launch
            }
            if (cloudBpmRepository.isRoadClosed()) {
                bpmFlight("BPM_RETRY_STOP deck=$deck reason=circuit_open_wait_for_probe")
                applyFBpmFallback(isA, track, artistKey, titleKey, expectedUrl, bpmGeneration, "circuit_open")
                return@launch
            }
            if (httpCode != 404) {
                val failReason = "http_${if (httpCode == 0) "unknown" else httpCode}"
                bpmFlight("BPM_RETRY_STOP deck=$deck reason=$failReason")
                applyFBpmFallback(isA, track, artistKey, titleKey, expectedUrl, bpmGeneration, failReason)
                return@launch
            }

            // A/B are physical playback decks: never run the Fonoteka translator from here.
            // A real 404 ends the cloud attempt for this deck and falls straight to the
            // non-blocking local F balcony fallback. Translator/enrichment belongs backstage.
            bpmFlight("BPM_RETRY_STOP deck=$deck reason=404_no_ab_translator")
            applyFBpmFallback(isA, track, artistKey, titleKey, expectedUrl, bpmGeneration, "404_no_ab_translator")
        }
        if (isA) bpmLookupJobA = job else bpmLookupJobB = job
    }

    /**
     * Server BPM lane for PARTY modes. Deezer/server is authoritative.
     * JUST A PARTY (the champagne lane) has a hard 118..138 BPM fence and
     * ranks known server BPM by distance from the 128 BPM sweet spot.
     */
    private suspend fun cloudPartyBpm(track: TrackRef): Float? {
        val mode = effectiveQemDanceMode()
        if (mode == QemDanceMode.NONE) return null
        val artistKey = endlessArtistKey(track)
        val titleKey = endlessTrackKey(track)
        if (artistKey.isBlank() || titleKey.isBlank()) return null
        val metadata = cloudBpmRepository.lookup(
            artistKey = artistKey,
            titleKey = titleKey,
            artist = artistDisplayName(track),
            title = trackDisplayTitle(track)
        ) ?: return null
        val bpm = metadata.bpm?.takeIf { it in 30f..300f }
        if (bpm != null) bpmEvidenceByUrl[track.url] = BpmEvidence(bpm, "deezer", 1f, true)
        return bpm
    }

    private suspend fun preferCloudPartyBpm(candidates: List<TrackRef>): List<TrackRef> {
        val mode = effectiveQemDanceMode()
        if (mode == QemDanceMode.NONE || candidates.isEmpty()) return candidates
        val checked = withTimeoutOrNull(900L) {
            coroutineScope {
                candidates.take(8).map { track ->
                    async(Dispatchers.IO) { track to cloudPartyBpm(track) }
                }.awaitAll()
            }
        } ?: return candidates

        val checkedUrls = checked.map { it.first.url }.toHashSet()
        val unchecked = candidates.filterNot { it.url in checkedUrls }
        return when (mode) {
            QemDanceMode.DANCE_PARTY -> {
                // 128 is the peak. Points fall symmetrically toward both hard edges, 118 and 138.
                val knownGood = checked
                    .filter { (_, bpm) -> bpm != null && bpm in 118f..138f }
                    .sortedBy { (_, bpm) -> kotlin.math.abs((bpm ?: 128f) - 128f) }
                    .map { it.first }
                val unknown = checked.filter { it.second == null }.map { it.first }
                // Known server values outside 118..138 are HARD rejected for champagne.
                knownGood + unknown + unchecked
            }
            QemDanceMode.SLOW_DANCE_PARTY -> {
                val knownGood = checked.filter { (_, bpm) -> bpm != null && bpm in 52f..108f }.map { it.first }
                val unknown = checked.filter { it.second == null }.map { it.first }
                (knownGood + unknown + unchecked).ifEmpty { candidates }
            }
            QemDanceMode.NONE -> candidates
        }
    }

    /** Full authoritative 🍾 cloud path: Deezer first, Fonoteka translator only after a real 404. */
    private suspend fun champagneDeezerBpm(track: TrackRef): Float? {
        val artistKey = endlessArtistKey(track)
        val titleKey = endlessTrackKey(track)
        val title = trackDisplayTitle(track)
        val artist = artistDisplayName(track)
        if (artistKey.isBlank() || titleKey.isBlank() || title.isBlank()) return null

        var httpCode = 0
        var metadata = cloudBpmRepository.lookup(
            artistKey = artistKey,
            titleKey = titleKey,
            artist = artist,
            title = title,
            diagnostic = { aidjFlight("CHAMPAGNE_DEEZER $it") },
            allowCachedMiss = false,
            httpStatus = { httpCode = it }
        )
        metadata?.bpm?.takeIf { it in 30f..300f }?.let { return it }
        if (httpCode != 404 || cloudBpmRepository.isRoadClosed()) return null

        aidjFlight("CHAMPAGNE_TRANSLATOR_START artist=${artist.take(60)} title=${title.take(60)}")
        ensureFonotekaCredit(artist, title)
        if (cloudBpmRepository.isRoadClosed()) return null

        httpCode = 0
        metadata = cloudBpmRepository.lookup(
            artistKey = artistKey,
            titleKey = titleKey,
            artist = artist,
            title = title,
            diagnostic = { aidjFlight("CHAMPAGNE_DEEZER_RETRY $it") },
            allowCachedMiss = false,
            httpStatus = { httpCode = it }
        )
        val bpm = metadata?.bpm?.takeIf { it in 30f..300f }
        aidjFlight("CHAMPAGNE_TRANSLATOR_DONE http=$httpCode hit=${bpm != null} artist=${artist.take(50)} title=${title.take(50)}")
        return bpm
    }

    /**
     * Final champagne BPM guard in the virtual preparation layer, before A/B receive NEXT.
     * DEEZER = GOD: server/cache/D1 is always first and authoritative. F may exist only after
     * the whole cloud path has no BPM. Low-confidence F is never allowed to become a "killer":
     * it may keep continuity, but it is marked syncSafe=false and cannot drive AIDJ SYNC.
     */
    private suspend fun champagnePreparedBpmAllowed(track: TrackRef): Boolean {
        if (effectiveQemDanceMode() != QemDanceMode.DANCE_PARTY) return true
        val artistKey = endlessArtistKey(track)
        val titleKey = endlessTrackKey(track)
        if (artistKey.isBlank() || titleKey.isBlank()) return false

        val serverBpm = runCatching { champagneDeezerBpm(track) }.getOrNull()
        if (serverBpm != null) {
            val evidence = BpmEvidence(serverBpm, "deezer", 1f, true)
            bpmEvidenceByUrl[track.url] = evidence
            val ok = serverBpm in 118f..138f
            aidjFlight("CHAMPAGNE_BPM source=deezer bpm=$serverBpm allowed=$ok title=${trackDisplayTitle(track).take(70)}")
            return ok
        }

        // Only after Deezer/Fonoteka has failed is F allowed to wake up.
        val cached = withContext(Dispatchers.IO) { fallbackBpmStore.get(artistKey, titleKey) }
        val local = cached ?: run {
            val direct = track.streamUrl ?: return false
            aidjFlight("CHAMPAGNE_F_START title=${trackDisplayTitle(track).take(70)}")
            val result = runCatching {
                runLowPriorityAnalysis { TempoAnalyzer.analyze(direct, cacheKey = "CHAMPAGNE|${track.url}", scanMs = 24_000L) }
            }.getOrNull() ?: return false
            val bpm = result.bpm.takeIf { it in 30f..300f } ?: return false
            withContext(Dispatchers.IO) { fallbackBpmStore.put(artistKey, titleKey, bpm, result.confidence) }
            FallbackBpmStore.Entry(bpm, result.confidence)
        }

        val inLane = local.bpm in 118f..138f
        val syncConfident = local.confidence >= champagneFConfidenceFloor && inLane
        bpmEvidenceByUrl[track.url] = BpmEvidence(local.bpm, "F", local.confidence, syncConfident)

        // 🍾 admission is absolute: the FINAL BPM must be inside 118..138 no matter where
        // it came from. F confidence may decide SYNC safety, but it may never smuggle 75, 150,
        // or any other outside value into JUST A PARTY. No octave trick is used to force a song
        // into the lane.
        if (!inLane) {
            aidjFlight("CHAMPAGNE_BPM source=F bpm=${local.bpm} confidence=${local.confidence} allowed=false sync=false reason=outside_hard_gate title=${trackDisplayTitle(track).take(70)}")
            return false
        }
        if (local.confidence < champagneFConfidenceFloor) {
            aidjFlight("CHAMPAGNE_F_UNCERTAIN bpm=${local.bpm} confidence=${local.confidence} allowed=true sync=false reason=low_conf title=${trackDisplayTitle(track).take(70)}")
            return true
        }

        aidjFlight("CHAMPAGNE_BPM source=F bpm=${local.bpm} confidence=${local.confidence} allowed=true title=${trackDisplayTitle(track).take(70)}")
        return true
    }

    /** Prepare beat phase only for 🍾. This is balcony work: one short opening scan, cached by URL. */
    private fun prepareAidjGrid(track: TrackRef) {
        if (effectiveQemDanceMode() != QemDanceMode.DANCE_PARTY) return
        val direct = track.streamUrl ?: return
        val evidence = bpmEvidenceByUrl[track.url] ?: return
        if (!evidence.syncSafe || evidence.bpm !in 118f..138f) {
            aidjFlight("SYNC_SKIP_PREP reason=bpm_uncertain_or_outside source=${evidence.source} bpm=${evidence.bpm} title=${trackDisplayTitle(track).take(60)}")
            return
        }
        if (aidjGridByUrl.containsKey(track.url) || aidjGridJobs[track.url]?.isActive == true) return
        val session = endlessSessionGeneration
        val job = lifecycleScope.launch {
            aidjFlight("FIRST_BEAT_START source=${evidence.source} bpm=${evidence.bpm} title=${trackDisplayTitle(track).take(60)}")
            val grid = runCatching {
                runLowPriorityAnalysis {
                    BeatGridAnalyzer.analyze(direct, evidence.bpm, cacheKey = "AIDJ|${track.url}|${evidence.bpm}", scanMs = 40_000L)
                }
            }.getOrNull()
            aidjGridJobs.remove(track.url)
            if (!endlessActive || session != endlessSessionGeneration || effectiveQemDanceMode() != QemDanceMode.DANCE_PARTY) return@launch
            if (grid == null) {
                aidjFlight("SYNC_SKIP_PREP reason=no_grid title=${trackDisplayTitle(track).take(60)}")
                return@launch
            }
            aidjGridByUrl[track.url] = grid
            aidjFlight("BEAT_PAIR firstMs=${grid.firstBeatMs} secondMs=${grid.secondBeatMs} cueMs=${grid.cueMs} confidence=${grid.confidence} bpm=${grid.bpm} title=${trackDisplayTitle(track).take(60)}")
            aidjFlight("FIRST_BEAT ms=${grid.firstBeatMs} cueMs=${grid.cueMs} confidence=${grid.confidence} bpm=${grid.bpm} title=${trackDisplayTitle(track).take(60)}")
            aidjFlight("BEAT_GRID periodMs=${grid.beatPeriodMs} firstBeatMs=${grid.firstBeatMs} secondBeatMs=${grid.secondBeatMs} confidence=${grid.confidence} title=${trackDisplayTitle(track).take(60)}")
        }
        aidjGridJobs[track.url] = job
    }

    private fun prefetchArtistArtwork(track: TrackRef) {
        val artist = artistDisplayName(track)
        val key = endlessArtistKey(track)
        if (artist.isBlank() || key.isBlank()) return
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching { artistArtworkRepository.getArtwork(artist, key) }
        }
    }

    private fun updateArtistArtworkUi() {
        updateArtistArtworkForDeck(true, playerA.isPlaying, MixerStore.deckA)
        updateArtistArtworkForDeck(false, playerB.isPlaying, MixerStore.deckB)
    }

    private fun updateArtistArtworkForDeck(isA: Boolean, isPlaying: Boolean, track: TrackRef?) {
        val view = if (isA) binding.loadA else binding.loadB
        val currentUrl = if (isA) artistArtworkTrackA else artistArtworkTrackB
        val shown = if (isA) artistArtworkShownA else artistArtworkShownB

        if (!isPlaying || track == null) {
            if (currentUrl != null || shown) restoreDeckGlobe(isA)
            return
        }

        // While ACTIVE this location is already non-interactive; artwork is visual only.
        view.isEnabled = false
        if (shown && currentUrl == track.url) {
            view.alpha = 0.80f
            return
        }
        if (currentUrl == track.url) return

        if (isA) {
            artistArtworkJobA?.cancel()
            artistArtworkTrackA = track.url
        } else {
            artistArtworkJobB?.cancel()
            artistArtworkTrackB = track.url
        }

        val artist = artistDisplayName(track)
        val artistKey = endlessArtistKey(track)
        if (artist.isBlank() || artistKey.isBlank()) return
        val job = lifecycleScope.launch {
            val bitmap = runCatching { artistArtworkRepository.getArtwork(artist, artistKey) }.getOrNull()
            val stillCurrent = if (isA) {
                playerA.isPlaying && MixerStore.deckA?.url == track.url && artistArtworkTrackA == track.url
            } else {
                playerB.isPlaying && MixerStore.deckB?.url == track.url && artistArtworkTrackB == track.url
            }
            if (!stillCurrent || bitmap == null) return@launch

            view.animate().cancel()
            view.animate().alpha(0f).setDuration(180L).withEndAction {
                val remainsCurrent = if (isA) playerA.isPlaying && MixerStore.deckA?.url == track.url
                else playerB.isPlaying && MixerStore.deckB?.url == track.url
                if (!remainsCurrent) {
                    restoreDeckGlobe(isA)
                    return@withEndAction
                }
                view.setImageBitmap(bitmap)
                view.scaleType = ImageView.ScaleType.FIT_CENTER
                if (isA) artistArtworkShownA = true else artistArtworkShownB = true
                view.animate().alpha(0.80f).setDuration(260L).start()
            }.start()
        }
        if (isA) artistArtworkJobA = job else artistArtworkJobB = job
    }

    private fun restoreDeckGlobe(isA: Boolean) {
        val view = if (isA) binding.loadA else binding.loadB
        if (isA) {
            artistArtworkJobA?.cancel()
            artistArtworkJobA = null
            artistArtworkTrackA = null
        } else {
            artistArtworkJobB?.cancel()
            artistArtworkJobB = null
            artistArtworkTrackB = null
        }
        val hadArtwork = if (isA) artistArtworkShownA else artistArtworkShownB
        if (!hadArtwork) {
            updateLoadButtons()
            return
        }
        view.animate().cancel()
        view.animate().alpha(0f).setDuration(180L).withEndAction {
            view.setImageResource(if (isA) R.drawable.load_a else R.drawable.load_b)
            view.scaleType = ImageView.ScaleType.FIT_CENTER
            if (isA) artistArtworkShownA = false else artistArtworkShownB = false
            val targetAlpha = if (controlsLocked) 0.35f else 1f
            view.alpha = 0f
            view.animate().alpha(targetAlpha).setDuration(260L).withEndAction { updateLoadButtons() }.start()
        }.start()
    }

    private fun updateLoadButtons() {
        val aLocked = playerA.isPlaying
        val bLocked = playerB.isPlaying

        binding.loadA.isEnabled = !controlsLocked && !aLocked
        binding.loadA.alpha = if (aLocked && artistArtworkShownA) 0.80f else if (controlsLocked || aLocked) 0.35f else 1f
        binding.loadB.isEnabled = !controlsLocked && !bLocked
        binding.loadB.alpha = if (bLocked && artistArtworkShownB) 0.80f else if (controlsLocked || bLocked) 0.35f else 1f
    }

    private fun setPlayColor(button: Button, pausedState: Boolean) {
        button.backgroundTintList = null
        button.setBackgroundResource(if (pausedState) R.drawable.lux_gold_button else R.drawable.lux_blue_button)
        button.setTextColor(ContextCompat.getColor(this, if (pausedState) R.color.black else R.color.white))
        button.elevation = dp(6).toFloat()
    }

    private fun updateAutoButton() {
        binding.autoMix.backgroundTintList = null
        binding.autoMix.setBackgroundResource(if (autoEnabled) R.drawable.lux_gold_button else R.drawable.lux_silver_button)
        binding.autoMix.setTextColor(ContextCompat.getColor(this, R.color.black))
        binding.autoMix.elevation = dp(6).toFloat()
        binding.autoMix.text = if (autoEnabled) "AUTO IS ON" else "AUTO IS OFF"
        binding.autoMix.isEnabled = !controlsLocked
        syncPlaybackProtectionService()
    }

    /** Keeps the process in media-playback foreground priority while audio/AUTO is live.
     *  This does not own discovery or mutate deck state; it only prevents Android from treating
     *  EndlessMix like a disposable background Activity while the user opens ChatGPT/browser.
     */
    private fun syncPlaybackProtectionService() {
        val shouldProtect = endlessActive || autoEnabled || playerA.isPlaying || playerB.isPlaying
        if (shouldProtect) ForegroundPlaybackService.start(this)
        else ForegroundPlaybackService.stop(this)
    }

    /** Explicit user STOP: unlike stopEndlessMix(), this silences both decks immediately. */
    private fun hardStopAllPlayback() {
        if (endlessActive || autoEnabled) stopEndlessMix()
        autoEnabled = false
        controlsLocked = false
        lockedSafetyStopped = false
        lockedSafetyResumeA = false
        lockedSafetyResumeB = false
        lockedSafetyAutoWasEnabled = false
        autoFadeJob?.cancel()
        endlessDiscoveryJob?.cancel()
        qemEngine.discoveryJob?.cancel()
        endlessLoadJobA?.cancel()
        endlessLoadJobB?.cancel()
        playerA.pause(); playerB.pause()
        playerA.stop(); playerB.stop()
        playerA.clearMediaItems(); playerB.clearMediaItems()
        MixerStore.deckA = null
        MixerStore.deckB = null
        MixerStore.waveA = null
        MixerStore.waveB = null
        lastTrackAUrl = null
        lastTrackBUrl = null
        refreshDecks(force = true)
        updateAutoButton()
        updateControlLockUi()
        updateModeButtons()
        ForegroundPlaybackService.stop(this)
    }

    // ---------------- ENDLESS MIX ----------------

    private fun onEndlessAction() {
        if (endlessActive) {
            stopEndlessMix()
            return
        }

        syncSeedsFromCurrentDecks()
        if (endlessSeeds.isNotEmpty()) {
            startEndlessMix()
        } else {
            endlessSeedMode = true
            showEndlessSearch(true)
            binding.endlessStatus.text = if (endlessSeeds.size == 1) {
                "1/2 loaded — choose a similar second song"
            } else {
                "Choose the first seed song"
            }
            updateEndlessAction()
        }
    }

    private fun syncSeedsFromCurrentDecks() {
        if (endlessActive) return
        endlessSeeds.clear()
        MixerStore.deckA?.let { endlessSeeds.add(it) }
        MixerStore.deckB?.let { b -> if (endlessSeeds.none { it.url == b.url }) endlessSeeds.add(b) }
        updateEndlessAction()
    }

    private fun updateEndlessAction() {
        binding.endlessAction.text = when {
            endlessActive -> "STOP ENDLESS MIX"
            endlessSeeds.isNotEmpty() -> "PLAY ENDLESS MIX"
            else -> "LOAD TWO SIMILAR SONGS\nAND MAKE ENDLESS MIX"
        }
    }

    private fun showEndlessSearch(show: Boolean) {
        if (show && quickDrawerOpen) closeQuickDrawer()
        binding.endlessSearchPanel.visibility = if (show) View.VISIBLE else View.GONE
        binding.modeButtonRow.visibility = if (show) View.GONE else View.VISIBLE
        binding.endlessLowerSpacer.visibility = if (show || quickDrawerOpen) View.GONE else View.VISIBLE
        // During seed loading the search gets the lower workspace without leaving the mixer window.
        binding.autoMix.visibility = if (show) View.GONE else View.VISIBLE
        binding.aiDjMode.visibility = if (show) View.GONE else View.VISIBLE
        binding.crossLabels.visibility = if (show) View.GONE else View.VISIBLE
        binding.crossfader.visibility = if (show) View.GONE else View.VISIBLE
        if (!show) endlessAdapter.submit(emptyList())
    }

    private fun runEndlessSearch() {
        val q = binding.endlessSearchInput.text.toString().trim()
        if (q.isBlank()) return
        binding.endlessStatus.text = "Searching…"
        lifecycleScope.launch {
            runCatching {
                withContext(Dispatchers.IO) { searchRepo.search(q) }
            }.onSuccess { results ->
                endlessAdapter.submit(results)
                binding.endlessStatus.text = if (endlessActive && endlessAddMode) {
                    "Choose a song to add — ${results.size} results"
                } else when (endlessSeeds.size) {
                    0 -> "Choose the first song — ${results.size} results"
                    else -> "Choose a similar second song — ${results.size} results"
                }
            }.onFailure {
                binding.endlessStatus.text = "Search error: ${it.message ?: "unknown"}"
            }
        }
    }

    private fun selectEndlessSeed(track: TrackRef) {
        if (endlessActive && endlessAddMode) {
            endlessAddMode = false
            controlsLocked = true
            endlessManualUrls.add(track.url)
            showEndlessSearch(false)
            updateControlLockUi()
            binding.endlessSearchInput.setText("")
            binding.endlessStatus.text = "Added to mix"
            // A deliberate user choice outranks an automatically preloaded NEXT track, but it
            // can never overwrite the currently playing deck or either still-reserved seed.
            val safeTarget: Boolean? = when {
                playerA.isPlaying && !playerB.isPlaying && !endlessSeedProtectedB -> false
                playerB.isPlaying && !playerA.isPlaying && !endlessSeedProtectedA -> true
                activeWaitingFreeDeck != null -> activeWaitingFreeDeck
                else -> null
            }
            if (safeTarget != null) {
                endlessQueued = null
                activeWaitingFreeDeck = null
                if (safeTarget) endlessLoadJobA?.cancel() else endlessLoadJobB?.cancel()
                loadEndlessTrackIntoDeck(safeTarget, track)
            } else {
                endlessQueued = track
            }
            return
        }
        if (endlessSeeds.any { it.url == track.url }) {
            Toast.makeText(this, "Choose a different second song", Toast.LENGTH_SHORT).show()
            return
        }

        when {
            MixerStore.deckA == null -> MixerStore.setA(track)
            MixerStore.deckB == null -> MixerStore.setB(track)
            endlessSeeds.isEmpty() -> MixerStore.setA(track)
            endlessSeeds.size == 1 -> {
                val first = endlessSeeds.first()
                if (MixerStore.deckA?.url == first.url) MixerStore.setB(track) else MixerStore.setA(track)
            }
            else -> return
        }

        refreshDecks()
        syncSeedsFromCurrentDecks()
        if (endlessSeeds.size >= 2) {
            endlessSeedMode = false
            showEndlessSearch(false)
            binding.endlessSearchInput.setText("")
            updateEndlessAction()
        } else {
            binding.endlessStatus.text = "1/2 loaded — choose a similar second song"
        }
    }

    private fun startEndlessMix() {
        syncSeedsFromCurrentDecks()
        if (endlessSeeds.isEmpty()) {
            showEndlessSearch(true)
            return
        }

        if (autoDiscoveryMotor == AutoDiscoveryMotor.NONE) {
            switchDiscoveryMotor(if (quickSessionActive) AutoDiscoveryMotor.QEM else AutoDiscoveryMotor.BASIC)
        }

        // Every successful Endless start advances persistent history by one mix. Previous plays
        // keep a ranking penalty for exactly the next five mixes; the sixth mix restores normal rank.
        beginPersistentMix()

        // A new Endless press is a NEW session, but it adopts whatever is already playing.
        // Nothing queued/resolving from the previous session may survive and overwrite the
        // user's newly chosen A/B tracks.
        endlessSessionGeneration++
        endlessDiscoveryJob?.cancel()
        endlessDiscoveryJob = null
        endlessLoadJobA?.cancel()
        endlessLoadJobB?.cancel()
        endlessLoadJobA = null
        endlessLoadJobB = null
        endlessQueued = null
        qemEngine.queued = null
        qemEngine.virtualCrateJob?.cancel(); qemEngine.virtualCrateJob = null
        qemEngine.handoffJobA?.cancel(); qemEngine.handoffJobA = null
        qemEngine.handoffJobB?.cancel(); qemEngine.handoffJobB = null
        qemEngine.virtualCrateC.clear(); qemEngine.virtualCrateD.clear()
        aidjGridJobs.values.forEach { it.cancel() }
        aidjGridJobs.clear()
        aidjGridByUrl.clear()
        bpmEvidenceByUrl.clear()
        playerA.playbackParameters = PlaybackParameters(1f)
        playerB.playbackParameters = PlaybackParameters(1f)
        basicWaitingFreeDeck = null
        qemEngine.waitingFreeDeck = null
        endlessRecoveryDeck = null
        endlessActiveOwnerIsA = null
        endlessOwnerStartedAtMs = 0L
        endlessLastRefillKickAtMs = 0L
        unexpectedActiveStopSinceA = 0L
        unexpectedActiveStopSinceB = 0L
        endlessManualProtectedA = false
        endlessManualProtectedB = false
        endlessPendingNextUrlA = null
        endlessPendingNextUrlB = null
        endlessManualUrls.clear()
        endlessAnchorTracks.clear()
        endlessPendingAnchorTracks.clear()
        endlessDiscoveriesSinceAnchorExpansion = 0
        autoFadeJob?.cancel()
        autoFadeJob = null
        // A stale prepare callback from a previous/manual deck must never auto-start A after
        // Endless has selected B (or vice versa). Start permission belongs to exactly one deck.
        pendingEndlessStart = false
        pendingEndlessStartIsA = null

        if (::audioFocusRequest.isInitialized) audioManager.requestAudioFocus(audioFocusRequest)
        endlessActive = true
        endlessSeedMode = false
        autoEnabled = true
        // Master live-safety rule: every mix mode enters LOCK automatically.
        // Starting/locking never touches playback; the user may explicitly UNLOCK afterwards.
        controlsLocked = true
        endlessUsedUrls.clear()
        endlessUsedTrackKeys.clear()
        endlessSeedArtistKeys.clear()
        endlessNonSeedSelections = 0
        endlessPlayedAutoUrls.clear()
        endlessArtistReplayQueue.clear()
        endlessModeLocked = false
        val seedAForProfile = endlessSeeds[0]
        val seedBForProfile = endlessSeeds.getOrNull(1) ?: seedAForProfile
        // A one-seed session is valid: play/adopt it now and let background discovery fill NEXT.
        // Do not accidentally enter artist-only mode just because the fallback profile seed is itself.
        endlessArtistOnlyMode = endlessSeeds.size >= 2 && sameArtistConfidence(seedAForProfile, seedBForProfile)
        endlessGenreProfile = classifyEndlessGenre(seedAForProfile, seedBForProfile)
        endlessSceneProfile = quickSceneOverride ?: classifyEndlessScene(seedAForProfile, seedBForProfile)
        endlessModeLocked = true
        endlessArtistOnlySeed = if (endlessArtistOnlyMode) endlessSeeds[0] else null
        endlessArtistAllowLongTracks = false
        endlessRecent.clear()
        endlessRecentArtists.clear()
        endlessPlayedArtistHistory.clear()
        endlessSeeds.take(2).forEach {
            endlessUsedUrls.add(it.url)
            endlessUsedTrackKeys.add(endlessTrackKey(it))
            endlessSeedArtistKeys.add(endlessArtistKey(it))
            endlessRecent.add(it)
            rememberEndlessArtist(it)
            endlessAnchorTracks.add(it)
        }
        endlessDeckHasPlayedA = playerA.isPlaying
        endlessDeckHasPlayedB = playerB.isPlaying
        showEndlessSearch(false)
        updateAutoButton()
        updateEndlessAction()
        updateControlLockUi()

        // Adopt the LIVE mixer instead of forcing deck A from 0:00.
        // Preserve playback positions and the user's current crossfader. The non-playing loaded
        // deck becomes READY_NEXT; if both are playing, the louder side is treated as current.
        // QUICK is not an "adopt the live mixer" start. It has a deterministic owner:
        // deck A starts, deck B is READY_NEXT, and the fader is hard-left.
        // BASIC and QEM use the exact same physical A/B transmission and status rail.
        // Never invent a Quick-only owner: the deck that is actually playing owns the mix.
        // This keeps the crossfader/status rail truthful and makes QEM handoff identical to
        // the proven Basic Endless behavior.
        val activeIsA = when {
            playerA.isPlaying && !playerB.isPlaying -> true
            playerB.isPlaying && !playerA.isPlaying -> false
            playerA.isPlaying && playerB.isPlaying -> cross <= 0.5f
            playerA.mediaItemCount > 0 && playerB.mediaItemCount == 0 -> true
            playerB.mediaItemCount > 0 && playerA.mediaItemCount == 0 -> false
            else -> cross <= 0.5f
        }

        // Session start can never be visually/audio "cross-eyed": the fader is committed to
        // the deck that owns playback before AUTO becomes operational. QUICK with no live song
        // still owns A; an adopted live song keeps whichever deck is actually playing.
        cross = if (activeIsA) 0f else 1f
        binding.crossfader.progress = if (activeIsA) 0 else 100
        applyVolumes()

        // QEM shares Basic Endless playback ownership. Do not pause/reset both decks here.
        // QEM differs only in discovery/filtering; the physical A/B chassis and status rail are shared.

        if (activeIsA) {
            // One source deck only. The opposite seed is prepared NEXT but must not run in parallel.
            if (playerB.isPlaying) playerB.pause()
            endlessDeckStateA = EndlessDeckState.PLAYING
            endlessDeckStateB = when {
                playerB.mediaItemCount == 0 -> EndlessDeckState.FREE
                playerB.playbackState == Player.STATE_READY -> EndlessDeckState.READY_NEXT
                else -> EndlessDeckState.LOADING_NEXT
            }
            endlessSeedProtectedA = playerA.mediaItemCount > 0
            endlessSeedProtectedB = playerB.mediaItemCount > 0
            if (!playerA.isPlaying) {
                if (playerA.mediaItemCount > 0) playerA.play()
                else {
                    pendingEndlessStart = true
                    pendingEndlessStartIsA = true
                    MixerStore.deckA?.let { resolvePrepareAnalyze(true, it) }
                }
            }
        } else {
            // Symmetric B start: clear/pause A and grant deferred autoplay only to B.
            if (playerA.isPlaying) playerA.pause()
            endlessDeckStateB = EndlessDeckState.PLAYING
            endlessDeckStateA = when {
                playerA.mediaItemCount == 0 -> EndlessDeckState.FREE
                playerA.playbackState == Player.STATE_READY -> EndlessDeckState.READY_NEXT
                else -> EndlessDeckState.LOADING_NEXT
            }
            endlessSeedProtectedA = playerA.mediaItemCount > 0
            endlessSeedProtectedB = playerB.mediaItemCount > 0
            if (!playerB.isPlaying) {
                if (playerB.mediaItemCount > 0) playerB.play()
                else {
                    pendingEndlessStart = true
                    pendingEndlessStartIsA = false
                    MixerStore.deckB?.let { resolvePrepareAnalyze(false, it) }
                }
            }
        }

        // If Endless adopts a track that was already playing before the session started,
        // ExoPlayer may not emit a fresh onIsPlayingChanged(true). Record it explicitly so
        // artist cooldown and played-song hard block start from the real current song.
        when {
            playerA.isPlaying -> MixerStore.deckA?.let { rememberActuallyPlayedTrack(it) }
            playerB.isPlaying -> MixerStore.deckB?.let { rememberActuallyPlayedTrack(it) }
        }

        // Reconcile logical state with the actual player/store before the first refill kick.
        // If the UI/player is EMPTY, it is FREE regardless of stale protection/state flags.
        if (MixerStore.deckA == null || playerA.mediaItemCount == 0) {
            endlessDeckStateA = EndlessDeckState.FREE
            endlessSeedProtectedA = false
            endlessManualProtectedA = false
        }
        if (MixerStore.deckB == null || playerB.mediaItemCount == 0) {
            endlessDeckStateB = EndlessDeckState.FREE
            endlessSeedProtectedB = false
            endlessManualProtectedB = false
        }

        // If one physical deck is already FREE, arm it AND start discovery immediately.
        // The waiting flag is only the destination, never a substitute for a running search.
        if (!suppressInitialEndlessDiscovery) {
            if (endlessDeckStateA == EndlessDeckState.FREE && !playerA.isPlaying) {
                activeWaitingFreeDeck = true
                discoverQueuedCandidate()
            } else if (endlessDeckStateB == EndlessDeckState.FREE && !playerB.isPlaying) {
                activeWaitingFreeDeck = false
                discoverQueuedCandidate()
            }
        }
        updateControlLockUi()
    }

    private fun stopEndlessMix() {
        // Invalidate every asynchronous result from this session BEFORE clearing state. A stale
        // English/USA candidate from an old session must never arrive later and replace new seeds.
        endlessSessionGeneration++
        switchDiscoveryMotor(AutoDiscoveryMotor.NONE)
        quickSessionActive = false
        oneArtistMixActive = false
        qemEngine.sessionArtistPool = emptyList()
        qemEngine.sessionStyleKeys = emptySet()
        qemEngine.sessionEraKeys = emptySet()
        qemEngine.sessionInstrumental = false
        qemEngine.sessionPiano = false
        qemEngine.recentArtistIds.clear()
        qemEngine.trackArtistIds.clear()
        qemEngine.candidateStamps.clear()
        quickSessionTempoBand = null
        quickStartupGuardA = false
        endlessActive = false
        endlessSeedMode = false
        autoEnabled = false
        controlsLocked = false
        pendingEndlessStart = false
        pendingEndlessStartIsA = null
        endlessDiscoveryJob?.cancel()
        endlessDiscoveryJob = null
        endlessLoadJobA?.cancel()
        endlessLoadJobB?.cancel()
        endlessLoadJobA = null
        endlessLoadJobB = null
        autoFadeJob?.cancel()
        autoFadeJob = null
        endlessQueued = null
        qemEngine.queued = null
        qemEngine.virtualCrateJob?.cancel(); qemEngine.virtualCrateJob = null
        qemEngine.handoffJobA?.cancel(); qemEngine.handoffJobA = null
        qemEngine.handoffJobB?.cancel(); qemEngine.handoffJobB = null
        qemEngine.virtualCrateC.clear(); qemEngine.virtualCrateD.clear()
        basicWaitingFreeDeck = null
        qemEngine.waitingFreeDeck = null
        endlessDeckHasPlayedA = false
        endlessDeckHasPlayedB = false
        endlessDeckStateA = EndlessDeckState.FREE
        endlessDeckStateB = EndlessDeckState.FREE
        endlessSeedProtectedA = false
        endlessSeedProtectedB = false
        endlessManualProtectedA = false
        endlessManualProtectedB = false
        endlessPendingNextUrlA = null
        endlessPendingNextUrlB = null
        endlessAddMode = false
        endlessManualUrls.clear()
        quickSceneOverride = null
        quickSessionAnchorTerms = ""
        quickSessionStyleTerms = ""
        quickLongFormDuration = false
        endlessSeeds.clear()
        endlessUsedUrls.clear()
        endlessUsedTrackKeys.clear()
        endlessSeedArtistKeys.clear()
        endlessNonSeedSelections = 0
        endlessPlayedAutoUrls.clear()
        endlessGenreProfile = EndlessGenreProfile.POP
        endlessSceneProfile = EndlessSceneProfile.GLOBAL
        endlessArtistOnlyMode = false
        endlessModeLocked = false
        endlessRecoveryDeck = null
        endlessArtistOnlySeed = null
        endlessArtistAllowLongTracks = false
        endlessArtistReplayQueue.clear()
        endlessRecent.clear()
        endlessRecentArtists.clear()
        endlessPlayedArtistHistory.clear()
        endlessAnchorTracks.clear()
        endlessPendingAnchorTracks.clear()
        endlessDiscoveriesSinceAnchorExpansion = 0
        showEndlessSearch(false)
        updateAutoButton()
        updateEndlessAction()
        updateControlLockUi()
        updateModeButtons()
        // Deliberately do not pause/seek either player: current music continues uninterrupted.
    }

    private fun stopEndlessForManualControl() {
        endlessSessionGeneration++
        switchDiscoveryMotor(AutoDiscoveryMotor.NONE)
        quickSessionActive = false
        oneArtistMixActive = false
        qemEngine.sessionArtistPool = emptyList()
        qemEngine.sessionStyleKeys = emptySet()
        qemEngine.sessionEraKeys = emptySet()
        qemEngine.sessionInstrumental = false
        qemEngine.sessionPiano = false
        qemEngine.recentArtistIds.clear()
        qemEngine.trackArtistIds.clear()
        qemEngine.candidateStamps.clear()
        quickSessionTempoBand = null
        quickStartupGuardA = false
        endlessActive = false
        endlessSeedMode = false
        autoEnabled = false
        controlsLocked = false
        pendingEndlessStart = false
        pendingEndlessStartIsA = null
        endlessDiscoveryJob?.cancel()
        endlessDiscoveryJob = null
        endlessLoadJobA?.cancel()
        endlessLoadJobB?.cancel()
        endlessLoadJobA = null
        endlessLoadJobB = null
        endlessQueued = null
        qemEngine.queued = null
        qemEngine.virtualCrateJob?.cancel(); qemEngine.virtualCrateJob = null
        qemEngine.handoffJobA?.cancel(); qemEngine.handoffJobA = null
        qemEngine.handoffJobB?.cancel(); qemEngine.handoffJobB = null
        qemEngine.virtualCrateC.clear(); qemEngine.virtualCrateD.clear()
        basicWaitingFreeDeck = null
        qemEngine.waitingFreeDeck = null
        endlessDeckHasPlayedA = false
        endlessDeckHasPlayedB = false
        endlessDeckStateA = EndlessDeckState.FREE
        endlessDeckStateB = EndlessDeckState.FREE
        endlessSeedProtectedA = false
        endlessSeedProtectedB = false
        endlessManualProtectedA = false
        endlessManualProtectedB = false
        endlessPendingNextUrlA = null
        endlessPendingNextUrlB = null
        endlessAddMode = false
        endlessManualUrls.clear()
        quickSceneOverride = null
        quickSessionAnchorTerms = ""
        quickSessionStyleTerms = ""
        quickLongFormDuration = false
        endlessSeeds.clear()
        endlessUsedUrls.clear()
        endlessUsedTrackKeys.clear()
        endlessSeedArtistKeys.clear()
        endlessNonSeedSelections = 0
        endlessPlayedAutoUrls.clear()
        endlessGenreProfile = EndlessGenreProfile.POP
        endlessSceneProfile = EndlessSceneProfile.GLOBAL
        endlessArtistOnlyMode = false
        endlessModeLocked = false
        endlessRecoveryDeck = null
        endlessArtistOnlySeed = null
        endlessArtistAllowLongTracks = false
        endlessArtistReplayQueue.clear()
        endlessRecent.clear()
        endlessRecentArtists.clear()
        endlessPlayedArtistHistory.clear()
        endlessAnchorTracks.clear()
        endlessPendingAnchorTracks.clear()
        endlessDiscoveriesSinceAnchorExpansion = 0
        showEndlessSearch(false)
        updateAutoButton()
        updateEndlessAction()
        updateControlLockUi()
    }

    private fun onEndlessTransitionComplete(freedIsA: Boolean) {
        if (endlessActive) {
            // Fade completion is a hard ownership boundary. The opposite deck is now ACTIVE by
            // definition; normalize its logical state from the real transport before any FREE/refill
            // bookkeeping runs. This prevents the scheduler from losing a song that is audibly live.
            val activeIsA = !freedIsA
            val activePlayer = if (activeIsA) playerA else playerB
            val activeState = if (activeIsA) endlessDeckStateA else endlessDeckStateB
            if (activePlayer.isPlaying && activeState != EndlessDeckState.PLAYING) {
                flight("STATE_REPAIR deck=${if (activeIsA) "A" else "B"} from=$activeState to=PLAYING reason=fade_complete")
                if (activeIsA) endlessDeckStateA = EndlessDeckState.PLAYING else endlessDeckStateB = EndlessDeckState.PLAYING
            }
            // No stale pending NEXT claim may survive promotion of the deck to ACTIVE.
            if (activeIsA) endlessPendingNextUrlA = null else endlessPendingNextUrlB = null
        }
        flight("TRANSITION_COMPLETE_ENTER free=${if (freedIsA) "A" else "B"} Aplay=${playerA.isPlaying} Bplay=${playerB.isPlaying} stateA=$endlessDeckStateA stateB=$endlessDeckStateB")
        if (!endlessActive) return
        // QEM must not start a fresh NewPipe/network burst on the exact frame that the fade ends.
        // Give the new ACTIVE player and UI three seconds to settle first. The old deck stays parked
        // and no playback object is stopped/cleared during this window.
        if (autoDiscoveryMotor == AutoDiscoveryMotor.QEM) {
            qemEngine.searchNotBeforeMs = SystemClock.elapsedRealtime() + 3_000L
        }
        // NEXT/crossfade is playback only. It must never change the automatic discovery owner.
        // Restore the session mirror BEFORE freeing/refilling the old deck, otherwise a stale
        // quickSessionActive=false could route refill into BASIC.
        enforceAutoOwnerInvariant()
        // Do not bookkeep the NEW ACTIVE here. Played-history belongs to the playback listener,
        // not to the crossfade completion frame. Keeping this callback tiny protects A/B.

        // Crossfade completion is authoritative: an original seed is protected only until it
        // has actually had its first turn. Once that seed was the source of a completed fade,
        // release its reservation and reclaim the deck immediately.
        if (freedIsA) endlessSeedProtectedA = false else endlessSeedProtectedB = false

        // A manually added track is protected only until it has had its guaranteed turn.
        // Once it finishes as the source of a completed transition, release that protection
        // and allow the physical deck to become FREE for normal Endless discovery again.
        val finished = if (freedIsA) MixerStore.deckA else MixerStore.deckB
        // Selection-level duplicate claims live only while a track occupies/owns a physical slot.
        // Once it has genuinely finished, release that claim; the persistent 20-play history is
        // now the sole authority deciding when the song becomes eligible again.
        finished?.let {
            endlessUsedUrls.remove(it.url)
            endlessUsedTrackKeys.remove(endlessTrackKey(it))
        }
        if (finished?.url in endlessManualUrls) {
            finished?.url?.let { endlessManualUrls.remove(it) }
            if (freedIsA) endlessManualProtectedA = false else endlessManualProtectedB = false
        }
        flight("TRANSITION_BEFORE_FREE free=${if (freedIsA) "A" else "B"}")
        freePausedEndlessDeck(freedIsA, force = true, requestNextImmediately = false)
        flight("TRANSITION_AFTER_FREE free=${if (freedIsA) "A" else "B"} stateA=$endlessDeckStateA stateB=$endlessDeckStateB")
        requestNextPleaseAfterTransition(freedIsA)
        flight("TRANSITION_SEDATIVE_ARMED free=${if (freedIsA) "A" else "B"}")
    }

    private fun isNextSelectionFrozen(targetIsA: Boolean, proposedUrl: String): Boolean {
        if (!endlessActive) return false
        val source = if (targetIsA) playerB else playerA
        if (!source.isPlaying) return false
        val remaining = remainingMs(source)
        if (remaining < 0L || remaining > endlessNextFreezeMs) return false

        // In the final 30 seconds, an already chosen NEXT is immutable.
        // This includes a candidate that is still resolving/loading. If no NEXT exists yet,
        // filling the empty deck is still allowed to protect continuity.
        val pendingUrl = if (targetIsA) endlessPendingNextUrlA else endlessPendingNextUrlB
        val state = if (targetIsA) endlessDeckStateA else endlessDeckStateB
        val loadedUrl = if (state == EndlessDeckState.LOADING_NEXT || state == EndlessDeckState.READY_NEXT) {
            if (targetIsA) MixerStore.deckA?.url else MixerStore.deckB?.url
        } else null
        val chosenUrl = pendingUrl ?: loadedUrl
        return chosenUrl != null && chosenUrl != proposedUrl
    }

    private fun loadEndlessTrackIntoDeck(isA: Boolean, track: TrackRef) {
        if (!endlessActive) return
        val isManualTrack = track.url in endlessManualUrls
        // QEM/1 ARTIST hard provenance gate: every automatic track loaded while the fonoteka
        // motor owns AUTO must have been produced by that motor. This makes REGION/STYLE/ERA
        // impossible to bypass via a stale Basic Endless result or a late async callback.
        if (autoDiscoveryMotor == AutoDiscoveryMotor.QEM && !isManualTrack && !isCurrentQemCandidate(track)) {
            // FINAL QEM AIRLOCK. A stale Basic result, an older QEM generation, or a candidate
            // from another REGION/STYLE/ERA fingerprint can never enter a physical deck.
            qemEngine.queued = null
            qemEngine.waitingFreeDeck = isA
            discoverQemCandidate()
            return
        }
        if (isNextSelectionFrozen(isA, track.url)) {
            // Keep the late candidate for a later slot; never swap NEXT inside the final 40 s.
            queueForActiveMotor(track)
            return
        }
        // The currently audible deck is sacred until the configured mix-out window.
        // Discovery may prepare only the waiting/free deck; never overwrite a track that is playing.
        val targetPlayer = if (isA) playerA else playerB
        if (targetPlayer.isPlaying) {
            queueForActiveMotor(track)
            return
        }
        // READY_NEXT is sticky once it has passed all gates. A later auto search/rerank may not
        // churn a good prepared song out of the deck. Explicit manual ADD TO MIX is the only
        // user-authorized override; invalid/unplayable candidates are freed elsewhere.
        val currentState = if (isA) endlessDeckStateA else endlessDeckStateB
        val currentReadyUrl = if (isA) MixerStore.deckA?.url else MixerStore.deckB?.url
        val currentPendingUrl = if (isA) endlessPendingNextUrlA else endlessPendingNextUrlB
        val currentOwnedUrl = currentPendingUrl ?: currentReadyUrl
        if (!isManualTrack &&
            (currentState == EndlessDeckState.LOADING_NEXT || currentState == EndlessDeckState.READY_NEXT) &&
            currentOwnedUrl != null && currentOwnedUrl != track.url) {
            // Sticky ownership begins the instant a candidate claims LOADING_NEXT, even before its
            // async resolver commits into MixerStore. This closes the small race where a second QEM
            // result saw MixerStore=null and replaced the first candidate while it was still loading.
            flight("NEXT_STICKY_PARK deck=${if (isA) "A" else "B"} state=$currentState owner=${currentOwnedUrl.takeLast(48)} incoming=${track.url.takeLast(48)}")
            queueForActiveMotor(track)
            return
        }
        if ((isA && endlessSeedProtectedA) || (!isA && endlessSeedProtectedB)) {
            queueForActiveMotor(track)
            return
        }
        // Manual ADD TO MIX is law for itself: once a user-selected track owns a NEXT deck,
        // no automatic candidate, rerank, refresh, recovery or late async result may replace it.
        // The only permitted write into a manually protected deck is that same manual track.
        val manualProtected = if (isA) endlessManualProtectedA else endlessManualProtectedB
        if (manualProtected && !isManualTrack) {
            queueForActiveMotor(track)
            return
        }
        if (isManualTrack) {
            if (isA) endlessManualProtectedA = true else endlessManualProtectedB = true
        }
        val session = endlessSessionGeneration
        val loadOwner = autoDiscoveryMotor
        val loadQemGeneration = qemEngine.discoveryGeneration
        val loadQemFingerprint = qemEngine.filterFingerprint
        val needsTempoValidation = requiresMeasuredTempoFilter() && !isManualTrack
        if (isA) tempoValidatedA = !needsTempoValidation else tempoValidatedB = !needsTempoValidation
        if (isA) {
            endlessPendingNextUrlA = track.url
            endlessDeckStateA = EndlessDeckState.LOADING_NEXT
        } else {
            endlessPendingNextUrlB = track.url
            endlessDeckStateB = EndlessDeckState.LOADING_NEXT
        }
        // The slot has a real owner now; continuity monitoring is no longer needed for this cycle.
        if (::qemFreeDeckWatchdog.isInitialized) qemFreeDeckWatchdog.stop(isA)
        val job = lifecycleScope.launch {
            val resolved = withTimeoutOrNull(8_000L) {
                withContext(Dispatchers.IO) {
                    runCatching {
                        if (track.streamUrl != null) track
                        else track.copy(streamUrl = AudioResolver.resolveBestAudioUrl(track.url))
                    }.getOrNull()
                }
            }
            if (!endlessActive || session != endlessSessionGeneration) return@launch
            // A NEXT resolve that began under another motor can never commit after a mode switch.
            if (autoDiscoveryMotor != loadOwner) return@launch
            if (loadOwner == AutoDiscoveryMotor.QEM && !isManualTrack) {
                if (loadQemGeneration != qemEngine.discoveryGeneration ||
                    loadQemFingerprint != qemEngine.filterFingerprint ||
                    !isCurrentQemCandidate(track) ||
                    (resolved != null && !isCurrentQemCandidate(resolved))) return@launch
            }
            // Hard freeze: once the opposite/current song is inside its final 40 seconds,
            // a late async completion may commit only if it is still the chosen NEXT URL.
            val chosenPending = if (isA) endlessPendingNextUrlA else endlessPendingNextUrlB
            if (chosenPending != track.url || isNextSelectionFrozen(isA, track.url)) return@launch
            // A stale automatic load may have started before the user pressed ADD TO MIX.
            // Re-check protection after resolve so that late async completion can never overwrite
            // the user's manually inserted NEXT track or mark its deck FREE.
            val protectedNow = if (isA) endlessManualProtectedA else endlessManualProtectedB
            if (!isManualTrack && protectedNow) return@launch
            if (resolved == null) {
                if (isManualTrack) {
                    endlessManualUrls.remove(track.url)
                    if (isA) endlessManualProtectedA = false else endlessManualProtectedB = false
                }
                if (isA) {
                    endlessPendingNextUrlA = null
                    endlessDeckStateA = EndlessDeckState.FREE
                } else {
                    endlessPendingNextUrlB = null
                    endlessDeckStateB = EndlessDeckState.FREE
                }
                activeWaitingFreeDeck = isA
                if (::qemFreeDeckWatchdog.isInitialized) qemFreeDeckWatchdog.start(isA)
                clearQueuedForActiveMotor()
                delay(500)
                if (session == endlessSessionGeneration) discoverQueuedCandidate()
                return@launch
            }

            // ASYNC COMMIT FIREWALL: the target may have become ACTIVE while URL resolution was
            // running. Re-read the physical player NOW; a stale job may never overwrite a live deck.
            val targetNow = if (isA) playerA else playerB
            if (targetNow.isPlaying) {
                if (isA) endlessPendingNextUrlA = null else endlessPendingNextUrlB = null
                queueForActiveMotor(resolved)
                return@launch
            }
            if (isA) {
                MixerStore.setA(resolved)
                endlessPendingNextUrlA = null
            } else {
                MixerStore.setB(resolved)
                endlessPendingNextUrlB = null
            }
            endlessRecent.add(resolved)
            while (endlessRecent.size > 8) endlessRecent.removeAt(0)
            rememberEndlessArtist(resolved)
            endlessUsedTrackKeys.add(endlessTrackKey(resolved))
            refreshDecks(onlyIsA = isA)
            // refreshDecks resets per-deck analysis state. Re-apply the authoritative BPM gate
            // for this exact NEXT load; manual ADD TO MIX bypasses automatic tempo rejection.
            if (isA) tempoValidatedA = !needsTempoValidation else tempoValidatedB = !needsTempoValidation

            val direct = resolved.streamUrl
            if (direct == null) {
                // Never leave a deck stuck in LOADING_NEXT because a resolver returned a TrackRef
                // without a playable stream. Treat it exactly like a rejected candidate and keep
                // the persistent discovery loop alive.
                if (isA) {
                    endlessPendingNextUrlA = null
                    endlessDeckStateA = EndlessDeckState.FREE
                } else {
                    endlessPendingNextUrlB = null
                    endlessDeckStateB = EndlessDeckState.FREE
                }
                activeWaitingFreeDeck = isA
                if (::qemFreeDeckWatchdog.isInitialized) qemFreeDeckWatchdog.start(isA)
                delay(250)
                if (endlessActive && session == endlessSessionGeneration) discoverQueuedCandidate()
                return@launch
            }
            val key = resolved.url

            // Cloud BPM is triggered centrally from prepareDeck() for every prepared track.
            // Keeping a second trigger here would duplicate Worker requests for automatic NEXT loads.

            // Legacy measured-tempo branch remains dormant. Cloud metadata above is enrichment only
            // and never gates READY_NEXT or playback.
            // Real BPM validation starts immediately after playable URL preparation, in parallel
            // with intro/waveform work. ExoPlayer may buffer meanwhile, but READY_NEXT is gated
            // until this check passes whenever manual tempo or a venue tempo profile is active.
            if (needsTempoValidation) {
                launch {
                    val tempo = runLowPriorityAnalysis { TempoAnalyzer.analyze(direct, cacheKey = key) }
                    val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                    if (!endlessActive || session != endlessSessionGeneration || !sameTrack) return@launch
                    if (tempo == null) {
                        // Unknown BPM must not deadlock Endless. Keep the candidate, but search terms
                        // still bias it toward the requested profile.
                        if (isA) tempoValidatedA = true else tempoValidatedB = true
                    } else {
                        if (isA) measuredBpmA = tempo.bpm else measuredBpmB = tempo.bpm
                        updateBpmLabel(isA, tempo.bpm)
                        if (!isMeasuredTempoAcceptable(tempo)) {
                            val source = if (isA) playerB else playerA
                            val safeToReplace = !source.isPlaying || remainingMs(source) > endlessNextFreezeMs
                            if (safeToReplace) {
                                endlessUsedUrls.add(resolved.url)
                                endlessUsedTrackKeys.add(endlessTrackKey(resolved))
                                if (isA) tempoValidatedA = false else tempoValidatedB = false
                                val fallback = queuedForActiveMotor()
                                clearQueuedForActiveMotor()
                                freePausedEndlessDeck(isA, force = true)
                                activeWaitingFreeDeck = isA
                                if (fallback != null) loadEndlessTrackIntoDeck(isA, fallback)
                                else {
                                    delay(150)
                                    if (endlessActive && session == endlessSessionGeneration) discoverQueuedCandidate()
                                }
                                return@launch
                            } else {
                                // Too late to churn NEXT. Continuity beats a late preference miss.
                                if (isA) tempoValidatedA = true else tempoValidatedB = true
                            }
                        }
                        if (isA) tempoValidatedA = true else tempoValidatedB = true
                    }
                    val stateNow = if (isA) endlessDeckStateA else endlessDeckStateB
                    val playerNow = if (isA) playerA else playerB
                    if (stateNow == EndlessDeckState.LOADING_NEXT && playerNow.playbackState == Player.STATE_READY && !playerNow.isPlaying) {
                        if (isA) endlessDeckStateA = EndlessDeckState.READY_NEXT else endlessDeckStateB = EndlessDeckState.READY_NEXT
                    }
                }
            }

            launch {
                delay(1_500)
                if (!endlessActive || session != endlessSessionGeneration) return@launch
                val intro = runLowPriorityAnalysis {
                    runCatching { WaveformAnalyzer.analyzeIntro(direct) }.getOrNull()
                } ?: return@launch
                val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                if (!endlessActive || session != endlessSessionGeneration || !sameTrack) return@launch
                // Reject a genuinely near-silent/broken NEXT during the EARLY preload scan, never
                // at transition time. Inside the protected final 30 s we keep the already-prepared
                // NEXT rather than creating dead air. Prefer an already-buffered queue fallback.
                if (!isManualTrack && intro.rms >= 0.001f && intro.rms < minimumEndlessRms) {
                    val source = if (isA) playerB else playerA
                    val safeToReplace = !source.isPlaying || remainingMs(source) > endlessNextFreezeMs
                    if (safeToReplace) {
                        endlessUsedUrls.add(resolved.url)
                        endlessUsedTrackKeys.add(endlessTrackKey(resolved))
                        val fallback = queuedForActiveMotor()
                        clearQueuedForActiveMotor()
                        freePausedEndlessDeck(isA, force = true)
                        activeWaitingFreeDeck = isA
                        if (fallback != null) loadEndlessTrackIntoDeck(isA, fallback)
                        else if (endlessActive && session == endlessSessionGeneration) discoverQueuedCandidate()
                        return@launch
                    }
                }
                if (isA) mixInMsA = maxOf(mixInMsA, intro.mixInMs)
                else mixInMsB = maxOf(mixInMsB, intro.mixInMs)
            }

            launch {
                delay(5_000)
                if (!endlessActive || session != endlessSessionGeneration) return@launch
                val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                if (sameTrack) analyzeWaveform(isA, resolved)
            }
        }
        if (isA) {
            endlessLoadJobA?.cancel()
            endlessLoadJobA = job
        } else {
            endlessLoadJobB?.cancel()
            endlessLoadJobB = job
        }
    }


    private fun queueWaitingSlot2(track: TrackRef, session: Long) {
        // Motor-local logical Waiting Slot 2. It never shares storage across BASIC/QEM.
        val ownerAtQueue = autoDiscoveryMotor
        val qemGenerationAtQueue = qemEngine.discoveryGeneration
        if (ownerAtQueue == AutoDiscoveryMotor.QEM && !isCurrentQemCandidate(track)) {
            discoverQemCandidate()
            return
        }
        queueForActiveMotor(track)
        lifecycleScope.launch {
            val prepared = withTimeoutOrNull(8_000L) {
                withContext(Dispatchers.IO) {
                    runCatching {
                        if (track.streamUrl != null) track
                        else track.copy(streamUrl = AudioResolver.resolveBestAudioUrl(track.url))
                    }.getOrNull()
                }
            }
            if (!endlessActive || session != endlessSessionGeneration || autoDiscoveryMotor != ownerAtQueue) return@launch
            if (ownerAtQueue == AutoDiscoveryMotor.QEM && qemGenerationAtQueue != qemEngine.discoveryGeneration) return@launch
            if (queuedForActiveMotor()?.url != track.url) return@launch
            if (prepared?.streamUrl != null) {
                if (ownerAtQueue == AutoDiscoveryMotor.QEM && !isCurrentQemCandidate(track)) {
                    clearQueuedForActiveMotor(); discoverQemCandidate(); return@launch
                }
                clearQueuedForActiveMotor()
                queueForActiveMotor(prepared)
            } else {
                clearQueuedForActiveMotor()
                delay(250L)
                if (endlessActive && session == endlessSessionGeneration && autoDiscoveryMotor == ownerAtQueue) discoverQueuedCandidate()
            }
        }
    }

    private fun discoverQueuedCandidate() {
        if (!endlessActive) return
        when (autoDiscoveryMotor) {
            AutoDiscoveryMotor.QEM -> { discoverQemCandidate(); return }
            AutoDiscoveryMotor.BASIC -> Unit
            AutoDiscoveryMotor.NONE -> return
        }
        if (endlessQueued != null || endlessDiscoveryJob?.isActive == true) return
        if (qemEngine.handoffPending) return
        val session = endlessSessionGeneration

        // Artist-only mode: after the catalogue is exhausted, replay the two original
        // seeds in order, then begin a fresh pass through that artist's catalogue.
        if (endlessArtistOnlyMode && endlessArtistReplayQueue.isNotEmpty()) {
            val replay = endlessArtistReplayQueue.removeFirst()
            endlessUsedUrls.add(replay.url)
            endlessUsedTrackKeys.add(endlessTrackKey(replay))
            val waiting = activeWaitingFreeDeck
            if (waiting != null) {
                activeWaitingFreeDeck = null
                loadEndlessTrackIntoDeck(waiting, replay)
                discoverQueuedCandidate()
            } else {
                endlessQueued = replay
            }
            return
        }

        val primaryQueries = buildEndlessQueries()
        endlessDiscoveryJob = lifecycleScope.launch {
            // Refill is time-critical. The previous implementation could walk dozens of NewPipe
            // queries sequentially (up to ~2 minutes), which looked like a dead Endless pipeline
            // and allowed the active song to finish before NEXT was prepared. Search in bounded
            // parallel rounds instead: one slow/bad query can never hold the deck hostage.
            suspend fun searchRound(queries: List<String>, maxQueries: Int, timeoutMs: Long): TrackRef? {
                if (queries.isEmpty()) return null
                val selected = queries.shuffled(Random.Default).take(maxQueries)
                val merged = coroutineScope {
                    selected.map { query ->
                        async(Dispatchers.IO) {
                            withTimeoutOrNull(timeoutMs) {
                                runCatching { searchRepo.search(query) }.getOrElse { emptyList() }
                            } ?: emptyList()
                        }
                    }.awaitAll().flatten()
                }
                if (!endlessActive || session != endlessSessionGeneration) return null
                return chooseEndlessCandidate(merged.distinctBy { endlessTrackKey(it) }.shuffled(Random.Default))
            }

            var candidate = searchRound(
                primaryQueries,
                maxQueries = 4,
                timeoutMs = 5_000L
            )

            // Broaden wording only; hard scene/genre/content gates stay untouched. One fallback
            // round also has a hard wall-clock ceiling instead of a long sequential marathon.
            if (candidate == null && !endlessArtistOnlyMode && endlessActive && session == endlessSessionGeneration) {
                candidate = searchRound(buildEndlessFallbackQueries(), maxQueries = 8, timeoutMs = 5_000L)
            }

            if (session != endlessSessionGeneration) return@launch
            endlessDiscoveryJob = null
            if (!endlessActive) return@launch

            if (candidate == null) {
                if (endlessArtistOnlyMode && endlessSeeds.size >= 2) {
                    if (!endlessArtistAllowLongTracks) {
                        endlessArtistAllowLongTracks = true
                        discoverQueuedCandidate()
                    } else {
                        endlessArtistAllowLongTracks = false
                        endlessUsedUrls.clear()
                        endlessUsedTrackKeys.clear()
                        endlessRecentArtists.clear()
                        endlessArtistReplayQueue.clear()
                        endlessArtistReplayQueue.addLast(endlessSeeds[0])
                        endlessArtistReplayQueue.addLast(endlessSeeds[1])
                        discoverQueuedCandidate()
                    }
                } else {
                    // AUTO is a persistent state, not a one-shot request. A rejected/exhausted
                    // batch only means "try another batch". Keep looping until a valid NEXT is
                    // READY/queued or the user turns Endless off.
                    delay(700)
                    if (endlessActive && session == endlessSessionGeneration &&
                        endlessQueued == null && endlessDiscoveryJob?.isActive != true) {
                        discoverQueuedCandidate()
                    }
                }
                return@launch
            }

            endlessDiscoveriesSinceAnchorExpansion++
            maybePromoteEndlessAnchor()
            endlessUsedUrls.add(candidate.url)
            endlessUsedTrackKeys.add(endlessTrackKey(candidate))
            val waiting = activeWaitingFreeDeck
            if (waiting != null) {
                activeWaitingFreeDeck = null
                loadEndlessTrackIntoDeck(waiting, candidate)
                // Keep one candidate ahead in the background whenever possible.
                discoverQueuedCandidate()
            } else {
                queueWaitingSlot2(candidate, session)
            }
        }
    }

    private fun buildEndlessQueries(): List<String> {
        val a = endlessSeeds.getOrNull(0) ?: return emptyList()
        // One-seed Endless is a first-class mode. Never return an empty primary query set just
        // because NEXT has not been discovered yet; use the live seed twice for query wording
        // while hard gates/cooldowns still prevent replaying the same URL/artist as immediate NEXT.
        val b = endlessSeeds.getOrNull(1) ?: a
        val artistA = endlessArtistKey(a)
        val artistB = endlessArtistKey(b)

        if (endlessArtistOnlyMode) {
            val artist = endlessArtistKey(endlessArtistOnlySeed ?: a).ifBlank { artistA }
            return listOf(
                "$artist official audio",
                "$artist official music video",
                "$artist songs"
            ).map { it.trim() }.filter { it.isNotBlank() }.distinct()
        }

        val genreAnchor = if (quickSessionStyleTerms.isNotBlank()) {
            quickSessionStyleTerms
        } else when (endlessGenreProfile) {
            EndlessGenreProfile.POP -> "pop pop rock"
            EndlessGenreProfile.POP_FOLK -> "pop folk folk"
            EndlessGenreProfile.FOLK -> "folk pop folk"
        }
        val sceneAnchor = sceneSearchAnchor(endlessSceneProfile)
        val quickAnchor = listOf(quickSessionAnchorTerms, effectiveSessionTempoTerms()).filter { it.isNotBlank() }.joinToString(" ")

        // Progressive widening: the first two discoveries are STRICTLY tied to the original
        // two songs. Only after two candidate discoveries may a successfully PLAYED in-lane
        // auto track become an additional anchor. Then we run another two discoveries, promote
        // one more confirmed track, and repeat. Region/genre themselves never widen.
        val promoted = endlessAnchorTracks.drop(2).takeLast(5).filterNot { anchor ->
            endlessPlayedArtistHistory.lastOrNull()?.let { isSameArtistFamily(it, anchor) } == true
        }.takeLast(3)
        val progressive = promoted.joinToString(" ") { t ->
            val artist = endlessArtistKey(t)
            val title = canonicalCompareText(t.title).take(80)
            "$artist $title"
        }
        val seedSongs = "${a.title} ${b.title}"

        return (listOf(
            "$seedSongs $progressive $sceneAnchor $genreAnchor $quickAnchor similar songs official",
            "$artistA $artistB $progressive $sceneAnchor $genreAnchor $quickAnchor related artists music",
            "music like $seedSongs $progressive $sceneAnchor $genreAnchor $quickAnchor"
        )).map { it.trim().replace(Regex("\\s+"), " ") }.filter { it.isNotBlank() }.distinct()
    }

    private fun buildEndlessFallbackQueries(): List<String> {
        val genreAnchor = if (quickSessionStyleTerms.isNotBlank()) {
            quickSessionStyleTerms
        } else when (endlessGenreProfile) {
            EndlessGenreProfile.POP -> "pop pop rock"
            EndlessGenreProfile.POP_FOLK -> "pop folk folk"
            EndlessGenreProfile.FOLK -> "folk pop folk"
        }
        val sceneAnchor = sceneSearchAnchor(endlessSceneProfile)
        val quickAnchor = listOf(quickSessionAnchorTerms, effectiveSessionTempoTerms()).filter { it.isNotBlank() }.joinToString(" ")

        // No seed names here on purpose. The hard guards still enforce the locked scene/genre,
        // seed-artist block, recent-artist cooldown, used-track block and content rules.
        // This only widens discovery when seed-heavy result pages keep returning unusable items.
        val localSceneTerms = when (endlessSceneProfile) {
            EndlessSceneProfile.EX_YU -> listOf("ex yu muzika", "balkan muzika", "regionalni hitovi")
            EndlessSceneProfile.ITALIAN -> listOf("musica italiana", "canzoni italiane", "cantanti italiani", "italian pop hits")
            EndlessSceneProfile.FRANCOPHONE -> listOf("chanson francaise", "pop francais", "artistes francophones")
            EndlessSceneProfile.HISPANIC -> listOf("musica en espanol", "pop latino", "artistas latinos")
            EndlessSceneProfile.LUSOPHONE -> listOf("musica portuguesa", "musica brasileira", "pop portugues")
            EndlessSceneProfile.DACH -> listOf("deutsche musik", "deutsch pop", "german pop")
            EndlessSceneProfile.GREEK -> listOf("greek music", "ellinika tragoudia")
            EndlessSceneProfile.TURKISH -> listOf("turkce muzik", "turkish pop")
            EndlessSceneProfile.ARABIC -> listOf("arabic music", "arab pop")
            EndlessSceneProfile.SOUTH_ASIAN -> listOf("hindi music", "bollywood songs", "urdu pop")
            EndlessSceneProfile.EAST_SLAVIC -> listOf("russian music", "ukrainian music", "east slavic pop")
            EndlessSceneProfile.KOREAN -> listOf("korean music", "k pop")
            EndlessSceneProfile.JAPANESE -> listOf("japanese music", "j pop")
            EndlessSceneProfile.ANGLO -> listOf("english pop", "uk us pop", "english rock")
            EndlessSceneProfile.GLOBAL -> listOf("popular music")
        }
        val queries = mutableListOf<String>().apply {
            add("$sceneAnchor $genreAnchor $quickAnchor official music")
            add("$sceneAnchor $genreAnchor $quickAnchor popular songs official")
            add("$sceneAnchor $genreAnchor $quickAnchor related artists music")
            add("$sceneAnchor $genreAnchor $quickAnchor hits music video")
            add("$sceneAnchor $genreAnchor $quickAnchor songs")
        }
        localSceneTerms.forEach { term ->
            queries += "$term $genreAnchor $quickAnchor official music"
            queries += "$term $genreAnchor $quickAnchor popular songs"
        }
        return queries.map { it.trim().replace(Regex("\\s+"), " ") }.filter { it.isNotBlank() }.distinct()
    }

    private fun chooseEndlessCandidate(items: List<TrackRef>): TrackRef? {
        val hardBlockedWords = listOf(
            "karaoke", "reaction", "tutorial", "full album", "playlist", "instrumental karaoke",
            "interview", "intervju", "podcast", "talk", "conversation", "gostovanje", "gost u",
            "emisija", "behind the scenes", "documentary", "dokumentar", "press conference", "press",
            "q&a", "q & a", "review", "recenzija", "priča", "prica", "razgovor",
            "radio interview", "tv interview", "radio emisija", "tv emisija", "dnevnik", "vesti", "vijesti",
            "news", "breaking", "reportaza", "reportaža", "podcast clip", "shorts interview"
        )
        val softPenaltyWords = listOf(
            "acoustic", "unplugged", "remix", "concert", "session",
            "sped up", "slowed", "nightcore", "extended", "edit", "remastered"
        )
        val artistOnlySeed = endlessArtistOnlySeed

        val candidates = items.mapIndexedNotNull { index, track ->
            val title = track.title.lowercase(Locale.getDefault())
            val artist = endlessArtistKey(track)
            val trackKey = endlessTrackKey(track)
            val correctArtistForArtistOnly = !endlessArtistOnlyMode ||
                (artistOnlySeed != null && isSameArtistFamily(artistOnlySeed, track))
            val seedArtistBlocked = !endlessArtistOnlyMode &&
                endlessNonSeedSelections < 5 &&
                isOriginalSeedArtist(track)
            val activeTrack = when {
                endlessDeckStateA == EndlessDeckState.PLAYING && playerA.mediaItemCount > 0 -> MixerStore.deckA
                endlessDeckStateB == EndlessDeckState.PLAYING && playerB.mediaItemCount > 0 -> MixerStore.deckB
                playerA.isPlaying -> MixerStore.deckA
                playerB.isPlaying -> MixerStore.deckB
                else -> null
            }
            // Auto engine may NEVER schedule the current artist as immediate NEXT.
            val consecutiveArtistBlocked = !endlessArtistOnlyMode && activeTrack?.let { isSameArtistFamily(it, track) } == true
            // One authoritative repeat gate for BASIC and QEM. No pool-size relaxation: if the
            // hard history blocks a candidate, discovery keeps searching instead of weakening it.
            val repeatEmergency = continuityRepeatEmergencyActive()
            val recentHistoryBlocked = persistentHardRepeatBlocked(track, bypassArtistBan = endlessArtistOnlyMode) && !repeatEmergency
            val durationAllowed = when {
                track.durationSeconds <= 0 -> true
                track.durationSeconds < 75 -> false
                endlessArtistOnlyMode && endlessArtistAllowLongTracks -> true
                else -> track.durationSeconds <= if (quickLongFormDuration) 1500 else 480
            }

            val uploaderText = track.uploader.lowercase(Locale.getDefault())
            val isLive = listOf(" live", "live ", "concert", "koncert", "unplugged").any { it in title }
            val isCover = listOf("cover", "tribute", "obrada").any { it in title }
            val looksOfficial = track.uploaderVerified || "official" in title || "official" in uploaderText || "vevo" in uploaderText || "topic" in uploaderText
            val narrativeNonSong = looksLikeNarrativeNonSong(track)
            val formatNonSong = looksLikeProgramOrCompilation(track)
            val wrongScene = !endlessArtistOnlyMode && violatesLockedScene(track)
            val wrongGenre = !endlessArtistOnlyMode && violatesLockedGenre(track)

            val passes = (repeatEmergency || track.url !in endlessUsedUrls) &&
                (repeatEmergency || trackKey !in endlessUsedTrackKeys) &&
                !recentHistoryBlocked &&
                correctArtistForArtistOnly &&
                !consecutiveArtistBlocked &&
                !seedArtistBlocked &&
                durationAllowed &&
                hardBlockedWords.none { it in title } &&
                !narrativeNonSong &&
                !formatNonSong &&
                !wrongScene &&
                !wrongGenre &&
                passesGlobalTitleTypeFilters(track)

            if (!passes) return@mapIndexedNotNull null

            // Ranking happens only AFTER every hard rule above has passed.
            // Search relevance still matters, but fame/popularity is intentionally flattened so the
            // engine does not live only at the top of the chart/canonical-result scale.
            var score = 1000 - index * 2
            softPenaltyWords.forEach { word -> if (word in title) score -= 140 }

            val cleanSongShape = listOf(" - ", " – ", " — ").any { sep ->
                val pos = track.title.indexOf(sep)
                pos >= 2 && pos < track.title.length - sep.length - 1
            }
            if (cleanSongShape) score += 70
            if ("official audio" in title) score += 110
            if ("official video" in title) score += 85
            if ("vevo" in uploaderText || "topic" in uploaderText) score += 80
            if (track.uploaderVerified) score += 90
            if (track.durationSeconds in 150..330) score += 35

            if (track.viewCount > 0L) {
                // Strong compression: popularity remains a mild tie-breaker, never the main reason
                // a candidate wins. sqrt(log10()) sharply narrows the gap between 100k and 100M.
                val popularity = kotlin.math.sqrt(
                    kotlin.math.log10(track.viewCount.toDouble().coerceAtLeast(1.0))
                )
                score += (popularity * 24.0).roundToInt()
                if (track.viewCount >= 1_000_000L) score += 6
                if (track.viewCount >= 10_000_000L) score += 5
                if (track.viewCount >= 100_000_000L) score += 4
            }

            // Cross-mix history is a POST-filter ranking penalty only. It never weakens region/style
            // hard gates. A song played in mix N is penalized in N+1..N+5 and fully restored in N+6.
            score -= persistentPlaybackPenalty(track)
            score to track
        }

        if (candidates.isEmpty()) return null

        // Hard gates + quality scoring define an acceptable quality lane; playback ORDER is random
        // inside that lane. This prevents identical filter requests from recreating a glued playlist.
        val ranked = candidates.sortedByDescending { it.first }
        val bestScore = ranked.first().first
        val qualityPool = ranked
            .filter { it.first >= bestScore - 320 }
            .take(24)
            .map { it.second }
        return qualityPool.randomOrNull(Random.Default) ?: ranked.first().second
    }

    private fun loadPersistentPlaybackHistory() = historyGuard.load()

    private fun recentSongKeys(): Set<String> = historyGuard.recentSongKeys()

    private fun recentArtistKeys(): Set<String> = historyGuard.recentArtistKeys()

    // Kept as an explicit lifecycle hook so call sites stay simple. Anti-repeat windows are based
    // on PLAYED TRACKS, not mix/session numbers, so starting a new mix never ages the history.
    private fun beginPersistentMix() = Unit

    private fun persistentHardRepeatBlocked(track: TrackRef, bypassArtistBan: Boolean = false): Boolean =
        historyGuard.isBlocked(
            songKey = endlessTrackKey(track),
            artistKeys = creditedArtistKeys(track),
            bypassArtistBan = bypassArtistBan
        )

    /**
     * 30-second continuity sanctuary. Repeat history stays HARD during normal discovery, but it
     * may never be the reason AUTO goes silent at the end of the ACTIVE track. This flag only
     * opens the repeat-history emergency lane when ACTIVE has <= 30 s left and the opposite
     * physical deck is still not READY_NEXT. Region/style/song-type/playability gates remain intact.
     */
    private fun continuityRepeatEmergencyActive(): Boolean {
        // Main-thread-only playback snapshot. Media3/ExoPlayer must never be touched by QEM
        // discovery workers. qemFindTracks() captures this once on Main and passes the plain
        // Boolean through the entire worker/ranking pipeline.
        if (!endlessActive || autoFadeJob?.isActive == true) return false
        val activeIsA = when {
            playerA.isPlaying && !playerB.isPlaying -> true
            playerB.isPlaying && !playerA.isPlaying -> false
            else -> return false
        }
        val active = if (activeIsA) playerA else playerB
        val next = if (activeIsA) playerB else playerA
        val remaining = remainingMs(active)
        return remaining in 1L..30_000L && !deckReadyForAuto(next)
    }

    private fun persistentPlaybackPenalty(track: TrackRef, referenceMix: Int = 0): Int = 0

    private fun persistActuallyPlayedTrack(track: TrackRef) =
        historyGuard.recordActuallyPlayed(endlessTrackKey(track), creditedArtistKeys(track))

    private fun canonicalCompareText(text: String): String = historyGuard.canonicalCompareText(text)

    private fun normalizeArtistText(text: String): String = historyGuard.normalizeArtistText(text)


    private fun titleSides(track: TrackRef): Set<String> {
        val separators = listOf(" - ", " – ", " — ", " | ")
        for (sep in separators) {
            val i = track.title.indexOf(sep)
            if (i > 0 && i + sep.length < track.title.length) {
                return setOf(
                    normalizeArtistText(track.title.substring(0, i)),
                    normalizeArtistText(track.title.substring(i + sep.length))
                ).filter { it.length >= 3 }.toSet()
            }
        }
        return emptySet()
    }

    private fun artistAliases(track: TrackRef): Set<String> {
        // Artist identity must never include the song-title side of "Artist - Song".
        return primaryArtistAliases(track).filter { alias ->
            alias.split(' ').any { it.length >= 3 }
        }.toSet()
    }

    private fun titleArtistPrefix(track: TrackRef): String {
        val separators = listOf(" - ", " – ", " — ", " | ")
        for (sep in separators) {
            val i = track.title.indexOf(sep)
            if (i > 0) return normalizeArtistText(track.title.substring(0, i))
        }
        return ""
    }

    private fun sameArtistConfidence(a: TrackRef, b: TrackRef): Boolean {
        // If both titles expose an "Artist - Song" prefix, trust that over uploader channels.
        // Two different performers on the same label/channel must never create artist-only mode.
        val prefixA = titleArtistPrefix(a)
        val prefixB = titleArtistPrefix(b)
        if (prefixA.length >= 3 && prefixB.length >= 3) {
            return prefixA == prefixB || prefixA.contains(prefixB) || prefixB.contains(prefixA)
        }

        val uploaderA = normalizeArtistText(a.uploader)
        val uploaderB = normalizeArtistText(b.uploader)
        val genericUploaderWords = listOf("records", "recordings", "label", "music", "channel", "topic", "official")
        val uploaderLooksGeneric = genericUploaderWords.any { it in uploaderA || it in uploaderB }
        if (!uploaderLooksGeneric && uploaderA.length >= 3 && uploaderB.length >= 3 && uploaderA == uploaderB) return true

        val aliasesA = artistAliases(a)
        val aliasesB = artistAliases(b)
        return aliasesA.any { aa ->
            aliasesB.any { bb ->
                aa.length >= 4 && bb.length >= 4 && (aa == bb || aa.contains(bb) || bb.contains(aa))
            }
        }
    }

    private fun isSameArtistFamily(seed: TrackRef, candidate: TrackRef): Boolean {
        val seedAliases = artistAliases(seed)
        val candidateAliases = artistAliases(candidate)
        if (seedAliases.any { sa -> candidateAliases.any { ca ->
                sa.length >= 4 && ca.length >= 4 && (sa == ca || sa.contains(ca) || ca.contains(sa))
            } }) return true

        val stop = setOf(
            "official", "music", "video", "audio", "lyrics", "lyric", "records", "recordings",
            "topic", "channel", "band", "grupa", "the", "and", "feat", "ft"
        )
        fun words(text: String): Set<String> = canonicalCompareText(text)
            .split(' ')
            .map { it.trim() }
            .filter { it.length >= 4 && it !in stop }
            .toSet()

        val seedArtistWords = words(endlessArtistKey(seed))
        if (seedArtistWords.isEmpty()) return false
        val candidateWords = words(endlessArtistKey(candidate)) + words(candidate.uploader) + words(candidate.title)
        return seedArtistWords.any { it in candidateWords }
    }

    private fun splitArtistCredit(raw: String): Set<String> = historyGuard.splitArtistCredit(raw)

    private fun creditedArtistKeys(track: TrackRef): Set<String> = historyGuard.creditedArtistKeys(track)

    private fun primaryArtistAliases(track: TrackRef): Set<String> = creditedArtistKeys(track)

    private fun isOriginalSeedArtist(candidate: TrackRef): Boolean {
        val candidateTitle = canonicalCompareText(candidate.title)
        val candidateAliases = primaryArtistAliases(candidate)
        return endlessSeeds.take(2).any { seed ->
            val seedAliases = primaryArtistAliases(seed) + endlessArtistKey(seed)
            seedAliases.filter { it.length >= 3 }.any { seedAlias ->
                candidateAliases.any { ca ->
                    ca == seedAlias || ca.contains(seedAlias) || seedAlias.contains(ca)
                } || candidateTitle == seedAlias || candidateTitle.startsWith("$seedAlias ")
            }
        }
    }

    private fun markEndlessAutoPlayed(track: TrackRef) {
        if (!endlessActive) return
        rememberActuallyPlayedArtist(track)
        if (endlessSeeds.take(2).any { seed -> seed.url == track.url }) return
        if (endlessPlayedAutoUrls.add(track.url)) {
            endlessNonSeedSelections++
            if (track.url in endlessManualUrls) return
            // Only a track that really played AND still passes the locked region/genre gates may
            // influence future discovery. A stray wrong-region result can never contaminate anchors.
            if (hasPositiveLockedSceneEvidence(track) && !violatesLockedGenre(track) &&
                endlessPendingAnchorTracks.none { it.url == track.url } &&
                endlessAnchorTracks.none { it.url == track.url }) {
                endlessPendingAnchorTracks.addLast(track)
            }
            maybePromoteEndlessAnchor()
        }
    }


    private fun rememberActuallyPlayedTrack(track: TrackRef) {
        if (!endlessActive) return

        // Ignore duplicate callbacks for the same physical item; only a genuine audible play
        // advances the 20-song / 15-artist windows.
        val last = endlessPlayedArtistHistory.lastOrNull()
        if (last?.url != track.url) {
            endlessPlayedArtistHistory.add(track)
            while (endlessPlayedArtistHistory.size > playedHistoryRetention) endlessPlayedArtistHistory.removeAt(0)
            persistActuallyPlayedTrack(track)
        }

        if (quickSessionActive) {
            creditedArtistKeys(track).forEach { artistId ->
                qemEngine.recentArtistIds.remove(artistId)
                qemEngine.recentArtistIds.addLast(artistId)
                while (qemEngine.recentArtistIds.size > playedArtistHardWindow) qemEngine.recentArtistIds.removeFirst()
            }
        }
    }

    private fun rememberActuallyPlayedArtist(track: TrackRef) {
        // Compatibility for existing transition callbacks; the unified function de-duplicates
        // callbacks for the same physical track and updates both song and artist histories.
        rememberActuallyPlayedTrack(track)
    }

    private fun maybePromoteEndlessAnchor() {
        if (endlessDiscoveriesSinceAnchorExpansion < 2) return
        val next = if (endlessPendingAnchorTracks.isEmpty()) return else endlessPendingAnchorTracks.removeFirst()
        if (hasPositiveLockedSceneEvidence(next) && !violatesLockedGenre(next)) {
            endlessAnchorTracks.add(next)
            while (endlessAnchorTracks.size > 7) endlessAnchorTracks.removeAt(2)
            endlessDiscoveriesSinceAnchorExpansion = 0
        }
    }

    private fun sceneSearchAnchor(scene: EndlessSceneProfile): String = when (scene) {
        EndlessSceneProfile.EX_YU -> "ex yu balkan"
        EndlessSceneProfile.ANGLO -> "english"
        EndlessSceneProfile.FRANCOPHONE -> "francophone french"
        EndlessSceneProfile.HISPANIC -> "spanish latin"
        EndlessSceneProfile.LUSOPHONE -> "portuguese brazil portugal"
        EndlessSceneProfile.DACH -> "german deutsch"
        EndlessSceneProfile.ITALIAN -> "italian italiano"
        EndlessSceneProfile.GREEK -> "greek"
        EndlessSceneProfile.TURKISH -> "turkish"
        EndlessSceneProfile.ARABIC -> "arabic"
        EndlessSceneProfile.SOUTH_ASIAN -> "hindi urdu indian"
        EndlessSceneProfile.EAST_SLAVIC -> "russian ukrainian"
        EndlessSceneProfile.KOREAN -> "korean"
        EndlessSceneProfile.JAPANESE -> "japanese"
        EndlessSceneProfile.GLOBAL -> ""
    }

    private fun classifyEndlessScene(a: TrackRef, b: TrackRef): EndlessSceneProfile {
        val sa = classifyTrackScene(a)
        val sb = classifyTrackScene(b)
        return when {
            sa == sb && sa != EndlessSceneProfile.GLOBAL -> sa
            sa == EndlessSceneProfile.GLOBAL -> sb
            sb == EndlessSceneProfile.GLOBAL -> sa
            else -> EndlessSceneProfile.GLOBAL
        }
    }

    private fun classifyTrackScene(track: TrackRef): EndlessSceneProfile {
        val raw = "${track.title} ${track.uploader}".lowercase(Locale.ROOT)
        val text = canonicalCompareText(raw)

        // Strong regional metadata/artist signals. This is intentionally used before the generic
        // lexical classifier so common EX-YU seeds with short titles still lock the correct basin.
        val strongSceneSignals = listOf(
            EndlessSceneProfile.EX_YU to listOf(
                "dino merlin", "dzenan loncarevic", "zeljko joksimovic", "tony cetinski", "lexington",
                "miligram", "colonia", "hari mata hari", "crvena jabuka", "bijelo dugme", "parni valjak",
                "zdravko colic", "severina", "gibonni", "petar graso", "aco pejovic", "sasa matic",
                "aleksandra prijovic", "lepa brena", "ceca", "barbara bobak", "andrijana cekic",
                "magazin", "novi fosili", "prljavo kazaliste", "plavi orkestar", "zabranjeno pusenje",
                "divlje jagode", "atomsko skloniste", "riblja corba", "bajaga", "bajaga i instruktori",
                "galija", "kerber", "yu grupa", "smak", "film", "azra", "haustor", "elektricni orgazam",
                "idoli", "piloti", "van gogh", "neverne bebe", "negative", "partibrejkers", "ekv",
                "ekatarina velika", "indexi", "ambasadori", "bolero", "regina", "valentino", "vatra",
                "silente", "hladno pivo", "psihomodo pop", "leteci odred", "daleka obala", "oliver dragojevic",
                "massimo savic", "vanna", "josipa lisac", "nina badric", "jelena rozga", "danijela martinovic",
                "tajci", "vesna pisarovic", "toni cetinski", "zeljko bebеk", "zeljko bebek", "aleksandra radovic",
                "vlado georgiev", "sergej cetkovic", "knez", "miladin sobic", "ramba amadeus", "who see",
                "grand production", "croatia records", "idjvideos", "city records", "hayat production",
                "pgp rts", "pgp rtb", "jugoton", "diskoton", "menart", "aquamarius", "fm jam"
            ),
            EndlessSceneProfile.ITALIAN to listOf(
                "eros ramazzotti", "toto cutugno", "laura pausini", "zucchero", "nek", "tiziano ferro",
                "gianna nannini", "umberto tozzi", "adriano celentano", "al bano", "romina power",
                "ricchi e poveri", "raffaella carra", "marco mengoni", "mahmood", "annalisa", "giorgia",
                "elisa", "jovanotti", "cesare cremonini", "biagio antonacci", "lucio dalla", "mina",
                "matia bazar", "pooh", "the kolors", "elodie"
            ),
            EndlessSceneProfile.ANGLO to listOf(
                "bon jovi", "the calling", "coldplay", "blur", "oasis", "u2", "queen", "elton john",
                "ed sheeran", "dua lipa", "adele", "taylor swift", "bruno mars", "maroon 5", "the weeknd",
                "sade", "sting", "norah jones", "michael buble", "george michael", "phil collins",
                "fleetwood mac", "simply red", "jamiroquai", "bee gees", "robbie williams", "seal",
                "stevie wonder", "lionel richie", "whitney houston", "billy joel", "hall and oates"
            ),
            EndlessSceneProfile.FRANCOPHONE to listOf(
                "stromae", "indila", "celine dion", "mylene farmer", "edith piaf", "joe dassin",
                "francis cabrel", "zaz", "kendji girac", "christophe mae"
            ),
            EndlessSceneProfile.HISPANIC to listOf(
                "shakira", "enrique iglesias", "luis miguel", "alejandro sanz", "maluma", "bad bunny",
                "karol g", "daddy yankee", "rosalia", "juan luis guerra", "juanes", "carlos vives",
                "marc anthony", "ricky martin", "chayanne", "mana", "ricardo arjona", "camilo",
                "sebastian yatra", "luis fonsi", "gloria estefan", "santana"
            ),
            EndlessSceneProfile.LUSOPHONE to listOf(
                "roberto carlos", "mariza", "ana moura", "ivete sangalo", "jorge e mateus",
                "gusttavo lima", "marilia mendonca", "caetano veloso", "gilberto gil"
            ),
            EndlessSceneProfile.DACH to listOf(
                "herbert gronemeyer", "nena", "udo lindenberg", "helene fischer", "sarah connor",
                "mark forster", "peter maffay", "rammstein"
            ),
            EndlessSceneProfile.TURKISH to listOf(
                "tarkan", "sezen aksu", "mustafa sandal", "sertab erener", "hadise", "kenan dogulu"
            ),
            EndlessSceneProfile.GREEK to listOf(
                "anna vissi", "sakis rouvas", "despina vandi", "nikos vertis", "antonis remos"
            ),
            EndlessSceneProfile.ARABIC to listOf(
                "amr diab", "nancy ajram", "elissa", "ragheb alama", "kadim al sahir", "fairuz"
            ),
            EndlessSceneProfile.SOUTH_ASIAN to listOf(
                "arijit singh", "shreya ghoshal", "sonu nigam", "atif aslam", "neha kakkar", "badshah"
            ),
            EndlessSceneProfile.EAST_SLAVIC to listOf(
                "alla pugacheva", "dima bilan", "sergey lazarev", "ani lorak", "loboda", "monatik"
            ),
            EndlessSceneProfile.KOREAN to listOf(
                "bts", "blackpink", "twice", "exo", "iu", "newjeans", "stray kids"
            ),
            EndlessSceneProfile.JAPANESE to listOf(
                "hikaru utada", "ayumi hamasaki", "yoasobi", "kenshi yonezu", "arashi", "one ok rock"
            )
        )
        strongSceneSignals.firstOrNull { (_, signals) -> signals.any { it in text } }?.let { return it.first }
        if (Regex("[đć]").containsMatchIn(raw)) return EndlessSceneProfile.EX_YU

        fun score(words: List<String>): Int = words.count { w ->
            Regex("(^|\\s)${Regex.escape(w)}(\\s|$)").containsMatchIn(text)
        }

        // Script is a very strong signal and avoids trying to maintain a country database.
        if (Regex("[\\u3040-\\u30ff\\u31f0-\\u31ff]").containsMatchIn(raw)) return EndlessSceneProfile.JAPANESE
        if (Regex("[\\uac00-\\ud7af]").containsMatchIn(raw)) return EndlessSceneProfile.KOREAN
        if (Regex("[\\u0600-\\u06ff]").containsMatchIn(raw)) return EndlessSceneProfile.ARABIC
        if (Regex("[\\u0370-\\u03ff]").containsMatchIn(raw)) return EndlessSceneProfile.GREEK
        if (Regex("[\\u0900-\\u097f]").containsMatchIn(raw)) return EndlessSceneProfile.SOUTH_ASIAN

        val dictionaries = listOf(
            EndlessSceneProfile.EX_YU to listOf(
                "miligram", "bulevari", "ljubav", "srce", "sreca", "zivot", "noc", "moja", "moje", "moj",
                "tvoja", "tvoje", "tvoj", "dodji", "dodi", "pjesma", "pesma", "pjeva", "peva", "kafana",
                "samo", "tebe", "meni", "zelim", "volim", "nikad", "zauvijek", "zauvek", "balkan", "ex yu"
            ),
            EndlessSceneProfile.FRANCOPHONE to listOf(
                "amour", "chanson", "coeur", "avec", "pour", "sans", "toujours", "jamais", "mon", "ma", "mes", "toi", "moi", "dans", "une", "des"
            ),
            EndlessSceneProfile.HISPANIC to listOf(
                "amor", "corazon", "contigo", "quiero", "vida", "noche", "beso", "besame", "siempre", "nunca", "para", "conmigo", "cancion", "latino"
            ),
            EndlessSceneProfile.LUSOPHONE to listOf(
                "amor", "coracao", "voce", "saudade", "beijo", "noite", "vida", "meu", "minha", "brasil", "portugal", "sertanejo"
            ),
            EndlessSceneProfile.DACH to listOf(
                "liebe", "herz", "nacht", "leben", "immer", "niemals", "mein", "meine", "dein", "deine", "deutsch", "schlager"
            ),
            EndlessSceneProfile.ITALIAN to listOf(
                "amore", "cuore", "vita", "notte", "sempre", "mai", "mio", "mia", "tuo", "tua", "italiano", "canzone"
            ),
            EndlessSceneProfile.TURKISH to listOf(
                "ask", "aşk", "kalp", "gece", "hayat", "seni", "benim", "senin", "turk", "turkish"
            ),
            EndlessSceneProfile.EAST_SLAVIC to listOf(
                "любовь", "сердце", "песня", "ночь", "жизнь", "моя", "тебя", "россия", "украина", "russian", "ukrainian"
            ),
            EndlessSceneProfile.ANGLO to listOf(
                "girls", "boys", "love", "heart", "night", "baby", "forever", "never", "you", "your", "english", "uk", "british"
            )
        )

        var best = EndlessSceneProfile.GLOBAL
        var bestScore = 0
        for ((scene, words) in dictionaries) {
            val s = score(words)
            if (s > bestScore) {
                bestScore = s
                best = scene
            }
        }
        // Require two lexical hits so a single universal word such as "amor" cannot lock a scene.
        return if (bestScore >= 2) best else EndlessSceneProfile.GLOBAL
    }

    private fun hasPositiveLockedSceneEvidence(track: TrackRef): Boolean {
        if (endlessSceneProfile == EndlessSceneProfile.GLOBAL) return true
        val candidateScene = classifyTrackScene(track)
        if (candidateScene == endlessSceneProfile) return true
        if (candidateScene != EndlessSceneProfile.GLOBAL) return false

        // REGION IS CANON: fallback may broaden artists, never the language/scene basin.
        // An exact/family artist match to an already-confirmed in-lane anchor is valid positive
        // evidence; otherwise unknown metadata is rejected rather than guessed into the session.
        if (endlessAnchorTracks.any { isSameArtistFamily(it, track) }) return true

        val raw = "${track.title} ${track.uploader}".lowercase(Locale.ROOT)
        val text = canonicalCompareText(raw)
        val sceneLabels = when (endlessSceneProfile) {
            EndlessSceneProfile.ITALIAN -> listOf(
                "italia", "italian", "italiano", "italiana", "musica italiana", "canzone italiana",
                "warner music italy", "sony music italy", "universal music italia", "rai", "sanremo"
            )
            EndlessSceneProfile.FRANCOPHONE -> listOf("france", "francais", "francaise", "chanson francaise", "francophone")
            EndlessSceneProfile.HISPANIC -> listOf("latin", "latino", "latina", "espanol", "mexico", "argentina", "colombia", "spain")
            EndlessSceneProfile.LUSOPHONE -> listOf("brasil", "brazil", "portugal", "portugues", "portuguese")
            EndlessSceneProfile.DACH -> listOf("deutsch", "deutsche", "germany", "austria", "schweiz", "switzerland")
            EndlessSceneProfile.GREEK -> listOf("greek", "greece", "ellinika")
            EndlessSceneProfile.TURKISH -> listOf("turkish", "turkiye", "turkce")
            EndlessSceneProfile.ARABIC -> listOf("arabic", "arab", "middle east")
            EndlessSceneProfile.SOUTH_ASIAN -> listOf("hindi", "urdu", "bollywood", "india", "pakistan")
            EndlessSceneProfile.EAST_SLAVIC -> listOf("russian", "ukrainian", "russia", "ukraine")
            EndlessSceneProfile.KOREAN -> listOf("korean", "korea", "k-pop", "kpop")
            EndlessSceneProfile.JAPANESE -> listOf("japanese", "japan", "j-pop", "jpop")
            EndlessSceneProfile.ANGLO -> listOf("uk", "british", "usa", "american", "english")
            else -> emptyList()
        }
        if (sceneLabels.any { it in text }) return true

        if (endlessSceneProfile == EndlessSceneProfile.EX_YU) {
            if (Regex("[čćžšđ]").containsMatchIn(raw)) return true
            val regionalLabels = listOf(
                "croatia records", "grand production", "grand online", "idjvideos", "idj tunes",
                "city records", "hayat production", "bn music", "bn televizija", "pink music",
                "pgp rts", "jugoton", "diskoton", "sarajevo", "beograd", "belgrade", "zagreb",
                "podgorica", "split", "novi sad", "balkan", "ex yu"
            )
            if (regionalLabels.any { it in text }) return true
        }
        return false
    }

    private fun violatesLockedScene(track: TrackRef): Boolean = !hasPositiveLockedSceneEvidence(track)

    private fun classifyEndlessGenre(a: TrackRef, b: TrackRef): EndlessGenreProfile {
        val text = canonicalCompareText("${a.title} ${a.uploader} ${b.title} ${b.uploader}")
        val popFolkSignals = listOf(
            "pop folk", "folk pop", "popfolk", "cajka", "cajke", "turbofolk", "turbo folk",
            "miligram", "aco pejovic", "sasa matic", "tanja savic", "aleksandra prijovic", "ceca",
            "dragana mirkovic", "seka aleksic", "dara bubamara", "ana bekuta", "lepa brena"
        )
        val folkSignals = listOf(
            "folk", "narodna", "narodne", "narodni", "izvorna", "izvorne", "sevdah", "sevdalinka",
            "tambura", "tamburica", "kolo", "gusle", "ganga", "etno", "kafana", "kafanska"
        )
        return when {
            popFolkSignals.any { it in text } -> EndlessGenreProfile.POP_FOLK
            folkSignals.any { it in text } -> EndlessGenreProfile.FOLK
            else -> EndlessGenreProfile.POP
        }
    }

    private fun looksLikeNarrativeNonSong(track: TrackRef): Boolean {
        val text = canonicalCompareText(track.title)
        val narrativePhrases = listOf(
            "otkrio", "otkrila", "otkriva", "rekao", "rekla", "kaze", "kazao", "kazala",
            "govori", "govorio", "govorila", "pricao", "pricala", "prica o", "ispricao", "ispricala",
            "objasnio", "objasnila", "priznao", "priznala", "progovorio", "progovorila",
            "reveals", "revealed", "says", "said", "talks about", "speaks about", "explains",
            "admits", "confesses", "interview", "intervju", "gostovanje", "razgovor"
        )
        return narrativePhrases.any { phrase ->
            Regex("(^|\\s)${Regex.escape(phrase)}(\\s|$)").containsMatchIn(text)
        }
    }

    private fun looksLikeProgramOrCompilation(track: TrackRef): Boolean {
        // Global content-format guard: Endless Mix wants ONE SONG, not a quiz/show/playlist/mix package.
        // Canonical matching makes this work across accents (e.g. MUZIČKI -> muzicki).
        val text = canonicalCompareText("${track.title} ${track.uploader}")
        val exactFormats = listOf(
            "muzicki kviz", "music quiz", "quiz show", "kviz",
            "kompilacija", "compilation", "playlist", "plejlista",
            "top hits", "greatest hits", "best of", "hitovi", "najveci hitovi",
            "radio show", "radio emisija", "tv show", "tv emisija", "countdown",
            "non stop", "nonstop", "continuous mix", "full mix", "dj mix",
            "megamixt", "megamix", "medley", "mix compilation"
        )
        if (exactFormats.any { phrase ->
                Regex("(^|\\s)${Regex.escape(phrase)}(\\s|$)").containsMatchIn(text)
            }) return true

        // Numbered/best-of packages are especially common in QUICK searches and must never
        // masquerade as one long song (e.g. "Top 50 Ex Yu Rock Songs" or
        // "50 najboljih Ex-YU rock pesama").
        val numberedPackage = listOf(
            Regex("\\btop\\s+\\d{1,3}\\b"),
            Regex("\\b\\d{1,3}\\s+(najboljih|najbolje|najvecih|best)\\b"),
            Regex("\\b(best|top)\\s+(songs|pesama|pjesama|hitova|tracks)\\b"),
            Regex("\\b\\d{1,3}\\s+(songs|pesama|pjesama|hitova|tracks)\\b")
        ).any { it.containsMatchIn(text) }
        if (numberedPackage) return true

        // Generic MIX is ambiguous (a real song can be a remix), so reject it only when the
        // surrounding title clearly describes a package/era/collection rather than Artist - Song.
        val hasArtistSongShape = listOf(" - ", " – ", " — ").any { sep ->
            val i = track.title.indexOf(sep)
            i >= 2 && i < track.title.length - sep.length - 1
        }
        val packageSignals = listOf(
            "80", "90", "2000", "2020", "2021", "2022", "2023", "2024", "2025", "2026",
            "ex yu", "balkan mix", "summer mix", "party mix", "dance mix", "rock mix",
            "pop mix", "folk mix", "hour mix", "1 hour", "2 hour", "mix songs", "mix pesama", "mix pjesama"
        )
        return !hasArtistSongShape && " mix" in " $text " && packageSignals.any { it in text }
    }

    private fun violatesLockedGenre(track: TrackRef): Boolean {
        val text = canonicalCompareText("${track.title} ${track.uploader}")
        val folkLean = listOf(
            "folk", "narodna", "narodne", "narodni", "izvorna", "izvorne", "sevdah", "sevdalinka",
            "tambura", "tamburica", "gusle", "ganga", "kafana", "kafanska", "turbofolk", "turbo folk",
            "cajka", "cajke",
            // POP / POP-ROCK must not silently drift into folk just because a normal song title
            // contains no genre word. These are strong artist/uploader signals, not ranking hints.
            "aco pejovic", "sasa matic", "tanja savic", "aleksandra prijovic", "ceca",
            "dragana mirkovic", "seka aleksic", "dara bubamara", "ana bekuta", "lepa brena",
            "barbara bobak", "andrijana cekic", "mile kitic", "sinan sakic", "saban saulic",
            "halid beslic", "halid muslimovic", "haris dzinovic", "jana todorovic", "rasta folk"
        )
        val nationalistOrWar = listOf(
            "patriotska", "patriotske", "patriotic", "rodoljubiva", "rodoljubive", "rodoljubna",
            "nacionalisticka", "nacionalisticke", "nationalist", "nationalistic",
            "cetnik", "cetnici", "cetnicka", "ustasa", "ustase", "ustaska", "ratna pjesma", "ratne pjesme",
            "vojna pjesma", "vojne pjesme", "mars na", "bojna pjesma"
        )
        return when (endlessGenreProfile) {
            EndlessGenreProfile.POP -> folkLean.any { it in text } || nationalistOrWar.any { it in text }
            EndlessGenreProfile.POP_FOLK -> false // Friendly with FOLK by design.
            EndlessGenreProfile.FOLK -> false // Friendly with POP/FOLK by design.
        }
    }

    private fun rememberEndlessArtist(track: TrackRef) {
        val key = endlessArtistKey(track)
        if (key.isBlank()) return
        endlessRecentArtists.remove(key)
        endlessRecentArtists.add(key)
        while (endlessRecentArtists.size > 5) endlessRecentArtists.removeAt(0)
    }

    private fun passesGlobalTitleTypeFilters(track: TrackRef): Boolean {
        val title = canonicalCompareText(track.title)
        if (allowLive && !Regex("\\blive\\b").containsMatchIn(title)) return false
        if (allowCover && !Regex("\\bcover\\b").containsMatchIn(title)) return false
        if (onlyOfficial && !Regex("\\bofficial\\b").containsMatchIn(title)) return false
        return true
    }

    private fun endlessArtistKey(track: TrackRef): String {
        // Prefer the artist prefix from common "Artist - Song" titles. Comparison keys
        // are always Unicode-canonical so Ž/Z, accents and punctuation cannot bypass blocks.
        val separators = listOf(" - ", " – ", " — ", " | ")
        val titleArtist = separators
            .mapNotNull { sep ->
                val index = track.title.indexOf(sep)
                if (index > 0) track.title.substring(0, index) else null
            }
            .minByOrNull { it.length }
            .orEmpty()
        val normalizedTitleArtist = normalizeArtistText(titleArtist)
        if (normalizedTitleArtist.length >= 2) return normalizedTitleArtist

        return normalizeArtistText(track.uploader)
    }

    private fun endlessTrackKey(track: TrackRef): String {
        val separators = listOf(" - ", " – ", " — ", " | ")
        var songPart = track.title
        val uploader = normalizeArtistText(track.uploader)
        for (sep in separators) {
            val i = track.title.indexOf(sep)
            if (i > 0 && i + sep.length < track.title.length) {
                val leftRaw = track.title.substring(0, i)
                val rightRaw = track.title.substring(i + sep.length)
                val left = normalizeArtistText(leftRaw)
                val right = normalizeArtistText(rightRaw)
                songPart = when {
                    uploader.length >= 3 && (uploader.contains(left) || left.contains(uploader)) -> rightRaw
                    uploader.length >= 3 && (uploader.contains(right) || right.contains(uploader)) -> leftRaw
                    else -> rightRaw
                }
                break
            }
        }
        return songPart
            .lowercase(Locale.getDefault())
            .replace(Regex("\\([^)]*\\)|\\[[^]]*]"), " ")
            .replace(
                Regex("\\b(official|video|audio|lyrics|lyric|hd|hq|remastered|remaster|live|version|acoustic|unplugged|remix|mix|cover|concert|session|extended|edit|radio|sped|slowed|nightcore)\\b"),
                " "
            )
            .replace(Regex("\\b(19|20)\\d{2}\\b"), " ")
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .trim()
    }

    private fun updateEndlessFilterButtons() {
        fun style(button: Button, on: Boolean, label: String) {
            button.backgroundTintList = null
            button.setBackgroundResource(if (on) R.drawable.lux_worn_gold_button else R.drawable.lux_worn_gunmetal_button)
            button.setTextColor(ContextCompat.getColor(this, if (on) R.color.black else R.color.lux_silver))
            button.elevation = dp(4).toFloat()
            button.text = "$label ${if (on) "ON" else "OFF"}"
            button.isEnabled = !controlsLocked
        }
        style(binding.filterLive, allowLive, "LIVE")
        style(binding.filterCover, allowCover, "COVER")
        style(binding.filterOfficial, onlyOfficial, "OFFICIAL")
        style(binding.quickFilterLive, allowLive, "LIVE")
        style(binding.quickFilterCover, allowCover, "COVER")
        style(binding.quickFilterOfficial, onlyOfficial, "OFFICIAL")
        updateTempoButtons()
    }

    private fun updateCrossfadeButton() {
        if (!::binding.isInitialized) return
        binding.crossfadeMode.text = if (crossfadeEnabled) "CROSSFADE ON" else "CROSSFADE OFF"
        binding.crossfadeMode.backgroundTintList = null
        binding.crossfadeMode.setBackgroundResource(if (crossfadeEnabled) R.drawable.lux_gold_button else R.drawable.lux_black_button)
        binding.crossfadeMode.setTextColor(ContextCompat.getColor(this, if (crossfadeEnabled) R.color.black else R.color.lux_silver))
        binding.crossfadeMode.elevation = dp(4).toFloat()
        binding.crossfadeMode.isEnabled = true
        binding.lockedCrossfadeMode.text = binding.crossfadeMode.text
        binding.lockedCrossfadeMode.backgroundTintList = null
        binding.lockedCrossfadeMode.setBackgroundResource(if (crossfadeEnabled) R.drawable.lux_gold_button else R.drawable.lux_black_button)
        binding.lockedCrossfadeMode.setTextColor(ContextCompat.getColor(this, if (crossfadeEnabled) R.color.black else R.color.lux_silver))
        binding.lockedCrossfadeMode.isEnabled = true
        binding.quickCrossfadeMode.text = binding.crossfadeMode.text
        binding.quickCrossfadeMode.backgroundTintList = null
        binding.quickCrossfadeMode.setBackgroundResource(if (crossfadeEnabled) R.drawable.lux_gold_button else R.drawable.lux_black_button)
        binding.quickCrossfadeMode.setTextColor(ContextCompat.getColor(this, if (crossfadeEnabled) R.color.black else R.color.lux_silver))
        binding.quickCrossfadeMode.isEnabled = true
    }

    private fun requestEndlessVoiceSearch() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            launchSpeechRecognizer()
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun setupAudioFocusProtection() {
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setWillPauseWhenDucked(false)
            .setOnAudioFocusChangeListener { change ->
                when (change) {
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                        masterDuck = 0.35f
                        applyVolumes()
                    }
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                        resumeAAfterFocus = playerA.isPlaying
                        resumeBAfterFocus = playerB.isPlaying
                        masterDuck = 0.12f
                        applyVolumes()
                    }
                    AudioManager.AUDIOFOCUS_GAIN -> {
                        masterDuck = 1f
                        applyVolumes()
                        if (resumeAAfterFocus && !playerA.isPlaying && playerA.playbackState == Player.STATE_READY) playerA.play()
                        if (resumeBAfterFocus && !playerB.isPlaying && playerB.playbackState == Player.STATE_READY) playerB.play()
                        resumeAAfterFocus = false
                        resumeBAfterFocus = false
                    }
                    AudioManager.AUDIOFOCUS_LOSS -> {
                        resumeAAfterFocus = playerA.isPlaying
                        resumeBAfterFocus = playerB.isPlaying
                        masterDuck = 0.12f
                        applyVolumes()
                    }
                }
            }
            .build()
        audioManager.requestAudioFocus(audioFocusRequest)
    }

    private fun animateLockHardware(afterMidpoint: () -> Unit) {
        binding.lockIcon.animate().cancel()
        binding.mixLock.animate().cancel()
        binding.mixLock.animate()
            .translationY(dp(3).toFloat())
            .scaleX(0.985f)
            .scaleY(0.96f)
            .setDuration(70L)
            .withEndAction {
                afterMidpoint()
                binding.lockIcon.rotation = -28f
                binding.lockIcon.scaleX = 0.82f
                binding.lockIcon.scaleY = 0.82f
                binding.lockIcon.animate().rotation(0f).scaleX(1f).scaleY(1f).setDuration(150L).start()
                binding.mixLock.animate().translationY(0f).scaleX(1f).scaleY(1f).setDuration(120L).start()
            }.start()
    }

    private fun armVideoScreensaver() {
        // Manual VIDEO mode only. Automatic screensaver/countdown intentionally retired.
        videoScreensaverJob?.cancel()
        videoScreensaverJob = null
    }

    private fun activeScreensaverTrack(): Pair<TrackRef, Long>? {
        // During an A/B crossfade BOTH physical players are intentionally playing. The screensaver
        // must keep showing the established outgoing ACTIVE video until the transition has actually
        // completed, then switch once to the new owner. Do not let playerA-first ordering randomly
        // choose the visual owner during a mix.
        endlessActiveOwnerIsA?.let { ownerIsA ->
            val ownerTrack = if (ownerIsA) MixerStore.deckA else MixerStore.deckB
            val ownerPlayer = if (ownerIsA) playerA else playerB
            if (ownerTrack != null && (ownerPlayer.isPlaying ||
                    (if (ownerIsA) endlessDeckStateA else endlessDeckStateB) == EndlessDeckState.PLAYING)) {
                return ownerTrack to ownerPlayer.currentPosition
            }
        }
        return when {
            playerA.isPlaying && !playerB.isPlaying && MixerStore.deckA != null -> MixerStore.deckA!! to playerA.currentPosition
            playerB.isPlaying && !playerA.isPlaying && MixerStore.deckB != null -> MixerStore.deckB!! to playerB.currentPosition
            endlessDeckStateA == EndlessDeckState.PLAYING && MixerStore.deckA != null -> MixerStore.deckA!! to playerA.currentPosition
            endlessDeckStateB == EndlessDeckState.PLAYING && MixerStore.deckB != null -> MixerStore.deckB!! to playerB.currentPosition
            else -> null
        }
    }

    private fun youtubeVideoId(url: String): String? = runCatching {
        val uri = Uri.parse(url)
        when {
            uri.host?.contains("youtu.be", ignoreCase = true) == true -> uri.pathSegments.firstOrNull()
            uri.host?.contains("youtube.com", ignoreCase = true) == true -> {
                uri.getQueryParameter("v")
                    ?: uri.pathSegments.dropWhile { it != "shorts" && it != "embed" }.drop(1).firstOrNull()
            }
            else -> null
        }?.takeIf { it.matches(Regex("[A-Za-z0-9_-]{6,20}")) }
    }.getOrNull()

    private fun showVideoScreensaver() {
        if (videoScreensaverOverlay != null) return

        val overlay = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            isClickable = true
            isFocusable = true
        }
        val decor = window.decorView as ViewGroup
        decor.addView(overlay, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        videoScreensaverOverlay = overlay
        showVideoScreensaverLoading(overlay)
        flight("VIDEO_MANUAL_OVERLAY_OPEN")
        refreshVideoScreensaverActive()

        // The mixer transition engine is deliberately independent from this visual layer. Poll only
        // the already-established ACTIVE ownership so a finished A/B mix can hand the screensaver
        // to the new video even when the Activity itself never pauses/resumes. This fixes the old
        // frozen-last-frame case while leaving A/B playback completely untouched.
        videoScreensaverWatcherJob?.cancel()
        videoScreensaverWatcherJob = lifecycleScope.launch {
            while (isActive && videoScreensaverOverlay != null) {
                delay(300L)
                refreshVideoScreensaverActive()
            }
        }
    }

    private fun installVideoScreensaverContent(overlay: FrameLayout, content: View) {
        overlay.removeAllViews()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.BLACK)
        }

        // Keep the official player in a proper 16:9 portrait-console window instead of stretching
        // a WebView through the whole screen.  The small top/bottom weights place the video group
        // slightly above centre so BACK stays close to the picture and safely above phone nav bars.
        root.addView(View(this), LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            0,
            0.75f
        ))

        val screenWidthPx = resources.displayMetrics.widthPixels
        val screenHeightPx = resources.displayMetrics.heightPixels
        val videoHeightPx = minOf(
            (screenWidthPx * 9f / 16f).toInt(),
            (screenHeightPx * 0.48f).toInt()
        ).coerceAtLeast(dp(180))
        root.addView(content, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            videoHeightPx
        ))

        val back = Button(this).apply {
            text = "BACK TO ENDLESS MIX"
            textSize = 16f
            isAllCaps = true
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            // Match the physical mixer controls instead of looking like an ad/action banner.
            background = androidx.appcompat.content.res.AppCompatResources.getDrawable(this@MixerActivity, R.drawable.lux_worn_gunmetal_button)
            setOnClickListener {
                flight("VIDEO_BACK_TO_MIX")
                dismissVideoScreensaver()
            }
        }
        val backWidthPx = minOf(dp(300), screenWidthPx - dp(36))
        root.addView(back, LinearLayout.LayoutParams(backWidthPx, dp(56)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = dp(8)
        })

        root.addView(View(this), LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            0,
            1.25f
        ))

        overlay.addView(root, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))
    }

    private fun showVideoScreensaverLoading(overlay: FrameLayout) {
        videoScreensaverWebView?.destroy()
        videoScreensaverWebView = null

        val center = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        center.addView(ImageView(this).apply {
            setImageResource(R.drawable.endlessmix_banner_center)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            alpha = 0.78f
        }, LinearLayout.LayoutParams(dp(520), dp(180)))

        val spinnerBox = FrameLayout(this)
        spinnerBox.addView(ProgressBar(this).apply { isIndeterminate = true }, FrameLayout.LayoutParams(dp(96), dp(96), Gravity.CENTER))
        spinnerBox.addView(TextView(this).apply {
            text = "▶"
            textSize = 34f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }, FrameLayout.LayoutParams(dp(96), dp(96), Gravity.CENTER))
        center.addView(spinnerBox, LinearLayout.LayoutParams(dp(120), dp(120)))
        installVideoScreensaverContent(overlay, center)
    }

    private fun refreshVideoScreensaverActive() {
        val overlay = videoScreensaverOverlay ?: return
        val active = activeScreensaverTrack()
        if (active == null) {
            if (videoScreensaverWebView != null) showVideoScreensaverLoading(overlay)
            videoScreensaverTrackUrl = null
            return
        }
        val (track, positionMs) = active
        if (videoScreensaverTrackUrl == track.url && videoScreensaverWebView != null) return
        val videoId = youtubeVideoId(track.url)
        if (videoId == null) {
            videoScreensaverTrackUrl = track.url
            showVideoScreensaverLoading(overlay)
            flight("VIDEO_SS_NO_EMBED_ID title=${track.title.take(80)}")
            return
        }

        videoScreensaverTrackUrl = track.url

        // Keep a small indeterminate spinner above the WebView until YouTube reports actual PLAYING.
        // This layer is visual-only; A/B remain the sole audio/transport authority.
        val videoStage = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = WebViewClient()
        }
        val startSpinner = ProgressBar(this).apply {
            isIndeterminate = true
            visibility = View.VISIBLE
        }
        videoStage.addView(web, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))
        videoStage.addView(startSpinner, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER))

        web.addJavascriptInterface(object {
            @android.webkit.JavascriptInterface
            fun onPlaying() {
                runOnUiThread {
                    if (videoScreensaverWebView === web) {
                        startSpinner.visibility = View.GONE
                        flight("VIDEO_SS_PLAYING spinner=false title=${track.title.take(80)}")
                    }
                }
            }

            @android.webkit.JavascriptInterface
            fun onError() {
                runOnUiThread {
                    if (videoScreensaverWebView === web) {
                        startSpinner.visibility = View.GONE
                        flight("VIDEO_SS_ERROR spinner=false title=${track.title.take(80)}")
                    }
                }
            }
        }, "AndroidVideoBridge")

        videoScreensaverWebView?.destroy()
        videoScreensaverWebView = web
        installVideoScreensaverContent(overlay, videoStage)

        // Official YouTube embedded player. Keep controls/branding intact and do not overlay it.
        // The embed is muted because A/B remain the sole audio authority. Start near the current
        // ACTIVE position so the visual layer follows the song without touching A/B transport.
        val startSec = (positionMs / 1000L).coerceAtLeast(0L)
        val html = """
            <!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
            <style>html,body,#player{margin:0;width:100%;height:100%;background:#000;overflow:hidden}</style></head>
            <body><div id="player"></div><script src="https://www.youtube.com/iframe_api"></script><script>
            var p; function onYouTubeIframeAPIReady(){ p=new YT.Player('player',{width:'100%',height:'100%',videoId:'$videoId',
              playerVars:{autoplay:1,controls:1,playsinline:1,fs:0,start:$startSec},
              events:{
                onReady:function(e){e.target.mute();e.target.playVideo();},
                onStateChange:function(e){if(e.data===YT.PlayerState.PLAYING){AndroidVideoBridge.onPlaying();}},
                onError:function(e){AndroidVideoBridge.onError();}
              }}); }
            </script></body></html>
        """.trimIndent()
        // A non-empty base URL supplies the required Referer identity for an Android WebView embed.
        web.loadDataWithBaseURL("https://endlessmix.app/", html, "text/html", "UTF-8", null)
        flight("VIDEO_SS_VIDEO title=${track.title.take(80)} startSec=$startSec")
    }


    private fun dismissVideoScreensaver() {
        videoScreensaverJob?.cancel()
        videoScreensaverJob = null
        videoScreensaverWatcherJob?.cancel()
        videoScreensaverWatcherJob = null
        videoScreensaverWebView?.apply { stopLoading(); destroy() }
        videoScreensaverWebView = null
        videoScreensaverOverlay?.let { (it.parent as? ViewGroup)?.removeView(it) }
        videoScreensaverOverlay = null
        videoScreensaverTrackUrl = null
        flight("VIDEO_SS_CLOSE")
    }

    private fun toggleControlLock() {
        if (!controlsLocked) {
            animateLockHardware {
                controlsLocked = true
                updateControlLockUi()
            }
            return
        }
        AlertDialog.Builder(this)
            .setTitle("ARE YOU SURE?")
            .setMessage("Unlock mixer controls?")
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("UNLOCK") { _, _ ->
                animateLockHardware {
                    controlsLocked = false
                    updateControlLockUi()
                }
            }
            .show()
    }

    private fun initDeckZ() {
        deckZController.initialize { autoDeckZLocale() }
    }

    private fun currentDeckZBpm(): Float {
        val active = when {
            playerA.isPlaying && cross <= 0.55f -> MixerStore.deckA
            playerB.isPlaying && cross >= 0.45f -> MixerStore.deckB
            else -> if (cross < 0.5f) MixerStore.deckA else MixerStore.deckB
        }
        return active?.url?.let { bpmEvidenceByUrl[it]?.bpm }?.takeIf { it in 70f..180f } ?: 124f
    }

    private fun updateDeckZButton() {
        if (!::binding.isInitialized) return
        binding.aiDjMode.text = if (aiDjVoiceEnabled) "AI DJ ON" else "AI DJ OFF"
        binding.aiDjMode.backgroundTintList = null
        binding.aiDjMode.setBackgroundResource(if (aiDjVoiceEnabled) R.drawable.lux_gold_button else R.drawable.lux_black_button)
        binding.aiDjMode.setTextColor(ContextCompat.getColor(this, if (aiDjVoiceEnabled) R.color.black else R.color.lux_silver))
    }

    private fun deckZSceneForTrack(track: TrackRef?): EndlessSceneProfile {
        // Deck Z language follows the user's explicit QEM geography first. This survives the
        // QEM handoff even when quickSceneOverride is neutralized for discovery, so an EX-YU,
        // Italian, French, etc. session cannot silently fall back to English. If no geography
        // was selected, use the current song as the language signal.
        quickCountry?.let { sceneForQuickCountry(it) }?.let { return it }
        quickRegions.asSequence().mapNotNull { sceneForQuickRegion(it) }.firstOrNull()?.let { return it }
        if (track != null) {
            val songScene = classifyTrackScene(track)
            if (songScene != EndlessSceneProfile.GLOBAL) return songScene
        }
        quickSceneOverride?.let { return it }
        return endlessSceneProfile
    }

    private fun deckZLocaleForCountry(country: String?): Locale? = when (country) {
        // Anglo
        "United Kingdom" -> Locale.forLanguageTag("en-GB")
        "United States" -> Locale.forLanguageTag("en-US")
        "Ireland" -> Locale.forLanguageTag("en-IE")
        "Canada" -> Locale.forLanguageTag("en-CA")
        "Australia" -> Locale.forLanguageTag("en-AU")
        "New Zealand" -> Locale.forLanguageTag("en-NZ")

        // EX-YU: country-aware first; VoiceRouter may fall back across mutually intelligible BCS.
        "Croatia" -> Locale.forLanguageTag("hr-HR")
        "Serbia" -> Locale.forLanguageTag("sr-RS")
        "Bosnia and Herzegovina" -> Locale.forLanguageTag("bs-BA")
        "Montenegro" -> Locale.forLanguageTag("sr-ME")
        "Slovenia" -> Locale.forLanguageTag("sl-SI")
        "North Macedonia" -> Locale.forLanguageTag("mk-MK")
        "Kosovo" -> Locale.forLanguageTag("sq-XK")

        // Italian
        "Italy", "San Marino", "Vatican City" -> Locale.forLanguageTag("it-IT")

        // Spanish / Latin America
        "Spain" -> Locale.forLanguageTag("es-ES")
        "Mexico" -> Locale.forLanguageTag("es-MX")
        "Argentina" -> Locale.forLanguageTag("es-AR")
        "Colombia" -> Locale.forLanguageTag("es-CO")
        "Chile" -> Locale.forLanguageTag("es-CL")
        "Peru" -> Locale.forLanguageTag("es-PE")
        "Venezuela" -> Locale.forLanguageTag("es-VE")
        "Ecuador" -> Locale.forLanguageTag("es-EC")
        "Bolivia" -> Locale.forLanguageTag("es-BO")
        "Paraguay" -> Locale.forLanguageTag("es-PY")
        "Uruguay" -> Locale.forLanguageTag("es-UY")
        "Costa Rica" -> Locale.forLanguageTag("es-CR")
        "Panama" -> Locale.forLanguageTag("es-PA")
        "Guatemala" -> Locale.forLanguageTag("es-GT")
        "Honduras" -> Locale.forLanguageTag("es-HN")
        "El Salvador" -> Locale.forLanguageTag("es-SV")
        "Nicaragua" -> Locale.forLanguageTag("es-NI")
        "Cuba" -> Locale.forLanguageTag("es-CU")
        "Dominican Republic" -> Locale.forLanguageTag("es-DO")
        "Puerto Rico" -> Locale.forLanguageTag("es-PR")
        "Equatorial Guinea" -> Locale.forLanguageTag("es-GQ")

        // Portuguese
        "Brazil" -> Locale.forLanguageTag("pt-BR")
        "Portugal" -> Locale.forLanguageTag("pt-PT")
        "Angola" -> Locale.forLanguageTag("pt-AO")
        "Mozambique" -> Locale.forLanguageTag("pt-MZ")
        "Cape Verde" -> Locale.forLanguageTag("pt-CV")
        "Guinea-Bissau" -> Locale.forLanguageTag("pt-GW")
        "Sao Tome and Principe" -> Locale.forLanguageTag("pt-ST")
        "Timor-Leste" -> Locale.forLanguageTag("pt-TL")

        // Francophone
        "France" -> Locale.forLanguageTag("fr-FR")
        "Belgium" -> Locale.forLanguageTag("fr-BE")
        "Luxembourg" -> Locale.forLanguageTag("fr-LU")
        "Monaco" -> Locale.forLanguageTag("fr-MC")
        "Haiti" -> Locale.forLanguageTag("fr-HT")
        "Senegal" -> Locale.forLanguageTag("fr-SN")
        "Cote d'Ivoire" -> Locale.forLanguageTag("fr-CI")
        "Cameroon" -> Locale.forLanguageTag("fr-CM")
        "Mali" -> Locale.forLanguageTag("fr-ML")
        "Benin" -> Locale.forLanguageTag("fr-BJ")
        "Burkina Faso" -> Locale.forLanguageTag("fr-BF")
        "Niger" -> Locale.forLanguageTag("fr-NE")
        "Togo" -> Locale.forLanguageTag("fr-TG")
        "Gabon" -> Locale.forLanguageTag("fr-GA")
        "Congo" -> Locale.forLanguageTag("fr-CG")
        "Democratic Republic of the Congo" -> Locale.forLanguageTag("fr-CD")

        // DACH
        "Germany" -> Locale.forLanguageTag("de-DE")
        "Austria" -> Locale.forLanguageTag("de-AT")
        "Switzerland" -> Locale.forLanguageTag("de-CH")
        "Liechtenstein" -> Locale.forLanguageTag("de-LI")

        "Greece" -> Locale.forLanguageTag("el-GR")
        "Cyprus" -> Locale.forLanguageTag("el-CY")
        "Turkey" -> Locale.forLanguageTag("tr-TR")

        // East Slavic
        "Russia" -> Locale.forLanguageTag("ru-RU")
        "Ukraine" -> Locale.forLanguageTag("uk-UA")
        "Belarus" -> Locale.forLanguageTag("be-BY")

        // South Asian
        "India" -> Locale.forLanguageTag("hi-IN")
        "Pakistan" -> Locale.forLanguageTag("ur-PK")
        "Bangladesh" -> Locale.forLanguageTag("bn-BD")
        "Nepal" -> Locale.forLanguageTag("ne-NP")
        "Sri Lanka" -> Locale.forLanguageTag("si-LK")

        // Arabic-speaking country tags help engines expose the most natural available accent.
        "Saudi Arabia" -> Locale.forLanguageTag("ar-SA")
        "United Arab Emirates" -> Locale.forLanguageTag("ar-AE")
        "Qatar" -> Locale.forLanguageTag("ar-QA")
        "Kuwait" -> Locale.forLanguageTag("ar-KW")
        "Bahrain" -> Locale.forLanguageTag("ar-BH")
        "Oman" -> Locale.forLanguageTag("ar-OM")
        "Jordan" -> Locale.forLanguageTag("ar-JO")
        "Lebanon" -> Locale.forLanguageTag("ar-LB")
        "Syria" -> Locale.forLanguageTag("ar-SY")
        "Iraq" -> Locale.forLanguageTag("ar-IQ")
        "Yemen" -> Locale.forLanguageTag("ar-YE")
        "Egypt" -> Locale.forLanguageTag("ar-EG")
        "Libya" -> Locale.forLanguageTag("ar-LY")
        "Tunisia" -> Locale.forLanguageTag("ar-TN")
        "Algeria" -> Locale.forLanguageTag("ar-DZ")
        "Morocco" -> Locale.forLanguageTag("ar-MA")
        "Sudan" -> Locale.forLanguageTag("ar-SD")
        "Palestine" -> Locale.forLanguageTag("ar-PS")

        "Japan" -> Locale.forLanguageTag("ja-JP")
        "South Korea" -> Locale.forLanguageTag("ko-KR")
        else -> null
    }

    private fun deckZLocaleForTrack(track: TrackRef?): Locale {
        // COUNTRY is the strongest speech-locale signal because it can distinguish Spain/Mexico,
        // Portugal/Brazil, Serbia/Croatia/Bosnia, etc. Region/track scene remains the fallback.
        deckZLocaleForCountry(quickCountry)?.let { return it }
        return when (deckZSceneForTrack(track)) {
            EndlessSceneProfile.EX_YU -> Locale.forLanguageTag("hr-HR")
            EndlessSceneProfile.HISPANIC -> Locale.forLanguageTag("es-MX")
            EndlessSceneProfile.LUSOPHONE -> Locale.forLanguageTag("pt-BR")
            EndlessSceneProfile.FRANCOPHONE -> Locale.forLanguageTag("fr-FR")
            EndlessSceneProfile.DACH -> Locale.forLanguageTag("de-DE")
            EndlessSceneProfile.ITALIAN -> Locale.forLanguageTag("it-IT")
            EndlessSceneProfile.GREEK -> Locale.forLanguageTag("el-GR")
            EndlessSceneProfile.TURKISH -> Locale.forLanguageTag("tr-TR")
            EndlessSceneProfile.ARABIC -> Locale.forLanguageTag("ar-AE")
            EndlessSceneProfile.SOUTH_ASIAN -> Locale.forLanguageTag("hi-IN")
            EndlessSceneProfile.EAST_SLAVIC -> Locale.forLanguageTag("ru-RU")
            EndlessSceneProfile.KOREAN -> Locale.forLanguageTag("ko-KR")
            EndlessSceneProfile.JAPANESE -> Locale.forLanguageTag("ja-JP")
            else -> Locale.US
        }
    }

    private fun currentDeckZTrack(): TrackRef? = when {
        playerA.isPlaying && cross <= 0.55f -> MixerStore.deckA
        playerB.isPlaying && cross >= 0.45f -> MixerStore.deckB
        else -> if (cross < 0.5f) MixerStore.deckA else MixerStore.deckB
    }

    private fun autoDeckZLocale(): Locale = deckZLocaleForTrack(currentDeckZTrack())

    private fun deckZAutomaticText(track: TrackRef): String {
        val artist = artistDisplayName(track).ifBlank { track.uploader }.trim()
        val title = trackDisplayTitle(track).ifBlank { track.title }.trim()
        val locale = deckZLocaleForTrack(track)
        // Automatic Z speaks every third mix. Rotate wording, but keep text and TTS locale paired.
        val variant = ((deckZMixCounter / 3).coerceAtLeast(1) - 1) % 5
        val selected = deckZAnnouncementRouter.automatic(locale, artist, title, variant)
        aidjFlight("DECK_Z_PHRASE locale=${locale.toLanguageTag()} variant=$variant")
        return selected
    }

    private fun maybeSpeakAutomaticDeckZ(incoming: TrackRef?) {
        if (!aiDjVoiceEnabled || incoming == null) return
        deckZMixCounter += 1
        if (deckZMixCounter % 3 != 0) return
        // Automatic Z is crossfade-only. If synthesis is late or occupied, music wins: skip it.
        if (deckZController.isBusy || !deckZController.isReady) return
        deckZController.speakAutomatic(deckZAutomaticText(incoming), deckZLocaleForTrack(incoming))
    }

    private fun speakManualDeckZ(text: String) {
        deckZController.speakManual(text, autoDeckZLocale())
    }

    private fun requestAddToMix() {
        if (!endlessActive) return

        val density = resources.displayMetrics.density
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((22 * density).toInt(), (14 * density).toInt(), (22 * density).toInt(), (8 * density).toInt())
        }
        var chooser: AlertDialog? = null
        val song = Button(this).apply {
            text = "1 — SONG"
            textSize = 18f
            isAllCaps = false
            setTextColor(ContextCompat.getColor(this@MixerActivity, R.color.black))
            setBackgroundResource(R.drawable.lux_worn_silver_button)
            setOnClickListener {
                chooser?.dismiss()
                beginManualSongAdd()
            }
        }
        val voice = Button(this).apply {
            text = if (deckZController.isBusy) "2 — VOICE  •  BUSY" else "2 — VOICE"
            textSize = 18f
            isAllCaps = false
            isEnabled = !deckZController.isBusy
            alpha = if (deckZController.isBusy) 0.45f else 1f
            setTextColor(ContextCompat.getColor(this@MixerActivity, if (deckZController.isBusy) R.color.lux_silver else R.color.black))
            setBackgroundResource(if (deckZController.isBusy) R.drawable.lux_worn_gunmetal_button else R.drawable.lux_worn_gold_button)
            setOnClickListener {
                chooser?.dismiss()
                showManualDeckZTextDialog()
            }
        }
        box.addView(song, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (58 * density).toInt()).apply { bottomMargin = (10 * density).toInt() })
        box.addView(voice, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (58 * density).toInt()))
        chooser = AlertDialog.Builder(this)
            .setTitle("ADD TO MIX")
            .setView(box)
            .setNegativeButton("CANCEL", null)
            .create()
        chooser?.show()
    }

    private fun beginManualSongAdd() {
        endlessAddMode = true
        if (quickDrawerOpen) closeQuickDrawer()
        showAddToMixOverlay()
    }

    private fun closeAddToMixOverlay() {
        addToMixOverlayDialog?.dismiss()
        addToMixOverlayDialog = null
        addToMixOverlayInput = null
        addToMixOverlayStatus = null
        addToMixOverlayAdapter = null
        endlessAddMode = false
        updateControlLockUi()
    }

    private fun showAddToMixOverlay() {
        addToMixOverlayDialog?.dismiss()
        val density = resources.displayMetrics.density
        fun d(v: Int) = (v * density).toInt()
        val dialog = android.app.Dialog(this, android.R.style.Theme_Material_NoActionBar)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(12), d(10), d(12), d(10))
            setBackgroundColor(android.graphics.Color.BLACK)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply { text = "ADD TO MIX"; textSize = 20f; setTextColor(android.graphics.Color.WHITE); setTypeface(typeface, android.graphics.Typeface.BOLD) }
        val close = Button(this).apply { text = "✕ CLOSE"; textSize = 16f; setTextColor(android.graphics.Color.BLACK); setBackgroundResource(R.drawable.lux_worn_silver_button) }
        top.addView(title, LinearLayout.LayoutParams(0, d(52), 1f))
        top.addView(close, LinearLayout.LayoutParams(d(150), d(52)))
        root.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, d(56)))

        val searchRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val input = EditText(this).apply { hint = "Artist / song"; textSize = 19f; isSingleLine = true; setTextColor(android.graphics.Color.WHITE); setHintTextColor(android.graphics.Color.LTGRAY); setBackgroundResource(R.drawable.bw_border); imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH }
        val go = Button(this).apply { text = "GO"; textSize = 18f; setTextColor(android.graphics.Color.BLACK); setBackgroundResource(R.drawable.lux_worn_silver_button) }
        val mic = ImageButton(this).apply { setImageResource(R.drawable.ic_mic); setBackgroundResource(R.drawable.bw_border); contentDescription = "Voice search"; setPadding(d(13), d(13), d(13), d(13)) }
        searchRow.addView(input, LinearLayout.LayoutParams(0, d(58), 1f).apply { marginEnd = d(6) })
        searchRow.addView(go, LinearLayout.LayoutParams(d(86), d(58)).apply { marginEnd = d(6) })
        searchRow.addView(mic, LinearLayout.LayoutParams(d(62), d(58)))
        root.addView(searchRow)
        val status = TextView(this).apply { text = "Search a song to add to this mix"; textSize = 14f; setTextColor(android.graphics.Color.WHITE); gravity = android.view.Gravity.CENTER_VERTICAL }
        root.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, d(36)))
        val results = androidx.recyclerview.widget.RecyclerView(this).apply { layoutManager = LinearLayoutManager(this@MixerActivity); setBackgroundColor(android.graphics.Color.BLACK) }
        val adapter = SearchAdapter(null, {}, {}, onSelect = { track ->
            dialog.dismiss(); addToMixOverlayDialog = null; addToMixOverlayInput = null; addToMixOverlayStatus = null; addToMixOverlayAdapter = null
            selectEndlessSeed(track)
        })
        results.adapter = adapter
        root.addView(results, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        dialog.setContentView(root)
        dialog.setOnDismissListener { if (addToMixOverlayDialog === dialog) { addToMixOverlayDialog = null; addToMixOverlayInput = null; addToMixOverlayStatus = null; addToMixOverlayAdapter = null; endlessAddMode = false; updateControlLockUi() } }
        close.setOnClickListener { closeAddToMixOverlay() }
        go.setOnClickListener { runAddToMixOverlaySearch() }
        input.setOnEditorActionListener { _, actionId, _ -> if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH) { runAddToMixOverlaySearch(); true } else false }
        mic.setOnClickListener { requestEndlessVoiceSearch() }
        addToMixOverlayDialog = dialog; addToMixOverlayInput = input; addToMixOverlayStatus = status; addToMixOverlayAdapter = adapter
        dialog.show()
        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setDimAmount(0.08f)
            addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setGravity(android.view.Gravity.TOP)
            attributes = attributes.apply { y = d(168) }
            setLayout(android.view.WindowManager.LayoutParams.MATCH_PARENT, android.view.WindowManager.LayoutParams.MATCH_PARENT)
        }
        input.requestFocus()
    }

    private fun runAddToMixOverlaySearch() {
        val q = addToMixOverlayInput?.text?.toString()?.trim().orEmpty()
        if (q.isBlank()) return
        addToMixOverlayStatus?.text = "Searching…"
        lifecycleScope.launch {
            runCatching { withContext(Dispatchers.IO) { searchRepo.search(q) } }
                .onSuccess { results -> addToMixOverlayAdapter?.submit(results); addToMixOverlayStatus?.text = "Choose a song — ${results.size} results" }
                .onFailure { addToMixOverlayStatus?.text = "Search error: ${it.message ?: "unknown"}" }
        }
    }

    private fun showManualDeckZTextDialog() {
        if (deckZController.isBusy) return
        val input = EditText(this).apply {
            hint = "What should AI DJ say?"
            minLines = 3
            maxLines = 6
            setTextColor(ContextCompat.getColor(this@MixerActivity, R.color.white))
            setHintTextColor(ContextCompat.getColor(this@MixerActivity, R.color.lux_silver))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("VOICE — DECK Z")
            .setView(input)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("SPEAK", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val text = input.text.toString().trim()
                if (text.isBlank()) return@setOnClickListener
                dialog.dismiss()
                // Manual VOICE is the explicit exception: speak as soon as Z audio is ready.
                speakManualDeckZ(text)
                controlsLocked = true
                endlessAddMode = false
                updateControlLockUi()
            }
        }
        dialog.show()
        input.requestFocus()
    }

    private fun updateControlLockUi() {
        val lockedHardwareView = endlessActive && controlsLocked && !quickDrawerOpen && !endlessAddMode
        binding.lockedControlsPanel.visibility = if (lockedHardwareView) View.VISIBLE else View.GONE
        val showConsoleActionRow = !lockedHardwareView && !quickDrawerOpen && !endlessAddMode
        binding.endlessLockActionRow.visibility = if (showConsoleActionRow) View.VISIBLE else View.GONE
        binding.mixLock.visibility = View.VISIBLE
        binding.mixLock.isEnabled = endlessActive
        binding.mixLock.alpha = if (endlessActive) 1f else 0.55f
        binding.quickAddToMix.visibility = if (quickDrawerOpen && endlessActive) View.VISIBLE else View.GONE
        binding.quickAddToMix.isEnabled = endlessActive
        val showMainAdd = endlessActive && !controlsLocked && !quickDrawerOpen && !endlessAddMode
        binding.mainAddToMix.visibility = if (showMainAdd) View.VISIBLE else View.GONE
        binding.mainAddToMix.isEnabled = showMainAdd
        binding.mainAddToMix.alpha = if (showMainAdd) 1f else 0.55f
        binding.quickAddToMix.alpha = if (endlessActive) 1f else 0.55f
        binding.quickAddToMix.backgroundTintList = null
        binding.quickAddToMix.setBackgroundResource(if (endlessActive) R.drawable.lux_worn_silver_button else R.drawable.lux_worn_gunmetal_button)
        binding.quickAddToMix.setTextColor(ContextCompat.getColor(this, if (endlessActive) R.color.black else R.color.lux_silver))
        binding.lockText.text = if (controlsLocked) "UNLOCK" else "LOCK"
        binding.lockText.setTextColor(ContextCompat.getColor(this, if (controlsLocked) R.color.black else R.color.lux_silver))
        binding.lockIcon.setImageResource(if (controlsLocked) R.drawable.ic_lock_closed else R.drawable.ic_lock_open)
        binding.lockIcon.setColorFilter(ContextCompat.getColor(this, if (controlsLocked) R.color.black else R.color.lux_gold))
        binding.mixLock.backgroundTintList = null
        binding.mixLock.setBackgroundResource(if (controlsLocked) R.drawable.lux_worn_gold_button else R.drawable.lux_worn_gunmetal_button)
        binding.mixLock.elevation = dp(6).toFloat()

        if (lockedHardwareView) {
            binding.endlessAction.visibility = View.GONE
            binding.endlessFilterRow.visibility = View.GONE
            binding.modeButtonRow.visibility = View.VISIBLE
        } else if (!quickDrawerOpen && !endlessAddMode) {
            binding.endlessAction.visibility = View.GONE
            binding.endlessFilterRow.visibility = View.VISIBLE
            binding.modeButtonRow.visibility = View.VISIBLE
        }

        binding.playA.isEnabled = !controlsLocked && playerA.mediaItemCount > 0
        binding.playB.isEnabled = !controlsLocked && playerB.mediaItemCount > 0
        binding.autoMix.isEnabled = !controlsLocked
        binding.aiDjMode.isEnabled = !controlsLocked
        binding.aiDjMode.alpha = if (controlsLocked) 0.55f else 1f
        updateDeckZButton()
        binding.crossfader.isEnabled = !controlsLocked
        updateCrossfadeButton()
        binding.volumeA.isEnabled = !controlsLocked
        binding.volumeB.isEnabled = !controlsLocked
        binding.masterVolume.isEnabled = true
        binding.masterMute.isEnabled = true
        binding.masterMute.alpha = 1f
        binding.waveA.isEnabled = !controlsLocked
        binding.waveB.isEnabled = !controlsLocked
        binding.endlessAction.isEnabled = !controlsLocked
        val addSearchAllowed = endlessActive && endlessAddMode
        binding.endlessSearchInput.isEnabled = !controlsLocked || addSearchAllowed
        binding.endlessSearchButton.isEnabled = !controlsLocked || addSearchAllowed
        binding.endlessVoiceButton.isEnabled = !controlsLocked || addSearchAllowed
        updateEndlessFilterButtons()
        updateLoadButtons()
    }


    private fun showLockedControlNotice() {
        android.widget.Toast.makeText(this, "UNLOCK TO USE CONTROLS", android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun setupQuickEndlessUi() {
        binding.quickCountryButton.setOnClickListener { showQuickCountryPicker() }
        binding.lockedAddToMix.setOnClickListener { requestAddToMix() }
        binding.lockedUnlock.setOnClickListener { toggleControlLock() }
        binding.lockedMute.setOnClickListener {
            masterMuted = !masterMuted
            updateMasterMuteUi()
        }
        binding.lockedStop.setOnClickListener { toggleLockedSafetyStopResume() }
        binding.quickDrawerClose.setOnClickListener { closeQuickDrawer() }
        binding.quickSlowDanceParty.setOnClickListener {
            qemDanceMode = if (qemDanceMode == QemDanceMode.SLOW_DANCE_PARTY) QemDanceMode.NONE else QemDanceMode.SLOW_DANCE_PARTY
            updateQemDanceModeButtons()
        }
        binding.quickDanceParty.setOnClickListener {
            qemDanceMode = if (qemDanceMode == QemDanceMode.DANCE_PARTY) QemDanceMode.NONE else QemDanceMode.DANCE_PARTY
            updateQemDanceModeButtons()
        }
        updateQemDanceModeButtons()
        binding.videoTvButton.setOnClickListener {
            if (activeScreensaverTrack() == null) {
                android.widget.Toast.makeText(this, "NO ACTIVE VIDEO", android.widget.Toast.LENGTH_SHORT).show()
            } else {
                flight("VIDEO_MANUAL_OPEN")
                showVideoScreensaver()
            }
        }
        binding.videoTvButton.setOnLongClickListener { false }
        binding.quickEndlessButton.setOnClickListener {
            if (controlsLocked && !quickDrawerOpen) {
                AlertDialog.Builder(this)
                    .setTitle("ARE YOU SURE?")
                    .setMessage("Open Quick Endless Mix drawer?")
                    .setNegativeButton("CANCEL", null)
                    .setPositiveButton("OPEN") { _, _ -> openQuickDrawer() }
                    .show()
                return@setOnClickListener
            }
            // While QEM owns AUTO, this button is the doorway to a NEW QEM filter, not STOP.
            // Stopping the current QEM here used to force the user to kill playback before changing
            // filters and also pushed the state machine through the shared restart path.
            if (endlessActive && autoDiscoveryMotor == AutoDiscoveryMotor.QEM && !oneArtistMixActive) {
                enforceAutoOwnerInvariant()
                if (!quickDrawerOpen) openQuickDrawer()
                return@setOnClickListener
            }
            // Opening the QEM drawer is UI-only. Do not alter the currently running motor until ENTER.
            if (controlsLocked && !quickDrawerOpen) {
                AlertDialog.Builder(this)
                    .setTitle("ARE YOU SURE?")
                    .setMessage("Open Quick Endless Mix while controls are locked?")
                    .setNegativeButton("CANCEL", null)
                    .setPositiveButton("QUICK MIX") { _, _ -> openQuickDrawer() }
                    .show()
            } else {
                if (quickDrawerOpen) closeQuickDrawer() else openQuickDrawer()
            }
        }
        // Keep an explicit STOP path without sacrificing the normal tap for hot QEM changes.
        binding.quickEndlessButton.setOnLongClickListener {
            if (controlsLocked) { showLockedControlNotice(); return@setOnLongClickListener true }
            if (endlessActive && autoDiscoveryMotor == AutoDiscoveryMotor.QEM && !oneArtistMixActive) {
                stopEndlessMix()
                updateModeButtons()
                true
            } else false
        }
        binding.quickDrawerEnter.setOnClickListener {
            binding.teslaSpark.burst()
            binding.quickDrawerEnter.animate()
                .scaleX(0.985f).scaleY(0.96f).setDuration(80L)
                .withEndAction { binding.quickDrawerEnter.animate().scaleX(1f).scaleY(1f).setDuration(120L).start() }
                .start()
            if (quickRegions.isEmpty() && quickCountry == null && quickEras.isEmpty() && quickStyles.isEmpty() && tempoBand == null) closeQuickDrawer()
            else startQuickEndlessMix()
        }
        binding.quickDrawerReset.setOnClickListener { resetQuickSelections() }

        rebuildQuickRegionButtons()
        rebuildQuickStyleButtons()

        val eraPale = "#F2DEAD"
        val eraStrong = "#FF0000"
        bindQuickChoice(binding.quickEraEvergreen, quickEras, "evergreen classics", eraPale, eraStrong)
        bindQuickChoice(binding.quickEra70, quickEras, "original release 1970s", eraPale, eraStrong)
        bindQuickChoice(binding.quickEra80, quickEras, "original release 1980s", eraPale, eraStrong)
        bindQuickChoice(binding.quickEra90, quickEras, "original release 1990s", eraPale, eraStrong)
        bindQuickChoice(binding.quickEra2000, quickEras, "original release 2000s", eraPale, eraStrong)
        bindQuickChoice(binding.quickEra2010, quickEras, "original release 2010s", eraPale, eraStrong)
        bindQuickChoice(binding.quickEra2020, quickEras, "original release 2020s", eraPale, eraStrong)
        updateQuickEnterUi()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    private fun makeQuickButton(
        label: String,
        pale: String,
        selected: Boolean,
        weighted: Boolean = false,
        onClick: () -> Unit
    ): Button {
        return Button(this).apply {
            layoutParams = if (weighted) {
                LinearLayout.LayoutParams(0, dp(56), 1f).apply {
                    setMargins(dp(2), dp(2), dp(2), dp(2))
                }
            } else {
                LinearLayout.LayoutParams(dp(if (label.length > 13) 142 else 112), dp(56)).apply {
                    setMargins(dp(2), dp(2), dp(2), dp(2))
                }
            }
            text = label.uppercase(Locale.getDefault())
            textSize = when {
                label.length > 17 -> 8.5f
                label.length > 13 -> 9f
                else -> 10.5f
            }
            isAllCaps = false
            maxLines = 2
            backgroundTintList = null
            setBackgroundResource(if (selected) R.drawable.lux_gold_button else R.drawable.lux_silver_button)
            setTextColor(android.graphics.Color.parseColor("#111111"))
            elevation = dp(4).toFloat()
            minWidth = 0
            minHeight = 0
            setPadding(dp(3), 0, dp(3), 0)
            setOnClickListener { onClick() }
        }
    }

    private fun addWrappedButtons(
        container: LinearLayout,
        options: List<QemFonoteka.UiOption>,
        selected: Set<String>,
        pale: String,
        perRow: Int,
        onToggle: (QemFonoteka.UiOption) -> Unit
    ) {
        container.removeAllViews()
        options.chunked(perRow).forEach { chunk ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(62))
            }
            chunk.forEach { option ->
                row.addView(makeQuickButton(option.label, pale, option.key in selected, weighted = true) {
                    onToggle(option)
                })
            }
            // Keep the last incomplete row aligned without stretching its existing buttons.
            repeat(perRow - chunk.size) {
                row.addView(Space(this).apply {
                    layoutParams = LinearLayout.LayoutParams(0, dp(56), 1f)
                })
            }
            container.addView(row)
        }
    }

    private fun rebuildQuickRegionButtons() {
        // Main strip is intentionally short and finger-friendly.
        // GLOBAL is represented by no selected region; all other regions/countries live
        // in the long PICK REGION / COUNTRY selector.
        val primaryKeys = listOf("ANGLO", "LATINO_SPANISH", "ITALIAN", "EX_YU")
        val byKey = qemFonoteka.regionOptions().associateBy { it.key }
        val options = buildList {
            add(QemFonoteka.UiOption("__GLOBAL__", "Global", "region"))
            add(QemFonoteka.UiOption("ANGLO", "English", "region"))
            add(QemFonoteka.UiOption("LATINO_SPANISH", "LATINO", "region"))
            add(QemFonoteka.UiOption("ITALIAN", "Italian", "region"))
            add(QemFonoteka.UiOption("EX_YU", "EX-YU", "region"))
        }
        val row = binding.quickRegionDynamicRow
        addWrappedButtons(
            row,
            options,
            if (quickRegions.isEmpty()) setOf("__GLOBAL__") else quickRegions,
            "#B9D9F2",
            perRow = 5
        ) { option ->
            quickCountry = null
            binding.quickCountryButton.text = "PICK COUNTRY ▾"
            quickRegions.clear()
            if (option.key != "__GLOBAL__") quickRegions.add(option.key)
            rebuildQuickRegionButtons()
            rebuildQuickStyleButtons()
            updateQuickEnterUi()
        }
    }

    private fun rebuildQuickStyleButtons() {
        val row = binding.quickStyleDynamicRow
        val options = mutableListOf(QemFonoteka.UiOption("__MIXED__", "Mixed", "mixed"))
        options += qemFonoteka.styleOptions(quickRegions)
        val allowed = options.map { it.key }.filter { it != "__MIXED__" }.toSet()
        quickStyles.retainAll(allowed)
        // Combined / paired styles occupy the first two rows and use their own hardware color.
        val combinedKeys = setOf("__MIXED__", "POP_ROCK", "HIP_HOP_RAP", "RNB_HIP_HOP", "POP_FOLK", "REGGAE_CARIBBEAN", "WORLD", "DANCE")
        val ordered = options.sortedBy { if (it.key in combinedKeys) 0 else 1 }
        row.removeAllViews()
        ordered.chunked(4).forEach { chunk ->
            val styleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(62)) }
            chunk.forEach { option ->
                val selectedNow = if (quickStyles.isEmpty()) option.key == "__MIXED__" else option.key in quickStyles
                val button = makeQuickButton(if (option.key == "DANCE") "DANCE/HOUSE" else option.label, "#BFE6CD", selectedNow, weighted = true) {
                    if (option.key == "__MIXED__") quickStyles.clear() else { if (option.key in quickStyles) quickStyles.remove(option.key) else quickStyles.add(option.key) }
                    rebuildQuickStyleButtons(); updateQuickEnterUi()
                }
                if (!selectedNow && option.key in combinedKeys) { button.setBackgroundResource(R.drawable.lux_blue_button); button.setTextColor(ContextCompat.getColor(this, R.color.white)) }
                styleRow.addView(button)
            }
            repeat(4 - chunk.size) { styleRow.addView(Space(this).apply { layoutParams = LinearLayout.LayoutParams(0, dp(56), 1f) }) }
            row.addView(styleRow)
        }

    }

    private fun bindQuickChoice(button: Button, set: MutableSet<String>, value: String, pale: String, strong: String) {
        fun paint() {
            button.backgroundTintList = null
            button.setBackgroundResource(if (value in set) R.drawable.lux_gold_button else R.drawable.lux_silver_button)
            button.setTextColor(android.graphics.Color.parseColor("#111111"))
            button.elevation = dp(4).toFloat()
        }
        paint()
        button.setOnClickListener {
            if (value in set) set.remove(value) else set.add(value)
            paint()
            updateQuickEnterUi()
        }
    }

    private fun updateQuickEnterUi() {
        val hasAny = quickRegions.isNotEmpty() || quickCountry != null || quickEras.isNotEmpty() || quickStyles.isNotEmpty() || tempoBand != null
        binding.quickDrawerEnter.text = if (hasAny) "START NEW MIX" else "▼"
        binding.quickDrawerEnter.backgroundTintList = null
        binding.quickDrawerEnter.setBackgroundResource(if (hasAny) R.drawable.lux_gold_button else R.drawable.lux_black_button)
        binding.quickDrawerEnter.setTextColor(android.graphics.Color.parseColor(if (hasAny) "#111111" else "#D0D3D6"))
        binding.quickDrawerEnter.elevation = dp(7).toFloat()
    }

    private fun resetQuickSelections() {
        quickRegions.clear()
        quickCountry = null
        binding.quickCountryButton.text = "PICK COUNTRY ▾"
        tempoBand = null
        quickStyles.clear()
        quickEras.clear()
        qemDanceMode = QemDanceMode.NONE
        updateQemDanceModeButtons()
        rebuildQuickRegionButtons()
        rebuildQuickStyleButtons()
        listOf(binding.quickEraEvergreen, binding.quickEra70, binding.quickEra80, binding.quickEra90,
            binding.quickEra2000, binding.quickEra2010, binding.quickEra2020).forEach {
            it.backgroundTintList = null
            it.setBackgroundResource(R.drawable.lux_silver_button)
            it.setTextColor(android.graphics.Color.rgb(17, 17, 17))
            it.elevation = dp(4).toFloat()
        }
        updateTempoButtons()
        updateQuickEnterUi()
    }

    private fun activeTempoBand(): String? =
        if (quickSessionActive) quickSessionTempoBand ?: tempoBand else tempoBand

    // Legacy on-device BPM/energy analysis is intentionally dormant.
    // Tempo controls were removed from the UI; keep this gate hard-off so no hidden path
    // can decode/analyze audio and steal CPU/I/O from playback, NEXT preparation or discovery.
    private fun requiresMeasuredTempoFilter(): Boolean = false

    private fun isMeasuredTempoAcceptable(result: TempoAnalyzer.Result): Boolean {
        val band = result.band
        val energy = result.energyBand
        fun lowEnergy() = energy == "low"
        fun lowMidEnergy() = energy == "low" || energy == "middle"
        fun midHighEnergy() = energy == "middle" || energy == "high" || energy == "very high"
        fun highEnergy() = energy == "high" || energy == "very high"

        // Universal tempo buttons are musical-feel filters: normalized BPM + measured ENERGY.
        activeTempoBand()?.let { selected ->
            return when (selected) {
                "slow" -> band == "slow" && lowEnergy()
                "middle" -> band == "middle" && lowMidEnergy()
                "fast" -> band == "fast" && midHighEnergy()
                "very fast" -> band == "very fast" && highEnergy()
                else -> true
            }
        }
        return true
    }

    private fun tempoSearchTerms(): String = when (if (quickSessionActive) quickSessionTempoBand ?: tempoBand else tempoBand) {
        "slow" -> "slow mellow relaxed ballad"
        "middle" -> "mid tempo medium tempo groove"
        "fast" -> "upbeat fast dance energetic"
        "very fast" -> "very fast high energy uptempo"
        else -> ""
    }

    private fun effectiveSessionTempoTerms(): String = tempoSearchTerms()

    private fun setTempoBand(value: String?) {
        tempoBand = if (tempoBand == value) null else value
        if (endlessActive && quickSessionActive) quickSessionTempoBand = tempoBand
        updateTempoButtons()
        if (quickDrawerOpen) updateQuickEnterUi()
    }

    private fun updateTempoButtons() {
        if (!::binding.isInitialized) return
        fun paint(button: Button, value: String) {
            val on = tempoBand == value
            button.backgroundTintList = ColorStateList.valueOf(
                ContextCompat.getColor(this, if (on) R.color.red_control else R.color.white)
            )
            button.setTextColor(ContextCompat.getColor(this, if (on) R.color.white else R.color.black))
        }
    }

    private fun quickAllowsLongForm(): Boolean {
        if (quickStyles.isEmpty()) return false
        val longKeys = setOf("JAZZ", "WORLD", "CLASSICAL", "INSTRUMENTAL", "PIANO")
        return quickStyles.all { it in longKeys }
    }

    private fun openQuickDrawer() {
        if (endlessAddMode) return
        quickDrawerOpen = true
        // QEM drawer owns the whole console below the banner. Keep only the header visible.
        binding.deckTransportRow.visibility = View.GONE
        binding.deckMeterRow.visibility = View.GONE
        binding.autoMix.visibility = View.GONE
        binding.aiDjMode.visibility = View.GONE
        binding.crossLabels.visibility = View.GONE
        binding.crossFaderArea.visibility = View.GONE
        binding.startEndlessAutoMix.visibility = View.GONE
        binding.endlessAction.visibility = View.GONE
        binding.endlessLockActionRow.visibility = View.GONE
        binding.lockedControlsPanel.visibility = View.GONE
        binding.endlessFilterRow.visibility = View.GONE
        binding.tempoFilterRow.visibility = View.GONE
        binding.endlessSearchPanel.visibility = View.GONE
        binding.endlessLowerSpacer.visibility = View.GONE
        binding.modeButtonRow.visibility = View.GONE
        // Full-screen QEM body: main console relinquishes all space below the fixed header.
        binding.endlessContainer.visibility = View.GONE
        binding.quickSearchingRow.visibility = View.GONE
        binding.quickAddToMix.visibility = if (endlessActive) View.VISIBLE else View.GONE
        binding.quickAddToMix.isEnabled = endlessActive
        binding.mainAddToMix.visibility = View.GONE
        binding.quickDrawer.visibility = View.VISIBLE
        binding.quickDrawer.alpha = 0f
        binding.quickDrawer.translationY = 120f
        binding.quickDrawer.animate().alpha(1f).translationY(0f).setDuration(160L).start()
    }

    private fun closeQuickDrawer() {
        quickDrawerOpen = false
        binding.quickSearchingRow.visibility = View.GONE
        binding.quickDrawerEnter.isEnabled = true
        binding.quickAddToMix.visibility = View.GONE
        binding.mainAddToMix.visibility = View.GONE
        binding.quickDrawer.visibility = View.GONE
        binding.quickDrawer.translationY = 0f
        binding.endlessContainer.visibility = View.VISIBLE
        binding.deckTransportRow.visibility = View.VISIBLE
        binding.deckMeterRow.visibility = View.VISIBLE
        binding.autoMix.visibility = View.VISIBLE
        binding.aiDjMode.visibility = View.VISIBLE
        binding.crossLabels.visibility = View.VISIBLE
        binding.crossFaderArea.visibility = View.VISIBLE
        binding.endlessAction.visibility = View.GONE
        binding.endlessFilterRow.visibility = View.VISIBLE
        binding.tempoFilterRow.visibility = View.VISIBLE
        binding.endlessSearchPanel.visibility = View.GONE
        binding.endlessLowerSpacer.visibility = View.VISIBLE
        updateEndlessAction()
        updateControlLockUi()
        updateContextualModeUi()
    }

    private fun showQuickCountryPicker() {
        val countries = qemFonoteka.availableCountries(quickRegions)
            .filterNot { it.equals("Balkans", ignoreCase = true) }
        if (countries.isEmpty()) {
            Toast.makeText(this, "No countries for the current region.", Toast.LENGTH_SHORT).show()
            return
        }

        val density = resources.displayMetrics.density
        // Compact country wall: on tablets almost the whole catalog fits at once.
        // Keep buttons large enough to hit, but avoid the old weighted rows that
        // stretched five countries into full-height pillars.
        val columns = when {
            resources.configuration.smallestScreenWidthDp >= 720 -> 7
            resources.configuration.smallestScreenWidthDp >= 600 -> 6
            else -> 4
        }

        var countryPicker: AlertDialog? = null
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((14 * density).toInt(), (10 * density).toInt(), (14 * density).toInt(), (2 * density).toInt())
        }
        val title = TextView(this).apply {
            text = "COUNTRY"
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(ContextCompat.getColor(this@MixerActivity, R.color.white))
            gravity = android.view.Gravity.CENTER
            setPadding(0, 0, 0, (8 * density).toInt())
        }
        container.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val grid = GridLayout(this).apply {
            columnCount = columns
            rowCount = ((countries.size + columns - 1) / columns)
            useDefaultMargins = true
            alignmentMode = GridLayout.ALIGN_BOUNDS
        }

        fun selectCountry(country: String) {
            quickCountry = country
            binding.quickCountryButton.text = country.take(22)
            rebuildQuickRegionButtons()
            rebuildQuickStyleButtons()
            updateQuickEnterUi()
        }

        countries.forEach { country ->
            val button = Button(this).apply {
                text = country
                textSize = if (resources.configuration.smallestScreenWidthDp >= 600) 11.5f else 10.5f
                isAllCaps = false
                maxLines = 2
                gravity = android.view.Gravity.CENTER
                backgroundTintList = null
                setBackgroundResource(if (quickCountry.equals(country, ignoreCase = true)) R.drawable.lux_gold_button else R.drawable.lux_silver_button)
                setTextColor(ContextCompat.getColor(this@MixerActivity, R.color.black))
                elevation = dp(4).toFloat()
                minWidth = 0
                minHeight = 0
                setPadding((4 * density).toInt(), (2 * density).toInt(), (4 * density).toInt(), (2 * density).toInt())
                setOnClickListener {
                    selectCountry(country)
                    countryPicker?.dismiss()
                }
            }
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(if (resources.configuration.smallestScreenWidthDp >= 600) 50 else 48)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                // No row weight: fixed compact rows prevent giant vertical country pillars.
                rowSpec = GridLayout.spec(GridLayout.UNDEFINED)
                setMargins((2 * density).toInt(), (2 * density).toInt(), (2 * density).toInt(), (2 * density).toInt())
            }
            grid.addView(button, params)
        }

        val gridScroll = ScrollView(this).apply {
            isFillViewport = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            addView(grid, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        container.addView(gridScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        countryPicker = AlertDialog.Builder(this)
            .setView(container)
            .setNegativeButton("CLEAR") { _, _ ->
                quickCountry = null
                binding.quickCountryButton.text = "PICK COUNTRY ▾"
                rebuildQuickRegionButtons()
                rebuildQuickStyleButtons()
                updateQuickEnterUi()
            }
            .create()
        countryPicker.setOnShowListener {
            countryPicker?.window?.setLayout(
                (resources.displayMetrics.widthPixels * 0.96f).toInt(),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        countryPicker.show()
    }

    private fun sceneForQuickRegion(region: String): EndlessSceneProfile? = when (region) {

        "ex yu" -> EndlessSceneProfile.EX_YU
        "italian" -> EndlessSceneProfile.ITALIAN
        "latin" -> EndlessSceneProfile.HISPANIC
        "english uk us" -> EndlessSceneProfile.ANGLO
        "french francophone" -> EndlessSceneProfile.FRANCOPHONE
        "german dach" -> EndlessSceneProfile.DACH
        "turkish" -> EndlessSceneProfile.TURKISH
        "arabic" -> EndlessSceneProfile.ARABIC
        "brazilian portuguese" -> EndlessSceneProfile.LUSOPHONE
        "japanese" -> EndlessSceneProfile.JAPANESE
        "korean" -> EndlessSceneProfile.KOREAN
        else -> null
    }

    private fun sceneForQuickCountry(country: String): EndlessSceneProfile? = when (country) {
        // Anglo
        "United Kingdom", "United States", "Ireland", "Canada", "Australia", "New Zealand" -> EndlessSceneProfile.ANGLO
        // Italian
        "Italy", "San Marino", "Vatican City" -> EndlessSceneProfile.ITALIAN
        // Hispanic / Spanish-speaking
        "Spain", "Mexico", "Argentina", "Colombia", "Chile", "Peru", "Venezuela", "Ecuador", "Bolivia",
        "Paraguay", "Uruguay", "Costa Rica", "Panama", "Guatemala", "Honduras", "El Salvador", "Nicaragua",
        "Cuba", "Dominican Republic", "Puerto Rico", "Equatorial Guinea" -> EndlessSceneProfile.HISPANIC
        // Lusophone
        "Brazil", "Portugal", "Angola", "Mozambique", "Cape Verde", "Guinea-Bissau", "Sao Tome and Principe", "Timor-Leste" -> EndlessSceneProfile.LUSOPHONE
        // Francophone core
        "France", "Belgium", "Luxembourg", "Monaco", "Senegal", "Cote d'Ivoire", "Cameroon", "Mali", "Benin",
        "Burkina Faso", "Niger", "Togo", "Gabon", "Congo", "Democratic Republic of the Congo", "Haiti" -> EndlessSceneProfile.FRANCOPHONE
        // German-speaking
        "Germany", "Austria", "Switzerland", "Liechtenstein" -> EndlessSceneProfile.DACH
        // Greece / Cyprus
        "Greece", "Cyprus" -> EndlessSceneProfile.GREEK
        "Turkey" -> EndlessSceneProfile.TURKISH
        // Ex-YU
        "Croatia", "Serbia", "Bosnia and Herzegovina", "Montenegro", "Slovenia", "North Macedonia", "Kosovo" -> EndlessSceneProfile.EX_YU
        // East Slavic
        "Russia", "Ukraine", "Belarus" -> EndlessSceneProfile.EAST_SLAVIC
        // South Asian
        "India", "Pakistan", "Bangladesh", "Nepal", "Sri Lanka" -> EndlessSceneProfile.SOUTH_ASIAN
        // Arabic-speaking core
        "Saudi Arabia", "United Arab Emirates", "Qatar", "Kuwait", "Bahrain", "Oman", "Jordan", "Lebanon", "Syria",
        "Iraq", "Yemen", "Egypt", "Libya", "Tunisia", "Algeria", "Morocco", "Sudan", "Palestine" -> EndlessSceneProfile.ARABIC
        "Japan" -> EndlessSceneProfile.JAPANESE
        "South Korea" -> EndlessSceneProfile.KOREAN
        else -> null
    }

    private fun selectedQuickSceneOverride(): EndlessSceneProfile? {
        if (quickRegions.size != 1) return null
        return sceneForQuickRegion(quickRegions.first())
    }


    private fun qemRegionKeysFromUi(): Set<String> = quickRegions.filter { it in qemFonoteka.availableRegions }.toSet()

    private fun qemEraKeysFromUi(): Set<String> = quickEras.mapNotNull { value ->
        when {
            "evergreen" in value -> "EVERGREEN"
            "1970" in value -> "1970s"
            "1980" in value -> "1980s"
            "1990" in value -> "1990s"
            "2000" in value -> "2000s"
            "2010" in value -> "2010s"
            "2020" in value -> "2020s"
            else -> null
        }
    }.toSet()

    private fun qemStyleKeysFromUi(): Set<String> {
        val result = linkedSetOf<String>()
        quickStyles.forEach { key ->
            if (key in qemFonoteka.availableStyles) result += key
            result += qemFonoteka.combinedComponents(key).filter { it in qemFonoteka.availableStyles }
        }
        return result
    }

    private fun qemClassicalSelected(): Boolean = "CLASSICAL" in quickStyles
    private fun qemInstrumentalSelected(): Boolean = "INSTRUMENTAL" in quickStyles || "PIANO" in quickStyles
    private fun qemPianoSelected(): Boolean = "PIANO" in quickStyles

    private fun qemEraQueryTerms(): String = when {
        qemEngine.sessionEraKeys.size != 1 -> ""
        "EVERGREEN" in qemEngine.sessionEraKeys -> "classic original recording"
        "1970s" in qemEngine.sessionEraKeys -> "1970s"
        "1980s" in qemEngine.sessionEraKeys -> "1980s"
        "1990s" in qemEngine.sessionEraKeys -> "1990s"
        "2000s" in qemEngine.sessionEraKeys -> "2000s"
        "2010s" in qemEngine.sessionEraKeys -> "2010s"
        "2020s" in qemEngine.sessionEraKeys -> "2020s"
        else -> ""
    }

    private fun qemStyleQueryTerm(style: String): String = when (style) {
        "POP" -> "pop"
        "ROCK" -> "rock"
        "COUNTRY" -> "country"
        "FOLK" -> "folk traditional"
        "POP_FOLK" -> "pop folk"
        "DANCE" -> "dance"
        "HIP_HOP" -> "hip hop"
        "RAP" -> "rap"
        "REGGAE_CARIBBEAN" -> "reggae caribbean"
        "JAZZ" -> "jazz"
        "BLUES" -> "blues"
        "SOUL" -> "soul"
        "RNB" -> "r&b"
        "WORLD" -> "world music"
        "CLASSICAL" -> "classical"
        else -> ""
    }

    /**
     * PARTY discovery words are intentionally country-local instead of one giant multilingual
     * query. LOVE SONGS searches only for ballad/love/romantic concepts; JUST A PARTY
     * searches only for party/celebration concepts. REGION/STYLE/ERA remain separate hard QEM
     * context and are never replaced by these hints.
     */
    private fun effectiveQemDanceMode(): QemDanceMode =
        if (qemEngine.handoffPending || quickSessionActive || autoDiscoveryMotor == AutoDiscoveryMotor.QEM)
            qemSessionDanceMode
        else qemDanceMode

    private fun qemPartyDiscoveryHint(): String {
        val country = quickCountry.orEmpty().lowercase(Locale.ROOT)
        val region = quickRegions.singleOrNull().orEmpty()
        if (effectiveQemDanceMode() == QemDanceMode.NONE) return ""

        // A top REGION button is sufficient language context when COUNTRY is unset.
        if (country.isBlank()) {
            return when (effectiveQemDanceMode()) {
                QemDanceMode.SLOW_DANCE_PARTY -> when (region) {
                    "EX_YU" -> "balade ljubavne pjesme romantične pjesme"
                    "ITALIAN" -> "ballate canzoni d'amore canzoni romantiche"
                    "LATINO_SPANISH" -> "baladas canciones de amor canciones románticas"
                    "ANGLO" -> "ballads love songs romantic songs"
                    else -> "ballads love songs romantic songs" // GLOBAL base lane; see qemSearchQueries()
                }
                QemDanceMode.DANCE_PARTY -> when (region) {
                    "EX_YU" -> "žurka zurka zabava"
                    "ITALIAN" -> "festa party"
                    "LATINO_SPANISH" -> "fiesta party"
                    else -> "party celebration"
                }
                QemDanceMode.NONE -> ""
            }
        }

        fun slow(default: String = "ballads love songs romantic songs"): String = when {
            country in setOf("montenegro", "serbia", "croatia", "bosnia and herzegovina", "bosnia", "slovenia") ->
                "balade ljubavne pjesme romantične pjesme"
            country in setOf("italy", "san marino") -> "ballate canzoni d'amore canzoni romantiche"
            country in setOf("spain", "mexico", "argentina", "chile", "colombia", "peru", "venezuela", "cuba", "uruguay", "paraguay", "bolivia", "ecuador", "dominican republic", "puerto rico") ->
                "baladas canciones de amor canciones románticas"
            country in setOf("france", "belgium", "monaco") -> "ballades chansons d'amour chansons romantiques"
            country in setOf("portugal", "brazil") -> "baladas canções de amor músicas românticas"
            country in setOf("germany", "austria", "switzerland") -> "balladen liebeslieder romantische lieder"
            country in setOf("greece", "cyprus") -> "μπαλάντες ερωτικά τραγούδια ρομαντικά τραγούδια"
            country == "turkey" -> "balad aşk şarkıları romantik şarkılar"
            country in setOf("poland") -> "ballady piosenki miłosne romantyczne piosenki"
            country in setOf("czech republic", "czechia", "slovakia") -> "balady milostné písně romantické písně"
            country in setOf("romania", "moldova") -> "balade cântece de dragoste melodii romantice"
            country in setOf("hungary") -> "balladák szerelmes dalok romantikus dalok"
            country in setOf("netherlands") -> "ballads liefdesliedjes romantische liedjes"
            country in setOf("sweden") -> "ballader kärlekslåtar romantiska låtar"
            country in setOf("norway") -> "ballader kjærlighetssanger romantiske sanger"
            country in setOf("denmark") -> "ballader kærlighedssange romantiske sange"
            country in setOf("finland") -> "balladit rakkauslaulut romanttiset laulut"
            country in setOf("russia", "ukraine", "belarus") -> "баллады песни о любви романтические песни"
            country in setOf("japan") -> "バラード ラブソング 恋愛ソング"
            country in setOf("south korea", "korea") -> "발라드 사랑 노래 로맨틱 노래"
            country in setOf("china", "taiwan") -> "情歌 爱情歌曲 浪漫歌曲"
            country in setOf("india") -> "बैलाड प्रेम गीत रोमांटिक गीत"
            country in setOf("israel") -> "בלדות שירי אהבה שירים רומנטיים"
            country in setOf("egypt", "lebanon", "jordan", "morocco", "algeria", "tunisia", "saudi arabia", "united arab emirates") ->
                "أغاني حب أغاني رومانسية بالاد"
            else -> default
        }

        fun party(default: String = "party celebration"): String = when {
            country in setOf("montenegro", "serbia", "croatia", "bosnia and herzegovina", "bosnia", "slovenia") -> "žurka zurka zabava"
            country in setOf("italy", "san marino") -> "festa party"
            country in setOf("spain", "mexico", "argentina", "chile", "colombia", "peru", "venezuela", "cuba", "uruguay", "paraguay", "bolivia", "ecuador", "dominican republic", "puerto rico") -> "fiesta party"
            country in setOf("france", "belgium", "monaco") -> "fête soirée party"
            country in setOf("portugal", "brazil") -> "festa party"
            country in setOf("germany", "austria", "switzerland") -> "party feier"
            country in setOf("greece", "cyprus") -> "πάρτι γιορτή"
            country == "turkey" -> "parti eğlence"
            country == "poland" -> "impreza party"
            country in setOf("czech republic", "czechia", "slovakia") -> "párty oslava"
            country in setOf("romania", "moldova") -> "petrecere party"
            country == "hungary" -> "buli party"
            country == "netherlands" -> "feest party"
            country == "sweden" -> "fest party"
            country == "norway" -> "fest party"
            country == "denmark" -> "fest party"
            country == "finland" -> "juhlat bileet"
            country in setOf("russia", "ukraine", "belarus") -> "вечеринка праздник"
            country == "japan" -> "パーティー 宴会"
            country in setOf("south korea", "korea") -> "파티 잔치"
            country in setOf("china", "taiwan") -> "派对 聚会"
            country == "india" -> "पार्टी जश्न"
            country == "israel" -> "מסיבה חגיגה"
            country in setOf("egypt", "lebanon", "jordan", "morocco", "algeria", "tunisia", "saudi arabia", "united arab emirates") -> "حفلة سهرة"
            else -> default
        }

        return when (effectiveQemDanceMode()) {
            QemDanceMode.SLOW_DANCE_PARTY -> slow()
            QemDanceMode.DANCE_PARTY -> party()
            QemDanceMode.NONE -> ""
        }
    }

    private fun qemSearchQuery(artist: QemFonoteka.ArtistChoice): String {
        val attributeTerms = when {
            qemEngine.sessionPiano -> "piano instrumental"
            qemEngine.sessionInstrumental -> "instrumental"
            else -> ""
        }
        val titleTypeTerms = buildList {
            if (allowLive) add("live")
            if (allowCover) add("cover")
            if (onlyOfficial) add("official")
        }.joinToString(" ")
        val discoveryHint = if (titleTypeTerms.isBlank()) "official music" else "$titleTypeTerms music"
        val danceModeHint = qemPartyDiscoveryHint()
        return listOf(
            artist.name,
            qemStyleQueryTerm(artist.style),
            qemEraQueryTerms(),
            attributeTerms,
            danceModeHint,
            discoveryHint
        ).filter { it.isNotBlank() }.joinToString(" ")
    }

    private fun qemSearchQueries(artist: QemFonoteka.ArtistChoice): List<String> {
        val base = qemSearchQuery(artist)
        if (effectiveQemDanceMode() != QemDanceMode.SLOW_DANCE_PARTY ||
            quickCountry?.isNotBlank() == true || quickRegions.isNotEmpty()) {
            return listOf(base)
        }

        // GLOBAL SLOW deliberately opens exactly ENGLISH + LATINO + ITALIAN as separate searches.
        // EX-YU is excluded from GLOBAL and requires explicit EX-YU selection.
        val english = "ballads love songs romantic songs"
        return listOf(
            base,
            base.replace(english, "baladas canciones de amor canciones románticas"),
            base.replace(english, "ballate canzoni d'amore canzoni romantiche")
        ).distinct()
    }

    private fun qemTrackMatchesArtist(track: TrackRef, artist: QemFonoteka.ArtistChoice): Boolean {
        // Universal passport: same resolver for every language/script/catalog. Search rank is never
        // evidence. Strong title/credit identity OR trusted uploader identity is enough, while
        // choreography/tribute/type-beat/etc. remain hard rejects.
        return CanonicalIdentityResolver.matchesWantedArtist(track, artist.name)
    }

    private fun qemBorderAllows(track: TrackRef, artist: QemFonoteka.ArtistChoice): Boolean {
        val ok = qemTrackMatchesArtist(track, artist)
        if (!ok) {
            aidjFlight("BORDER_REJECT wanted=${artist.name.take(50)} got=${track.title.take(80)} uploader=${track.uploader.take(50)}")
        }
        return ok
    }

    private fun qemCheapTrackGuard(track: TrackRef, repeatEmergency: Boolean): Boolean {
        if (persistentHardRepeatBlocked(track, bypassArtistBan = oneArtistMixActive) &&
            !repeatEmergency) return false
        if (!passesGlobalTitleTypeFilters(track)) return false
        if (looksLikeNarrativeNonSong(track) || looksLikeProgramOrCompilation(track)) return false
        val text = canonicalCompareText("${track.title} ${track.uploader}")
        val blocked = listOf(
            "karaoke", "reaction", "tutorial", "full album", "playlist", "interview", "intervju",
            "podcast", "talk", "conversation", "gostovanje", "emisija", "documentary", "review",
            "recenzija", "news", "vijesti", "vesti", "press conference"
        )
        if (blocked.any { it in text }) return false
        if (qemEngine.sessionInstrumental) {
            val vocalSignals = listOf("lyrics", "lyric video", "vocal cover", "karaoke")
            if (vocalSignals.any { it in text } && "instrumental" !in text) return false
        }
        if (qemEngine.sessionPiano && "piano" !in text) return false
        return true
    }

    private fun qemArtistOrder(limit: Int, liveTrack: TrackRef?, repeatEmergency: Boolean): List<QemFonoteka.ArtistChoice> {
        val remaining = qemEngine.sessionArtistPool.toMutableList()
        val chosen = mutableListOf<QemFonoteka.ArtistChoice>()
        val liveArtist = liveTrack?.let(::endlessArtistKey).orEmpty()

        repeat(minOf(limit, remaining.size)) {
            val weighted = remaining.map { artist ->
                // Flatten catalog fame/rank heavily. Rank 1 still gets a modest advantage, but rank
                // 80/120/150 remains genuinely selectable instead of being starved by the top tier.
                var weight = (34.0 / kotlin.math.sqrt(artist.rank.toDouble().coerceAtLeast(1.0)) + 9.0)
                    .roundToInt()
                    .coerceAtLeast(8)
                val key = normalizeArtistText(artist.name)
                if (!oneArtistMixActive && splitArtistCredit(artist.name).any { it in recentArtistKeys() }) {
                    // Normal lane: 15-play artist ban is absolute. Final-30-second emergency lane:
                    // keep the artist eligible at low weight rather than accept dead air.
                    weight = if (repeatEmergency) maxOf(1, weight / 8) else 0
                }

                // Montenegro POP/ROCK soft variety adjustment. These artists remain fully valid;
                // only their post-filter selection weight is reduced to prevent repetition.
                val montenegroPopRock = quickCountry.equals("Montenegro", ignoreCase = true) &&
                    (quickStyles.isEmpty() || quickStyles.any { it == "POP" || it == "POP_ROCK" || it == "ROCK" })
                if (montenegroPopRock) {
                    weight = when {
                        key == normalizeArtistText("Sergej Ćetković") -> maxOf(1, weight / 3)
                        key == normalizeArtistText("Perper") -> maxOf(1, weight / 3)
                        key.startsWith(normalizeArtistText("Danijel")) -> maxOf(1, (weight * 3) / 4)
                        else -> weight
                    }
                }

                if (liveArtist.isNotBlank() && key == liveArtist) {
                    // Immediate same-artist remains forbidden normally. In the continuity sanctuary
                    // it becomes a last-resort low-weight option, because silence is worse.
                    weight = if (repeatEmergency) maxOf(1, weight / 12) else 0
                }
                artist to weight
            }
            val total = weighted.sumOf { it.second }
            // HARD artist history is never relaxed just because the current pool is exhausted.
            // Return fewer artists and let the discovery watchdog widen/search again.
            if (total <= 0) return@repeat
            var needle = Random.nextInt(total)
            val pick = weighted.firstOrNull { (_, weight) ->
                needle -= weight
                needle < 0
            }?.first ?: return@repeat
            chosen += pick
            remaining.remove(pick)
        }
        return chosen
    }

    /**
     * LOVE SONGS is query-driven, not a BPM/tempo mode.
     * Positive words such as ballad/love/romantic belong ONLY to discovery queries; they never
     * grant admission merely because they appear in a track title. The title is used only to
     * reject explicit energetic or alternate-version markers (dance/remix/club/sped-up/etc.).
     */
    private fun qemSlowDanceCandidateAllowed(track: TrackRef, searchRank: Int): Boolean {
        if (qemDanceMode != QemDanceMode.SLOW_DANCE_PARTY && qemSessionDanceMode != QemDanceMode.SLOW_DANCE_PARTY) return true

        // LOVE SONGS positive targeting lives ONLY in the search query. Search rank and
        // positive words in the concrete track title (ballad/love/romantic...) are not
        // admission evidence, because titles can be misleading (e.g. a fast punk/rock song
        // containing "Balada").
        @Suppress("UNUSED_VARIABLE")
        val ignoredSearchRank = searchRank

        // The title is used only as a negative/version safety gate.
        val title = canonicalCompareText(track.title)
        val hardEnergySignals = listOf(
            "dance", "party", "zurka", "club", "disco", "house", "techno", "edm",
            "hardstyle", "trance", "festival", "remix", "extended mix", "club mix",
            "dance mix", "dj mix", "dj set", "bootleg", "mashup", "sped up", "speed up",
            "nightcore", "workout", "gym", "high energy", "upbeat"
        )
        if (hardEnergySignals.any { it in title }) return false

        // If the dedicated LOVE SONGS query found it and it carries no explicit energetic/
        // alternate-version marker, let the normal ranking/other QEM gates decide.
        return true
    }

    private fun qemTrackScore(track: TrackRef): Double {
        // Very soft popularity tie-breaker. Compress views twice so huge channels no longer bury
        // equally valid deeper-catalog songs from less famous artists.
        val logViews = kotlin.math.log10(1.0 + track.viewCount.coerceAtLeast(0L).toDouble())
        val views = kotlin.math.sqrt(logViews.coerceAtLeast(0.0))
        var score = views * 1.35 + if (track.uploaderVerified) 2.2 else 0.0
        val officialText = canonicalCompareText("${track.title} ${track.uploader}")
        val officialAudio = "official audio" in officialText
        val officialVideo = "official video" in officialText || "official music video" in officialText
        val officialChannel = track.uploaderVerified || "vevo" in officialText || " topic" in " $officialText"
        // OFFICIAL FIRST, never OFFICIAL ONLY: official audio/video and verified artist/label
        // sources sort ahead, but a clean fallback can still keep continuity when no official
        // source is available. PARTY modes weight this preference more strongly.
        if (officialAudio) score += if (effectiveQemDanceMode() != QemDanceMode.NONE) 30.0 else 12.0
        if (officialVideo) score += if (effectiveQemDanceMode() != QemDanceMode.NONE) 26.0 else 10.0
        if (officialChannel) score += if (effectiveQemDanceMode() != QemDanceMode.NONE) 15.0 else 6.0
        if ("official" in officialText && !officialAudio && !officialVideo) score += 5.0
        score -= persistentPlaybackPenalty(track).toDouble() / 100.0
        val partyText = canonicalCompareText("${track.title} ${track.uploader}")
        when (effectiveQemDanceMode()) {
            QemDanceMode.DANCE_PARTY -> {
                if (listOf("dance", "club", "party", "remix", "disco", "house").any { it in partyText }) score += 2.8
                if (listOf("ballad", "acoustic", "slow", "piano version").any { it in partyText }) score -= 3.0
                // If final BPM evidence is already cached, 128 is the scoring summit and points
                // fall in both directions toward 118/138. Unknown BPM never gains admission here.
                bpmEvidenceByUrl[track.url]?.takeIf { it.syncSafe && it.bpm in 118f..138f }?.let { ev ->
                    score += (10.0 - kotlin.math.abs(ev.bpm - 128f).toDouble()).coerceAtLeast(0.0)
                }
            }
            QemDanceMode.SLOW_DANCE_PARTY -> {
                if (listOf("slow", "love", "romantic", "ballad", "acoustic").any { it in partyText }) score += 2.8
                if (listOf("hardstyle", "techno", "club mix", "extended mix").any { it in partyText }) score -= 2.2
            }
            QemDanceMode.NONE -> Unit
        }
        return score
    }

    // QEM discovery must never run CPU/catalog work on Android main. PARTY modes can
    // broaden/reshape discovery and therefore make this especially important: a slow
    // repository/catalog pass may delay NEXT, but it may NEVER freeze playback/UI.
    private suspend fun qemFindTracks(count: Int, liveTrack: TrackRef?, deadlineMs: Long): List<TrackRef> {
        // ONE playback-state snapshot per discovery pass. This is the only point where the QEM
        // path is allowed to ask A/B about the continuity sanctuary, and it happens on Main.
        val repeatEmergency = withContext(Dispatchers.Main.immediate) {
            continuityRepeatEmergencyActive()
        }
        return withContext(Dispatchers.Default) {
            // PARTY asks a wider valid QEM pool, then lets the SERVER BPM lane order/filter it.
            // This is intentionally off the playback thread and unknown BPM never blocks continuity.
            val party = effectiveQemDanceMode() != QemDanceMode.NONE
            val discoveryCount = if (party) maxOf(count * 4, 8) else count
            val base = qemFindTracksWorker(discoveryCount, liveTrack, deadlineMs, repeatEmergency)
            if (party) preferCloudPartyBpm(base).take(count) else base.take(count)
        }
    }

    private suspend fun qemFindTracksWorker(count: Int, liveTrack: TrackRef?, deadlineMs: Long, repeatEmergency: Boolean): List<TrackRef> {
        if (count <= 0 || qemEngine.sessionArtistPool.isEmpty()) return emptyList()
        // Snapshot provenance at search start. A late callback from an older QEM request may never
        // stamp itself as belonging to a newer filter generation.
        val provenanceGeneration = qemEngine.discoveryGeneration
        val provenanceFingerprint = qemEngine.filterFingerprint
        fun markIfStillCurrent(track: TrackRef, artistId: String) {
            if (autoDiscoveryMotor == AutoDiscoveryMotor.QEM &&
                provenanceGeneration == qemEngine.discoveryGeneration &&
                provenanceFingerprint.isNotBlank() && provenanceFingerprint == qemEngine.filterFingerprint) {
                markQemCandidate(track, artistId)
            }
        }

        // 1 ARTIST MIX intentionally needs several different songs by the SAME artist.
        // QEM normally prefers one song per artist, so this mode gets a dedicated catalog pass.
        if (oneArtistMixActive && qemEngine.sessionArtistPool.size == 1) {
            val artist = qemEngine.sessionArtistPool.first()
            val deadline = SystemClock.elapsedRealtime() + deadlineMs
            val remaining = (deadline - SystemClock.elapsedRealtime()).coerceAtLeast(1L)
            val tracks = withTimeoutOrNull(minOf(6_000L, remaining)) {
                withContext(Dispatchers.IO) {
                    val typeHint = buildList {
                        if (allowLive) add("live")
                        if (allowCover) add("cover")
                        if (onlyOfficial) add("official")
                    }.joinToString(" ").ifBlank { "official" }
                    runCatching { searchRepo.search("${artist.name} $typeHint music songs") }.getOrDefault(emptyList())
                }
            }.orEmpty()
            val maxSeconds = 480L
            fun candidates(ignoreCycleHistory: Boolean): List<TrackRef> = tracks.asSequence()
                .filter { it.durationSeconds <= 0 || it.durationSeconds in 75L..maxSeconds }
                .filter { qemCheapTrackGuard(it, repeatEmergency) }
                .filter { qemBorderAllows(it, artist) }
                .filter { liveTrack == null || endlessTrackKey(it) != endlessTrackKey(liveTrack) }
                .filter { ignoreCycleHistory || (!endlessUsedTrackKeys.contains(endlessTrackKey(it)) && !recentSongKeys().contains(endlessTrackKey(it))) }
                .distinctBy(::endlessTrackKey)
                .sortedByDescending(::qemTrackScore)
                .take(24)
                .toList()

            var valid = candidates(ignoreCycleHistory = false)
            if (valid.isEmpty()) {
                // Catalog exhausted: begin a new shuffled cycle, while never replaying the currently ACTIVE song immediately.
                endlessUsedTrackKeys.clear()
                        valid = candidates(ignoreCycleHistory = true)
            }
            val picked = valid.take(8).shuffled(Random.Default).take(count)
            picked.forEach { markIfStillCurrent(it, artist.id) }
            return picked
        }

        // Small intersections stay compact. Large REGION/STYLE intersections may draw from up to
        // 150 artists so QEM can rotate beyond the most famous top slice of the fonoteka.
        val artistBaseLimit = if (qemEngine.sessionArtistPool.size >= 60) 150 else 36
        val orderedArtists = qemArtistOrder(minOf(artistBaseLimit, qemEngine.sessionArtistPool.size), liveTrack, repeatEmergency)
        val found = mutableListOf<TrackRef>()
        val usedArtists = linkedSetOf<String>()
        val deadline = SystemClock.elapsedRealtime() + deadlineMs

        // NewPipe extractors are intentionally serialized here. Three concurrent YouTube page
        // extractors plus ExoPlayer + waveform work can spike memory/CPU exactly after a handoff
        // on modest Android tablets. One artist at a time is fast enough with a full-song runway
        // and, critically, cannot destabilize the playback process.
        for (chunk in orderedArtists.chunked(1)) {
            if (SystemClock.elapsedRealtime() >= deadline) break
            val batches = coroutineScope {
                chunk.map { artist ->
                    async(Dispatchers.IO) {
                        val remaining = (deadline - SystemClock.elapsedRealtime()).coerceAtLeast(1L)
                        val tracks = withTimeoutOrNull(minOf(4_500L, remaining)) {
                            runCatching {
                                qemSearchQueries(artist)
                                    .flatMap { query -> searchRepo.search(query) }
                                    .distinctBy(::endlessTrackKey)
                            }.getOrDefault(emptyList())
                        }.orEmpty()
                        artist to tracks
                    }
                }.awaitAll()
            }
            batches.forEach { (artist, tracks) ->
                if (artist.id in usedArtists) return@forEach
                val maxSeconds = if (quickLongFormDuration || qemEngine.sessionStyleKeys.any { it in setOf("JAZZ", "WORLD") }) 1500L else 480L
                val valid = tracks.withIndex().asSequence()
                    .filter { (_, track) -> track.durationSeconds <= 0 || track.durationSeconds in 75L..maxSeconds }
                    .filter { (_, track) -> qemCheapTrackGuard(track, repeatEmergency) }
                    .filter { (_, track) -> qemBorderAllows(track, artist) }
                    .filter { (rank, track) -> qemSlowDanceCandidateAllowed(track, rank) }
                    .map { it.value }
                    .filter { track ->
                        val key = endlessTrackKey(track)
                        repeatEmergency || (!endlessUsedTrackKeys.contains(key) && !recentSongKeys().contains(key))
                    }
                    .sortedByDescending { track ->
                        // In emergency, valid fresh songs still outrank repeated history by a mile.
                        qemTrackScore(track) - if (repeatEmergency && persistentHardRepeatBlocked(track, bypassArtistBan = oneArtistMixActive)) 1000.0 else 0.0
                    }
                    .take(5)
                    .toList()
                val quality = valid.take(3).shuffled(Random.Default)
                val selected = quality.firstOrNull { candidate ->
                    liveTrack?.let { active -> isSameArtistFamily(active, candidate) } != true &&
                        found.none { existing -> isSameArtistFamily(existing, candidate) }
                }
                if (selected != null) {
                    markIfStillCurrent(selected, artist.id)
                    found += selected
                    usedArtists += artist.id
                }
            }
            if (found.size >= count) break
        }
        return found.take(count)
    }

    /**
     * Fill virtual C/D crates only when A/B already have real material. This deliberately moves
     * NewPipe/Fonoteka work away from the post-crossfade instant that used to destabilize playback.
     * C belongs only to A; D belongs only to B. Crates are hints, never playback state.
     */
    private fun kickQemVirtualCrates() {
        if (!endlessActive || !autoEnabled || autoDiscoveryMotor != AutoDiscoveryMotor.QEM ||
            !quickSessionActive || qemEngine.sessionArtistPool.isEmpty()) return
        if (qemEngine.virtualCrateJob?.isActive == true || qemEngine.discoveryJob?.isActive == true) return
        // Do deep work only with a full runway: both physical decks contain media and neither is FREE.
        if (playerA.mediaItemCount == 0 || playerB.mediaItemCount == 0 ||
            endlessDeckStateA == EndlessDeckState.FREE || endlessDeckStateB == EndlessDeckState.FREE) return
        val needC = (qemEngine.virtualCrateDepth - qemEngine.virtualCrateC.size).coerceAtLeast(0)
        val needD = (qemEngine.virtualCrateDepth - qemEngine.virtualCrateD.size).coerceAtLeast(0)
        val missing = needC + needD
        if (missing <= 0) return

        val session = endlessSessionGeneration
        val generation = qemEngine.discoveryGeneration
        val live = when { playerA.isPlaying -> MixerStore.deckA; playerB.isPlaying -> MixerStore.deckB; else -> null }
        qemEngine.virtualCrateJob = lifecycleScope.launch {
            // Scottish mode: fill only the holes. At steady state one consumed virtual slot causes
            // one replacement search, then the worker sleeps again. Never rebuild a full batch.
            val batch = qemFindTracks(count = missing, liveTrack = live, deadlineMs = 12_000L)
            if (session != endlessSessionGeneration || generation != qemEngine.discoveryGeneration ||
                autoDiscoveryMotor != AutoDiscoveryMotor.QEM || !quickSessionActive) {
                qemEngine.virtualCrateJob = null
                return@launch
            }
            qemEngine.storeVirtualBatch(
                batch = batch,
                keyOf = ::endlessTrackKey,
                isCurrent = ::isCurrentQemCandidate
            )
            qemEngine.virtualCrateJob = null
        }
    }

    private fun takeVirtualQemForDeck(isA: Boolean): TrackRef? =
        qemEngine.takeVirtualForDeck(isA) { candidate ->
            isCurrentQemCandidate(candidate) &&
                !persistentHardRepeatBlocked(candidate, bypassArtistBan = oneArtistMixActive)
        }

    /**
     * FREE-DECK continuity escalation. The watchdog owns the age of the physical vacancy; QEM's
     * inner search attempts are free to rotate without hiding a 20+ second empty chassis. Only
     * the backstage discovery job is cancelled/restarted here. The audible deck is never touched.
     */
    private fun restartQemDiscoveryForFreeDeck(isA: Boolean, elapsedMs: Long) {
        if (!endlessActive || !autoEnabled || autoDiscoveryMotor != AutoDiscoveryMotor.QEM || !quickSessionActive) return
        val state = if (isA) endlessDeckStateA else endlessDeckStateB
        val player = if (isA) playerA else playerB
        if (state != EndlessDeckState.FREE || player.isPlaying) return

        val job = qemEngine.discoveryJob
        if (job?.isActive == true) {
            qemEngine.discoveryAttemptSerial++
            job.cancel()
            qemEngine.discoveryJob = null
            qemEngine.discoveryStartedAtMs = 0L
            flight("FREE_DECK_DISCOVERY_RESTART target=${if (isA) "A" else "B"} emptyMs=$elapsedMs queued=${qemEngine.queued != null}")
        } else {
            flight("FREE_DECK_DISCOVERY_KICK target=${if (isA) "A" else "B"} emptyMs=$elapsedMs queued=${qemEngine.queued != null}")
        }
        requestNextPlease(isA)
    }

    private fun ensureQemDiscoveryLiveness(reason: String): Boolean {
        if (!endlessActive || !autoEnabled || autoDiscoveryMotor != AutoDiscoveryMotor.QEM || !quickSessionActive) return false
        val job = qemEngine.discoveryJob
        if (job?.isActive != true) return false
        val age = (SystemClock.elapsedRealtime() - qemEngine.discoveryStartedAtMs).coerceAtLeast(0L)
        if (age < qemEngine.discoveryStallMs) return false

        // A QEM search that is "active" for too long but has produced no parked/READY candidate
        // is stale, not healthy work. Cancel only the backstage search and start a fresh attempt.
        // A/B are sacred: no pause/seek/clear/reload happens here.
        qemEngine.discoveryAttemptSerial++
        job.cancel()
        qemEngine.discoveryJob = null
        qemEngine.discoveryStartedAtMs = 0L
        flight("QEM_DISCOVERY_STALL_RESTART reason=$reason ageMs=$age queued=${qemEngine.queued != null}")
        discoverQemCandidate()
        return true
    }

    private fun discoverQemCandidate() {
        if (!endlessActive || autoDiscoveryMotor != AutoDiscoveryMotor.QEM || !quickSessionActive || qemEngine.sessionArtistPool.isEmpty() ||
            qemEngine.queued != null) return
        if (qemEngine.discoveryJob?.isActive == true) {
            ensureQemDiscoveryLiveness("discover_reentry")
            return
        }

        // Instant handoff from virtual C/D before starting any new search. This is the core rule:
        // a deck becoming FREE consumes prepared work; it does not trigger a panic search.
        val freePhysical: Boolean? = when {
            playerA.isPlaying && !playerB.isPlaying &&
                (MixerStore.deckB == null || playerB.mediaItemCount == 0 || endlessDeckStateB == EndlessDeckState.FREE) -> false
            playerB.isPlaying && !playerA.isPlaying &&
                (MixerStore.deckA == null || playerA.mediaItemCount == 0 || endlessDeckStateA == EndlessDeckState.FREE) -> true
            else -> null
        }
        if (freePhysical != null) {
            val cached = takeVirtualQemForDeck(freePhysical)
            if (cached != null) {
                qemEngine.waitingFreeDeck = freePhysical
                prepareQemHandoffForDeck(freePhysical, cached)
                return
            }
        }

        val now = SystemClock.elapsedRealtime()
        if (now < qemEngine.searchNotBeforeMs) {
            val waitMs = (qemEngine.searchNotBeforeMs - now).coerceAtLeast(1L)
            val attempt = ++qemEngine.discoveryAttemptSerial
            qemEngine.discoveryStartedAtMs = SystemClock.elapsedRealtime()
            qemEngine.discoveryJob = lifecycleScope.launch {
                delay(waitMs)
                if (attempt != qemEngine.discoveryAttemptSerial) return@launch
                qemEngine.discoveryJob = null
                qemEngine.discoveryStartedAtMs = 0L
                if (endlessActive && autoEnabled && autoDiscoveryMotor == AutoDiscoveryMotor.QEM && quickSessionActive) {
                    discoverQemCandidate()
                }
            }
            return
        }
        val session = endlessSessionGeneration
        val motorGeneration = qemEngine.discoveryGeneration
        val activeTrack = when {
            playerA.isPlaying -> MixerStore.deckA
            playerB.isPlaying -> MixerStore.deckB
            else -> null
        }
        val attempt = ++qemEngine.discoveryAttemptSerial
        qemEngine.discoveryStartedAtMs = SystemClock.elapsedRealtime()
        qemEngine.discoveryJob = lifecycleScope.launch {
            val found = withTimeoutOrNull(14_000L) {
                qemFindTracks(count = 1, liveTrack = activeTrack, deadlineMs = 12_000L)
            } ?: emptyList()
            if (attempt != qemEngine.discoveryAttemptSerial) return@launch
            if (session != endlessSessionGeneration || motorGeneration != qemEngine.discoveryGeneration || autoDiscoveryMotor != AutoDiscoveryMotor.QEM) return@launch
            qemEngine.discoveryJob = null
            qemEngine.discoveryStartedAtMs = 0L
            if (!endlessActive || !quickSessionActive || autoDiscoveryMotor != AutoDiscoveryMotor.QEM) return@launch
            val candidate = found.firstOrNull()
            if (candidate == null) {
                delay(900L)
                if (endlessActive && quickSessionActive && autoDiscoveryMotor == AutoDiscoveryMotor.QEM &&
                    session == endlessSessionGeneration && motorGeneration == qemEngine.discoveryGeneration &&
                    qemEngine.queued == null && qemEngine.discoveryJob?.isActive != true) {
                    discoverQemCandidate()
                }
                return@launch
            }
            if (!isCurrentQemCandidate(candidate)) {
                delay(100L)
                discoverQemCandidate()
                return@launch
            }
            endlessUsedUrls.add(candidate.url)
            endlessUsedTrackKeys.add(endlessTrackKey(candidate))

            // CONSTITUTION: QEM never trusts a stale reservation for an EMPTY deck. Re-read the
            // physical chassis at the instant the candidate is ready. If exactly one deck is
            // ACTIVE and the opposite deck is physically empty/free, load it there immediately.
            // Only when both physical decks are genuinely occupied may QEM keep candidate #2
            // logically queued.
            val physicalWaiting: Boolean? = when {
                playerA.isPlaying && !playerB.isPlaying &&
                    (MixerStore.deckB == null || playerB.mediaItemCount == 0 || endlessDeckStateB == EndlessDeckState.FREE) -> false
                playerB.isPlaying && !playerA.isPlaying &&
                    (MixerStore.deckA == null || playerA.mediaItemCount == 0 || endlessDeckStateA == EndlessDeckState.FREE) -> true
                // DEAD-AIR OWNERSHIP: when neither transport is playing, recovery already chose
                // exactly one physical destination. Do not park the result or let a second deck
                // race it; hand the candidate to that recovery owner immediately.
                !playerA.isPlaying && !playerB.isPlaying && endlessRecoveryDeck != null -> endlessRecoveryDeck
                else -> null
            }
            qemEngine.waitingFreeDeck = null
            if (physicalWaiting != null) {
                qemEngine.waitingFreeDeck = physicalWaiting
                if (!playerA.isPlaying && !playerB.isPlaying && endlessRecoveryDeck == physicalWaiting) {
                    flight("DEAD_AIR_CANDIDATE_HANDOFF deck=${if (physicalWaiting) "A" else "B"} title=${candidate.title.take(80)}")
                }
                prepareQemHandoffForDeck(physicalWaiting, candidate)
            } else {
                qemEngine.queued = candidate
                lifecycleScope.launch { delay(1_500L); kickQemVirtualCrates() }
            }
        }
    }

    private fun updateQemDanceModeButtons() {
        fun apply(button: android.widget.Button, active: Boolean) {
            // PARTY controls must always read as live controls, never as disabled/grey ghosts.
            button.alpha = 1.0f
            button.isEnabled = true
            button.isClickable = true
            button.isSelected = active
            button.setBackgroundResource(
                if (active) R.drawable.lux_ferrari_red_button else R.drawable.lux_silver_button
            )
            button.setTextColor(if (active) android.graphics.Color.WHITE else android.graphics.Color.BLACK)
            // Active PARTY label: white lettering with a black outline/halo for strong contrast.
            if (active) button.setShadowLayer(dp(1).toFloat(), 0f, 0f, android.graphics.Color.BLACK)
            else button.setShadowLayer(0f, 0f, 0f, android.graphics.Color.TRANSPARENT)
            button.elevation = dp(4).toFloat()
        }
        apply(binding.quickSlowDanceParty, qemDanceMode == QemDanceMode.SLOW_DANCE_PARTY)
        apply(binding.quickDanceParty, qemDanceMode == QemDanceMode.DANCE_PARTY)
    }

    private fun startQuickEndlessMix() {
        // Validate first. Preserve the current owner until we know whether this is QEM->QEM hot
        // swap or a real handoff from BASIC / 1 ARTIST / NONE.
        val wasOneArtistMix = oneArtistMixActive
        val regionKeys = qemRegionKeysFromUi()
        val eraKeys = qemEraKeysFromUi()
        val styleKeys = qemStyleKeysFromUi()
        val includeClassical = qemClassicalSelected()
        val instrumental = qemInstrumentalSelected()
        val piano = qemPianoSelected()
        val requestedTempoBand = tempoBand
        val requestedDanceMode = qemDanceMode

        val requestedPool = runCatching {
            qemFonoteka.buildArtistPool(
                regionKeys = regionKeys,
                country = quickCountry,
                styleKeys = styleKeys,
                eraKeys = eraKeys,
                includeClassical = includeClassical
            )
        }.getOrElse {
            AlertDialog.Builder(this)
                .setMessage("Fonoteka could not be loaded")
                .setPositiveButton("OK", null)
                .show()
            return
        }

        // The JSON is authoritative. An impossible filter combination is a valid zero-result state;
        // QEM never widens region/style/era behind the user's back just to make something play.
        if (requestedPool.isEmpty()) {
            AlertDialog.Builder(this)
                .setMessage("No artists exist for this filter combination")
                .setPositiveButton("OK", null)
                .show()
            return
        }

        // HOT QEM FILTER SWITCH: while QEM is already playing, ENTER changes only the QEM
        // discovery universe. ACTIVE audio is inherited untouched; the old waiting deck/Slot 2
        // are invalidated and rebuilt from the new hard filters immediately. No STOP is required.
        val liveQemActiveIsA: Boolean? = when {
            playerA.isPlaying && !playerB.isPlaying -> true
            playerB.isPlaying && !playerA.isPlaying -> false
            playerA.isPlaying && playerB.isPlaying -> cross <= 0.5f
            else -> null
        }
        if (endlessActive && autoDiscoveryMotor == AutoDiscoveryMotor.QEM &&
            !wasOneArtistMix && liveQemActiveIsA != null) {
            // QEM ENTER is a filter-generation change, never an engine-owner change.
            quickSessionActive = true
            autoEnabled = true
            enforceAutoOwnerInvariant()
            quickStartJob?.cancel()
            quickStartJob = lifecycleScope.launch {
                binding.quickDrawerEnter.isEnabled = false
                binding.quickSearchingRow.visibility = View.VISIBLE
                binding.quickSearchingText.text = "APPLYING NEW QEM FILTER…"

                // Invalidate every candidate/search/load belonging to the previous QEM filter.
                qemEngine.discoveryGeneration++
                val hotSwapGeneration = qemEngine.discoveryGeneration
                qemEngine.discoveryJob?.cancel(); qemEngine.discoveryJob = null
                endlessLoadJobA?.cancel(); endlessLoadJobA = null
                endlessLoadJobB?.cancel(); endlessLoadJobB = null
                qemEngine.queued = null
                qemEngine.waitingFreeDeck = null
                qemEngine.candidateStamps.clear()
                qemEngine.trackArtistIds.clear()
                qemEngine.recentArtistIds.clear()

                qemEngine.sessionArtistPool = requestedPool
                qemEngine.sessionStyleKeys = styleKeys
                qemEngine.sessionEraKeys = eraKeys
                qemEngine.sessionInstrumental = instrumental
                qemEngine.sessionPiano = piano
                qemSessionDanceMode = requestedDanceMode
                if (requestedDanceMode == QemDanceMode.DANCE_PARTY) {
                    MixerStore.deckA?.let { prefetchCloudTrackMetadata(true, it) }
                    MixerStore.deckB?.let { prefetchCloudTrackMetadata(false, it) }
                }
                qemEngine.filterFingerprint = buildString {
                    append("QEM|")
                    append(regionKeys.sorted().joinToString(",")); append('|')
                    append(quickCountry.orEmpty()); append('|')
                    append(styleKeys.sorted().joinToString(",")); append('|')
                    append(eraKeys.sorted().joinToString(",")); append('|')
                    append("I=").append(instrumental).append("|P=").append(piano).append("|C=").append(includeClassical).append("|D=").append(requestedDanceMode.name)
                }
                quickSessionTempoBand = requestedTempoBand
                quickLongFormDuration = quickAllowsLongForm() || includeClassical || instrumental || piano ||
                    styleKeys.any { it in setOf("JAZZ", "WORLD") }
                qemEngine.handoffPending = false
                // Re-assert after all async cancellation/state mutation: old callbacks may not
                // demote the currently active QEM session.
                quickSessionActive = true
                autoEnabled = true
                if (autoDiscoveryMotor != AutoDiscoveryMotor.QEM) switchDiscoveryMotor(AutoDiscoveryMotor.QEM)
                enforceAutoOwnerInvariant()

                val waitingIsA = !liveQemActiveIsA
                // NEW RULE: SEARCH FIRST, SWAP SECOND. The currently parked NEXT is left physically
                // untouched while QEM walks fonoteka -> artist -> query -> web search -> validation.
                // We only release/replace that waiting deck after a concrete valid candidate exists.
                val waitingTrackBeforeSearch = if (waitingIsA) MixerStore.deckA else MixerStore.deckB
                val waitingWasManual = waitingTrackBeforeSearch?.url?.let { it in endlessManualUrls } == true
                qemEngine.waitingFreeDeck = null

                val wanted = if (requiresMeasuredTempoFilter()) 8 else 1
                var candidates = qemFindTracks(
                    count = wanted,
                    liveTrack = if (liveQemActiveIsA) MixerStore.deckA else MixerStore.deckB,
                    deadlineMs = 14_000L
                )
                if (!isActive || qemEngine.discoveryGeneration != hotSwapGeneration ||
                    autoDiscoveryMotor != AutoDiscoveryMotor.QEM || !quickSessionActive) return@launch

                // qemFindTracks() already gives server BPM one tightly bounded chance to improve
                // PARTY ordering. Never perform a second network wait here: SEARCH FIRST / SWAP
                // SECOND must still mean that a valid NEXT proceeds straight to resolve/load.

                if (!isActive || qemEngine.discoveryGeneration != hotSwapGeneration ||
                    autoDiscoveryMotor != AutoDiscoveryMotor.QEM || !quickSessionActive) return@launch

                val nextRaw = candidates.firstOrNull()
                val next = if (nextRaw != null && isCurrentQemCandidate(nextRaw)) {
                    if (nextRaw.streamUrl != null) nextRaw else withTimeoutOrNull(8_000L) {
                        withContext(Dispatchers.IO) {
                            runCatching { nextRaw.copy(streamUrl = AudioResolver.resolveBestAudioUrl(nextRaw.url)) }.getOrNull()
                        }
                    }
                } else null

                if (next?.streamUrl != null && isCurrentQemCandidate(next)) {
                    binding.quickSearchingText.text = "LOADING NEXT…"
                    if (!waitingWasManual) {
                        // SEARCH/RESOLVE/VALIDATE FIRST. Only now do we replace the parked NEXT.
                        // No pre-clear, no FREE reservation and no 12-second "failed -> EMPTY" cleanup.
                        val installed = installPreparedQemTrackIntoWaitingDeck(waitingIsA, next)
                        if (installed) {
                            qemEngine.waitingFreeDeck = null
                            discoverQueuedCandidate()
                        } else {
                            // A late manual protection/playback change wins; preserve the parking track.
                            qemEngine.queued = next
                        }
                    } else {
                        // Manual ADD TO MIX is sacred.
                        qemEngine.queued = next
                    }
                } else {
                    // No immediate hit is not a failure. AUTO stays ON and QEM keeps searching
                    // inside the exact new filter until it can fill the waiting deck.
                    // EMPTY deck has no QEM owner. Search without reserving it; the result
                    // will inspect the physical A/B state and load the still-empty opposite deck.
                    qemEngine.waitingFreeDeck = null
                    binding.quickSearchingText.text = "SEARCHING NEXT…"
                    discoverQemCandidate()
                }

                // HOT QEM switch ends in QEM, regardless of search/load timing. ACTIVE stays
                // on its physical deck; the other deck remains QEM's waiting destination.
                quickSessionActive = true
                autoEnabled = true
                enforceAutoOwnerInvariant()
                resetQuickSelections()
                closeQuickDrawer()
                binding.quickDrawerEnter.isEnabled = true
                updateAutoButton()
                updateModeButtons()
            }
            return
        }

        // This is a real owner handoff (NONE/BASIC/1 ARTIST -> QEM), not a hot filter swap.
        oneArtistMixActive = false
        quickStartJob?.cancel()
        qemEngine.handoffPending = true
        quickStartJob = lifecycleScope.launch {
            binding.quickDrawerEnter.isEnabled = false
            binding.quickSearchingRow.visibility = View.VISIBLE
            binding.quickSearchingText.text = "SEARCHING FONOTEKA…"

            // ATOMIC QEM HANDOFF: never switch AUTO OFF before the new QEM lane has proved it can
            // continue. The old implementation called stopEndlessMix() here; that preserved the
            // audible ACTIVE song but set autoEnabled=false and cleared the old discovery session.
            // If QEM search/resolve then failed or a coroutine was interrupted, the first song simply
            // played to its end and the mixer landed on EMPTY / AUTO IS OFF. Keep the live AUTO
            // session armed during handoff and transfer discovery ownership only. Physical ACTIVE
            // and any already-loaded waiting deck remain untouched until QEM has a concrete result.
            oneArtistMixActive = false
            if (!endlessActive) {
                autoEnabled = true
            }
            switchDiscoveryMotor(AutoDiscoveryMotor.QEM)
            qemEngine.queued = null

            qemEngine.sessionArtistPool = requestedPool
            qemEngine.sessionStyleKeys = styleKeys
            qemEngine.sessionEraKeys = eraKeys
            qemEngine.sessionInstrumental = instrumental
            qemEngine.sessionPiano = piano
            qemSessionDanceMode = requestedDanceMode
            if (requestedDanceMode == QemDanceMode.DANCE_PARTY) {
                MixerStore.deckA?.let { prefetchCloudTrackMetadata(true, it) }
                MixerStore.deckB?.let { prefetchCloudTrackMetadata(false, it) }
            }
            qemEngine.filterFingerprint = buildString {
                append("QEM|")
                append(regionKeys.sorted().joinToString(",")); append('|')
                append(quickCountry.orEmpty()); append('|')
                append(styleKeys.sorted().joinToString(",")); append('|')
                append(eraKeys.sorted().joinToString(",")); append('|')
                append("I=").append(instrumental).append("|P=").append(piano).append("|C=").append(includeClassical).append("|D=").append(requestedDanceMode.name)
            }
            qemEngine.recentArtistIds.clear()
            qemEngine.trackArtistIds.clear()
            qemEngine.candidateStamps.clear()
            quickSessionTempoBand = requestedTempoBand
            quickLongFormDuration = quickAllowsLongForm() || includeClassical || instrumental || piano ||
                styleKeys.any { it in setOf("JAZZ", "WORLD") }

            val liveActiveIsA: Boolean? = when {
                playerA.isPlaying && !playerB.isPlaying -> true
                playerB.isPlaying && !playerA.isPlaying -> false
                playerA.isPlaying && playerB.isPlaying -> cross <= 0.5f
                else -> null
            }
            val liveActiveTrack = when (liveActiveIsA) {
                true -> MixerStore.deckA
                false -> MixerStore.deckB
                null -> null
            }

            // Normalize ownership if an old broken state had both decks audible. The chosen ACTIVE
            // deck is never stopped, sought, reloaded or replaced.
            if (liveActiveIsA != null) {
                if (liveActiveIsA) {
                    playerB.pause(); playerB.playWhenReady = false
                    cross = 0f; binding.crossfader.progress = 0
                } else {
                    playerA.pause(); playerA.playWhenReady = false
                    cross = 1f; binding.crossfader.progress = 100
                }
                applyVolumes()
            }

            quickSessionActive = false
            quickStartupGuardA = false
            pendingEndlessStart = false
            pendingEndlessStartIsA = null
            autoFadeJob?.cancel(); autoFadeJob = null
            endlessSeeds.clear()
            endlessQueued = null
            qemEngine.queued = null
            activeWaitingFreeDeck = null
            endlessRecoveryDeck = null

            // SEARCH FIRST, SWAP SECOND. During a live owner handoff, never empty the parked
            // waiting deck before QEM has a concrete playable replacement. Keep the physical pair
            // exactly as-is while fonoteka/search/validation runs. Only the no-live-audio cold start
            // still begins from clean A/B decks.
            if (liveActiveIsA == true) {
                endlessDeckStateA = EndlessDeckState.PLAYING
                endlessDeckStateB = when {
                    MixerStore.deckB != null && playerB.mediaItemCount > 0 -> EndlessDeckState.READY_NEXT
                    else -> EndlessDeckState.FREE
                }
            } else if (liveActiveIsA == false) {
                endlessDeckStateB = EndlessDeckState.PLAYING
                endlessDeckStateA = when {
                    MixerStore.deckA != null && playerA.mediaItemCount > 0 -> EndlessDeckState.READY_NEXT
                    else -> EndlessDeckState.FREE
                }
            } else {
                playerA.pause(); playerB.pause()
                playerA.stop(); playerB.stop()
                playerA.clearMediaItems(); playerB.clearMediaItems()
                MixerStore.deckA = null; MixerStore.deckB = null
                MixerStore.waveA = null; MixerStore.waveB = null
                lastTrackAUrl = null; lastTrackBUrl = null
                resolvingA = null; resolvingB = null
                endlessDeckStateA = EndlessDeckState.FREE
                endlessDeckStateB = EndlessDeckState.FREE
                cross = 0f; binding.crossfader.progress = 0
                applyVolumes()
            }

            binding.endlessAction.visibility = View.GONE
            binding.endlessLockActionRow.visibility = View.GONE
            binding.endlessFilterRow.visibility = View.GONE
            binding.endlessSearchPanel.visibility = View.GONE
            binding.endlessLowerSpacer.visibility = View.GONE
            binding.modeButtonRow.visibility = View.GONE
            binding.quickDrawer.visibility = View.VISIBLE

            // LIVE QEM HANDOFF — USE THE SAME PROVEN TRANSMISSION AS BASIC ENDLESS.
            //
            // Basic Endless is reliable because ENTER happens only after two physical deck tracks
            // already exist: the live ACTIVE track and the newly chosen waiting seed. startEndlessMix()
            // then adopts the live player and treats the opposite loaded deck as READY_NEXT.
            //
            // QEM must use that exact transmission. Its only special job is choosing the new waiting
            // song from the hard fonoteka filters. Once chosen, we install it into the physical waiting
            // deck exactly like a manually selected Basic seed, wait until that deck is actually READY,
            // and only then call the shared startEndlessMix() handoff. No custom QEM deck-loader path,
            // no EMPTY-deck ownership proxy and no parallel second transmission. ACTIVE is never touched.
            if (liveActiveIsA != null) {
                val nextIsA = !liveActiveIsA
                binding.quickSearchingText.text = "FINDING NEXT…"

                // Search several valid candidates while the inherited ACTIVE song keeps playing.
                // Resolve the audio URL before touching the waiting deck so a dead search result can
                // never leave the physical transmission half-installed.
                val wantedLiveCandidates = if (requiresMeasuredTempoFilter()) 10 else 4
                var liveCandidates = qemFindTracks(
                    count = wantedLiveCandidates,
                    liveTrack = liveActiveTrack,
                    deadlineMs = 22_000L
                )
                if (!isActive) return@launch

                if (requiresMeasuredTempoFilter() && liveCandidates.isNotEmpty()) {
                    binding.quickSearchingText.text = "CHECKING TEMPO…"
                    liveCandidates = coroutineScope {
                        liveCandidates.take(12).map { t ->
                            async(Dispatchers.IO) {
                                val resolved = runCatching {
                                    if (t.streamUrl != null) t else t.copy(streamUrl = AudioResolver.resolveBestAudioUrl(t.url))
                                }.getOrNull() ?: return@async null
                                val direct = resolved.streamUrl ?: return@async null
                                val tempo = runLowPriorityAnalysis { TempoAnalyzer.analyze(direct, cacheKey = resolved.url) }
                                if (tempo == null || isMeasuredTempoAcceptable(tempo)) resolved else null
                            }
                        }.awaitAll().filterNotNull()
                    }
                }

                var preparedNext: TrackRef? = null
                for (candidate in liveCandidates) {
                    if (!isCurrentQemCandidate(candidate)) continue
                    val resolved = if (candidate.streamUrl != null) candidate else {
                        withTimeoutOrNull(8_000L) {
                            withContext(Dispatchers.IO) {
                                runCatching { candidate.copy(streamUrl = AudioResolver.resolveBestAudioUrl(candidate.url)) }.getOrNull()
                            }
                        }
                    }
                    if (resolved?.streamUrl != null && isCurrentQemCandidate(resolved)) {
                        preparedNext = resolved
                        break
                    }
                }

                val installedNext = preparedNext ?: run {
                    // Nothing was installed, therefore ACTIVE remains exactly as it was. Do not fake
                    // an AUTO start with an EMPTY transmission; tell the user this filter pass failed.
                    qemEngine.handoffPending = false
                    quickSessionActive = false
                    switchDiscoveryMotor(AutoDiscoveryMotor.NONE)
                    qemEngine.sessionArtistPool = emptyList()
                    binding.quickSearchingRow.visibility = View.GONE
                    binding.quickDrawerEnter.isEnabled = true
                    AlertDialog.Builder(this@MixerActivity)
                        .setMessage("No playable tracks found inside the selected fonoteka filters")
                        .setPositiveButton("OK", null)
                        .show()
                    return@launch
                }

                binding.quickSearchingText.text = "INSTALLING NEXT…"

                // STALE-OWNER KILL SWITCH. Search may have taken many seconds and a manual/automatic
                // crossfade may have changed ACTIVE meanwhile. Never trust liveActiveIsA captured above.
                // Re-read the physical truth at commit time and write only to the opposite NON-playing deck.
                val commitActiveIsA: Boolean? = when {
                    playerA.isPlaying && !playerB.isPlaying -> true
                    playerB.isPlaying && !playerA.isPlaying -> false
                    playerA.isPlaying && playerB.isPlaying -> if (cross <= 0.5f) true else false
                    else -> null
                }
                if (commitActiveIsA == null) {
                    qemEngine.queued = installedNext
                    qemEngine.handoffPending = false
                    quickSessionActive = true
                    autoEnabled = true
                    switchDiscoveryMotor(AutoDiscoveryMotor.QEM)
                    binding.quickDrawerEnter.isEnabled = true
                    return@launch
                }
                val commitNextIsA = !commitActiveIsA
                val commitTarget = if (commitNextIsA) playerA else playerB
                if (commitTarget.isPlaying) {
                    qemEngine.queued = installedNext
                    qemEngine.handoffPending = false
                    quickSessionActive = true
                    autoEnabled = true
                    switchDiscoveryMotor(AutoDiscoveryMotor.QEM)
                    binding.quickDrawerEnter.isEnabled = true
                    return@launch
                }

                // SEARCH FIRST, SWAP SECOND. installedNext already has a real resolved stream URL and
                // passed the QEM gates. Replace only the freshly verified waiting deck, never both decks.
                if (commitNextIsA) {
                    MixerStore.setA(installedNext)
                    MixerStore.waveA = null
                    lastTrackAUrl = "__QEM_LIVE_ATOMIC_A__"
                    resolvingA = null
                } else {
                    MixerStore.setB(installedNext)
                    MixerStore.waveB = null
                    lastTrackBUrl = "__QEM_LIVE_ATOMIC_B__"
                    resolvingB = null
                }
                refreshDecks(onlyIsA = commitNextIsA)

                // The chassis now looks exactly like the known-good Basic case: one deck is LIVE,
                // the opposite deck already contains the new seed and is READY. Hand this pair to
                // the SAME shared startEndlessMix() transmission. Keep quickSessionActive false only
                // during adoption so startEndlessMix() follows the physically playing deck instead of
                // forcing Quick's cold-start owner A. QEM ownership itself is already selected.
                syncSeedsFromCurrentDecks()
                quickSessionActive = false
                quickStartupGuardA = false
                suppressInitialEndlessDiscovery = true
                try {
                    startEndlessMix()
                } finally {
                    suppressInitialEndlessDiscovery = false
                }
                if (!endlessActive || !autoEnabled) {
                    qemEngine.handoffPending = false
                    binding.quickSearchingText.text = "HANDOFF FAILED"
                    binding.quickDrawerEnter.isEnabled = true
                    return@launch
                }

                // Only AFTER the shared Basic transmission has adopted A/B do we expose QEM as the
                // discovery owner. From here on QEM supplies future candidates; the physical gearbox,
                // transition engine and READY_NEXT behavior are exactly the same shared infrastructure.
                quickSessionActive = true
                qemEngine.handoffPending = false
                autoEnabled = true
                enforceAutoOwnerInvariant()

                // Ownership may have changed while search was running; publish the COMMIT-time owner,
                // not the stale entry-time snapshot.
                if (commitActiveIsA) {
                    endlessDeckStateA = EndlessDeckState.PLAYING
                    endlessDeckStateB = EndlessDeckState.READY_NEXT
                    cross = 0f; binding.crossfader.progress = 0
                } else {
                    endlessDeckStateB = EndlessDeckState.PLAYING
                    endlessDeckStateA = EndlessDeckState.READY_NEXT
                    cross = 1f; binding.crossfader.progress = 100
                }
                applyVolumes()

                // Prepare only logical Slot 2 now; the physical waiting deck is already occupied by
                // the first QEM seed and must remain sticky until its transition.
                qemEngine.waitingFreeDeck = null
                discoverQueuedCandidate()

                updateAutoButton()
                updateEndlessAction()
                updateModeButtons()
                resetQuickSelections()
                closeQuickDrawer()
                binding.quickDrawerEnter.isEnabled = true
                return@launch
            }

            // Robust QEM/PARTY cold start: always prepare TWO starters before first playback.
            // One-track PARTY cold-start was removed because it could leave the opposite deck EMPTY.
            // Both starters must be physically READY with a small safe buffer before A is allowed to play.
            val coldPartyStart = false
            val requiredStarters = 2
            val wanted = if (requiresMeasuredTempoFilter()) maxOf(requiredStarters * 5, 8) else requiredStarters
            var candidates = qemFindTracks(
                count = wanted,
                liveTrack = liveActiveTrack,
                deadlineMs = 22_000L
            )
            if (!isActive) return@launch

            if (requiresMeasuredTempoFilter() && candidates.isNotEmpty()) {
                binding.quickSearchingText.text = "CHECKING TEMPO…"
                candidates = coroutineScope {
                    candidates.take(12).map { t ->
                        async(Dispatchers.IO) {
                            val resolved = runCatching {
                                if (t.streamUrl != null) t else t.copy(streamUrl = AudioResolver.resolveBestAudioUrl(t.url))
                            }.getOrNull() ?: return@async null
                            val direct = resolved.streamUrl ?: return@async null
                            val tempo = runLowPriorityAnalysis { TempoAnalyzer.analyze(direct, cacheKey = resolved.url) }
                            if (tempo == null || isMeasuredTempoAcceptable(tempo)) resolved else null
                        }
                    }.awaitAll().filterNotNull()
                }
            }

            val found = candidates.take(requiredStarters)
            if (found.size < requiredStarters) {
                qemEngine.handoffPending = false
                quickSessionActive = false
                // QEM discovery failure is not a STOP command. If music/AUTO was already live,
                // fall back to the Basic discovery owner so the current song still gets a NEXT.
                // Only a pre-play cold start may return to NONE.
                if (endlessActive) switchDiscoveryMotor(AutoDiscoveryMotor.BASIC)
                else switchDiscoveryMotor(AutoDiscoveryMotor.NONE)
                qemEngine.sessionArtistPool = emptyList()
                binding.quickSearchingRow.visibility = View.GONE
                binding.quickDrawerEnter.isEnabled = true
                AlertDialog.Builder(this@MixerActivity)
                    .setMessage("No playable tracks found inside the selected fonoteka filters")
                    .setPositiveButton("OK", null)
                    .show()
                return@launch
            }

            // Old heuristic Quick fields are deliberately neutralized: QEM refill is now owned by
            // qemEngine.sessionArtistPool/fonoteka.json, while Basic Endless keeps its existing logic intact.
            quickSceneOverride = null
            quickSessionAnchorTerms = ""
            quickSessionStyleTerms = ""

            if (liveActiveIsA != null) {
                val nextIsA = !liveActiveIsA
                syncSeedsFromCurrentDecks()
                quickSessionActive = false
                quickStartupGuardA = false
                // Do not let shared Basic Endless refill the FREE deck during this handoff.
                // That race could inject a GLOBAL/English candidate before QEM becomes owner,
                // bypassing the selected hard REGION/STYLE pool (e.g. EX-YU + DANCE).
                suppressInitialEndlessDiscovery = true
                try {
                    startEndlessMix()
                } finally {
                    suppressInitialEndlessDiscovery = false
                }
                if (!endlessActive || !autoEnabled) {
                    binding.quickSearchingText.text = "STILL SEARCHING…"
                    binding.quickDrawerEnter.isEnabled = true
                    return@launch
                }

                // startEndlessMix is shared with Basic and may have armed its normal refill for the
                // free deck. Cancel that one race, then hand ownership to the QEM motor.
                endlessDiscoveryJob?.cancel()
                endlessDiscoveryJob = null
                endlessQueued = null
                activeWaitingFreeDeck = null
                switchDiscoveryMotor(AutoDiscoveryMotor.QEM)
                quickSessionActive = true
                qemEngine.handoffPending = false
                if (liveActiveIsA) {
                    endlessDeckStateA = EndlessDeckState.PLAYING
                    endlessDeckStateB = EndlessDeckState.FREE
                    endlessSeedProtectedB = false
                    cross = 0f; binding.crossfader.progress = 0
                } else {
                    endlessDeckStateB = EndlessDeckState.PLAYING
                    endlessDeckStateA = EndlessDeckState.FREE
                    endlessSeedProtectedA = false
                    cross = 1f; binding.crossfader.progress = 100
                }
                applyVolumes()

                binding.quickSearchingText.text = "LOADING NEXT…"
                // No READY deadline here. Once QEM has chosen a candidate, the shared loader owns
                // buffering just like Basic Endless. A slow buffer is LOADING_NEXT, never a reason
                // to manufacture FREE/EMPTY.
                loadEndlessTrackIntoDeck(nextIsA, found[0])
                activeWaitingFreeDeck = null
                discoverQueuedCandidate()
            } else {
                MixerStore.setA(found[0])
                if (coldPartyStart) {
                    // Do not manufacture a nullable TrackRef for slot B. An empty B is represented
                    // by the nullable store field itself; the QEM motor will fill it after A starts.
                    MixerStore.deckB = null
                    MixerStore.waveB = null
                } else {
                    MixerStore.setB(found[1])
                }
                cross = 0f; binding.crossfader.progress = 0; applyVolumes()
                // Startup is a two-deck preload barrier: neither player may autoplay while
                // refreshDecks attaches the two starter media items. This prevents the first
                // deck from audibly starting on a thin buffer before B is READY_NEXT.
                playerA.playWhenReady = false
                playerB.playWhenReady = false
                playerA.pause()
                playerB.pause()
                refreshDecks(force = true)

                if (!coldPartyStart) {
                    binding.quickSearchingText.text = "LOADING 2/2…"
                    while (isActive && (
                            playerA.mediaItemCount == 0 || playerA.playbackState != Player.STATE_READY ||
                            (playerA.bufferedPosition - playerA.currentPosition) < 2_500L ||
                            playerB.mediaItemCount == 0 || playerB.playbackState != Player.STATE_READY ||
                            (playerB.bufferedPosition - playerB.currentPosition) < 2_500L
                        )) {
                        if (playerA.isPlaying) playerA.pause()
                        if (playerB.isPlaying) playerB.pause()
                        delay(100L)
                    }
                    if (!isActive) return@launch
                } else {
                    binding.quickSearchingText.text = "STARTING…"
                }

                syncSeedsFromCurrentDecks()
                quickSessionActive = true
                qemEngine.handoffPending = false
                quickStartupGuardA = true
                switchDiscoveryMotor(AutoDiscoveryMotor.QEM)
                startEndlessMix()
                if (!endlessActive || !autoEnabled) {
                    quickSessionActive = false
                    quickStartupGuardA = false
                    binding.quickSearchingText.text = "STILL SEARCHING…"
                    binding.quickDrawerEnter.isEnabled = true
                    return@launch
                }
                playerB.pause(); playerB.playWhenReady = false
                endlessDeckStateA = EndlessDeckState.PLAYING
                if (coldPartyStart) {
                    endlessDeckStateB = EndlessDeckState.FREE
                    endlessSeedProtectedB = false
                    // PARTY cold-start handoff: B is physically EMPTY, so never reserve it through
                    // activeWaitingFreeDeck. Let the QEM no-empty law own the real chassis slot.
                    // The first kick can happen before A has actually entered isPlaying, therefore
                    // re-kick continuity just after playback starts as well.
                    activeWaitingFreeDeck = null
                    qemEngine.waitingFreeDeck = null
                    discoverQueuedCandidate()
                    lifecycleScope.launch {
                        delay(250L)
                        if (endlessActive && autoEnabled && autoDiscoveryMotor == AutoDiscoveryMotor.QEM &&
                            MixerStore.deckB == null && playerA.isPlaying) {
                            protectEndlessContinuity()
                        }
                    }
                } else {
                    endlessDeckStateB = EndlessDeckState.READY_NEXT
                }
                cross = 0f; binding.crossfader.progress = 0; applyVolumes()
                if (!playerA.isPlaying) {
                    if (playerA.playbackState == Player.STATE_READY) playerA.play()
                    else { pendingEndlessStart = true; pendingEndlessStartIsA = true }
                }
            }

            updateAutoButton()
            updateEndlessAction()
            resetQuickSelections()
            closeQuickDrawer()
        }
    }

    private fun quickStarterPassesHardGuards(track: TrackRef, sceneOverride: EndlessSceneProfile?): Boolean {
        if (looksLikeNarrativeNonSong(track) || looksLikeProgramOrCompilation(track)) return false
        val text = canonicalCompareText("${track.title} ${track.uploader}")
        val hardBlockedWords = listOf(
            "karaoke", "reaction", "tutorial", "full album", "playlist", "instrumental karaoke",
            "interview", "intervju", "podcast", "talk", "conversation", "gostovanje", "gost u",
            "emisija", "behind the scenes", "documentary", "dokumentar", "press conference",
            "q a", "review", "recenzija", "razgovor", "radio emisija", "tv emisija", "dnevnik",
            "vesti", "vijesti", "news", "breaking", "reportaza", "reportaža"
        )
        if (hardBlockedWords.any { it in text }) return false

        // QUICK REGION is a hard gate exactly like Endless region DNA. Unknown/global evidence is
        // rejected when a concrete region was selected; it may not sneak through on popularity.
        if (sceneOverride != null) {
            val candidateScene = classifyTrackScene(track)
            if (candidateScene != sceneOverride) return false
        }

        // Reuse the Endless POP/POP-FOLK/FOLK hard genre behavior for starter selection too.
        // Other QUICK style tokens remain search constraints and become the seed DNA once started.
        val selected = quickStyles.map { canonicalCompareText(it) }
        if (selected.isNotEmpty()) {
            val oldProfile = endlessGenreProfile
            val profile = when {
                selected.any { it == "folk" } && selected.none { "pop folk" in it } -> EndlessGenreProfile.FOLK
                selected.any { "pop folk" in it } -> EndlessGenreProfile.POP_FOLK
                selected.any { it == "pop" || it == "rock" || it == "hard rock" } -> EndlessGenreProfile.POP
                else -> null
            }
            if (profile != null) {
                endlessGenreProfile = profile
                val rejected = violatesLockedGenre(track)
                endlessGenreProfile = oldProfile
                if (rejected) return false
            }
        }
        return true
    }

    private fun showOneArtistMixPopup() {
        val input = EditText(this).apply {
            hint = "Artist name"
            isSingleLine = true
            textSize = 20f
            setPadding(dp(20), dp(12), dp(20), dp(12))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("1 ARTIST MIX")
            .setView(input)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("START", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val artist = input.text.toString().trim()
                if (artist.isBlank()) return@setOnClickListener
                dialog.dismiss()
                startOneArtistMix(artist)
            }
        }
        dialog.show()
    }

    private fun startOneArtistMix(query: String) {
        val known = qemFonoteka.resolveArtist(query)
        if (known != null) startKnownOneArtistMix(known) else startLegacyOneArtistMix(query)
    }

    private fun startKnownOneArtistMix(artist: QemFonoteka.ArtistChoice) {
        if (endlessActive) stopEndlessMix() // preserves ACTIVE playback by design
        oneArtistMixActive = true
        quickSessionActive = true
        switchDiscoveryMotor(AutoDiscoveryMotor.QEM)
        qemEngine.sessionArtistPool = listOf(artist)
        qemEngine.sessionStyleKeys = emptySet()
        qemEngine.sessionEraKeys = emptySet()
        qemEngine.sessionInstrumental = false
        qemEngine.sessionPiano = false
        qemEngine.filterFingerprint = "ONE_ARTIST|${artist.id}|${normalizeArtistText(artist.name)}"
        qemEngine.recentArtistIds.clear()
        qemEngine.trackArtistIds.clear()
        qemEngine.candidateStamps.clear()
        quickSessionTempoBand = tempoBand
        quickLongFormDuration = false
        updateModeButtons()

        lifecycleScope.launch {
            val liveIsA: Boolean? = when {
                playerA.isPlaying && !playerB.isPlaying -> true
                playerB.isPlaying && !playerA.isPlaying -> false
                playerA.isPlaying && playerB.isPlaying -> cross <= 0.5f
                else -> null
            }
            val liveTrack = when (liveIsA) { true -> MixerStore.deckA; false -> MixerStore.deckB; null -> null }
            // Live 1-ARTIST asks for several choices so a dead URL can be discarded off-deck
            // without ever sacrificing the currently parked NEXT.
            val wanted = if (liveIsA == null) 2 else 4
            val found = qemFindTracks(wanted, liveTrack, 18_000L)
            val minimumNeeded = if (liveIsA == null) 2 else 1
            if (found.size < minimumNeeded) {
                oneArtistMixActive = false
                quickSessionActive = false
                qemEngine.sessionArtistPool = emptyList()
                updateModeButtons()
                AlertDialog.Builder(this@MixerActivity).setMessage("No playable songs found for ${artist.name}").setPositiveButton("OK", null).show()
                return@launch
            }

            if (liveIsA != null) {
                val nextIsA = !liveIsA

                // SAME LAW AS QEM2: discovery/resolve/validation happens completely off-deck.
                // The old parking track is untouched until a real stream exists.
                var preparedNext: TrackRef? = null
                for (candidate in found) {
                    if (!isCurrentQemCandidate(candidate)) continue
                    val resolved = if (candidate.streamUrl != null) candidate else withTimeoutOrNull(8_000L) {
                        withContext(Dispatchers.IO) {
                            runCatching { candidate.copy(streamUrl = AudioResolver.resolveBestAudioUrl(candidate.url)) }.getOrNull()
                        }
                    }
                    val direct = resolved?.streamUrl ?: continue
                    if (requiresMeasuredTempoFilter()) {
                        val tempo = runLowPriorityAnalysis { TempoAnalyzer.analyze(direct, cacheKey = resolved.url) }
                        if (tempo != null && !isMeasuredTempoAcceptable(tempo)) continue
                    }
                    if (isCurrentQemCandidate(resolved)) {
                        preparedNext = resolved
                        break
                    }
                }

                val installedNext = preparedNext
                if (installedNext == null) {
                    // Candidate failed before the swap: keep the existing parked song exactly as-is.
                    oneArtistMixActive = false
                    quickSessionActive = false
                    qemEngine.sessionArtistPool = emptyList()
                    switchDiscoveryMotor(AutoDiscoveryMotor.NONE)
                    updateModeButtons()
                    AlertDialog.Builder(this@MixerActivity)
                        .setMessage("No playable songs found for ${artist.name}")
                        .setPositiveButton("OK", null)
                        .show()
                    return@launch
                }

                // Atomic parking replacement: no clearMediaItems(), no deck=null and no FREE gap
                // before the new song has already been found and resolved.
                if (nextIsA) {
                    MixerStore.setA(installedNext)
                    MixerStore.waveA = null
                    lastTrackAUrl = "__ONE_ARTIST_ATOMIC_A__"
                    resolvingA = null
                } else {
                    MixerStore.setB(installedNext)
                    MixerStore.waveB = null
                    lastTrackBUrl = "__ONE_ARTIST_ATOMIC_B__"
                    resolvingB = null
                }
                refreshDecks()

                quickSessionActive = false
                syncSeedsFromCurrentDecks()
                startEndlessMix()
                endlessDiscoveryJob?.cancel(); endlessDiscoveryJob = null
                activeWaitingFreeDeck = null
                quickSessionActive = true
                oneArtistMixActive = true
                switchDiscoveryMotor(AutoDiscoveryMotor.QEM)
                qemEngine.sessionArtistPool = listOf(artist)
                if (liveIsA) {
                    endlessDeckStateA = EndlessDeckState.PLAYING
                    endlessDeckStateB = if (playerB.playbackState == Player.STATE_READY) EndlessDeckState.READY_NEXT else EndlessDeckState.LOADING_NEXT
                } else {
                    endlessDeckStateB = EndlessDeckState.PLAYING
                    endlessDeckStateA = if (playerA.playbackState == Player.STATE_READY) EndlessDeckState.READY_NEXT else EndlessDeckState.LOADING_NEXT
                }
                discoverQueuedCandidate()
            } else {
                MixerStore.setA(found[0]); MixerStore.setB(found[1])
                cross = 0f; binding.crossfader.progress = 0; applyVolumes()
                refreshDecks(force = true)
                while (isActive && (playerA.mediaItemCount == 0 || playerB.mediaItemCount == 0 ||
                            playerA.playbackState != Player.STATE_READY || playerB.playbackState != Player.STATE_READY)) delay(100L)
                if (!isActive) return@launch
                quickSessionActive = true
                oneArtistMixActive = true
                syncSeedsFromCurrentDecks()
                startEndlessMix()
                playerB.pause(); playerB.playWhenReady = false
                endlessDeckStateA = EndlessDeckState.PLAYING
                endlessDeckStateB = EndlessDeckState.READY_NEXT
            }
            updateModeButtons()
        }
    }

    private fun startLegacyOneArtistMix(query: String) {
        if (endlessActive) stopEndlessMix()
        oneArtistMixActive = true
        quickSessionActive = false
        switchDiscoveryMotor(AutoDiscoveryMotor.BASIC)
        updateModeButtons()
        lifecycleScope.launch {
            val tracks = withContext(Dispatchers.IO) {
                val typeHint = buildList {
                    if (allowLive) add("live")
                    if (allowCover) add("cover")
                    if (onlyOfficial) add("official")
                }.joinToString(" ").ifBlank { "official" }
                runCatching { searchRepo.search("$query $typeHint music songs") }.getOrDefault(emptyList())
            }
            val needle = canonicalCompareText(query)
            val found = tracks.asSequence()
                .filter { !looksLikeNarrativeNonSong(it) && !looksLikeProgramOrCompilation(it) }
                .filter { needle in canonicalCompareText("${it.title} ${it.uploader}") }
                .distinctBy(::endlessTrackKey)
                .take(2).toList()
            if (found.size < 2) {
                oneArtistMixActive = false
                updateModeButtons()
                AlertDialog.Builder(this@MixerActivity).setMessage("Artist not in fonoteka and old motor could not find two playable songs.").setPositiveButton("OK", null).show()
                return@launch
            }
            val liveIsA = when { playerA.isPlaying && !playerB.isPlaying -> true; playerB.isPlaying && !playerA.isPlaying -> false; else -> null }
            if (liveIsA == null) {
                MixerStore.setA(found[0]); MixerStore.setB(found[1]); refreshDecks(force = true)
                while (isActive && (playerA.playbackState != Player.STATE_READY || playerB.playbackState != Player.STATE_READY)) delay(100L)
                syncSeedsFromCurrentDecks(); startEndlessMix()
            } else {
                val nextIsA = !liveIsA
                if (nextIsA) MixerStore.setA(found[0]) else MixerStore.setB(found[0])
                refreshDecks()
                syncSeedsFromCurrentDecks(); startEndlessMix()
            }
            // Explicitly lock old discovery to the requested artist after adoption/start.
            endlessArtistOnlyMode = true
            endlessArtistOnlySeed = found.first()
            oneArtistMixActive = true
            updateModeButtons()
        }
    }

    private fun updateModeButtons() {
        if (!::binding.isInitialized) return
        // UI follows the authoritative discovery owner, not a fragile session mirror.
        if (endlessActive) enforceAutoOwnerInvariant()
        val basic = endlessActive && autoDiscoveryMotor == AutoDiscoveryMotor.BASIC && !oneArtistMixActive
        val qem = endlessActive && autoDiscoveryMotor == AutoDiscoveryMotor.QEM && !oneArtistMixActive
        val artist = endlessActive && oneArtistMixActive

        binding.basicEndlessButton.text = "ENDLESS MIX"
        binding.quickEndlessButton.text = if (qem) "CHANGE QUICK MIX" else "QUICK ENDLESS MIX"
        binding.oneArtistMixButton.text = "1 ARTIST MIX"

        fun styleModeButton(button: android.widget.Button, active: Boolean, activeBg: Int, activeText: Int) {
            button.backgroundTintList = null
            button.setBackgroundResource(if (active) activeBg else R.drawable.lux_worn_gunmetal_button)
            button.setTextColor(ContextCompat.getColor(this, if (active) activeText else R.color.lux_silver))
            button.alpha = 1f
            button.elevation = dp(6).toFloat()
        }

        styleModeButton(binding.basicEndlessButton, basic, R.drawable.lux_blue_button, R.color.white)
        styleModeButton(binding.quickEndlessButton, qem, R.drawable.lux_gold_button, R.color.black)
        styleModeButton(binding.oneArtistMixButton, artist, R.drawable.lux_green_button, R.color.black)
    }

    private fun updateContextualModeUi() {
        if (!::binding.isInitialized) return
        val twoUsable = MixerStore.deckA != null && MixerStore.deckB != null && playerA.mediaItemCount > 0 && playerB.mediaItemCount > 0
        binding.startEndlessAutoMix.visibility = if (!endlessActive && !quickDrawerOpen && twoUsable) View.VISIBLE else View.GONE
        binding.modeButtonRow.visibility = if (!quickDrawerOpen && binding.endlessSearchPanel.visibility != View.VISIBLE) View.VISIBLE else View.GONE
        binding.endlessAction.visibility = View.GONE
        updateModeButtons()
    }

    private fun normalizeInstantNextWaitingDeckState() {
        // After many rapid manual NEXT transitions, the parked deck can remain logically tagged
        // PLAYING even though it is physically not playing anymore and ExoPlayer is READY.
        // AUTO tolerates that because deckReadyForAuto() accepts PLAYING, but contextual NEXT
        // arrows require READY_NEXT. Normalize that desync before visibility checks.
        if (!endlessActive || autoFadeJob?.isActive == true) return
        if (playerA.isPlaying && !playerB.isPlaying && playerB.mediaItemCount > 0 && playerB.playbackState == Player.STATE_READY && endlessDeckStateB == EndlessDeckState.PLAYING) {
            endlessDeckStateB = EndlessDeckState.READY_NEXT
        }
        if (playerB.isPlaying && !playerA.isPlaying && playerA.mediaItemCount > 0 && playerA.playbackState == Player.STATE_READY && endlessDeckStateA == EndlessDeckState.PLAYING) {
            endlessDeckStateA = EndlessDeckState.READY_NEXT
        }
    }

    private fun canInstantNext(fromA: Boolean): Boolean {
        // NEXT belongs to MASTER AUTO, not to a particular discovery motor. It therefore works
        // in Basic Endless, QEM, 1 ARTIST MIX and ordinary two-deck AUTO whenever NEXT is safe.
        normalizeInstantNextWaitingDeckState()
        if (!autoEnabled || autoFadeJob?.isActive == true) return false
        val source = if (fromA) playerA else playerB
        val target = if (fromA) playerB else playerA
        if (!source.isPlaying || target.mediaItemCount == 0 || target.playbackState != Player.STATE_READY) return false
        return if (endlessActive) {
            val state = if (fromA) endlessDeckStateB else endlessDeckStateA
            state == EndlessDeckState.READY_NEXT
        } else {
            deckReadyForAuto(target)
        }
    }

    private fun updateInstantNextButtons() {
        if (!::binding.isInitialized) return
        val fromA = canInstantNext(true)
        val fromB = canInstantNext(false)
        binding.instantNextA.visibility = if (fromA) View.VISIBLE else View.INVISIBLE
        binding.instantNextB.visibility = if (fromB) View.VISIBLE else View.INVISIBLE
        // NEXT remains intentionally usable under LOCK.
        binding.instantNextA.isEnabled = fromA
        binding.instantNextB.isEnabled = fromB
    }

    private fun launchSpeechRecognizer() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Search music")
        }
        runCatching { speechLauncher.launch(intent) }
            .onFailure { binding.endlessStatus.text = "Voice search unavailable" }
    }

    private fun formatTime(ms: Long): String {
        val total = (ms / 1000L).coerceAtLeast(0L)
        val m = total / 60
        val s = total % 60
        return "%d:%02d".format(m, s)
    }


    /** UI-only reattachment used after Android recreates MixerActivity while PlaybackRuntime lives. */
    private fun bindDeckUiToSurvivingRuntime() {
        fun bind(isA: Boolean) {
            val track = if (isA) MixerStore.deckA else MixerStore.deckB
            val player = if (isA) playerA else playerB
            val title = if (isA) binding.titleA else binding.titleB
            val play = if (isA) binding.playA else binding.playB
            val wave = if (isA) binding.waveA else binding.waveB
            val time = if (isA) binding.timeA else binding.timeB
            title.text = track?.title ?: "EMPTY"
            play.isEnabled = track != null
            updatePlayButton(isA)
            if (track == null) {
                wave.setEmpty()
                time.text = ""
            } else {
                wave.setTrackPresent(true)
                val cached = if (isA) MixerStore.waveA else MixerStore.waveB
                if (cached != null) wave.setWaveform(cached, 1f)
            }
            if (isA) lastTrackAUrl = track?.url else lastTrackBUrl = track?.url

            // Reconstruct only physical deck truth. Never stop/clear a surviving MediaItem here.
            val state = when {
                player.isPlaying -> EndlessDeckState.PLAYING
                track == null || player.mediaItemCount == 0 -> EndlessDeckState.FREE
                player.playbackState == Player.STATE_READY -> EndlessDeckState.READY_NEXT
                else -> EndlessDeckState.LOADING_NEXT
            }
            if (isA) endlessDeckStateA = state else endlessDeckStateB = state
        }
        bind(true)
        bind(false)
        updateLoadButtons()
        updateInstantNextButtons()
        updateModeButtons()
    }

    private fun trackToJson(t: TrackRef): JSONObject = JSONObject().apply {
        put("title", t.title); put("uploader", t.uploader); put("url", t.url)
        put("durationSeconds", t.durationSeconds); put("streamUrl", t.streamUrl ?: JSONObject.NULL)
        put("viewCount", t.viewCount); put("uploaderVerified", t.uploaderVerified)
    }

    private fun trackFromJson(o: JSONObject): TrackRef = TrackRef(
        title = o.optString("title"), uploader = o.optString("uploader"), url = o.optString("url"),
        durationSeconds = o.optLong("durationSeconds"),
        streamUrl = o.optString("streamUrl").takeIf { it.isNotBlank() && it != "null" },
        viewCount = o.optLong("viewCount", -1L), uploaderVerified = o.optBoolean("uploaderVerified", false)
    )

    private fun restoreMixerControllerState(state: Bundle) {
        endlessActive = state.getBoolean(STATE_ENDLESS_ACTIVE, endlessActive)
        autoEnabled = state.getBoolean(STATE_AUTO_ENABLED, autoEnabled)
        controlsLocked = state.getBoolean(STATE_CONTROLS_LOCKED, controlsLocked)
        oneArtistMixActive = state.getBoolean(STATE_ONE_ARTIST, oneArtistMixActive)
        quickSessionActive = state.getBoolean(STATE_QUICK_ACTIVE, quickSessionActive)
        autoDiscoveryMotor = runCatching {
            AutoDiscoveryMotor.valueOf(state.getString(STATE_MOTOR) ?: AutoDiscoveryMotor.NONE.name)
        }.getOrDefault(if (quickSessionActive) AutoDiscoveryMotor.QEM else if (endlessActive) AutoDiscoveryMotor.BASIC else AutoDiscoveryMotor.NONE)
        qemSessionDanceMode = runCatching {
            QemDanceMode.valueOf(state.getString(STATE_DANCE_MODE) ?: QemDanceMode.NONE.name)
        }.getOrDefault(QemDanceMode.NONE)
        aiDjVoiceEnabled = state.getBoolean(STATE_AI_DJ_ENABLED, true)
        deckZMixCounter = state.getInt(STATE_AI_DJ_MIX_COUNTER, 0)
        updateDeckZButton()
        qemEngine.sessionStyleKeys = state.getStringArrayList(STATE_QEM_STYLES)?.toSet().orEmpty()
        qemEngine.sessionEraKeys = state.getStringArrayList(STATE_QEM_ERAS)?.toSet().orEmpty()
        qemEngine.sessionInstrumental = state.getBoolean(STATE_QEM_INSTRUMENTAL, false)
        qemEngine.sessionPiano = state.getBoolean(STATE_QEM_PIANO, false)
        qemEngine.filterFingerprint = state.getString(STATE_QEM_FINGERPRINT).orEmpty()
        quickSessionTempoBand = state.getString(STATE_QEM_TEMPO_BAND)
        quickSessionAnchorTerms = state.getString(STATE_QEM_ANCHOR).orEmpty()
        quickSessionStyleTerms = state.getString(STATE_QEM_STYLE_TERMS).orEmpty()
        quickLongFormDuration = state.getBoolean(STATE_QEM_LONG_FORM, false)
        quickCountry = state.getString(STATE_QUICK_COUNTRY)
        quickSceneOverride = state.getString(STATE_QUICK_SCENE)?.let { n ->
            runCatching { EndlessSceneProfile.valueOf(n) }.getOrNull()
        }
        quickStartupGuardA = state.getBoolean(STATE_QUICK_GUARD_A, false)
        endlessSeedProtectedA = state.getBoolean(STATE_SEED_PROTECTED_A, false)
        endlessSeedProtectedB = state.getBoolean(STATE_SEED_PROTECTED_B, false)
        endlessManualProtectedA = state.getBoolean(STATE_MANUAL_PROTECTED_A, false)
        endlessManualProtectedB = state.getBoolean(STATE_MANUAL_PROTECTED_B, false)
        endlessDeckHasPlayedA = state.getBoolean(STATE_HAS_PLAYED_A, playerA.isPlaying)
        endlessDeckHasPlayedB = state.getBoolean(STATE_HAS_PLAYED_B, playerB.isPlaying)
        endlessManualUrls.clear()
        endlessManualUrls.addAll(state.getStringArrayList(STATE_MANUAL_URLS).orEmpty())

        state.getString(STATE_ENDLESS_SEEDS)?.let { raw ->
            runCatching {
                val arr = JSONArray(raw)
                endlessSeeds.clear()
                for (i in 0 until arr.length()) endlessSeeds += trackFromJson(arr.getJSONObject(i))
            }
        }
        state.getString(STATE_QEM_POOL)?.let { raw ->
            runCatching {
                val arr = JSONArray(raw)
                qemEngine.sessionArtistPool = buildList {
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val cc = o.optJSONArray("countries") ?: JSONArray()
                        val countries = buildList { for (j in 0 until cc.length()) add(cc.optString(j)) }
                        add(QemFonoteka.ArtistChoice(
                            id = o.optString("id"), name = o.optString("name"), rank = o.optInt("rank"),
                            region = o.optString("region"), style = o.optString("style"), era = o.optString("era"),
                            countries = countries
                        ))
                    }
                }
            }
        }

        // If QEM was active but Android delivered an incomplete Bundle, fail safe by keeping music
        // alive under BASIC discovery rather than killing AUTO or silently widening QEM filters.
        if (endlessActive && autoEnabled && autoDiscoveryMotor == AutoDiscoveryMotor.QEM && qemEngine.sessionArtistPool.isEmpty()) {
            quickSessionActive = false
            autoDiscoveryMotor = AutoDiscoveryMotor.BASIC
        }
        updateControlLockUi()
        updateCrossfadeButton()
        applyVolumes()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putFloat(STATE_CROSS, cross)
        outState.putBoolean(STATE_ENDLESS_ACTIVE, endlessActive)
        outState.putBoolean(STATE_AUTO_ENABLED, autoEnabled)
        outState.putBoolean(STATE_CONTROLS_LOCKED, controlsLocked)
        outState.putBoolean(STATE_ONE_ARTIST, oneArtistMixActive)
        outState.putBoolean(STATE_QUICK_ACTIVE, quickSessionActive)
        outState.putString(STATE_MOTOR, autoDiscoveryMotor.name)
        outState.putString(STATE_DANCE_MODE, qemSessionDanceMode.name)
        outState.putStringArrayList(STATE_QEM_STYLES, ArrayList(qemEngine.sessionStyleKeys))
        outState.putStringArrayList(STATE_QEM_ERAS, ArrayList(qemEngine.sessionEraKeys))
        outState.putBoolean(STATE_QEM_INSTRUMENTAL, qemEngine.sessionInstrumental)
        outState.putBoolean(STATE_QEM_PIANO, qemEngine.sessionPiano)
        outState.putString(STATE_QEM_FINGERPRINT, qemEngine.filterFingerprint)
        outState.putString(STATE_QEM_TEMPO_BAND, quickSessionTempoBand)
        outState.putString(STATE_QEM_ANCHOR, quickSessionAnchorTerms)
        outState.putString(STATE_QEM_STYLE_TERMS, quickSessionStyleTerms)
        outState.putBoolean(STATE_QEM_LONG_FORM, quickLongFormDuration)
        outState.putString(STATE_QUICK_COUNTRY, quickCountry)
        outState.putString(STATE_QUICK_SCENE, quickSceneOverride?.name)
        outState.putBoolean(STATE_QUICK_GUARD_A, quickStartupGuardA)
        outState.putBoolean(STATE_SEED_PROTECTED_A, endlessSeedProtectedA)
        outState.putBoolean(STATE_SEED_PROTECTED_B, endlessSeedProtectedB)
        outState.putBoolean(STATE_MANUAL_PROTECTED_A, endlessManualProtectedA)
        outState.putBoolean(STATE_MANUAL_PROTECTED_B, endlessManualProtectedB)
        outState.putBoolean(STATE_HAS_PLAYED_A, endlessDeckHasPlayedA)
        outState.putBoolean(STATE_HAS_PLAYED_B, endlessDeckHasPlayedB)
        outState.putStringArrayList(STATE_MANUAL_URLS, ArrayList(endlessManualUrls))
        outState.putString(STATE_ENDLESS_SEEDS, JSONArray().apply { endlessSeeds.forEach { put(trackToJson(it)) } }.toString())
        outState.putBoolean(STATE_AI_DJ_ENABLED, aiDjVoiceEnabled)
        outState.putInt(STATE_AI_DJ_MIX_COUNTER, deckZMixCounter)
        outState.putString(STATE_QEM_POOL, JSONArray().apply {
            qemEngine.sessionArtistPool.forEach { a ->
                put(JSONObject().apply {
                    put("id", a.id); put("name", a.name); put("rank", a.rank); put("region", a.region)
                    put("style", a.style); put("era", a.era); put("countries", JSONArray(a.countries))
                })
            }
        }.toString())
    }

    override fun onPause() {
        // Power/screen-off and backgrounding must never leave a stale WebView frame behind.
        // A/B audio keeps running; only the visual screensaver layer is destroyed.
        if (videoScreensaverOverlay != null) {
            flight("VIDEO_SS_PAUSE_DISMISS")
            dismissVideoScreensaver()
        }
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized) {
            refreshDecks()
            if (!endlessActive && !endlessSeedMode) syncSeedsFromCurrentDecks()
            if (videoScreensaverOverlay != null) refreshVideoScreensaverActive()
        }
    }

    override fun onDestroy() {
        flight("ACTIVITY_ON_DESTROY finishing=$isFinishing changing=$isChangingConfigurations Aplay=${playerA.isPlaying} Bplay=${playerB.isPlaying}")
        // UI listeners must never pin a dead Activity. The actual players live in PlaybackRuntime
        // while the foreground playback guard is running, so background navigation cannot kill audio.
        playerListenerA?.let { playerA.removeListener(it) }
        playerListenerB?.let { playerB.removeListener(it) }
        playerListenerA = null
        playerListenerB = null
        videoScreensaverJob?.cancel()
        videoScreensaverJob = null
        videoScreensaverWatcherJob?.cancel()
        videoScreensaverWatcherJob = null
        videoScreensaverWebView?.destroy()
        videoScreensaverWebView = null
        videoScreensaverOverlay = null
        if (::qemFreeDeckWatchdog.isInitialized) qemFreeDeckWatchdog.stopAll()
        deckZController.shutdown()
        if (!ForegroundPlaybackService.isRunning) {
            autoFadeJob?.cancel()
            endlessDiscoveryJob?.cancel()
            if (::audioFocusRequest.isInitialized) audioManager.abandonAudioFocusRequest(audioFocusRequest)
            PlaybackRuntime.releaseAll()
        }
        super.onDestroy()
    }
}
