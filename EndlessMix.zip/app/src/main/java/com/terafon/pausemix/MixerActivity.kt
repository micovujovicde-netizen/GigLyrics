package com.terafon.pausemix

import android.Manifest
import android.util.DisplayMetrics
import android.content.res.Configuration
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.media.AudioManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.os.Bundle
import android.os.SystemClock
import android.os.Process
import android.speech.RecognizerIntent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Space
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.recyclerview.widget.LinearLayoutManager
import com.terafon.pausemix.databinding.ActivityMixerBinding
import com.terafon.pausemix.model.MixerStore
import com.terafon.pausemix.model.TrackRef
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.text.Normalizer
import java.util.Locale
import org.json.JSONObject
import kotlin.math.roundToInt
import kotlin.random.Random

class MixerActivity : AppCompatActivity() {
    /**
     * PHONE = same mixer canvas as TABLET.
     * On narrow phones we lower only this Activity's logical density so the exact same
     * mixer window/layout fits on screen instead of crushing fixed controls.
     * No playback/discovery logic is changed.
     */
    override fun attachBaseContext(newBase: Context) {
        val baseRes = newBase.resources
        val baseConfig = baseRes.configuration
        if (baseConfig.smallestScreenWidthDp < 600) {
            val config = Configuration(baseConfig)
            val widthPx = baseRes.displayMetrics.widthPixels.coerceAtLeast(1)
            val targetCanvasWidthDp = 600f
            val density = widthPx / targetCanvasWidthDp
            config.densityDpi = (density * DisplayMetrics.DENSITY_DEFAULT)
                .roundToInt()
                .coerceIn(120, 320)
            super.attachBaseContext(newBase.createConfigurationContext(config))
        } else {
            super.attachBaseContext(newBase)
        }
    }

    private enum class EndlessGenreProfile { POP, POP_FOLK, FOLK }
    private enum class EndlessDeckState { FREE, LOADING_NEXT, READY_NEXT, PLAYING }
    private enum class AutoDiscoveryMotor { NONE, BASIC, QEM }
    private enum class EndlessSceneProfile {
        GLOBAL, EX_YU, ANGLO, FRANCOPHONE, HISPANIC, LUSOPHONE, DACH, ITALIAN,
        GREEK, TURKISH, ARABIC, SOUTH_ASIAN, EAST_SLAVIC, KOREAN, JAPANESE
    }

    private lateinit var binding: ActivityMixerBinding
    private lateinit var playerA: ExoPlayer
    private lateinit var playerB: ExoPlayer
    private var playerListenerA: Player.Listener? = null
    private var playerListenerB: Player.Listener? = null
    private lateinit var endlessAdapter: SearchAdapter

    private val searchRepo = SearchRepository()
    private val qemFonoteka by lazy { QemFonoteka(this) }
    private val artistArtworkRepository by lazy { ArtistArtworkRepository(this) }
    private var artistArtworkJobA: Job? = null
    private var artistArtworkJobB: Job? = null
    private var artistArtworkTrackA: String? = null
    private var artistArtworkTrackB: String? = null
    private var artistArtworkShownA = false
    private var artistArtworkShownB = false

    // PLAYBACK PRIORITY LADDER:
    // ACTIVE audio > READY_NEXT preparation > discovery/refill > waveform/BPM analysis > UI.
    // Heavy analysis remains capped, but it must never starve the waiting deck long enough
    // to create dead air. Basic Endless selection behavior is unchanged.
    private val analysisSlots = Semaphore(2)

    private var userVolA = 1f
    private var userVolB = 1f
    private var measuredRmsA: Float? = null
    private var measuredRmsB: Float? = null
    private val loudnessTargetRms = 0.18f
    // Only genuinely near-silent/broken sources are rejected. Validation happens during early preload.
    private val minimumEndlessRms = 0.035f
    private var allowLive = false
    private var allowCover = false
    private var onlyOfficial = false
    private var crossfadeEnabled = true
    private var cross = 0f

    private var lastTrackAUrl: String? = null
    private var lastTrackBUrl: String? = null
    private var analyzingA: String? = null
    private var analyzingB: String? = null
    private var resolvingA: String? = null
    private var resolvingB: String? = null
    private var autoEnabled = false
    private var autoFadeJob: Job? = null
    private val autoTriggerMs = 12_000L
    private val autoFadeMs = 3_000L

    private var controlsLocked = false
    private var masterDuck = 1f
    private var masterVolume = 1f
    private var masterMuted = false
    // LOCK safety: MUTE reveals PAUSE; PAUSE preserves the loaded mix and becomes PLAY.
    private var lockedSafetyStopped = false
    private var lockedSafetyResumeA = false
    private var lockedSafetyResumeB = false
    private var lockedSafetyAutoWasEnabled = false
    private var resumeAAfterFocus = false
    private var resumeBAfterFocus = false
    private lateinit var audioManager: AudioManager
    private lateinit var audioFocusRequest: AudioFocusRequest

    private var endlessSeedMode = false
    private var endlessActive = false
    private var pendingEndlessStart = false
    private var pendingEndlessStartIsA: Boolean? = null
    private val endlessSeeds = mutableListOf<TrackRef>()
    private val endlessUsedUrls = linkedSetOf<String>()
    private val endlessUsedTrackKeys = linkedSetOf<String>()
    private val endlessSeedArtistKeys = linkedSetOf<String>()
    private var endlessNonSeedSelections = 0
    private val endlessPlayedAutoUrls = linkedSetOf<String>()
    private var endlessGenreProfile = EndlessGenreProfile.POP
    private var endlessSceneProfile = EndlessSceneProfile.GLOBAL
    private var endlessArtistOnlyMode = false
    private var endlessArtistOnlySeed: TrackRef? = null
    private var endlessArtistAllowLongTracks = false
    private val endlessArtistReplayQueue = ArrayDeque<TrackRef>()
    private val endlessRecent = mutableListOf<TrackRef>()
    private val endlessRecentArtists = mutableListOf<String>()
    // Session playback history. Only tracks that actually become audible are recorded here.
    // AUTO may repeat an artist only after three other songs have played; a played song title
    // is hard-blocked for the rest of this Endless session. Manual ADD TO MIX bypasses selection gates.
    private val endlessPlayedSongKeys = linkedSetOf<String>()
    private val endlessPlayedArtistHistory = mutableListOf<TrackRef>()
    // Kept as the compact last-three view used by existing discovery/anchor code.
    private val endlessPlayedArtistCooldown = mutableListOf<TrackRef>()

    // Persistent playback history survives new Endless mixes and app restarts.
    // A played song loses ranking for the NEXT five mixes, then returns to normal ranking.
    // Artist history is a softer cross-mix diversity hint; the hard 3-song cooldown remains session-only.
    private val persistentSongLastPlayedMix = mutableMapOf<String, Int>()
    private val persistentArtistLastPlayedMix = mutableMapOf<String, Int>()
    private var persistentMixNumber = 0
    private val playbackHistoryPrefs by lazy { getSharedPreferences("endless_playback_history", MODE_PRIVATE) }

    // BASIC and QEM discovery are deliberately isolated. They share only the physical A/B
    // playback/transition infrastructure; candidates/jobs may never cross a mode boundary.
    private var autoDiscoveryMotor = AutoDiscoveryMotor.NONE
    private var endlessQueued: TrackRef? = null // BASIC Slot 2 only
    private var qemQueued: TrackRef? = null     // QEM Slot 2 only
    private var basicWaitingFreeDeck: Boolean? = null
    private var qemWaitingFreeDeck: Boolean? = null
    /** Destination ownership is motor-local. BASIC and QEM can never share a waiting-deck marker. */
    private var activeWaitingFreeDeck: Boolean?
        get() = when (autoDiscoveryMotor) {
            AutoDiscoveryMotor.BASIC -> basicWaitingFreeDeck
            AutoDiscoveryMotor.QEM -> qemWaitingFreeDeck
            AutoDiscoveryMotor.NONE -> null
        }
        set(value) {
            when (autoDiscoveryMotor) {
                AutoDiscoveryMotor.BASIC -> basicWaitingFreeDeck = value
                AutoDiscoveryMotor.QEM -> qemWaitingFreeDeck = value
                AutoDiscoveryMotor.NONE -> if (value == null) {
                    basicWaitingFreeDeck = null
                    qemWaitingFreeDeck = null
                }
            }
        }
    // QEM live-mode handoff: suppress the shared Basic Endless initial refill race until
    // QEM has adopted the live ACTIVE deck and explicitly loaded its validated NEXT.
    private var suppressInitialEndlessDiscovery = false
    // True only while QEM is taking ownership from another AUTO mode. Basic discovery is forbidden
    // during this window so a stale/global candidate can never cross the new hard QEM gates.
    private var qemHandoffPending = false
    private var endlessDiscoveryJob: Job? = null // BASIC discovery only
    private var qemDiscoveryJob: Job? = null     // QEM discovery only
    private var qemDiscoveryGeneration = 0L
    private var endlessLoadJobA: Job? = null
    private var endlessLoadJobB: Job? = null
    private var endlessSessionGeneration = 0L
    private val endlessAnchorTracks = mutableListOf<TrackRef>()
    private val endlessPendingAnchorTracks = ArrayDeque<TrackRef>()
    private var endlessDiscoveriesSinceAnchorExpansion = 0
    private var lastContinuityGuardAt = 0L
    private var lastRecoveryAttemptAt = 0L
    private var endlessRecoveryDeck: Boolean? = null
    private var endlessModeLocked = false
    private val endlessPrefetchMs = 60_000L
    private val endlessReadyDeadlineMs = 15_000L
    private val endlessNextFreezeMs = 40_000L
    private val endlessEarlySearchAtMs = 3_000L
    private var endlessDeckHasPlayedA = false
    private var endlessDeckHasPlayedB = false
    private var endlessDeckStateA = EndlessDeckState.FREE
    private var endlessDeckStateB = EndlessDeckState.FREE
    private var endlessSeedProtectedA = false
    private var endlessSeedProtectedB = false
    private var endlessManualProtectedA = false
    private var endlessManualProtectedB = false
    private var endlessPendingNextUrlA: String? = null
    private var endlessPendingNextUrlB: String? = null
    private var endlessAddMode = false
    private val endlessManualUrls = linkedSetOf<String>()
    private var mixInMsA = 0L
    private var mixInMsB = 0L
    private var mixOutMsA = 0L
    private var mixOutMsB = 0L

    private var quickDrawerOpen = false
    private val quickRegions = linkedSetOf<String>()
    private val quickEras = linkedSetOf<String>()
    private val quickStyles = linkedSetOf<String>()
    private var quickSceneOverride: EndlessSceneProfile? = null
    private var quickSessionAnchorTerms = ""
    private var quickSessionStyleTerms = ""
    private var quickLongFormDuration = false
    private var quickSessionActive = false
    private var oneArtistMixActive = false
    // QEM motor state. The JSON artist pool owns discovery while the existing Endless engine
    // continues to own the physical A/B decks, buffering, transitions and recovery.
    private var qemSessionArtistPool: List<QemFonoteka.ArtistChoice> = emptyList()
    private var qemSessionStyleKeys: Set<String> = emptySet()
    private var qemSessionEraKeys: Set<String> = emptySet()
    private var qemSessionInstrumental = false
    private var qemSessionPiano = false
    private val qemRecentArtistIds = ArrayDeque<String>()
    private val qemTrackArtistIds = mutableMapOf<String, String>()
    private data class QemCandidateStamp(
        val generation: Long,
        val filterFingerprint: String,
        val artistId: String
    )
    private val qemCandidateStamps = mutableMapOf<String, QemCandidateStamp>()
    private var qemFilterFingerprint = ""

    private fun markQemCandidate(track: TrackRef, artistId: String) {
        if (autoDiscoveryMotor != AutoDiscoveryMotor.QEM || qemFilterFingerprint.isBlank()) return
        val artist = qemSessionArtistPool.firstOrNull { it.id == artistId } ?: return
        // Never trust the search query as proof of identity. A YouTube search for an EX-YU artist
        // may contain recommendations by unrelated artists. Only stamp a result after the result
        // itself proves the expected artist identity.
        if (!qemTrackMatchesArtist(track, artist)) return
        val key = endlessTrackKey(track)
        qemTrackArtistIds[key] = artistId
        qemCandidateStamps[key] = QemCandidateStamp(
            generation = qemDiscoveryGeneration,
            filterFingerprint = qemFilterFingerprint,
            artistId = artistId
        )
    }

    private fun isCurrentQemCandidate(track: TrackRef): Boolean {
        if (autoDiscoveryMotor != AutoDiscoveryMotor.QEM) return false
        val stamp = qemCandidateStamps[endlessTrackKey(track)] ?: return false
        if (stamp.generation != qemDiscoveryGeneration) return false
        if (stamp.filterFingerprint != qemFilterFingerprint || qemFilterFingerprint.isBlank()) return false
        val artist = qemSessionArtistPool.firstOrNull { it.id == stamp.artistId } ?: return false
        // FINAL identity airlock: re-check the actual returned track, not merely its old stamp.
        return qemTrackMatchesArtist(track, artist)
    }
    // Venue profile frozen for the active QUICK session; lower manual tempo overrides it.
    private var quickSessionTempoBand: String? = null
    private var quickStartJob: Job? = null
    // QUICK startup invariant: A is the sole playback owner until the first real A→B transition.
    // Any delayed/stale play request on B is rejected while this guard is armed.
    private var quickStartupGuardA = false
    // Universal human-friendly tempo preference. Null means unrestricted.
    private var tempoBand: String? = null
    // A NEXT deck may become READY only after real-audio BPM validation when a tempo profile is active.
    private var tempoValidatedA = true
    private var tempoValidatedB = true
    private var measuredBpmA: Float? = null
    private var measuredBpmB: Float? = null
    // Optional precise country refinement for QUICK. REGION buttons override/clear this value.
    private var quickCountry: String? = null
    private var endlessActiveOwnerIsA: Boolean? = null
    private var endlessOwnerStartedAtMs = 0L
    private var endlessLastRefillKickAtMs = 0L

    private fun queuedForActiveMotor(): TrackRef? = when (autoDiscoveryMotor) {
        AutoDiscoveryMotor.QEM -> qemQueued
        AutoDiscoveryMotor.BASIC -> endlessQueued
        AutoDiscoveryMotor.NONE -> null
    }

    private fun queueForActiveMotor(track: TrackRef) {
        when (autoDiscoveryMotor) {
            AutoDiscoveryMotor.QEM -> if (qemQueued == null) qemQueued = track
            AutoDiscoveryMotor.BASIC -> if (endlessQueued == null) endlessQueued = track
            AutoDiscoveryMotor.NONE -> Unit
        }
    }

    private fun clearQueuedForActiveMotor() {
        when (autoDiscoveryMotor) {
            AutoDiscoveryMotor.QEM -> qemQueued = null
            AutoDiscoveryMotor.BASIC -> endlessQueued = null
            AutoDiscoveryMotor.NONE -> Unit
        }
    }

    private fun discoveryActiveForMotor(): Boolean = when (autoDiscoveryMotor) {
        AutoDiscoveryMotor.QEM -> qemDiscoveryJob?.isActive == true
        AutoDiscoveryMotor.BASIC -> endlessDiscoveryJob?.isActive == true
        AutoDiscoveryMotor.NONE -> false
    }

    /**
     * AUTO owner is authoritative. Session/UI booleans are mirrors only and are never allowed
     * to silently demote QEM to BASIC during NEXT transitions or a hot QEM filter change.
     */
    private fun enforceAutoOwnerInvariant() {
        if (!endlessActive) return
        when (autoDiscoveryMotor) {
            AutoDiscoveryMotor.QEM -> {
                quickSessionActive = true
                autoEnabled = true
            }
            AutoDiscoveryMotor.BASIC -> {
                if (!oneArtistMixActive) quickSessionActive = false
            }
            AutoDiscoveryMotor.NONE -> Unit
        }
    }

    private fun switchDiscoveryMotor(newMotor: AutoDiscoveryMotor) {
        if (autoDiscoveryMotor == newMotor) return
        // NEXT loader jobs belong to the old discovery motor. They are never ACTIVE playback jobs,
        // so cancelling them at the ownership boundary cannot interrupt the song that is audible.
        endlessLoadJobA?.cancel(); endlessLoadJobA = null
        endlessLoadJobB?.cancel(); endlessLoadJobB = null
        // Cancel and invalidate the OLD motor completely. ACTIVE audio is not touched.
        when (autoDiscoveryMotor) {
            AutoDiscoveryMotor.BASIC -> {
                endlessDiscoveryJob?.cancel(); endlessDiscoveryJob = null
                endlessQueued = null
                basicWaitingFreeDeck = null
            }
            AutoDiscoveryMotor.QEM -> {
                qemDiscoveryGeneration++
                qemDiscoveryJob?.cancel(); qemDiscoveryJob = null
                qemQueued = null
                qemWaitingFreeDeck = null
                qemCandidateStamps.clear()
            }
            AutoDiscoveryMotor.NONE -> Unit
        }
        autoDiscoveryMotor = newMotor
        when (newMotor) {
            AutoDiscoveryMotor.BASIC -> {
                qemDiscoveryGeneration++; qemDiscoveryJob?.cancel(); qemDiscoveryJob = null; qemQueued = null
                qemWaitingFreeDeck = null; qemCandidateStamps.clear(); qemFilterFingerprint = ""
            }
            AutoDiscoveryMotor.QEM -> {
                endlessDiscoveryJob?.cancel(); endlessDiscoveryJob = null; endlessQueued = null; basicWaitingFreeDeck = null
                qemDiscoveryGeneration++; qemWaitingFreeDeck = null; qemCandidateStamps.clear()
            }
            AutoDiscoveryMotor.NONE -> {
                endlessDiscoveryJob?.cancel(); endlessDiscoveryJob = null; endlessQueued = null; basicWaitingFreeDeck = null
                qemDiscoveryGeneration++; qemDiscoveryJob?.cancel(); qemDiscoveryJob = null; qemQueued = null
                qemWaitingFreeDeck = null; qemCandidateStamps.clear(); qemFilterFingerprint = ""
            }
        }
    }

    private val speechLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != RESULT_OK || !::binding.isInitialized) return@registerForActivityResult
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
            ?.trim()
            .orEmpty()
        if (spoken.isNotBlank()) {
            binding.endlessSearchInput.setText(spoken)
            binding.endlessSearchInput.setSelection(spoken.length)
            runEndlessSearch()
        }
    }

    private val micPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchSpeechRecognizer()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMixerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        loadPersistentPlaybackHistory()
        // Fonoteka refresh is completely outside the audio engine. It can never touch ACTIVE/NEXT.
        lifecycleScope.launch { FonotekaUpdateManager(this@MixerActivity).checkDaily() }
        EngineRulesStore.initialize(this)
        lifecycleScope.launch { EngineRulesUpdateManager(this@MixerActivity).checkDaily() }

        val loadControlA = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 40_000, 2_500, 2_500)
            .setBackBuffer(20_000, true)
            .build()
        val loadControlB = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 40_000, 2_500, 2_500)
            .setBackBuffer(20_000, true)
            .build()
        val runtimePlayers = PlaybackRuntime.acquire(this, loadControlA, loadControlB)
        playerA = runtimePlayers.first
        playerB = runtimePlayers.second
        playerA.setWakeMode(C.WAKE_MODE_NETWORK)
        playerB.setWakeMode(C.WAKE_MODE_NETWORK)
        setupAudioFocusProtection()
        playerListenerA = addPlayerListener(playerA, true)
        playerListenerB = addPlayerListener(playerB, false)

        endlessAdapter = SearchAdapter(
            targetDeck = null,
            onImportA = {},
            onImportB = {},
            onSelect = { selectEndlessSeed(it) }
        )
        binding.endlessResults.layoutManager = LinearLayoutManager(this)
        binding.endlessResults.adapter = endlessAdapter

        binding.loadA.setOnClickListener { openSearchFor("A") }
        binding.loadB.setOnClickListener { openSearchFor("B") }

        binding.playA.setOnClickListener {
            cancelAutoFadeForManualControl()
            MixerStore.deckA?.let { toggleDeck(true, it) }
                ?: Toast.makeText(this, "Press A to load a song", Toast.LENGTH_SHORT).show()
        }
        binding.playB.setOnClickListener {
            cancelAutoFadeForManualControl()
            MixerStore.deckB?.let { toggleDeck(false, it) }
                ?: Toast.makeText(this, "Press B to load a song", Toast.LENGTH_SHORT).show()
        }

        binding.autoMix.setOnClickListener {
            if (endlessActive) {
                Toast.makeText(this, "Endless Mix controls AUTO", Toast.LENGTH_SHORT).show()
            } else {
                autoEnabled = !autoEnabled
                updateAutoButton()
            }
        }

        binding.waveA.onSeekRequested = { fraction ->
            seekDeck(playerA, fraction)
        }
        binding.waveB.onSeekRequested = { fraction ->
            seekDeck(playerB, fraction)
        }

        binding.volumeA.progress = 100
        binding.volumeA.onProgressChanged = { p ->
            userVolA = p / 100f
            applyVolumes()
        }
        binding.volumeB.progress = 100
        binding.volumeB.onProgressChanged = { p ->
            userVolB = p / 100f
            applyVolumes()
        }

        binding.masterVolume.progress = 100
        binding.masterVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                masterVolume = progress / 100f
                applyVolumes()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        binding.masterMute.setOnClickListener {
            masterMuted = !masterMuted
            updateMasterMuteUi()
            applyVolumes()
        }
        updateMasterMuteUi()

        // App startup always begins hard-left on deck A. Do not restore a stale crossfader
        // position from an earlier session; both the UI thumb and volume engine start on A.
        cross = 0f
        binding.crossfader.progress = 0
        applyVolumes()

        binding.crossfader.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    cancelAutoFadeForManualControl()
                    cross = progress / 100f
                    applyVolumes()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                cancelAutoFadeForManualControl()
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        binding.endlessAction.setOnClickListener { onEndlessAction() }
        binding.endlessSearchButton.setOnClickListener { runEndlessSearch() }
        binding.endlessVoiceButton.setOnClickListener { requestEndlessVoiceSearch() }
        binding.mixLock.setOnClickListener { toggleControlLock() }
        binding.addToMix.setOnClickListener { requestAddToMix() }
        setupQuickEndlessUi()
        binding.basicEndlessButton.setOnClickListener {
            if (controlsLocked) { showLockedControlNotice(); return@setOnClickListener }
            val alreadyBasic = endlessActive && !quickSessionActive && !oneArtistMixActive
            if (alreadyBasic) {
                stopEndlessMix()
                updateModeButtons()
                return@setOnClickListener
            }
            if (endlessActive) stopEndlessMix()
            oneArtistMixActive = false
            quickSessionActive = false
            switchDiscoveryMotor(AutoDiscoveryMotor.BASIC)
            onEndlessAction()
            updateModeButtons()
        }
        binding.oneArtistMixButton.setOnClickListener {
            if (controlsLocked) { showLockedControlNotice(); return@setOnClickListener }
            if (endlessActive && oneArtistMixActive) {
                stopEndlessMix()
                updateModeButtons()
            } else {
                showOneArtistMixPopup()
            }
        }
        binding.startEndlessAutoMix.setOnClickListener {
            if (!endlessActive && MixerStore.deckA != null && MixerStore.deckB != null) {
                oneArtistMixActive = false
                quickSessionActive = false
                switchDiscoveryMotor(AutoDiscoveryMotor.BASIC)
                onEndlessAction()
                updateModeButtons()
            }
        }
        binding.instantNextA.setOnClickListener { if (canInstantNext(fromA = true)) startAutoTransition(fromA = true) }
        binding.instantNextB.setOnClickListener { if (canInstantNext(fromA = false)) startAutoTransition(fromA = false) }

        fun toggleLiveFilter() {
            if (!controlsLocked) {
                allowLive = !allowLive
                updateEndlessFilterButtons()
            }
        }
        fun toggleCoverFilter() {
            if (!controlsLocked) {
                allowCover = !allowCover
                updateEndlessFilterButtons()
            }
        }
        fun toggleOfficialFilter() {
            if (!controlsLocked) {
                onlyOfficial = !onlyOfficial
                updateEndlessFilterButtons()
            }
        }

        binding.filterLive.setOnClickListener { toggleLiveFilter() }
        binding.filterCover.setOnClickListener { toggleCoverFilter() }
        binding.filterOfficial.setOnClickListener { toggleOfficialFilter() }
        binding.quickFilterLive.setOnClickListener { toggleLiveFilter() }
        binding.quickFilterCover.setOnClickListener { toggleCoverFilter() }
        binding.quickFilterOfficial.setOnClickListener { toggleOfficialFilter() }

        fun toggleCrossfade() {
            crossfadeEnabled = !crossfadeEnabled
            updateCrossfadeButton()
        }
        binding.crossfadeMode.setOnClickListener { toggleCrossfade() }
        binding.lockedCrossfadeMode.setOnClickListener { toggleCrossfade() }
        binding.quickCrossfadeMode.setOnClickListener { toggleCrossfade() }
        binding.endlessSearchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                runEndlessSearch()
                true
            } else false
        }

        refreshDecks(force = true)
        syncSeedsFromCurrentDecks()
        updateAutoButton()
        updateEndlessAction()
        updateControlLockUi()
        updateEndlessFilterButtons()
        updateCrossfadeButton()
        applyVolumes()

        lifecycleScope.launch {
            while (isActive) {
                updateDeckUi(playerA, true)
                updateDeckUi(playerB, false)
                updateArtistArtworkUi()
                checkAutoMix()
                // QUICK owns its own strict two-seed start barrier. Never auto-start merely
                // because both MixerStore slots are non-null; one/both players may still be
                // resolving or buffering, and a stale deck must never become audible.
                protectEndlessContinuity()
                updateCrossSpectrum()
                updateMasterVuMeters()
                updateContextualModeUi()
                updateInstantNextButtons()
                delay(100)
            }
        }
    }

    private fun addPlayerListener(player: ExoPlayer, isA: Boolean): Player.Listener {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                val button = if (isA) binding.playA else binding.playB
                when (playbackState) {
                    Player.STATE_BUFFERING -> {
                        button.text = "LOADING"
                        setPlayColor(button, false)
                    }
                    Player.STATE_READY -> {
                        updatePlayButton(isA)
                        if (endlessActive && !player.isPlaying) {
                            val state = if (isA) endlessDeckStateA else endlessDeckStateB
                            // Only a deck we explicitly loaded as NEXT may become READY_NEXT.
                            // A spent paused deck can remain ExoPlayer STATE_READY at -0:04; FREE
                            // must remain FREE even if ExoPlayer reports READY again.
                            val tempoOk = if (isA) tempoValidatedA else tempoValidatedB
                            if (state == EndlessDeckState.LOADING_NEXT && tempoOk) {
                                if (isA) endlessDeckStateA = EndlessDeckState.READY_NEXT
                                else endlessDeckStateB = EndlessDeckState.READY_NEXT
                            }
                        }
                        if (endlessActive && pendingEndlessStart && pendingEndlessStartIsA == isA) {
                            pendingEndlessStart = false
                            pendingEndlessStartIsA = null
                            player.play()
                        }
                        if (endlessActive && endlessRecoveryDeck == isA && !playerA.isPlaying && !playerB.isPlaying) {
                            cross = if (isA) 0f else 1f
                            binding.crossfader.progress = if (isA) 0 else 100
                            applyVolumes()
                            applyEndlessMixInPoint(player, targetIsA = isA)
                            player.play()
                            (if (isA) MixerStore.deckA else MixerStore.deckB)?.let { markEndlessAutoPlayed(it) }
                            endlessRecoveryDeck = null
                            activeWaitingFreeDeck = null
                            discoverQueuedCandidate()
                        }
                    }
                    Player.STATE_ENDED -> {
                        if ((isA && endlessSeedProtectedA) || (!isA && endlessSeedProtectedB)) return
                        if (isA) endlessDeckStateA = EndlessDeckState.FREE else endlessDeckStateB = EndlessDeckState.FREE
                        button.text = "PLAY"
                        setPlayColor(button, false)
                        updateLoadButtons()
                        if (endlessActive && autoFadeJob?.isActive != true) {
                            // Do not wait for the 100 ms watchdog loop. An ended deck is immediately
                            // available for the next candidate; if both are stopped this also arms
                            // the recovery autostart path.
                            activeWaitingFreeDeck = isA
                            if (!playerA.isPlaying && !playerB.isPlaying) endlessRecoveryDeck = isA
                            queuedForActiveMotor()?.let { queued ->
                                clearQueuedForActiveMotor()
                                activeWaitingFreeDeck = null
                                loadEndlessTrackIntoDeck(isA, queued)
                            } ?: discoverQueuedCandidate()
                        }
                    }
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (endlessActive && isPlaying) {
                    // Absolute QUICK start gate: until the first intentional A→B crossfade begins,
                    // B may NEVER become audible. This catches stale ExoPlayer autoplay callbacks,
                    // late prepare completions and manual state races at session startup.
                    if (quickStartupGuardA && !isA) {
                        player.pause()
                        updatePlayButton(isA)
                        updateLoadButtons()
                        return
                    }
                    val state = if (isA) endlessDeckStateA else endlessDeckStateB
                    val crossfadeRunning = autoFadeJob?.isActive == true

                    // HARD single-owner playback rule. A prepared NEXT deck is not allowed to
                    // promote itself to PLAYING just because ExoPlayer received a stale/delayed
                    // play request. Only a deck already explicitly granted PLAYING state may run.
                    // The sole exception is the intentional crossfade window, when both decks
                    // are allowed to be audible at the same time.
                    if (state != EndlessDeckState.PLAYING && !crossfadeRunning) {
                        player.pause()
                        updatePlayButton(isA)
                        updateLoadButtons()
                        return
                    }

                    if (isA) {
                        endlessSeedProtectedA = false
                        endlessDeckHasPlayedA = true
                    } else {
                        endlessSeedProtectedB = false
                        endlessDeckHasPlayedB = true
                    }
                    // Playback itself is authoritative. Search/load events do not enter history.
                    (if (isA) MixerStore.deckA else MixerStore.deckB)?.let { rememberActuallyPlayedTrack(it) }
                }
                updatePlayButton(isA)
                updateLoadButtons()
                syncPlaybackProtectionService()
            }
        }
        player.addListener(listener)
        return listener
    }

    private fun openSearchFor(deck: String) {
        startActivity(Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_TARGET_DECK, deck))
    }

    private fun prepareDeck(isA: Boolean, track: TrackRef) {
        val player = if (isA) playerA else playerB
        val button = if (isA) binding.playA else binding.playB
        val direct = track.streamUrl ?: return

        button.text = "LOADING"
        button.isEnabled = false
        setPlayColor(button, false)
        // Never let a previous deck's playWhenReady leak into a newly prepared track.
        // Playback permission is granted explicitly by the deck state machine only.
        player.pause()
        player.playWhenReady = false
        player.setMediaItem(MediaItem.fromUri(direct))
        player.prepare()
    }

    private fun toggleDeck(isA: Boolean, track: TrackRef) {
        if (::audioFocusRequest.isInitialized) audioManager.requestAudioFocus(audioFocusRequest)
        val player = if (isA) playerA else playerB
        if (player.mediaItemCount == 0) {
            resolvePrepareAnalyze(isA, track)
            return
        }
        if (player.playbackState == Player.STATE_READY || player.playbackState == Player.STATE_BUFFERING) {
            if (player.isPlaying) player.pause() else player.play()
        }
    }

    private fun refreshDecks(force: Boolean = false) {
        val a = MixerStore.deckA
        val b = MixerStore.deckB

        if (force || a?.url != lastTrackAUrl) {
            playerA.stop(); playerA.clearMediaItems()
            lastTrackAUrl = a?.url
            measuredRmsA = null
            measuredBpmA = null
            tempoValidatedA = !requiresMeasuredTempoFilter()
            mixInMsA = 0L
            mixOutMsA = 0L
            endlessDeckHasPlayedA = false
            userVolA = 1f
            binding.volumeA.progress = 100
            binding.titleA.text = a?.title ?: "EMPTY"
            binding.playA.text = "PLAY"
            binding.playA.isEnabled = a != null
            setPlayColor(binding.playA, false)
            if (a == null) {
                binding.waveA.setEmpty()
                binding.timeA.text = ""
            } else {
                binding.waveA.setTrackPresent(true)
                val cached = MixerStore.waveA
                if (cached != null) binding.waveA.setWaveform(cached, 1f)
                resolvePrepareAnalyze(true, a)
                prefetchArtistArtwork(a)
            }
        }

        if (force || b?.url != lastTrackBUrl) {
            playerB.stop(); playerB.clearMediaItems()
            lastTrackBUrl = b?.url
            measuredRmsB = null
            measuredBpmB = null
            tempoValidatedB = !requiresMeasuredTempoFilter()
            mixInMsB = 0L
            mixOutMsB = 0L
            endlessDeckHasPlayedB = false
            userVolB = 1f
            binding.volumeB.progress = 100
            binding.titleB.text = b?.title ?: "EMPTY"
            binding.playB.text = "PLAY"
            binding.playB.isEnabled = b != null
            setPlayColor(binding.playB, false)
            if (b == null) {
                binding.waveB.setEmpty()
                binding.timeB.text = ""
            } else {
                binding.waveB.setTrackPresent(true)
                val cached = MixerStore.waveB
                if (cached != null) binding.waveB.setWaveform(cached, 1f)
                resolvePrepareAnalyze(false, b)
                prefetchArtistArtwork(b)
            }
        }
    }

    private fun resolvePrepareAnalyze(isA: Boolean, track: TrackRef) {
        val key = track.url
        val player = if (isA) playerA else playerB
        val button = if (isA) binding.playA else binding.playB

        if (player.mediaItemCount > 0) {
            if (!endlessActive && (if (isA) MixerStore.waveA else MixerStore.waveB) == null) analyzeWaveform(isA, track)
            return
        }

        val existing = track.streamUrl
        if (existing != null) {
            prepareDeck(isA, track)
            // Endless preloads prioritize ExoPlayer buffering; their analysis is scheduled a few
            // seconds later by loadEndlessTrackIntoDeck so it cannot steal bandwidth from READY.
            if (!endlessActive && (if (isA) MixerStore.waveA else MixerStore.waveB) == null) analyzeWaveform(isA, track)
            return
        }

        if ((if (isA) resolvingA else resolvingB) == key) return
        if (isA) resolvingA = key else resolvingB = key
        button.text = "LOADING"
        button.isEnabled = false
        setPlayColor(button, false)

        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) { AudioResolver.resolveBestAudioUrl(track.url) }
            }
            if (isA) resolvingA = null else resolvingB = null

            result.onSuccess { direct ->
                val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                if (!sameTrack) return@onSuccess
                val updated = track.copy(streamUrl = direct)
                if (isA) MixerStore.deckA = updated else MixerStore.deckB = updated
                prepareDeck(isA, updated)
                analyzeWaveform(isA, updated)
            }.onFailure {
                val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                if (sameTrack) {
                    button.isEnabled = true
                    button.text = "PLAY"
                    setPlayColor(button, false)
                    Toast.makeText(this@MixerActivity, "Stream error: ${it.message ?: "unknown"}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private suspend fun awaitAudioHeadroom(maxWaitMs: Long = 1_500L) {
        // Protect genuinely endangered ACTIVE buffering, but do not hold analysis/search
        // for several seconds: the NEXT deck must keep being prepared promptly.
        val started = SystemClock.elapsedRealtime()
        while (SystemClock.elapsedRealtime() - started < maxWaitMs) {
            val aCritical = playerA.isPlaying && (playerA.bufferedPosition - playerA.currentPosition) < 6_000L
            val bCritical = playerB.isPlaying && (playerB.bufferedPosition - playerB.currentPosition) < 6_000L
            if (!aCritical && !bCritical) return
            delay(150L)
        }
    }

    private suspend fun <T> runLowPriorityAnalysis(block: () -> T): T {
        awaitAudioHeadroom()
        return analysisSlots.withPermit {
            withContext(Dispatchers.IO) {
                val tid = Process.myTid()
                val oldPriority = runCatching { Process.getThreadPriority(tid) }.getOrDefault(Process.THREAD_PRIORITY_DEFAULT)
                try {
                    runCatching { Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND) }
                    block()
                } finally {
                    runCatching { Process.setThreadPriority(oldPriority) }
                }
            }
        }
    }

    private fun analyzeWaveform(isA: Boolean, track: TrackRef) {
        val direct = track.streamUrl ?: return
        val key = track.url
        if (isA) {
            if (MixerStore.waveA != null || analyzingA == key) return
            analyzingA = key
        } else {
            if (MixerStore.waveB != null || analyzingB == key) return
            analyzingB = key
        }

        lifecycleScope.launch {
            val analysis = runCatching {
                runLowPriorityAnalysis {
                    WaveformAnalyzer.analyze(direct) { partial, fraction ->
                        runOnUiThread {
                            val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                            if (sameTrack) {
                                if (isA) binding.waveA.setWaveform(partial, fraction)
                                else binding.waveB.setWaveform(partial, fraction)
                            }
                        }
                    }
                }
            }.getOrNull()

            if (isA) {
                analyzingA = null
                if (MixerStore.deckA?.url == key && analysis != null) {
                    MixerStore.waveA = analysis.waveform
                    measuredRmsA = analysis.rms
                    mixInMsA = maxOf(mixInMsA, detectMixInPointMs(analysis.waveform, track.durationSeconds * 1000L))
                    mixOutMsA = detectMixOutPointMs(analysis.waveform, track.durationSeconds * 1000L)
                    binding.waveA.setWaveform(analysis.waveform, 1f)
                    applyAutoLoudness(true, analysis.rms)
                }
            } else {
                analyzingB = null
                if (MixerStore.deckB?.url == key && analysis != null) {
                    MixerStore.waveB = analysis.waveform
                    measuredRmsB = analysis.rms
                    mixInMsB = maxOf(mixInMsB, detectMixInPointMs(analysis.waveform, track.durationSeconds * 1000L))
                    mixOutMsB = detectMixOutPointMs(analysis.waveform, track.durationSeconds * 1000L)
                    binding.waveB.setWaveform(analysis.waveform, 1f)
                    applyAutoLoudness(false, analysis.rms)
                }
            }
        }
    }

    private fun updateDeckUi(player: ExoPlayer, isA: Boolean) {
        val duration = player.duration
        val position = player.currentPosition.coerceAtLeast(0L)
        val p = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f
        val remaining = if (duration > 0) (duration - position).coerceAtLeast(0L) else -1L

        if (isA) {
            binding.waveA.setProgress(p)
            binding.timeA.text = if (remaining >= 0) "-${formatTime(remaining)}" else ""
        } else {
            binding.waveB.setProgress(p)
            binding.timeB.text = if (remaining >= 0) "-${formatTime(remaining)}" else ""
        }
    }

    private fun seekDeck(player: ExoPlayer, fraction: Float) {
        if (player.mediaItemCount == 0) return
        val duration = player.duration
        if (duration > 0) player.seekTo((duration * fraction.coerceIn(0f, 1f)).toLong())
    }

    private fun checkAutoMix() {
        if (!autoEnabled || autoFadeJob?.isActive == true) return

        if (!crossfadeEnabled) {
            if (playerA.playbackState == Player.STATE_ENDED && deckReadyForAuto(playerB)) {
                startSequentialNext(fromA = true)
            } else if (playerB.playbackState == Player.STATE_ENDED && deckReadyForAuto(playerA)) {
                startSequentialNext(fromA = false)
            }
            return
        }

        val aDuration = playerA.duration
        val bDuration = playerB.duration
        val aDefaultTrigger = if (aDuration > 0L) (aDuration - autoTriggerMs).coerceAtLeast(0L) else Long.MAX_VALUE
        val bDefaultTrigger = if (bDuration > 0L) (bDuration - autoTriggerMs).coerceAtLeast(0L) else Long.MAX_VALUE
        val aTriggerAt = if (mixOutMsA > 0L) minOf(aDefaultTrigger, mixOutMsA) else aDefaultTrigger
        val bTriggerAt = if (mixOutMsB > 0L) minOf(bDefaultTrigger, mixOutMsB) else bDefaultTrigger

        if (playerA.isPlaying && playerA.currentPosition >= aTriggerAt && deckReadyForAuto(playerB)) {
            startAutoFade(fromA = true)
        } else if (playerB.isPlaying && playerB.currentPosition >= bTriggerAt && deckReadyForAuto(playerA)) {
            startAutoFade(fromA = false)
        }
    }

    private fun freePausedEndlessDeck(isA: Boolean, force: Boolean = false) {
        if (!endlessActive) return
        if ((isA && endlessSeedProtectedA) || (!isA && endlessSeedProtectedB)) return
        // A user-inserted ADD TO MIX track is sacred until it has actually played.
        // Never reclaim/refresh its deck merely because it is paused while waiting.
        if ((isA && endlessManualProtectedA) || (!isA && endlessManualProtectedB)) return
        val hasPlayed = if (isA) endlessDeckHasPlayedA else endlessDeckHasPlayedB
        if (!force && !hasPlayed) return
        if (isA) {
            endlessDeckHasPlayedA = false
            endlessDeckStateA = EndlessDeckState.FREE
        } else {
            endlessDeckHasPlayedB = false
            endlessDeckStateB = EndlessDeckState.FREE
        }

        // Mark the physical deck as the destination before touching discovery. If a discovery
        // job is already running, it will see this waiting slot when it completes and load the
        // candidate directly here instead of leaving it merely queued.
        activeWaitingFreeDeck = isA
        val queued = queuedForActiveMotor()
        if (queued != null) {
            clearQueuedForActiveMotor()
            activeWaitingFreeDeck = null
            loadEndlessTrackIntoDeck(isA, queued)
        } else {
            // Safe even if a discovery job is already active: that job keeps running and will
            // consume activeWaitingFreeDeck on completion. If none is active, this starts one.
            discoverQueuedCandidate()
        }
    }

    /**
     * QEM waiting-deck replacement gate.
     *
     * IMPORTANT: this function NEVER empties a physical deck. QEM discovery must finish first.
     * Once a concrete resolved/validated candidate exists, the caller may replace the parked
     * automatic NEXT in one step. Manual ADD TO MIX remains sacred.
     */
    private fun prepareQemWaitingDeckForAtomicSwap(isA: Boolean): Boolean {
        if (!endlessActive || autoDiscoveryMotor != AutoDiscoveryMotor.QEM) return false
        val targetPlayer = if (isA) playerA else playerB
        if (targetPlayer.isPlaying) return false
        val waitingTrack = if (isA) MixerStore.deckA else MixerStore.deckB
        val trulyManualProtected = waitingTrack?.url?.let { it in endlessManualUrls } == true
        if (trulyManualProtected) return false

        // Cancel only stale automatic work. Do NOT stop/clear the player and do NOT null MixerStore.
        if (isA) {
            endlessLoadJobA?.cancel(); endlessLoadJobA = null
            endlessSeedProtectedA = false
            endlessPendingNextUrlA = null
            endlessDeckHasPlayedA = false
            endlessManualProtectedA = false
            tempoValidatedA = true
        } else {
            endlessLoadJobB?.cancel(); endlessLoadJobB = null
            endlessSeedProtectedB = false
            endlessPendingNextUrlB = null
            endlessDeckHasPlayedB = false
            endlessManualProtectedB = false
            tempoValidatedB = true
        }
        qemWaitingFreeDeck = null
        return true
    }

    /**
     * Install a QEM candidate only after discovery/resolve/validation has completed off-deck.
     * This is the actual swap moment: the old parked track remains visible/playable until here.
     */
    private fun installPreparedQemTrackIntoWaitingDeck(isA: Boolean, prepared: TrackRef): Boolean {
        if (prepared.streamUrl == null || !isCurrentQemCandidate(prepared)) return false
        if (!prepareQemWaitingDeckForAtomicSwap(isA)) return false

        if (isA) {
            MixerStore.setA(prepared)
            MixerStore.waveA = null
            endlessPendingNextUrlA = null
            endlessDeckStateA = EndlessDeckState.LOADING_NEXT
            lastTrackAUrl = "__QEM_ATOMIC_SWAP_A__"
            resolvingA = null
        } else {
            MixerStore.setB(prepared)
            MixerStore.waveB = null
            endlessPendingNextUrlB = null
            endlessDeckStateB = EndlessDeckState.LOADING_NEXT
            lastTrackBUrl = "__QEM_ATOMIC_SWAP_B__"
            resolvingB = null
        }
        // refreshDecks now performs the single real replacement. There is no search-time EMPTY gap.
        refreshDecks()
        return true
    }


    /**
     * FIRST COMMANDMENT / SUPREME CONTINUITY LAW.
     * While AUTO is active, exactly one audible deck + one physically EMPTY opposite deck is the
     * highest-priority fault in the app. Nothing else (ranking, prefetch, sticky NEXT bookkeeping,
     * filter retries, old protection flags) may run ahead of repairing it. ACTIVE is sacred.
     *
     * Returns true while the emergency EMPTY condition exists so the normal continuity pass can
     * stop for this tick and avoid fighting the repair. The next 100 ms tick re-checks the physical
     * deck and keeps hammering until it is no longer empty.
     */
    private fun enforceSupremeNoEmptyLaw(): Boolean {
        if (!endlessActive || !autoEnabled) return false

        val activeIsA: Boolean = when {
            playerA.isPlaying && !playerB.isPlaying -> true
            playerB.isPlaying && !playerA.isPlaying -> false
            else -> return false
        }
        val targetIsA = !activeIsA
        val targetPlayer = if (targetIsA) playerA else playerB
        val targetTrack = if (targetIsA) MixerStore.deckA else MixerStore.deckB
        val physicallyEmpty = targetTrack == null || targetPlayer.mediaItemCount == 0
        if (!physicallyEmpty) return false

        // Physical reality wins over every stale logical flag. Never touch the ACTIVE player.
        if (targetIsA) {
            endlessDeckStateA = EndlessDeckState.FREE
            endlessSeedProtectedA = false
            endlessManualProtectedA = false
            endlessPendingNextUrlA = null
            tempoValidatedA = true
        } else {
            endlessDeckStateB = EndlessDeckState.FREE
            endlessSeedProtectedB = false
            endlessManualProtectedB = false
            endlessPendingNextUrlB = null
            tempoValidatedB = true
        }

        // The CURRENT motor owns the empty physical destination directly. Do not use a shared
        // proxy that can be rewritten by the other discovery engine during a handoff.
        when (autoDiscoveryMotor) {
            AutoDiscoveryMotor.QEM -> {
                // CONSTITUTION: EMPTY HAS NO QEM OWNER. A physically empty deck is chassis space,
                // never a QEM reservation. Only a concrete queued track may claim it, and then it
                // must be loaded immediately. Otherwise QEM may search, but it does not own the
                // empty deck while searching.
                basicWaitingFreeDeck = null
                qemWaitingFreeDeck = null

                // If a handoff left the QEM session flag down for a tick but its session universe
                // still exists, repair the flag rather than allowing one-deck AUTO.
                if (!quickSessionActive && qemSessionArtistPool.isNotEmpty()) quickSessionActive = true

                val queued = qemQueued
                if (queued != null) {
                    qemQueued = null
                    loadEndlessTrackIntoDeck(targetIsA, queued)
                } else {
                    // Search is engine work, not deck ownership. When a result returns,
                    // discoverQemCandidate() re-reads physical A/B reality and loads whichever
                    // opposite deck is still truly EMPTY.
                    discoverQemCandidate()
                }
            }
            AutoDiscoveryMotor.BASIC -> {
                qemWaitingFreeDeck = null
                basicWaitingFreeDeck = targetIsA
                val queued = endlessQueued
                if (queued != null) {
                    endlessQueued = null
                    basicWaitingFreeDeck = null
                    loadEndlessTrackIntoDeck(targetIsA, queued)
                } else {
                    discoverQueuedCandidate()
                }
            }
            AutoDiscoveryMotor.NONE -> {
                // AUTO ON with no discovery owner is itself an invalid state. Adopt the motor that
                // has a real live session; otherwise fall back to Basic rather than accept EMPTY.
                val owner = if (quickSessionActive && qemSessionArtistPool.isNotEmpty()) {
                    AutoDiscoveryMotor.QEM
                } else {
                    AutoDiscoveryMotor.BASIC
                }
                switchDiscoveryMotor(owner)
                if (owner == AutoDiscoveryMotor.QEM) qemWaitingFreeDeck = targetIsA
                else basicWaitingFreeDeck = targetIsA
                discoverQueuedCandidate()
            }
        }

        endlessLastRefillKickAtMs = android.os.SystemClock.elapsedRealtime()
        return true
    }

    private fun protectEndlessContinuity() {
        if (!endlessActive) return
        enforceAutoOwnerInvariant()

        // FIRST COMMANDMENT: while AUTO is alive, EMPTY opposite ACTIVE is handled before every
        // other continuity/ranking/prefetch rule. Keep this at the very top of the watchdog.
        if (enforceSupremeNoEmptyLaw()) return

        val now = android.os.SystemClock.elapsedRealtime()

        // Endless rule: reclaim only a deck that was the actual PLAYING owner and has now stopped.
        // A stale hasPlayed flag must NEVER reclaim a deck that QEM has already moved into
        // LOADING_NEXT / READY_NEXT while it is (correctly) not playing. That race could keep the
        // physical NEXT deck looking EMPTY forever even though QEM keeps trying to fill it.
        if (endlessDeckHasPlayedA && !playerA.isPlaying && endlessDeckStateA == EndlessDeckState.PLAYING &&
            autoFadeJob?.isActive != true) {
            freePausedEndlessDeck(true)
        }
        if (endlessDeckHasPlayedB && !playerB.isPlaying && endlessDeckStateB == EndlessDeckState.PLAYING &&
            autoFadeJob?.isActive != true) {
            freePausedEndlessDeck(false)
        }

        // Pipeline rule: give a newly started song only about three seconds to stabilize,
        // then start finding the song AFTER the already-loaded opposite deck. Keep it queued
        // until a played deck becomes free. This gives search/resolution almost a full song.
        val active = when {
            playerA.isPlaying -> playerA
            playerB.isPlaying -> playerB
            else -> null
        }

        // Every new ACTIVE track must re-arm refill. This applies equally to normal Endless and
        // every QUICK combination. If the pipeline has no queue/load/search 10 s into a song,
        // kick discovery again instead of discovering the failure at the end of the track.
        val activeOwnerIsA = when {
            playerA.isPlaying && !playerB.isPlaying -> true
            playerB.isPlaying && !playerA.isPlaying -> false
            else -> null
        }
        if (activeOwnerIsA != null && activeOwnerIsA != endlessActiveOwnerIsA) {
            endlessActiveOwnerIsA = activeOwnerIsA
            endlessOwnerStartedAtMs = now
            endlessLastRefillKickAtMs = 0L
        }

        // PHYSICAL EMPTY is authoritative. Async/state flags may occasionally survive a cleared
        // MixerStore/player slot; never let READY/PROTECTED/WAITING fiction suppress refill.
        fun normalizePhysicallyEmptyDeck(isA: Boolean) {
            val player = if (isA) playerA else playerB
            val storeTrack = if (isA) MixerStore.deckA else MixerStore.deckB
            val state = if (isA) endlessDeckStateA else endlessDeckStateB
            val physicallyEmpty = storeTrack == null || player.mediaItemCount == 0
            if (!physicallyEmpty) return
            if (state == EndlessDeckState.PLAYING && player.isPlaying) return

            if (isA) {
                endlessDeckStateA = EndlessDeckState.FREE
                endlessSeedProtectedA = false
                endlessManualProtectedA = false
                endlessPendingNextUrlA = null
            } else {
                endlessDeckStateB = EndlessDeckState.FREE
                endlessSeedProtectedB = false
                endlessManualProtectedB = false
                endlessPendingNextUrlB = null
            }
            // BASIC may remember a free destination. QEM may not reserve an EMPTY deck:
            // physical emptiness itself is the destination signal.
            if (autoDiscoveryMotor == AutoDiscoveryMotor.BASIC &&
                (basicWaitingFreeDeck == null || basicWaitingFreeDeck == isA)) {
                basicWaitingFreeDeck = isA
            } else if (autoDiscoveryMotor == AutoDiscoveryMotor.QEM) {
                qemWaitingFreeDeck = null
            }
        }
        normalizePhysicallyEmptyDeck(true)
        normalizePhysicallyEmptyDeck(false)

        // QEM continuity owns its physical NEXT deck explicitly. Do not route this first-refill
        // decision through the shared BASIC/QEM waiting proxy. If exactly one deck is ACTIVE and
        // the opposite deck is physically empty/FREE, QEM must keep that deck armed until a real
        // candidate reaches LOADING_NEXT/READY_NEXT. This mirrors the state that manual ADD TO MIX
        // accidentally created in the successful Madonna test, but without requiring a manual track.
        if (autoDiscoveryMotor == AutoDiscoveryMotor.QEM && quickSessionActive) {
            val qemTargetIsA: Boolean? = when {
                playerA.isPlaying && !playerB.isPlaying &&
                    (MixerStore.deckB == null || playerB.mediaItemCount == 0 || endlessDeckStateB == EndlessDeckState.FREE) -> false
                playerB.isPlaying && !playerA.isPlaying &&
                    (MixerStore.deckA == null || playerA.mediaItemCount == 0 || endlessDeckStateA == EndlessDeckState.FREE) -> true
                else -> null
            }
            if (qemTargetIsA != null) {
                basicWaitingFreeDeck = null
                qemWaitingFreeDeck = null
                val readyQueued = qemQueued
                if (readyQueued != null) {
                    qemQueued = null
                    loadEndlessTrackIntoDeck(qemTargetIsA, readyQueued)
                } else if (qemDiscoveryJob?.isActive != true) {
                    endlessLastRefillKickAtMs = now
                    discoverQemCandidate()
                }
            }
        }

        // A waiting FREE deck is NOT refill activity; it is only a destination marker.
        // If no query/load/queue is actually alive, discovery must start even when
        // activeWaitingFreeDeck already points at that deck.
        val freeTargetIsA: Boolean? = when {
            endlessDeckStateA == EndlessDeckState.FREE && !playerA.isPlaying -> true
            endlessDeckStateB == EndlessDeckState.FREE && !playerB.isPlaying -> false
            else -> null
        }
        val hasPhysicalEmptyTarget = freeTargetIsA != null

        // CORE CONTINUITY LAW: a FREE physical deck must never wait for the active song to enter
        // a prefetch window. If a candidate is already buffered in endlessQueued, consume it NOW.
        // Otherwise arm discovery NOW. This removes the deadlock where endlessQueued != null blocked
        // new search while the queued song itself waited until <=60 s before being loaded.
        if (freeTargetIsA != null) {
            // BASIC can reserve FREE. QEM cannot reserve EMPTY/FREE; its result must re-check
            // the physical deck when it arrives. This prevents stale QEM ownership from making
            // an empty deck untouchable.
            if (autoDiscoveryMotor == AutoDiscoveryMotor.BASIC) basicWaitingFreeDeck = freeTargetIsA
            else if (autoDiscoveryMotor == AutoDiscoveryMotor.QEM) qemWaitingFreeDeck = null
            val queuedNow = queuedForActiveMotor()
            if (queuedNow != null) {
                clearQueuedForActiveMotor()
                if (autoDiscoveryMotor == AutoDiscoveryMotor.BASIC) basicWaitingFreeDeck = null
                loadEndlessTrackIntoDeck(freeTargetIsA, queuedNow)
            } else if (!discoveryActiveForMotor()) {
                endlessLastRefillKickAtMs = now
                discoverQueuedCandidate()
            }
        } else if (active != null && active.currentPosition >= endlessEarlySearchAtMs &&
            queuedForActiveMotor() == null && !discoveryActiveForMotor()) {
            // Both decks are occupied (ACTIVE + READY_NEXT): keep one extra candidate buffered so
            // the next FREE deck can be filled instantly after the transition.
            endlessLastRefillKickAtMs = now
            discoverQueuedCandidate()
        }

        // Healthy means real work/data exists. Never count activeWaitingFreeDeck by itself: doing
        // so can leave AUTO ON with an EMPTY deck for an entire song while no search is running.
        val refillHealthy = queuedForActiveMotor() != null ||
            discoveryActiveForMotor() ||
            (activeOwnerIsA == true && (endlessDeckStateB == EndlessDeckState.LOADING_NEXT || endlessDeckStateB == EndlessDeckState.READY_NEXT)) ||
            (activeOwnerIsA == false && (endlessDeckStateA == EndlessDeckState.LOADING_NEXT || endlessDeckStateA == EndlessDeckState.READY_NEXT))
        if (activeOwnerIsA != null && now - endlessOwnerStartedAtMs >= 10_000L && !refillHealthy &&
            now - endlessLastRefillKickAtMs >= 2_000L) {
            endlessLastRefillKickAtMs = now
            discoverQueuedCandidate()
        }

        fun ensureNextDeck(source: ExoPlayer, sourceIsA: Boolean, target: ExoPlayer) {
            if (!source.isPlaying) return
            val remaining = remainingMs(source)
            val targetIsA = !sourceIsA
            if ((targetIsA && endlessSeedProtectedA) || (!targetIsA && endlessSeedProtectedB)) return

            // Start preparing the next deck a full minute before the transition. If a candidate
            // is already queued, load it immediately into the non-playing deck instead of waiting
            // for the current song to end.
            if (remaining <= endlessPrefetchMs && !deckReadyForAuto(target)) {
                if (activeWaitingFreeDeck == null) activeWaitingFreeDeck = targetIsA
                val queued = queuedForActiveMotor()
                if (queued != null && activeWaitingFreeDeck == targetIsA) {
                    clearQueuedForActiveMotor()
                    activeWaitingFreeDeck = null
                    loadEndlessTrackIntoDeck(targetIsA, queued)
                } else {
                    discoverQueuedCandidate()
                }
            }

            // By 15 seconds the target must be READY. Keep hammering discovery/resolution.
            if (remaining <= endlessReadyDeadlineMs && !deckReadyForAuto(target)) {
                activeWaitingFreeDeck = targetIsA
                discoverQueuedCandidate()
            }

        }

        ensureNextDeck(playerA, true, playerB)
        ensureNextDeck(playerB, false, playerA)

        if (!playerA.isPlaying && !playerB.isPlaying && autoFadeJob?.isActive != true) {
            // FINAL DEAD-AIR KILLER: after long runtimes an event can occasionally be missed even
            // though one deck is already READY_NEXT and the opposite deck has reached the end.
            // In that exact state, do not wait for search/recovery bookkeeping: start READY_NEXT now.
            val aReadyNext = endlessDeckStateA == EndlessDeckState.READY_NEXT &&
                playerA.mediaItemCount > 0 && playerA.playbackState == Player.STATE_READY
            val bReadyNext = endlessDeckStateB == EndlessDeckState.READY_NEXT &&
                playerB.mediaItemCount > 0 && playerB.playbackState == Player.STATE_READY
            val aEnded = playerA.mediaItemCount == 0 || playerA.playbackState == Player.STATE_ENDED || remainingMs(playerA) <= 1_000L
            val bEnded = playerB.mediaItemCount == 0 || playerB.playbackState == Player.STATE_ENDED || remainingMs(playerB) <= 1_000L
            if (aReadyNext && bEnded) {
                cross = 0f
                binding.crossfader.progress = 0
                applyVolumes()
                applyEndlessMixInPoint(playerA, targetIsA = true)
                endlessDeckStateA = EndlessDeckState.PLAYING
                playerA.play()
                MixerStore.deckA?.let { markEndlessAutoPlayed(it) }
                endlessRecoveryDeck = null
                activeWaitingFreeDeck = false
                discoverQueuedCandidate()
                return
            }
            if (bReadyNext && aEnded) {
                cross = 1f
                binding.crossfader.progress = 100
                applyVolumes()
                applyEndlessMixInPoint(playerB, targetIsA = false)
                endlessDeckStateB = EndlessDeckState.PLAYING
                playerB.play()
                MixerStore.deckB?.let { markEndlessAutoPlayed(it) }
                endlessRecoveryDeck = null
                activeWaitingFreeDeck = true
                discoverQueuedCandidate()
                return
            }

            if (now - lastRecoveryAttemptAt < 750L) return
            lastRecoveryAttemptAt = now
            val aPlayable = deckReadyForAuto(playerA) && remainingMs(playerA) > 2_000L
            val bPlayable = deckReadyForAuto(playerB) && remainingMs(playerB) > 2_000L
            when {
                aPlayable -> {
                    cross = 0f
                    binding.crossfader.progress = 0
                    applyVolumes()
                    applyEndlessMixInPoint(playerA, targetIsA = true)
                    endlessDeckStateA = EndlessDeckState.PLAYING
                    playerA.play()
                    MixerStore.deckA?.let { markEndlessAutoPlayed(it) }
                    endlessRecoveryDeck = null
                    activeWaitingFreeDeck = false
                    discoverQueuedCandidate()
                }
                bPlayable -> {
                    cross = 1f
                    binding.crossfader.progress = 100
                    applyVolumes()
                    applyEndlessMixInPoint(playerB, targetIsA = false)
                    endlessDeckStateB = EndlessDeckState.PLAYING
                    playerB.play()
                    MixerStore.deckB?.let { markEndlessAutoPlayed(it) }
                    endlessRecoveryDeck = null
                    activeWaitingFreeDeck = true
                    discoverQueuedCandidate()
                }
                else -> {
                    // Prefer an ended/empty deck for recovery. Keep retrying until one becomes READY.
                    val recoverA = playerA.playbackState == Player.STATE_ENDED || playerA.mediaItemCount == 0 ||
                        (playerB.playbackState != Player.STATE_ENDED && remainingMs(playerA) <= remainingMs(playerB))
                    endlessRecoveryDeck = recoverA
                    activeWaitingFreeDeck = recoverA
                    clearQueuedForActiveMotor()
                    discoverQueuedCandidate()
                }
            }
        }
    }

    private fun deckReadyForAuto(player: ExoPlayer): Boolean {
        if (player.mediaItemCount == 0 || player.playbackState != Player.STATE_READY) return false
        if (endlessActive) {
            val state = if (player === playerA) endlessDeckStateA else endlessDeckStateB
            // ExoPlayer may remain STATE_READY on the old paused track (often around -0:04).
            // FREE is authoritative: a spent deck can never masquerade as the next ready deck.
            if (state != EndlessDeckState.READY_NEXT && state != EndlessDeckState.PLAYING) return false
        }
        val d = player.duration
        return d <= 0 || player.currentPosition < d - 1_000L
    }

    private fun remainingMs(player: ExoPlayer): Long {
        val d = player.duration
        return if (d > 0) (d - player.currentPosition).coerceAtLeast(0L) else Long.MAX_VALUE
    }

    private fun startAutoTransition(fromA: Boolean) {
        if (crossfadeEnabled) startAutoFade(fromA) else startSequentialNext(fromA)
    }

    private fun startSequentialNext(fromA: Boolean) {
        val source = if (fromA) playerA else playerB
        val target = if (fromA) playerB else playerA
        if (!deckReadyForAuto(target)) return

        if (quickStartupGuardA && fromA) quickStartupGuardA = false

        target.seekTo(0L)
        if (endlessActive) {
            if (fromA) endlessDeckStateB = EndlessDeckState.PLAYING else endlessDeckStateA = EndlessDeckState.PLAYING
        }

        source.pause()
        cross = if (fromA) 1f else 0f
        binding.crossfader.progress = if (fromA) 100 else 0
        applyVolumes()
        target.play()

        if (endlessActive) onEndlessTransitionComplete(freedIsA = fromA)
        updateInstantNextButtons()
    }

    private fun startAutoFade(fromA: Boolean) {
        val source = if (fromA) playerA else playerB
        // The first intentional A→B transition is the only event allowed to release QUICK's
        // startup B-block. From this point both decks may overlap for the crossfade window.
        if (quickStartupGuardA && fromA) quickStartupGuardA = false
        val target = if (fromA) playerB else playerA
        if (!deckReadyForAuto(target)) return

        applyEndlessMixInPoint(target, targetIsA = !fromA)
        if (endlessActive) {
            if (fromA) endlessDeckStateB = EndlessDeckState.PLAYING else endlessDeckStateA = EndlessDeckState.PLAYING
        }
        target.play()
        val startCross = cross
        val endCross = if (fromA) 1f else 0f

        autoFadeJob = lifecycleScope.launch {
            val steps = 50
            for (i in 0..steps) {
                if (!isActive) return@launch
                val t = i / steps.toFloat()
                cross = startCross + (endCross - startCross) * t
                binding.crossfader.progress = (cross * 100f).roundToInt().coerceIn(0, 100)
                applyVolumes()
                delay(autoFadeMs / steps)
            }
            source.pause()
            cross = endCross
            binding.crossfader.progress = (cross * 100f).roundToInt()
            applyVolumes()
            autoFadeJob = null
            if (endlessActive) onEndlessTransitionComplete(freedIsA = fromA)
        }
    }

    private fun cancelAutoFadeForManualControl() {
        if (endlessActive) stopEndlessForManualControl()
        if (autoFadeJob?.isActive == true) {
            autoFadeJob?.cancel()
            autoFadeJob = null
            autoEnabled = false
            updateAutoButton()
        }
    }

    private fun detectMixInPointMs(waveform: FloatArray, durationMs: Long): Long {
        if (durationMs <= 0L || waveform.isEmpty()) return 0L
        val maxSkipMs = minOf(20_000L, durationMs / 8)
        val maxBucket = ((maxSkipMs.toDouble() / durationMs) * waveform.size)
            .toInt().coerceIn(1, waveform.lastIndex.coerceAtLeast(1))
        // If the opening is already clearly audible, keep the true beginning.
        if (waveform.take(minOf(3, waveform.size)).any { it >= 0.20f }) return 0L
        for (i in 0 until maxBucket) {
            val end = minOf(i + 4, waveform.size)
            if (end - i >= 3 && waveform.sliceArray(i until end).count { it >= 0.22f } >= 3) {
                return ((i.toDouble() / waveform.size) * durationMs).toLong().coerceIn(0L, maxSkipMs)
            }
        }
        return 0L
    }

    private fun detectMixOutPointMs(waveform: FloatArray, durationMs: Long): Long {
        if (durationMs <= 0L || waveform.size < 8) return 0L
        // Look only near the tail. If a sustained quiet tail begins before the normal 12 s
        // trigger, transition at the start of that tail rather than fading through silence.
        val scanStart = (waveform.size * 0.72f).toInt().coerceIn(0, waveform.lastIndex)
        var quietRun = 0
        var quietStart = -1
        for (i in scanStart until waveform.size) {
            if (waveform[i] < 0.10f) {
                if (quietRun == 0) quietStart = i
                quietRun++
                if (quietRun >= 4) {
                    val t = ((quietStart.toDouble() / waveform.size) * durationMs).toLong()
                    return t.coerceIn(0L, durationMs)
                }
            } else {
                quietRun = 0
                quietStart = -1
            }
        }
        return 0L
    }

    private fun updateMasterMuteUi() {
        binding.masterMute.setImageResource(if (masterMuted) R.drawable.ic_unmute else R.drawable.ic_mute)
        binding.masterMute.contentDescription = if (masterMuted) "Unmute master" else "Mute master"
        binding.masterMute.backgroundTintList = ColorStateList.valueOf(
            ContextCompat.getColor(this, if (masterMuted) R.color.red_control else R.color.yellow_control)
        )
        if (::binding.isInitialized) {
            binding.lockedMute.setImageResource(if (masterMuted) R.drawable.ic_unmute else R.drawable.ic_mute)
            binding.lockedMute.contentDescription = if (masterMuted) "Unmute master" else "Mute master"
            binding.lockedMute.backgroundTintList = ColorStateList.valueOf(
                ContextCompat.getColor(this, if (masterMuted) R.color.red_control else R.color.yellow_control)
            )
            updateLockedSafetyActionUi()
        }
    }

    private fun updateLockedSafetyActionUi() {
        if (!::binding.isInitialized) return
        val showAction = lockedSafetyStopped || masterMuted
        binding.lockedStop.visibility = if (showAction) View.VISIBLE else View.GONE
        if (lockedSafetyStopped) {
            binding.lockedStop.text = "▶"
            binding.lockedStop.contentDescription = "Resume playback"
            binding.lockedStop.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, R.color.green_control))
            binding.lockedStop.setTextColor(ContextCompat.getColor(this, R.color.black))
        } else {
            binding.lockedStop.text = "Ⅱ"
            binding.lockedStop.contentDescription = "Pause playback"
            binding.lockedStop.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, R.color.yellow_control))
            binding.lockedStop.setTextColor(ContextCompat.getColor(this, R.color.black))
        }
    }

    private fun toggleLockedSafetyStopResume() {
        if (!lockedSafetyStopped) {
            // Second safety step after MUTE: pause transport without destroying either deck.
            // This intentionally preserves the current mix, parking track and QEM/BASIC state.
            lockedSafetyResumeA = playerA.isPlaying
            lockedSafetyResumeB = playerB.isPlaying
            lockedSafetyAutoWasEnabled = autoEnabled
            autoFadeJob?.cancel()
            playerA.pause()
            playerB.pause()
            autoEnabled = false
            lockedSafetyStopped = true
        } else {
            // PLAY restores exactly the transport that was running before the safety pause.
            lockedSafetyStopped = false
            autoEnabled = lockedSafetyAutoWasEnabled && endlessActive
            if (lockedSafetyResumeA && playerA.mediaItemCount > 0) playerA.play()
            if (lockedSafetyResumeB && playerB.mediaItemCount > 0) playerB.play()
            lockedSafetyResumeA = false
            lockedSafetyResumeB = false
            lockedSafetyAutoWasEnabled = false
        }
        applyVolumes()
        updateAutoButton()
        updateLockedSafetyActionUi()
    }

    private fun waveformEnergy(isA: Boolean): Float {
        val player = if (isA) playerA else playerB
        if (player.mediaItemCount == 0 || player.duration <= 0L) return 0f
        val wave = if (isA) MixerStore.waveA else MixerStore.waveB
        val gain = if (isA) (1f - cross) else cross
        if (wave == null || wave.isEmpty()) return if (player.isPlaying) 0.28f * gain else 0f
        val fraction = (player.currentPosition.toFloat() / player.duration).coerceIn(0f, 0.999f)
        val index = (fraction * wave.size).toInt().coerceIn(0, wave.lastIndex)
        val local = wave[index]
        return (local * gain).coerceIn(0f, 1f)
    }

    private fun updateCrossSpectrum() {
        val phase = ((playerA.currentPosition + playerB.currentPosition) % 4000L) / 4000f * 6.283185f
        binding.crossSpectrum.setEnergy(waveformEnergy(true), waveformEnergy(false), phase)
    }

    private fun updateMasterVuMeters() {
        // Lightweight MASTER L/R simulation from the same playback envelope already used by
        // the mixer UI. It never touches the audio path. Slight channel decorrelation keeps
        // the stereo needles natural while both still follow final master gain/mute state.
        val base = (waveformEnergy(true) * userVolA + waveformEnergy(false) * userVolB)
            .coerceIn(0f, 1f) * masterVolume * masterDuck * if (masterMuted) 0f else 1f
        val t = ((playerA.currentPosition + playerB.currentPosition) % 2400L) / 2400f * 6.283185f
        val l = (base * (0.92f + 0.08f * kotlin.math.sin(t))).coerceIn(0f, 1f)
        val r = (base * (0.92f + 0.08f * kotlin.math.sin(t + 1.35f))).coerceIn(0f, 1f)
        binding.masterVuLeft.setLevel(l)
        binding.masterVuRight.setLevel(r)
    }

    private fun applyEndlessMixInPoint(player: ExoPlayer, targetIsA: Boolean) {
        if (!endlessActive || player.currentPosition > 1_000L) return
        val mixIn = if (targetIsA) mixInMsA else mixInMsB
        if (mixIn > 750L) player.seekTo(mixIn)
    }

    private fun applyAutoLoudness(isA: Boolean, rms: Float) {
        if (rms <= 0.001f) return
        // Never boost above the clean 100% deck level; only tame louder tracks.
        val normalized = (loudnessTargetRms / rms).coerceIn(0.55f, 1f)
        val progress = (normalized * 100f).roundToInt().coerceIn(55, 100)
        if (isA) {
            userVolA = progress / 100f
            binding.volumeA.progress = progress
        } else {
            userVolB = progress / 100f
            binding.volumeB.progress = progress
        }
        applyVolumes()
    }

    private fun applyVolumes() {
        val headroom = 0.82f
        val aGain = (1f - cross) * headroom
        val bGain = cross * headroom
        val muteGain = if (masterMuted) 0f else 1f
        playerA.volume = (userVolA * aGain * masterVolume * masterDuck * muteGain).coerceIn(0f, 1f)
        playerB.volume = (userVolB * bGain * masterVolume * masterDuck * muteGain).coerceIn(0f, 1f)
    }

    private fun updatePlayButton(isA: Boolean) {
        val player = if (isA) playerA else playerB
        val button = if (isA) binding.playA else binding.playB
        button.isEnabled = !controlsLocked && player.mediaItemCount > 0 && player.playbackState != Player.STATE_IDLE
        if (player.isPlaying) {
            button.text = "PAUSE"
            setPlayColor(button, true)
        } else if (player.playbackState == Player.STATE_BUFFERING) {
            button.text = "LOADING"
            setPlayColor(button, false)
        } else {
            button.text = "PLAY"
            setPlayColor(button, false)
        }
    }

    private fun artistDisplayName(track: TrackRef): String {
        val separators = listOf(" - ", " – ", " — ", " | ")
        val titleArtist = separators.mapNotNull { sep ->
            val i = track.title.indexOf(sep)
            if (i > 0) track.title.substring(0, i).trim() else null
        }.minByOrNull { it.length }.orEmpty()
        if (titleArtist.length >= 2) return titleArtist
        return track.uploader
            .replace(Regex("(?i)\\bofficial\\b"), "")
            .replace(Regex("(?i)\\bVEVO\\b"), "")
            .trim(' ', '-', '_')
    }

    private fun prefetchArtistArtwork(track: TrackRef) {
        val artist = artistDisplayName(track)
        val key = endlessArtistKey(track)
        if (artist.isBlank() || key.isBlank()) return
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching { artistArtworkRepository.getArtwork(artist, key) }
        }
    }

    private fun updateArtistArtworkUi() {
        updateArtistArtworkForDeck(true, playerA.isPlaying, MixerStore.deckA)
        updateArtistArtworkForDeck(false, playerB.isPlaying, MixerStore.deckB)
    }

    private fun updateArtistArtworkForDeck(isA: Boolean, isPlaying: Boolean, track: TrackRef?) {
        val view = if (isA) binding.loadA else binding.loadB
        val currentUrl = if (isA) artistArtworkTrackA else artistArtworkTrackB
        val shown = if (isA) artistArtworkShownA else artistArtworkShownB

        if (!isPlaying || track == null) {
            if (currentUrl != null || shown) restoreDeckGlobe(isA)
            return
        }

        // While ACTIVE this location is already non-interactive; artwork is visual only.
        view.isEnabled = false
        if (shown && currentUrl == track.url) {
            view.alpha = 0.80f
            return
        }
        if (currentUrl == track.url) return

        if (isA) {
            artistArtworkJobA?.cancel()
            artistArtworkTrackA = track.url
        } else {
            artistArtworkJobB?.cancel()
            artistArtworkTrackB = track.url
        }

        val artist = artistDisplayName(track)
        val artistKey = endlessArtistKey(track)
        if (artist.isBlank() || artistKey.isBlank()) return
        val job = lifecycleScope.launch {
            val bitmap = runCatching { artistArtworkRepository.getArtwork(artist, artistKey) }.getOrNull()
            val stillCurrent = if (isA) {
                playerA.isPlaying && MixerStore.deckA?.url == track.url && artistArtworkTrackA == track.url
            } else {
                playerB.isPlaying && MixerStore.deckB?.url == track.url && artistArtworkTrackB == track.url
            }
            if (!stillCurrent || bitmap == null) return@launch

            view.animate().cancel()
            view.animate().alpha(0f).setDuration(180L).withEndAction {
                val remainsCurrent = if (isA) playerA.isPlaying && MixerStore.deckA?.url == track.url
                else playerB.isPlaying && MixerStore.deckB?.url == track.url
                if (!remainsCurrent) {
                    restoreDeckGlobe(isA)
                    return@withEndAction
                }
                view.setImageBitmap(bitmap)
                view.scaleType = ImageView.ScaleType.FIT_CENTER
                if (isA) artistArtworkShownA = true else artistArtworkShownB = true
                view.animate().alpha(0.80f).setDuration(260L).start()
            }.start()
        }
        if (isA) artistArtworkJobA = job else artistArtworkJobB = job
    }

    private fun restoreDeckGlobe(isA: Boolean) {
        val view = if (isA) binding.loadA else binding.loadB
        if (isA) {
            artistArtworkJobA?.cancel()
            artistArtworkJobA = null
            artistArtworkTrackA = null
        } else {
            artistArtworkJobB?.cancel()
            artistArtworkJobB = null
            artistArtworkTrackB = null
        }
        val hadArtwork = if (isA) artistArtworkShownA else artistArtworkShownB
        if (!hadArtwork) {
            updateLoadButtons()
            return
        }
        view.animate().cancel()
        view.animate().alpha(0f).setDuration(180L).withEndAction {
            view.setImageResource(if (isA) R.drawable.load_a else R.drawable.load_b)
            view.scaleType = ImageView.ScaleType.FIT_CENTER
            if (isA) artistArtworkShownA = false else artistArtworkShownB = false
            val targetAlpha = if (controlsLocked) 0.35f else 1f
            view.alpha = 0f
            view.animate().alpha(targetAlpha).setDuration(260L).withEndAction { updateLoadButtons() }.start()
        }.start()
    }

    private fun updateLoadButtons() {
        val aLocked = playerA.isPlaying
        val bLocked = playerB.isPlaying

        binding.loadA.isEnabled = !controlsLocked && !aLocked
        binding.loadA.alpha = if (aLocked && artistArtworkShownA) 0.80f else if (controlsLocked || aLocked) 0.35f else 1f
        binding.loadB.isEnabled = !controlsLocked && !bLocked
        binding.loadB.alpha = if (bLocked && artistArtworkShownB) 0.80f else if (controlsLocked || bLocked) 0.35f else 1f
    }

    private fun setPlayColor(button: Button, pausedState: Boolean) {
        button.backgroundTintList = null
        button.setBackgroundResource(if (pausedState) R.drawable.lux_gold_button else R.drawable.lux_blue_button)
        button.setTextColor(ContextCompat.getColor(this, if (pausedState) R.color.black else R.color.white))
        button.elevation = dp(6).toFloat()
    }

    private fun updateAutoButton() {
        binding.autoMix.backgroundTintList = null
        binding.autoMix.setBackgroundResource(if (autoEnabled) R.drawable.lux_gold_button else R.drawable.lux_silver_button)
        binding.autoMix.setTextColor(ContextCompat.getColor(this, R.color.black))
        binding.autoMix.elevation = dp(6).toFloat()
        binding.autoMix.text = if (autoEnabled) "AUTO IS ON" else "AUTO IS OFF"
        binding.autoMix.isEnabled = !controlsLocked
        syncPlaybackProtectionService()
    }

    /** Keeps the process in media-playback foreground priority while audio/AUTO is live.
     *  This does not own discovery or mutate deck state; it only prevents Android from treating
     *  EndlessMix like a disposable background Activity while the user opens ChatGPT/browser.
     */
    private fun syncPlaybackProtectionService() {
        val shouldProtect = endlessActive || autoEnabled || playerA.isPlaying || playerB.isPlaying
        if (shouldProtect) ForegroundPlaybackService.start(this)
        else ForegroundPlaybackService.stop(this)
    }

    /** Explicit user STOP: unlike stopEndlessMix(), this silences both decks immediately. */
    private fun hardStopAllPlayback() {
        if (endlessActive || autoEnabled) stopEndlessMix()
        autoEnabled = false
        controlsLocked = false
        lockedSafetyStopped = false
        lockedSafetyResumeA = false
        lockedSafetyResumeB = false
        lockedSafetyAutoWasEnabled = false
        autoFadeJob?.cancel()
        endlessDiscoveryJob?.cancel()
        qemDiscoveryJob?.cancel()
        endlessLoadJobA?.cancel()
        endlessLoadJobB?.cancel()
        playerA.pause(); playerB.pause()
        playerA.stop(); playerB.stop()
        playerA.clearMediaItems(); playerB.clearMediaItems()
        MixerStore.deckA = null
        MixerStore.deckB = null
        MixerStore.waveA = null
        MixerStore.waveB = null
        lastTrackAUrl = null
        lastTrackBUrl = null
        refreshDecks(force = true)
        updateAutoButton()
        updateControlLockUi()
        updateModeButtons()
        ForegroundPlaybackService.stop(this)
    }

    // ---------------- ENDLESS MIX ----------------

    private fun onEndlessAction() {
        if (endlessActive) {
            stopEndlessMix()
            return
        }

        syncSeedsFromCurrentDecks()
        if (endlessSeeds.isNotEmpty()) {
            startEndlessMix()
        } else {
            endlessSeedMode = true
            showEndlessSearch(true)
            binding.endlessStatus.text = if (endlessSeeds.size == 1) {
                "1/2 loaded — choose a similar second song"
            } else {
                "Choose the first seed song"
            }
            updateEndlessAction()
        }
    }

    private fun syncSeedsFromCurrentDecks() {
        if (endlessActive) return
        endlessSeeds.clear()
        MixerStore.deckA?.let { endlessSeeds.add(it) }
        MixerStore.deckB?.let { b -> if (endlessSeeds.none { it.url == b.url }) endlessSeeds.add(b) }
        updateEndlessAction()
    }

    private fun updateEndlessAction() {
        binding.endlessAction.text = when {
            endlessActive -> "STOP ENDLESS MIX"
            endlessSeeds.isNotEmpty() -> "PLAY ENDLESS MIX"
            else -> "LOAD TWO SIMILAR SONGS\nAND MAKE ENDLESS MIX"
        }
    }

    private fun showEndlessSearch(show: Boolean) {
        if (show && quickDrawerOpen) closeQuickDrawer()
        binding.endlessSearchPanel.visibility = if (show) View.VISIBLE else View.GONE
        binding.modeButtonRow.visibility = if (show) View.GONE else View.VISIBLE
        binding.endlessLowerSpacer.visibility = if (show || quickDrawerOpen) View.GONE else View.VISIBLE
        // During seed loading the search gets the lower workspace without leaving the mixer window.
        binding.autoMix.visibility = if (show) View.GONE else View.VISIBLE
        binding.crossLabels.visibility = if (show) View.GONE else View.VISIBLE
        binding.crossfader.visibility = if (show) View.GONE else View.VISIBLE
        if (!show) endlessAdapter.submit(emptyList())
    }

    private fun runEndlessSearch() {
        val q = binding.endlessSearchInput.text.toString().trim()
        if (q.isBlank()) return
        binding.endlessStatus.text = "Searching…"
        lifecycleScope.launch {
            runCatching {
                withContext(Dispatchers.IO) { searchRepo.search(q) }
            }.onSuccess { results ->
                endlessAdapter.submit(results)
                binding.endlessStatus.text = if (endlessActive && endlessAddMode) {
                    "Choose a song to add — ${results.size} results"
                } else when (endlessSeeds.size) {
                    0 -> "Choose the first song — ${results.size} results"
                    else -> "Choose a similar second song — ${results.size} results"
                }
            }.onFailure {
                binding.endlessStatus.text = "Search error: ${it.message ?: "unknown"}"
            }
        }
    }

    private fun selectEndlessSeed(track: TrackRef) {
        if (endlessActive && endlessAddMode) {
            endlessAddMode = false
            endlessManualUrls.add(track.url)
            showEndlessSearch(false)
            binding.endlessSearchInput.setText("")
            binding.endlessStatus.text = "Added to mix"
            // A deliberate user choice outranks an automatically preloaded NEXT track, but it
            // can never overwrite the currently playing deck or either still-reserved seed.
            val safeTarget: Boolean? = when {
                playerA.isPlaying && !playerB.isPlaying && !endlessSeedProtectedB -> false
                playerB.isPlaying && !playerA.isPlaying && !endlessSeedProtectedA -> true
                activeWaitingFreeDeck != null -> activeWaitingFreeDeck
                else -> null
            }
            if (safeTarget != null) {
                endlessQueued = null
                activeWaitingFreeDeck = null
                if (safeTarget) endlessLoadJobA?.cancel() else endlessLoadJobB?.cancel()
                loadEndlessTrackIntoDeck(safeTarget, track)
            } else {
                endlessQueued = track
            }
            return
        }
        if (endlessSeeds.any { it.url == track.url }) {
            Toast.makeText(this, "Choose a different second song", Toast.LENGTH_SHORT).show()
            return
        }

        when {
            MixerStore.deckA == null -> MixerStore.setA(track)
            MixerStore.deckB == null -> MixerStore.setB(track)
            endlessSeeds.isEmpty() -> MixerStore.setA(track)
            endlessSeeds.size == 1 -> {
                val first = endlessSeeds.first()
                if (MixerStore.deckA?.url == first.url) MixerStore.setB(track) else MixerStore.setA(track)
            }
            else -> return
        }

        refreshDecks()
        syncSeedsFromCurrentDecks()
        if (endlessSeeds.size >= 2) {
            endlessSeedMode = false
            showEndlessSearch(false)
            binding.endlessSearchInput.setText("")
            updateEndlessAction()
        } else {
            binding.endlessStatus.text = "1/2 loaded — choose a similar second song"
        }
    }

    private fun startEndlessMix() {
        syncSeedsFromCurrentDecks()
        if (endlessSeeds.isEmpty()) {
            showEndlessSearch(true)
            return
        }

        if (autoDiscoveryMotor == AutoDiscoveryMotor.NONE) {
            switchDiscoveryMotor(if (quickSessionActive) AutoDiscoveryMotor.QEM else AutoDiscoveryMotor.BASIC)
        }

        // Every successful Endless start advances persistent history by one mix. Previous plays
        // keep a ranking penalty for exactly the next five mixes; the sixth mix restores normal rank.
        beginPersistentMix()

        // A new Endless press is a NEW session, but it adopts whatever is already playing.
        // Nothing queued/resolving from the previous session may survive and overwrite the
        // user's newly chosen A/B tracks.
        endlessSessionGeneration++
        endlessDiscoveryJob?.cancel()
        endlessDiscoveryJob = null
        endlessLoadJobA?.cancel()
        endlessLoadJobB?.cancel()
        endlessLoadJobA = null
        endlessLoadJobB = null
        endlessQueued = null
        qemQueued = null
        basicWaitingFreeDeck = null
        qemWaitingFreeDeck = null
        endlessRecoveryDeck = null
        endlessActiveOwnerIsA = null
        endlessOwnerStartedAtMs = 0L
        endlessLastRefillKickAtMs = 0L
        endlessManualProtectedA = false
        endlessManualProtectedB = false
        endlessPendingNextUrlA = null
        endlessPendingNextUrlB = null
        endlessManualUrls.clear()
        endlessAnchorTracks.clear()
        endlessPendingAnchorTracks.clear()
        endlessDiscoveriesSinceAnchorExpansion = 0
        autoFadeJob?.cancel()
        autoFadeJob = null
        // A stale prepare callback from a previous/manual deck must never auto-start A after
        // Endless has selected B (or vice versa). Start permission belongs to exactly one deck.
        pendingEndlessStart = false
        pendingEndlessStartIsA = null

        if (::audioFocusRequest.isInitialized) audioManager.requestAudioFocus(audioFocusRequest)
        endlessActive = true
        endlessSeedMode = false
        autoEnabled = true
        // Master live-safety rule: every mix mode enters LOCK automatically.
        // Starting/locking never touches playback; the user may explicitly UNLOCK afterwards.
        controlsLocked = true
        endlessUsedUrls.clear()
        endlessUsedTrackKeys.clear()
        endlessSeedArtistKeys.clear()
        endlessNonSeedSelections = 0
        endlessPlayedAutoUrls.clear()
        endlessArtistReplayQueue.clear()
        endlessModeLocked = false
        val seedAForProfile = endlessSeeds[0]
        val seedBForProfile = endlessSeeds.getOrNull(1) ?: seedAForProfile
        // A one-seed session is valid: play/adopt it now and let background discovery fill NEXT.
        // Do not accidentally enter artist-only mode just because the fallback profile seed is itself.
        endlessArtistOnlyMode = endlessSeeds.size >= 2 && sameArtistConfidence(seedAForProfile, seedBForProfile)
        endlessGenreProfile = classifyEndlessGenre(seedAForProfile, seedBForProfile)
        endlessSceneProfile = quickSceneOverride ?: classifyEndlessScene(seedAForProfile, seedBForProfile)
        endlessModeLocked = true
        endlessArtistOnlySeed = if (endlessArtistOnlyMode) endlessSeeds[0] else null
        endlessArtistAllowLongTracks = false
        endlessRecent.clear()
        endlessRecentArtists.clear()
        endlessPlayedSongKeys.clear()
        endlessPlayedArtistHistory.clear()
        endlessPlayedArtistCooldown.clear()
        endlessSeeds.take(2).forEach {
            endlessUsedUrls.add(it.url)
            endlessUsedTrackKeys.add(endlessTrackKey(it))
            endlessSeedArtistKeys.add(endlessArtistKey(it))
            endlessRecent.add(it)
            rememberEndlessArtist(it)
            endlessAnchorTracks.add(it)
        }
        endlessDeckHasPlayedA = playerA.isPlaying
        endlessDeckHasPlayedB = playerB.isPlaying
        showEndlessSearch(false)
        updateAutoButton()
        updateEndlessAction()
        updateControlLockUi()

        // Adopt the LIVE mixer instead of forcing deck A from 0:00.
        // Preserve playback positions and the user's current crossfader. The non-playing loaded
        // deck becomes READY_NEXT; if both are playing, the louder side is treated as current.
        // QUICK is not an "adopt the live mixer" start. It has a deterministic owner:
        // deck A starts, deck B is READY_NEXT, and the fader is hard-left.
        // BASIC and QEM use the exact same physical A/B transmission and status rail.
        // Never invent a Quick-only owner: the deck that is actually playing owns the mix.
        // This keeps the crossfader/status rail truthful and makes QEM handoff identical to
        // the proven Basic Endless behavior.
        val activeIsA = when {
            playerA.isPlaying && !playerB.isPlaying -> true
            playerB.isPlaying && !playerA.isPlaying -> false
            playerA.isPlaying && playerB.isPlaying -> cross <= 0.5f
            playerA.mediaItemCount > 0 && playerB.mediaItemCount == 0 -> true
            playerB.mediaItemCount > 0 && playerA.mediaItemCount == 0 -> false
            else -> cross <= 0.5f
        }

        // Session start can never be visually/audio "cross-eyed": the fader is committed to
        // the deck that owns playback before AUTO becomes operational. QUICK with no live song
        // still owns A; an adopted live song keeps whichever deck is actually playing.
        cross = if (activeIsA) 0f else 1f
        binding.crossfader.progress = if (activeIsA) 0 else 100
        applyVolumes()

        // QEM shares Basic Endless playback ownership. Do not pause/reset both decks here.
        // QEM differs only in discovery/filtering; the physical A/B chassis and status rail are shared.

        if (activeIsA) {
            // One source deck only. The opposite seed is prepared NEXT but must not run in parallel.
            if (playerB.isPlaying) playerB.pause()
            endlessDeckStateA = EndlessDeckState.PLAYING
            endlessDeckStateB = when {
                playerB.mediaItemCount == 0 -> EndlessDeckState.FREE
                playerB.playbackState == Player.STATE_READY -> EndlessDeckState.READY_NEXT
                else -> EndlessDeckState.LOADING_NEXT
            }
            endlessSeedProtectedA = playerA.mediaItemCount > 0
            endlessSeedProtectedB = playerB.mediaItemCount > 0
            if (!playerA.isPlaying) {
                if (playerA.mediaItemCount > 0) playerA.play()
                else {
                    pendingEndlessStart = true
                    pendingEndlessStartIsA = true
                    MixerStore.deckA?.let { resolvePrepareAnalyze(true, it) }
                }
            }
        } else {
            // Symmetric B start: clear/pause A and grant deferred autoplay only to B.
            if (playerA.isPlaying) playerA.pause()
            endlessDeckStateB = EndlessDeckState.PLAYING
            endlessDeckStateA = when {
                playerA.mediaItemCount == 0 -> EndlessDeckState.FREE
                playerA.playbackState == Player.STATE_READY -> EndlessDeckState.READY_NEXT
                else -> EndlessDeckState.LOADING_NEXT
            }
            endlessSeedProtectedA = playerA.mediaItemCount > 0
            endlessSeedProtectedB = playerB.mediaItemCount > 0
            if (!playerB.isPlaying) {
                if (playerB.mediaItemCount > 0) playerB.play()
                else {
                    pendingEndlessStart = true
                    pendingEndlessStartIsA = false
                    MixerStore.deckB?.let { resolvePrepareAnalyze(false, it) }
                }
            }
        }

        // If Endless adopts a track that was already playing before the session started,
        // ExoPlayer may not emit a fresh onIsPlayingChanged(true). Record it explicitly so
        // artist cooldown and played-song hard block start from the real current song.
        when {
            playerA.isPlaying -> MixerStore.deckA?.let { rememberActuallyPlayedTrack(it) }
            playerB.isPlaying -> MixerStore.deckB?.let { rememberActuallyPlayedTrack(it) }
        }

        // Reconcile logical state with the actual player/store before the first refill kick.
        // If the UI/player is EMPTY, it is FREE regardless of stale protection/state flags.
        if (MixerStore.deckA == null || playerA.mediaItemCount == 0) {
            endlessDeckStateA = EndlessDeckState.FREE
            endlessSeedProtectedA = false
            endlessManualProtectedA = false
        }
        if (MixerStore.deckB == null || playerB.mediaItemCount == 0) {
            endlessDeckStateB = EndlessDeckState.FREE
            endlessSeedProtectedB = false
            endlessManualProtectedB = false
        }

        // If one physical deck is already FREE, arm it AND start discovery immediately.
        // The waiting flag is only the destination, never a substitute for a running search.
        if (!suppressInitialEndlessDiscovery) {
            if (endlessDeckStateA == EndlessDeckState.FREE && !playerA.isPlaying) {
                activeWaitingFreeDeck = true
                discoverQueuedCandidate()
            } else if (endlessDeckStateB == EndlessDeckState.FREE && !playerB.isPlaying) {
                activeWaitingFreeDeck = false
                discoverQueuedCandidate()
            }
        }
        updateControlLockUi()
    }

    private fun stopEndlessMix() {
        // Invalidate every asynchronous result from this session BEFORE clearing state. A stale
        // English/USA candidate from an old session must never arrive later and replace new seeds.
        endlessSessionGeneration++
        switchDiscoveryMotor(AutoDiscoveryMotor.NONE)
        quickSessionActive = false
        oneArtistMixActive = false
        qemSessionArtistPool = emptyList()
        qemSessionStyleKeys = emptySet()
        qemSessionEraKeys = emptySet()
        qemSessionInstrumental = false
        qemSessionPiano = false
        qemRecentArtistIds.clear()
        qemTrackArtistIds.clear()
        qemCandidateStamps.clear()
        quickSessionTempoBand = null
        quickStartupGuardA = false
        endlessActive = false
        endlessSeedMode = false
        autoEnabled = false
        controlsLocked = false
        pendingEndlessStart = false
        pendingEndlessStartIsA = null
        endlessDiscoveryJob?.cancel()
        endlessDiscoveryJob = null
        endlessLoadJobA?.cancel()
        endlessLoadJobB?.cancel()
        endlessLoadJobA = null
        endlessLoadJobB = null
        autoFadeJob?.cancel()
        autoFadeJob = null
        endlessQueued = null
        qemQueued = null
        basicWaitingFreeDeck = null
        qemWaitingFreeDeck = null
        endlessDeckHasPlayedA = false
        endlessDeckHasPlayedB = false
        endlessDeckStateA = EndlessDeckState.FREE
        endlessDeckStateB = EndlessDeckState.FREE
        endlessSeedProtectedA = false
        endlessSeedProtectedB = false
        endlessManualProtectedA = false
        endlessManualProtectedB = false
        endlessPendingNextUrlA = null
        endlessPendingNextUrlB = null
        endlessAddMode = false
        endlessManualUrls.clear()
        quickSceneOverride = null
        quickSessionAnchorTerms = ""
        quickSessionStyleTerms = ""
        quickLongFormDuration = false
        endlessSeeds.clear()
        endlessUsedUrls.clear()
        endlessUsedTrackKeys.clear()
        endlessSeedArtistKeys.clear()
        endlessNonSeedSelections = 0
        endlessPlayedAutoUrls.clear()
        endlessGenreProfile = EndlessGenreProfile.POP
        endlessSceneProfile = EndlessSceneProfile.GLOBAL
        endlessArtistOnlyMode = false
        endlessModeLocked = false
        endlessRecoveryDeck = null
        endlessArtistOnlySeed = null
        endlessArtistAllowLongTracks = false
        endlessArtistReplayQueue.clear()
        endlessRecent.clear()
        endlessRecentArtists.clear()
        endlessPlayedSongKeys.clear()
        endlessPlayedArtistHistory.clear()
        endlessPlayedArtistCooldown.clear()
        endlessAnchorTracks.clear()
        endlessPendingAnchorTracks.clear()
        endlessDiscoveriesSinceAnchorExpansion = 0
        showEndlessSearch(false)
        updateAutoButton()
        updateEndlessAction()
        updateControlLockUi()
        updateModeButtons()
        // Deliberately do not pause/seek either player: current music continues uninterrupted.
    }

    private fun stopEndlessForManualControl() {
        endlessSessionGeneration++
        switchDiscoveryMotor(AutoDiscoveryMotor.NONE)
        quickSessionActive = false
        oneArtistMixActive = false
        qemSessionArtistPool = emptyList()
        qemSessionStyleKeys = emptySet()
        qemSessionEraKeys = emptySet()
        qemSessionInstrumental = false
        qemSessionPiano = false
        qemRecentArtistIds.clear()
        qemTrackArtistIds.clear()
        qemCandidateStamps.clear()
        quickSessionTempoBand = null
        quickStartupGuardA = false
        endlessActive = false
        endlessSeedMode = false
        autoEnabled = false
        controlsLocked = false
        pendingEndlessStart = false
        pendingEndlessStartIsA = null
        endlessDiscoveryJob?.cancel()
        endlessDiscoveryJob = null
        endlessLoadJobA?.cancel()
        endlessLoadJobB?.cancel()
        endlessLoadJobA = null
        endlessLoadJobB = null
        endlessQueued = null
        qemQueued = null
        basicWaitingFreeDeck = null
        qemWaitingFreeDeck = null
        endlessDeckHasPlayedA = false
        endlessDeckHasPlayedB = false
        endlessDeckStateA = EndlessDeckState.FREE
        endlessDeckStateB = EndlessDeckState.FREE
        endlessSeedProtectedA = false
        endlessSeedProtectedB = false
        endlessManualProtectedA = false
        endlessManualProtectedB = false
        endlessPendingNextUrlA = null
        endlessPendingNextUrlB = null
        endlessAddMode = false
        endlessManualUrls.clear()
        quickSceneOverride = null
        quickSessionAnchorTerms = ""
        quickSessionStyleTerms = ""
        quickLongFormDuration = false
        endlessSeeds.clear()
        endlessUsedUrls.clear()
        endlessUsedTrackKeys.clear()
        endlessSeedArtistKeys.clear()
        endlessNonSeedSelections = 0
        endlessPlayedAutoUrls.clear()
        endlessGenreProfile = EndlessGenreProfile.POP
        endlessSceneProfile = EndlessSceneProfile.GLOBAL
        endlessArtistOnlyMode = false
        endlessModeLocked = false
        endlessRecoveryDeck = null
        endlessArtistOnlySeed = null
        endlessArtistAllowLongTracks = false
        endlessArtistReplayQueue.clear()
        endlessRecent.clear()
        endlessRecentArtists.clear()
        endlessPlayedSongKeys.clear()
        endlessPlayedArtistHistory.clear()
        endlessPlayedArtistCooldown.clear()
        endlessAnchorTracks.clear()
        endlessPendingAnchorTracks.clear()
        endlessDiscoveriesSinceAnchorExpansion = 0
        showEndlessSearch(false)
        updateAutoButton()
        updateEndlessAction()
        updateControlLockUi()
    }

    private fun onEndlessTransitionComplete(freedIsA: Boolean) {
        if (!endlessActive) return
        // NEXT/crossfade is playback only. It must never change the automatic discovery owner.
        // Restore the session mirror BEFORE freeing/refilling the old deck, otherwise a stale
        // quickSessionActive=false could route refill into BASIC.
        enforceAutoOwnerInvariant()
        val nowPlaying = if (freedIsA) MixerStore.deckB else MixerStore.deckA
        nowPlaying?.let { markEndlessAutoPlayed(it) }

        // Crossfade completion is authoritative: an original seed is protected only until it
        // has actually had its first turn. Once that seed was the source of a completed fade,
        // release its reservation and reclaim the deck immediately.
        if (freedIsA) endlessSeedProtectedA = false else endlessSeedProtectedB = false

        // A manually added track is protected only until it has had its guaranteed turn.
        // Once it finishes as the source of a completed transition, release that protection
        // and allow the physical deck to become FREE for normal Endless discovery again.
        val finished = if (freedIsA) MixerStore.deckA else MixerStore.deckB
        if (finished?.url in endlessManualUrls) {
            finished?.url?.let { endlessManualUrls.remove(it) }
            if (freedIsA) endlessManualProtectedA = false else endlessManualProtectedB = false
        }
        freePausedEndlessDeck(freedIsA, force = true)
    }

    private fun isNextSelectionFrozen(targetIsA: Boolean, proposedUrl: String): Boolean {
        if (!endlessActive) return false
        val source = if (targetIsA) playerB else playerA
        if (!source.isPlaying) return false
        val remaining = remainingMs(source)
        if (remaining < 0L || remaining > endlessNextFreezeMs) return false

        // In the final 40 seconds, an already chosen NEXT is immutable.
        // This includes a candidate that is still resolving/loading. If no NEXT exists yet,
        // filling the empty deck is still allowed to protect continuity.
        val pendingUrl = if (targetIsA) endlessPendingNextUrlA else endlessPendingNextUrlB
        val state = if (targetIsA) endlessDeckStateA else endlessDeckStateB
        val loadedUrl = if (state == EndlessDeckState.LOADING_NEXT || state == EndlessDeckState.READY_NEXT) {
            if (targetIsA) MixerStore.deckA?.url else MixerStore.deckB?.url
        } else null
        val chosenUrl = pendingUrl ?: loadedUrl
        return chosenUrl != null && chosenUrl != proposedUrl
    }

    private fun loadEndlessTrackIntoDeck(isA: Boolean, track: TrackRef) {
        if (!endlessActive) return
        val isManualTrack = track.url in endlessManualUrls
        // QEM/1 ARTIST hard provenance gate: every automatic track loaded while the fonoteka
        // motor owns AUTO must have been produced by that motor. This makes REGION/STYLE/ERA
        // impossible to bypass via a stale Basic Endless result or a late async callback.
        if (autoDiscoveryMotor == AutoDiscoveryMotor.QEM && !isManualTrack && !isCurrentQemCandidate(track)) {
            // FINAL QEM AIRLOCK. A stale Basic result, an older QEM generation, or a candidate
            // from another REGION/STYLE/ERA fingerprint can never enter a physical deck.
            qemQueued = null
            qemWaitingFreeDeck = isA
            discoverQemCandidate()
            return
        }
        if (isNextSelectionFrozen(isA, track.url)) {
            // Keep the late candidate for a later slot; never swap NEXT inside the final 40 s.
            queueForActiveMotor(track)
            return
        }
        // The currently audible deck is sacred until the configured mix-out window.
        // Discovery may prepare only the waiting/free deck; never overwrite a track that is playing.
        val targetPlayer = if (isA) playerA else playerB
        if (targetPlayer.isPlaying) {
            queueForActiveMotor(track)
            return
        }
        // READY_NEXT is sticky once it has passed all gates. A later auto search/rerank may not
        // churn a good prepared song out of the deck. Explicit manual ADD TO MIX is the only
        // user-authorized override; invalid/unplayable candidates are freed elsewhere.
        val currentState = if (isA) endlessDeckStateA else endlessDeckStateB
        val currentReadyUrl = if (isA) MixerStore.deckA?.url else MixerStore.deckB?.url
        if (!isManualTrack &&
            (currentState == EndlessDeckState.LOADING_NEXT || currentState == EndlessDeckState.READY_NEXT) &&
            currentReadyUrl != null && currentReadyUrl != track.url) {
            // Once an automatic NEXT has been accepted into the waiting deck, it is sticky from
            // LOADING_NEXT onward. Slot 2 may prefetch, but it may not churn a good visible NEXT.
            // Replacement happens only through explicit invalid/unplayable rejection paths.
            queueForActiveMotor(track)
            return
        }
        if ((isA && endlessSeedProtectedA) || (!isA && endlessSeedProtectedB)) {
            queueForActiveMotor(track)
            return
        }
        // Manual ADD TO MIX is law for itself: once a user-selected track owns a NEXT deck,
        // no automatic candidate, rerank, refresh, recovery or late async result may replace it.
        // The only permitted write into a manually protected deck is that same manual track.
        val manualProtected = if (isA) endlessManualProtectedA else endlessManualProtectedB
        if (manualProtected && !isManualTrack) {
            queueForActiveMotor(track)
            return
        }
        if (isManualTrack) {
            if (isA) endlessManualProtectedA = true else endlessManualProtectedB = true
        }
        val session = endlessSessionGeneration
        val loadOwner = autoDiscoveryMotor
        val loadQemGeneration = qemDiscoveryGeneration
        val loadQemFingerprint = qemFilterFingerprint
        val needsTempoValidation = requiresMeasuredTempoFilter() && !isManualTrack
        if (isA) tempoValidatedA = !needsTempoValidation else tempoValidatedB = !needsTempoValidation
        if (isA) {
            endlessPendingNextUrlA = track.url
            endlessDeckStateA = EndlessDeckState.LOADING_NEXT
        } else {
            endlessPendingNextUrlB = track.url
            endlessDeckStateB = EndlessDeckState.LOADING_NEXT
        }
        val job = lifecycleScope.launch {
            val resolved = withTimeoutOrNull(8_000L) {
                withContext(Dispatchers.IO) {
                    runCatching {
                        if (track.streamUrl != null) track
                        else track.copy(streamUrl = AudioResolver.resolveBestAudioUrl(track.url))
                    }.getOrNull()
                }
            }
            if (!endlessActive || session != endlessSessionGeneration) return@launch
            // A NEXT resolve that began under another motor can never commit after a mode switch.
            if (autoDiscoveryMotor != loadOwner) return@launch
            if (loadOwner == AutoDiscoveryMotor.QEM && !isManualTrack) {
                if (loadQemGeneration != qemDiscoveryGeneration ||
                    loadQemFingerprint != qemFilterFingerprint ||
                    !isCurrentQemCandidate(track) ||
                    (resolved != null && !isCurrentQemCandidate(resolved))) return@launch
            }
            // Hard freeze: once the opposite/current song is inside its final 40 seconds,
            // a late async completion may commit only if it is still the chosen NEXT URL.
            val chosenPending = if (isA) endlessPendingNextUrlA else endlessPendingNextUrlB
            if (chosenPending != track.url || isNextSelectionFrozen(isA, track.url)) return@launch
            // A stale automatic load may have started before the user pressed ADD TO MIX.
            // Re-check protection after resolve so that late async completion can never overwrite
            // the user's manually inserted NEXT track or mark its deck FREE.
            val protectedNow = if (isA) endlessManualProtectedA else endlessManualProtectedB
            if (!isManualTrack && protectedNow) return@launch
            if (resolved == null) {
                if (isManualTrack) {
                    endlessManualUrls.remove(track.url)
                    if (isA) endlessManualProtectedA = false else endlessManualProtectedB = false
                }
                if (isA) {
                    endlessPendingNextUrlA = null
                    endlessDeckStateA = EndlessDeckState.FREE
                } else {
                    endlessPendingNextUrlB = null
                    endlessDeckStateB = EndlessDeckState.FREE
                }
                activeWaitingFreeDeck = isA
                clearQueuedForActiveMotor()
                delay(500)
                if (session == endlessSessionGeneration) discoverQueuedCandidate()
                return@launch
            }

            if (isA) {
                MixerStore.setA(resolved)
                endlessPendingNextUrlA = null
            } else {
                MixerStore.setB(resolved)
                endlessPendingNextUrlB = null
            }
            endlessRecent.add(resolved)
            while (endlessRecent.size > 8) endlessRecent.removeAt(0)
            rememberEndlessArtist(resolved)
            endlessUsedTrackKeys.add(endlessTrackKey(resolved))
            refreshDecks()
            // refreshDecks resets per-deck analysis state. Re-apply the authoritative BPM gate
            // for this exact NEXT load; manual ADD TO MIX bypasses automatic tempo rejection.
            if (isA) tempoValidatedA = !needsTempoValidation else tempoValidatedB = !needsTempoValidation

            val direct = resolved.streamUrl
            if (direct == null) {
                // Never leave a deck stuck in LOADING_NEXT because a resolver returned a TrackRef
                // without a playable stream. Treat it exactly like a rejected candidate and keep
                // the persistent discovery loop alive.
                if (isA) {
                    endlessPendingNextUrlA = null
                    endlessDeckStateA = EndlessDeckState.FREE
                } else {
                    endlessPendingNextUrlB = null
                    endlessDeckStateB = EndlessDeckState.FREE
                }
                activeWaitingFreeDeck = isA
                delay(250)
                if (endlessActive && session == endlessSessionGeneration) discoverQueuedCandidate()
                return@launch
            }
            val key = resolved.url

            // Real BPM validation starts immediately after playable URL preparation, in parallel
            // with intro/waveform work. ExoPlayer may buffer meanwhile, but READY_NEXT is gated
            // until this check passes whenever manual tempo or a venue tempo profile is active.
            if (needsTempoValidation) {
                launch {
                    val tempo = runLowPriorityAnalysis { TempoAnalyzer.analyze(direct, cacheKey = key) }
                    val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                    if (!endlessActive || session != endlessSessionGeneration || !sameTrack) return@launch
                    if (tempo == null) {
                        // Unknown BPM must not deadlock Endless. Keep the candidate, but search terms
                        // still bias it toward the requested profile.
                        if (isA) tempoValidatedA = true else tempoValidatedB = true
                    } else {
                        if (isA) measuredBpmA = tempo.bpm else measuredBpmB = tempo.bpm
                        if (!isMeasuredTempoAcceptable(tempo)) {
                            val source = if (isA) playerB else playerA
                            val safeToReplace = !source.isPlaying || remainingMs(source) > endlessNextFreezeMs
                            if (safeToReplace) {
                                endlessUsedUrls.add(resolved.url)
                                endlessUsedTrackKeys.add(endlessTrackKey(resolved))
                                if (isA) tempoValidatedA = false else tempoValidatedB = false
                                val fallback = queuedForActiveMotor()
                                clearQueuedForActiveMotor()
                                freePausedEndlessDeck(isA, force = true)
                                activeWaitingFreeDeck = isA
                                if (fallback != null) loadEndlessTrackIntoDeck(isA, fallback)
                                else {
                                    delay(150)
                                    if (endlessActive && session == endlessSessionGeneration) discoverQueuedCandidate()
                                }
                                return@launch
                            } else {
                                // Too late to churn NEXT. Continuity beats a late preference miss.
                                if (isA) tempoValidatedA = true else tempoValidatedB = true
                            }
                        }
                        if (isA) tempoValidatedA = true else tempoValidatedB = true
                    }
                    val stateNow = if (isA) endlessDeckStateA else endlessDeckStateB
                    val playerNow = if (isA) playerA else playerB
                    if (stateNow == EndlessDeckState.LOADING_NEXT && playerNow.playbackState == Player.STATE_READY && !playerNow.isPlaying) {
                        if (isA) endlessDeckStateA = EndlessDeckState.READY_NEXT else endlessDeckStateB = EndlessDeckState.READY_NEXT
                    }
                }
            }

            launch {
                delay(1_500)
                if (!endlessActive || session != endlessSessionGeneration) return@launch
                val intro = runLowPriorityAnalysis {
                    runCatching { WaveformAnalyzer.analyzeIntro(direct) }.getOrNull()
                } ?: return@launch
                val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                if (!endlessActive || session != endlessSessionGeneration || !sameTrack) return@launch
                // Reject a genuinely near-silent/broken NEXT during the EARLY preload scan, never
                // at transition time. Inside the protected final 40 s we keep the already-prepared
                // NEXT rather than creating dead air. Prefer an already-buffered queue fallback.
                if (!isManualTrack && intro.rms >= 0.001f && intro.rms < minimumEndlessRms) {
                    val source = if (isA) playerB else playerA
                    val safeToReplace = !source.isPlaying || remainingMs(source) > endlessNextFreezeMs
                    if (safeToReplace) {
                        endlessUsedUrls.add(resolved.url)
                        endlessUsedTrackKeys.add(endlessTrackKey(resolved))
                        val fallback = queuedForActiveMotor()
                        clearQueuedForActiveMotor()
                        freePausedEndlessDeck(isA, force = true)
                        activeWaitingFreeDeck = isA
                        if (fallback != null) loadEndlessTrackIntoDeck(isA, fallback)
                        else if (endlessActive && session == endlessSessionGeneration) discoverQueuedCandidate()
                        return@launch
                    }
                }
                if (isA) mixInMsA = maxOf(mixInMsA, intro.mixInMs)
                else mixInMsB = maxOf(mixInMsB, intro.mixInMs)
            }

            launch {
                delay(5_000)
                if (!endlessActive || session != endlessSessionGeneration) return@launch
                val sameTrack = if (isA) MixerStore.deckA?.url == key else MixerStore.deckB?.url == key
                if (sameTrack) analyzeWaveform(isA, resolved)
            }
        }
        if (isA) {
            endlessLoadJobA?.cancel()
            endlessLoadJobA = job
        } else {
            endlessLoadJobB?.cancel()
            endlessLoadJobB = job
        }
    }


    private fun queueWaitingSlot2(track: TrackRef, session: Long) {
        // Motor-local logical Waiting Slot 2. It never shares storage across BASIC/QEM.
        val ownerAtQueue = autoDiscoveryMotor
        val qemGenerationAtQueue = qemDiscoveryGeneration
        if (ownerAtQueue == AutoDiscoveryMotor.QEM && !isCurrentQemCandidate(track)) {
            discoverQemCandidate()
            return
        }
        queueForActiveMotor(track)
        lifecycleScope.launch {
            val prepared = withTimeoutOrNull(8_000L) {
                withContext(Dispatchers.IO) {
                    runCatching {
                        if (track.streamUrl != null) track
                        else track.copy(streamUrl = AudioResolver.resolveBestAudioUrl(track.url))
                    }.getOrNull()
                }
            }
            if (!endlessActive || session != endlessSessionGeneration || autoDiscoveryMotor != ownerAtQueue) return@launch
            if (ownerAtQueue == AutoDiscoveryMotor.QEM && qemGenerationAtQueue != qemDiscoveryGeneration) return@launch
            if (queuedForActiveMotor()?.url != track.url) return@launch
            if (prepared?.streamUrl != null) {
                if (ownerAtQueue == AutoDiscoveryMotor.QEM && !isCurrentQemCandidate(track)) {
                    clearQueuedForActiveMotor(); discoverQemCandidate(); return@launch
                }
                clearQueuedForActiveMotor()
                queueForActiveMotor(prepared)
            } else {
                clearQueuedForActiveMotor()
                delay(250L)
                if (endlessActive && session == endlessSessionGeneration && autoDiscoveryMotor == ownerAtQueue) discoverQueuedCandidate()
            }
        }
    }

    private fun discoverQueuedCandidate() {
        if (!endlessActive) return
        when (autoDiscoveryMotor) {
            AutoDiscoveryMotor.QEM -> { discoverQemCandidate(); return }
            AutoDiscoveryMotor.BASIC -> Unit
            AutoDiscoveryMotor.NONE -> return
        }
        if (endlessQueued != null || endlessDiscoveryJob?.isActive == true) return
        if (qemHandoffPending) return
        val session = endlessSessionGeneration

        // Artist-only mode: after the catalogue is exhausted, replay the two original
        // seeds in order, then begin a fresh pass through that artist's catalogue.
        if (endlessArtistOnlyMode && endlessArtistReplayQueue.isNotEmpty()) {
            val replay = endlessArtistReplayQueue.removeFirst()
            endlessUsedUrls.add(replay.url)
            endlessUsedTrackKeys.add(endlessTrackKey(replay))
            val waiting = activeWaitingFreeDeck
            if (waiting != null) {
                activeWaitingFreeDeck = null
                loadEndlessTrackIntoDeck(waiting, replay)
                discoverQueuedCandidate()
            } else {
                endlessQueued = replay
            }
            return
        }

        val primaryQueries = buildEndlessQueries()
        endlessDiscoveryJob = lifecycleScope.launch {
            // Refill is time-critical. The previous implementation could walk dozens of NewPipe
            // queries sequentially (up to ~2 minutes), which looked like a dead Endless pipeline
            // and allowed the active song to finish before NEXT was prepared. Search in bounded
            // parallel rounds instead: one slow/bad query can never hold the deck hostage.
            suspend fun searchRound(queries: List<String>, maxQueries: Int, timeoutMs: Long): TrackRef? {
                if (queries.isEmpty()) return null
                val selected = queries.shuffled(Random.Default).take(maxQueries)
                val merged = coroutineScope {
                    selected.map { query ->
                        async(Dispatchers.IO) {
                            withTimeoutOrNull(timeoutMs) {
                                runCatching { searchRepo.search(query) }.getOrElse { emptyList() }
                            } ?: emptyList()
                        }
                    }.awaitAll().flatten()
                }
                if (!endlessActive || session != endlessSessionGeneration) return null
                return chooseEndlessCandidate(merged.distinctBy { endlessTrackKey(it) }.shuffled(Random.Default))
            }

            var candidate = searchRound(
                primaryQueries,
                maxQueries = 4,
                timeoutMs = 5_000L
            )

            // Broaden wording only; hard scene/genre/content gates stay untouched. One fallback
            // round also has a hard wall-clock ceiling instead of a long sequential marathon.
            if (candidate == null && !endlessArtistOnlyMode && endlessActive && session == endlessSessionGeneration) {
                candidate = searchRound(buildEndlessFallbackQueries(), maxQueries = 8, timeoutMs = 5_000L)
            }

            if (session != endlessSessionGeneration) return@launch
            endlessDiscoveryJob = null
            if (!endlessActive) return@launch

            if (candidate == null) {
                if (endlessArtistOnlyMode && endlessSeeds.size >= 2) {
                    if (!endlessArtistAllowLongTracks) {
                        endlessArtistAllowLongTracks = true
                        discoverQueuedCandidate()
                    } else {
                        endlessArtistAllowLongTracks = false
                        endlessUsedUrls.clear()
                        endlessUsedTrackKeys.clear()
                        endlessRecentArtists.clear()
        endlessPlayedArtistCooldown.clear()
                        endlessArtistReplayQueue.clear()
                        endlessArtistReplayQueue.addLast(endlessSeeds[0])
                        endlessArtistReplayQueue.addLast(endlessSeeds[1])
                        discoverQueuedCandidate()
                    }
                } else {
                    // AUTO is a persistent state, not a one-shot request. A rejected/exhausted
                    // batch only means "try another batch". Keep looping until a valid NEXT is
                    // READY/queued or the user turns Endless off.
                    delay(700)
                    if (endlessActive && session == endlessSessionGeneration &&
                        endlessQueued == null && endlessDiscoveryJob?.isActive != true) {
                        discoverQueuedCandidate()
                    }
                }
                return@launch
            }

            endlessDiscoveriesSinceAnchorExpansion++
            maybePromoteEndlessAnchor()
            endlessUsedUrls.add(candidate.url)
            endlessUsedTrackKeys.add(endlessTrackKey(candidate))
            val waiting = activeWaitingFreeDeck
            if (waiting != null) {
                activeWaitingFreeDeck = null
                loadEndlessTrackIntoDeck(waiting, candidate)
                // Keep one candidate ahead in the background whenever possible.
                discoverQueuedCandidate()
            } else {
                queueWaitingSlot2(candidate, session)
            }
        }
    }

    private fun buildEndlessQueries(): List<String> {
        val a = endlessSeeds.getOrNull(0) ?: return emptyList()
        // One-seed Endless is a first-class mode. Never return an empty primary query set just
        // because NEXT has not been discovered yet; use the live seed twice for query wording
        // while hard gates/cooldowns still prevent replaying the same URL/artist as immediate NEXT.
        val b = endlessSeeds.getOrNull(1) ?: a
        val artistA = endlessArtistKey(a)
        val artistB = endlessArtistKey(b)

        if (endlessArtistOnlyMode) {
            val artist = endlessArtistKey(endlessArtistOnlySeed ?: a).ifBlank { artistA }
            return listOf(
                "$artist official audio",
                "$artist official music video",
                "$artist songs"
            ).map { it.trim() }.filter { it.isNotBlank() }.distinct()
        }

        val genreAnchor = if (quickSessionStyleTerms.isNotBlank()) {
            quickSessionStyleTerms
        } else when (endlessGenreProfile) {
            EndlessGenreProfile.POP -> "pop pop rock"
            EndlessGenreProfile.POP_FOLK -> "pop folk folk"
            EndlessGenreProfile.FOLK -> "folk pop folk"
        }
        val sceneAnchor = sceneSearchAnchor(endlessSceneProfile)
        val quickAnchor = listOf(quickSessionAnchorTerms, effectiveSessionTempoTerms()).filter { it.isNotBlank() }.joinToString(" ")

        // Progressive widening: the first two discoveries are STRICTLY tied to the original
        // two songs. Only after two candidate discoveries may a successfully PLAYED in-lane
        // auto track become an additional anchor. Then we run another two discoveries, promote
        // one more confirmed track, and repeat. Region/genre themselves never widen.
        val promoted = endlessAnchorTracks.drop(2).takeLast(5).filterNot { anchor ->
            endlessPlayedArtistCooldown.lastOrNull()?.let { isSameArtistFamily(it, anchor) } == true
        }.takeLast(3)
        val progressive = promoted.joinToString(" ") { t ->
            val artist = endlessArtistKey(t)
            val title = canonicalCompareText(t.title).take(80)
            "$artist $title"
        }
        val seedSongs = "${a.title} ${b.title}"

        return (listOf(
            "$seedSongs $progressive $sceneAnchor $genreAnchor $quickAnchor similar songs official",
            "$artistA $artistB $progressive $sceneAnchor $genreAnchor $quickAnchor related artists music",
            "music like $seedSongs $progressive $sceneAnchor $genreAnchor $quickAnchor"
        )).map { it.trim().replace(Regex("\\s+"), " ") }.filter { it.isNotBlank() }.distinct()
    }

    private fun buildEndlessFallbackQueries(): List<String> {
        val genreAnchor = if (quickSessionStyleTerms.isNotBlank()) {
            quickSessionStyleTerms
        } else when (endlessGenreProfile) {
            EndlessGenreProfile.POP -> "pop pop rock"
            EndlessGenreProfile.POP_FOLK -> "pop folk folk"
            EndlessGenreProfile.FOLK -> "folk pop folk"
        }
        val sceneAnchor = sceneSearchAnchor(endlessSceneProfile)
        val quickAnchor = listOf(quickSessionAnchorTerms, effectiveSessionTempoTerms()).filter { it.isNotBlank() }.joinToString(" ")

        // No seed names here on purpose. The hard guards still enforce the locked scene/genre,
        // seed-artist block, recent-artist cooldown, used-track block and content rules.
        // This only widens discovery when seed-heavy result pages keep returning unusable items.
        val localSceneTerms = when (endlessSceneProfile) {
            EndlessSceneProfile.EX_YU -> listOf("ex yu muzika", "balkan muzika", "regionalni hitovi")
            EndlessSceneProfile.ITALIAN -> listOf("musica italiana", "canzoni italiane", "cantanti italiani", "italian pop hits")
            EndlessSceneProfile.FRANCOPHONE -> listOf("chanson francaise", "pop francais", "artistes francophones")
            EndlessSceneProfile.HISPANIC -> listOf("musica en espanol", "pop latino", "artistas latinos")
            EndlessSceneProfile.LUSOPHONE -> listOf("musica portuguesa", "musica brasileira", "pop portugues")
            EndlessSceneProfile.DACH -> listOf("deutsche musik", "deutsch pop", "german pop")
            EndlessSceneProfile.GREEK -> listOf("greek music", "ellinika tragoudia")
            EndlessSceneProfile.TURKISH -> listOf("turkce muzik", "turkish pop")
            EndlessSceneProfile.ARABIC -> listOf("arabic music", "arab pop")
            EndlessSceneProfile.SOUTH_ASIAN -> listOf("hindi music", "bollywood songs", "urdu pop")
            EndlessSceneProfile.EAST_SLAVIC -> listOf("russian music", "ukrainian music", "east slavic pop")
            EndlessSceneProfile.KOREAN -> listOf("korean music", "k pop")
            EndlessSceneProfile.JAPANESE -> listOf("japanese music", "j pop")
            EndlessSceneProfile.ANGLO -> listOf("english pop", "uk us pop", "english rock")
            EndlessSceneProfile.GLOBAL -> listOf("popular music")
        }
        val queries = mutableListOf<String>().apply {
            add("$sceneAnchor $genreAnchor $quickAnchor official music")
            add("$sceneAnchor $genreAnchor $quickAnchor popular songs official")
            add("$sceneAnchor $genreAnchor $quickAnchor related artists music")
            add("$sceneAnchor $genreAnchor $quickAnchor hits music video")
            add("$sceneAnchor $genreAnchor $quickAnchor songs")
        }
        localSceneTerms.forEach { term ->
            queries += "$term $genreAnchor $quickAnchor official music"
            queries += "$term $genreAnchor $quickAnchor popular songs"
        }
        return queries.map { it.trim().replace(Regex("\\s+"), " ") }.filter { it.isNotBlank() }.distinct()
    }

    private fun chooseEndlessCandidate(items: List<TrackRef>): TrackRef? {
        val hardBlockedWords = listOf(
            "karaoke", "reaction", "tutorial", "full album", "playlist", "instrumental karaoke",
            "interview", "intervju", "podcast", "talk", "conversation", "gostovanje", "gost u",
            "emisija", "behind the scenes", "documentary", "dokumentar", "press conference", "press",
            "q&a", "q & a", "review", "recenzija", "priča", "prica", "razgovor",
            "radio interview", "tv interview", "radio emisija", "tv emisija", "dnevnik", "vesti", "vijesti",
            "news", "breaking", "reportaza", "reportaža", "podcast clip", "shorts interview"
        )
        val softPenaltyWords = listOf(
            "acoustic", "unplugged", "remix", "concert", "session",
            "sped up", "slowed", "nightcore", "extended", "edit", "remastered"
        )
        val artistOnlySeed = endlessArtistOnlySeed

        val candidates = items.mapIndexedNotNull { index, track ->
            val title = track.title.lowercase(Locale.getDefault())
            val artist = endlessArtistKey(track)
            val trackKey = endlessTrackKey(track)
            val correctArtistForArtistOnly = !endlessArtistOnlyMode ||
                (artistOnlySeed != null && isSameArtistFamily(artistOnlySeed, track))
            val seedArtistBlocked = !endlessArtistOnlyMode &&
                endlessNonSeedSelections < 5 &&
                isOriginalSeedArtist(track)
            val activeTrack = when {
                endlessDeckStateA == EndlessDeckState.PLAYING && playerA.mediaItemCount > 0 -> MixerStore.deckA
                endlessDeckStateB == EndlessDeckState.PLAYING && playerB.mediaItemCount > 0 -> MixerStore.deckB
                playerA.isPlaying -> MixerStore.deckA
                playerB.isPlaying -> MixerStore.deckB
                else -> null
            }
            // Auto engine may NEVER schedule the current artist as immediate NEXT.
            val consecutiveArtistBlocked = !endlessArtistOnlyMode && activeTrack?.let { isSameArtistFamily(it, track) } == true
            // Short cooldown is based on tracks that actually PLAYED, not merely loaded/search hits.
            val recentArtistBlocked = !endlessArtistOnlyMode && endlessPlayedArtistCooldown.takeLast(3).any { played ->
                isSameArtistFamily(played, track)
            }
            val durationAllowed = when {
                track.durationSeconds <= 0 -> true
                track.durationSeconds < 75 -> false
                endlessArtistOnlyMode && endlessArtistAllowLongTracks -> true
                else -> track.durationSeconds <= if (quickLongFormDuration) 1500 else 480
            }

            val uploaderText = track.uploader.lowercase(Locale.getDefault())
            val isLive = listOf(" live", "live ", "concert", "koncert", "unplugged").any { it in title }
            val isCover = listOf("cover", "tribute", "obrada").any { it in title }
            val looksOfficial = track.uploaderVerified || "official" in title || "official" in uploaderText || "vevo" in uploaderText || "topic" in uploaderText
            val narrativeNonSong = looksLikeNarrativeNonSong(track)
            val formatNonSong = looksLikeProgramOrCompilation(track)
            val wrongScene = !endlessArtistOnlyMode && violatesLockedScene(track)
            val wrongGenre = !endlessArtistOnlyMode && violatesLockedGenre(track)

            val playedSongBlocked = !endlessArtistOnlyMode && trackKey in endlessPlayedSongKeys

            val passes = track.url !in endlessUsedUrls &&
                trackKey !in endlessUsedTrackKeys &&
                !playedSongBlocked &&
                correctArtistForArtistOnly &&
                !recentArtistBlocked &&
                !consecutiveArtistBlocked &&
                !seedArtistBlocked &&
                durationAllowed &&
                hardBlockedWords.none { it in title } &&
                !narrativeNonSong &&
                !formatNonSong &&
                !wrongScene &&
                !wrongGenre &&
                passesGlobalTitleTypeFilters(track)

            if (!passes) return@mapIndexedNotNull null

            // Ranking happens only AFTER every hard rule above has passed.
            // Search relevance matters, but popularity is deliberately logarithmic: 100M views
            // should beat 100k when all else is equal, without steamrolling a much better match.
            var score = 1000 - index * 5
            softPenaltyWords.forEach { word -> if (word in title) score -= 140 }

            val cleanSongShape = listOf(" - ", " – ", " — ").any { sep ->
                val pos = track.title.indexOf(sep)
                pos >= 2 && pos < track.title.length - sep.length - 1
            }
            if (cleanSongShape) score += 70
            if ("official audio" in title) score += 110
            if ("official video" in title) score += 85
            if ("vevo" in uploaderText || "topic" in uploaderText) score += 80
            if (track.uploaderVerified) score += 90
            if (track.durationSeconds in 150..330) score += 35

            if (track.viewCount > 0L) {
                val popularity = kotlin.math.log10(track.viewCount.toDouble().coerceAtLeast(1.0))
                score += (popularity * 55.0).roundToInt()
                if (track.viewCount >= 1_000_000L) score += 25
                if (track.viewCount >= 10_000_000L) score += 25
                if (track.viewCount >= 100_000_000L) score += 20
            }

            // Cross-mix history is a POST-filter ranking penalty only. It never weakens region/style
            // hard gates. A song played in mix N is penalized in N+1..N+5 and fully restored in N+6.
            score -= persistentPlaybackPenalty(track)
            score to track
        }

        if (candidates.isEmpty()) return null

        // Hard gates + quality scoring define an acceptable quality lane; playback ORDER is random
        // inside that lane. This prevents identical filter requests from recreating a glued playlist.
        val ranked = candidates.sortedByDescending { it.first }
        val bestScore = ranked.first().first
        val qualityPool = ranked
            .filter { it.first >= bestScore - 320 }
            .take(24)
            .map { it.second }
        return qualityPool.randomOrNull(Random.Default) ?: ranked.first().second
    }

    private fun loadPersistentPlaybackHistory() {
        persistentMixNumber = playbackHistoryPrefs.getInt("mix_number", 0)
        persistentSongLastPlayedMix.clear()
        persistentArtistLastPlayedMix.clear()

        fun readMap(prefKey: String, target: MutableMap<String, Int>) {
            val raw = playbackHistoryPrefs.getString(prefKey, null) ?: return
            runCatching {
                val json = JSONObject(raw)
                val keys = json.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    target[key] = json.optInt(key, 0)
                }
            }
        }
        readMap("songs", persistentSongLastPlayedMix)
        readMap("artists", persistentArtistLastPlayedMix)
        trimAndSavePersistentPlaybackHistory(save = false)
    }

    private fun beginPersistentMix() {
        persistentMixNumber += 1
        trimAndSavePersistentPlaybackHistory(save = true)
    }

    private fun persistentReferenceMix(): Int =
        if (endlessActive && persistentMixNumber > 0) persistentMixNumber else persistentMixNumber + 1

    private fun persistentPlaybackPenalty(track: TrackRef, referenceMix: Int = persistentReferenceMix()): Int {
        var penalty = 0

        val songKey = endlessTrackKey(track)
        val songLast = persistentSongLastPlayedMix[songKey]
        if (songLast != null) {
            when (referenceMix - songLast) {
                1 -> penalty += 900
                2 -> penalty += 700
                3 -> penalty += 500
                4 -> penalty += 320
                5 -> penalty += 160
            }
        }

        // Softer artist memory across mixes: enough to diversify ordering without banning an artist.
        val artistKey = endlessArtistKey(track)
        val artistLast = persistentArtistLastPlayedMix[artistKey]
        if (artistLast != null) {
            when (referenceMix - artistLast) {
                1 -> penalty += 220
                2 -> penalty += 120
                3 -> penalty += 60
            }
        }
        return penalty
    }

    private fun persistActuallyPlayedTrack(track: TrackRef) {
        if (persistentMixNumber <= 0) return
        val songKey = endlessTrackKey(track)
        if (songKey.isNotBlank()) persistentSongLastPlayedMix[songKey] = persistentMixNumber
        val artistKey = endlessArtistKey(track)
        if (artistKey.isNotBlank()) persistentArtistLastPlayedMix[artistKey] = persistentMixNumber
        trimAndSavePersistentPlaybackHistory(save = true)
    }

    private fun trimAndSavePersistentPlaybackHistory(save: Boolean) {
        // Song penalties expire after five subsequent mixes. Keep one extra generation only for
        // clean boundary handling; anything older can no longer affect ranking.
        persistentSongLastPlayedMix.entries.removeAll { (_, lastMix) -> persistentMixNumber - lastMix > 5 }
        persistentArtistLastPlayedMix.entries.removeAll { (_, lastMix) -> persistentMixNumber - lastMix > 3 }
        if (!save) return

        fun toJson(map: Map<String, Int>): String {
            val json = JSONObject()
            map.forEach { (key, value) -> json.put(key, value) }
            return json.toString()
        }
        playbackHistoryPrefs.edit()
            .putInt("mix_number", persistentMixNumber)
            .putString("songs", toJson(persistentSongLastPlayedMix))
            .putString("artists", toJson(persistentArtistLastPlayedMix))
            .apply()
    }

    private fun canonicalCompareText(text: String): String {
        val lowered = text.lowercase(Locale.ROOT)
            .replace("đ", "dj")
            .replace("ð", "d")
        val decomposed = Normalizer.normalize(lowered, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
        return decomposed
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun normalizeArtistText(text: String): String = canonicalCompareText(text)
        .replace(Regex("\\b(official|music|vevo|records|recordings|topic|channel|band|grupa)\\b"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()


    private fun titleSides(track: TrackRef): Set<String> {
        val separators = listOf(" - ", " – ", " — ", " | ")
        for (sep in separators) {
            val i = track.title.indexOf(sep)
            if (i > 0 && i + sep.length < track.title.length) {
                return setOf(
                    normalizeArtistText(track.title.substring(0, i)),
                    normalizeArtistText(track.title.substring(i + sep.length))
                ).filter { it.length >= 3 }.toSet()
            }
        }
        return emptySet()
    }

    private fun artistAliases(track: TrackRef): Set<String> {
        // Artist identity must never include the song-title side of "Artist - Song".
        return primaryArtistAliases(track).filter { alias ->
            alias.split(' ').any { it.length >= 3 }
        }.toSet()
    }

    private fun titleArtistPrefix(track: TrackRef): String {
        val separators = listOf(" - ", " – ", " — ", " | ")
        for (sep in separators) {
            val i = track.title.indexOf(sep)
            if (i > 0) return normalizeArtistText(track.title.substring(0, i))
        }
        return ""
    }

    private fun sameArtistConfidence(a: TrackRef, b: TrackRef): Boolean {
        // If both titles expose an "Artist - Song" prefix, trust that over uploader channels.
        // Two different performers on the same label/channel must never create artist-only mode.
        val prefixA = titleArtistPrefix(a)
        val prefixB = titleArtistPrefix(b)
        if (prefixA.length >= 3 && prefixB.length >= 3) {
            return prefixA == prefixB || prefixA.contains(prefixB) || prefixB.contains(prefixA)
        }

        val uploaderA = normalizeArtistText(a.uploader)
        val uploaderB = normalizeArtistText(b.uploader)
        val genericUploaderWords = listOf("records", "recordings", "label", "music", "channel", "topic", "official")
        val uploaderLooksGeneric = genericUploaderWords.any { it in uploaderA || it in uploaderB }
        if (!uploaderLooksGeneric && uploaderA.length >= 3 && uploaderB.length >= 3 && uploaderA == uploaderB) return true

        val aliasesA = artistAliases(a)
        val aliasesB = artistAliases(b)
        return aliasesA.any { aa ->
            aliasesB.any { bb ->
                aa.length >= 4 && bb.length >= 4 && (aa == bb || aa.contains(bb) || bb.contains(aa))
            }
        }
    }

    private fun isSameArtistFamily(seed: TrackRef, candidate: TrackRef): Boolean {
        val seedAliases = artistAliases(seed)
        val candidateAliases = artistAliases(candidate)
        if (seedAliases.any { sa -> candidateAliases.any { ca ->
                sa.length >= 4 && ca.length >= 4 && (sa == ca || sa.contains(ca) || ca.contains(sa))
            } }) return true

        val stop = setOf(
            "official", "music", "video", "audio", "lyrics", "lyric", "records", "recordings",
            "topic", "channel", "band", "grupa", "the", "and", "feat", "ft"
        )
        fun words(text: String): Set<String> = canonicalCompareText(text)
            .split(' ')
            .map { it.trim() }
            .filter { it.length >= 4 && it !in stop }
            .toSet()

        val seedArtistWords = words(endlessArtistKey(seed))
        if (seedArtistWords.isEmpty()) return false
        val candidateWords = words(endlessArtistKey(candidate)) + words(candidate.uploader) + words(candidate.title)
        return seedArtistWords.any { it in candidateWords }
    }

    private fun primaryArtistAliases(track: TrackRef): Set<String> {
        val aliases = linkedSetOf<String>()
        val uploader = normalizeArtistText(track.uploader)
        if (uploader.length >= 3) aliases += uploader
        val separators = listOf(" - ", " – ", " — ", " | ")
        for (sep in separators) {
            val i = track.title.indexOf(sep)
            if (i > 0) {
                val prefix = normalizeArtistText(track.title.substring(0, i))
                if (prefix.length >= 3) aliases += prefix
                break
            }
        }
        return aliases
    }

    private fun isOriginalSeedArtist(candidate: TrackRef): Boolean {
        val candidateTitle = canonicalCompareText(candidate.title)
        val candidateAliases = primaryArtistAliases(candidate)
        return endlessSeeds.take(2).any { seed ->
            val seedAliases = primaryArtistAliases(seed) + endlessArtistKey(seed)
            seedAliases.filter { it.length >= 3 }.any { seedAlias ->
                candidateAliases.any { ca ->
                    ca == seedAlias || ca.contains(seedAlias) || seedAlias.contains(ca)
                } || candidateTitle == seedAlias || candidateTitle.startsWith("$seedAlias ")
            }
        }
    }

    private fun markEndlessAutoPlayed(track: TrackRef) {
        if (!endlessActive) return
        rememberActuallyPlayedArtist(track)
        if (endlessSeeds.take(2).any { seed -> seed.url == track.url }) return
        if (endlessPlayedAutoUrls.add(track.url)) {
            endlessNonSeedSelections++
            if (track.url in endlessManualUrls) return
            // Only a track that really played AND still passes the locked region/genre gates may
            // influence future discovery. A stray wrong-region result can never contaminate anchors.
            if (hasPositiveLockedSceneEvidence(track) && !violatesLockedGenre(track) &&
                endlessPendingAnchorTracks.none { it.url == track.url } &&
                endlessAnchorTracks.none { it.url == track.url }) {
                endlessPendingAnchorTracks.addLast(track)
            }
            maybePromoteEndlessAnchor()
        }
    }


    private fun rememberActuallyPlayedTrack(track: TrackRef) {
        if (!endlessActive) return

        val songKey = endlessTrackKey(track)
        if (songKey.isNotBlank()) endlessPlayedSongKeys.add(songKey)

        // Ignore duplicate callbacks for the same currently-playing item, but if this artist
        // genuinely returns later, append a new playback position. The last three song positions
        // therefore enforce exactly: three OTHER songs must pass before AUTO may use that artist.
        val last = endlessPlayedArtistHistory.lastOrNull()
        if (last?.url != track.url) {
            endlessPlayedArtistHistory.add(track)
            while (endlessPlayedArtistHistory.size > 64) endlessPlayedArtistHistory.removeAt(0)
        }

        endlessPlayedArtistCooldown.clear()
        endlessPlayedArtistCooldown.addAll(endlessPlayedArtistHistory.takeLast(3))

        // Record only real playback, never a search hit or merely-preloaded candidate.
        persistActuallyPlayedTrack(track)
        if (quickSessionActive) {
            qemTrackArtistIds[endlessTrackKey(track)]?.let { artistId ->
                qemRecentArtistIds.remove(artistId)
                qemRecentArtistIds.addLast(artistId)
                while (qemRecentArtistIds.size > 5) qemRecentArtistIds.removeFirst()
            }
        }
    }

    private fun rememberActuallyPlayedArtist(track: TrackRef) {
        // Compatibility for existing transition callbacks; the unified function de-duplicates
        // callbacks for the same physical track and updates both song and artist histories.
        rememberActuallyPlayedTrack(track)
    }

    private fun maybePromoteEndlessAnchor() {
        if (endlessDiscoveriesSinceAnchorExpansion < 2) return
        val next = if (endlessPendingAnchorTracks.isEmpty()) return else endlessPendingAnchorTracks.removeFirst()
        if (hasPositiveLockedSceneEvidence(next) && !violatesLockedGenre(next)) {
            endlessAnchorTracks.add(next)
            while (endlessAnchorTracks.size > 7) endlessAnchorTracks.removeAt(2)
            endlessDiscoveriesSinceAnchorExpansion = 0
        }
    }

    private fun sceneSearchAnchor(scene: EndlessSceneProfile): String = when (scene) {
        EndlessSceneProfile.EX_YU -> "ex yu balkan"
        EndlessSceneProfile.ANGLO -> "english"
        EndlessSceneProfile.FRANCOPHONE -> "francophone french"
        EndlessSceneProfile.HISPANIC -> "spanish latin"
        EndlessSceneProfile.LUSOPHONE -> "portuguese brazil portugal"
        EndlessSceneProfile.DACH -> "german deutsch"
        EndlessSceneProfile.ITALIAN -> "italian italiano"
        EndlessSceneProfile.GREEK -> "greek"
        EndlessSceneProfile.TURKISH -> "turkish"
        EndlessSceneProfile.ARABIC -> "arabic"
        EndlessSceneProfile.SOUTH_ASIAN -> "hindi urdu indian"
        EndlessSceneProfile.EAST_SLAVIC -> "russian ukrainian"
        EndlessSceneProfile.KOREAN -> "korean"
        EndlessSceneProfile.JAPANESE -> "japanese"
        EndlessSceneProfile.GLOBAL -> ""
    }

    private fun classifyEndlessScene(a: TrackRef, b: TrackRef): EndlessSceneProfile {
        val sa = classifyTrackScene(a)
        val sb = classifyTrackScene(b)
        return when {
            sa == sb && sa != EndlessSceneProfile.GLOBAL -> sa
            sa == EndlessSceneProfile.GLOBAL -> sb
            sb == EndlessSceneProfile.GLOBAL -> sa
            else -> EndlessSceneProfile.GLOBAL
        }
    }

    private fun classifyTrackScene(track: TrackRef): EndlessSceneProfile {
        val raw = "${track.title} ${track.uploader}".lowercase(Locale.ROOT)
        val text = canonicalCompareText(raw)

        // Strong regional metadata/artist signals. This is intentionally used before the generic
        // lexical classifier so common EX-YU seeds with short titles still lock the correct basin.
        val strongSceneSignals = listOf(
            EndlessSceneProfile.EX_YU to listOf(
                "dino merlin", "dzenan loncarevic", "zeljko joksimovic", "tony cetinski", "lexington",
                "miligram", "colonia", "hari mata hari", "crvena jabuka", "bijelo dugme", "parni valjak",
                "zdravko colic", "severina", "gibonni", "petar graso", "aco pejovic", "sasa matic",
                "aleksandra prijovic", "lepa brena", "ceca", "barbara bobak", "andrijana cekic",
                "magazin", "novi fosili", "prljavo kazaliste", "plavi orkestar", "zabranjeno pusenje",
                "divlje jagode", "atomsko skloniste", "riblja corba", "bajaga", "bajaga i instruktori",
                "galija", "kerber", "yu grupa", "smak", "film", "azra", "haustor", "elektricni orgazam",
                "idoli", "piloti", "van gogh", "neverne bebe", "negative", "partibrejkers", "ekv",
                "ekatarina velika", "indexi", "ambasadori", "bolero", "regina", "valentino", "vatra",
                "silente", "hladno pivo", "psihomodo pop", "leteci odred", "daleka obala", "oliver dragojevic",
                "massimo savic", "vanna", "josipa lisac", "nina badric", "jelena rozga", "danijela martinovic",
                "tajci", "vesna pisarovic", "toni cetinski", "zeljko bebеk", "zeljko bebek", "aleksandra radovic",
                "vlado georgiev", "sergej cetkovic", "knez", "miladin sobic", "ramba amadeus", "who see",
                "grand production", "croatia records", "idjvideos", "city records", "hayat production",
                "pgp rts", "pgp rtb", "jugoton", "diskoton", "menart", "aquamarius", "fm jam"
            ),
            EndlessSceneProfile.ITALIAN to listOf(
                "eros ramazzotti", "toto cutugno", "laura pausini", "zucchero", "nek", "tiziano ferro",
                "gianna nannini", "umberto tozzi", "adriano celentano", "al bano", "romina power",
                "ricchi e poveri", "raffaella carra", "marco mengoni", "mahmood", "annalisa", "giorgia",
                "elisa", "jovanotti", "cesare cremonini", "biagio antonacci", "lucio dalla", "mina",
                "matia bazar", "pooh", "the kolors", "elodie"
            ),
            EndlessSceneProfile.ANGLO to listOf(
                "bon jovi", "the calling", "coldplay", "blur", "oasis", "u2", "queen", "elton john",
                "ed sheeran", "dua lipa", "adele", "taylor swift", "bruno mars", "maroon 5", "the weeknd",
                "sade", "sting", "norah jones", "michael buble", "george michael", "phil collins",
                "fleetwood mac", "simply red", "jamiroquai", "bee gees", "robbie williams", "seal",
                "stevie wonder", "lionel richie", "whitney houston", "billy joel", "hall and oates"
            ),
            EndlessSceneProfile.FRANCOPHONE to listOf(
                "stromae", "indila", "celine dion", "mylene farmer", "edith piaf", "joe dassin",
                "francis cabrel", "zaz", "kendji girac", "christophe mae"
            ),
            EndlessSceneProfile.HISPANIC to listOf(
                "shakira", "enrique iglesias", "luis miguel", "alejandro sanz", "maluma", "bad bunny",
                "karol g", "daddy yankee", "rosalia", "juan luis guerra", "juanes", "carlos vives",
                "marc anthony", "ricky martin", "chayanne", "mana", "ricardo arjona", "camilo",
                "sebastian yatra", "luis fonsi", "gloria estefan", "santana"
            ),
            EndlessSceneProfile.LUSOPHONE to listOf(
                "roberto carlos", "mariza", "ana moura", "ivete sangalo", "jorge e mateus",
                "gusttavo lima", "marilia mendonca", "caetano veloso", "gilberto gil"
            ),
            EndlessSceneProfile.DACH to listOf(
                "herbert gronemeyer", "nena", "udo lindenberg", "helene fischer", "sarah connor",
                "mark forster", "peter maffay", "rammstein"
            ),
            EndlessSceneProfile.TURKISH to listOf(
                "tarkan", "sezen aksu", "mustafa sandal", "sertab erener", "hadise", "kenan dogulu"
            ),
            EndlessSceneProfile.GREEK to listOf(
                "anna vissi", "sakis rouvas", "despina vandi", "nikos vertis", "antonis remos"
            ),
            EndlessSceneProfile.ARABIC to listOf(
                "amr diab", "nancy ajram", "elissa", "ragheb alama", "kadim al sahir", "fairuz"
            ),
            EndlessSceneProfile.SOUTH_ASIAN to listOf(
                "arijit singh", "shreya ghoshal", "sonu nigam", "atif aslam", "neha kakkar", "badshah"
            ),
            EndlessSceneProfile.EAST_SLAVIC to listOf(
                "alla pugacheva", "dima bilan", "sergey lazarev", "ani lorak", "loboda", "monatik"
            ),
            EndlessSceneProfile.KOREAN to listOf(
                "bts", "blackpink", "twice", "exo", "iu", "newjeans", "stray kids"
            ),
            EndlessSceneProfile.JAPANESE to listOf(
                "hikaru utada", "ayumi hamasaki", "yoasobi", "kenshi yonezu", "arashi", "one ok rock"
            )
        )
        strongSceneSignals.firstOrNull { (_, signals) -> signals.any { it in text } }?.let { return it.first }
        if (Regex("[đć]").containsMatchIn(raw)) return EndlessSceneProfile.EX_YU

        fun score(words: List<String>): Int = words.count { w ->
            Regex("(^|\\s)${Regex.escape(w)}(\\s|$)").containsMatchIn(text)
        }

        // Script is a very strong signal and avoids trying to maintain a country database.
        if (Regex("[\\u3040-\\u30ff\\u31f0-\\u31ff]").containsMatchIn(raw)) return EndlessSceneProfile.JAPANESE
        if (Regex("[\\uac00-\\ud7af]").containsMatchIn(raw)) return EndlessSceneProfile.KOREAN
        if (Regex("[\\u0600-\\u06ff]").containsMatchIn(raw)) return EndlessSceneProfile.ARABIC
        if (Regex("[\\u0370-\\u03ff]").containsMatchIn(raw)) return EndlessSceneProfile.GREEK
        if (Regex("[\\u0900-\\u097f]").containsMatchIn(raw)) return EndlessSceneProfile.SOUTH_ASIAN

        val dictionaries = listOf(
            EndlessSceneProfile.EX_YU to listOf(
                "miligram", "bulevari", "ljubav", "srce", "sreca", "zivot", "noc", "moja", "moje", "moj",
                "tvoja", "tvoje", "tvoj", "dodji", "dodi", "pjesma", "pesma", "pjeva", "peva", "kafana",
                "samo", "tebe", "meni", "zelim", "volim", "nikad", "zauvijek", "zauvek", "balkan", "ex yu"
            ),
            EndlessSceneProfile.FRANCOPHONE to listOf(
                "amour", "chanson", "coeur", "avec", "pour", "sans", "toujours", "jamais", "mon", "ma", "mes", "toi", "moi", "dans", "une", "des"
            ),
            EndlessSceneProfile.HISPANIC to listOf(
                "amor", "corazon", "contigo", "quiero", "vida", "noche", "beso", "besame", "siempre", "nunca", "para", "conmigo", "cancion", "latino"
            ),
            EndlessSceneProfile.LUSOPHONE to listOf(
                "amor", "coracao", "voce", "saudade", "beijo", "noite", "vida", "meu", "minha", "brasil", "portugal", "sertanejo"
            ),
            EndlessSceneProfile.DACH to listOf(
                "liebe", "herz", "nacht", "leben", "immer", "niemals", "mein", "meine", "dein", "deine", "deutsch", "schlager"
            ),
            EndlessSceneProfile.ITALIAN to listOf(
                "amore", "cuore", "vita", "notte", "sempre", "mai", "mio", "mia", "tuo", "tua", "italiano", "canzone"
            ),
            EndlessSceneProfile.TURKISH to listOf(
                "ask", "aşk", "kalp", "gece", "hayat", "seni", "benim", "senin", "turk", "turkish"
            ),
            EndlessSceneProfile.EAST_SLAVIC to listOf(
                "любовь", "сердце", "песня", "ночь", "жизнь", "моя", "тебя", "россия", "украина", "russian", "ukrainian"
            ),
            EndlessSceneProfile.ANGLO to listOf(
                "girls", "boys", "love", "heart", "night", "baby", "forever", "never", "you", "your", "english", "uk", "british"
            )
        )

        var best = EndlessSceneProfile.GLOBAL
        var bestScore = 0
        for ((scene, words) in dictionaries) {
            val s = score(words)
            if (s > bestScore) {
                bestScore = s
                best = scene
            }
        }
        // Require two lexical hits so a single universal word such as "amor" cannot lock a scene.
        return if (bestScore >= 2) best else EndlessSceneProfile.GLOBAL
    }

    private fun hasPositiveLockedSceneEvidence(track: TrackRef): Boolean {
        if (endlessSceneProfile == EndlessSceneProfile.GLOBAL) return true
        val candidateScene = classifyTrackScene(track)
        if (candidateScene == endlessSceneProfile) return true
        if (candidateScene != EndlessSceneProfile.GLOBAL) return false

        // REGION IS CANON: fallback may broaden artists, never the language/scene basin.
        // An exact/family artist match to an already-confirmed in-lane anchor is valid positive
        // evidence; otherwise unknown metadata is rejected rather than guessed into the session.
        if (endlessAnchorTracks.any { isSameArtistFamily(it, track) }) return true

        val raw = "${track.title} ${track.uploader}".lowercase(Locale.ROOT)
        val text = canonicalCompareText(raw)
        val sceneLabels = when (endlessSceneProfile) {
            EndlessSceneProfile.ITALIAN -> listOf(
                "italia", "italian", "italiano", "italiana", "musica italiana", "canzone italiana",
                "warner music italy", "sony music italy", "universal music italia", "rai", "sanremo"
            )
            EndlessSceneProfile.FRANCOPHONE -> listOf("france", "francais", "francaise", "chanson francaise", "francophone")
            EndlessSceneProfile.HISPANIC -> listOf("latin", "latino", "latina", "espanol", "mexico", "argentina", "colombia", "spain")
            EndlessSceneProfile.LUSOPHONE -> listOf("brasil", "brazil", "portugal", "portugues", "portuguese")
            EndlessSceneProfile.DACH -> listOf("deutsch", "deutsche", "germany", "austria", "schweiz", "switzerland")
            EndlessSceneProfile.GREEK -> listOf("greek", "greece", "ellinika")
            EndlessSceneProfile.TURKISH -> listOf("turkish", "turkiye", "turkce")
            EndlessSceneProfile.ARABIC -> listOf("arabic", "arab", "middle east")
            EndlessSceneProfile.SOUTH_ASIAN -> listOf("hindi", "urdu", "bollywood", "india", "pakistan")
            EndlessSceneProfile.EAST_SLAVIC -> listOf("russian", "ukrainian", "russia", "ukraine")
            EndlessSceneProfile.KOREAN -> listOf("korean", "korea", "k-pop", "kpop")
            EndlessSceneProfile.JAPANESE -> listOf("japanese", "japan", "j-pop", "jpop")
            EndlessSceneProfile.ANGLO -> listOf("uk", "british", "usa", "american", "english")
            else -> emptyList()
        }
        if (sceneLabels.any { it in text }) return true

        if (endlessSceneProfile == EndlessSceneProfile.EX_YU) {
            if (Regex("[čćžšđ]").containsMatchIn(raw)) return true
            val regionalLabels = listOf(
                "croatia records", "grand production", "grand online", "idjvideos", "idj tunes",
                "city records", "hayat production", "bn music", "bn televizija", "pink music",
                "pgp rts", "jugoton", "diskoton", "sarajevo", "beograd", "belgrade", "zagreb",
                "podgorica", "split", "novi sad", "balkan", "ex yu"
            )
            if (regionalLabels.any { it in text }) return true
        }
        return false
    }

    private fun violatesLockedScene(track: TrackRef): Boolean = !hasPositiveLockedSceneEvidence(track)

    private fun classifyEndlessGenre(a: TrackRef, b: TrackRef): EndlessGenreProfile {
        val text = canonicalCompareText("${a.title} ${a.uploader} ${b.title} ${b.uploader}")
        val popFolkSignals = listOf(
            "pop folk", "folk pop", "popfolk", "cajka", "cajke", "turbofolk", "turbo folk",
            "miligram", "aco pejovic", "sasa matic", "tanja savic", "aleksandra prijovic", "ceca",
            "dragana mirkovic", "seka aleksic", "dara bubamara", "ana bekuta", "lepa brena"
        )
        val folkSignals = listOf(
            "folk", "narodna", "narodne", "narodni", "izvorna", "izvorne", "sevdah", "sevdalinka",
            "tambura", "tamburica", "kolo", "gusle", "ganga", "etno", "kafana", "kafanska"
        )
        return when {
            popFolkSignals.any { it in text } -> EndlessGenreProfile.POP_FOLK
            folkSignals.any { it in text } -> EndlessGenreProfile.FOLK
            else -> EndlessGenreProfile.POP
        }
    }

    private fun looksLikeNarrativeNonSong(track: TrackRef): Boolean {
        val text = canonicalCompareText(track.title)
        val narrativePhrases = listOf(
            "otkrio", "otkrila", "otkriva", "rekao", "rekla", "kaze", "kazao", "kazala",
            "govori", "govorio", "govorila", "pricao", "pricala", "prica o", "ispricao", "ispricala",
            "objasnio", "objasnila", "priznao", "priznala", "progovorio", "progovorila",
            "reveals", "revealed", "says", "said", "talks about", "speaks about", "explains",
            "admits", "confesses", "interview", "intervju", "gostovanje", "razgovor"
        )
        return narrativePhrases.any { phrase ->
            Regex("(^|\\s)${Regex.escape(phrase)}(\\s|$)").containsMatchIn(text)
        }
    }

    private fun looksLikeProgramOrCompilation(track: TrackRef): Boolean {
        // Global content-format guard: Endless Mix wants ONE SONG, not a quiz/show/playlist/mix package.
        // Canonical matching makes this work across accents (e.g. MUZIČKI -> muzicki).
        val text = canonicalCompareText("${track.title} ${track.uploader}")
        val exactFormats = listOf(
            "muzicki kviz", "music quiz", "quiz show", "kviz",
            "kompilacija", "compilation", "playlist", "plejlista",
            "top hits", "greatest hits", "best of", "hitovi", "najveci hitovi",
            "radio show", "radio emisija", "tv show", "tv emisija", "countdown",
            "non stop", "nonstop", "continuous mix", "full mix", "dj mix",
            "megamixt", "megamix", "medley", "mix compilation"
        )
        if (exactFormats.any { phrase ->
                Regex("(^|\\s)${Regex.escape(phrase)}(\\s|$)").containsMatchIn(text)
            }) return true

        // Numbered/best-of packages are especially common in QUICK searches and must never
        // masquerade as one long song (e.g. "Top 50 Ex Yu Rock Songs" or
        // "50 najboljih Ex-YU rock pesama").
        val numberedPackage = listOf(
            Regex("\\btop\\s+\\d{1,3}\\b"),
            Regex("\\b\\d{1,3}\\s+(najboljih|najbolje|najvecih|best)\\b"),
            Regex("\\b(best|top)\\s+(songs|pesama|pjesama|hitova|tracks)\\b"),
            Regex("\\b\\d{1,3}\\s+(songs|pesama|pjesama|hitova|tracks)\\b")
        ).any { it.containsMatchIn(text) }
        if (numberedPackage) return true

        // Generic MIX is ambiguous (a real song can be a remix), so reject it only when the
        // surrounding title clearly describes a package/era/collection rather than Artist - Song.
        val hasArtistSongShape = listOf(" - ", " – ", " — ").any { sep ->
            val i = track.title.indexOf(sep)
            i >= 2 && i < track.title.length - sep.length - 1
        }
        val packageSignals = listOf(
            "80", "90", "2000", "2020", "2021", "2022", "2023", "2024", "2025", "2026",
            "ex yu", "balkan mix", "summer mix", "party mix", "dance mix", "rock mix",
            "pop mix", "folk mix", "hour mix", "1 hour", "2 hour", "mix songs", "mix pesama", "mix pjesama"
        )
        return !hasArtistSongShape && " mix" in " $text " && packageSignals.any { it in text }
    }

    private fun violatesLockedGenre(track: TrackRef): Boolean {
        val text = canonicalCompareText("${track.title} ${track.uploader}")
        val folkLean = listOf(
            "folk", "narodna", "narodne", "narodni", "izvorna", "izvorne", "sevdah", "sevdalinka",
            "tambura", "tamburica", "gusle", "ganga", "kafana", "kafanska", "turbofolk", "turbo folk",
            "cajka", "cajke",
            // POP / POP-ROCK must not silently drift into folk just because a normal song title
            // contains no genre word. These are strong artist/uploader signals, not ranking hints.
            "aco pejovic", "sasa matic", "tanja savic", "aleksandra prijovic", "ceca",
            "dragana mirkovic", "seka aleksic", "dara bubamara", "ana bekuta", "lepa brena",
            "barbara bobak", "andrijana cekic", "mile kitic", "sinan sakic", "saban saulic",
            "halid beslic", "halid muslimovic", "haris dzinovic", "jana todorovic", "rasta folk"
        )
        val nationalistOrWar = listOf(
            "patriotska", "patriotske", "patriotic", "rodoljubiva", "rodoljubive", "rodoljubna",
            "nacionalisticka", "nacionalisticke", "nationalist", "nationalistic",
            "cetnik", "cetnici", "cetnicka", "ustasa", "ustase", "ustaska", "ratna pjesma", "ratne pjesme",
            "vojna pjesma", "vojne pjesme", "mars na", "bojna pjesma"
        )
        return when (endlessGenreProfile) {
            EndlessGenreProfile.POP -> folkLean.any { it in text } || nationalistOrWar.any { it in text }
            EndlessGenreProfile.POP_FOLK -> false // Friendly with FOLK by design.
            EndlessGenreProfile.FOLK -> false // Friendly with POP/FOLK by design.
        }
    }

    private fun rememberEndlessArtist(track: TrackRef) {
        val key = endlessArtistKey(track)
        if (key.isBlank()) return
        endlessRecentArtists.remove(key)
        endlessRecentArtists.add(key)
        while (endlessRecentArtists.size > 5) endlessRecentArtists.removeAt(0)
    }

    private fun passesGlobalTitleTypeFilters(track: TrackRef): Boolean {
        val title = canonicalCompareText(track.title)
        if (allowLive && !Regex("\\blive\\b").containsMatchIn(title)) return false
        if (allowCover && !Regex("\\bcover\\b").containsMatchIn(title)) return false
        if (onlyOfficial && !Regex("\\bofficial\\b").containsMatchIn(title)) return false
        return true
    }

    private fun endlessArtistKey(track: TrackRef): String {
        // Prefer the artist prefix from common "Artist - Song" titles. Comparison keys
        // are always Unicode-canonical so Ž/Z, accents and punctuation cannot bypass blocks.
        val separators = listOf(" - ", " – ", " — ", " | ")
        val titleArtist = separators
            .mapNotNull { sep ->
                val index = track.title.indexOf(sep)
                if (index > 0) track.title.substring(0, index) else null
            }
            .minByOrNull { it.length }
            .orEmpty()
        val normalizedTitleArtist = normalizeArtistText(titleArtist)
        if (normalizedTitleArtist.length >= 2) return normalizedTitleArtist

        return normalizeArtistText(track.uploader)
    }

    private fun endlessTrackKey(track: TrackRef): String {
        val separators = listOf(" - ", " – ", " — ", " | ")
        var songPart = track.title
        val uploader = normalizeArtistText(track.uploader)
        for (sep in separators) {
            val i = track.title.indexOf(sep)
            if (i > 0 && i + sep.length < track.title.length) {
                val leftRaw = track.title.substring(0, i)
                val rightRaw = track.title.substring(i + sep.length)
                val left = normalizeArtistText(leftRaw)
                val right = normalizeArtistText(rightRaw)
                songPart = when {
                    uploader.length >= 3 && (uploader.contains(left) || left.contains(uploader)) -> rightRaw
                    uploader.length >= 3 && (uploader.contains(right) || right.contains(uploader)) -> leftRaw
                    else -> rightRaw
                }
                break
            }
        }
        return songPart
            .lowercase(Locale.getDefault())
            .replace(Regex("\\([^)]*\\)|\\[[^]]*]"), " ")
            .replace(
                Regex("\\b(official|video|audio|lyrics|lyric|hd|hq|remastered|remaster|live|version|acoustic|unplugged|remix|mix|cover|concert|session|extended|edit|radio|sped|slowed|nightcore)\\b"),
                " "
            )
            .replace(Regex("\\b(19|20)\\d{2}\\b"), " ")
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .trim()
    }

    private fun updateEndlessFilterButtons() {
        fun style(button: Button, on: Boolean, label: String) {
            button.backgroundTintList = null
            button.setBackgroundResource(if (on) R.drawable.lux_worn_gold_button else R.drawable.lux_worn_gunmetal_button)
            button.setTextColor(ContextCompat.getColor(this, if (on) R.color.black else R.color.lux_silver))
            button.elevation = dp(4).toFloat()
            button.text = "$label ${if (on) "ON" else "OFF"}"
            button.isEnabled = !controlsLocked
        }
        style(binding.filterLive, allowLive, "LIVE")
        style(binding.filterCover, allowCover, "COVER")
        style(binding.filterOfficial, onlyOfficial, "OFFICIAL")
        style(binding.quickFilterLive, allowLive, "LIVE")
        style(binding.quickFilterCover, allowCover, "COVER")
        style(binding.quickFilterOfficial, onlyOfficial, "OFFICIAL")
        updateTempoButtons()
    }

    private fun updateCrossfadeButton() {
        if (!::binding.isInitialized) return
        binding.crossfadeMode.text = if (crossfadeEnabled) "CROSSFADE ON" else "CROSSFADE OFF"
        binding.crossfadeMode.backgroundTintList = null
        binding.crossfadeMode.setBackgroundResource(if (crossfadeEnabled) R.drawable.lux_gold_button else R.drawable.lux_black_button)
        binding.crossfadeMode.setTextColor(ContextCompat.getColor(this, if (crossfadeEnabled) R.color.black else R.color.lux_silver))
        binding.crossfadeMode.elevation = dp(4).toFloat()
        binding.crossfadeMode.isEnabled = true
        binding.lockedCrossfadeMode.text = binding.crossfadeMode.text
        binding.lockedCrossfadeMode.backgroundTintList = null
        binding.lockedCrossfadeMode.setBackgroundResource(if (crossfadeEnabled) R.drawable.lux_gold_button else R.drawable.lux_black_button)
        binding.lockedCrossfadeMode.setTextColor(ContextCompat.getColor(this, if (crossfadeEnabled) R.color.black else R.color.lux_silver))
        binding.lockedCrossfadeMode.isEnabled = true
        binding.quickCrossfadeMode.text = binding.crossfadeMode.text
        binding.quickCrossfadeMode.backgroundTintList = null
        binding.quickCrossfadeMode.setBackgroundResource(if (crossfadeEnabled) R.drawable.lux_gold_button else R.drawable.lux_black_button)
        binding.quickCrossfadeMode.setTextColor(ContextCompat.getColor(this, if (crossfadeEnabled) R.color.black else R.color.lux_silver))
        binding.quickCrossfadeMode.isEnabled = true
    }

    private fun requestEndlessVoiceSearch() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            launchSpeechRecognizer()
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun setupAudioFocusProtection() {
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setWillPauseWhenDucked(false)
            .setOnAudioFocusChangeListener { change ->
                when (change) {
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                        masterDuck = 0.35f
                        applyVolumes()
                    }
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                        resumeAAfterFocus = playerA.isPlaying
                        resumeBAfterFocus = playerB.isPlaying
                        masterDuck = 0.12f
                        applyVolumes()
                    }
                    AudioManager.AUDIOFOCUS_GAIN -> {
                        masterDuck = 1f
                        applyVolumes()
                        if (resumeAAfterFocus && !playerA.isPlaying && playerA.playbackState == Player.STATE_READY) playerA.play()
                        if (resumeBAfterFocus && !playerB.isPlaying && playerB.playbackState == Player.STATE_READY) playerB.play()
                        resumeAAfterFocus = false
                        resumeBAfterFocus = false
                    }
                    AudioManager.AUDIOFOCUS_LOSS -> {
                        resumeAAfterFocus = playerA.isPlaying
                        resumeBAfterFocus = playerB.isPlaying
                        masterDuck = 0.12f
                        applyVolumes()
                    }
                }
            }
            .build()
        audioManager.requestAudioFocus(audioFocusRequest)
    }

    private fun animateLockHardware(afterMidpoint: () -> Unit) {
        binding.lockIcon.animate().cancel()
        binding.mixLock.animate().cancel()
        binding.mixLock.animate()
            .translationY(dp(3).toFloat())
            .scaleX(0.985f)
            .scaleY(0.96f)
            .setDuration(70L)
            .withEndAction {
                afterMidpoint()
                binding.lockIcon.rotation = -28f
                binding.lockIcon.scaleX = 0.82f
                binding.lockIcon.scaleY = 0.82f
                binding.lockIcon.animate().rotation(0f).scaleX(1f).scaleY(1f).setDuration(150L).start()
                binding.mixLock.animate().translationY(0f).scaleX(1f).scaleY(1f).setDuration(120L).start()
            }.start()
    }

    private fun toggleControlLock() {
        if (!controlsLocked) {
            animateLockHardware {
                controlsLocked = true
                updateControlLockUi()
            }
            return
        }
        AlertDialog.Builder(this)
            .setTitle("ARE YOU SURE?")
            .setMessage("Unlock mixer controls?")
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("UNLOCK") { _, _ ->
                animateLockHardware {
                    controlsLocked = false
                    updateControlLockUi()
                }
            }
            .show()
    }

    private fun requestAddToMix() {
        if (!endlessActive) return
        AlertDialog.Builder(this)
            .setTitle("ARE YOU SURE?")
            .setMessage("Add a song manually to the current Endless Mix?")
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("ADD TO MIX") { _, _ ->
                endlessAddMode = true
                showEndlessSearch(true)
                binding.endlessSearchInput.isEnabled = true
                binding.endlessSearchButton.isEnabled = true
                binding.endlessVoiceButton.isEnabled = true
                binding.endlessStatus.text = "Search a song to add to this mix"
                binding.endlessSearchInput.requestFocus()
            }
            .show()
    }

    private fun updateControlLockUi() {
        val lockedHardwareView = endlessActive && controlsLocked && !quickDrawerOpen && !endlessAddMode
        binding.lockedControlsPanel.visibility = if (lockedHardwareView) View.VISIBLE else View.GONE
        val showConsoleActionRow = !lockedHardwareView && !quickDrawerOpen && !endlessAddMode
        binding.endlessLockActionRow.visibility = if (showConsoleActionRow) View.VISIBLE else View.GONE
        binding.mixLock.visibility = View.VISIBLE
        binding.mixLock.isEnabled = endlessActive
        binding.mixLock.alpha = if (endlessActive) 1f else 0.55f
        binding.addToMix.visibility = View.VISIBLE
        binding.addToMix.isEnabled = endlessActive
        binding.addToMix.alpha = if (endlessActive) 1f else 0.55f
        binding.addToMix.backgroundTintList = null
        binding.addToMix.setBackgroundResource(if (endlessActive) R.drawable.lux_worn_silver_button else R.drawable.lux_worn_gunmetal_button)
        binding.addToMix.setTextColor(ContextCompat.getColor(this, if (endlessActive) R.color.black else R.color.lux_silver))
        binding.lockText.text = if (controlsLocked) "UNLOCK" else "LOCK"
        binding.lockText.setTextColor(ContextCompat.getColor(this, if (controlsLocked) R.color.black else R.color.lux_silver))
        binding.lockIcon.setImageResource(if (controlsLocked) R.drawable.ic_lock_closed else R.drawable.ic_lock_open)
        binding.lockIcon.setColorFilter(ContextCompat.getColor(this, if (controlsLocked) R.color.black else R.color.lux_gold))
        binding.mixLock.backgroundTintList = null
        binding.mixLock.setBackgroundResource(if (controlsLocked) R.drawable.lux_worn_gold_button else R.drawable.lux_worn_gunmetal_button)
        binding.mixLock.elevation = dp(6).toFloat()

        if (lockedHardwareView) {
            binding.endlessAction.visibility = View.GONE
            binding.endlessFilterRow.visibility = View.GONE
            binding.modeButtonRow.visibility = View.VISIBLE
        } else if (!quickDrawerOpen && !endlessAddMode) {
            binding.endlessAction.visibility = View.GONE
            binding.endlessFilterRow.visibility = View.VISIBLE
            binding.modeButtonRow.visibility = View.VISIBLE
        }

        binding.playA.isEnabled = !controlsLocked && playerA.mediaItemCount > 0
        binding.playB.isEnabled = !controlsLocked && playerB.mediaItemCount > 0
        binding.autoMix.isEnabled = !controlsLocked
        binding.crossfader.isEnabled = !controlsLocked
        updateCrossfadeButton()
        binding.volumeA.isEnabled = !controlsLocked
        binding.volumeB.isEnabled = !controlsLocked
        binding.masterVolume.isEnabled = true
        binding.masterMute.isEnabled = true
        binding.masterMute.alpha = 1f
        binding.waveA.isEnabled = !controlsLocked
        binding.waveB.isEnabled = !controlsLocked
        binding.endlessAction.isEnabled = !controlsLocked
        val addSearchAllowed = endlessActive && endlessAddMode
        binding.endlessSearchInput.isEnabled = !controlsLocked || addSearchAllowed
        binding.endlessSearchButton.isEnabled = !controlsLocked || addSearchAllowed
        binding.endlessVoiceButton.isEnabled = !controlsLocked || addSearchAllowed
        updateEndlessFilterButtons()
        updateLoadButtons()
    }

    private fun showLockedControlNotice() {
        android.widget.Toast.makeText(this, "UNLOCK TO USE CONTROLS", android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun setupQuickEndlessUi() {
        binding.quickCountryButton.setOnClickListener { showQuickCountryPicker() }
        binding.lockedAddToMix.setOnClickListener { requestAddToMix() }
        binding.lockedUnlock.setOnClickListener { toggleControlLock() }
        binding.lockedMute.setOnClickListener {
            masterMuted = !masterMuted
            updateMasterMuteUi()
        }
        binding.lockedStop.setOnClickListener { toggleLockedSafetyStopResume() }
        binding.quickDrawerClose.setOnClickListener { closeQuickDrawer() }
        binding.quickEndlessButton.setOnClickListener {
            if (controlsLocked) { showLockedControlNotice(); return@setOnClickListener }
            // While QEM owns AUTO, this button is the doorway to a NEW QEM filter, not STOP.
            // Stopping the current QEM here used to force the user to kill playback before changing
            // filters and also pushed the state machine through the shared restart path.
            if (endlessActive && autoDiscoveryMotor == AutoDiscoveryMotor.QEM && !oneArtistMixActive) {
                enforceAutoOwnerInvariant()
                if (!quickDrawerOpen) openQuickDrawer()
                return@setOnClickListener
            }
            // Opening the QEM drawer is UI-only. Do not alter the currently running motor until ENTER.
            if (controlsLocked && !quickDrawerOpen) {
                AlertDialog.Builder(this)
                    .setTitle("ARE YOU SURE?")
                    .setMessage("Open Quick Endless Mix while controls are locked?")
                    .setNegativeButton("CANCEL", null)
                    .setPositiveButton("QUICK MIX") { _, _ -> openQuickDrawer() }
                    .show()
            } else {
                if (quickDrawerOpen) closeQuickDrawer() else openQuickDrawer()
            }
        }
        // Keep an explicit STOP path without sacrificing the normal tap for hot QEM changes.
        binding.quickEndlessButton.setOnLongClickListener {
            if (controlsLocked) { showLockedControlNotice(); return@setOnLongClickListener true }
            if (endlessActive && autoDiscoveryMotor == AutoDiscoveryMotor.QEM && !oneArtistMixActive) {
                stopEndlessMix()
                updateModeButtons()
                true
            } else false
        }
        binding.quickDrawerEnter.setOnClickListener {
            binding.teslaSpark.burst()
            binding.quickDrawerEnter.animate()
                .scaleX(0.985f).scaleY(0.96f).setDuration(80L)
                .withEndAction { binding.quickDrawerEnter.animate().scaleX(1f).scaleY(1f).setDuration(120L).start() }
                .start()
            if (quickRegions.isEmpty() && quickCountry == null && quickEras.isEmpty() && quickStyles.isEmpty() && tempoBand == null) closeQuickDrawer()
            else startQuickEndlessMix()
        }
        binding.quickDrawerReset.setOnClickListener { resetQuickSelections() }

        rebuildQuickRegionButtons()
        rebuildQuickStyleButtons()

        val eraPale = "#F2DEAD"
        val eraStrong = "#FF0000"
        bindQuickChoice(binding.quickEraEvergreen, quickEras, "evergreen classics", eraPale, eraStrong)
        bindQuickChoice(binding.quickEra70, quickEras, "original release 1970s", eraPale, eraStrong)
        bindQuickChoice(binding.quickEra80, quickEras, "original release 1980s", eraPale, eraStrong)
        bindQuickChoice(binding.quickEra90, quickEras, "original release 1990s", eraPale, eraStrong)
        bindQuickChoice(binding.quickEra2000, quickEras, "original release 2000s", eraPale, eraStrong)
        bindQuickChoice(binding.quickEra2010, quickEras, "original release 2010s", eraPale, eraStrong)
        bindQuickChoice(binding.quickEra2020, quickEras, "original release 2020s", eraPale, eraStrong)
        updateQuickEnterUi()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    private fun makeQuickButton(
        label: String,
        pale: String,
        selected: Boolean,
        weighted: Boolean = false,
        onClick: () -> Unit
    ): Button {
        return Button(this).apply {
            layoutParams = if (weighted) {
                LinearLayout.LayoutParams(0, dp(56), 1f).apply {
                    setMargins(dp(2), dp(2), dp(2), dp(2))
                }
            } else {
                LinearLayout.LayoutParams(dp(if (label.length > 13) 142 else 112), dp(56)).apply {
                    setMargins(dp(2), dp(2), dp(2), dp(2))
                }
            }
            text = label.uppercase(Locale.getDefault())
            textSize = when {
                label.length > 17 -> 8.5f
                label.length > 13 -> 9f
                else -> 10.5f
            }
            isAllCaps = false
            maxLines = 2
            backgroundTintList = null
            setBackgroundResource(if (selected) R.drawable.lux_gold_button else R.drawable.lux_silver_button)
            setTextColor(android.graphics.Color.parseColor("#111111"))
            elevation = dp(4).toFloat()
            minWidth = 0
            minHeight = 0
            setPadding(dp(3), 0, dp(3), 0)
            setOnClickListener { onClick() }
        }
    }

    private fun addWrappedButtons(
        container: LinearLayout,
        options: List<QemFonoteka.UiOption>,
        selected: Set<String>,
        pale: String,
        perRow: Int,
        onToggle: (QemFonoteka.UiOption) -> Unit
    ) {
        container.removeAllViews()
        options.chunked(perRow).forEach { chunk ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(62))
            }
            chunk.forEach { option ->
                row.addView(makeQuickButton(option.label, pale, option.key in selected, weighted = true) {
                    onToggle(option)
                })
            }
            // Keep the last incomplete row aligned without stretching its existing buttons.
            repeat(perRow - chunk.size) {
                row.addView(Space(this).apply {
                    layoutParams = LinearLayout.LayoutParams(0, dp(56), 1f)
                })
            }
            container.addView(row)
        }
    }

    private fun rebuildQuickRegionButtons() {
        // Main strip is intentionally short and finger-friendly.
        // GLOBAL is represented by no selected region; all other regions/countries live
        // in the long PICK REGION / COUNTRY selector.
        val primaryKeys = listOf("ANGLO", "LATINO_SPANISH", "ITALIAN", "EX_YU")
        val byKey = qemFonoteka.regionOptions().associateBy { it.key }
        val options = buildList {
            add(QemFonoteka.UiOption("__GLOBAL__", "Global", "region"))
            add(QemFonoteka.UiOption("ANGLO", "English", "region"))
            add(QemFonoteka.UiOption("LATINO_SPANISH", "LATINO", "region"))
            add(QemFonoteka.UiOption("ITALIAN", "Italian", "region"))
            add(QemFonoteka.UiOption("EX_YU", "EX-YU", "region"))
        }
        val row = binding.quickRegionDynamicRow
        addWrappedButtons(
            row,
            options,
            if (quickRegions.isEmpty()) setOf("__GLOBAL__") else quickRegions,
            "#B9D9F2",
            perRow = 5
        ) { option ->
            quickCountry = null
            binding.quickCountryButton.text = "PICK COUNTRY ▾"
            quickRegions.clear()
            if (option.key != "__GLOBAL__") quickRegions.add(option.key)
            rebuildQuickRegionButtons()
            rebuildQuickStyleButtons()
            updateQuickEnterUi()
        }
    }

    private fun rebuildQuickStyleButtons() {
        val row = binding.quickStyleDynamicRow
        val options = mutableListOf(QemFonoteka.UiOption("__MIXED__", "Mixed", "mixed"))
        options += qemFonoteka.styleOptions(quickRegions)
        val allowed = options.map { it.key }.filter { it != "__MIXED__" }.toSet()
        quickStyles.retainAll(allowed)
        // Combined / paired styles occupy the first two rows and use their own hardware color.
        val combinedKeys = setOf("__MIXED__", "POP_ROCK", "HIP_HOP_RAP", "RNB_HIP_HOP", "POP_FOLK", "REGGAE_CARIBBEAN", "WORLD", "DANCE")
        val ordered = options.sortedBy { if (it.key in combinedKeys) 0 else 1 }
        row.removeAllViews()
        ordered.chunked(4).forEach { chunk ->
            val styleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(62)) }
            chunk.forEach { option ->
                val selectedNow = if (quickStyles.isEmpty()) option.key == "__MIXED__" else option.key in quickStyles
                val button = makeQuickButton(if (option.key == "DANCE") "DANCE/HOUSE" else option.label, "#BFE6CD", selectedNow, weighted = true) {
                    if (option.key == "__MIXED__") quickStyles.clear() else { if (option.key in quickStyles) quickStyles.remove(option.key) else quickStyles.add(option.key) }
                    rebuildQuickStyleButtons(); updateQuickEnterUi()
                }
                if (!selectedNow && option.key in combinedKeys) { button.setBackgroundResource(R.drawable.lux_blue_button); button.setTextColor(ContextCompat.getColor(this, R.color.white)) }
                styleRow.addView(button)
            }
            repeat(4 - chunk.size) { styleRow.addView(Space(this).apply { layoutParams = LinearLayout.LayoutParams(0, dp(56), 1f) }) }
            row.addView(styleRow)
        }

    }

    private fun bindQuickChoice(button: Button, set: MutableSet<String>, value: String, pale: String, strong: String) {
        fun paint() {
            button.backgroundTintList = null
            button.setBackgroundResource(if (value in set) R.drawable.lux_gold_button else R.drawable.lux_silver_button)
            button.setTextColor(android.graphics.Color.parseColor("#111111"))
            button.elevation = dp(4).toFloat()
        }
        paint()
        button.setOnClickListener {
            if (value in set) set.remove(value) else set.add(value)
            paint()
            updateQuickEnterUi()
        }
    }

    private fun updateQuickEnterUi() {
        val hasAny = quickRegions.isNotEmpty() || quickCountry != null || quickEras.isNotEmpty() || quickStyles.isNotEmpty() || tempoBand != null
        binding.quickDrawerEnter.text = if (hasAny) "START NEW MIX" else "▼"
        binding.quickDrawerEnter.backgroundTintList = null
        binding.quickDrawerEnter.setBackgroundResource(if (hasAny) R.drawable.lux_gold_button else R.drawable.lux_black_button)
        binding.quickDrawerEnter.setTextColor(android.graphics.Color.parseColor(if (hasAny) "#111111" else "#D0D3D6"))
        binding.quickDrawerEnter.elevation = dp(7).toFloat()
    }

    private fun resetQuickSelections() {
        quickRegions.clear()
        quickCountry = null
        binding.quickCountryButton.text = "PICK COUNTRY ▾"
        tempoBand = null
        quickStyles.clear()
        quickEras.clear()
        rebuildQuickRegionButtons()
        rebuildQuickStyleButtons()
        listOf(binding.quickEraEvergreen, binding.quickEra70, binding.quickEra80, binding.quickEra90,
            binding.quickEra2000, binding.quickEra2010, binding.quickEra2020).forEach {
            it.backgroundTintList = null
            it.setBackgroundResource(R.drawable.lux_silver_button)
            it.setTextColor(android.graphics.Color.rgb(17, 17, 17))
            it.elevation = dp(4).toFloat()
        }
        updateTempoButtons()
        updateQuickEnterUi()
    }

    private fun activeTempoBand(): String? =
        if (quickSessionActive) quickSessionTempoBand ?: tempoBand else tempoBand

    // HARD RULE: real BPM/energy analysis runs ONLY after an explicit tempo-button selection.
    // No SLOW/MIDDLE/FAST/VERY FAST selection = zero TempoAnalyzer work in Quick or refill.
    private fun requiresMeasuredTempoFilter(): Boolean =
        activeTempoBand() != null

    private fun isMeasuredTempoAcceptable(result: TempoAnalyzer.Result): Boolean {
        val band = result.band
        val energy = result.energyBand
        fun lowEnergy() = energy == "low"
        fun lowMidEnergy() = energy == "low" || energy == "middle"
        fun midHighEnergy() = energy == "middle" || energy == "high" || energy == "very high"
        fun highEnergy() = energy == "high" || energy == "very high"

        // Universal tempo buttons are musical-feel filters: normalized BPM + measured ENERGY.
        activeTempoBand()?.let { selected ->
            return when (selected) {
                "slow" -> band == "slow" && lowEnergy()
                "middle" -> band == "middle" && lowMidEnergy()
                "fast" -> band == "fast" && midHighEnergy()
                "very fast" -> band == "very fast" && highEnergy()
                else -> true
            }
        }
        return true
    }

    private fun tempoSearchTerms(): String = when (if (quickSessionActive) quickSessionTempoBand ?: tempoBand else tempoBand) {
        "slow" -> "slow mellow relaxed ballad"
        "middle" -> "mid tempo medium tempo groove"
        "fast" -> "upbeat fast dance energetic"
        "very fast" -> "very fast high energy uptempo"
        else -> ""
    }

    private fun effectiveSessionTempoTerms(): String = tempoSearchTerms()

    private fun setTempoBand(value: String?) {
        tempoBand = if (tempoBand == value) null else value
        if (endlessActive && quickSessionActive) quickSessionTempoBand = tempoBand
        updateTempoButtons()
        if (quickDrawerOpen) updateQuickEnterUi()
    }

    private fun updateTempoButtons() {
        if (!::binding.isInitialized) return
        fun paint(button: Button, value: String) {
            val on = tempoBand == value
            button.backgroundTintList = ColorStateList.valueOf(
                ContextCompat.getColor(this, if (on) R.color.red_control else R.color.white)
            )
            button.setTextColor(ContextCompat.getColor(this, if (on) R.color.white else R.color.black))
        }
    }

    private fun quickAllowsLongForm(): Boolean {
        if (quickStyles.isEmpty()) return false
        val longKeys = setOf("JAZZ", "WORLD", "CLASSICAL", "INSTRUMENTAL", "PIANO")
        return quickStyles.all { it in longKeys }
    }

    private fun openQuickDrawer() {
        if (endlessAddMode) return
        quickDrawerOpen = true
        // QEM drawer owns the whole console below the banner. Keep only the header visible.
        binding.deckTransportRow.visibility = View.GONE
        binding.deckMeterRow.visibility = View.GONE
        binding.autoMix.visibility = View.GONE
        binding.crossLabels.visibility = View.GONE
        binding.crossFaderArea.visibility = View.GONE
        binding.startEndlessAutoMix.visibility = View.GONE
        binding.endlessAction.visibility = View.GONE
        binding.endlessLockActionRow.visibility = View.GONE
        binding.lockedControlsPanel.visibility = View.GONE
        binding.endlessFilterRow.visibility = View.GONE
        binding.tempoFilterRow.visibility = View.GONE
        binding.endlessSearchPanel.visibility = View.GONE
        binding.endlessLowerSpacer.visibility = View.GONE
        binding.modeButtonRow.visibility = View.GONE
        // Full-screen QEM body: main console relinquishes all space below the fixed header.
        binding.endlessContainer.visibility = View.GONE
        binding.quickSearchingRow.visibility = View.GONE
        binding.quickDrawer.visibility = View.VISIBLE
        binding.quickDrawer.alpha = 0f
        binding.quickDrawer.translationY = 120f
        binding.quickDrawer.animate().alpha(1f).translationY(0f).setDuration(160L).start()
    }

    private fun closeQuickDrawer() {
        quickDrawerOpen = false
        binding.quickSearchingRow.visibility = View.GONE
        binding.quickDrawerEnter.isEnabled = true
        binding.quickDrawer.visibility = View.GONE
        binding.quickDrawer.translationY = 0f
        binding.endlessContainer.visibility = View.VISIBLE
        binding.deckTransportRow.visibility = View.VISIBLE
        binding.deckMeterRow.visibility = View.VISIBLE
        binding.autoMix.visibility = View.VISIBLE
        binding.crossLabels.visibility = View.VISIBLE
        binding.crossFaderArea.visibility = View.VISIBLE
        binding.endlessAction.visibility = View.GONE
        binding.endlessFilterRow.visibility = View.VISIBLE
        binding.tempoFilterRow.visibility = View.VISIBLE
        binding.endlessSearchPanel.visibility = View.GONE
        binding.endlessLowerSpacer.visibility = View.VISIBLE
        updateEndlessAction()
        updateControlLockUi()
        updateContextualModeUi()
    }

    private fun showQuickCountryPicker() {
        val countries = qemFonoteka.availableCountries(quickRegions)
            .filterNot { it.equals("Balkans", ignoreCase = true) }
        if (countries.isEmpty()) {
            Toast.makeText(this, "No countries for the current region.", Toast.LENGTH_SHORT).show()
            return
        }

        val density = resources.displayMetrics.density
        // Compact country wall: on tablets almost the whole catalog fits at once.
        // Keep buttons large enough to hit, but avoid the old weighted rows that
        // stretched five countries into full-height pillars.
        val columns = when {
            resources.configuration.smallestScreenWidthDp >= 720 -> 7
            resources.configuration.smallestScreenWidthDp >= 600 -> 6
            else -> 4
        }

        var countryPicker: AlertDialog? = null
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((14 * density).toInt(), (10 * density).toInt(), (14 * density).toInt(), (2 * density).toInt())
        }
        val title = TextView(this).apply {
            text = "COUNTRY"
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(ContextCompat.getColor(this@MixerActivity, R.color.white))
            gravity = android.view.Gravity.CENTER
            setPadding(0, 0, 0, (8 * density).toInt())
        }
        container.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val grid = GridLayout(this).apply {
            columnCount = columns
            rowCount = ((countries.size + columns - 1) / columns)
            useDefaultMargins = true
            alignmentMode = GridLayout.ALIGN_BOUNDS
        }

        fun selectCountry(country: String) {
            quickCountry = country
            binding.quickCountryButton.text = country.take(22)
            rebuildQuickRegionButtons()
            rebuildQuickStyleButtons()
            updateQuickEnterUi()
        }

        countries.forEach { country ->
            val button = Button(this).apply {
                text = country
                textSize = if (resources.configuration.smallestScreenWidthDp >= 600) 11.5f else 10.5f
                isAllCaps = false
                maxLines = 2
                gravity = android.view.Gravity.CENTER
                backgroundTintList = null
                setBackgroundResource(if (quickCountry.equals(country, ignoreCase = true)) R.drawable.lux_gold_button else R.drawable.lux_silver_button)
                setTextColor(ContextCompat.getColor(this@MixerActivity, R.color.black))
                elevation = dp(4).toFloat()
                minWidth = 0
                minHeight = 0
                setPadding((4 * density).toInt(), (2 * density).toInt(), (4 * density).toInt(), (2 * density).toInt())
                setOnClickListener {
                    selectCountry(country)
                    countryPicker?.dismiss()
                }
            }
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(if (resources.configuration.smallestScreenWidthDp >= 600) 50 else 48)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                // No row weight: fixed compact rows prevent giant vertical country pillars.
                rowSpec = GridLayout.spec(GridLayout.UNDEFINED)
                setMargins((2 * density).toInt(), (2 * density).toInt(), (2 * density).toInt(), (2 * density).toInt())
            }
            grid.addView(button, params)
        }

        val gridScroll = ScrollView(this).apply {
            isFillViewport = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            addView(grid, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        container.addView(gridScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        countryPicker = AlertDialog.Builder(this)
            .setView(container)
            .setNegativeButton("CLEAR") { _, _ ->
                quickCountry = null
                binding.quickCountryButton.text = "PICK COUNTRY ▾"
                rebuildQuickRegionButtons()
                rebuildQuickStyleButtons()
                updateQuickEnterUi()
            }
            .create()
        countryPicker.setOnShowListener {
            countryPicker?.window?.setLayout(
                (resources.displayMetrics.widthPixels * 0.96f).toInt(),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        countryPicker.show()
    }

    private fun sceneForQuickRegion(region: String): EndlessSceneProfile? = when (region) {

        "ex yu" -> EndlessSceneProfile.EX_YU
        "italian" -> EndlessSceneProfile.ITALIAN
        "latin" -> EndlessSceneProfile.HISPANIC
        "english uk us" -> EndlessSceneProfile.ANGLO
        "french francophone" -> EndlessSceneProfile.FRANCOPHONE
        "german dach" -> EndlessSceneProfile.DACH
        "turkish" -> EndlessSceneProfile.TURKISH
        "arabic" -> EndlessSceneProfile.ARABIC
        "brazilian portuguese" -> EndlessSceneProfile.LUSOPHONE
        "japanese" -> EndlessSceneProfile.JAPANESE
        "korean" -> EndlessSceneProfile.KOREAN
        else -> null
    }

    private fun sceneForQuickCountry(country: String): EndlessSceneProfile? = when (country) {
        // Anglo
        "United Kingdom", "United States", "Ireland", "Canada", "Australia", "New Zealand" -> EndlessSceneProfile.ANGLO
        // Italian
        "Italy", "San Marino", "Vatican City" -> EndlessSceneProfile.ITALIAN
        // Hispanic / Spanish-speaking
        "Spain", "Mexico", "Argentina", "Colombia", "Chile", "Peru", "Venezuela", "Ecuador", "Bolivia",
        "Paraguay", "Uruguay", "Costa Rica", "Panama", "Guatemala", "Honduras", "El Salvador", "Nicaragua",
        "Cuba", "Dominican Republic", "Puerto Rico", "Equatorial Guinea" -> EndlessSceneProfile.HISPANIC
        // Lusophone
        "Brazil", "Portugal", "Angola", "Mozambique", "Cape Verde", "Guinea-Bissau", "Sao Tome and Principe", "Timor-Leste" -> EndlessSceneProfile.LUSOPHONE
        // Francophone core
        "France", "Belgium", "Luxembourg", "Monaco", "Senegal", "Cote d'Ivoire", "Cameroon", "Mali", "Benin",
        "Burkina Faso", "Niger", "Togo", "Gabon", "Congo", "Democratic Republic of the Congo", "Haiti" -> EndlessSceneProfile.FRANCOPHONE
        // German-speaking
        "Germany", "Austria", "Switzerland", "Liechtenstein" -> EndlessSceneProfile.DACH
        // Greece / Cyprus
        "Greece", "Cyprus" -> EndlessSceneProfile.GREEK
        "Turkey" -> EndlessSceneProfile.TURKISH
        // Ex-YU
        "Croatia", "Serbia", "Bosnia and Herzegovina", "Montenegro", "Slovenia", "North Macedonia", "Kosovo" -> EndlessSceneProfile.EX_YU
        // East Slavic
        "Russia", "Ukraine", "Belarus" -> EndlessSceneProfile.EAST_SLAVIC
        // South Asian
        "India", "Pakistan", "Bangladesh", "Nepal", "Sri Lanka" -> EndlessSceneProfile.SOUTH_ASIAN
        // Arabic-speaking core
        "Saudi Arabia", "United Arab Emirates", "Qatar", "Kuwait", "Bahrain", "Oman", "Jordan", "Lebanon", "Syria",
        "Iraq", "Yemen", "Egypt", "Libya", "Tunisia", "Algeria", "Morocco", "Sudan", "Palestine" -> EndlessSceneProfile.ARABIC
        "Japan" -> EndlessSceneProfile.JAPANESE
        "South Korea" -> EndlessSceneProfile.KOREAN
        else -> null
    }

    private fun selectedQuickSceneOverride(): EndlessSceneProfile? {
        if (quickRegions.size != 1) return null
        return sceneForQuickRegion(quickRegions.first())
    }


    private fun qemRegionKeysFromUi(): Set<String> = quickRegions.filter { it in qemFonoteka.availableRegions }.toSet()

    private fun qemEraKeysFromUi(): Set<String> = quickEras.mapNotNull { value ->
        when {
            "evergreen" in value -> "EVERGREEN"
            "1970" in value -> "1970s"
            "1980" in value -> "1980s"
            "1990" in value -> "1990s"
            "2000" in value -> "2000s"
            "2010" in value -> "2010s"
            "2020" in value -> "2020s"
            else -> null
        }
    }.toSet()

    private fun qemStyleKeysFromUi(): Set<String> {
        val result = linkedSetOf<String>()
        quickStyles.forEach { key ->
            if (key in qemFonoteka.availableStyles) result += key
            result += qemFonoteka.combinedComponents(key).filter { it in qemFonoteka.availableStyles }
        }
        return result
    }

    private fun qemClassicalSelected(): Boolean = "CLASSICAL" in quickStyles
    private fun qemInstrumentalSelected(): Boolean = "INSTRUMENTAL" in quickStyles || "PIANO" in quickStyles
    private fun qemPianoSelected(): Boolean = "PIANO" in quickStyles

    private fun qemEraQueryTerms(): String = when {
        qemSessionEraKeys.size != 1 -> ""
        "EVERGREEN" in qemSessionEraKeys -> "classic original recording"
        "1970s" in qemSessionEraKeys -> "1970s"
        "1980s" in qemSessionEraKeys -> "1980s"
        "1990s" in qemSessionEraKeys -> "1990s"
        "2000s" in qemSessionEraKeys -> "2000s"
        "2010s" in qemSessionEraKeys -> "2010s"
        "2020s" in qemSessionEraKeys -> "2020s"
        else -> ""
    }

    private fun qemStyleQueryTerm(style: String): String = when (style) {
        "POP" -> "pop"
        "ROCK" -> "rock"
        "COUNTRY" -> "country"
        "FOLK" -> "folk traditional"
        "POP_FOLK" -> "pop folk"
        "DANCE" -> "dance"
        "HIP_HOP" -> "hip hop"
        "RAP" -> "rap"
        "REGGAE_CARIBBEAN" -> "reggae caribbean"
        "JAZZ" -> "jazz"
        "BLUES" -> "blues"
        "SOUL" -> "soul"
        "RNB" -> "r&b"
        "WORLD" -> "world music"
        "CLASSICAL" -> "classical"
        else -> ""
    }

    private fun qemSearchQuery(artist: QemFonoteka.ArtistChoice): String {
        val attributeTerms = when {
            qemSessionPiano -> "piano instrumental"
            qemSessionInstrumental -> "instrumental"
            else -> ""
        }
        val titleTypeTerms = buildList {
            if (allowLive) add("live")
            if (allowCover) add("cover")
            if (onlyOfficial) add("official")
        }.joinToString(" ")
        val discoveryHint = if (titleTypeTerms.isBlank()) "official music" else "$titleTypeTerms music"
        return listOf(
            artist.name,
            qemStyleQueryTerm(artist.style),
            qemEraQueryTerms(),
            attributeTerms,
            discoveryHint
        ).filter { it.isNotBlank() }.joinToString(" ")
    }

    private fun qemTrackMatchesArtist(track: TrackRef, artist: QemFonoteka.ArtistChoice): Boolean {
        val needle = canonicalCompareText(artist.name).trim()
        if (needle.isBlank()) return false
        val title = canonicalCompareText(track.title).trim()
        val uploader = canonicalCompareText(track.uploader).trim()

        fun fieldContainsPhrase(text: String, phrase: String): Boolean =
            text == phrase || " $text ".contains(" $phrase ")
        fun titleStartsWithArtist(text: String, phrase: String): Boolean =
            text == phrase || text.startsWith("$phrase ")

        // Search context is NOT identity. Accept only evidence carried by the returned item itself:
        // normally "Artist - Song" (canonicalized to an artist prefix) or an uploader/channel that
        // explicitly contains the complete artist name. This deliberately rejects recommendations
        // whose song title merely happens to contain a generic artist word (ET, Karma, Voyage...).
        if (titleStartsWithArtist(title, needle)) return true
        if (fieldContainsPhrase(uploader, needle)) return true
        if (allowCover && fieldContainsPhrase(title, needle)) return true

        val wanted = needle.split(' ').filter { it.isNotBlank() && it !in setOf("the", "and") }
        if (wanted.size < 2) return false
        val uploaderTokens = uploader.split(' ').filter { it.isNotBlank() }.toSet()

        // Conservative punctuation/diacritic fallback for multi-word official channels only.
        // Never rebuild identity by mixing tokens from title and uploader.
        return wanted.all { it in uploaderTokens }
    }

    private fun qemCheapTrackGuard(track: TrackRef): Boolean {
        if (!passesGlobalTitleTypeFilters(track)) return false
        if (looksLikeNarrativeNonSong(track) || looksLikeProgramOrCompilation(track)) return false
        val text = canonicalCompareText("${track.title} ${track.uploader}")
        val blocked = listOf(
            "karaoke", "reaction", "tutorial", "full album", "playlist", "interview", "intervju",
            "podcast", "talk", "conversation", "gostovanje", "emisija", "documentary", "review",
            "recenzija", "news", "vijesti", "vesti", "press conference"
        )
        if (blocked.any { it in text }) return false
        if (qemSessionInstrumental) {
            val vocalSignals = listOf("lyrics", "lyric video", "vocal cover", "karaoke")
            if (vocalSignals.any { it in text } && "instrumental" !in text) return false
        }
        if (qemSessionPiano && "piano" !in text) return false
        return true
    }

    private fun qemArtistOrder(limit: Int, liveTrack: TrackRef?): List<QemFonoteka.ArtistChoice> {
        val remaining = qemSessionArtistPool.toMutableList()
        val chosen = mutableListOf<QemFonoteka.ArtistChoice>()
        val liveArtist = liveTrack?.let(::endlessArtistKey).orEmpty()
        val referenceMix = persistentMixNumber + if (endlessActive) 0 else 1

        repeat(minOf(limit, remaining.size)) {
            val weighted = remaining.map { artist ->
                var weight = (110 - artist.rank).coerceAtLeast(8)
                if (artist.id in qemRecentArtistIds) weight = maxOf(1, weight / 10)
                val key = normalizeArtistText(artist.name)

                // Montenegro POP/ROCK soft variety adjustment. These artists remain fully valid;
                // only their post-filter selection weight is reduced to prevent repetition.
                val montenegroPopRock = quickCountry.equals("Montenegro", ignoreCase = true) &&
                    (quickStyles.isEmpty() || quickStyles.any { it == "POP" || it == "POP_ROCK" || it == "ROCK" })
                if (montenegroPopRock) {
                    weight = when {
                        key == normalizeArtistText("Sergej Ćetković") -> maxOf(1, weight / 3)
                        key == normalizeArtistText("Perper") -> maxOf(1, weight / 3)
                        key.startsWith(normalizeArtistText("Danijel")) -> maxOf(1, (weight * 3) / 4)
                        else -> weight
                    }
                }

                val lastMix = persistentArtistLastPlayedMix[key]
                if (lastMix != null) {
                    weight = when (referenceMix - lastMix) {
                        0, 1 -> maxOf(1, weight / 10)
                        2 -> maxOf(1, weight / 4)
                        3 -> maxOf(1, weight / 2)
                        else -> weight
                    }
                }
                if (liveArtist.isNotBlank() && key == liveArtist) weight = 0
                artist to weight
            }
            val total = weighted.sumOf { it.second }
            val pick = if (total <= 0) remaining.randomOrNull(Random.Default) else {
                var needle = Random.nextInt(total)
                weighted.firstOrNull { (_, weight) ->
                    needle -= weight
                    needle < 0
                }?.first
            } ?: remaining.first()
            chosen += pick
            remaining.remove(pick)
        }
        return chosen
    }

    private fun qemTrackScore(track: TrackRef): Double {
        val views = kotlin.math.ln(1.0 + track.viewCount.coerceAtLeast(0L).toDouble())
        var score = views + if (track.uploaderVerified) 3.0 else 0.0
        if ("official" in track.title.lowercase(Locale.getDefault())) score += 2.0
        score -= persistentPlaybackPenalty(track).toDouble() / 100.0
        return score
    }

    private suspend fun qemFindTracks(count: Int, liveTrack: TrackRef?, deadlineMs: Long): List<TrackRef> {
        if (count <= 0 || qemSessionArtistPool.isEmpty()) return emptyList()
        // Snapshot provenance at search start. A late callback from an older QEM request may never
        // stamp itself as belonging to a newer filter generation.
        val provenanceGeneration = qemDiscoveryGeneration
        val provenanceFingerprint = qemFilterFingerprint
        fun markIfStillCurrent(track: TrackRef, artistId: String) {
            if (autoDiscoveryMotor == AutoDiscoveryMotor.QEM &&
                provenanceGeneration == qemDiscoveryGeneration &&
                provenanceFingerprint.isNotBlank() && provenanceFingerprint == qemFilterFingerprint) {
                markQemCandidate(track, artistId)
            }
        }

        // 1 ARTIST MIX intentionally needs several different songs by the SAME artist.
        // QEM normally prefers one song per artist, so this mode gets a dedicated catalog pass.
        if (oneArtistMixActive && qemSessionArtistPool.size == 1) {
            val artist = qemSessionArtistPool.first()
            val deadline = SystemClock.elapsedRealtime() + deadlineMs
            val remaining = (deadline - SystemClock.elapsedRealtime()).coerceAtLeast(1L)
            val tracks = withTimeoutOrNull(minOf(6_000L, remaining)) {
                withContext(Dispatchers.IO) {
                    val typeHint = buildList {
                        if (allowLive) add("live")
                        if (allowCover) add("cover")
                        if (onlyOfficial) add("official")
                    }.joinToString(" ").ifBlank { "official" }
                    runCatching { searchRepo.search("${artist.name} $typeHint music songs") }.getOrDefault(emptyList())
                }
            }.orEmpty()
            val maxSeconds = 480L
            fun candidates(ignoreCycleHistory: Boolean): List<TrackRef> = tracks.asSequence()
                .filter { it.durationSeconds <= 0 || it.durationSeconds in 75L..maxSeconds }
                .filter(::qemCheapTrackGuard)
                .filter { qemTrackMatchesArtist(it, artist) }
                .filter { liveTrack == null || endlessTrackKey(it) != endlessTrackKey(liveTrack) }
                .filter { ignoreCycleHistory || (!endlessUsedTrackKeys.contains(endlessTrackKey(it)) && !endlessPlayedSongKeys.contains(endlessTrackKey(it))) }
                .distinctBy(::endlessTrackKey)
                .sortedByDescending(::qemTrackScore)
                .take(24)
                .toList()

            var valid = candidates(ignoreCycleHistory = false)
            if (valid.isEmpty()) {
                // Catalog exhausted: begin a new shuffled cycle, while never replaying the currently ACTIVE song immediately.
                endlessUsedTrackKeys.clear()
                endlessPlayedSongKeys.clear()
                valid = candidates(ignoreCycleHistory = true)
            }
            val picked = valid.take(8).shuffled(Random.Default).take(count)
            picked.forEach { markIfStillCurrent(it, artist.id) }
            return picked
        }

        val orderedArtists = qemArtistOrder(minOf(24, qemSessionArtistPool.size), liveTrack)
        val found = mutableListOf<TrackRef>()
        val usedArtists = linkedSetOf<String>()
        val deadline = SystemClock.elapsedRealtime() + deadlineMs

        for (chunk in orderedArtists.chunked(3)) {
            if (SystemClock.elapsedRealtime() >= deadline) break
            val batches = coroutineScope {
                chunk.map { artist ->
                    async(Dispatchers.IO) {
                        val remaining = (deadline - SystemClock.elapsedRealtime()).coerceAtLeast(1L)
                        val tracks = withTimeoutOrNull(minOf(4_500L, remaining)) {
                            runCatching { searchRepo.search(qemSearchQuery(artist)) }.getOrDefault(emptyList())
                        }.orEmpty()
                        artist to tracks
                    }
                }.awaitAll()
            }
            batches.forEach { (artist, tracks) ->
                if (artist.id in usedArtists) return@forEach
                val maxSeconds = if (quickLongFormDuration || qemSessionStyleKeys.any { it in setOf("JAZZ", "WORLD") }) 1500L else 480L
                val valid = tracks.asSequence()
                    .filter { it.durationSeconds <= 0 || it.durationSeconds in 75L..maxSeconds }
                    .filter(::qemCheapTrackGuard)
                    .filter { qemTrackMatchesArtist(it, artist) }
                    .filterNot { endlessUsedTrackKeys.contains(endlessTrackKey(it)) || endlessPlayedSongKeys.contains(endlessTrackKey(it)) }
                    .sortedByDescending(::qemTrackScore)
                    .take(5)
                    .toList()
                val quality = valid.take(3).shuffled(Random.Default)
                val selected = quality.firstOrNull { candidate ->
                    liveTrack?.let { active -> isSameArtistFamily(active, candidate) } != true &&
                        found.none { existing -> isSameArtistFamily(existing, candidate) }
                }
                if (selected != null) {
                    markIfStillCurrent(selected, artist.id)
                    found += selected
                    usedArtists += artist.id
                }
            }
            if (found.size >= count) break
        }
        return found.take(count)
    }

    private fun discoverQemCandidate() {
        if (!endlessActive || autoDiscoveryMotor != AutoDiscoveryMotor.QEM || !quickSessionActive || qemSessionArtistPool.isEmpty() ||
            qemQueued != null || qemDiscoveryJob?.isActive == true) return
        val session = endlessSessionGeneration
        val motorGeneration = qemDiscoveryGeneration
        val activeTrack = when {
            playerA.isPlaying -> MixerStore.deckA
            playerB.isPlaying -> MixerStore.deckB
            else -> null
        }
        qemDiscoveryJob = lifecycleScope.launch {
            val found = qemFindTracks(count = 1, liveTrack = activeTrack, deadlineMs = 12_000L)
            if (session != endlessSessionGeneration || motorGeneration != qemDiscoveryGeneration || autoDiscoveryMotor != AutoDiscoveryMotor.QEM) return@launch
            qemDiscoveryJob = null
            if (!endlessActive || !quickSessionActive || autoDiscoveryMotor != AutoDiscoveryMotor.QEM) return@launch
            val candidate = found.firstOrNull()
            if (candidate == null) {
                delay(900L)
                if (endlessActive && quickSessionActive && autoDiscoveryMotor == AutoDiscoveryMotor.QEM &&
                    session == endlessSessionGeneration && motorGeneration == qemDiscoveryGeneration &&
                    qemQueued == null && qemDiscoveryJob?.isActive != true) {
                    discoverQemCandidate()
                }
                return@launch
            }
            if (!isCurrentQemCandidate(candidate)) {
                delay(100L)
                discoverQemCandidate()
                return@launch
            }
            endlessUsedUrls.add(candidate.url)
            endlessUsedTrackKeys.add(endlessTrackKey(candidate))

            // CONSTITUTION: QEM never trusts a stale reservation for an EMPTY deck. Re-read the
            // physical chassis at the instant the candidate is ready. If exactly one deck is
            // ACTIVE and the opposite deck is physically empty/free, load it there immediately.
            // Only when both physical decks are genuinely occupied may QEM keep candidate #2
            // logically queued.
            val physicalWaiting: Boolean? = when {
                playerA.isPlaying && !playerB.isPlaying &&
                    (MixerStore.deckB == null || playerB.mediaItemCount == 0 || endlessDeckStateB == EndlessDeckState.FREE) -> false
                playerB.isPlaying && !playerA.isPlaying &&
                    (MixerStore.deckA == null || playerA.mediaItemCount == 0 || endlessDeckStateA == EndlessDeckState.FREE) -> true
                else -> null
            }
            qemWaitingFreeDeck = null
            if (physicalWaiting != null) {
                loadEndlessTrackIntoDeck(physicalWaiting, candidate)
                discoverQueuedCandidate()
            } else {
                qemQueued = candidate
            }
        }
    }

    private fun startQuickEndlessMix() {
        // Validate first. Preserve the current owner until we know whether this is QEM->QEM hot
        // swap or a real handoff from BASIC / 1 ARTIST / NONE.
        val wasOneArtistMix = oneArtistMixActive
        val regionKeys = qemRegionKeysFromUi()
        val eraKeys = qemEraKeysFromUi()
        val styleKeys = qemStyleKeysFromUi()
        val includeClassical = qemClassicalSelected()
        val instrumental = qemInstrumentalSelected()
        val piano = qemPianoSelected()
        val requestedTempoBand = tempoBand

        val requestedPool = runCatching {
            qemFonoteka.buildArtistPool(
                regionKeys = regionKeys,
                country = quickCountry,
                styleKeys = styleKeys,
                eraKeys = eraKeys,
                includeClassical = includeClassical
            )
        }.getOrElse {
            AlertDialog.Builder(this)
                .setMessage("Fonoteka could not be loaded")
                .setPositiveButton("OK", null)
                .show()
            return
        }

        // The JSON is authoritative. An impossible filter combination is a valid zero-result state;
        // QEM never widens region/style/era behind the user's back just to make something play.
        if (requestedPool.isEmpty()) {
            AlertDialog.Builder(this)
                .setMessage("No artists exist for this filter combination")
                .setPositiveButton("OK", null)
                .show()
            return
        }

        // HOT QEM FILTER SWITCH: while QEM is already playing, ENTER changes only the QEM
        // discovery universe. ACTIVE audio is inherited untouched; the old waiting deck/Slot 2
        // are invalidated and rebuilt from the new hard filters immediately. No STOP is required.
        val liveQemActiveIsA: Boolean? = when {
            playerA.isPlaying && !playerB.isPlaying -> true
            playerB.isPlaying && !playerA.isPlaying -> false
            playerA.isPlaying && playerB.isPlaying -> cross <= 0.5f
            else -> null
        }
        if (endlessActive && autoDiscoveryMotor == AutoDiscoveryMotor.QEM &&
            !wasOneArtistMix && liveQemActiveIsA != null) {
            // QEM ENTER is a filter-generation change, never an engine-owner change.
            quickSessionActive = true
            autoEnabled = true
            enforceAutoOwnerInvariant()
            quickStartJob?.cancel()
            quickStartJob = lifecycleScope.launch {
                binding.quickDrawerEnter.isEnabled = false
                binding.quickSearchingRow.visibility = View.VISIBLE
                binding.quickSearchingText.text = "APPLYING NEW QEM FILTER…"

                // Invalidate every candidate/search/load belonging to the previous QEM filter.
                qemDiscoveryGeneration++
                val hotSwapGeneration = qemDiscoveryGeneration
                qemDiscoveryJob?.cancel(); qemDiscoveryJob = null
                endlessLoadJobA?.cancel(); endlessLoadJobA = null
                endlessLoadJobB?.cancel(); endlessLoadJobB = null
                qemQueued = null
                qemWaitingFreeDeck = null
                qemCandidateStamps.clear()
                qemTrackArtistIds.clear()
                qemRecentArtistIds.clear()

                qemSessionArtistPool = requestedPool
                qemSessionStyleKeys = styleKeys
                qemSessionEraKeys = eraKeys
                qemSessionInstrumental = instrumental
                qemSessionPiano = piano
                qemFilterFingerprint = buildString {
                    append("QEM|")
                    append(regionKeys.sorted().joinToString(",")); append('|')
                    append(quickCountry.orEmpty()); append('|')
                    append(styleKeys.sorted().joinToString(",")); append('|')
                    append(eraKeys.sorted().joinToString(",")); append('|')
                    append("I=").append(instrumental).append("|P=").append(piano).append("|C=").append(includeClassical)
                }
                quickSessionTempoBand = requestedTempoBand
                quickLongFormDuration = quickAllowsLongForm() || includeClassical || instrumental || piano ||
                    styleKeys.any { it in setOf("JAZZ", "WORLD") }
                qemHandoffPending = false
                // Re-assert after all async cancellation/state mutation: old callbacks may not
                // demote the currently active QEM session.
                quickSessionActive = true
                autoEnabled = true
                if (autoDiscoveryMotor != AutoDiscoveryMotor.QEM) switchDiscoveryMotor(AutoDiscoveryMotor.QEM)
                enforceAutoOwnerInvariant()

                val waitingIsA = !liveQemActiveIsA
                // NEW RULE: SEARCH FIRST, SWAP SECOND. The currently parked NEXT is left physically
                // untouched while QEM walks fonoteka -> artist -> query -> web search -> validation.
                // We only release/replace that waiting deck after a concrete valid candidate exists.
                val waitingTrackBeforeSearch = if (waitingIsA) MixerStore.deckA else MixerStore.deckB
                val waitingWasManual = waitingTrackBeforeSearch?.url?.let { it in endlessManualUrls } == true
                qemWaitingFreeDeck = null

                val wanted = if (requiresMeasuredTempoFilter()) 8 else 1
                var candidates = qemFindTracks(
                    count = wanted,
                    liveTrack = if (liveQemActiveIsA) MixerStore.deckA else MixerStore.deckB,
                    deadlineMs = 14_000L
                )
                if (!isActive || qemDiscoveryGeneration != hotSwapGeneration ||
                    autoDiscoveryMotor != AutoDiscoveryMotor.QEM || !quickSessionActive) return@launch

                if (requiresMeasuredTempoFilter() && candidates.isNotEmpty()) {
                    binding.quickSearchingText.text = "CHECKING TEMPO…"
                    candidates = coroutineScope {
                        candidates.take(10).map { t ->
                            async(Dispatchers.IO) {
                                val resolved = runCatching {
                                    if (t.streamUrl != null) t else t.copy(streamUrl = AudioResolver.resolveBestAudioUrl(t.url))
                                }.getOrNull() ?: return@async null
                                val direct = resolved.streamUrl ?: return@async null
                                val tempo = runLowPriorityAnalysis { TempoAnalyzer.analyze(direct, cacheKey = resolved.url) }
                                if (tempo == null || isMeasuredTempoAcceptable(tempo)) resolved else null
                            }
                        }.awaitAll().filterNotNull()
                    }
                }

                if (!isActive || qemDiscoveryGeneration != hotSwapGeneration ||
                    autoDiscoveryMotor != AutoDiscoveryMotor.QEM || !quickSessionActive) return@launch

                val nextRaw = candidates.firstOrNull()
                val next = if (nextRaw != null && isCurrentQemCandidate(nextRaw)) {
                    if (nextRaw.streamUrl != null) nextRaw else withTimeoutOrNull(8_000L) {
                        withContext(Dispatchers.IO) {
                            runCatching { nextRaw.copy(streamUrl = AudioResolver.resolveBestAudioUrl(nextRaw.url)) }.getOrNull()
                        }
                    }
                } else null

                if (next?.streamUrl != null && isCurrentQemCandidate(next)) {
                    binding.quickSearchingText.text = "LOADING NEXT…"
                    if (!waitingWasManual) {
                        // SEARCH/RESOLVE/VALIDATE FIRST. Only now do we replace the parked NEXT.
                        // No pre-clear, no FREE reservation and no 12-second "failed -> EMPTY" cleanup.
                        val installed = installPreparedQemTrackIntoWaitingDeck(waitingIsA, next)
                        if (installed) {
                            qemWaitingFreeDeck = null
                            discoverQueuedCandidate()
                        } else {
                            // A late manual protection/playback change wins; preserve the parking track.
                            qemQueued = next
                        }
                    } else {
                        // Manual ADD TO MIX is sacred.
                        qemQueued = next
                    }
                } else {
                    // No immediate hit is not a failure. AUTO stays ON and QEM keeps searching
                    // inside the exact new filter until it can fill the waiting deck.
                    // EMPTY deck has no QEM owner. Search without reserving it; the result
                    // will inspect the physical A/B state and load the still-empty opposite deck.
                    qemWaitingFreeDeck = null
                    binding.quickSearchingText.text = "SEARCHING NEXT…"
                    discoverQemCandidate()
                }

                // HOT QEM switch ends in QEM, regardless of search/load timing. ACTIVE stays
                // on its physical deck; the other deck remains QEM's waiting destination.
                quickSessionActive = true
                autoEnabled = true
                enforceAutoOwnerInvariant()
                resetQuickSelections()
                closeQuickDrawer()
                binding.quickDrawerEnter.isEnabled = true
                updateAutoButton()
                updateModeButtons()
            }
            return
        }

        // This is a real owner handoff (NONE/BASIC/1 ARTIST -> QEM), not a hot filter swap.
        oneArtistMixActive = false
        quickStartJob?.cancel()
        qemHandoffPending = true
        quickStartJob = lifecycleScope.launch {
            binding.quickDrawerEnter.isEnabled = false
            binding.quickSearchingRow.visibility = View.VISIBLE
            binding.quickSearchingText.text = "SEARCHING FONOTEKA…"

            // ENTER changes the automatic owner but not the physical decks. Stopping the previous
            // mode invalidates its jobs while deliberately leaving the live ACTIVE track untouched.
            if (endlessActive) stopEndlessMix()
            oneArtistMixActive = false
            switchDiscoveryMotor(AutoDiscoveryMotor.QEM)
            qemQueued = null

            qemSessionArtistPool = requestedPool
            qemSessionStyleKeys = styleKeys
            qemSessionEraKeys = eraKeys
            qemSessionInstrumental = instrumental
            qemSessionPiano = piano
            qemFilterFingerprint = buildString {
                append("QEM|")
                append(regionKeys.sorted().joinToString(",")); append('|')
                append(quickCountry.orEmpty()); append('|')
                append(styleKeys.sorted().joinToString(",")); append('|')
                append(eraKeys.sorted().joinToString(",")); append('|')
                append("I=").append(instrumental).append("|P=").append(piano).append("|C=").append(includeClassical)
            }
            qemRecentArtistIds.clear()
            qemTrackArtistIds.clear()
            qemCandidateStamps.clear()
            quickSessionTempoBand = requestedTempoBand
            quickLongFormDuration = quickAllowsLongForm() || includeClassical || instrumental || piano ||
                styleKeys.any { it in setOf("JAZZ", "WORLD") }

            val liveActiveIsA: Boolean? = when {
                playerA.isPlaying && !playerB.isPlaying -> true
                playerB.isPlaying && !playerA.isPlaying -> false
                playerA.isPlaying && playerB.isPlaying -> cross <= 0.5f
                else -> null
            }
            val liveActiveTrack = when (liveActiveIsA) {
                true -> MixerStore.deckA
                false -> MixerStore.deckB
                null -> null
            }

            // Normalize ownership if an old broken state had both decks audible. The chosen ACTIVE
            // deck is never stopped, sought, reloaded or replaced.
            if (liveActiveIsA != null) {
                if (liveActiveIsA) {
                    playerB.pause(); playerB.playWhenReady = false
                    cross = 0f; binding.crossfader.progress = 0
                } else {
                    playerA.pause(); playerA.playWhenReady = false
                    cross = 1f; binding.crossfader.progress = 100
                }
                applyVolumes()
            }

            quickSessionActive = false
            quickStartupGuardA = false
            pendingEndlessStart = false
            pendingEndlessStartIsA = null
            autoFadeJob?.cancel(); autoFadeJob = null
            endlessSeeds.clear()
            endlessQueued = null
            qemQueued = null
            activeWaitingFreeDeck = null
            endlessRecoveryDeck = null

            // SEARCH FIRST, SWAP SECOND. During a live owner handoff, never empty the parked
            // waiting deck before QEM has a concrete playable replacement. Keep the physical pair
            // exactly as-is while fonoteka/search/validation runs. Only the no-live-audio cold start
            // still begins from clean A/B decks.
            if (liveActiveIsA == true) {
                endlessDeckStateA = EndlessDeckState.PLAYING
                endlessDeckStateB = when {
                    MixerStore.deckB != null && playerB.mediaItemCount > 0 -> EndlessDeckState.READY_NEXT
                    else -> EndlessDeckState.FREE
                }
            } else if (liveActiveIsA == false) {
                endlessDeckStateB = EndlessDeckState.PLAYING
                endlessDeckStateA = when {
                    MixerStore.deckA != null && playerA.mediaItemCount > 0 -> EndlessDeckState.READY_NEXT
                    else -> EndlessDeckState.FREE
                }
            } else {
                playerA.pause(); playerB.pause()
                playerA.stop(); playerB.stop()
                playerA.clearMediaItems(); playerB.clearMediaItems()
                MixerStore.deckA = null; MixerStore.deckB = null
                MixerStore.waveA = null; MixerStore.waveB = null
                lastTrackAUrl = null; lastTrackBUrl = null
                resolvingA = null; resolvingB = null
                endlessDeckStateA = EndlessDeckState.FREE
                endlessDeckStateB = EndlessDeckState.FREE
                cross = 0f; binding.crossfader.progress = 0
                applyVolumes()
            }

            binding.endlessAction.visibility = View.GONE
            binding.endlessLockActionRow.visibility = View.GONE
            binding.endlessFilterRow.visibility = View.GONE
            binding.endlessSearchPanel.visibility = View.GONE
            binding.endlessLowerSpacer.visibility = View.GONE
            binding.modeButtonRow.visibility = View.GONE
            binding.quickDrawer.visibility = View.VISIBLE

            // LIVE QEM HANDOFF — USE THE SAME PROVEN TRANSMISSION AS BASIC ENDLESS.
            //
            // Basic Endless is reliable because ENTER happens only after two physical deck tracks
            // already exist: the live ACTIVE track and the newly chosen waiting seed. startEndlessMix()
            // then adopts the live player and treats the opposite loaded deck as READY_NEXT.
            //
            // QEM must use that exact transmission. Its only special job is choosing the new waiting
            // song from the hard fonoteka filters. Once chosen, we install it into the physical waiting
            // deck exactly like a manually selected Basic seed, wait until that deck is actually READY,
            // and only then call the shared startEndlessMix() handoff. No custom QEM deck-loader path,
            // no EMPTY-deck ownership proxy and no parallel second transmission. ACTIVE is never touched.
            if (liveActiveIsA != null) {
                val nextIsA = !liveActiveIsA
                binding.quickSearchingText.text = "FINDING NEXT…"

                // Search several valid candidates while the inherited ACTIVE song keeps playing.
                // Resolve the audio URL before touching the waiting deck so a dead search result can
                // never leave the physical transmission half-installed.
                val wantedLiveCandidates = if (requiresMeasuredTempoFilter()) 10 else 4
                var liveCandidates = qemFindTracks(
                    count = wantedLiveCandidates,
                    liveTrack = liveActiveTrack,
                    deadlineMs = 22_000L
                )
                if (!isActive) return@launch

                if (requiresMeasuredTempoFilter() && liveCandidates.isNotEmpty()) {
                    binding.quickSearchingText.text = "CHECKING TEMPO…"
                    liveCandidates = coroutineScope {
                        liveCandidates.take(12).map { t ->
                            async(Dispatchers.IO) {
                                val resolved = runCatching {
                                    if (t.streamUrl != null) t else t.copy(streamUrl = AudioResolver.resolveBestAudioUrl(t.url))
                                }.getOrNull() ?: return@async null
                                val direct = resolved.streamUrl ?: return@async null
                                val tempo = runLowPriorityAnalysis { TempoAnalyzer.analyze(direct, cacheKey = resolved.url) }
                                if (tempo == null || isMeasuredTempoAcceptable(tempo)) resolved else null
                            }
                        }.awaitAll().filterNotNull()
                    }
                }

                var preparedNext: TrackRef? = null
                for (candidate in liveCandidates) {
                    if (!isCurrentQemCandidate(candidate)) continue
                    val resolved = if (candidate.streamUrl != null) candidate else {
                        withTimeoutOrNull(8_000L) {
                            withContext(Dispatchers.IO) {
                                runCatching { candidate.copy(streamUrl = AudioResolver.resolveBestAudioUrl(candidate.url)) }.getOrNull()
                            }
                        }
                    }
                    if (resolved?.streamUrl != null && isCurrentQemCandidate(resolved)) {
                        preparedNext = resolved
                        break
                    }
                }

                val installedNext = preparedNext ?: run {
                    // Nothing was installed, therefore ACTIVE remains exactly as it was. Do not fake
                    // an AUTO start with an EMPTY transmission; tell the user this filter pass failed.
                    qemHandoffPending = false
                    quickSessionActive = false
                    switchDiscoveryMotor(AutoDiscoveryMotor.NONE)
                    qemSessionArtistPool = emptyList()
                    binding.quickSearchingRow.visibility = View.GONE
                    binding.quickDrawerEnter.isEnabled = true
                    AlertDialog.Builder(this@MixerActivity)
                        .setMessage("No playable tracks found inside the selected fonoteka filters")
                        .setPositiveButton("OK", null)
                        .show()
                    return@launch
                }

                binding.quickSearchingText.text = "INSTALLING NEXT…"

                // SEARCH FIRST, SWAP SECOND. installedNext already has a real resolved stream URL and
                // passed the QEM gates. Until this exact moment the old parking track was untouched.
                // Now perform one real replacement and immediately hand the pair to the proven Basic
                // transmission. DO NOT impose a 12-second READY deadline: Basic already knows how to
                // carry a waiting deck through BUFFERING/LOADING_NEXT while ACTIVE keeps playing.
                if (nextIsA) {
                    MixerStore.setA(installedNext)
                    MixerStore.waveA = null
                    lastTrackAUrl = "__QEM_LIVE_ATOMIC_A__"
                    resolvingA = null
                } else {
                    MixerStore.setB(installedNext)
                    MixerStore.waveB = null
                    lastTrackBUrl = "__QEM_LIVE_ATOMIC_B__"
                    resolvingB = null
                }
                refreshDecks()

                // The chassis now looks exactly like the known-good Basic case: one deck is LIVE,
                // the opposite deck already contains the new seed and is READY. Hand this pair to
                // the SAME shared startEndlessMix() transmission. Keep quickSessionActive false only
                // during adoption so startEndlessMix() follows the physically playing deck instead of
                // forcing Quick's cold-start owner A. QEM ownership itself is already selected.
                syncSeedsFromCurrentDecks()
                quickSessionActive = false
                quickStartupGuardA = false
                suppressInitialEndlessDiscovery = true
                try {
                    startEndlessMix()
                } finally {
                    suppressInitialEndlessDiscovery = false
                }
                if (!endlessActive || !autoEnabled) {
                    qemHandoffPending = false
                    binding.quickSearchingText.text = "HANDOFF FAILED"
                    binding.quickDrawerEnter.isEnabled = true
                    return@launch
                }

                // Only AFTER the shared Basic transmission has adopted A/B do we expose QEM as the
                // discovery owner. From here on QEM supplies future candidates; the physical gearbox,
                // transition engine and READY_NEXT behavior are exactly the same shared infrastructure.
                quickSessionActive = true
                qemHandoffPending = false
                autoEnabled = true
                enforceAutoOwnerInvariant()

                if (liveActiveIsA) {
                    endlessDeckStateA = EndlessDeckState.PLAYING
                    endlessDeckStateB = EndlessDeckState.READY_NEXT
                    cross = 0f; binding.crossfader.progress = 0
                } else {
                    endlessDeckStateB = EndlessDeckState.PLAYING
                    endlessDeckStateA = EndlessDeckState.READY_NEXT
                    cross = 1f; binding.crossfader.progress = 100
                }
                applyVolumes()

                // Prepare only logical Slot 2 now; the physical waiting deck is already occupied by
                // the first QEM seed and must remain sticky until its transition.
                qemWaitingFreeDeck = null
                discoverQueuedCandidate()

                updateAutoButton()
                updateEndlessAction()
                updateModeButtons()
                resetQuickSelections()
                closeQuickDrawer()
                binding.quickDrawerEnter.isEnabled = true
                return@launch
            }

            val requiredStarters = 2
            val wanted = if (requiresMeasuredTempoFilter()) maxOf(requiredStarters * 5, 8) else requiredStarters
            var candidates = qemFindTracks(
                count = wanted,
                liveTrack = liveActiveTrack,
                deadlineMs = 22_000L
            )
            if (!isActive) return@launch

            if (requiresMeasuredTempoFilter() && candidates.isNotEmpty()) {
                binding.quickSearchingText.text = "CHECKING TEMPO…"
                candidates = coroutineScope {
                    candidates.take(12).map { t ->
                        async(Dispatchers.IO) {
                            val resolved = runCatching {
                                if (t.streamUrl != null) t else t.copy(streamUrl = AudioResolver.resolveBestAudioUrl(t.url))
                            }.getOrNull() ?: return@async null
                            val direct = resolved.streamUrl ?: return@async null
                            val tempo = runLowPriorityAnalysis { TempoAnalyzer.analyze(direct, cacheKey = resolved.url) }
                            if (tempo == null || isMeasuredTempoAcceptable(tempo)) resolved else null
                        }
                    }.awaitAll().filterNotNull()
                }
            }

            val found = candidates.take(requiredStarters)
            if (found.size < requiredStarters) {
                qemHandoffPending = false
                quickSessionActive = false
                switchDiscoveryMotor(AutoDiscoveryMotor.NONE)
                qemSessionArtistPool = emptyList()
                binding.quickSearchingRow.visibility = View.GONE
                binding.quickDrawerEnter.isEnabled = true
                AlertDialog.Builder(this@MixerActivity)
                    .setMessage("No playable tracks found inside the selected fonoteka filters")
                    .setPositiveButton("OK", null)
                    .show()
                return@launch
            }

            // Old heuristic Quick fields are deliberately neutralized: QEM refill is now owned by
            // qemSessionArtistPool/fonoteka.json, while Basic Endless keeps its existing logic intact.
            quickSceneOverride = null
            quickSessionAnchorTerms = ""
            quickSessionStyleTerms = ""

            if (liveActiveIsA != null) {
                val nextIsA = !liveActiveIsA
                syncSeedsFromCurrentDecks()
                quickSessionActive = false
                quickStartupGuardA = false
                // Do not let shared Basic Endless refill the FREE deck during this handoff.
                // That race could inject a GLOBAL/English candidate before QEM becomes owner,
                // bypassing the selected hard REGION/STYLE pool (e.g. EX-YU + DANCE).
                suppressInitialEndlessDiscovery = true
                try {
                    startEndlessMix()
                } finally {
                    suppressInitialEndlessDiscovery = false
                }
                if (!endlessActive || !autoEnabled) {
                    binding.quickSearchingText.text = "STILL SEARCHING…"
                    binding.quickDrawerEnter.isEnabled = true
                    return@launch
                }

                // startEndlessMix is shared with Basic and may have armed its normal refill for the
                // free deck. Cancel that one race, then hand ownership to the QEM motor.
                endlessDiscoveryJob?.cancel()
                endlessDiscoveryJob = null
                endlessQueued = null
                activeWaitingFreeDeck = null
                switchDiscoveryMotor(AutoDiscoveryMotor.QEM)
                quickSessionActive = true
                qemHandoffPending = false
                if (liveActiveIsA) {
                    endlessDeckStateA = EndlessDeckState.PLAYING
                    endlessDeckStateB = EndlessDeckState.FREE
                    endlessSeedProtectedB = false
                    cross = 0f; binding.crossfader.progress = 0
                } else {
                    endlessDeckStateB = EndlessDeckState.PLAYING
                    endlessDeckStateA = EndlessDeckState.FREE
                    endlessSeedProtectedA = false
                    cross = 1f; binding.crossfader.progress = 100
                }
                applyVolumes()

                binding.quickSearchingText.text = "LOADING NEXT…"
                // No READY deadline here. Once QEM has chosen a candidate, the shared loader owns
                // buffering just like Basic Endless. A slow buffer is LOADING_NEXT, never a reason
                // to manufacture FREE/EMPTY.
                loadEndlessTrackIntoDeck(nextIsA, found[0])
                activeWaitingFreeDeck = null
                discoverQueuedCandidate()
            } else {
                MixerStore.setA(found[0])
                MixerStore.setB(found[1])
                cross = 0f; binding.crossfader.progress = 0; applyVolumes()
                refreshDecks(force = true)
                binding.quickSearchingText.text = "LOADING 2/2…"
                while (isActive && (
                        playerA.mediaItemCount == 0 || playerA.playbackState != Player.STATE_READY ||
                        playerB.mediaItemCount == 0 || playerB.playbackState != Player.STATE_READY
                    )) {
                    if (playerA.isPlaying) playerA.pause()
                    if (playerB.isPlaying) playerB.pause()
                    delay(100L)
                }
                if (!isActive) return@launch
                syncSeedsFromCurrentDecks()
                quickSessionActive = true
                qemHandoffPending = false
                quickStartupGuardA = true
                switchDiscoveryMotor(AutoDiscoveryMotor.QEM)
                startEndlessMix()
                if (!endlessActive || !autoEnabled) {
                    quickSessionActive = false
                    quickStartupGuardA = false
                    binding.quickSearchingText.text = "STILL SEARCHING…"
                    binding.quickDrawerEnter.isEnabled = true
                    return@launch
                }
                playerB.pause(); playerB.playWhenReady = false
                endlessDeckStateA = EndlessDeckState.PLAYING
                endlessDeckStateB = EndlessDeckState.READY_NEXT
                cross = 0f; binding.crossfader.progress = 0; applyVolumes()
                if (!playerA.isPlaying) {
                    if (playerA.playbackState == Player.STATE_READY) playerA.play()
                    else { pendingEndlessStart = true; pendingEndlessStartIsA = true }
                }
            }

            updateAutoButton()
            updateEndlessAction()
            resetQuickSelections()
            closeQuickDrawer()
        }
    }

    private fun quickStarterPassesHardGuards(track: TrackRef, sceneOverride: EndlessSceneProfile?): Boolean {
        if (looksLikeNarrativeNonSong(track) || looksLikeProgramOrCompilation(track)) return false
        val text = canonicalCompareText("${track.title} ${track.uploader}")
        val hardBlockedWords = listOf(
            "karaoke", "reaction", "tutorial", "full album", "playlist", "instrumental karaoke",
            "interview", "intervju", "podcast", "talk", "conversation", "gostovanje", "gost u",
            "emisija", "behind the scenes", "documentary", "dokumentar", "press conference",
            "q a", "review", "recenzija", "razgovor", "radio emisija", "tv emisija", "dnevnik",
            "vesti", "vijesti", "news", "breaking", "reportaza", "reportaža"
        )
        if (hardBlockedWords.any { it in text }) return false

        // QUICK REGION is a hard gate exactly like Endless region DNA. Unknown/global evidence is
        // rejected when a concrete region was selected; it may not sneak through on popularity.
        if (sceneOverride != null) {
            val candidateScene = classifyTrackScene(track)
            if (candidateScene != sceneOverride) return false
        }

        // Reuse the Endless POP/POP-FOLK/FOLK hard genre behavior for starter selection too.
        // Other QUICK style tokens remain search constraints and become the seed DNA once started.
        val selected = quickStyles.map { canonicalCompareText(it) }
        if (selected.isNotEmpty()) {
            val oldProfile = endlessGenreProfile
            val profile = when {
                selected.any { it == "folk" } && selected.none { "pop folk" in it } -> EndlessGenreProfile.FOLK
                selected.any { "pop folk" in it } -> EndlessGenreProfile.POP_FOLK
                selected.any { it == "pop" || it == "rock" || it == "hard rock" } -> EndlessGenreProfile.POP
                else -> null
            }
            if (profile != null) {
                endlessGenreProfile = profile
                val rejected = violatesLockedGenre(track)
                endlessGenreProfile = oldProfile
                if (rejected) return false
            }
        }
        return true
    }

    private fun showOneArtistMixPopup() {
        val input = EditText(this).apply {
            hint = "Artist name"
            isSingleLine = true
            textSize = 20f
            setPadding(dp(20), dp(12), dp(20), dp(12))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("1 ARTIST MIX")
            .setView(input)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("START", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val artist = input.text.toString().trim()
                if (artist.isBlank()) return@setOnClickListener
                dialog.dismiss()
                startOneArtistMix(artist)
            }
        }
        dialog.show()
    }

    private fun startOneArtistMix(query: String) {
        val known = qemFonoteka.resolveArtist(query)
        if (known != null) startKnownOneArtistMix(known) else startLegacyOneArtistMix(query)
    }

    private fun startKnownOneArtistMix(artist: QemFonoteka.ArtistChoice) {
        if (endlessActive) stopEndlessMix() // preserves ACTIVE playback by design
        oneArtistMixActive = true
        quickSessionActive = true
        switchDiscoveryMotor(AutoDiscoveryMotor.QEM)
        qemSessionArtistPool = listOf(artist)
        qemSessionStyleKeys = emptySet()
        qemSessionEraKeys = emptySet()
        qemSessionInstrumental = false
        qemSessionPiano = false
        qemFilterFingerprint = "ONE_ARTIST|${artist.id}|${normalizeArtistText(artist.name)}"
        qemRecentArtistIds.clear()
        qemTrackArtistIds.clear()
        qemCandidateStamps.clear()
        quickSessionTempoBand = tempoBand
        quickLongFormDuration = false
        updateModeButtons()

        lifecycleScope.launch {
            val liveIsA: Boolean? = when {
                playerA.isPlaying && !playerB.isPlaying -> true
                playerB.isPlaying && !playerA.isPlaying -> false
                playerA.isPlaying && playerB.isPlaying -> cross <= 0.5f
                else -> null
            }
            val liveTrack = when (liveIsA) { true -> MixerStore.deckA; false -> MixerStore.deckB; null -> null }
            // Live 1-ARTIST asks for several choices so a dead URL can be discarded off-deck
            // without ever sacrificing the currently parked NEXT.
            val wanted = if (liveIsA == null) 2 else 4
            val found = qemFindTracks(wanted, liveTrack, 18_000L)
            val minimumNeeded = if (liveIsA == null) 2 else 1
            if (found.size < minimumNeeded) {
                oneArtistMixActive = false
                quickSessionActive = false
                qemSessionArtistPool = emptyList()
                updateModeButtons()
                AlertDialog.Builder(this@MixerActivity).setMessage("No playable songs found for ${artist.name}").setPositiveButton("OK", null).show()
                return@launch
            }

            if (liveIsA != null) {
                val nextIsA = !liveIsA

                // SAME LAW AS QEM2: discovery/resolve/validation happens completely off-deck.
                // The old parking track is untouched until a real stream exists.
                var preparedNext: TrackRef? = null
                for (candidate in found) {
                    if (!isCurrentQemCandidate(candidate)) continue
                    val resolved = if (candidate.streamUrl != null) candidate else withTimeoutOrNull(8_000L) {
                        withContext(Dispatchers.IO) {
                            runCatching { candidate.copy(streamUrl = AudioResolver.resolveBestAudioUrl(candidate.url)) }.getOrNull()
                        }
                    }
                    val direct = resolved?.streamUrl ?: continue
                    if (requiresMeasuredTempoFilter()) {
                        val tempo = runLowPriorityAnalysis { TempoAnalyzer.analyze(direct, cacheKey = resolved.url) }
                        if (tempo != null && !isMeasuredTempoAcceptable(tempo)) continue
                    }
                    if (isCurrentQemCandidate(resolved)) {
                        preparedNext = resolved
                        break
                    }
                }

                val installedNext = preparedNext
                if (installedNext == null) {
                    // Candidate failed before the swap: keep the existing parked song exactly as-is.
                    oneArtistMixActive = false
                    quickSessionActive = false
                    qemSessionArtistPool = emptyList()
                    switchDiscoveryMotor(AutoDiscoveryMotor.NONE)
                    updateModeButtons()
                    AlertDialog.Builder(this@MixerActivity)
                        .setMessage("No playable songs found for ${artist.name}")
                        .setPositiveButton("OK", null)
                        .show()
                    return@launch
                }

                // Atomic parking replacement: no clearMediaItems(), no deck=null and no FREE gap
                // before the new song has already been found and resolved.
                if (nextIsA) {
                    MixerStore.setA(installedNext)
                    MixerStore.waveA = null
                    lastTrackAUrl = "__ONE_ARTIST_ATOMIC_A__"
                    resolvingA = null
                } else {
                    MixerStore.setB(installedNext)
                    MixerStore.waveB = null
                    lastTrackBUrl = "__ONE_ARTIST_ATOMIC_B__"
                    resolvingB = null
                }
                refreshDecks()

                quickSessionActive = false
                syncSeedsFromCurrentDecks()
                startEndlessMix()
                endlessDiscoveryJob?.cancel(); endlessDiscoveryJob = null
                activeWaitingFreeDeck = null
                quickSessionActive = true
                oneArtistMixActive = true
                switchDiscoveryMotor(AutoDiscoveryMotor.QEM)
                qemSessionArtistPool = listOf(artist)
                if (liveIsA) {
                    endlessDeckStateA = EndlessDeckState.PLAYING
                    endlessDeckStateB = if (playerB.playbackState == Player.STATE_READY) EndlessDeckState.READY_NEXT else EndlessDeckState.LOADING_NEXT
                } else {
                    endlessDeckStateB = EndlessDeckState.PLAYING
                    endlessDeckStateA = if (playerA.playbackState == Player.STATE_READY) EndlessDeckState.READY_NEXT else EndlessDeckState.LOADING_NEXT
                }
                discoverQueuedCandidate()
            } else {
                MixerStore.setA(found[0]); MixerStore.setB(found[1])
                cross = 0f; binding.crossfader.progress = 0; applyVolumes()
                refreshDecks(force = true)
                while (isActive && (playerA.mediaItemCount == 0 || playerB.mediaItemCount == 0 ||
                            playerA.playbackState != Player.STATE_READY || playerB.playbackState != Player.STATE_READY)) delay(100L)
                if (!isActive) return@launch
                quickSessionActive = true
                oneArtistMixActive = true
                syncSeedsFromCurrentDecks()
                startEndlessMix()
                playerB.pause(); playerB.playWhenReady = false
                endlessDeckStateA = EndlessDeckState.PLAYING
                endlessDeckStateB = EndlessDeckState.READY_NEXT
            }
            updateModeButtons()
        }
    }

    private fun startLegacyOneArtistMix(query: String) {
        if (endlessActive) stopEndlessMix()
        oneArtistMixActive = true
        quickSessionActive = false
        switchDiscoveryMotor(AutoDiscoveryMotor.BASIC)
        updateModeButtons()
        lifecycleScope.launch {
            val tracks = withContext(Dispatchers.IO) {
                val typeHint = buildList {
                    if (allowLive) add("live")
                    if (allowCover) add("cover")
                    if (onlyOfficial) add("official")
                }.joinToString(" ").ifBlank { "official" }
                runCatching { searchRepo.search("$query $typeHint music songs") }.getOrDefault(emptyList())
            }
            val needle = canonicalCompareText(query)
            val found = tracks.asSequence()
                .filter { !looksLikeNarrativeNonSong(it) && !looksLikeProgramOrCompilation(it) }
                .filter { needle in canonicalCompareText("${it.title} ${it.uploader}") }
                .distinctBy(::endlessTrackKey)
                .take(2).toList()
            if (found.size < 2) {
                oneArtistMixActive = false
                updateModeButtons()
                AlertDialog.Builder(this@MixerActivity).setMessage("Artist not in fonoteka and old motor could not find two playable songs.").setPositiveButton("OK", null).show()
                return@launch
            }
            val liveIsA = when { playerA.isPlaying && !playerB.isPlaying -> true; playerB.isPlaying && !playerA.isPlaying -> false; else -> null }
            if (liveIsA == null) {
                MixerStore.setA(found[0]); MixerStore.setB(found[1]); refreshDecks(force = true)
                while (isActive && (playerA.playbackState != Player.STATE_READY || playerB.playbackState != Player.STATE_READY)) delay(100L)
                syncSeedsFromCurrentDecks(); startEndlessMix()
            } else {
                val nextIsA = !liveIsA
                if (nextIsA) MixerStore.setA(found[0]) else MixerStore.setB(found[0])
                refreshDecks()
                syncSeedsFromCurrentDecks(); startEndlessMix()
            }
            // Explicitly lock old discovery to the requested artist after adoption/start.
            endlessArtistOnlyMode = true
            endlessArtistOnlySeed = found.first()
            oneArtistMixActive = true
            updateModeButtons()
        }
    }

    private fun updateModeButtons() {
        if (!::binding.isInitialized) return
        // UI follows the authoritative discovery owner, not a fragile session mirror.
        if (endlessActive) enforceAutoOwnerInvariant()
        val basic = endlessActive && autoDiscoveryMotor == AutoDiscoveryMotor.BASIC && !oneArtistMixActive
        val qem = endlessActive && autoDiscoveryMotor == AutoDiscoveryMotor.QEM && !oneArtistMixActive
        val artist = endlessActive && oneArtistMixActive

        binding.basicEndlessButton.text = "ENDLESS MIX"
        binding.quickEndlessButton.text = if (qem) "CHANGE QUICK MIX" else "QUICK ENDLESS MIX"
        binding.oneArtistMixButton.text = "1 ARTIST MIX"

        fun styleModeButton(button: android.widget.Button, active: Boolean, activeBg: Int, activeText: Int) {
            button.backgroundTintList = null
            button.setBackgroundResource(if (active) activeBg else R.drawable.lux_worn_gunmetal_button)
            button.setTextColor(ContextCompat.getColor(this, if (active) activeText else R.color.lux_silver))
            button.alpha = 1f
            button.elevation = dp(6).toFloat()
        }

        styleModeButton(binding.basicEndlessButton, basic, R.drawable.lux_blue_button, R.color.white)
        styleModeButton(binding.quickEndlessButton, qem, R.drawable.lux_gold_button, R.color.black)
        styleModeButton(binding.oneArtistMixButton, artist, R.drawable.lux_green_button, R.color.black)
    }

    private fun updateContextualModeUi() {
        if (!::binding.isInitialized) return
        val twoUsable = MixerStore.deckA != null && MixerStore.deckB != null && playerA.mediaItemCount > 0 && playerB.mediaItemCount > 0
        binding.startEndlessAutoMix.visibility = if (!endlessActive && !quickDrawerOpen && twoUsable) View.VISIBLE else View.GONE
        binding.modeButtonRow.visibility = if (!quickDrawerOpen && binding.endlessSearchPanel.visibility != View.VISIBLE) View.VISIBLE else View.GONE
        binding.endlessAction.visibility = View.GONE
        updateModeButtons()
    }

    private fun normalizeInstantNextWaitingDeckState() {
        // After many rapid manual NEXT transitions, the parked deck can remain logically tagged
        // PLAYING even though it is physically not playing anymore and ExoPlayer is READY.
        // AUTO tolerates that because deckReadyForAuto() accepts PLAYING, but contextual NEXT
        // arrows require READY_NEXT. Normalize that desync before visibility checks.
        if (!endlessActive || autoFadeJob?.isActive == true) return
        if (playerA.isPlaying && !playerB.isPlaying && playerB.mediaItemCount > 0 && playerB.playbackState == Player.STATE_READY && endlessDeckStateB == EndlessDeckState.PLAYING) {
            endlessDeckStateB = EndlessDeckState.READY_NEXT
        }
        if (playerB.isPlaying && !playerA.isPlaying && playerA.mediaItemCount > 0 && playerA.playbackState == Player.STATE_READY && endlessDeckStateA == EndlessDeckState.PLAYING) {
            endlessDeckStateA = EndlessDeckState.READY_NEXT
        }
    }

    private fun canInstantNext(fromA: Boolean): Boolean {
        // NEXT belongs to MASTER AUTO, not to a particular discovery motor. It therefore works
        // in Basic Endless, QEM, 1 ARTIST MIX and ordinary two-deck AUTO whenever NEXT is safe.
        normalizeInstantNextWaitingDeckState()
        if (!autoEnabled || autoFadeJob?.isActive == true) return false
        val source = if (fromA) playerA else playerB
        val target = if (fromA) playerB else playerA
        if (!source.isPlaying || target.mediaItemCount == 0 || target.playbackState != Player.STATE_READY) return false
        return if (endlessActive) {
            val state = if (fromA) endlessDeckStateB else endlessDeckStateA
            state == EndlessDeckState.READY_NEXT
        } else {
            deckReadyForAuto(target)
        }
    }

    private fun updateInstantNextButtons() {
        if (!::binding.isInitialized) return
        val fromA = canInstantNext(true)
        val fromB = canInstantNext(false)
        binding.instantNextA.visibility = if (fromA) View.VISIBLE else View.INVISIBLE
        binding.instantNextB.visibility = if (fromB) View.VISIBLE else View.INVISIBLE
        // NEXT remains intentionally usable under LOCK.
        binding.instantNextA.isEnabled = fromA
        binding.instantNextB.isEnabled = fromB
    }

    private fun launchSpeechRecognizer() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Search music")
        }
        runCatching { speechLauncher.launch(intent) }
            .onFailure { binding.endlessStatus.text = "Voice search unavailable" }
    }

    private fun formatTime(ms: Long): String {
        val total = (ms / 1000L).coerceAtLeast(0L)
        val m = total / 60
        val s = total % 60
        return "%d:%02d".format(m, s)
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized) {
            refreshDecks()
            if (!endlessActive && !endlessSeedMode) syncSeedsFromCurrentDecks()
        }
    }

    override fun onDestroy() {
        // UI listeners must never pin a dead Activity. The actual players live in PlaybackRuntime
        // while the foreground playback guard is running, so background navigation cannot kill audio.
        playerListenerA?.let { playerA.removeListener(it) }
        playerListenerB?.let { playerB.removeListener(it) }
        playerListenerA = null
        playerListenerB = null
        if (!ForegroundPlaybackService.isRunning) {
            autoFadeJob?.cancel()
            endlessDiscoveryJob?.cancel()
            if (::audioFocusRequest.isInitialized) audioManager.abandonAudioFocusRequest(audioFocusRequest)
            PlaybackRuntime.releaseAll()
        }
        super.onDestroy()
    }
}
