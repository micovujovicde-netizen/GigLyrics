package com.terafon.pausemix

import android.content.Context
import com.terafon.pausemix.model.TrackRef
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Local-only user preference history. This file is never sent to Fonoteka/server.
 * Favorites are intentionally independent from the playback hard-repeat history.
 */
class UserHistoryStore(context: Context) {
    private val file = File(context.filesDir, "endlessmix_user_history.json")
    private val favorites = linkedMapOf<String, FavoriteEntry>()

    data class FavoriteEntry(
        val key: String,
        val title: String,
        val uploader: String,
        val url: String,
        val updatedAtMs: Long,
    )

    @Synchronized
    fun load() {
        favorites.clear()
        if (!file.exists()) return
        runCatching {
            val root = JSONObject(file.readText())
            val arr = root.optJSONArray("favorites") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val key = obj.optString("key").trim()
                if (key.isBlank()) continue
                favorites[key] = FavoriteEntry(
                    key = key,
                    title = obj.optString("title"),
                    uploader = obj.optString("uploader"),
                    url = obj.optString("url"),
                    updatedAtMs = obj.optLong("updatedAtMs", 0L),
                )
            }
        }
    }

    @Synchronized
    fun isFavorite(key: String): Boolean = key.isNotBlank() && favorites.containsKey(key)

    @Synchronized
    fun setFavorite(key: String, track: TrackRef, favorite: Boolean): Boolean {
        if (key.isBlank()) return false
        if (favorite) {
            favorites[key] = FavoriteEntry(
                key = key,
                title = track.title,
                uploader = track.uploader,
                url = track.url,
                updatedAtMs = System.currentTimeMillis(),
            )
        } else {
            favorites.remove(key)
        }
        persist()
        return favorite
    }

    @Synchronized
    fun toggleFavorite(key: String, track: TrackRef): Boolean {
        val next = !isFavorite(key)
        return setFavorite(key, track, next)
    }

    @Synchronized
    fun favoriteKeys(): Set<String> = favorites.keys.toSet()

    @Synchronized
    private fun persist() {
        runCatching {
            val root = JSONObject()
            root.put("version", 1)
            val arr = JSONArray()
            favorites.values.forEach { entry ->
                arr.put(JSONObject().apply {
                    put("key", entry.key)
                    put("title", entry.title)
                    put("uploader", entry.uploader)
                    put("url", entry.url)
                    put("updatedAtMs", entry.updatedAtMs)
                })
            }
            root.put("favorites", arr)
            val tmp = File(file.parentFile, "${file.name}.tmp")
            tmp.writeText(root.toString())
            if (!tmp.renameTo(file)) {
                file.writeText(root.toString())
                tmp.delete()
            }
        }
    }
}
