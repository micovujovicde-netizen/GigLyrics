package com.terafon.pausemix

import org.schabi.newpipe.extractor.stream.StreamInfo

object AudioResolver {
    fun resolveBestAudioUrl(pageUrl: String): String {
        if (!EngineRulesStore.sourceEnabled) throw IllegalStateException("Source temporarily disabled by compatibility rules")
        val info = StreamInfo.getInfo(pageUrl)

        // Prefer audio-only streams. They are smaller and ideal for a mixer.
        val audio = info.audioStreams
            .filter { it.isUrl && !it.content.isNullOrBlank() }
            .sortedByDescending { it.averageBitrate }
            .firstOrNull()
            ?.content
        if (!audio.isNullOrBlank()) return audio

        // Fallback to muxed video streams: ExoPlayer can use their audio track.
        // This avoids failing on YouTube items where no separate audio URL is exposed.
        if (!EngineRulesStore.allowMuxedFallback) throw IllegalStateException("No playable audio-only stream available")
        val muxed = info.videoStreams
            .firstOrNull { it.isUrl && !it.content.isNullOrBlank() }
            ?.content
        if (!muxed.isNullOrBlank()) return muxed

        throw IllegalStateException("No playable audio stream available")
    }
}
