package com.terafon.pausemix

import org.schabi.newpipe.extractor.stream.StreamInfo

object AudioResolver {

    /**
     * Tiny audio-only stream for BPM/ENERGY probing. We deliberately prefer the
     * lowest-bitrate usable audio representation because tempo/energy analysis
     * does not need playback quality. Playback still uses resolveBestAudioUrl().
     */
    fun resolveAnalysisAudioUrl(pageUrl: String): String {
        if (!EngineRulesStore.sourceEnabled) throw IllegalStateException("Source temporarily disabled by compatibility rules")
        val info = StreamInfo.getInfo(pageUrl)

        val audioStreams = info.audioStreams
            .filter { it.isUrl && !it.content.isNullOrBlank() }

        val lowestKnownBitrate = audioStreams
            .filter { it.averageBitrate > 0 }
            .minByOrNull { it.averageBitrate }
            ?.content
        if (!lowestKnownBitrate.isNullOrBlank()) return lowestKnownBitrate

        val anyAudio = audioStreams.firstOrNull()?.content
        if (!anyAudio.isNullOrBlank()) return anyAudio

        // Analysis should almost never need muxed video, but keep a compatibility
        // fallback so a missing audio-only representation does not kill the candidate.
        if (!EngineRulesStore.allowMuxedFallback) throw IllegalStateException("No playable analysis audio stream available")
        val muxed = info.videoStreams
            .filter { it.isUrl && !it.content.isNullOrBlank() }
            .firstOrNull()
            ?.content
        if (!muxed.isNullOrBlank()) return muxed

        throw IllegalStateException("No playable analysis audio stream available")
    }
    fun resolveBestAudioUrl(pageUrl: String): String {
        if (!EngineRulesStore.sourceEnabled) throw IllegalStateException("Source temporarily disabled by compatibility rules")
        val info = StreamInfo.getInfo(pageUrl)

        // Prefer audio-only streams. They are smaller and ideal for a mixer.
        val audio = info.audioStreams
            .filter { it.isUrl && !it.content.isNullOrBlank() }
            .sortedByDescending { it.averageBitrate }
            .firstOrNull()
            ?.content
        if (!audio.isNullOrBlank()) return audio

        // Fallback to muxed video streams: ExoPlayer can use their audio track.
        // This avoids failing on YouTube items where no separate audio URL is exposed.
        if (!EngineRulesStore.allowMuxedFallback) throw IllegalStateException("No playable audio-only stream available")
        val muxed = info.videoStreams
            .firstOrNull { it.isUrl && !it.content.isNullOrBlank() }
            ?.content
        if (!muxed.isNullOrBlank()) return muxed

        throw IllegalStateException("No playable audio stream available")
    }
}
