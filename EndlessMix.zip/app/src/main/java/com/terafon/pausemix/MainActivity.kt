package com.terafon.pausemix

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.View
import android.view.inputmethod.EditorInfo
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.terafon.pausemix.databinding.ActivityMainBinding
import com.terafon.pausemix.model.MixerStore
import com.terafon.pausemix.model.TrackRef
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val repo = SearchRepository()
    private var targetDeck: String? = null
    private var loadingTrack = false

    private val speechLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != RESULT_OK) return@registerForActivityResult
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
            ?.trim()
            .orEmpty()
        if (spoken.isNotBlank() && ::binding.isInitialized) {
            binding.searchInput.setText(spoken)
            binding.searchInput.setSelection(spoken.length)
            doSearch()
        }
    }

    private val micPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchSpeechRecognizer()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        targetDeck = intent.getStringExtra(EXTRA_TARGET_DECK)?.takeIf { it == "A" || it == "B" }
        if (targetDeck == null) {
            finish()
            return
        }

        fun resolveAndLoad(track: TrackRef) {
            val deck = targetDeck ?: return
            if (deck == "A") MixerStore.setA(track) else MixerStore.setB(track)
            finish()
        }

        val adapter = SearchAdapter(
            targetDeck = targetDeck,
            onImportA = { resolveAndLoad(it) },
            onImportB = { resolveAndLoad(it) }
        )
        binding.results.layoutManager = LinearLayoutManager(this)
        binding.results.adapter = adapter

        binding.searchButton.setOnClickListener { doSearch() }
        binding.voiceSearchButton.setOnClickListener { requestVoiceSearch() }
        binding.searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                doSearch()
                true
            } else false
        }
    }

    private fun doSearch() {
        if (loadingTrack || !::binding.isInitialized) return
        val q = binding.searchInput.text.toString().trim()
        if (q.isBlank()) return
        binding.progress.visibility = View.VISIBLE
        binding.statusText.text = "Searching…"

        val adapter = binding.results.adapter as? SearchAdapter ?: return
        lifecycleScope.launch {
            runCatching {
                withContext(Dispatchers.IO) { repo.search(q) }
            }.onSuccess { results ->
                adapter.submit(results)
                binding.statusText.text = "${results.size} results"
            }.onFailure {
                binding.statusText.text = "Search error: ${it.message ?: "unknown"}"
            }
            binding.progress.visibility = View.GONE
        }
    }

    private fun requestVoiceSearch() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            launchSpeechRecognizer()
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun launchSpeechRecognizer() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Search music")
        }
        runCatching { speechLauncher.launch(intent) }
            .onFailure { binding.statusText.text = "Voice search unavailable" }
    }

    companion object {
        const val EXTRA_TARGET_DECK = "target_deck"
    }
}
