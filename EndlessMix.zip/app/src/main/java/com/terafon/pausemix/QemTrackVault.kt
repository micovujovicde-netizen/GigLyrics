package com.terafon.pausemix

import android.content.Context
import com.terafon.pausemix.model.TrackRef
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.random.Random

/**
 * Persistent QEM track vault ("music hotel treasury").
 *
 * Two layers are deliberately separated:
 *  1) immutable APK seed: assets/qem_track_vault_seed.json
 *  2) device-learned append-only shelf: qem_track_vault_learned.jsonl
 *
 * The vault stores song identity + QEM provenance plus a device-local durable cache of canonical
 * YouTube WATCH URLs. It never stores expiring googlevideo stream URLs and never marks anything
 * as played. Every transport URL is still resolved/validated before A/B may see it.
 */
internal class QemTrackVault(private val context: Context) {
    data class Entry(
        val artist: String,
        val title: String,
        val region: String,
        val countries: Set<String>,
        val styles: Set<String>,
        val eras: Set<String>,
        val artistId: String?,
        val searchQuery: String,
        val youtubeUrl: String?,
        val bpm: Double?,
        val bpmConfidence: Double?,
        val energy: Double?,
        val energyConfidence: Double?,
        val spotifyId: String?,
        val spotifyUrl: String?,
        val year: Int?,
        val decade: Int?,
        val danceability: Double?,
        val valence: Double?,
        val loudness: Double?,
        val acousticness: Double?,
        val instrumentalness: Double?,
        val learned: Boolean
    )

    data class Pick(val entry: Entry, val artist: QemFonoteka.ArtistChoice)

    data class Metadata(
        val bpm: Double?,
        val bpmConfidence: Double?,
        val energy: Double?,
        val energyConfidence: Double?,
        val spotifyId: String?,
        val spotifyUrl: String?,
        val year: Int?,
        val decade: Int?,
        val danceability: Double?,
        val valence: Double?,
        val loudness: Double?,
        val acousticness: Double?,
        val instrumentalness: Double?
    )

    companion object {
        private const val LEARNED_FILE = "qem_track_vault_learned.jsonl"
        private const val URL_CACHE_FILE = "qem_track_vault_urls.jsonl"
        private const val MAX_LEARNED_ENTRIES = 12_000
        private const val COMPACT_AT_BYTES = 4L * 1024L * 1024L
        private const val META_PREFS = "qem_track_vault_meta_v2"
        private const val HYDRATION_CURSOR_KEY = "hydration_cursor"
    }

    private val learnedFile = File(context.filesDir, LEARNED_FILE)
    private val urlCacheFile = File(context.filesDir, URL_CACHE_FILE)
    private val lock = Any()
    private val seedEntries: List<Entry> by lazy { loadSeed() }
    private val learnedEntries = mutableListOf<Entry>()
    private val learnedKeys = linkedSetOf<String>()
    private val urlCache = linkedMapOf<String, String>()
    private val metaPrefs = context.getSharedPreferences(META_PREFS, Context.MODE_PRIVATE)

    init {
        loadLearned()
        loadUrlCache()
    }

    fun findMetadata(artist: String, title: String): Metadata? {
        val a = CanonicalIdentityResolver.normalize(artist)
        val t = CanonicalIdentityResolver.normalize(title)
        if (a.isBlank() || t.isBlank()) return null
        val e = synchronized(lock) {
            (seedEntries + learnedEntries).firstOrNull {
                CanonicalIdentityResolver.normalize(it.artist) == a &&
                    CanonicalIdentityResolver.normalize(it.title) == t
            }
        } ?: return null
        return Metadata(
            bpm = e.bpm, bpmConfidence = e.bpmConfidence,
            energy = e.energy, energyConfidence = e.energyConfidence,
            spotifyId = e.spotifyId, spotifyUrl = e.spotifyUrl,
            year = e.year, decade = e.decade, danceability = e.danceability,
            valence = e.valence, loudness = e.loudness,
            acousticness = e.acousticness, instrumentalness = e.instrumentalness
        )
    }

    fun pick(
        regionKeys: Set<String>,
        country: String?,
        styleKeys: Set<String>,
        eraKeys: Set<String>,
        relaxedRegionOnly: Boolean,
        artistPool: List<QemFonoteka.ArtistChoice>,
        limit: Int
    ): List<Pick> {
        if (limit <= 0) return emptyList()
        val byId = artistPool.associateBy { it.id }
        val byName = artistPool.associateBy { CanonicalIdentityResolver.normalize(it.name) }
        val wantedRegions = regionKeys.map(::normTag).filter(String::isNotBlank).toSet()
        val wantedStyles = styleKeys
            .flatMap(::styleFamily)
            .map(::normTag)
            .filter(String::isNotBlank)
            .toSet()
        val wantedEras = eraKeys.map(::normTag).filter(String::isNotBlank).toSet()
        val wantedCountry = country?.let(::normTag).orEmpty()

        val snapshot = synchronized(lock) {
            (seedEntries + learnedEntries).map { e ->
                val cached = urlCache[transportIdentityKey(e.artist, e.title)]
                if (cached.isNullOrBlank() || cached == e.youtubeUrl) e else e.copy(youtubeUrl = cached)
            }
        }
        return snapshot.asSequence()
            .filter { e -> wantedRegions.isEmpty() || normTag(e.region) in wantedRegions }
            .filter { e -> relaxedRegionOnly || wantedCountry.isBlank() || e.countries.any { normTag(it) == wantedCountry } }
            // STYLE/PARTY identity is never relaxed. J may broaden country/era for continuity,
            // but must never turn a FOLK/PARTY session into unrelated POP/ROCK.
            .filter { e ->
                wantedStyles.isEmpty() || e.styles
                    .flatMap(::styleFamily)
                    .map(::normTag)
                    .any { it in wantedStyles }
            }
            .filter { e -> relaxedRegionOnly || wantedEras.isEmpty() || e.eras.any { normTag(it) in wantedEras } }
            .map { e ->
                // JURASSIC/KRDO is now a first-class artist authority. The old Fonoteka artist
                // pool may enrich an entry when it knows the performer, but it may NEVER veto a
                // valid local vault identity. This removes the legacy "old management" gate
                // that caused endless QEM_LOCAL_VAULT_MISS loops after a transition.
                val artist = e.artistId?.let(byId::get)
                    ?: byName[CanonicalIdentityResolver.normalize(e.artist)]
                    ?: QemFonoteka.ArtistChoice(
                        id = e.artistId ?: "vault:${CanonicalIdentityResolver.normalize(e.artist)}",
                        name = e.artist,
                        rank = 50,
                        region = e.region,
                        style = e.styles.firstOrNull().orEmpty(),
                        era = e.eras.firstOrNull().orEmpty(),
                        countries = e.countries.toList()
                    )
                Pick(e, artist)
            }
            .distinctBy { identityKey(it.entry) }
            .toList()
            .shuffled(Random.Default)
            .sortedWith(compareByDescending<Pick> { it.entry.youtubeUrl != null }
                .thenByDescending { it.entry.spotifyId != null }
                .thenByDescending { it.entry.bpm != null }
                .thenByDescending { it.entry.energy != null })
            .take(limit)
    }

    /**
     * Return identities still missing a durable canonical YouTube WATCH URL.
     *
     * The old worker always asked for the first N rows and could permanently stall after
     * those rows were attempted. This is a persistent circular crawler: every call advances
     * through the whole Monster J catalog, and the cursor survives app restarts.
     */
    fun hydrationCandidates(limit: Int): List<Pick> {
        if (limit <= 0) return emptyList()
        val snapshot = synchronized(lock) { seedEntries + learnedEntries }
        val missing = snapshot.asSequence()
            .filter { e ->
                e.youtubeUrl.isNullOrBlank() &&
                    urlCache[transportIdentityKey(e.artist, e.title)].isNullOrBlank()
            }
            .sortedWith(
                compareByDescending<Entry> { it.spotifyId != null }
                    .thenByDescending { it.bpm != null }
                    .thenByDescending { it.energy != null }
                    .thenByDescending { it.year != null }
            )
            .toList()
        if (missing.isEmpty()) return emptyList()

        val saved = metaPrefs.getInt(HYDRATION_CURSOR_KEY, 0)
        val startAt = ((saved % missing.size) + missing.size) % missing.size
        val takeCount = minOf(limit, missing.size)
        val chosen = buildList {
            for (i in 0 until takeCount) add(missing[(startAt + i) % missing.size])
        }
        val next = (startAt + takeCount) % missing.size
        metaPrefs.edit().putInt(HYDRATION_CURSOR_KEY, next).apply()

        return chosen.map { e ->
            Pick(
                e,
                QemFonoteka.ArtistChoice(
                    id = e.artistId ?: "vault:${CanonicalIdentityResolver.normalize(e.artist)}",
                    name = e.artist,
                    rank = 50,
                    region = e.region,
                    style = e.styles.firstOrNull().orEmpty(),
                    era = e.eras.firstOrNull().orEmpty(),
                    countries = e.countries.toList()
                )
            )
        }
    }

    fun rememberValidatedYoutubeUrl(artist: String, title: String, url: String): Boolean {
        if (!url.startsWith("https://www.youtube.com/watch?v=") &&
            !url.startsWith("https://youtu.be/")) return false
        val key = transportIdentityKey(artist, title)
        if (key.isBlank()) return false
        synchronized(lock) {
            if (urlCache[key] == url) return false
            urlCache[key] = url
            runCatching {
                urlCacheFile.parentFile?.mkdirs()
                urlCacheFile.appendText(
                    JSONObject()
                        .put("artist", artist)
                        .put("title", title)
                        .put("youtube_url", url)
                        .toString() + "\n"
                )
            }
        }
        return true
    }

    fun cachedYoutubeUrl(artist: String, title: String): String? = synchronized(lock) {
        urlCache[transportIdentityKey(artist, title)]
    }

    /**
     * Learn only hits which QEM has ALREADY admitted through its current candidate guards.
     * Learned song identities remain separate from the durable canonical YouTube URL cache.
     */
    fun learnValidated(
        tracks: List<TrackRef>,
        artist: QemFonoteka.ArtistChoice,
        sessionCountry: String?
    ): Int {
        if (tracks.isEmpty()) return 0
        val additions = mutableListOf<Entry>()
        for (track in tracks.take(5)) {
            val identity = CanonicalIdentityResolver.resolve(track)
            val title = identity.catalogTitle.trim().takeIf { it.length >= 2 } ?: continue
            val region = artist.region.takeIf { it.isNotBlank() } ?: continue
            val countries = when {
                !sessionCountry.isNullOrBlank() -> setOf(sessionCountry)
                artist.countries.isNotEmpty() -> artist.countries.toSet()
                else -> emptySet()
            }
            val styles = artist.style.takeIf { it.isNotBlank() }?.let { setOf(it) }.orEmpty()
            val eras = artist.era.takeIf { it.isNotBlank() }?.let { setOf(it) }.orEmpty()
            additions += Entry(
                artist = artist.name,
                title = title,
                region = region,
                countries = countries,
                styles = styles,
                eras = eras,
                artistId = artist.id,
                searchQuery = "${artist.name} $title official music",
                youtubeUrl = null,
                bpm = null,
                bpmConfidence = null,
                energy = null,
                energyConfidence = null,
                spotifyId = null, spotifyUrl = null, year = null, decade = null,
                danceability = null, valence = null, loudness = null, acousticness = null,
                instrumentalness = null, learned = true
            )
        }
        if (additions.isEmpty()) return 0

        var added = 0
        synchronized(lock) {
            for (entry in additions) {
                if (learnedEntries.size >= MAX_LEARNED_ENTRIES) break
                val key = identityKey(entry)
                if (!learnedKeys.add(key)) continue
                learnedEntries += entry
                added++
                runCatching {
                    learnedFile.parentFile?.mkdirs()
                    learnedFile.appendText(toJson(entry).toString() + "\n")
                }
            }
            if (learnedFile.length() > COMPACT_AT_BYTES) compactLearnedLocked()
        }
        return added
    }

    private fun loadSeed(): List<Entry> = runCatching {
        val root = JSONObject(context.assets.open("qem_track_vault_seed.json").bufferedReader().use { it.readText() })
        val tracks = root.optJSONArray("tracks") ?: JSONArray()
        buildList {
            for (i in 0 until tracks.length()) parseEntry(tracks.optJSONObject(i), learned = false)?.let(::add)
        }
    }.getOrDefault(emptyList())

    private fun loadLearned() {
        if (!learnedFile.isFile) return
        synchronized(lock) {
            learnedFile.useLines { lines ->
                lines.forEach { line ->
                    val e = runCatching { parseEntry(JSONObject(line), learned = true) }.getOrNull() ?: return@forEach
                    val key = identityKey(e)
                    if (learnedKeys.add(key) && learnedEntries.size < MAX_LEARNED_ENTRIES) learnedEntries += e
                }
            }
        }
    }

    private fun loadUrlCache() {
        if (!urlCacheFile.isFile) return
        synchronized(lock) {
            urlCacheFile.useLines { lines ->
                lines.forEach { line ->
                    val o = runCatching { JSONObject(line) }.getOrNull() ?: return@forEach
                    val artist = o.optString("artist").trim()
                    val title = o.optString("title").trim()
                    val url = o.optString("youtube_url").trim()
                    if (artist.isNotBlank() && title.isNotBlank() && url.isNotBlank()) {
                        urlCache[transportIdentityKey(artist, title)] = url
                    }
                }
            }
        }
    }

    private fun parseEntry(o: JSONObject?, learned: Boolean): Entry? {
        if (o == null) return null
        val artist = o.optString("artist").trim()
        val title = o.optString("title").trim()
        val region = o.optString("region").trim()
        if (artist.isBlank() || title.isBlank() || region.isBlank()) return null
        val spotifyYear = o.optJSONObject("spotify_features")?.optInt("year", -1)?.takeIf { it > 0 }
        val seededEras = stringSet(o.optJSONArray("eras"))
        val effectiveEras = if (spotifyYear != null) {
            buildSet {
                add("${(spotifyYear / 10) * 10}s")
                if (seededEras.any { it.equals("EVERGREEN", ignoreCase = true) }) add("EVERGREEN")
            }
        } else seededEras
        return Entry(
            artist = artist,
            title = title,
            region = region,
            countries = stringSet(o.optJSONArray("countries")),
            styles = stringSet(o.optJSONArray("styles")),
            eras = effectiveEras,
            artistId = o.optString("artist_id").trim().takeIf(String::isNotBlank),
            searchQuery = o.optString("search_query").trim().ifBlank { "$artist $title official music" },
            youtubeUrl = o.optJSONObject("youtube")?.optString("youtube_url")?.trim()?.takeIf(String::isNotBlank),
            bpm = o.optJSONObject("bpm_cache")?.optDouble("bpm")?.takeIf { !it.isNaN() },
            bpmConfidence = o.optJSONObject("bpm_cache")?.optDouble("confidence")?.takeIf { !it.isNaN() },
            energy = o.optJSONObject("energy_cache")?.optDouble("energy")?.takeIf { !it.isNaN() },
            energyConfidence = o.optJSONObject("energy_cache")?.optDouble("confidence")?.takeIf { !it.isNaN() },
            spotifyId = o.optJSONObject("spotify_features")?.optString("spotify_id")?.trim()?.takeIf(String::isNotBlank),
            spotifyUrl = o.optJSONObject("spotify_features")?.optString("spotify_url")?.trim()?.takeIf(String::isNotBlank),
            year = spotifyYear,
            decade = spotifyYear?.let { (it / 10) * 10 },
            danceability = o.optJSONObject("spotify_features")?.optDouble("danceability")?.takeIf { !it.isNaN() },
            valence = o.optJSONObject("spotify_features")?.optDouble("valence")?.takeIf { !it.isNaN() },
            loudness = o.optJSONObject("spotify_features")?.optDouble("loudness")?.takeIf { !it.isNaN() },
            acousticness = o.optJSONObject("spotify_features")?.optDouble("acousticness")?.takeIf { !it.isNaN() },
            instrumentalness = o.optJSONObject("spotify_features")?.optDouble("instrumentalness")?.takeIf { !it.isNaN() },
            learned = learned
        )
    }

    private fun toJson(e: Entry): JSONObject = JSONObject().apply {
        put("artist", e.artist)
        put("title", e.title)
        put("region", e.region)
        put("countries", JSONArray(e.countries.toList()))
        put("styles", JSONArray(e.styles.toList()))
        put("eras", JSONArray(e.eras.toList()))
        e.artistId?.let { put("artist_id", it) }
        put("search_query", e.searchQuery)
        e.youtubeUrl?.let { put("youtube", JSONObject().put("youtube_url", it)) }
        e.bpm?.let { bpm -> put("bpm_cache", JSONObject().put("bpm", bpm).apply { e.bpmConfidence?.let { put("confidence", it) } }) }
        e.energy?.let { energy -> put("energy_cache", JSONObject().put("energy", energy).put("scale", "0..1").apply { e.energyConfidence?.let { put("confidence", it) } }) }
        put("learned", true)
    }

    private fun compactLearnedLocked() {
        val keep = learnedEntries.takeLast(MAX_LEARNED_ENTRIES)
        val tmp = File(context.filesDir, "$LEARNED_FILE.tmp")
        runCatching {
            tmp.bufferedWriter().use { w -> keep.forEach { w.append(toJson(it).toString()).append('\n') } }
            if (learnedFile.exists()) learnedFile.delete()
            tmp.renameTo(learnedFile)
        }
    }

    private fun transportIdentityKey(artist: String, title: String): String =
        CanonicalIdentityResolver.normalize(artist) + "|" + CanonicalIdentityResolver.normalize(title)

    private fun identityKey(e: Entry): String = listOf(
        CanonicalIdentityResolver.normalize(e.artist),
        CanonicalIdentityResolver.normalize(e.title),
        normTag(e.region),
        e.countries.map(::normTag).sorted().joinToString(","),
        e.styles.map(::normTag).sorted().joinToString(","),
        e.eras.map(::normTag).sorted().joinToString(",")
    ).joinToString("|")

    private fun stringSet(arr: JSONArray?): Set<String> = buildSet {
        for (i in 0 until (arr?.length() ?: 0)) {
            val value = arr?.optString(i)?.trim().orEmpty()
            if (value.isNotBlank()) add(value)
        }
    }


    /**
     * Bridge QEM UI style names to Jurassic/Spotify vault tags.
     * This is metadata vocabulary normalization only; it does not relax REGION,
     * artist identity, history, or transport validation.
     */
    private fun styleFamily(raw: String): Set<String> {
        val s = normTag(raw)
        return when (s) {
            "POP_FOLK" -> setOf("POP_FOLK", "POP", "FOLK")
            "DANCE" -> setOf("DANCE", "DANCE_HOUSE")
            "DANCE_HOUSE" -> setOf("DANCE_HOUSE", "DANCE")
            "RNB" -> setOf("RNB", "RNB_SOUL")
            "SOUL" -> setOf("SOUL", "RNB_SOUL")
            "RNB_SOUL" -> setOf("RNB_SOUL", "RNB", "SOUL")
            "REGGAE_CARIBBEAN" -> setOf("REGGAE_CARIBBEAN", "REGGAE")
            "REGGAE" -> setOf("REGGAE", "REGGAE_CARIBBEAN")
            "RAP" -> setOf("RAP", "HIP_HOP")
            "HIP_HOP" -> setOf("HIP_HOP", "RAP")
            else -> setOf(s)
        }
    }

    private fun normTag(raw: String): String = raw.trim().lowercase(Locale.ROOT)
}
