package com.terafon.pausemix.model

object MixerStore {
    var deckA: TrackRef? = null
    var deckB: TrackRef? = null
    var waveA: FloatArray? = null
    var waveB: FloatArray? = null

    fun setA(track: TrackRef) {
        deckA = track
        waveA = null
    }

    fun setB(track: TrackRef) {
        deckB = track
        waveB = null
    }
}
