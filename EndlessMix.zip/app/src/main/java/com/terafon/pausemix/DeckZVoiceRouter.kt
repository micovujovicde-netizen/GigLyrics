package com.terafon.pausemix

import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

/**
 * Regional/language-aware voice selection policy for Deck Z.
 *
 * This class contains no playback logic. It only chooses the best voice already exposed by the
 * active Android TTS engine. Music must never wait for voice installation/download/network.
 */
class DeckZVoiceRouter(
    private val log: (String) -> Unit
) {
    data class Selection(
        val voice: Voice?,
        val locale: Locale,
        val route: String,
        val score: Int
    )

    fun select(engine: TextToSpeech, requested: Locale): Selection {
        val installed = engine.voices.orEmpty().filterNot { voice ->
            voice.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) == true
        }

        val route = localeRoute(requested)
        for ((routeIndex, locale) in route.withIndex()) {
            val candidates = installed.filter { voice ->
                sameLanguage(voice.locale, locale)
            }
            if (candidates.isEmpty()) continue

            val best = candidates.maxByOrNull { voice -> scoreVoice(voice, locale, routeIndex) }
            if (best != null) {
                val score = scoreVoice(best, locale, routeIndex)
                val routeLabel = when (routeIndex) {
                    0 -> "exact"
                    1 -> "regional"
                    else -> "language"
                }
                log(
                    "DECK_Z_ROUTE requested=${requested.toLanguageTag()} route=$routeLabel " +
                        "target=${locale.toLanguageTag()} voice=${best.name} actual=${best.locale.toLanguageTag()} " +
                        "quality=${best.quality} network=${best.isNetworkConnectionRequired} score=$score"
                )
                return Selection(best, locale, routeLabel, score)
            }
        }

        // Last-resort English fallback. It is deliberately local/offline-preferred when possible.
        val english = installed.filter { sameLanguage(it.locale, Locale.US) }
            .maxByOrNull { scoreVoice(it, Locale.US, 99) }
        if (english != null) {
            val score = scoreVoice(english, Locale.US, 99)
            log(
                "DECK_Z_ROUTE requested=${requested.toLanguageTag()} route=english_fallback " +
                    "voice=${english.name} actual=${english.locale.toLanguageTag()} score=$score"
            )
            return Selection(english, Locale.US, "english_fallback", score)
        }

        log("DECK_Z_ROUTE requested=${requested.toLanguageTag()} route=engine_default")
        return Selection(null, Locale.US, "engine_default", Int.MIN_VALUE)
    }

    /** Ordered, deterministic regional fallback chain. */
    private fun localeRoute(requested: Locale): List<Locale> {
        val tag = requested.toLanguageTag().lowercase(Locale.ROOT)
        val language = requested.language.lowercase(Locale.ROOT)
        val tags: List<String> = when {
            // EX-YU: keep mutually intelligible BCS voices together before English.
            language in setOf("hr", "sr", "bs", "sh") -> listOf(
                requested.toLanguageTag(), "hr-HR", "sr-RS", "bs-BA"
            )
            language == "es" -> listOf(
                requested.toLanguageTag(), "es-MX", "es-US", "es-ES", "es-AR"
            )
            language == "pt" -> listOf(
                requested.toLanguageTag(), "pt-BR", "pt-PT"
            )
            language == "fr" -> listOf(
                requested.toLanguageTag(), "fr-FR", "fr-CA", "fr-BE", "fr-CH"
            )
            language == "de" -> listOf(
                requested.toLanguageTag(), "de-DE", "de-AT", "de-CH"
            )
            language == "it" -> listOf(requested.toLanguageTag(), "it-IT", "it-CH")
            language == "el" -> listOf(requested.toLanguageTag(), "el-GR")
            language == "tr" -> listOf(requested.toLanguageTag(), "tr-TR")
            language == "ar" -> listOf(
                requested.toLanguageTag(), "ar-AE", "ar-SA", "ar-EG"
            )
            language == "hi" -> listOf(requested.toLanguageTag(), "hi-IN")
            language == "ur" -> listOf(requested.toLanguageTag(), "ur-PK", "hi-IN")
            language == "bn" -> listOf(requested.toLanguageTag(), "bn-BD", "hi-IN")
            language == "ne" -> listOf(requested.toLanguageTag(), "ne-NP", "hi-IN")
            language == "si" -> listOf(requested.toLanguageTag(), "si-LK", "hi-IN")
            language == "sl" -> listOf(requested.toLanguageTag(), "sl-SI", "hr-HR")
            language == "mk" -> listOf(requested.toLanguageTag(), "mk-MK", "sr-RS", "hr-HR")
            language == "sq" -> listOf(requested.toLanguageTag(), "sq-XK", "sq-AL")
            language == "ru" -> listOf(requested.toLanguageTag(), "ru-RU")
            language == "uk" -> listOf(requested.toLanguageTag(), "uk-UA", "ru-RU")
            language == "be" -> listOf(requested.toLanguageTag(), "be-BY", "ru-RU")
            language == "ko" -> listOf(requested.toLanguageTag(), "ko-KR")
            language == "ja" -> listOf(requested.toLanguageTag(), "ja-JP")
            language == "en" -> listOf(
                requested.toLanguageTag(), "en-US", "en-GB", "en-AU", "en-CA"
            )
            else -> listOf(requested.toLanguageTag())
        }

        return tags
            .filter { it.isNotBlank() }
            .distinctBy { it.lowercase(Locale.ROOT) }
            .map { Locale.forLanguageTag(it) }
            .let { locales ->
                // The final same-language locale lets engines whose voice country is unusual compete.
                val generic = Locale(language)
                if (language.isNotBlank() && locales.none { it.language.equals(language, true) && it.country.isBlank() }) {
                    locales + generic
                } else locales
            }
    }

    private fun sameLanguage(a: Locale, b: Locale): Boolean =
        a.language.equals(b.language, ignoreCase = true)

    private fun scoreVoice(voice: Voice, target: Locale, routeIndex: Int): Int {
        var score = 0
        val actualTag = voice.locale.toLanguageTag()
        val targetTag = target.toLanguageTag()

        if (actualTag.equals(targetTag, ignoreCase = true)) score += 10_000
        if (voice.locale.country.isNotBlank() && voice.locale.country.equals(target.country, true)) score += 2_000
        if (sameLanguage(voice.locale, target)) score += 1_000

        // Android quality is engine-defined; preserve it as a meaningful tie-breaker.
        score += voice.quality.coerceIn(0, 1000) * 3

        // On-device voices are preferred for a live DJ: predictable and no network latency.
        if (!voice.isNetworkConnectionRequired) score += 900 else score -= 250

        score += maleHint(voice) * 350
        score -= routeIndex.coerceAtMost(20) * 100
        return score
    }

    private fun maleHint(voice: Voice): Int {
        val haystack = buildString {
            append(voice.name.lowercase(Locale.ROOT))
            append(' ')
            voice.features.orEmpty().forEach { append(it.lowercase(Locale.ROOT)).append(' ') }
        }
        val male = listOf(
            "male", "masculine", "masculino", "homme", "mann", "männlich", "maschio",
            "muški", "muski", "муж", "男", "남성"
        )
        val female = listOf(
            "female", "feminine", "femenino", "femme", "weiblich", "femmina",
            "ženski", "zenski", "жен", "女", "여성"
        )
        return when {
            male.any { it in haystack } -> 2
            female.any { it in haystack } -> -2
            else -> 0
        }
    }
}
