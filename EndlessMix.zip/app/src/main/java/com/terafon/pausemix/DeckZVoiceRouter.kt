package com.terafon.pausemix

import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

/**
 * Regional/language-aware voice selection policy for Deck Z.
 *
 * This class contains no playback logic. It only chooses the best voice already exposed by the
 * active Android TTS engine. Music must never wait for voice installation/download/network.
 */
class DeckZVoiceRouter(
    private val log: (String) -> Unit
) {
    data class Selection(
        val voice: Voice?,
        val locale: Locale,
        val route: String,
        val score: Int
    )

    fun select(engine: TextToSpeech, requested: Locale): Selection {
        val installed = engine.voices.orEmpty().filterNot { voice ->
            voice.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) == true
        }

        val route = localeRoute(requested)

        // Respect the user's/device's selected TTS voice when it belongs to the same linguistic
        // zone. Example: a Serbian voice selected on the tablet may serve hr/bs/sr-ME requests
        // instead of being ignored just because the country tag differs. Unrelated languages are
        // never accepted as a zone match.
        val preferred = engine.voice?.takeIf { voice ->
            installed.any { it.name == voice.name } && route.any { locale -> sameLanguage(voice.locale, locale) }
        }
        if (preferred != null) {
            val score = scoreVoice(preferred, requested, -1) + 20_000
            log(
                "DECK_Z_ROUTE requested=${requested.toLanguageTag()} route=device_preferred_zone " +
                    "voice=${preferred.name} actual=${preferred.locale.toLanguageTag()} score=$score"
            )
            return Selection(preferred, preferred.locale, "device_preferred_zone", score)
        }

        for ((routeIndex, locale) in route.withIndex()) {
            val candidates = installed.filter { voice ->
                sameLanguage(voice.locale, locale)
            }
            if (candidates.isEmpty()) continue

            val best = candidates.maxByOrNull { voice -> scoreVoice(voice, locale, routeIndex) }
            if (best != null) {
                val score = scoreVoice(best, locale, routeIndex)
                val routeLabel = when (routeIndex) {
                    0 -> "exact"
                    1 -> "regional"
                    else -> "language"
                }
                log(
                    "DECK_Z_ROUTE requested=${requested.toLanguageTag()} route=$routeLabel " +
                        "target=${locale.toLanguageTag()} voice=${best.name} actual=${best.locale.toLanguageTag()} " +
                        "quality=${best.quality} network=${best.isNetworkConnectionRequired} score=$score"
                )
                return Selection(best, locale, routeLabel, score)
            }
        }

        // Last-resort English fallback. It is deliberately local/offline-preferred when possible.
        val english = installed.filter { sameLanguage(it.locale, Locale.US) }
            .maxByOrNull { scoreVoice(it, Locale.US, 99) }
        if (english != null) {
            val score = scoreVoice(english, Locale.US, 99)
            log(
                "DECK_Z_ROUTE requested=${requested.toLanguageTag()} route=english_fallback " +
                    "voice=${english.name} actual=${english.locale.toLanguageTag()} score=$score"
            )
            return Selection(english, Locale.US, "english_fallback", score)
        }

        log("DECK_Z_ROUTE requested=${requested.toLanguageTag()} route=engine_default")
        return Selection(null, Locale.US, "engine_default", Int.MIN_VALUE)
    }

    /** Ordered, deterministic world voice-zone fallback chain. */
    private fun localeRoute(requested: Locale): List<Locale> {
        val language = requested.language.lowercase(Locale.ROOT)
        val exact = requested.toLanguageTag()
        val zoneTags: List<String> = when (language) {
            // BCS voice zone: one shared pool for Bosnia and Herzegovina, Montenegro, Croatia, Serbia.
            "hr", "sr", "bs", "sh", "cnr" -> listOf(
                exact, "sr-RS", "sr-ME", "hr-HR", "bs-BA"
            )

            // Major worldwide same-language/accent pools. Exact requested locale remains first.
            "en" -> listOf(exact, "en-US", "en-GB", "en-IE", "en-CA", "en-AU", "en-NZ", "en-ZA", "en-IN")
            "es" -> listOf(exact, "es-MX", "es-US", "es-ES", "es-AR", "es-CO", "es-CL", "es-PE")
            "pt" -> listOf(exact, "pt-BR", "pt-PT", "pt-AO", "pt-MZ")
            "fr" -> listOf(exact, "fr-FR", "fr-CA", "fr-BE", "fr-CH")
            "de" -> listOf(exact, "de-DE", "de-AT", "de-CH")
            "it" -> listOf(exact, "it-IT", "it-CH")
            "nl" -> listOf(exact, "nl-NL", "nl-BE")
            "sv" -> listOf(exact, "sv-SE", "sv-FI")
            "no", "nb", "nn" -> listOf(exact, "nb-NO", "nn-NO", "no-NO")
            "da" -> listOf(exact, "da-DK")
            "fi" -> listOf(exact, "fi-FI")
            "is" -> listOf(exact, "is-IS")
            "pl" -> listOf(exact, "pl-PL")
            "cs" -> listOf(exact, "cs-CZ")
            "sk" -> listOf(exact, "sk-SK")
            "hu" -> listOf(exact, "hu-HU")
            "ro" -> listOf(exact, "ro-RO", "ro-MD")
            "bg" -> listOf(exact, "bg-BG")
            "el" -> listOf(exact, "el-GR", "el-CY")
            "tr" -> listOf(exact, "tr-TR")
            "sq" -> listOf(exact, "sq-AL", "sq-XK")
            "sl" -> listOf(exact, "sl-SI", "hr-HR", "sr-RS")
            "mk" -> listOf(exact, "mk-MK", "sr-RS", "hr-HR")

            // East Slavic: same-language first; controlled neighboring fallback only where already
            // established as intelligible enough for emergency TTS fallback.
            "ru" -> listOf(exact, "ru-RU")
            "uk" -> listOf(exact, "uk-UA", "ru-RU")
            "be" -> listOf(exact, "be-BY", "ru-RU")

            // Arabic world: one Arabic pool with accent preference, never a geographic-language mix.
            "ar" -> listOf(exact, "ar-AE", "ar-SA", "ar-EG", "ar-JO", "ar-LB", "ar-IQ", "ar-MA")
            "he", "iw" -> listOf(exact, "he-IL")
            "fa" -> listOf(exact, "fa-IR")

            // South Asia: language-specific pools; neighboring-language fallback remains controlled.
            "hi" -> listOf(exact, "hi-IN")
            "ur" -> listOf(exact, "ur-PK", "hi-IN")
            "bn" -> listOf(exact, "bn-BD", "bn-IN")
            "pa" -> listOf(exact, "pa-IN", "pa-PK")
            "gu" -> listOf(exact, "gu-IN")
            "mr" -> listOf(exact, "mr-IN", "hi-IN")
            "ne" -> listOf(exact, "ne-NP", "hi-IN")
            "si" -> listOf(exact, "si-LK")
            "ta" -> listOf(exact, "ta-IN", "ta-LK", "ta-SG", "ta-MY")
            "te" -> listOf(exact, "te-IN")
            "kn" -> listOf(exact, "kn-IN")
            "ml" -> listOf(exact, "ml-IN")

            // East / Southeast Asia.
            "zh" -> listOf(exact, "zh-CN", "zh-TW", "zh-HK", "zh-SG")
            "yue" -> listOf(exact, "yue-HK", "zh-HK")
            "ja" -> listOf(exact, "ja-JP")
            "ko" -> listOf(exact, "ko-KR")
            "id" -> listOf(exact, "id-ID")
            "ms" -> listOf(exact, "ms-MY", "ms-SG", "ms-BN")
            "vi" -> listOf(exact, "vi-VN")
            "th" -> listOf(exact, "th-TH")
            "fil", "tl" -> listOf(exact, "fil-PH", "tl-PH")

            // Africa / other common Android TTS languages.
            "sw" -> listOf(exact, "sw-KE", "sw-TZ")
            "af" -> listOf(exact, "af-ZA")
            "zu" -> listOf(exact, "zu-ZA")
            "am" -> listOf(exact, "am-ET")

            else -> listOf(exact)
        }

        return zoneTags
            .filter { it.isNotBlank() }
            .distinctBy { it.lowercase(Locale.ROOT) }
            .map { Locale.forLanguageTag(it) }
            .let { locales ->
                // Final generic same-language target lets any installed accent for that language compete.
                // BCS already carries multiple language codes explicitly in the zone list.
                val generic = Locale(language)
                if (language.isNotBlank() && locales.none {
                        it.language.equals(language, true) && it.country.isBlank()
                    }) locales + generic else locales
            }
    }

    private fun sameLanguage(a: Locale, b: Locale): Boolean =
        a.language.equals(b.language, ignoreCase = true)

    private fun scoreVoice(voice: Voice, target: Locale, routeIndex: Int): Int {
        var score = 0
        val actualTag = voice.locale.toLanguageTag()
        val targetTag = target.toLanguageTag()

        if (actualTag.equals(targetTag, ignoreCase = true)) score += 10_000
        if (voice.locale.country.isNotBlank() && voice.locale.country.equals(target.country, true)) score += 2_000
        if (sameLanguage(voice.locale, target)) score += 1_000

        // Android quality is engine-defined; preserve it as a meaningful tie-breaker.
        score += voice.quality.coerceIn(0, 1000) * 3

        // On-device voices are preferred for a live DJ: predictable and no network latency.
        if (!voice.isNetworkConnectionRequired) score += 900 else score -= 250

        score += maleHint(voice) * 350
        score -= routeIndex.coerceAtMost(20) * 100
        return score
    }

    private fun maleHint(voice: Voice): Int {
        val haystack = buildString {
            append(voice.name.lowercase(Locale.ROOT))
            append(' ')
            voice.features.orEmpty().forEach { append(it.lowercase(Locale.ROOT)).append(' ') }
        }
        val male = listOf(
            "male", "masculine", "masculino", "homme", "mann", "männlich", "maschio",
            "muški", "muski", "муж", "男", "남성"
        )
        val female = listOf(
            "female", "feminine", "femenino", "femme", "weiblich", "femmina",
            "ženski", "zenski", "жен", "女", "여성"
        )
        return when {
            male.any { it in haystack } -> 2
            female.any { it in haystack } -> -2
            else -> 0
        }
    }
}
