package com.terafon.pausemix

import com.terafon.pausemix.model.TrackRef
import kotlinx.coroutines.Job
import java.util.ArrayDeque

/**
 * QEM backstage runtime owner.
 *
 * This class deliberately owns NO ExoPlayer and performs NO playback, seek, fade, transition,
 * YouTube resolve, filtering or BPM/Fonoteka work. Its job is narrower: keep QEM's mutable
 * backstage bookkeeping out of MixerActivity so the physical A/B floor stays readable.
 *
 * Music-Hotel boundary:
 * - MixerActivity/physical layer decides when A or B is FREE/PLAYING and performs the actual load.
 * - QEM discovery code decides which candidate is valid.
 * - QemEngine owns only the runtime shelves between those layers: parked NEXT, destination,
 *   discovery lifecycle, virtual C/D crates, and handoff coroutine ownership.
 */
internal data class QemCandidateStamp(
    val generation: Long,
    val filterFingerprint: String,
    val artistId: String
)

internal class QemEngine {
    var sessionArtistPool: List<QemFonoteka.ArtistChoice> = emptyList()
    var sessionRegionKeys: Set<String> = emptySet()
    var sessionCountry: String? = null
    var sessionStyleKeys: Set<String> = emptySet()
    var sessionEraKeys: Set<String> = emptySet()
    var sessionInstrumental: Boolean = false
    var sessionPiano: Boolean = false
    var filterFingerprint: String = ""
    val recentArtistIds = ArrayDeque<String>()
    val trackArtistIds = mutableMapOf<String, String>()
    val candidateStamps = mutableMapOf<String, QemCandidateStamp>()
    val candidateArtistChoices = mutableMapOf<String, QemFonoteka.ArtistChoice>()
    val relaxedCandidateKeys = mutableSetOf<String>()

    var queued: TrackRef? = null
    var waitingFreeDeck: Boolean? = null
    var handoffPending: Boolean = false

    var discoveryJob: Job? = null
    var discoveryStartedAtMs: Long = 0L
    var discoveryAttemptSerial: Long = 0L
    val discoveryStallMs: Long = 18_000L
    var discoveryGeneration: Long = 0L
    var searchNotBeforeMs: Long = 0L
    // FREE-deck continuity lane: first attempt is strict; after 10 s the watchdog may
    // broaden discovery while REGION remains the only QEM selection gate that never relaxes.
    var relaxedDiscovery: Boolean = false

    // FAST VALID C/D: short-lived per-artist backoff prevents repeated YouTube junk loops.
    // Backstage-only bookkeeping; never influences A/B playback or weakens QEM hard gates.
    val artistSearchCooldownUntilMs = mutableMapOf<String, Long>()
    val artistSearchCooldownMs: Long = 45_000L

    val virtualCrateC = ArrayDeque<TrackRef>()
    val virtualCrateD = ArrayDeque<TrackRef>()
    var virtualCrateJob: Job? = null
    var handoffJobA: Job? = null
    var handoffJobB: Job? = null
    val virtualCrateDepth: Int = 3


    fun takeVirtualForDeck(isA: Boolean, accept: (TrackRef) -> Boolean): TrackRef? {
        val crate = if (isA) virtualCrateC else virtualCrateD
        while (crate.isNotEmpty()) {
            val candidate = crate.removeFirst()
            if (accept(candidate)) return candidate
        }
        return null
    }

    /** Store only missing C/D shelf entries; selection/admission remains owned by QEM policy. */
    fun storeVirtualBatch(
        batch: List<TrackRef>,
        keyOf: (TrackRef) -> String,
        isCurrent: (TrackRef) -> Boolean
    ) {
        val already = (virtualCrateC + virtualCrateD).map(keyOf).toMutableSet()
        var toA = virtualCrateC.size <= virtualCrateD.size
        batch.forEach { track ->
            val key = keyOf(track)
            if (key.isBlank() || key in already || !isCurrent(track)) return@forEach
            if (toA && virtualCrateC.size < virtualCrateDepth) virtualCrateC.addLast(track)
            else if (!toA && virtualCrateD.size < virtualCrateDepth) virtualCrateD.addLast(track)
            else if (virtualCrateC.size < virtualCrateDepth) virtualCrateC.addLast(track)
            else if (virtualCrateD.size < virtualCrateDepth) virtualCrateD.addLast(track)
            already += key
            toA = !toA
        }
    }

    /** Cancel only backstage QEM jobs. This never touches A/B playback. */
    fun cancelBackstageJobs() {
        discoveryJob?.cancel()
        discoveryJob = null
        virtualCrateJob?.cancel()
        virtualCrateJob = null
        handoffJobA?.cancel()
        handoffJobA = null
        handoffJobB?.cancel()
        handoffJobB = null
        discoveryStartedAtMs = 0L
    }

    /** Clear disposable QEM shelves after their jobs have been invalidated/cancelled. */
    fun clearShelves() {
        queued = null
        waitingFreeDeck = null
        handoffPending = false
        virtualCrateC.clear()
        virtualCrateD.clear()
        artistSearchCooldownUntilMs.clear()
        candidateArtistChoices.clear()
        relaxedCandidateKeys.clear()
        relaxedDiscovery = false
    }
}
