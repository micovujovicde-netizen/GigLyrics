package com.terafon.pausemix

import com.terafon.pausemix.model.TrackRef
import kotlinx.coroutines.Job
import java.util.ArrayDeque

/**
 * QEM backstage runtime owner.
 *
 * This class deliberately owns NO ExoPlayer and performs NO playback, seek, fade, transition,
 * YouTube resolve, filtering or BPM/Fonoteka work. Its job is narrower: keep QEM's mutable
 * backstage bookkeeping out of MixerActivity so the physical A/B floor stays readable.
 *
 * Music-Hotel boundary:
 * - MixerActivity/physical layer decides when A or B is FREE/PLAYING and performs the actual load.
 * - Deck J decides which candidate is valid and owns candidate/metadata authority.
 * - QemEngine owns only disposable transport bookkeeping: parked NEXT, discovery lifecycle,
 *   passive C/D parking shelves, and handoff coroutine ownership.
 * - C/D have no destination or admission rights over A/B.
 */
internal data class QemCandidateStamp(
    val generation: Long,
    val filterFingerprint: String,
    val artistId: String
)

internal class QemEngine {
    var sessionArtistPool: List<QemFonoteka.ArtistChoice> = emptyList()
    var sessionRegionKeys: Set<String> = emptySet()
    var sessionCountry: String? = null
    var sessionStyleKeys: Set<String> = emptySet()
    var sessionEraKeys: Set<String> = emptySet()
    var sessionInstrumental: Boolean = false
    var sessionPiano: Boolean = false
    var filterFingerprint: String = ""
    val recentArtistIds = ArrayDeque<String>()
    val trackArtistIds = mutableMapOf<String, String>()
    val candidateStamps = mutableMapOf<String, QemCandidateStamp>()
    val candidateArtistChoices = mutableMapOf<String, QemFonoteka.ArtistChoice>()
    val relaxedCandidateKeys = mutableSetOf<String>()

    var queued: TrackRef? = null
    var waitingFreeDeck: Boolean? = null
    var handoffPending: Boolean = false

    // DECK J TRANSPORT MUTEX.
    // Only one J -> resolver -> physical handoff may exist at a time.
    // C/D remain passive shelves; this flag gives them no authority.
    var deckJTransportBusy: Boolean = false
    var deckJTransportTarget: Boolean? = null

    var discoveryJob: Job? = null
    var discoveryStartedAtMs: Long = 0L
    var discoveryAttemptSerial: Long = 0L
    val discoveryStallMs: Long = 18_000L
    var discoveryGeneration: Long = 0L
    var searchNotBeforeMs: Long = 0L
    // FREE-deck continuity lane: first attempt is strict; after 10 s the watchdog may
    // broaden discovery while REGION remains the only QEM selection gate that never relaxes.
    var relaxedDiscovery: Boolean = false

    // FAST VALID C/D: short-lived per-artist backoff prevents repeated YouTube junk loops.
    // Backstage-only bookkeeping; never influences A/B playback or weakens QEM hard gates.
    val artistSearchCooldownUntilMs = mutableMapOf<String, Long>()
    val artistSearchCooldownMs: Long = 45_000L

    val virtualCrateC = ArrayDeque<TrackRef>()
    val virtualCrateD = ArrayDeque<TrackRef>()
    var virtualCrateJob: Job? = null
    var handoffJobA: Job? = null
    var handoffJobB: Job? = null
    val virtualCrateDepth: Int = 3


    /**
     * Passive parking read. C and D are deliberately pooled here: neither shelf is tied to A or B.
     * Deck J has already admitted these tracks; neither shelf has destination authority.
     */
    fun takePassiveBuffered(accept: (TrackRef) -> Boolean): TrackRef? {
        while (virtualCrateC.isNotEmpty() || virtualCrateD.isNotEmpty()) {
            val candidate = when {
                virtualCrateC.isEmpty() -> virtualCrateD.removeFirst()
                virtualCrateD.isEmpty() -> virtualCrateC.removeFirst()
                else -> virtualCrateC.removeFirst()
            }
            if (accept(candidate)) return candidate
        }
        return null
    }

    /** Store J-admitted candidates only as passive parking; C/D never choose A/B. */
    fun storeVirtualBatch(
        batch: List<TrackRef>,
        keyOf: (TrackRef) -> String,
        isCurrent: (TrackRef) -> Boolean
    ) {
        val already = (virtualCrateC + virtualCrateD).map(keyOf).toMutableSet()
        var toA = virtualCrateC.size <= virtualCrateD.size
        batch.forEach { track ->
            val key = keyOf(track)
            if (key.isBlank() || key in already || !isCurrent(track)) return@forEach
            if (toA && virtualCrateC.size < virtualCrateDepth) virtualCrateC.addLast(track)
            else if (!toA && virtualCrateD.size < virtualCrateDepth) virtualCrateD.addLast(track)
            else if (virtualCrateC.size < virtualCrateDepth) virtualCrateC.addLast(track)
            else if (virtualCrateD.size < virtualCrateDepth) virtualCrateD.addLast(track)
            already += key
            toA = !toA
        }
    }

    /** Cancel only backstage QEM jobs. This never touches A/B playback. */
    fun cancelBackstageJobs() {
        discoveryJob?.cancel()
        discoveryJob = null
        virtualCrateJob?.cancel()
        virtualCrateJob = null
        handoffJobA?.cancel()
        handoffJobA = null
        handoffJobB?.cancel()
        handoffJobB = null
        deckJTransportBusy = false
        deckJTransportTarget = null
        discoveryStartedAtMs = 0L
    }

    /** Clear disposable QEM shelves after their jobs have been invalidated/cancelled. */
    fun clearShelves() {
        queued = null
        waitingFreeDeck = null
        handoffPending = false
        deckJTransportBusy = false
        deckJTransportTarget = null
        virtualCrateC.clear()
        virtualCrateD.clear()
        artistSearchCooldownUntilMs.clear()
        candidateArtistChoices.clear()
        relaxedCandidateKeys.clear()
        relaxedDiscovery = false
    }
}
