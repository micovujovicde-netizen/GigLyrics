package com.terafon.pausemix

import com.terafon.pausemix.model.TrackRef
import kotlinx.coroutines.Job
import java.util.ArrayDeque

/**
 * QEM runtime bookkeeping only.
 *
 * No Music-Hotel, no C/D shelves, no secondary selector.
 * Deck J is the sole automatic selection/metadata authority.
 * A/B are physical playback only.
 */
internal data class QemCandidateStamp(
    val generation: Long,
    val filterFingerprint: String,
    val artistId: String
)

internal class QemEngine {
    var sessionArtistPool: List<QemFonoteka.ArtistChoice> = emptyList()
    var sessionRegionKeys: Set<String> = emptySet()
    var sessionCountry: String? = null
    var sessionStyleKeys: Set<String> = emptySet()
    var sessionEraKeys: Set<String> = emptySet()
    var sessionInstrumental: Boolean = false
    var sessionPiano: Boolean = false
    var filterFingerprint: String = ""

    val recentArtistIds = ArrayDeque<String>()
    val trackArtistIds = mutableMapOf<String, String>()
    val candidateStamps = mutableMapOf<String, QemCandidateStamp>()
    val candidateArtistChoices = mutableMapOf<String, QemFonoteka.ArtistChoice>()
    val relaxedCandidateKeys = mutableSetOf<String>()

    // Exactly one prepared/parked NEXT may exist outside A/B.
    var queued: TrackRef? = null
    var waitingFreeDeck: Boolean? = null
    var handoffPending: Boolean = false

    // Exactly one J -> resolver -> FREE A/B transport at a time.
    var deckJTransportBusy: Boolean = false
    var deckJTransportTarget: Boolean? = null

    var discoveryJob: Job? = null
    var discoveryStartedAtMs: Long = 0L
    var discoveryAttemptSerial: Long = 0L
    var discoveryGeneration: Long = 0L

    val artistSearchCooldownUntilMs = mutableMapOf<String, Long>()
    val artistSearchCooldownMs: Long = 45_000L

    var handoffJobA: Job? = null
    var handoffJobB: Job? = null

    fun cancelBackstageJobs() {
        discoveryJob?.cancel()
        discoveryJob = null
        handoffJobA?.cancel()
        handoffJobA = null
        handoffJobB?.cancel()
        handoffJobB = null
        deckJTransportBusy = false
        deckJTransportTarget = null
        discoveryStartedAtMs = 0L
    }

    fun clearShelves() {
        queued = null
        waitingFreeDeck = null
        handoffPending = false
        deckJTransportBusy = false
        deckJTransportTarget = null
        artistSearchCooldownUntilMs.clear()
        candidateArtistChoices.clear()
        relaxedCandidateKeys.clear()
    }
}
