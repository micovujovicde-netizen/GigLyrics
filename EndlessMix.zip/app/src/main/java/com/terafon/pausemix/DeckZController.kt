package com.terafon.pausemix

import android.animation.ValueAnimator
import android.app.Activity
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.audiofx.PresetReverb
import android.os.Bundle
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Dedicated spoken AI-DJ audio layer.
 *
 * This controller never owns or touches A/B players. Its only output toward playback is a scalar
 * duck value supplied through [onDuckChanged], so the physical playback layer remains sovereign.
 */
class DeckZController(
    private val activity: Activity,
    private val scope: CoroutineScope,
    private val cacheDir: File,
    private val currentBpm: () -> Float,
    private val onDuckChanged: (Float) -> Unit,
    private val onStateChanged: () -> Unit,
    private val log: (String) -> Unit
) {
    private var tts: TextToSpeech? = null
    @Volatile var isReady: Boolean = false
        private set
    @Volatile var isBusy: Boolean = false
        private set

    private var pendingManualText: String? = null
    private var pendingSynthFile: File? = null
    private var primaryPlayer: MediaPlayer? = null
    private var echoPlayer: MediaPlayer? = null
    private var reverb: PresetReverb? = null
    private var duck = 1f
    private var duckAnimator: ValueAnimator? = null
    private var localeProvider: (() -> Locale)? = null

    fun initialize(localeProvider: () -> Locale) {
        this.localeProvider = localeProvider
        val created = TextToSpeech(activity) { status ->
            activity.runOnUiThread {
                isReady = status == TextToSpeech.SUCCESS
                log("DECK_Z_TTS_INIT status=$status ready=$isReady")
                if (isReady) {
                    tts?.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    selectBestVoice(localeProvider())
                    val pending = pendingManualText
                    if (!pending.isNullOrBlank()) {
                        pendingManualText = null
                        synthesize(pending, localeProvider(), manual = true)
                    } else if (isBusy) {
                        setBusy(false)
                    }
                } else {
                    pendingManualText = null
                    setBusy(false)
                }
                onStateChanged()
            }
        }
        tts = created
        created.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                setBusy(true)
                log("DECK_Z_SYNTH_START id=${utteranceId ?: "unknown"}")
            }

            override fun onDone(utteranceId: String?) {
                if (utteranceId?.startsWith("deck_z_synth_") != true) {
                    log("DECK_Z_RENDER_IGNORED id=${utteranceId ?: "unknown"}")
                    releasePlayback()
                    return
                }
                val file = pendingSynthFile
                pendingSynthFile = null
                val bytes = if (file?.exists() == true) file.length() else 0L
                log("DECK_Z_RENDER_DONE id=$utteranceId bytes=$bytes")
                if (file != null && bytes > 0L) {
                    activity.runOnUiThread { playRenderedAudio(file) }
                } else {
                    log("DECK_Z_RENDER_ERROR id=$utteranceId reason=empty_file")
                    releasePlayback()
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                log("DECK_Z_RENDER_ERROR id=${utteranceId ?: "unknown"} code=legacy")
                releasePlayback()
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                log("DECK_Z_RENDER_ERROR id=${utteranceId ?: "unknown"} code=$errorCode")
                releasePlayback()
            }
        })
    }

    fun speakAutomatic(text: String, locale: Locale): Boolean {
        if (isBusy || !isReady) return false
        synthesize(text, locale, manual = false)
        return true
    }

    fun speakManual(text: String, locale: Locale): Boolean {
        if (isBusy) return false
        setBusy(true)
        if (!isReady) {
            pendingManualText = text
            return true
        }
        synthesize(text, locale, manual = true)
        return true
    }

    fun shutdown() {
        duckAnimator?.cancel()
        duckAnimator = null
        stopPlayers()
        pendingSynthFile?.delete()
        pendingSynthFile = null
        pendingManualText = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        isReady = false
        isBusy = false
        duck = 1f
        onDuckChanged(1f)
    }

    private fun setBusy(value: Boolean) {
        isBusy = value
        activity.runOnUiThread { onStateChanged() }
    }

    private fun selectBestVoice(requestedLocale: Locale): Voice? {
        val engine = tts ?: return null
        val language = requestedLocale.language
        val candidates = engine.voices.orEmpty().filter { voice ->
            voice.locale.language.equals(language, ignoreCase = true) &&
                voice.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) != true
        }

        fun maleHint(voice: Voice): Int {
            val haystack = buildString {
                append(voice.name.lowercase(Locale.ROOT))
                append(' ')
                voice.features.orEmpty().forEach { append(it.lowercase(Locale.ROOT)).append(' ') }
            }
            val maleTokens = listOf("male", "masculine", "masculino", "homme", "mann", "männlich", "maschio", "muški", "muski", "муж", "男", "남성")
            val femaleTokens = listOf("female", "feminine", "femenino", "femme", "weiblich", "femmina", "ženski", "zenski", "жен", "女", "여성")
            return when {
                maleTokens.any { it in haystack } -> 2
                femaleTokens.any { it in haystack } -> -2
                else -> 0
            }
        }

        val best = candidates.maxWithOrNull(
            compareBy<Voice> { maleHint(it) }
                .thenBy { it.quality }
                .thenBy { if (it.locale.toLanguageTag().equals(requestedLocale.toLanguageTag(), true)) 1 else 0 }
                .thenBy { if (it.isNetworkConnectionRequired) 1 else 0 }
        )
        if (best != null) {
            engine.voice = best
            log("DECK_Z_VOICE name=${best.name} locale=${best.locale.toLanguageTag()} maleHint=${maleHint(best)} quality=${best.quality} network=${best.isNetworkConnectionRequired}")
        } else {
            val availability = engine.isLanguageAvailable(requestedLocale)
            engine.language = if (availability >= TextToSpeech.LANG_AVAILABLE) requestedLocale else Locale.US
            log("DECK_Z_VOICE fallback=language locale=${engine.language?.toLanguageTag() ?: "unknown"}")
        }
        engine.setSpeechRate(0.80f)
        engine.setPitch(if (best != null && maleHint(best) > 0) 1.0f else 0.82f)
        return best
    }

    private fun synthesize(text: String, requestedLocale: Locale, manual: Boolean) {
        val engine = tts ?: run {
            setBusy(false)
            return
        }
        selectBestVoice(requestedLocale)
        setBusy(true)

        val id = "deck_z_synth_${if (manual) "manual" else "auto"}_${SystemClock.elapsedRealtime()}"
        val file = File(cacheDir, "$id.wav")
        pendingSynthFile?.delete()
        pendingSynthFile = file
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_FEATURE_NETWORK_TIMEOUT_MS, "5000")
            putString(TextToSpeech.Engine.KEY_FEATURE_NETWORK_RETRIES_COUNT, "1")
        }
        val result = engine.synthesizeToFile(text, params, file, id)
        if (result == TextToSpeech.ERROR) {
            pendingSynthFile = null
            releasePlayback()
        } else {
            log("DECK_Z_RENDER_START manual=$manual locale=${requestedLocale.toLanguageTag()} textChars=${text.length}")
        }
    }

    private fun releasePlayback() {
        stopPlayers()
        setDuck(1f, 650L)
        setBusy(false)
    }

    private fun stopPlayers() {
        try { primaryPlayer?.stop() } catch (_: Throwable) {}
        try { echoPlayer?.stop() } catch (_: Throwable) {}
        primaryPlayer?.release()
        echoPlayer?.release()
        reverb?.release()
        primaryPlayer = null
        echoPlayer = null
        reverb = null
    }

    private fun setDuck(target: Float, durationMs: Long) {
        val clamped = target.coerceIn(0f, 1f)
        duckAnimator?.cancel()
        val start = duck
        if (durationMs <= 0L) {
            duck = clamped
            onDuckChanged(clamped)
            return
        }
        duckAnimator = ValueAnimator.ofFloat(start, clamped).apply {
            duration = durationMs
            addUpdateListener { animator ->
                duck = (animator.animatedValue as Float).coerceIn(0f, 1f)
                onDuckChanged(duck)
            }
            start()
        }
    }

    private fun delayMs(): Long {
        val bpm = currentBpm().takeIf { it in 70f..180f } ?: 124f
        val quarter = 60_000f / bpm
        return (quarter / 2f).roundToInt().toLong().coerceIn(170L, 430L)
    }

    private fun playRenderedAudio(file: File) {
        if (!file.exists() || file.length() <= 0L) {
            log("DECK_Z_PLAYER_ERROR stage=input reason=empty_file")
            releasePlayback()
            return
        }
        stopPlayers()

        val primary = try {
            MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                setDataSource(file.absolutePath)
                prepare()
                setVolume(1f, 1f)
            }
        } catch (t: Throwable) {
            log("DECK_Z_PLAYER_ERROR stage=primary_prepare type=${t.javaClass.simpleName} msg=${t.message?.take(80)}")
            releasePlayback()
            return
        }

        primary.setOnCompletionListener {
            log("DECK_Z_PLAY_DONE")
            releasePlayback()
        }
        primary.setOnErrorListener { _, what, extra ->
            log("DECK_Z_PLAYER_ERROR stage=primary_runtime what=$what extra=$extra")
            releasePlayback()
            true
        }
        primaryPlayer = primary

        try {
            primary.start()
            setDuck(0.5f, 320L)
        } catch (t: Throwable) {
            log("DECK_Z_PLAYER_ERROR stage=primary_start type=${t.javaClass.simpleName} msg=${t.message?.take(80)}")
            releasePlayback()
            return
        }

        val echoDelayMs = delayMs()
        var reverbLabel = "off"
        try {
            val room = PresetReverb(0, 0).apply {
                preset = PresetReverb.PRESET_LARGEHALL
                enabled = true
            }
            primary.attachAuxEffect(room.id)
            primary.setAuxEffectSendLevel(0.50f)
            reverb = room
            reverbLabel = "largehall50"
        } catch (t: Throwable) {
            log("DECK_Z_FX_SKIP effect=reverb type=${t.javaClass.simpleName}")
        }

        try {
            val echo = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                setDataSource(file.absolutePath)
                prepare()
                setVolume(0.208f, 0.208f)
            }
            echoPlayer = echo
            scope.launch {
                delay(echoDelayMs)
                if (isBusy && primaryPlayer?.isPlaying == true) {
                    try {
                        echoPlayer?.start()
                        log("DECK_Z_ECHO_START delayMs=$echoDelayMs")
                    } catch (t: Throwable) {
                        log("DECK_Z_FX_SKIP effect=echo_start type=${t.javaClass.simpleName}")
                    }
                }
            }
        } catch (t: Throwable) {
            log("DECK_Z_FX_SKIP effect=echo_prepare type=${t.javaClass.simpleName}")
        }

        log("DECK_Z_PLAY fileBytes=${file.length()} duck=0.5 delayMs=$echoDelayMs reverb=$reverbLabel")
        file.deleteOnExit()
    }
}
