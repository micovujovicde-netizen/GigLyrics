package com.terafon.pausemix

import android.animation.ValueAnimator
import android.app.Activity
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.audiofx.Equalizer
import android.media.audiofx.PresetReverb
import android.os.Bundle
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Dedicated spoken AI-DJ audio layer.
 *
 * This controller never owns or touches A/B players. Its only output toward playback is a scalar
 * duck value supplied through [onDuckChanged], so the physical playback layer remains sovereign.
 */
class DeckZController(
    private val activity: Activity,
    private val scope: CoroutineScope,
    private val cacheDir: File,
    private val currentBpm: () -> Float,
    private val onDuckChanged: (Float) -> Unit,
    private val onStateChanged: () -> Unit,
    private val log: (String) -> Unit
) {
    private var tts: TextToSpeech? = null
    @Volatile var isReady: Boolean = false
        private set
    @Volatile var isBusy: Boolean = false
        private set

    private var pendingManualText: String? = null
    private var pendingSynthFile: File? = null
    private var primaryPlayer: MediaPlayer? = null
    private var echoPlayer: MediaPlayer? = null
    private var reverb: PresetReverb? = null
    private var speechEq: Equalizer? = null
    private var duck = 1f
    private var duckAnimator: ValueAnimator? = null
    private var localeProvider: (() -> Locale)? = null
    private val voiceRouter = DeckZVoiceRouter(log)

    fun initialize(localeProvider: () -> Locale) {
        this.localeProvider = localeProvider
        val created = TextToSpeech(activity) { status ->
            activity.runOnUiThread {
                isReady = status == TextToSpeech.SUCCESS
                log("DECK_Z_TTS_INIT status=$status ready=$isReady")
                if (isReady) {
                    tts?.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    selectBestVoice(localeProvider())
                    val pending = pendingManualText
                    if (!pending.isNullOrBlank()) {
                        pendingManualText = null
                        synthesize(pending, localeProvider(), manual = true)
                    } else if (isBusy) {
                        setBusy(false)
                    }
                } else {
                    pendingManualText = null
                    setBusy(false)
                }
                onStateChanged()
            }
        }
        tts = created
        created.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                setBusy(true)
                log("DECK_Z_SYNTH_START id=${utteranceId ?: "unknown"}")
            }

            override fun onDone(utteranceId: String?) {
                if (utteranceId?.startsWith("deck_z_synth_") != true) {
                    log("DECK_Z_RENDER_IGNORED id=${utteranceId ?: "unknown"}")
                    releasePlayback()
                    return
                }
                val file = pendingSynthFile
                pendingSynthFile = null
                val bytes = if (file?.exists() == true) file.length() else 0L
                log("DECK_Z_RENDER_DONE id=$utteranceId bytes=$bytes")
                if (file != null && bytes > 0L) {
                    activity.runOnUiThread { playRenderedAudio(file) }
                } else {
                    log("DECK_Z_RENDER_ERROR id=$utteranceId reason=empty_file")
                    releasePlayback()
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                log("DECK_Z_RENDER_ERROR id=${utteranceId ?: "unknown"} code=legacy")
                releasePlayback()
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                log("DECK_Z_RENDER_ERROR id=${utteranceId ?: "unknown"} code=$errorCode")
                releasePlayback()
            }
        })
    }

    fun speakAutomatic(text: String, locale: Locale): Boolean {
        if (isBusy || !isReady) return false
        synthesize(text, locale, manual = false)
        return true
    }

    fun speakManual(text: String, locale: Locale): Boolean {
        if (isBusy) return false
        setBusy(true)
        if (!isReady) {
            pendingManualText = text
            return true
        }
        synthesize(text, locale, manual = true)
        return true
    }

    fun shutdown() {
        duckAnimator?.cancel()
        duckAnimator = null
        stopPlayers()
        pendingSynthFile?.delete()
        pendingSynthFile = null
        pendingManualText = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        isReady = false
        isBusy = false
        duck = 1f
        onDuckChanged(1f)
    }

    private fun setBusy(value: Boolean) {
        isBusy = value
        activity.runOnUiThread { onStateChanged() }
    }

    private fun selectBestVoice(requestedLocale: Locale): Voice? {
        val engine = tts ?: return null
        val selection = voiceRouter.select(engine, requestedLocale)
        val best = selection.voice
        if (best != null) {
            engine.voice = best
        } else {
            val availability = engine.isLanguageAvailable(selection.locale)
            if (availability >= TextToSpeech.LANG_AVAILABLE) {
                engine.language = selection.locale
            }
        }

        // Keep the existing calm, male-leaning Deck Z character. Voice routing changes only
        // language/voice selection; it does not alter when Z speaks or any A/B behavior.
        engine.setSpeechRate(0.80f)
        engine.setPitch(0.92f)
        return best
    }

    private fun synthesize(text: String, requestedLocale: Locale, manual: Boolean) {
        val engine = tts ?: run {
            setBusy(false)
            return
        }
        selectBestVoice(requestedLocale)
        setBusy(true)

        val id = "deck_z_synth_${if (manual) "manual" else "auto"}_${SystemClock.elapsedRealtime()}"
        val file = File(cacheDir, "$id.wav")
        pendingSynthFile?.delete()
        pendingSynthFile = file
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_FEATURE_NETWORK_TIMEOUT_MS, "5000")
            putString(TextToSpeech.Engine.KEY_FEATURE_NETWORK_RETRIES_COUNT, "1")
        }
        val result = engine.synthesizeToFile(text, params, file, id)
        if (result == TextToSpeech.ERROR) {
            pendingSynthFile = null
            releasePlayback()
        } else {
            log("DECK_Z_RENDER_START manual=$manual locale=${requestedLocale.toLanguageTag()} textChars=${text.length}")
        }
    }

    private fun releasePlayback() {
        stopPlayers()
        setDuck(1f, 650L)
        setBusy(false)
    }

    private fun stopPlayers() {
        try { primaryPlayer?.stop() } catch (_: Throwable) {}
        try { echoPlayer?.stop() } catch (_: Throwable) {}
        primaryPlayer?.release()
        echoPlayer?.release()
        reverb?.release()
        speechEq?.release()
        primaryPlayer = null
        echoPlayer = null
        reverb = null
        speechEq = null
    }

    private fun setDuck(target: Float, durationMs: Long) {
        val clamped = target.coerceIn(0f, 1f)
        duckAnimator?.cancel()
        val start = duck
        if (durationMs <= 0L) {
            duck = clamped
            onDuckChanged(clamped)
            return
        }
        duckAnimator = ValueAnimator.ofFloat(start, clamped).apply {
            duration = durationMs
            addUpdateListener { animator ->
                duck = (animator.animatedValue as Float).coerceIn(0f, 1f)
                onDuckChanged(duck)
            }
            start()
        }
    }

    private fun delayMs(): Long {
        val bpm = currentBpm().takeIf { it in 70f..180f } ?: 124f
        val quarter = 60_000f / bpm
        return ((quarter / 2f) * DECK_Z_DELAY_SCALE).roundToInt().toLong().coerceIn(130L, 329L)
    }

    private fun playRenderedAudio(file: File) {
        if (!file.exists() || file.length() <= 0L) {
            log("DECK_Z_PLAYER_ERROR stage=input reason=empty_file")
            releasePlayback()
            return
        }
        stopPlayers()

        val primary = try {
            MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                setDataSource(file.absolutePath)
                prepare()
                setVolume(DECK_Z_OUTPUT_GAIN, DECK_Z_OUTPUT_GAIN)
            }
        } catch (t: Throwable) {
            log("DECK_Z_PLAYER_ERROR stage=primary_prepare type=${t.javaClass.simpleName} msg=${t.message?.take(80)}")
            releasePlayback()
            return
        }

        primary.setOnCompletionListener {
            log("DECK_Z_PLAY_DONE")
            releasePlayback()
        }
        primary.setOnErrorListener { _, what, extra ->
            log("DECK_Z_PLAYER_ERROR stage=primary_runtime what=$what extra=$extra")
            releasePlayback()
            true
        }
        primaryPlayer = primary

        // Deck Z only: a modest presence/air lift keeps synthesized speech intelligible over music.
        // The effect is best-effort and never touches the physical A/B playback chain.
        try {
            val eq = Equalizer(0, primary.audioSessionId)
            val range = eq.bandLevelRange
            val maxBoostMb = minOf(DECK_Z_HIGH_SHELF_BOOST_MB, range[1].toInt())
            var boosted = 0
            for (band in 0 until eq.numberOfBands.toInt()) {
                val centerHz = eq.getCenterFreq(band.toShort()) / 1000
                val levelMb = when {
                    // Stronger "AI/robot" contour: trim more low warmth, add more metallic speech presence,
                    // and double the previously approved high-frequency air. The effect remains
                    // local to Deck Z so A/B and MASTER are untouched.
                    centerHz < 250 -> maxOf(DECK_Z_ROBOT_LOW_CUT_MB, range[0].toInt())
                    centerHz < 700 -> maxOf((DECK_Z_ROBOT_LOW_CUT_MB * 0.55f).roundToInt(), range[0].toInt())
                    centerHz >= 8_000 -> maxBoostMb
                    centerHz >= 4_000 -> (maxBoostMb * 0.80f).roundToInt()
                    centerHz >= 1_500 -> minOf(DECK_Z_ROBOT_PRESENCE_MB, range[1].toInt())
                    else -> 0
                }.coerceIn(range[0].toInt(), range[1].toInt())
                eq.setBandLevel(band.toShort(), levelMb.toShort())
                if (levelMb > 0) boosted += 1
            }
            eq.enabled = true
            speechEq = eq
            log("DECK_Z_EQ_ON boostedBands=$boosted highBoostMb=$maxBoostMb outputDb=-1.0 character=stronger_robot")
        } catch (t: Throwable) {
            log("DECK_Z_FX_SKIP effect=eq type=${t.javaClass.simpleName}")
        }

        try {
            primary.start()
            setDuck(0.5f, 320L)
        } catch (t: Throwable) {
            log("DECK_Z_PLAYER_ERROR stage=primary_start type=${t.javaClass.simpleName} msg=${t.message?.take(80)}")
            releasePlayback()
            return
        }

        val echoDelayMs = delayMs()
        var reverbLabel = "off"
        try {
            val room = PresetReverb(0, 0).apply {
                preset = PresetReverb.PRESET_LARGEHALL
                enabled = true
            }
            primary.attachAuxEffect(room.id)
            primary.setAuxEffectSendLevel(0.50f)
            reverb = room
            reverbLabel = "largehall50"
        } catch (t: Throwable) {
            log("DECK_Z_FX_SKIP effect=reverb type=${t.javaClass.simpleName}")
        }

        try {
            val echo = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                setDataSource(file.absolutePath)
                prepare()
                setVolume(DECK_Z_ECHO_GAIN, DECK_Z_ECHO_GAIN)
            }
            echoPlayer = echo
            scope.launch {
                delay(echoDelayMs)
                if (isBusy && primaryPlayer?.isPlaying == true) {
                    try {
                        echoPlayer?.start()
                        log("DECK_Z_ECHO_START delayMs=$echoDelayMs")
                    } catch (t: Throwable) {
                        log("DECK_Z_FX_SKIP effect=echo_start type=${t.javaClass.simpleName}")
                    }
                }
            }
        } catch (t: Throwable) {
            log("DECK_Z_FX_SKIP effect=echo_prepare type=${t.javaClass.simpleName}")
        }

        log("DECK_Z_PLAY fileBytes=${file.length()} duck=0.5 delayMs=$echoDelayMs reverb=$reverbLabel gainDb=-1.0 eq=stronger_robot_high delayScale=$DECK_Z_DELAY_SCALE")
        file.deleteOnExit()
    }

    private companion object {
        // -1 dB: 10^(-1/20) = 0.89125. Kept local to Deck Z; A/B/master policy is untouched.
        const val DECK_Z_OUTPUT_GAIN: Float = 0.89125f
        const val DECK_Z_ECHO_GAIN: Float = 0.18539f // 0.208 * -1 dB gain

        // Android Equalizer levels are millibels. Deck Z keeps speech intelligible but the robot contour is now more pronounced.
        const val DECK_Z_HIGH_SHELF_BOOST_MB: Int = 500
        const val DECK_Z_ROBOT_PRESENCE_MB: Int = 270 // stronger +2.7 dB speech-presence contour
        const val DECK_Z_ROBOT_LOW_CUT_MB: Int = -270 // stronger -2.7 dB low-warmth cut for robot/AI tint
        const val DECK_Z_DELAY_SCALE: Float = 0.765f // current 0.90 delay reduced by a further 15%
    }
}
