package com.terafon.pausemix

/**
 * One central place for app-wide mix-output policy.
 *
 * Discovery motors and UI modes must not invent their own crossfade duration or output ceiling.
 * They may decide WHEN a transition is musically appropriate, but the physical A/B blend and
 * final output headroom stay global here.
 */
object AudioMixPolicy {
    /** Long, forgiving blend used by every automatic transition mode. */
    const val GLOBAL_CROSSFADE_MS: Long = 12_000L

    /**
     * Final mix-bus reserve: MASTER 100% still leaves 3 dB of clean digital headroom.
     * 10^(-3/20) = 0.7079458. This is applied once, centrally, after deck/crossfade gain.
     */
    const val OUTPUT_HEADROOM_GAIN: Float = 0.7079458f
}
