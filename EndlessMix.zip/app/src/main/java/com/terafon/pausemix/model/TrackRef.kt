package com.terafon.pausemix.model

data class TrackRef(
    val title: String,
    val uploader: String,
    val url: String,
    val durationSeconds: Long,
    val streamUrl: String? = null,
    val viewCount: Long = -1L,
    val uploaderVerified: Boolean = false
)
