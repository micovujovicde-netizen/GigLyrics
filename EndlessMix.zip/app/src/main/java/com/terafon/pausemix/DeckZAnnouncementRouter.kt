package com.terafon.pausemix

import java.util.Locale

/** Pure localized announcement templates for Deck Z. No TTS or playback ownership. */
class DeckZAnnouncementRouter {
    fun automatic(locale: Locale, artist: String, title: String, variant: Int): String {
        val phrases = when (locale.language.lowercase(Locale.ROOT)) {
            "hr", "sr", "bs", "sh" -> listOf(
                "Sljedeća ide $artist — $title.",
                "Nastavljamo uz $artist. $title.",
                "Na redu je $artist — $title.",
                "EndlessMix AI DJ. Sad ide $artist — $title.",
                "Još muzike. $artist — $title."
            )
            "sl" -> listOf(
                "Naslednji je $artist — $title.",
                "Nadaljujemo z $artist. $title.",
                "Na vrsti je $artist — $title.",
                "EndlessMix AI DJ. Zdaj $artist — $title.",
                "Še več glasbe. $artist — $title."
            )
            "mk" -> listOf(
                "Следно е $artist — $title.",
                "Продолжуваме со $artist. $title.",
                "На ред е $artist — $title.",
                "EndlessMix AI DJ. Сега $artist — $title.",
                "Уште музика. $artist — $title."
            )
            "sq" -> listOf(
                "Tani vjen $artist — $title.",
                "Vazhdojmë me $artist. $title.",
                "Në radhë është $artist — $title.",
                "EndlessMix AI DJ. Tani $artist — $title.",
                "Më shumë muzikë me $artist — $title."
            )
            "es" -> listOf(
                "Ahora suena $artist — $title.",
                "Seguimos con $artist. $title.",
                "A continuación, $artist — $title.",
                "EndlessMix AI DJ. Ahora, $artist — $title.",
                "Más música con $artist — $title."
            )
            "pt" -> listOf(
                "Agora toca $artist — $title.",
                "Continuamos com $artist. $title.",
                "A seguir, $artist — $title.",
                "EndlessMix AI DJ. Agora, $artist — $title.",
                "Mais música com $artist — $title."
            )
            "fr" -> listOf(
                "Maintenant, $artist — $title.",
                "On continue avec $artist. $title.",
                "À suivre, $artist — $title.",
                "EndlessMix AI DJ. Voici $artist — $title.",
                "Encore de la musique avec $artist — $title."
            )
            "de" -> listOf(
                "Jetzt kommt $artist — $title.",
                "Weiter geht's mit $artist. $title.",
                "Als Nächstes, $artist — $title.",
                "EndlessMix AI DJ. Jetzt $artist — $title.",
                "Mehr Musik mit $artist — $title."
            )
            "it" -> listOf(
                "Adesso $artist — $title.",
                "Continuiamo con $artist. $title.",
                "Il prossimo brano è $artist — $title.",
                "EndlessMix AI DJ. Ora $artist — $title.",
                "Ancora musica con $artist — $title."
            )
            "el" -> listOf(
                "Τώρα, $artist — $title.",
                "Συνεχίζουμε με $artist. $title.",
                "Επόμενο, $artist — $title.",
                "EndlessMix AI DJ. Τώρα $artist — $title.",
                "Περισσότερη μουσική με $artist — $title."
            )
            "tr" -> listOf(
                "Şimdi $artist — $title.",
                "$artist ile devam ediyoruz. $title.",
                "Sıradaki şarkı, $artist — $title.",
                "EndlessMix AI DJ. Şimdi $artist — $title.",
                "Müzik devam ediyor: $artist — $title."
            )
            "ar" -> listOf(
                "والآن $artist — $title.",
                "نواصل مع $artist. $title.",
                "الأغنية التالية، $artist — $title.",
                "EndlessMix AI DJ. الآن $artist — $title.",
                "المزيد من الموسيقى مع $artist — $title."
            )
            "hi" -> listOf(
                "अब $artist — $title।",
                "$artist के साथ आगे बढ़ते हैं। $title।",
                "अगला गाना, $artist — $title।",
                "EndlessMix AI DJ। अब $artist — $title।",
                "और संगीत: $artist — $title।"
            )
            "ur" -> listOf(
                "اب $artist — $title۔",
                "ہم $artist کے ساتھ آگے بڑھتے ہیں۔ $title۔",
                "اگلا گانا، $artist — $title۔",
                "EndlessMix AI DJ۔ اب $artist — $title۔",
                "مزید موسیقی، $artist — $title۔"
            )
            "bn" -> listOf(
                "এবার $artist — $title।",
                "$artist-এর সঙ্গে চলছি। $title।",
                "পরের গান, $artist — $title।",
                "EndlessMix AI DJ। এখন $artist — $title।",
                "আরও গান, $artist — $title।"
            )
            "ne" -> listOf(
                "अब $artist — $title।",
                "$artist सँग अगाडि बढौँ। $title।",
                "अर्को गीत, $artist — $title।",
                "EndlessMix AI DJ। अब $artist — $title।",
                "अझै संगीत, $artist — $title।"
            )
            "si" -> listOf(
                "දැන් $artist — $title.",
                "$artist සමඟ ඉදිරියට යමු. $title.",
                "ඊළඟ ගීතය $artist — $title.",
                "EndlessMix AI DJ. දැන් $artist — $title.",
                "තවත් සංගීතය, $artist — $title."
            )
            "ru" -> listOf(
                "Сейчас $artist — $title.",
                "Продолжаем с $artist. $title.",
                "Следующая песня, $artist — $title.",
                "EndlessMix AI DJ. Теперь $artist — $title.",
                "Ещё музыка: $artist — $title."
            )
            "uk" -> listOf(
                "Зараз $artist — $title.",
                "Продовжуємо з $artist. $title.",
                "Наступна пісня, $artist — $title.",
                "EndlessMix AI DJ. Тепер $artist — $title.",
                "Ще музика: $artist — $title."
            )
            "be" -> listOf(
                "Зараз $artist — $title.",
                "Працягваем з $artist. $title.",
                "Наступная песня, $artist — $title.",
                "EndlessMix AI DJ. Цяпер $artist — $title.",
                "Яшчэ музыка: $artist — $title."
            )
            "ko" -> listOf(
                "지금은 $artist — $title.",
                "${artist}의 $title, 계속 갑니다.",
                "다음 곡은 $artist — $title.",
                "EndlessMix AI DJ. 지금 $artist — $title.",
                "음악 계속됩니다. $artist — $title."
            )
            "ja" -> listOf(
                "今は $artist — $title。",
                "$artist の $title、続けます。",
                "次の曲は $artist — $title。",
                "EndlessMix AI DJ。今は $artist — $title。",
                "まだまだ音楽を。$artist — $title。"
            )
            else -> listOf(
                "Next up, $artist — $title.",
                "We keep it moving with $artist. $title.",
                "Coming in now, $artist — $title.",
                "EndlessMix AI DJ. Here's $artist — $title.",
                "More music. $artist — $title."
            )
        }
        return phrases[variant % phrases.size]
    }
}
