package com.terafon.pausemix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View

/** Tiny cosmetic age fracture for LUX hardware. Never intercepts touch. */
class HairlineCrackView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val d = resources.displayMetrics.density
    private val crackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(168, 10, 9, 8)
        style = Paint.Style.STROKE
        strokeWidth = 0.28f * d
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    init {
        isClickable = false
        isFocusable = false
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 2f || h <= 2f) return
        val isUnlock = tag?.toString() == "unlock"

        val main = Path()
        if (isUnlock) {
            main.moveTo(w * .16f, h * .55f)
            main.cubicTo(w * .23f, h * .50f, w * .25f, h * .43f, w * .31f, h * .47f)
            main.cubicTo(w * .35f, h * .50f, w * .37f, h * .39f, w * .43f, h * .42f)
            main.cubicTo(w * .48f, h * .45f, w * .50f, h * .35f, w * .57f, h * .39f)
            main.cubicTo(w * .61f, h * .42f, w * .66f, h * .36f, w * .72f, h * .38f)
            canvas.drawPath(main, crackPaint)
            val branch = Path().apply {
                moveTo(w * .43f, h * .42f)
                cubicTo(w * .41f, h * .47f, w * .42f, h * .52f, w * .39f, h * .57f)
            }
            canvas.drawPath(branch, crackPaint)
        } else {
            main.moveTo(w * .19f, h * .46f)
            main.cubicTo(w * .25f, h * .43f, w * .27f, h * .51f, w * .33f, h * .48f)
            main.cubicTo(w * .38f, h * .45f, w * .40f, h * .54f, w * .46f, h * .50f)
            main.cubicTo(w * .51f, h * .46f, w * .55f, h * .52f, w * .61f, h * .47f)
            main.cubicTo(w * .65f, h * .44f, w * .69f, h * .48f, w * .76f, h * .43f)
            canvas.drawPath(main, crackPaint)
            val branch = Path().apply {
                moveTo(w * .46f, h * .50f)
                cubicTo(w * .48f, h * .45f, w * .47f, h * .40f, w * .50f, h * .36f)
            }
            canvas.drawPath(branch, crackPaint)
        }
    }
}
