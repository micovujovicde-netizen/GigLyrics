package com.terafon.pausemix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View

/** Tiny cosmetic age fracture for LUX hardware. Never intercepts touch. */
class HairlineCrackView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val d = resources.displayMetrics.density
    private val crackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(168, 10, 9, 8)
        style = Paint.Style.STROKE
        strokeWidth = 0.46f * d
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    init {
        isClickable = false
        isFocusable = false
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 2f || h <= 2f) return
        val isUnlock = tag?.toString() == "unlock"

        val main = Path()
        if (isUnlock) {
            main.moveTo(w * .08f, h * .62f)
            main.cubicTo(w * .17f, h * .55f, w * .20f, h * .42f, w * .29f, h * .47f)
            main.cubicTo(w * .35f, h * .50f, w * .39f, h * .31f, w * .48f, h * .37f)
            main.cubicTo(w * .56f, h * .42f, w * .59f, h * .27f, w * .66f, h * .33f)
            main.cubicTo(w * .75f, h * .41f, w * .79f, h * .25f, w * .91f, h * .30f)
            canvas.drawPath(main, crackPaint)
            val branch = Path().apply {
                moveTo(w * .48f, h * .37f)
                cubicTo(w * .46f, h * .49f, w * .41f, h * .52f, w * .39f, h * .63f)
            }
            canvas.drawPath(branch, crackPaint)
        } else {
            main.moveTo(w * .10f, h * .40f)
            main.cubicTo(w * .19f, h * .44f, w * .24f, h * .61f, w * .32f, h * .54f)
            main.cubicTo(w * .39f, h * .48f, w * .44f, h * .67f, w * .53f, h * .59f)
            main.cubicTo(w * .61f, h * .51f, w * .68f, h * .68f, w * .76f, h * .57f)
            main.cubicTo(w * .82f, h * .49f, w * .87f, h * .53f, w * .92f, h * .47f)
            canvas.drawPath(main, crackPaint)
            val branch = Path().apply {
                moveTo(w * .53f, h * .59f)
                cubicTo(w * .55f, h * .46f, w * .60f, h * .42f, w * .62f, h * .31f)
            }
            canvas.drawPath(branch, crackPaint)
        }
    }
}
