package com.terafon.pausemix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View

/** Small natural micro-fracture for worn LUX hardware. Never intercepts touch. */
class HairlineCrackView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val d = resources.displayMetrics.density
    private val crackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(158, 10, 9, 8)
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    init {
        isClickable = false
        isFocusable = false
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    private fun stroke(canvas: Canvas, widthDp: Float, build: Path.() -> Unit) {
        crackPaint.strokeWidth = widthDp * d
        canvas.drawPath(Path().apply(build), crackPaint)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 2f || h <= 2f) return
        val unlock = tag?.toString() == "unlock"

        // A fracture has a root and loses material/width as it travels.
        // Separate irregular segments avoid the artificial constant-width drawn-line look.
        if (unlock) {
            stroke(canvas, .72f) { moveTo(w*.19f,h*.56f); cubicTo(w*.23f,h*.53f,w*.245f,h*.48f,w*.29f,h*.49f) }
            stroke(canvas, .52f) { moveTo(w*.29f,h*.49f); cubicTo(w*.325f,h*.50f,w*.34f,h*.43f,w*.385f,h*.445f) }
            stroke(canvas, .36f) { moveTo(w*.385f,h*.445f); cubicTo(w*.425f,h*.46f,w*.44f,h*.39f,w*.49f,h*.41f) }
            stroke(canvas, .23f) { moveTo(w*.49f,h*.41f); cubicTo(w*.535f,h*.43f,w*.56f,h*.385f,w*.61f,h*.395f) }
            stroke(canvas, .13f) { moveTo(w*.61f,h*.395f); cubicTo(w*.645f,h*.402f,w*.665f,h*.375f,w*.70f,h*.382f) }
            stroke(canvas, .27f) { moveTo(w*.385f,h*.445f); cubicTo(w*.37f,h*.48f,w*.375f,h*.505f,w*.35f,h*.535f) }
            stroke(canvas, .12f) { moveTo(w*.35f,h*.535f); cubicTo(w*.34f,h*.55f,w*.345f,h*.565f,w*.33f,h*.585f) }
        } else {
            stroke(canvas, .68f) { moveTo(w*.20f,h*.52f); cubicTo(w*.235f,h*.50f,w*.25f,h*.46f,w*.29f,h*.47f) }
            stroke(canvas, .49f) { moveTo(w*.29f,h*.47f); cubicTo(w*.325f,h*.485f,w*.34f,h*.425f,w*.385f,h*.44f) }
            stroke(canvas, .34f) { moveTo(w*.385f,h*.44f); cubicTo(w*.42f,h*.455f,w*.445f,h*.405f,w*.485f,h*.42f) }
            stroke(canvas, .22f) { moveTo(w*.485f,h*.42f); cubicTo(w*.525f,h*.435f,w*.55f,h*.405f,w*.59f,h*.412f) }
            stroke(canvas, .12f) { moveTo(w*.59f,h*.412f); cubicTo(w*.62f,h*.418f,w*.64f,h*.397f,w*.67f,h*.402f) }
            stroke(canvas, .25f) { moveTo(w*.385f,h*.44f); cubicTo(w*.37f,h*.475f,w*.378f,h*.50f,w*.355f,h*.525f) }
            stroke(canvas, .11f) { moveTo(w*.355f,h*.525f); cubicTo(w*.345f,h*.54f,w*.35f,h*.555f,w*.337f,h*.57f) }
        }
    }
}
