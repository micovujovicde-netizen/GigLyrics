package com.terafon.pausemix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View

/** Tiny cosmetic age fracture for LUX hardware. Never intercepts touch. */
class HairlineCrackView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val d = resources.displayMetrics.density
    private val crackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(168, 10, 9, 8)
        style = Paint.Style.STROKE
        strokeWidth = 0.22f * d
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    init {
        isClickable = false
        isFocusable = false
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 2f || h <= 2f) return
        val isUnlock = tag?.toString() == "unlock"

        val main = Path()
        if (isUnlock) {
            main.moveTo(w * .16f, h * .55f)
            main.cubicTo(w * .23f, h * .50f, w * .25f, h * .43f, w * .31f, h * .47f)
            main.cubicTo(w * .35f, h * .50f, w * .37f, h * .39f, w * .43f, h * .42f)
            main.cubicTo(w * .48f, h * .45f, w * .50f, h * .35f, w * .57f, h * .39f)
            main.cubicTo(w * .61f, h * .42f, w * .66f, h * .36f, w * .72f, h * .38f)
            canvas.drawPath(main, crackPaint)
            val branch = Path().apply {
                moveTo(w * .43f, h * .42f)
                cubicTo(w * .41f, h * .47f, w * .42f, h * .52f, w * .39f, h * .57f)
            }
            canvas.drawPath(branch, crackPaint)
        } else {
            // LOCK gets its own tiny, irregular fracture: no repeated zig-zag geometry.
            main.moveTo(w * .18f, h * .50f)
            main.cubicTo(w * .22f, h * .48f, w * .24f, h * .44f, w * .29f, h * .46f)
            main.cubicTo(w * .33f, h * .48f, w * .35f, h * .41f, w * .40f, h * .43f)
            main.cubicTo(w * .44f, h * .45f, w * .47f, h * .39f, w * .52f, h * .42f)
            main.cubicTo(w * .56f, h * .44f, w * .60f, h * .40f, w * .66f, h * .41f)
            main.cubicTo(w * .70f, h * .42f, w * .73f, h * .38f, w * .78f, h * .40f)
            canvas.drawPath(main, crackPaint)
            val branch = Path().apply {
                moveTo(w * .40f, h * .43f)
                cubicTo(w * .38f, h * .47f, w * .39f, h * .51f, w * .36f, h * .55f)
            }
            canvas.drawPath(branch, crackPaint)
        }
    }
}
