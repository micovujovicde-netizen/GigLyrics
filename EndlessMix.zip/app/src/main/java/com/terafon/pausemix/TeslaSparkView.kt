package com.terafon.pausemix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class TeslaSparkView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 2f * density
    }
    private var startedAt = 0L
    private var running = false
    private val rays = List(18) {
        Triple(Random.nextFloat() * 6.2831855f, 0.45f + Random.nextFloat() * 0.45f, Random.nextBoolean())
    }

    fun burst() {
        startedAt = System.currentTimeMillis()
        running = true
        visibility = VISIBLE
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!running) return
        val elapsed = System.currentTimeMillis() - startedAt
        if (elapsed >= 200L) {
            running = false
            visibility = INVISIBLE
            return
        }
        val t = elapsed / 200f
        val alpha = ((1f - t) * 255).toInt().coerceIn(0, 255)
        val cx = width / 2f
        val cy = height / 2f
        val base = minOf(width, height) * 0.28f
        val spread = minOf(width, height) * 0.48f
        rays.forEach { (angle, lengthFactor, gold) ->
            paint.color = if (gold) Color.rgb(226, 188, 73) else Color.rgb(224, 229, 234)
            paint.alpha = alpha
            val r0 = base * (0.72f + t * 0.28f)
            val r1 = base + spread * lengthFactor * t
            canvas.drawLine(cx + cos(angle) * r0, cy + sin(angle) * r0, cx + cos(angle) * r1, cy + sin(angle) * r1, paint)
        }
        postInvalidateOnAnimation()
    }
}
