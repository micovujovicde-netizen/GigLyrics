package com.terafon.pausemix

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.Normalizer
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/**
 * Small, deliberately non-critical artist-art layer.
 * Playback never waits for it: callers use it only from background coroutines.
 * Final ringed thumbnails are persisted locally, so an artist already seen does not
 * require another Wikimedia lookup on later mixes.
 */
class ArtistArtworkRepository(context: Context) {
    private val tag = "ArtistArtwork"
    private val appContext = context.applicationContext
    private val cacheDir = File(appContext.filesDir, "artist_artwork").apply { mkdirs() }
    private val prefs = appContext.getSharedPreferences("artist_artwork_cache", Context.MODE_PRIVATE)
    private val client = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    suspend fun getArtwork(artistName: String, canonicalArtistKey: String): Bitmap? = withContext(Dispatchers.IO) {
        if (artistName.isBlank() || canonicalArtistKey.isBlank()) return@withContext null

        val key = sha256(canonicalArtistKey)
        val cached = File(cacheDir, "$key.png")
        if (cached.isFile) {
            BitmapFactory.decodeFile(cached.absolutePath)?.let { return@withContext it }
        }

        // DEBUG: do not suppress retries while artist artwork is being verified.
        // The previous 12-hour miss cache made a single transient network/API failure
        // look like a permanent missing portrait during testing.
        Log.d(tag, "artwork request artist='$artistName' key='$canonicalArtistKey'")

        // Collaboration titles are common in YouTube metadata. The FIRST credited artist
        // is canonical for the deck portrait; guests are tried only as fallbacks.
        // Example: "Tanja Savic x Corona" -> Tanja Savic, then Corona.
        val searchNames = artworkArtistCandidates(artistName)
        Log.d(tag, "Artwork candidates for '$artistName': $searchNames")

        var found: Pair<String, String>? = null
        var foundArtist = artistName
        for (candidate in searchNames) {
            val wikipedia = runCatching { lookupWikipediaThumbnail(candidate) }
                .onFailure { Log.w(tag, "Wikipedia lookup failed for '$candidate'", it) }
                .getOrNull()
            Log.d(tag, "Wikipedia result for '$candidate': ${wikipedia?.first ?: "NONE"}")

            val deezer = if (wikipedia == null) {
                runCatching { lookupDeezerArtistPicture(candidate) }
                    .onFailure { Log.w(tag, "Deezer lookup failed for '$candidate'", it) }
                    .getOrNull()
            } else null
            if (wikipedia == null) Log.d(tag, "Deezer result for '$candidate': ${deezer?.first ?: "NONE"}")

            val candidateFound = wikipedia ?: deezer
            if (candidateFound != null) {
                found = candidateFound
                foundArtist = candidate
                break
            }
        }
        if (found == null) {
            prefs.edit().putLong("miss_$key", System.currentTimeMillis()).apply()
            return@withContext null
        }

        val (imageUrl, sourcePage) = found
        Log.d(tag, "Artwork source for '$artistName' via '$foundArtist': $sourcePage")
        val bytes = runCatching { download(imageUrl) }
            .onFailure { Log.w(tag, "Artwork download failed for '$artistName': $imageUrl", it) }
            .getOrNull()
        val raw = bytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
        if (bytes != null && raw == null) Log.w(tag, "Bitmap decode failed for '$artistName' (${bytes.size} bytes)")
        if (raw == null) {
            prefs.edit().putLong("miss_$key", System.currentTimeMillis()).apply()
            return@withContext null
        }

        val finished = makeRingedCircle(raw, 256)
        runCatching {
            cached.outputStream().use { out -> finished.compress(Bitmap.CompressFormat.PNG, 92, out) }
            prefs.edit()
                .remove("miss_$key")
                .putString("source_$key", sourcePage)
                .apply()
        }
        finished
    }


    private fun artworkArtistCandidates(artistName: String): List<String> {
        val cleaned = artistName.trim()
        if (cleaned.isBlank()) return emptyList()

        // Split only explicit collaboration separators so names such as AC/DC stay intact.
        val collaboration = Regex(
            "(?i)\\s+(?:x|&|feat\\.?|ft\\.?|featuring|with|vs\\.?|/|\\+)\\s+"
        )
        val parts = cleaned.split(collaboration)
            .map { it.trim(' ', '-', '_', ',', ';') }
            .filter { it.length >= 2 }
            .distinctBy { normalize(it) }

        if (parts.size <= 1) return listOf(cleaned)

        // Primary artist first. Other credited artists are fallback only. The full credit
        // comes last in case a collaboration itself has a dedicated artist/catalog entry.
        return (parts + cleaned).distinctBy { normalize(it) }
    }

    private fun lookupWikipediaThumbnail(artistName: String): Pair<String, String>? {
        val query = URLEncoder.encode("$artistName musician", "UTF-8")
        val url = "https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=$query&gsrnamespace=0&gsrlimit=4&prop=pageimages&piprop=thumbnail&pithumbsize=320&pilicense=free&format=json&formatversion=2"
        val json = JSONObject(download(url).toString(Charsets.UTF_8))
        val pages = json.optJSONObject("query")?.optJSONArray("pages") ?: return null
        if (pages.length() == 0) return null

        val wanted = normalize(artistName)
        var fallback: Pair<String, String>? = null
        for (i in 0 until pages.length()) {
            val page = pages.optJSONObject(i) ?: continue
            val thumb = page.optJSONObject("thumbnail")?.optString("source").orEmpty()
            if (thumb.isBlank()) continue
            val title = page.optString("title")
            val pageUrl = "https://en.wikipedia.org/wiki/" + URLEncoder.encode(title.replace(' ', '_'), "UTF-8").replace("+", "%20")
            val candidate = thumb to pageUrl
            if (fallback == null) fallback = candidate
            val titleKey = normalize(title)
            if (wanted.isNotBlank() && (titleKey.contains(wanted) || wanted.contains(titleKey))) return candidate
        }
        return fallback
    }


    /**
     * Broad fallback for regional artists that often have no English Wikipedia thumbnail.
     * Deezer's public search endpoint exposes the artist image attached to its catalog result.
     * Artwork is cosmetic only; failure simply leaves the globe in place.
     */
    private fun lookupDeezerArtistPicture(artistName: String): Pair<String, String>? {
        val query = URLEncoder.encode(artistName, "UTF-8")
        val url = "https://api.deezer.com/search/artist?q=$query&limit=6"
        val json = JSONObject(download(url).toString(Charsets.UTF_8))
        val data = json.optJSONArray("data") ?: return null
        val wanted = normalize(artistName)
        var fallback: Pair<String, String>? = null
        for (i in 0 until data.length()) {
            val artist = data.optJSONObject(i) ?: continue
            val name = artist.optString("name")
            val picture = artist.optString("picture_medium").ifBlank { artist.optString("picture_big") }
            if (picture.isBlank()) continue
            val link = artist.optString("link").ifBlank { "https://www.deezer.com/search/$query" }
            val candidate = picture to link
            if (fallback == null) fallback = candidate
            val foundKey = normalize(name)
            if (wanted.isNotBlank() && (foundKey == wanted || foundKey.contains(wanted) || wanted.contains(foundKey))) return candidate
        }
        return fallback
    }

    private fun download(url: String): ByteArray {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "EndlessMix/4.5 (artist artwork; Wikimedia API)")
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("HTTP ${response.code}")
            return response.body.bytes()
        }
    }

    private fun makeRingedCircle(source: Bitmap, size: Int): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val cx = size / 2f
        val cy = size / 2f
        val ring = size * 0.045f
        val radius = size / 2f - ring - 2f

        val scale = maxOf(size.toFloat() / source.width, size.toFloat() / source.height)
        val shader = BitmapShader(source, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        val matrix = android.graphics.Matrix().apply {
            setScale(scale, scale)
            postTranslate((size - source.width * scale) / 2f, (size - source.height * scale) / 2f)
        }
        shader.setLocalMatrix(matrix)
        val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.shader = shader }
        canvas.drawCircle(cx, cy, radius, imagePaint)

        // Two restrained hardware arcs: silver base and gold peak-side accent.
        val rect = RectF(ring / 2f, ring / 2f, size - ring / 2f, size - ring / 2f)
        val silver = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = ring
            color = Color.rgb(190, 194, 199)
        }
        val gold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = ring
            color = Color.rgb(212, 175, 55)
        }
        canvas.drawArc(rect, 55f, 190f, false, silver)
        canvas.drawArc(rect, 245f, 170f, false, gold)
        return out
    }

    private fun normalize(value: String): String {
        val ascii = Normalizer.normalize(value.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .replace("đ", "dj")
        return ascii.replace(Regex("[^a-z0-9]+"), " ").trim()
    }

    private fun sha256(value: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(value.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
