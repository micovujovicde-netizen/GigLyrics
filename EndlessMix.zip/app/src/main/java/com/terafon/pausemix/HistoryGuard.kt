package com.terafon.pausemix

import android.content.Context
import com.terafon.pausemix.model.TrackRef
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.util.ArrayDeque
import java.util.Locale

/**
 * Single authority for persistent song/artist anti-repeat history and canonical performer identity.
 *
 * It intentionally knows nothing about ExoPlayer, deck state, discovery motors or UI. Callers decide
 * when a track has actually become audible; HistoryGuard only records/checks that event.
 */
class HistoryGuard(
    context: Context,
    private val songHardWindow: Int = 20,
    private val artistHardWindow: Int = 5,
    private val retention: Int = 64
) {
    private data class PlayedHistoryEntry(val songKey: String, val artistKeys: Set<String>)

    private val prefs = context.getSharedPreferences("endless_playback_history_v2", Context.MODE_PRIVATE)
    private val playedHistory = ArrayDeque<PlayedHistoryEntry>()
    private val currentMixSongKeys = linkedSetOf<String>()

    fun load() {
        playedHistory.clear()
        val raw = prefs.getString("played_events", null) ?: return
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val song = obj.optString("song").trim()
                val artistsJson = obj.optJSONArray("artists") ?: JSONArray()
                val artists = linkedSetOf<String>()
                for (j in 0 until artistsJson.length()) {
                    artistsJson.optString(j).trim().takeIf { it.isNotBlank() }?.let(artists::add)
                }
                if (song.isNotBlank() || artists.isNotEmpty()) {
                    playedHistory.addLast(PlayedHistoryEntry(song, artists))
                }
            }
            trimRetention()
        }
    }

    fun isBlocked(songKey: String, artistKeys: Set<String>, bypassArtistBan: Boolean = false): Boolean {
        // A song that actually played is banned for the rest of THIS mix. Artist cooldown stays
        // position-based and persists across restarts, so the last five played artist slots remain hard.
        if (songKey.isNotBlank() && songKey in currentMixSongKeys) return true
        if (!bypassArtistBan && artistKeys.any { it in recentArtistKeys() }) return true
        return false
    }

    fun beginMix() {
        currentMixSongKeys.clear()
    }

    fun recordActuallyPlayed(songKey: String, artistKeys: Set<String>) {
        if (songKey.isBlank() && artistKeys.isEmpty()) return

        // Duplicate callbacks for the same physical item must not consume history positions.
        // A new mix may deliberately begin with the same song that ended the previous mix, so
        // current-mix song ownership is recorded before the persistent-position de-duplication.
        if (songKey.isNotBlank()) currentMixSongKeys.add(songKey)
        val last = playedHistory.lastOrNull()
        if (last != null && last.songKey == songKey && last.artistKeys == artistKeys) return

        playedHistory.addLast(PlayedHistoryEntry(songKey, artistKeys))
        trimRetention()
        persist()
    }

    fun recentSongKeys(): Set<String> = currentMixSongKeys.toSet()

    fun recentArtistKeys(): Set<String> =
        playedHistory.toList().takeLast(artistHardWindow)
            .flatMap { it.artistKeys }
            .toSet()

    private fun trimRetention() {
        while (playedHistory.size > retention) playedHistory.removeFirst()
    }

    private fun persist() {
        val arr = JSONArray()
        playedHistory.forEach { entry ->
            val obj = JSONObject()
            obj.put("song", entry.songKey)
            val artistsJson = JSONArray()
            entry.artistKeys.forEach { artistsJson.put(it) }
            obj.put("artists", artistsJson)
            arr.put(obj)
        }
        prefs.edit().putString("played_events", arr.toString()).apply()
    }

    fun canonicalCompareText(text: String): String {
        val lowered = text.lowercase(Locale.ROOT)
            .replace("đ", "dj")
            .replace("ð", "d")
        val decomposed = Normalizer.normalize(lowered, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
        return decomposed
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun normalizeArtistText(text: String): String = canonicalCompareText(text)
        .replace(Regex("\\b(official|music|vevo|records|recordings|topic|channel|band|grupa)\\b"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    fun splitArtistCredit(raw: String): Set<String> {
        if (raw.isBlank()) return emptySet()
        val normalized = raw
            .replace(Regex("(?i)\\b(feat(?:uring)?|ft|with|duet|vs)\\.?\\b"), " & ")
            .replace(Regex("(?i)\\s+[x×]\\s+"), " & ")
            .replace(Regex("(?i)\\s+(and|i)\\s+"), " & ")
        return normalized.split('&', ',', ';')
            .map(::normalizeArtistText)
            .map { it.trim() }
            .filter { it.length >= 3 }
            .toSet()
    }

    fun creditedArtistKeys(track: TrackRef): Set<String> {
        val credits = linkedSetOf<String>()
        val separators = listOf(" - ", " – ", " — ", " | ")
        var foundTitleCredit = false
        for (sep in separators) {
            val i = track.title.indexOf(sep)
            if (i > 0) {
                credits += splitArtistCredit(track.title.substring(0, i))
                foundTitleCredit = true
                break
            }
        }

        val uploader = normalizeArtistText(track.uploader)
        val generic = listOf("records", "recordings", "label", "music", "channel", "topic", "vevo")
        if (!foundTitleCredit || generic.none { it in uploader }) credits += splitArtistCredit(track.uploader)
        return credits.filter { it.isNotBlank() }.toSet()
    }
}
