package com.terafon.pausemix

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Lightweight real-audio tempo estimator used by Endless/Quick filtering.
 * It scans only the opening section of the resolved stream, derives a short-time
 * energy-onset envelope, autocorrelates plausible beat periods, and normalizes
 * half/double-time ambiguity into a human-perceived tempo range.
 */
object TempoAnalyzer {
    data class Result(val bpm: Float, val band: String, val energyBand: String, val energyScore: Float, val confidence: Float)

    private val cache = ConcurrentHashMap<String, Result>()

    fun cached(key: String): Result? = cache[key]

    fun analyze(url: String, cacheKey: String = url, scanMs: Long = 32_000L, normalizeOctave: Boolean = true): Result? {
        cache[cacheKey]?.let { return it }

        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(url, emptyMap())
            var trackIndex = -1
            var inputFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    trackIndex = i
                    inputFormat = f
                    break
                }
            }
            if (trackIndex < 0 || inputFormat == null) return null

            extractor.selectTrack(trackIndex)
            val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: return null
            val sampleRate = if (inputFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44_100
            val channels = if (inputFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1) else 2
            val frameSamples = max(1, (sampleRate * 0.025f).toInt()) * channels // 25 ms

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(inputFormat, null, null, 0)
            codec.start()

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var guard = 0
            var blockSq = 0.0
            var blockCount = 0
            var previousEnergy = 0f
            val onset = ArrayList<Float>(1500)
            val energyFrames = ArrayList<Float>(1500)

            while (!outputDone && guard++ < 80_000) {
                if (!inputDone) {
                    val inputIndex = codec.dequeueInputBuffer(8_000)
                    if (inputIndex >= 0) {
                        val inputBuffer = codec.getInputBuffer(inputIndex)
                        if (inputBuffer != null) {
                            val t = extractor.sampleTime
                            if (t < 0L || t > scanMs * 1000L) {
                                codec.queueInputBuffer(inputIndex, 0, 0, maxOf(0L, t), MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                val size = extractor.readSampleData(inputBuffer, 0)
                                if (size < 0) {
                                    codec.queueInputBuffer(inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                    inputDone = true
                                } else {
                                    codec.queueInputBuffer(inputIndex, 0, size, t, 0)
                                    extractor.advance()
                                }
                            }
                        }
                    }
                }

                val outputIndex = codec.dequeueOutputBuffer(info, 8_000)
                if (outputIndex >= 0) {
                    if (info.size > 0 && info.presentationTimeUs <= scanMs * 1000L) {
                        val out = codec.getOutputBuffer(outputIndex)
                        if (out != null) {
                            out.position(info.offset)
                            out.limit(info.offset + info.size)
                            val pcm = out.slice().order(ByteOrder.LITTLE_ENDIAN)
                            while (pcm.remaining() >= 2) {
                                val raw = pcm.short.toInt()
                                val n = raw / 32768.0
                                blockSq += n * n
                                blockCount++
                                if (blockCount >= frameSamples) {
                                    val energy = sqrt(blockSq / blockCount).toFloat()
                                    val flux = max(0f, energy - previousEnergy)
                                    onset.add(flux)
                                    energyFrames.add(energy)
                                    previousEnergy = energy
                                    blockSq = 0.0
                                    blockCount = 0
                                }
                            }
                        }
                    }
                    outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0 || info.presentationTimeUs > scanMs * 1000L
                    codec.releaseOutputBuffer(outputIndex, false)
                }
            }

            if (onset.size < 160) return null
            val values = onset.toFloatArray()
            val mean = values.average().toFloat()
            for (i in values.indices) values[i] = max(0f, values[i] - mean * 0.65f)

            // 25 ms frames: 60 BPM ~= 40 frames, 190 BPM ~= 13 frames.
            var bestLag = 0
            var bestScore = 0.0
            var secondScore = 0.0
            for (lag in 13..40) {
                var score = 0.0
                var normA = 0.0
                var normB = 0.0
                for (i in lag until values.size) {
                    val a = values[i].toDouble()
                    val b = values[i - lag].toDouble()
                    score += a * b
                    normA += a * a
                    normB += b * b
                }
                val denom = sqrt(normA * normB).coerceAtLeast(1e-9)
                val normalized = score / denom
                if (normalized > bestScore) {
                    secondScore = bestScore
                    bestScore = normalized
                    bestLag = lag
                } else if (normalized > secondScore) {
                    secondScore = normalized
                }
            }
            if (bestLag == 0 || bestScore < 0.05) return null

            var bpm = 60f / (bestLag * 0.025f)
            // Most callers want human-perceived octave normalization. LOVE disables it so the
            // half/double-time guard can inspect the original slow estimate instead of hiding it.
            if (normalizeOctave) {
                while (bpm < 70f) bpm *= 2f
                while (bpm > 180f) bpm /= 2f
            }

            val band = when {
                bpm <= 84f -> "slow"
                bpm <= 114f -> "middle"
                bpm <= 144f -> "fast"
                else -> "very fast"
            }

            // ENERGY is intentionally independent from half/double-time BPM normalization.
            // It combines average RMS with transient/onset density, so a mastered driving dance
            // song remains high-energy even when its 170 BPM pulse is perceived as ~85 half-time.
            val avgRms = if (energyFrames.isNotEmpty()) energyFrames.average().toFloat() else 0f
            val positiveFlux = onset.filter { it > 0f }
            val fluxMean = if (positiveFlux.isNotEmpty()) positiveFlux.average().toFloat() else 0f
            val fluxThreshold = (fluxMean * 1.65f).coerceAtLeast(0.004f)
            val onsetDensity = if (onset.isNotEmpty()) onset.count { it >= fluxThreshold }.toFloat() / onset.size else 0f
            val energyScore = (avgRms * 2.5f + onsetDensity * 1.15f + fluxMean * 5.0f).coerceIn(0f, 1f)
            val energyBand = when {
                energyScore < 0.30f -> "low"
                energyScore < 0.48f -> "middle"
                energyScore < 0.68f -> "high"
                else -> "very high"
            }
            val confidence = (bestScore * (1.0 + (bestScore - secondScore).coerceAtLeast(0.0))).toFloat().coerceIn(0f, 1f)
            return Result(bpm, band, energyBand, energyScore, confidence).also { cache[cacheKey] = it }
        } catch (_: Throwable) {
            return null
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }
}
