package com.terafon.pausemix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.LinearGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.max

/**
 * Slim full-track vertical waveform.
 * Empty deck = one thin vertical line.
 * Analysis fills top -> bottom.
 * A thick transparent green horizontal playhead follows playback and is seekable by touch.
 */
class WaveColumnView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val density = resources.displayMetrics.density
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(215, 174, 74)
        strokeWidth = max(1f * density, 1.3f)
        strokeCap = Paint.Cap.ROUND
    }
    private val baselinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(155, 158, 162)
        alpha = 115
        strokeWidth = max(0.7f * density, 1f)
    }
    private val glassPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glassRimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = max(0.8f * density, 1f)
        color = Color.argb(88, 205, 210, 205)
    }
    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(82, 77, 66) }
    private val baseRimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = max(0.7f * density, 1f)
        color = Color.rgb(170, 164, 145)
    }
    private val pinPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(150, 150, 142)
        strokeWidth = max(1f * density, 1.2f)
        strokeCap = Paint.Cap.ROUND
    }
    private val playheadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0, 230, 70)
        alpha = 220
        strokeWidth = max(8f * density, 10f)
        strokeCap = Paint.Cap.ROUND
    }

    private var samples: FloatArray? = null
    private var hasTrack = false
    private var playProgress = 0f
    private var loadProgress = 0f

    var onSeekRequested: ((Float) -> Unit)? = null

    fun setEmpty() {
        hasTrack = false
        samples = null
        playProgress = 0f
        loadProgress = 0f
        invalidate()
    }

    fun setTrackPresent(present: Boolean) {
        hasTrack = present
        if (!present) setEmpty() else invalidate()
    }

    fun setWaveform(values: FloatArray?, loadedFraction: Float = 1f) {
        samples = values?.copyOf()
        hasTrack = values != null || hasTrack
        loadProgress = loadedFraction.coerceIn(0f, 1f)
        invalidate()
    }

    fun setLoadProgress(value: Float) {
        loadProgress = value.coerceIn(0f, 1f)
        invalidate()
    }

    fun setProgress(value: Float) {
        playProgress = value.coerceIn(0f, 1f)
        invalidate()
    }

    fun setTrackSeed(value: String?) = setTrackPresent(value != null)
    fun setRunning(value: Boolean) = Unit

    private fun progressFromY(y: Float): Float {
        val top = height * 0.03f
        val bottom = height * 0.97f
        val usable = (bottom - top).coerceAtLeast(1f)
        return ((y - top) / usable).coerceIn(0f, 1f)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!hasTrack || !isEnabled) return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val p = progressFromY(event.y)
                playProgress = p
                invalidate()
                onSeekRequested?.invoke(p)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                if (event.actionMasked == MotionEvent.ACTION_UP) performClick()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.BLACK)

        val midX = width / 2f
        // Keep the tube deliberately narrow so VOL A/B and NEXT arrows retain their space.
        val tubeLeft = width * 0.025f
        val tubeRight = width * 0.975f
        val tubeTop = height * 0.008f
        val baseTop = height * 0.93f
        val baseBottom = height * 0.968f
        val pinBottom = height * 0.995f
        val tubeRect = RectF(tubeLeft, tubeTop, tubeRight, baseTop + 2f * density)
        val radius = (width * 0.30f).coerceAtLeast(2f * density)

        // Extremely transparent glass: the existing waveform remains the dominant inner element.
        glassPaint.shader = LinearGradient(tubeLeft, 0f, tubeRight, 0f,
            intArrayOf(Color.argb(34, 210, 220, 215), Color.argb(5, 255, 255, 255), Color.argb(28, 185, 195, 190)),
            null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(tubeRect, radius, radius, glassPaint)
        glassPaint.shader = null
        canvas.drawRoundRect(tubeRect, radius, radius, glassRimPaint)

        val baseRect = RectF(width * 0.12f, baseTop, width * 0.88f, baseBottom)
        canvas.drawRoundRect(baseRect, 2f * density, 2f * density, basePaint)
        canvas.drawRoundRect(baseRect, 2f * density, 2f * density, baseRimPaint)
        val pinXs = floatArrayOf(width * 0.34f, midX, width * 0.66f)
        for (x in pinXs) canvas.drawLine(x, baseBottom, x, pinBottom, pinPaint)

        val top = height * 0.025f
        val bottom = height * 0.92f
        val usableH = bottom - top

        if (!hasTrack) {
            canvas.drawLine(midX, top, midX, bottom, baselinePaint)
            return
        }

        canvas.drawLine(midX, top, midX, bottom, baselinePaint)

        val data = samples
        if (data != null && data.isNotEmpty()) {
            val halfW = width * 0.34f
            val loadedCount = (data.size * loadProgress).toInt().coerceIn(0, data.size)
            if (loadedCount > 0) {
                val denom = (data.size - 1).coerceAtLeast(1).toFloat()
                for (i in 0 until loadedCount) {
                    val y = top + (i.toFloat() / denom) * usableH
                    val level = data[i].coerceIn(0.012f, 1f)
                    val amp = level * halfW
                    wavePaint.color = if (level >= 0.74f) Color.rgb(215, 174, 74) else Color.rgb(210, 214, 219)
                    canvas.drawLine(midX - amp, y, midX + amp, y, wavePaint)
                }
            }
        }

        val py = top + playProgress * usableH
        canvas.drawLine(width * 0.11f, py, width * 0.89f, py, playheadPaint)
    }
}
