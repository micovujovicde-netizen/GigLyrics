package com.terafon.pausemix

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max
import kotlin.math.sqrt

/**
 * LOVE-only lightweight ENERGY sampler.
 *
 * Unlike TempoAnalyzer this does not estimate BPM at all. It seeks directly to a short window,
 * decodes only that slice, and computes the same RMS/transient energy score used elsewhere.
 * Callers intentionally schedule several short windows across the song rather than decoding one
 * long opening block. This catches songs that start softly and become loud later, while releasing
 * the shared analysis slot between windows so playback/preparation cannot be starved.
 */
object EnergyAnalyzer {
    data class Result(val energyBand: String, val energyScore: Float)

    private val cache = ConcurrentHashMap<String, Result>()

    fun analyzeWindow(
        url: String,
        cacheKey: String,
        startMs: Long,
        scanMs: Long = 3_500L
    ): Result? {
        cache[cacheKey]?.let { return it }

        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(url, emptyMap())
            var trackIndex = -1
            var inputFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    trackIndex = i
                    inputFormat = f
                    break
                }
            }
            if (trackIndex < 0 || inputFormat == null) return null

            extractor.selectTrack(trackIndex)
            extractor.seekTo(startMs.coerceAtLeast(0L) * 1000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

            val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: return null
            val sampleRate = if (inputFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44_100
            val channels = if (inputFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1) else 2
            val frameSamples = max(1, (sampleRate * 0.025f).toInt()) * channels
            val windowEndUs = (startMs.coerceAtLeast(0L) + scanMs.coerceAtLeast(1_000L)) * 1000L

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(inputFormat, null, null, 0)
            codec.start()

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var guard = 0
            var blockSq = 0.0
            var blockCount = 0
            var previousEnergy = 0f
            val onset = ArrayList<Float>(240)
            val energyFrames = ArrayList<Float>(240)

            while (!outputDone && guard++ < 20_000) {
                if (!inputDone) {
                    val inputIndex = codec.dequeueInputBuffer(8_000)
                    if (inputIndex >= 0) {
                        val inputBuffer = codec.getInputBuffer(inputIndex)
                        if (inputBuffer != null) {
                            val t = extractor.sampleTime
                            if (t < 0L || t > windowEndUs) {
                                codec.queueInputBuffer(inputIndex, 0, 0, maxOf(0L, t), MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                val size = extractor.readSampleData(inputBuffer, 0)
                                if (size < 0) {
                                    codec.queueInputBuffer(inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                    inputDone = true
                                } else {
                                    codec.queueInputBuffer(inputIndex, 0, size, t, 0)
                                    extractor.advance()
                                }
                            }
                        }
                    }
                }

                val outputIndex = codec.dequeueOutputBuffer(info, 8_000)
                if (outputIndex >= 0) {
                    if (info.size > 0 && info.presentationTimeUs >= startMs.coerceAtLeast(0L) * 1000L && info.presentationTimeUs <= windowEndUs) {
                        val out = codec.getOutputBuffer(outputIndex)
                        if (out != null) {
                            out.position(info.offset)
                            out.limit(info.offset + info.size)
                            val pcm = out.slice().order(ByteOrder.LITTLE_ENDIAN)
                            while (pcm.remaining() >= 2) {
                                val raw = pcm.short.toInt()
                                val n = raw / 32768.0
                                blockSq += n * n
                                blockCount++
                                if (blockCount >= frameSamples) {
                                    val energy = sqrt(blockSq / blockCount).toFloat()
                                    val flux = max(0f, energy - previousEnergy)
                                    onset.add(flux)
                                    energyFrames.add(energy)
                                    previousEnergy = energy
                                    blockSq = 0.0
                                    blockCount = 0
                                }
                            }
                        }
                    }
                    outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0 || info.presentationTimeUs > windowEndUs
                    codec.releaseOutputBuffer(outputIndex, false)
                }
            }

            if (energyFrames.size < 40) return null
            val avgRms = energyFrames.average().toFloat()
            val positiveFlux = onset.filter { it > 0f }
            val fluxMean = if (positiveFlux.isNotEmpty()) positiveFlux.average().toFloat() else 0f
            val fluxThreshold = (fluxMean * 1.65f).coerceAtLeast(0.004f)
            val onsetDensity = if (onset.isNotEmpty()) onset.count { it >= fluxThreshold }.toFloat() / onset.size else 0f
            val energyScore = (avgRms * 2.5f + onsetDensity * 1.15f + fluxMean * 5.0f).coerceIn(0f, 1f)
            val energyBand = when {
                energyScore < 0.30f -> "low"
                energyScore < 0.48f -> "middle"
                energyScore < 0.68f -> "high"
                else -> "very high"
            }
            return Result(energyBand, energyScore).also { cache[cacheKey] = it }
        } catch (_: Throwable) {
            return null
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }
}
