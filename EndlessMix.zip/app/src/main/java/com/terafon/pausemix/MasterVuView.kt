package com.terafon.pausemix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/** Decorative analog MASTER VU meter used only on the locked hardware panel. */
class MasterVuView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val d = resources.displayMetrics.density
    private val panel = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(12, 12, 12); style = Paint.Style.FILL }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(188, 194, 202); style = Paint.Style.STROKE; strokeWidth = 1.3f * d }
    private val gold = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(211, 172, 70); style = Paint.Style.STROKE; strokeWidth = 1.15f * d }
    private val red = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(210, 48, 42); style = Paint.Style.STROKE; strokeWidth = 1.7f * d }
    private val needle = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(220, 183, 78); style = Paint.Style.STROKE; strokeWidth = 1.8f * d; strokeCap = Paint.Cap.ROUND }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(205, 210, 216); textAlign = Paint.Align.CENTER; textSize = 9f * d }
    private val redText = Paint(text).apply { color = Color.rgb(225, 58, 50) }
    private var target = 0f
    private var shown = 0f
    private var peak = 0f

    fun setLevel(level: Float) {
        target = level.coerceIn(0f, 1f)
        shown += (target - shown) * if (target > shown) 0.62f else 0.20f
        peak = max(shown, peak * 0.94f)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        if (width < 2 || height < 2) return
        val w = width.toFloat(); val h = height.toFloat()
        val r = 8f * d
        c.drawRoundRect(1f*d, 1f*d, w-1f*d, h-1f*d, r, r, panel)
        c.drawRoundRect(1.5f*d, 1.5f*d, w-1.5f*d, h-1.5f*d, r, r, rim)

        val cx = w * .5f; val cy = h * .91f; val radius = minOf(w * .43f, h * .72f)
        val start = Math.toRadians(205.0); val sweep = Math.toRadians(130.0)
        for (i in 0..10) {
            val f = i / 10f
            val a = start + sweep * f
            val outer = radius
            val inner = radius - (if (i % 2 == 0) 9f else 5f) * d
            val p = if (f >= .82f) red else gold
            c.drawLine(cx + cos(a).toFloat()*inner, cy + sin(a).toFloat()*inner,
                cx + cos(a).toFloat()*outer, cy + sin(a).toFloat()*outer, p)
        }
        c.drawText("MASTER", cx, 18f*d, text)
        c.drawText("VU", cx, 31f*d, text)
        c.drawText("PEAK", w*.82f, 18f*d, redText)

        val a = start + sweep * shown
        val nx = cx + cos(a).toFloat() * (radius - 5f*d)
        val ny = cy + sin(a).toFloat() * (radius - 5f*d)
        c.drawLine(cx, cy, nx, ny, if (shown >= .82f) red else needle)
        c.drawCircle(cx, cy, 4.2f*d, panel)
        c.drawCircle(cx, cy, 4.2f*d, rim)

        // Tiny red peak-hold marker on the scale.
        if (peak >= .82f) {
            val pa = start + sweep * peak.coerceIn(0f,1f)
            c.drawCircle(cx + cos(pa).toFloat()*radius, cy + sin(pa).toFloat()*radius, 2.1f*d, redText)
        }
    }
}
