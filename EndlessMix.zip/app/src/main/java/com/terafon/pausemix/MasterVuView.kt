package com.terafon.pausemix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/** Embedded analog MASTER VU meter for the locked hardware panel. */
class MasterVuView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val d = resources.displayMetrics.density

    private val face = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(226, 205, 105)
        style = Paint.Style.FILL
    }
    private val faceEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(196, 201, 205)
        style = Paint.Style.STROKE
        strokeWidth = 1.25f * d
    }
    private val scale = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(38, 34, 24)
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * d
        strokeCap = Paint.Cap.ROUND
    }
    private val red = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(190, 47, 42)
        style = Paint.Style.STROKE
        strokeWidth = 2.0f * d
        strokeCap = Paint.Cap.ROUND
    }
    private val needle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(24, 22, 18)
        style = Paint.Style.STROKE
        strokeWidth = 1.8f * d
        strokeCap = Paint.Cap.ROUND
    }
    private val hubFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(10, 10, 10)
        style = Paint.Style.FILL
    }
    private val hubRim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(174, 178, 180)
        style = Paint.Style.STROKE
        strokeWidth = 1.25f * d
    }
    private val screwFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(112, 116, 118)
        style = Paint.Style.FILL
    }
    private val screwHighlight = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(202, 205, 206)
        style = Paint.Style.STROKE
        strokeWidth = 1.15f * d
    }
    private val screwSlot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(50, 52, 53)
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * d
        strokeCap = Paint.Cap.ROUND
    }
    private val vuText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(48, 43, 29)
        textAlign = Paint.Align.CENTER
        textSize = 17f * d
        isFakeBoldText = true
    }
    private val numberText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(63, 56, 34)
        textAlign = Paint.Align.CENTER
        textSize = 8.5f * d
    }
    private val redNumberText = Paint(numberText).apply {
        color = Color.rgb(170, 47, 41)
    }
    private val channelText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(220, 220, 220)
        textAlign = Paint.Align.CENTER
        textSize = 13f * d
        isFakeBoldText = true
    }

    private var level = 0f

    /** No damping: the needle follows the supplied master channel level immediately. */
    fun setLevel(value: Float) {
        level = value.coerceIn(0f, 1f)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        if (width < 2 || height < 2) return

        val w = width.toFloat()
        val h = height.toFloat()
        val labelSpace = 22f * d
        val meterBottom = (h - labelSpace).coerceAtLeast(h * .72f)

        // The face is intentionally not a rectangle: rounded/elliptical top and
        // a deep central lower notch like a classic analog VU meter window.
        val left = 5f * d
        val right = w - 5f * d
        val top = 5f * d
        val bottom = meterBottom - 2f * d
        val cx = w * .5f
        val facePath = Path().apply {
            // Broad, softly rounded classic VU silhouette: domed top, full cheeks,
            // and the characteristic shallow centre cut-out from the reference meter.
            moveTo(left + 13f*d, bottom - 5f*d)
            cubicTo(left + 2f*d, bottom - 9f*d, left - 1f*d, top + 28f*d, left + 12f*d, top + 14f*d)
            cubicTo(left + 24f*d, top + 1f*d, w * .35f, top, cx, top)
            cubicTo(w * .65f, top, right - 24f*d, top + 1f*d, right - 12f*d, top + 14f*d)
            cubicTo(right + 1f*d, top + 28f*d, right - 2f*d, bottom - 9f*d, right - 13f*d, bottom - 5f*d)
            cubicTo(w * .78f, bottom + 1f*d, w * .69f, bottom + 1f*d, w * .62f, bottom - 10f*d)
            cubicTo(w * .57f, bottom - 18f*d, w * .43f, bottom - 18f*d, w * .38f, bottom - 10f*d)
            cubicTo(w * .31f, bottom + 1f*d, w * .22f, bottom + 1f*d, left + 13f*d, bottom - 5f*d)
            close()
        }
        c.drawPath(facePath, face)
        c.drawPath(facePath, faceEdge)

        val pivotY = bottom - 1f*d
        val radius = minOf(w * .43f, (bottom - top) * .70f)
        val start = Math.toRadians(205.0)
        val sweep = Math.toRadians(130.0)

        for (i in 0..12) {
            val f = i / 12f
            val a = start + sweep * f
            val outer = radius
            val inner = radius - (if (i % 2 == 0) 10f else 6f) * d
            val p = if (f >= .82f) red else scale
            c.drawLine(
                cx + cos(a).toFloat() * inner,
                pivotY + sin(a).toFloat() * inner,
                cx + cos(a).toFloat() * outer,
                pivotY + sin(a).toFloat() * outer,
                p
            )
        }

        // Sparse classic scale labels, with the positive peak side in red.
        val labels = arrayOf("20", "10", "7", "5", "3", "2", "1", "0", "1", "2", "3")
        for (i in labels.indices) {
            val f = i / (labels.size - 1f)
            val a = start + sweep * f
            val rr = radius - 19f*d
            val p = if (f >= .80f) redNumberText else numberText
            c.drawText(
                labels[i],
                cx + cos(a).toFloat() * rr,
                pivotY + sin(a).toFloat() * rr + 3f*d,
                p
            )
        }

        c.drawText("VU", cx, top + (bottom - top) * .64f, vuText)

        // Immediate-response needle (no attack/release damping and no peak hold).
        val angle = start + sweep * level
        val needleR = radius - 7f*d
        c.drawLine(
            cx,
            pivotY,
            cx + cos(angle).toFloat() * needleR,
            pivotY + sin(angle).toFloat() * needleR,
            if (level >= .82f) red else needle
        )
        c.drawCircle(cx, pivotY, 4.7f*d, hubFill)
        c.drawCircle(cx, pivotY, 4.7f*d, hubRim)

        // Dirty-silver hardware screws belong to the instrument/frame joints, not
        // under the VU scale.  Two slightly oversized heads sit at the lower
        // left/right mounting points of each physical meter bezel.
        val screwY = bottom - 2.5f*d
        val screwR = 6.8f*d
        val screwXs = floatArrayOf(left + 9.5f*d, right - 9.5f*d)
        for ((index, screwX) in screwXs.withIndex()) {
            c.drawCircle(screwX, screwY, screwR, screwFill)
            c.drawArc(screwX-screwR, screwY-screwR, screwX+screwR, screwY+screwR, 205f, 145f, false, screwHighlight)
            // Opposing slot angles keep the pair from looking stamped/copied.
            val tilt = if (index == 0) 1f else -1f
            c.drawLine(
                screwX-3.7f*d, screwY+1.2f*d*tilt,
                screwX+3.7f*d, screwY-1.2f*d*tilt,
                screwSlot
            )
        }

        val channel = tag?.toString().orEmpty()
        if (channel.isNotBlank()) {
            c.drawText(channel, cx, h - 2f*d, channelText)
        }
    }
}
