package com.terafon.pausemix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

class CrossSpectrumView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val density = resources.displayMetrics.density
    private val silver = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(210,214,219); strokeWidth = max(1f*density,1.3f); strokeCap = Paint.Cap.ROUND }
    private val gold = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(215,174,74); strokeWidth = max(1.2f*density,1.5f); strokeCap = Paint.Cap.ROUND }
    private var energy = 0f
    private var phase = 0f
    fun setEnergy(left: Float, right: Float, phaseValue: Float) { energy = max(left,right).coerceIn(0f,1f); phase=phaseValue; invalidate() }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas); if(width<=0||height<=0)return
        val baseline=height*0.88f; val maxH=height*0.78f
        val step=max(2.2f*density, 3f); val bars=(width/step).toInt().coerceAtLeast(1); val dx=width.toFloat()/bars
        for(i in 0 until bars){
            val x=(i+.5f)*dx
            val harmonic=0.38f+0.62f*abs(sin(phase+i*0.47f)).toFloat()
            val h=maxH*(0.08f+0.92f*energy*harmonic)
            silver.alpha=if(energy>.02f)205 else 65
            canvas.drawLine(x,baseline,x,baseline-h,silver)
            if(h>5*density){ val peakY=baseline-h; canvas.drawLine(x,peakY,x,(peakY+3*density).coerceAtMost(baseline),gold) }
        }
    }
}
