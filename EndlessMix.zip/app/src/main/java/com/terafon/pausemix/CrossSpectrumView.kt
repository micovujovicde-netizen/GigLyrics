package com.terafon.pausemix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

class CrossSpectrumView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val density = resources.displayMetrics.density
    private val silver = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(205, 210, 216)
        strokeWidth = max(0.75f * density, 1f)
        strokeCap = Paint.Cap.BUTT
    }
    private val gold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(215, 174, 74)
        strokeWidth = max(0.9f * density, 1.1f)
        strokeCap = Paint.Cap.ROUND
    }
    private var energy = 0f
    private var phase = 0f

    fun setEnergy(left: Float, right: Float, phaseValue: Float) {
        energy = max(left, right).coerceIn(0f, 1f)
        phase = phaseValue
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        // Compact, waveform-like analyzer around the crossfader line rather than a full-height fence.
        val centerY = height * 0.50f
        val maxHalfHeight = height * 0.27f
        val step = max(13.4f * density, 16.0f)
        val bars = (width / step).toInt().coerceAtLeast(1)
        val dx = width.toFloat() / bars
        val live = energy.coerceIn(0f, 1f)

        for (i in 0 until bars) {
            val x = (i + 0.5f) * dx
            // Layered harmonics create irregular waveform-like movement; neighboring bars differ
            // naturally instead of forming the old uniform comb/fence.
            val a = abs(sin(phase * 1.37f + i * 0.41f)).toFloat()
            val b = abs(sin(phase * 0.73f + i * 0.173f + 1.7f)).toFloat()
            val c = abs(sin(phase * 2.11f + i * 0.067f + 0.4f)).toFloat()
            val shape = (0.12f + 0.50f * a + 0.25f * b + 0.13f * c).coerceIn(0f, 1f)
            val activity = if (live > 0.02f) (0.18f + 0.82f * live) else 0.05f
            val halfH = maxHalfHeight * activity * shape

            silver.alpha = if (live > 0.02f) 180 else 48
            canvas.drawLine(x, centerY - halfH, x, centerY + halfH, silver)

            // Gold is only a restrained true peak cap, not a stripe on every tall needle.
            if (live > 0.05f && shape > 0.72f) {
                gold.alpha = (120 + 110 * live).toInt().coerceIn(120, 230)
                val cap = (1.5f + 1.5f * live) * density
                canvas.drawLine(x, centerY - halfH, x, centerY - halfH + cap, gold)
            }
        }
    }
}
