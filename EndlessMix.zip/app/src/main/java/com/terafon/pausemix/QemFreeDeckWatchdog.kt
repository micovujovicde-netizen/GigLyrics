package com.terafon.pausemix

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Small continuity helper for QEM FREE-deck refill monitoring.
 *
 * It does not know about ExoPlayer, discovery policy, filters, BPM, Fonoteka or transitions.
 * MixerActivity publishes a read-only snapshot and the watchdog only asks for NEXT again while
 * the same physical deck is still genuinely FREE. One watchdog job exists per physical deck,
 * so stale transition-era checks cannot leak into a later ownership cycle.
 */
internal class QemFreeDeckWatchdog(
    private val scope: CoroutineScope,
    private val snapshot: (isA: Boolean) -> Snapshot,
    private val requestNext: (isA: Boolean) -> Unit,
    private val restartStalledDiscovery: (isA: Boolean, elapsedMs: Long) -> Unit,
    private val log: (String) -> Unit,
) {
    data class Snapshot(
        val endlessActive: Boolean,
        val autoEnabled: Boolean,
        val deckFree: Boolean,
        val deckPlaying: Boolean,
        val qemQueued: Boolean,
        val discoveryActive: Boolean,
    )

    private var jobA: Job? = null
    private var jobB: Job? = null

    fun start(isA: Boolean) {
        stop(isA)
        val job = scope.launch {
            var elapsedMs = 0L
            var waitMs = 2_500L
            while (true) {
                delay(waitMs)
                elapsedMs += waitMs
                val s = snapshot(isA)
                if (!s.endlessActive || !s.autoEnabled || !s.deckFree || s.deckPlaying) break

                log(
                    "FREE_DECK_REFILL_RECHECK target=${if (isA) "A" else "B"} " +
                        "afterMs=$elapsedMs qemQueued=${s.qemQueued} discovery=${s.discoveryActive}"
                )
                // First discovery pass stays STRICT. If the same physical deck is still FREE
                // at 10 s, promote exactly once to the RELAXED continuity lane. After that, do
                // not kill a healthy RELAXED attempt every 10 s: let its 12/14 s search budget
                // finish. The existing 18 s discovery-liveness guard remains the stall breaker.
                // REGION remains hard; only backstage selection breadth changes. A/B are untouched.
                if (elapsedMs == 10_000L) {
                    restartStalledDiscovery(isA, elapsedMs)
                } else {
                    requestNext(isA)
                }

                // Preserve the observation cadence: 2.5s, 10s total, then every 10s while this
                // exact deck remains FREE. Later checks ask NEXT again but do not forcibly restart
                // RELAXED discovery; requestNext/ensureQemDiscoveryLiveness owns the 18 s stall rule.
                waitMs = if (elapsedMs < 10_000L) 7_500L else 10_000L
            }
        }
        if (isA) jobA = job else jobB = job
        job.invokeOnCompletion {
            if (isA && jobA === job) jobA = null
            if (!isA && jobB === job) jobB = null
        }
    }

    fun stop(isA: Boolean) {
        if (isA) {
            jobA?.cancel()
            jobA = null
        } else {
            jobB?.cancel()
            jobB = null
        }
    }

    fun stopAll() {
        stop(true)
        stop(false)
    }
}
