val githubRepository = System.getenv("GITHUB_REPOSITORY").orEmpty()
val githubBranch = System.getenv("GITHUB_REF_NAME").orEmpty().ifBlank { "main" }
val fonotekaManifestUrl = if (githubRepository.isNotBlank())
    "https://raw.githubusercontent.com/$githubRepository/$githubBranch/fonoteka_manifest.json"
else ""
val engineRulesManifestUrl = if (githubRepository.isNotBlank())
    "https://raw.githubusercontent.com/$githubRepository/$githubBranch/engine_rules_manifest.json"
else ""

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.terafon.pausemix"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.terafon.endlessmix"
        minSdk = 26
        targetSdk = 35
        versionCode = 28
        versionName = "4.5"
        buildConfigField("String", "FONOTEKA_MANIFEST_URL", "\"${fonotekaManifestUrl}\"")
        buildConfigField("String", "ENGINE_RULES_MANIFEST_URL", "\"${engineRulesManifestUrl}\"")
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.4.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")

    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-common:1.5.1")

    // Search + stream extraction layer. Update only this version when YouTube changes.
    implementation("com.github.TeamNewPipe:NewPipeExtractor:${property("NEWPIPE_VERSION")}")

    implementation("com.squareup.okhttp3:okhttp:5.3.2")
}

// Fonoteka build-time combiner. On GitHub Actions it enriches the concrete
// Artist -> Song catalog BEFORE Android packages assets. Playback never runs this job.
val fonotekaEnrich by tasks.registering(Exec::class) {
    group = "fonoteka"
    description = "Expand Fonoteka with concrete songs/styles and YouTube view ranking before APK build"
    workingDir = rootProject.projectDir
    onlyIf { System.getenv("GITHUB_ACTIONS").equals("true", ignoreCase = true) }
    commandLine(
        "bash", "-lc",
        "python3 -m pip install --user -q yt-dlp && " +
            "python3 tools/fonoteka_combiner.py --input fonoteka.json --asset app/src/main/assets/fonoteka.json"
    )
}

tasks.named("preBuild") {
    dependsOn(fonotekaEnrich)
}
