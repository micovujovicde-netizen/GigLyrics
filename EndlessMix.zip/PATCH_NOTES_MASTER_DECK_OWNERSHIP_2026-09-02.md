# EndlessMix — Master Deck Ownership patch — 2026-09-02

Applied after Unified BB review.

## One key
A/B content is writable only when the target is truly FREE, or when the exact same LOADING_NEXT owner is completing its own preparation. `!isPlaying` alone is not permission.

## Changes
- Added centralized `mayWritePhysicalDeck()` firewall.
- `refreshDecks()` must pass the firewall before stop/clear/prepare.
- Late resolver commits must pass the firewall.
- Automatic `loadEndlessTrackIntoDeck()` claim and async commit must pass the firewall.
- QEM atomic swap may no longer replace READY_NEXT/committed/transition decks; target must be FREE.
- Physical A/B F-BPM fallback is now cache-read-only. Cache miss skips local decoder/FFT work.
- Song hard-ban is now current-mix lifetime: once actually played, that canonical song cannot return in the same mix.
- Artist hard-ban remains 5 played positions and now also checks the whole dirty YouTube title/uploader for a recent canonical artist name, preventing prefix junk from hiding the artist.
- `beginPersistentMix()` now starts a fresh current-mix song set while retaining persistent artist-position history.

## Intentionally unchanged
- First ONE SONG cold-start direct load path.
- A/B playback/crossfade timing.
- QEM/BASIC discovery engines beyond the ownership gate.
- Region/style/decade customs already present in the discovery path.
- UI/layout.
