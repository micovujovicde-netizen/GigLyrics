# EndlessMix — Deck Z World Voice Zones — 2026-08-31

- Deck Z now respects the Android TTS engine's currently selected/preferred voice when that voice belongs to the requested linguistic zone.
- Added worldwide linguistic voice-zone fallback chains rather than rigid country silos.
- BCS is one shared pool for Bosnia and Herzegovina, Montenegro, Croatia and Serbia.
- Expanded same-language/accent pools for major world languages (English, Spanish, Portuguese, French, German, Arabic, Chinese, South Asian, Southeast Asian, African and European languages).
- Unrelated languages are never grouped just because countries are geographically close.
- English remains a last-resort fallback.
- No A/B playback, discovery, transition, BORDER, BPM or Fonoteka behavior changed.
- Master Key updated: custom YouTube sync is explicitly retired; default YouTube timing + spinner remains.
