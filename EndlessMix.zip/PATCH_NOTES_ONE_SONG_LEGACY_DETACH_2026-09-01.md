# ONE SONG — legacy detach while playback continues

- The first selected song remains sacred and starts immediately.
- After playback is live, ONE SONG quietly invalidates/cancels only disposable legacy QEM/Quick backstage state.
- Cleanup does not touch A/B media, player state, crossfader, current ONE SONG discovery generation, persistent repeat history, or current canonical identity rules.
- Legacy QEM queued candidates, handoff jobs, passive C/D shelves, old filter fingerprint, artist pool and candidate stamps are detached so they cannot leak into the new session.
- BB markers: `ONE_SONG_LEGACY_DETACH_START` and `ONE_SONG_LEGACY_DETACH_DONE`.
