#!/usr/bin/env python3
"""EndlessMix build-time Fonoteka combiner.

Purpose:
  * Expand artist registry into concrete song identities before APK assembly.
  * Attach song-level style + era from concrete iTunes track metadata.
  * Optionally enrich exact song identities with YouTube view counts via yt-dlp.
  * Preserve existing LOVE/PARTY pen membership and existing manually curated fields.

This tool is intentionally build-time only. The Android playback process never runs it.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import datetime as dt
import json
import os
import re
import subprocess
import sys
import time
import unicodedata
import urllib.parse
import urllib.request
from pathlib import Path

UA = "EndlessMix-FonotekaCombiner/1.0 (+GitHub Actions build)"
ITUNES = "https://itunes.apple.com/search"

STYLE_MAP = {
    "pop": ["POP"],
    "rock": ["ROCK"],
    "alternative": ["ROCK"],
    "indie rock": ["ROCK"],
    "metal": ["ROCK"],
    "punk": ["ROCK"],
    "country": ["COUNTRY"],
    "folk": ["FOLK"],
    "singer/songwriter": ["FOLK"],
    "dance": ["DANCE"],
    "electronic": ["DANCE"],
    "house": ["DANCE"],
    "techno": ["DANCE"],
    "hip-hop/rap": ["HIP_HOP", "RAP"],
    "hip hop": ["HIP_HOP"],
    "rap": ["RAP"],
    "reggae": ["REGGAE_CARIBBEAN"],
    "ska": ["REGGAE_CARIBBEAN"],
    "jazz": ["JAZZ"],
    "blues": ["BLUES"],
    "soul": ["SOUL"],
    "r&b/soul": ["RNB", "SOUL"],
    "r&b": ["RNB"],
    "latin": ["WORLD"],
    "world": ["WORLD"],
}

BAD_YT = {
    "reaction", "karaoke", "tutorial", "nightcore", "sped up", "slowed",
    "8d audio", "cover by", "instrumental remake", "lyrics translation"
}


def canon(s: str) -> str:
    s = unicodedata.normalize("NFKD", s or "")
    s = "".join(c for c in s if not unicodedata.combining(c)).lower()
    s = s.replace("đ", "dj")
    s = re.sub(r"\([^)]*(official|video|audio|lyrics|lyric|hd|4k)[^)]*\)", " ", s)
    s = re.sub(r"\[[^]]*(official|video|audio|lyrics|lyric|hd|4k)[^]]*\]", " ", s)
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def tokens(s: str) -> set[str]:
    return {t for t in canon(s).split() if len(t) > 1}


def artist_match(wanted: str, got: str) -> bool:
    a, b = canon(wanted), canon(got)
    if not a or not b:
        return False
    if a == b:
        return True
    # collaborations are accepted only when the requested artist is a full credit component
    parts = [canon(x) for x in re.split(r"\b(?:feat\.?|ft\.?|featuring|with|x|and)\b|[&,/]", got, flags=re.I)]
    return a in parts


def style_from_genre(genre: str) -> list[str]:
    g = canon(genre)
    for key, vals in STYLE_MAP.items():
        if canon(key) in g:
            return vals[:]
    return []


def era_from_date(value: str) -> str:
    m = re.match(r"(\d{4})", value or "")
    if not m:
        return ""
    y = int(m.group(1))
    if y < 1970:
        return "EVERGREEN"
    if y < 1980: return "1970s"
    if y < 1990: return "1980s"
    if y < 2000: return "1990s"
    if y < 2010: return "2000s"
    if y < 2020: return "2010s"
    return "2020s"


def http_json(url: str, timeout: int = 20):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def fetch_itunes_tracks(artist: str, limit: int = 50, retries: int = 3) -> list[dict]:
    params = urllib.parse.urlencode({
        "term": artist,
        "entity": "song",
        "attribute": "artistTerm",
        "limit": str(limit),
    })
    url = f"{ITUNES}?{params}"
    last = None
    for n in range(retries):
        try:
            data = http_json(url)
            out = []
            for r in data.get("results", []):
                if not artist_match(artist, str(r.get("artistName", ""))):
                    continue
                title = str(r.get("trackName", "")).strip()
                if not title:
                    continue
                out.append({
                    "title": title,
                    "styles": style_from_genre(str(r.get("primaryGenreName", ""))),
                    "style_status": "TRACK_METADATA" if r.get("primaryGenreName") else "UNRESOLVED",
                    "style_evidence": {
                        "source": "iTunes Search API",
                        "primaryGenreName": r.get("primaryGenreName") or "",
                        "trackId": r.get("trackId"),
                    },
                    "era": era_from_date(str(r.get("releaseDate", ""))),
                    "release_date": str(r.get("releaseDate", ""))[:10],
                    "collection": str(r.get("collectionName", "")),
                })
            # de-dupe versions by canonical title while preserving first concrete result
            seen, uniq = set(), []
            for x in out:
                k = canon(x["title"])
                if k and k not in seen:
                    seen.add(k); uniq.append(x)
            return uniq
        except Exception as e:
            last = e
            time.sleep(1.5 * (n + 1))
    print(f"WARN iTunes {artist}: {last}", file=sys.stderr)
    return []


def merge_song(existing: dict | None, incoming: dict) -> dict:
    if existing is None:
        existing = {
            "title": incoming["title"],
            "styles": [],
            "style_status": "UNRESOLVED",
            "era": "",
            "pens": [],
            "youtube": {
                "status": "PENDING_EXACT_MATCH", "video_id": None, "url": None,
                "view_count": None, "matched_title": None, "matched_channel": None,
                "match_confidence": None, "captured_on": None,
            },
            "youtube_rank_by_views": None,
        }
    # Concrete track metadata may fill blanks but never removes manual/pen data.
    if not existing.get("styles") and incoming.get("styles"):
        existing["styles"] = incoming["styles"]
        existing["style_status"] = incoming.get("style_status", "TRACK_METADATA")
        existing["style_evidence"] = incoming.get("style_evidence", {})
    if not existing.get("era") and incoming.get("era"):
        existing["era"] = incoming["era"]
    if incoming.get("release_date") and not existing.get("release_date"):
        existing["release_date"] = incoming["release_date"]
    if incoming.get("collection") and not existing.get("collection"):
        existing["collection"] = incoming["collection"]
    return existing


def yt_candidates(query: str, n: int = 12) -> list[dict]:
    cmd = [sys.executable, "-m", "yt_dlp", "--dump-single-json", "--flat-playlist",
           "--no-warnings", f"ytsearch{n}:{query}"]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=45)
        if p.returncode != 0:
            return []
        d = json.loads(p.stdout)
        return d.get("entries") or []
    except Exception:
        return []


def score_yt(artist: str, song: str, e: dict) -> float:
    title = str(e.get("title") or "")
    low = canon(title)
    if any(canon(x) in low for x in BAD_YT):
        return -1.0
    st, at = tokens(song), tokens(artist)
    tt = tokens(title)
    if not st:
        return -1.0
    song_cov = len(st & tt) / len(st)
    art_cov = len(at & tt) / max(1, len(at))
    exact_phrase = 0.25 if canon(song) in low else 0.0
    official = 0.08 if any(x in low for x in ["official", "vevo", "topic", "audio"]) else 0.0
    return 0.68 * song_cov + 0.24 * art_cov + exact_phrase + official


def enrich_artist_youtube(artist: str, songs: list[dict]) -> None:
    # One YouTube search per artist, then match only exact concrete song identities.
    entries = yt_candidates(f'"{artist}" official music', n=20)
    if not entries:
        return
    date = dt.datetime.now(dt.timezone.utc).date().isoformat()
    for song in songs:
        best, best_score = None, -1.0
        for e in entries:
            s = score_yt(artist, str(song.get("title", "")), e)
            if s > best_score:
                best_score, best = s, e
        if best is None or best_score < 0.78:
            continue
        vc = best.get("view_count")
        # flat search does not always expose view_count; leave null rather than invent it.
        if vc is None:
            continue
        try: vc = int(vc)
        except Exception: continue
        vid = best.get("id")
        song["youtube"] = {
            "status": "EXACT_MATCH",
            "video_id": vid,
            "url": f"https://www.youtube.com/watch?v={vid}" if vid else None,
            "view_count": vc,
            "matched_title": best.get("title"),
            "matched_channel": best.get("channel") or best.get("uploader"),
            "match_confidence": round(best_score, 3),
            "captured_on": date,
        }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="fonoteka.json")
    ap.add_argument("--asset", default="app/src/main/assets/fonoteka.json")
    ap.add_argument("--songs-per-artist", type=int, default=int(os.getenv("FONOTEKA_SONGS_PER_ARTIST", "30")))
    ap.add_argument("--workers", type=int, default=int(os.getenv("FONOTEKA_WORKERS", "8")))
    ap.add_argument("--youtube", action="store_true", default=os.getenv("FONOTEKA_YOUTUBE", "1") != "0")
    ap.add_argument("--youtube-artists", type=int, default=int(os.getenv("FONOTEKA_YOUTUBE_ARTISTS", "250")))
    args = ap.parse_args()

    src = Path(args.input)
    root = json.loads(src.read_text(encoding="utf-8"))
    artists: dict = root.get("artists") or {}
    queue = [(aid, a.get("name", aid)) for aid, a in artists.items()]
    print(f"FONOTEKA COMBINER: {len(queue)} artists; iTunes song pass for all artists")

    results: dict[str, list[dict]] = {}
    with cf.ThreadPoolExecutor(max_workers=max(1, args.workers)) as ex:
        futs = {ex.submit(fetch_itunes_tracks, name, max(1, args.songs_per_artist)): (aid, name) for aid, name in queue}
        done = 0
        for fut in cf.as_completed(futs):
            aid, name = futs[fut]
            try: tracks = fut.result()
            except Exception as e:
                print(f"WARN {name}: {e}", file=sys.stderr); tracks = []
            results[aid] = tracks[:args.songs_per_artist]
            done += 1
            if done % 100 == 0 or done == len(queue):
                print(f"  metadata {done}/{len(queue)}")

    added = 0
    artists_with_songs = 0
    for aid, name in queue:
        a = artists[aid]
        old = a.get("songs") or []
        by_key = {canon(str(s.get("title") or s.get("song") or "")): s for s in old if canon(str(s.get("title") or s.get("song") or ""))}
        before = len(by_key)
        for inc in results.get(aid, []):
            k = canon(inc["title"])
            by_key[k] = merge_song(by_key.get(k), inc)
        merged = list(by_key.values())
        if merged:
            a["songs"] = merged
            artists_with_songs += 1
        added += max(0, len(merged) - before)

    # YouTube is intentionally bounded during normal APK builds: song identity/style coverage
    # is the hard prerequisite; YT views are a ranking enrichment and can grow build by build.
    if args.youtube:
        yt_queue = sorted(
            [(aid, artists[aid].get("name", aid)) for aid, _ in queue if artists[aid].get("songs")],
            key=lambda x: (0 if any((s.get("youtube") or {}).get("view_count") is None for s in artists[x[0]].get("songs", [])) else 1, x[1].lower())
        )[:max(0, args.youtube_artists)]
        print(f"YouTube exact-match ranking pass: {len(yt_queue)} artists")
        for i, (aid, name) in enumerate(yt_queue, 1):
            enrich_artist_youtube(name, artists[aid]["songs"])
            if i % 25 == 0 or i == len(yt_queue):
                print(f"  youtube {i}/{len(yt_queue)}")

    # Global competition rank by actual captured views only.
    ranked = []
    for aid, a in artists.items():
        for s in a.get("songs", []):
            vc = (s.get("youtube") or {}).get("view_count")
            if isinstance(vc, int) and vc >= 0:
                ranked.append((vc, aid, s))
    ranked.sort(key=lambda x: -x[0])
    rank, prev, seen = 0, None, 0
    for vc, aid, s in ranked:
        seen += 1
        if vc != prev:
            rank = seen; prev = vc
        s["youtube_rank_by_views"] = rank

    root["schema_version"] = str(root.get("schema_version", "2.7"))
    root["build_time_enrichment"] = {
        "version": "fonoteka-combiner-1.0",
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "artist_count": len(artists),
        "artists_with_concrete_songs": artists_with_songs,
        "new_songs_added": added,
        "concrete_song_count": sum(len(a.get("songs", [])) for a in artists.values()),
        "youtube_resolved_song_count": len(ranked),
        "selection_philosophy": "Fonoteka chooses exact Artist -> Song first; YouTube only resolves/ranks that identity.",
    }
    root.setdefault("design_rules", {})["song_catalogs_are_not_stored"] = False
    root["design_rules"]["song_level_style_is_authoritative_when_present"] = True

    text = json.dumps(root, ensure_ascii=False, indent=2) + "\n"
    src.write_text(text, encoding="utf-8")
    asset = Path(args.asset); asset.parent.mkdir(parents=True, exist_ok=True); asset.write_text(text, encoding="utf-8")
    print("FONOTEKA COMBINER DONE")
    print(json.dumps(root["build_time_enrichment"], ensure_ascii=False, indent=2))
    if artists_with_songs == 0:
        print("ERROR: no artist received concrete songs", file=sys.stderr)
        return 3
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
