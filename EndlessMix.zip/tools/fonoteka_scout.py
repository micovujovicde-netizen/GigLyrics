#!/usr/bin/env python3
import json, re, sys, unicodedata, urllib.request
from collections import defaultdict
from pathlib import Path
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[1]

def norm(s):
    s=unicodedata.normalize('NFKD', s or '').encode('ascii','ignore').decode().lower()
    s=s.replace('đ','dj')
    return re.sub(r'[^a-z0-9]+',' ',s).strip()

def load(name): return json.loads((ROOT/name).read_text(encoding='utf-8'))

def fetch(url):
    req=urllib.request.Request(url, headers={'User-Agent':'EndlessMix-Scout/1.0'})
    with urllib.request.urlopen(req, timeout=12) as r:
        return json.loads(r.read().decode('utf-8'))

def map_style(genres):
    text=' '.join(genres).lower()
    if 'hip-hop' in text or 'hip hop' in text: return ['HIP_HOP']
    if 'rap' in text: return ['RAP']
    if 'r&b' in text or 'rnb' in text: return ['RNB']
    if 'rock' in text: return ['ROCK']
    if 'pop' in text: return ['POP']
    if 'dance' in text or 'electronic' in text: return ['DANCE']
    if 'reggae' in text or 'caribbean' in text: return ['REGGAE_CARIBBEAN']
    if 'jazz' in text: return ['JAZZ']
    if 'blues' in text: return ['BLUES']
    if 'soul' in text: return ['SOUL']
    if 'country' in text or 'folk' in text: return ['FOLK_COUNTRY']
    if 'world' in text: return ['WORLD']
    return []

def era_for(date):
    m=re.match(r'(\d{4})', date or '')
    if not m: return None
    y=int(m.group(1))
    if y<1970:return 'EVERGREEN'
    return f'{(y//10)*10}s'

def main():
    fono=load('fonoteka.json'); cfg=load('scout_sources.json')
    known=set()
    for a in fono.get('artists',{}).values():
        known.add(norm(a.get('name','')))
        for alias in a.get('aliases',[]): known.add(norm(alias))
    seen=defaultdict(lambda:{'songs':set(),'countries':set(),'genres':set(),'best_rank':999,'dates':set()})
    errors=[]
    limit=int(cfg.get('limit',100))
    for country,code in cfg.get('countries',{}).items():
        url=f'https://rss.applemarketingtools.com/api/v2/{code}/music/most-played/{limit}/songs.json'
        try: data=fetch(url)
        except Exception as e:
            errors.append({'country':country,'error':type(e).__name__}); continue
        for rank,item in enumerate(data.get('feed',{}).get('results',[]),1):
            artist=(item.get('artistName') or '').strip()
            if not artist or norm(artist) in known: continue
            x=seen[artist]
            if item.get('name'): x['songs'].add(item['name'])
            x['countries'].add(country); x['best_rank']=min(x['best_rank'],rank)
            if item.get('releaseDate'): x['dates'].add(item['releaseDate'])
            for g in item.get('genres') or []:
                if isinstance(g,dict) and g.get('name'): x['genres'].add(g['name'])
    candidates=[]
    for artist,x in seen.items():
        styles=map_style(sorted(x['genres']))
        eras=sorted({e for d in x['dates'] if (e:=era_for(d))})
        song_count=len(x['songs']); country_count=len(x['countries'])
        evidence= song_count*3 + min(country_count,5)*2 + (3 if x['best_rank']<=20 else 1 if x['best_rank']<=50 else 0)
        status='ELIGIBLE_FOR_REVIEW' if styles and song_count>=2 and evidence>=9 else 'WATCH'
        candidates.append({
            'artist':artist,'status':status,'evidence_score':evidence,'chart_countries':sorted(x['countries']),
            'chart_song_count':song_count,'sample_songs':sorted(x['songs'])[:8],'source_genres':sorted(x['genres']),
            'suggested_styles':styles,'suggested_eras':eras,'best_chart_rank':x['best_rank'],
            'hard_gate_note':'Discovery only. REGION/STYLE/ERA/catalog-depth and anti-viral gates must pass before ACTIVE FONOTEKA.'
        })
    candidates.sort(key=lambda c:(c['status']!='ELIGIBLE_FOR_REVIEW',-c['evidence_score'],c['best_chart_rank'],norm(c['artist'])))
    out={
      'schema_version':'1.0','status':'SCOUT_INBOX','updated_at':datetime.now(timezone.utc).isoformat(),
      'source':'public country top-song feeds','active_fonoteka_modified':False,
      'rules':['chart/trending is discovery only','hard REGION gate','hard STYLE gate','hard ERA gate','catalog depth required','reject one-hit/viral-only evidence','no genre drift','questionable candidates remain pending'],
      'source_errors':errors,'candidates':candidates[:500]
    }
    (ROOT/'scout_inbox.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f"Scout candidates: {len(candidates)}, source errors: {len(errors)}")

if __name__=='__main__': main()
