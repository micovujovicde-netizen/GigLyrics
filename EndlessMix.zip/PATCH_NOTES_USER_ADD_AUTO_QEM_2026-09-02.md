# USER ADD -> AUTO QEM — 2026-09-02

- USER ADD TO MIX remains highest priority and stays protected by `endlessManualUrls`.
- The selected user track becomes the QEM anchor only when that exact URL becomes ACTIVE.
- Its artist/title/search hint are used to infer the old QEM virtual REGION/COUNTRY/STYLE/ERA selections.
- Collaboration names are split so e.g. `Tom Jones & Mousse T` can match an existing `Tom Jones` fonoteka identity.
- After virtual selections are filled, the app calls the same old `startQuickEndlessMix()` ENTER path.
- GIVE ME 1 SONG uses the same protection + auto-QEM arming path.
- New BB marker: `ONE_SONG_QEM_AUTO_ENTER`.
