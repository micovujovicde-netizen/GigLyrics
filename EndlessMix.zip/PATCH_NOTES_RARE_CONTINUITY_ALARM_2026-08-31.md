# Rare continuity alarm — 2026-08-31

- Keeps one Safety Belt; no new watchdog/coroutine/discovery engine.
- Normal dead-air recovery remains first and gets a 12-second hard-failure window.
- Only after 12 seconds of confirmed A+B silence may the existing session-history replay airbag fire.
- `discovery=true` is not allowed to veto the airbag after hard failure.
- Near-end <=15s / stuck-load <=5s behavior remains.
- Shared replay helper owns the emergency claim; late normal QEM results still park via existing ownership rules.
- A/B fade/transition timing is untouched.
