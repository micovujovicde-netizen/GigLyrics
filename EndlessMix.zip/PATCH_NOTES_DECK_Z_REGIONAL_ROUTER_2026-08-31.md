# Deck Z regional TTS routing experiment — 2026-08-31

Added a playback-isolated Deck Z language/voice routing layer.

- `DeckZVoiceRouter.kt`: chooses the best available Android TTS voice using country/region-aware fallback chains and quality/reliability scoring.
- `DeckZAnnouncementRouter.kt`: keeps spoken template language paired with the requested TTS locale.
- `MixerActivity.kt`: country is now the strongest locale signal; region/track scene remains fallback.
- `DeckZController.kt`: delegates voice selection to the router; still has no access to A/B players.
- No changes to QEM/BASIC discovery, transition timing, A/B state ownership, filters, history, or crossfade behavior.
- External/cloud TTS providers are intentionally NOT added in this experiment; the router uses voices already exposed by the Android TTS engine.
