# Deck J — ghost watchdog removed

The explicit QemFreeDeckWatchdog was already deleted, but one old high-frequency behavior remained
inside `enforceSupremeNoEmptyLaw()`.

Changes:
- A physically EMPTY opposite deck no longer calls `discoverQemCandidate()` every ~100 ms.
- If Deck J discovery or J transport is already active, the EMPTY guard is passive and returns.
- A new discovery request is made only when J is genuinely idle.
- `discoverQemCandidate()` re-entry while a J job is active is silent.
- Dead-air ARM logging is rate-limited to once per 5 seconds.
- No serial restart, no lane promotion, no cancellation, and no A/B touch was added.
- Deck J remains the only QEM authority; passive C/D remains transport-only.
