# Mićo Vujović – Šizofrenija curator placement

- Added `mico_vujovic` to `EX_YU -> DANCE -> 2000s`.
- Explicit curator approval recorded for **Mićo Vujović – Šizofrenija** as `EX_YU / DANCE / 2000s`.
- Added `DANCE` to the existing Mićo Vujović manual promotion styles.
- No A/B playback, transition, BPM, BORDER, Deck Z, or discovery engine logic changed.
