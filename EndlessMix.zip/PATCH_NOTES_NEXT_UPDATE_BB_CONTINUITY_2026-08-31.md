# EndlessMix — BB continuity update — 2026-08-31

Implemented from unified-BB evidence:
- QEM discovery liveness timeout/restart remains backstage-only.
- Dead-air discovery completion now honors `endlessRecoveryDeck` when neither physical player is running, so the found candidate goes straight to the expected recovery deck instead of being parked.
- Added `DEAD_AIR_CANDIDATE_HANDOFF` diagnostic.
- Existing dead-air ARM logging is throttled and stall restart is explicitly logged.

Locked for the same update line / follow-up verification:
- QEM RESET must be transactional rollback of an uncommitted ENTER/START NEW MIX attempt.
- YouTube popup startup spinner must remain visible until actual video playback begins.
- Deck Z correct regional request + engine_default is treated as installed-voice/provider availability, not locale wiring.

Sacred boundary: no fix in this package may stop/seek/restart the ACTIVE A/B transport to solve discovery.
