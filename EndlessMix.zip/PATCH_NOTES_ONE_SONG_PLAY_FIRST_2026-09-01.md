# ONE SONG — PLAY FIRST

- First selected song is law: playback/adoption starts before Deck J metadata work.
- Deck J seed metadata moved off the playback/UI path to Dispatchers.IO after a 3 s grace period.
- ONE SONG discovery waits for the identity lock instead of racing the first deck.
- REGION/COUNTRY + STYLE remain hard identity walls; DECADE is locked from seed metadata/title and injected into discovery queries.
- Removed Deck J metadata calls from the hot candidate ranking loop.
- BPM/ENERGY are enrichment after identity admission and may never block first-song playback.
- Physical A/B receive no candidate churn from metadata analysis; discovery starts only after ONE_SONG_LOCK_READY.
