# Deck J — watchdog removed

- Removed QemFreeDeckWatchdog completely from the QEM/J chain.
- No 2.5/10/20/30 second FREE-deck timer loop.
- No timer-driven STRICT -> RELAXED promotion.
- No QEM_DISCOVERY_STALL_RESTART.
- No watchdog cancellation/replacement of an active Deck J discovery serial.
- Deck J alone owns: STRICT -> LOCAL RELAXED -> candidate selection -> transport -> fallback.
- ensureQemDiscoveryLiveness is now passive: it only reports whether J discovery/transport is active.
- Dead-air recovery may ask NEXT PLEASE only when no J work is active; it cannot select, cancel, rerank or restart.
- A/B playback, Deck Z and manual ADD TO MIX rights are unchanged.
