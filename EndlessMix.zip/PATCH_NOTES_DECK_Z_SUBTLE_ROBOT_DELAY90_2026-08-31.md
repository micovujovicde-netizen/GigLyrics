# Deck Z subtle robot character + 10% shorter delay — 2026-08-31

- Deck Z only; A/B, MASTER, QEM, C/D, transitions and Safety Belt are untouched.
- Preserves the existing -1 dB Deck Z output gain and high-frequency lift.
- Adds a deliberately subtle robot/AI EQ contour: slight low-warmth trim and ~+1.8 dB speech-presence emphasis, while retaining the existing high shelf. This is designed to keep TTS intelligible rather than create an extreme toy/vocoder sound.
- BPM-derived Deck Z echo delay is reduced by exactly 10% (`DECK_Z_DELAY_SCALE = 0.90`). Clamp limits are reduced proportionally from 170–430 ms to 153–387 ms.
- Audio effects remain best-effort/fallback-safe; unsupported EQ/reverb paths cannot interrupt A/B playback.
- BB now identifies the voice contour as `character=subtle_robot` and logs `delayScale=0.90`.
