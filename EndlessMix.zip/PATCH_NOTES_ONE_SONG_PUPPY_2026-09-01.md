# GIVE ME 1 SONG — simple-start UX

- Removed the QEM filter drawer from all user-facing entry paths.
- Cold launch now opens one fullscreen popup: **GIVE ME 1 SONG**.
- User enters/searches one concrete song (voice supported), taps the correct result, and EndlessMix starts from that single seed.
- Lightweight seed-query cleanup removes common YouTube noise such as OFFICIAL VIDEO, LYRICS, HD, 4K, HQ, REMASTERED and VISUALIZER before search.
- Existing one-seed Endless engine remains the safe playback/discovery path; QEM internals are preserved only as legacy implementation so this UX change does not destabilize A/B continuity.
- The former QEM button is now **GIVE ME 1 SONG** when idle and **NEW MIX** while running.
- A later NEW MIX selection never interrupts the currently playing deck: the chosen song is prepared on the opposite deck and the shared Endless engine adopts the live owner.
