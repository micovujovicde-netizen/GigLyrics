# Unified Black Box — 5 minute report

- Added one `BLACK BOX · 5 MIN` button to the main mixer UI.
- Available while LOCKED or UNLOCKED.
- Merges PLAYBACK/QEM, Fonoteka, BPM, AIDJ and Deck Z diagnostics chronologically.
- Shows/copies only the last ~5 minutes, capped at 260 merged events.
- CLEAR ALL clears all four existing bounded recorders.
- Existing logging paths were reused; no new logging loop or playback work was introduced.
- No DJ behavior was intentionally changed.
