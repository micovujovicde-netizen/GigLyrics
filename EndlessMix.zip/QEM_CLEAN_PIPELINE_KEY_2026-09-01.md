# ENDLESSMIX — QEM CLEAN PIPELINE KEY
This is now a canonical architecture rule for EndlessMix.

### Sacred runtime path
`QEM UI filters -> DECK J local selection/metadata -> durable YouTube WATCH URL resolver/cache -> FREE A/B -> PLAY`

Nothing else is allowed to sit in the critical playback/NEXT/start path.

### A/B
- A/B are dumb, efficient physical playback machines only.
- They may load/play an already-prepared playable stream, crossfade/transition, expose state, and ask for NEXT.
- A/B never discover, rank, search, choose, BPM-analyze, energy-analyze, or repair candidate identity.
- Never touch/restart/seek/replace the currently ACTIVE deck because discovery is late.

### Deck J
- Deck J is the sole automatic QEM selection/admission/metadata authority.
- REGION / COUNTRY / STYLE / ERA / SLOW-MEDIUM-FAST are resolved locally against Deck J.
- BPM + ENERGY already present in Jurassic/Spotify metadata are primary truth for SLOW/MEDIUM/FAST.
- A selected speed band must filter Deck J before candidate transport.
- Missing BPM/ENERGY must NOT start an analyzer in the critical playback path.

### SLOW / MEDIUM / FAST
- These replace the old LOVE/slow-party and champagne/party buttons.
- They are universal musical-speed/energy lanes, independent from REGION / COUNTRY / STYLE / ERA.
- Use existing Deck J BPM + ENERGY metadata.
- Do not resurrect old PARTY/LOVE special discovery engines behind these buttons.

### Cold start / NEXT
- Local Deck J candidates are always attempted first and immediately.
- If a valid local J candidate has a cached durable YouTube WATCH URL, resolve it directly to a playable stream and hand it to the FREE A/B deck.
- Do not wait through serial legacy STRICT -> RELAXED -> supplier machinery merely because one speed/filter pool is empty.
- An empty local FAST/SLOW/MEDIUM pool is a metadata/supply condition, not permission to wake old critical-path workers.
- Continuity alarms may request NEXT; they may never select/rank/restart Deck J or clear a valid parked NEXT.

### Supplier/server rule
- Server/live search is a BACKGROUND SUPPLIER only.
- It may gradually enrich Deck J with missing/new tracks, metadata and durable validated YouTube WATCH URLs.
- Server response is never required before playback can continue when a local prepared candidate exists.
- Server never vetoes A/B, never owns NEXT, never participates in crossfade timing.
- No legacy supplier fallback is allowed to become the synchronous critical START/NEXT path.

### BPM / ENERGY rule
- Jurassic/Spotify/Deck J metadata is primary.
- Cloud BPM and local F BPM/energy analysis are removed from the QEM playback critical path.
- A 404 or missing BPM after A/B load must NOT trigger `BPM_F_ANALYZE_START` for normal QEM playback.
- Any optional metadata repair belongs to the low-priority basement enrichment worker only.
- Metadata repair may never delay PLAY, NEXT, handoff or transition.

### URL hydrator / basement worker
- URL hydration is low-CPU, low-priority background work only.
- It may run only while the hotel is calm: one ACTIVE deck + opposite READY_NEXT, no discovery/transport/handoff/crossfade emergency.
- Work in tiny bounded batches and yield immediately to playback/NEXT.
- Persist only validated durable YouTube WATCH URLs; never persist expiring googlevideo stream URLs.
- Exact artist + canonical track identity must be verified before caching.
- Hydration has zero song-selection or playback authority.
- Avoid repeatedly cycling over the same unresolved first batch; use cursor/rotation/skip-attempted behavior.

### Passive C/D
- C/D, if still present during transition/refactor, are passive parking shelves only.
- C/D have no search/ranking/analysis/selection authority and no fixed C->A / D->B ownership.
- They may hold already-approved surplus Deck J candidates only.
- Long-term clean target is no separate worker hierarchy between J and FREE A/B.

### ADD TO MIX and Deck Z
- Human ADD TO MIX remains highest insertion authority and sacred until actually played.
- Deck Z remains orthogonal speech/ducking only; it has no track-selection authority.
- Deck Z may alter only its duck scalar and voice output, never A/B ownership/track identity.

### Persistent device history
- Played song hard-ban: next 20 actually played tracks.
- Played artist hard-ban: next 5 actually played tracks.
- Device-local persistent history survives app restart.
- Search hits/rejected/preloaded-only candidates do not enter played history.

### Diagnostic meaning from BB 2026-09-01
Observed sequence:
- `DECK_J_LIGHTNING_POOL count=0`
- `DECK_J_TEMPO_POOL band=fast count=0`
- STRICT=0, RELAXED=0, then synchronous `DECK_J_SUPPLIER_FALLBACK`
- A/B resolved/prepared/played correctly once supplied.
- After load, cloud BPM 404 caused `BPM_F_ANALYZE_START` on both decks.

Conclusion locked:
- A/B transport is not the root problem in that trace.
- Remaining dinosaurs are synchronous supplier fallback and post-load cloud/F BPM analysis in the QEM critical path.
- Refactor target: `QEM -> J -> URL -> FREE A/B`, with enrichment only in the basement.

