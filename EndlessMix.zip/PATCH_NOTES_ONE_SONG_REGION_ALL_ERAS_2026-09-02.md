# ONE SONG auto-QEM widening

- Auto-QEM keeps the inferred REGION but removes COUNTRY restriction.
- Auto-QEM enables all decade/era buttons.
- ROCK is never allowed as a lone style: ROCK maps to POP_ROCK + DANCE.
- FOLK is protected: FOLK/POP_FOLK widens only to FOLK + POP_FOLK.
- The user-selected ACTIVE song is untouched; these rules affect future QEM discovery only.
