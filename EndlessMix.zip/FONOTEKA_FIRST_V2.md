# EndlessMix Fonoteka-first discovery

Runtime contract:
1. REGION / COUNTRY / STYLE / ERA determines eligible catalog artists/songs.
2. If concrete `artist.songs[]` data exists, QEM chooses a concrete Artist -> Song before web search.
3. LOVE reads only songs tagged `pens:["LOVE"]`; JUST A PARTY reads only `pens:["PARTY"]`.
4. YouTube/NewPipe search is an exact URL resolver only. A different song by the same artist is rejected.
5. Exact-song failure skips that catalog song; it never substitutes another title.
6. Generic QEM can use song-level `styles` / `era` when present. Older artist-only fonoteka remains backward compatible.
7. Playback chassis is unchanged: ACTIVE protection, READY_NEXT stickiness, anti-repeat and transition/dead-air safety stay outside catalog selection.

The embedded catalog has been seeded with the concrete LOVE/PARTY tracks whose artists already exist in the current app fonoteka. Song enrichment is additive; artist-only entries remain valid until enriched.
