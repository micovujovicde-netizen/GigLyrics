# Locked fix — Cloud Fonoteka network failures are non-fatal

Crash signature fixed: `java.net.SocketTimeoutException` escaping from `CloudFonotekaRepository.ensureTrack()` during background E/F enrichment.

Locked invariant:
- Cloud/Fonoteka enrichment never has authority to crash MixerActivity, QEM, playback, A/B, C/D, or transitions.
- `ensureTrack()` catches expected OkHttp/network `IOException` failures (including `SocketTimeoutException`), writes a `FONOTEKA_TRACK_NETWORK_ERROR` diagnostic through the existing black-box callback, and returns `false`.
- A final non-cancellation safety wall records `FONOTEKA_TRACK_ERROR` and also returns `false`.
- Coroutine cancellation is explicitly rethrown; cancellation semantics are not converted into a network failure.
- `fetchPage()` has the same non-fatal network safety wall for background artist-page enrichment and returns `null` on failure.
- Existing HTTP 503 backoff behavior is preserved.
