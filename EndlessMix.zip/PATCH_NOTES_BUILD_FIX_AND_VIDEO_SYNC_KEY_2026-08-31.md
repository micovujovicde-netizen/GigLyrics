# Build fix + Video Sync key — 2026-08-31

## Build fix
GitHub compile log showed one Kotlin syntax/type error in `MixerActivity.kt` inside the `QemFreeDeckWatchdog.Snapshot` named arguments.

Incorrect refactor artifact:
`qemEngine.queued = qemEngine.queued != null`

Correct named argument:
`qemQueued = qemEngine.queued != null`

This is wiring-only. It does not alter QEM discovery, watchdog timing, A/B playback, transition, BPM, Fonoteka or candidate policy.

## Video Sync key added to Master Key
A/B audio is the MASTER clock. On actual YouTube `PLAYING`, video may receive one video-only seek correction to the ACTIVE deck position. A/B is never changed for picture sync; no continuous sync loop.
