# Fonoteka app-side timing — 2026-08-30

- Increased the process-global Fonoteka/MusicBrainz request pace from 2.5 s to 4.5 s.
- Existing global `syncMutex` remains in place, so A/B/E/F Fonoteka calls from this app process are serialized.
- Existing 30 s backoff after HTTP 503 remains as a second safety layer.
- Playback/A/B state is untouched; this affects only low-priority Fonoteka network enrichment.
- Goal: prevent same-second request bursts at the source before they reach the Worker/MusicBrainz.
