# ONE SONG -> AUTO QEM (2026-09-02)

This build keeps the old cloudback QEM engine, but removes the manual QEM drawer from the user-facing path.

- QUICK ENDLESS MIX button is now **GIVE ME 1 SONG**.
- Cold launch opens the same one-song search popup used by the newer build.
- The selected song starts first; it is never rejected by QEM filters.
- The selected song automatically becomes the old QEM preset:
  - artist is resolved against the old fonoteka,
  - region/country/style are taken from the artist's strongest existing fonoteka lane,
  - an explicit year in the selected song title selects the matching era when available.
- After the chosen song is actually playing, the app calls the same `startQuickEndlessMix()` path as the old manual QEM ENTER button.
- The old QEM drawer remains internally available to the engine/bindings but is visually hidden from the user.
- If the selected artist cannot be mapped to the old fonoteka, the selected song keeps playing on the proven BASIC path rather than being stopped or replaced.

Black-box markers:
- `ONE_SONG_START`
- `ONE_SONG_QEM_PRESET`
- `ONE_SONG_QEM_SKIP`
