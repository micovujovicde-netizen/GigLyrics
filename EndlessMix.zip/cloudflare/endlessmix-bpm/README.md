# EndlessMix BPM Worker

Server-side BPM metadata cache for EndlessMix.

- Android sends artist/title keys plus display metadata.
- D1 is checked first.
- On a cache miss the Worker resolves track metadata from a server-side catalog source and stores BPM in D1.
- The tablet never decodes audio for PARTY BPM.
- Unknown BPM never blocks playback continuity.
- POST /api/v1/track remains protected by WRITE_TOKEN for manual/admin writes.

Health response schema 2 means server catalog resolution is enabled.
