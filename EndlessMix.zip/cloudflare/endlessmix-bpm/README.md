# endlessmix-bpm Worker

Binding: `DB` -> the D1 database already created in Cloudflare.

Public read endpoint:
`GET /api/v1/track?artist_key=...&title_key=...&version=`

Curated write endpoint:
`POST /api/v1/track` with `Authorization: Bearer <WRITE_TOKEN>`.
Never place WRITE_TOKEN in the Android app.

Android build wiring is intentionally fail-open and dormant until the build environment contains:
`ENDLESSMIX_BPM_API_URL=https://<your-worker-host>`

An empty URL performs zero BPM network requests. Cloud data never blocks playback and does not re-enable the old on-device BPM/energy analyzer.
