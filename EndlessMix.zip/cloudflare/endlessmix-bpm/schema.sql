CREATE TABLE IF NOT EXISTS tracks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    artist TEXT NOT NULL,
    title TEXT NOT NULL,
    artist_key TEXT NOT NULL,
    title_key TEXT NOT NULL,
    version TEXT DEFAULT '',
    duration_sec INTEGER,
    bpm REAL,
    energy REAL,
    source TEXT,
    source_id TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(artist_key, title_key, version)
);
CREATE INDEX IF NOT EXISTS idx_tracks_artist_key ON tracks(artist_key);
CREATE INDEX IF NOT EXISTS idx_tracks_title_key ON tracks(title_key);
CREATE INDEX IF NOT EXISTS idx_tracks_bpm ON tracks(bpm);
CREATE INDEX IF NOT EXISTS idx_tracks_source_id ON tracks(source_id);

-- Canonical Fonoteka harvested from MusicBrainz. This is enrichment only; playback never depends on it.
CREATE TABLE IF NOT EXISTS fonoteka_artists (
    artist_key TEXT PRIMARY KEY,
    artist TEXT NOT NULL,
    mbid TEXT,
    recording_count INTEGER DEFAULT 0,
    last_synced_at TEXT,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS fonoteka_songs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    artist_key TEXT NOT NULL,
    artist TEXT NOT NULL,
    title TEXT NOT NULL,
    title_key TEXT NOT NULL,
    mbid TEXT,
    first_release_date TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(artist_key, title_key)
);
CREATE INDEX IF NOT EXISTS idx_fonoteka_songs_artist_key ON fonoteka_songs(artist_key);
CREATE INDEX IF NOT EXISTS idx_fonoteka_songs_title_key ON fonoteka_songs(title_key);
CREATE INDEX IF NOT EXISTS idx_fonoteka_songs_mbid ON fonoteka_songs(mbid);
