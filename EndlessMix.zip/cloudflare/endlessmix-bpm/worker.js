const J={headers:{"content-type":"application/json"}};
const out=(x,s=200)=>new Response(JSON.stringify(x),{...J,status:s});
const c=v=>String(v??"").trim();
const key=v=>c(v).normalize("NFKD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/đ/g,"dj").replace(/[^\p{L}\p{N}]+/gu," ").replace(/\s+/g," ").trim();

function title(v){
  return c(v)
    .replace(/\s*[\[(](official|official music video|official video|official audio|lyrics?|audio|from\b).*?[\])]\s*/gi," ")
    .replace(/\s+(feat\.?|ft\.?|featuring)\s+.+$/i,"")
    .replace(/\s*-\s*(official\s*)?(music\s*)?(video|audio|lyrics?).*$/i,"")
    .replace(/\s+/g," ")
    .trim();
}

async function deezer(artist,track){
  artist=c(artist); track=title(track);
  if(!artist||!track) return {type:"nf"};
  const q=`artist:"${artist.replace(/"/g,"")}" track:"${track.replace(/"/g,"")}"`;
  let r;
  try{ r=await fetch("https://api.deezer.com/search?q="+encodeURIComponent(q)); }
  catch(e){ return {type:"down",msg:String(e)}; }
  if(!r.ok) return {type:"down",status:r.status};

  const j=await r.json().catch(()=>null);
  const rows=Array.isArray(j?.data)?j.data:[];
  if(!rows.length) return {type:"nf"};

  let best=rows[0];
  for(const x of rows){
    if(key(x?.artist?.name)===key(artist) && key(x?.title_short||x?.title)===key(track)){ best=x; break; }
  }

  let d;
  try{
    const x=await fetch("https://api.deezer.com/track/"+best.id);
    if(!x.ok) return {type:"down",status:x.status};
    d=await x.json();
  }catch(e){ return {type:"down",msg:String(e)}; }

  const bpm=Number(d?.bpm);
  if(!Number.isFinite(bpm)||bpm<30||bpm>300) return {type:"nf"};

  return {type:"ok",bpm,artist:d?.artist?.name||artist,title:d?.title_short||d?.title||track,source_id:"deezer:"+(d?.id||best.id)};
}

export default {
  async fetch(req,env){
    const u=new URL(req.url);

    if(u.pathname==="/"||u.pathname==="/health")
      return out({ok:true,service:"endlessmix-bpm",schema:2,query:"ARTIST + TRACK"});

    if(req.method!=="GET"||u.pathname!=="/api/v1/track")
      return out({error:"not found"},404);

    const artist=c(u.searchParams.get("artist"));
    const track=c(u.searchParams.get("title"));
    const ak=c(u.searchParams.get("artist_key"));
    const tk=c(u.searchParams.get("title_key"));
    const version=c(u.searchParams.get("version"));

    if(!ak||!tk) return out({error:"keys required"},400);

    let row=null;
    try{
      row=await env.DB.prepare("SELECT * FROM tracks WHERE artist_key=? AND title_key=? AND version=? LIMIT 1").bind(ak,tk,version).first();
    }catch(e){ return out({error:"db"},500); }

    if(row?.bpm) return out({found:true,...row});

    const z=await deezer(artist,track);
    if(z.type==="down") return out({found:false,service_available:false,reason:z},503);
    if(z.type!=="ok") return out({found:false,service_available:true},404);

    try{
      await env.DB.prepare(
        "INSERT INTO tracks (artist,title,artist_key,title_key,version,bpm,source,source_id,updated_at) VALUES(?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(artist_key,title_key,version) DO UPDATE SET bpm=excluded.bpm,source=excluded.source,source_id=excluded.source_id,updated_at=CURRENT_TIMESTAMP"
      ).bind(z.artist,z.title,ak,tk,version,z.bpm,"deezer",z.source_id).run();
    }catch(e){}

    return out({found:true,artist:z.artist,title:z.title,artist_key:ak,title_key:tk,version,bpm:z.bpm,source:"deezer",source_id:z.source_id});
  }
};
