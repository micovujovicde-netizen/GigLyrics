const JSON_HEADERS = { "content-type": "application/json; charset=utf-8" };

function json(data, status = 200, extra = {}) {
  return new Response(JSON.stringify(data), { status, headers: { ...JSON_HEADERS, ...extra } });
}

function clean(v, max = 500) {
  return String(v ?? "").trim().slice(0, max);
}

function finiteNumber(v) {
  if (v === null || v === undefined || v === "") return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function canon(v) {
  return clean(v, 500)
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/đ/g, "dj")
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .replace(/\b(official|video|audio|lyrics?|lyric|hd|hq|remastered|remaster|live|version)\b/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}


function catalogArtist(v) {
  return clean(v, 160)
    .replace(/\s*[\[(]\s*(official|vevo|topic).*?[\])]\s*/gi, " ")
    .replace(/\b(official|vevo|topic)\b/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function catalogTitle(v) {
  return clean(v, 240)
    .replace(/\s*[\[(]\s*(official\b|from\b|lyrics?\b|lyric\s+video\b|music\s+video\b|audio\b|visuali[sz]er\b|live\b|remaster(?:ed)?\b|hd\b|hq\b|4k\b).*?$/i, "")
    .replace(/\s+(?:ft\.?|feat\.?|featuring|with)\s+.+$/i, "")
    .replace(/\s*[\[(]\s*(?:ft\.?|feat\.?|featuring|with)\b.*?[\])]\s*$/i, "")
    .replace(/\s+/g, " ")
    .trim();
}

function tokenScore(a, b) {
  const A = new Set(canon(a).split(" ").filter(Boolean));
  const B = new Set(canon(b).split(" ").filter(Boolean));
  if (!A.size || !B.size) return 0;
  let hit = 0;
  for (const x of A) if (B.has(x)) hit++;
  return (2 * hit) / (A.size + B.size);
}

async function deezerResolve(artist, title) {
  artist = catalogArtist(artist);
  title = catalogTitle(title);
  if (!artist || !title) return null;

  // Deezer catalog input is deliberately minimal: ARTIST + TRACK only.
  // First use Deezer's fielded query; if that returns nothing, use one plain fallback.
  const queries = [
    `artist:"${artist.replace(/"/g, "")}" track:"${title.replace(/"/g, "")}"`,
    `${artist} ${title}`
  ];

  let rows = [];
  for (const query of queries) {
    const q = encodeURIComponent(query);
    const search = await fetch(`https://api.deezer.com/search?q=${q}&limit=12`);
    if (!search.ok) continue;
    const payload = await search.json().catch(() => null);
    rows = Array.isArray(payload?.data) ? payload.data : [];
    if (rows.length) break;
  }
  if (!rows.length) return null;

  // Collaboration strings often contain several performers while Deezer exposes
  // one primary artist on the result row. Accept the best individual artist match.
  const artistParts = artist
    .split(/\s*(?:,|&|\bx\b|\band\b|\bfeat\.?\b|\bft\.?\b|\bfeaturing\b|\bwith\b)\s*/i)
    .map(x => x.trim()).filter(Boolean);

  const ranked = rows.map(row => {
    const rowArtist = row?.artist?.name || "";
    const as = Math.max(tokenScore(artist, rowArtist), ...artistParts.map(x => tokenScore(x, rowArtist)));
    const ts = tokenScore(title, row?.title_short || row?.title || "");
    const exactArtist = [artist, ...artistParts].some(x => canon(x) === canon(rowArtist)) ? 0.25 : 0;
    const score = as * 0.40 + ts * 0.60 + exactArtist;
    return { row, score };
  }).sort((a, b) => b.score - a.score);

  const best = ranked[0];
  if (!best || best.score < 0.50 || !best.row?.id) return null;

  const detailRes = await fetch(`https://api.deezer.com/track/${best.row.id}`);
  if (!detailRes.ok) return null;
  const d = await detailRes.json().catch(() => null);
  const bpm = finiteNumber(d?.bpm);
  if (bpm === null || bpm < 30 || bpm > 300) return null;

  return {
    artist: clean(d?.artist?.name || best.row?.artist?.name || artist, 300),
    title: clean(d?.title_short || d?.title || best.row?.title || title, 300),
    duration_sec: finiteNumber(d?.duration),
    bpm,
    source: "deezer",
    source_id: `deezer:${d?.id || best.row.id}`
  };
}

async function upsertResolved(env, requested, resolved) {
  await env.DB.prepare(
    `INSERT INTO tracks
      (artist,title,artist_key,title_key,version,duration_sec,bpm,energy,source,source_id,updated_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
     ON CONFLICT(artist_key,title_key,version)
     DO UPDATE SET
       artist=excluded.artist,
       title=excluded.title,
       duration_sec=COALESCE(excluded.duration_sec,tracks.duration_sec),
       bpm=COALESCE(excluded.bpm,tracks.bpm),
       source=COALESCE(NULLIF(excluded.source,''),tracks.source),
       source_id=COALESCE(NULLIF(excluded.source_id,''),tracks.source_id),
       updated_at=CURRENT_TIMESTAMP`
  ).bind(
    resolved.artist || requested.artist,
    resolved.title || requested.title,
    requested.artistKey,
    requested.titleKey,
    requested.version,
    resolved.duration_sec,
    resolved.bpm,
    null,
    resolved.source,
    resolved.source_id
  ).run();
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.method === "GET" && (url.pathname === "/" || url.pathname === "/health")) {
      return json({ ok: true, service: "endlessmix-bpm", schema: 2, resolver: "server-catalog" });
    }

    if (request.method === "GET" && url.pathname === "/api/v1/track") {
      const artistKey = clean(url.searchParams.get("artist_key"));
      const titleKey = clean(url.searchParams.get("title_key"));
      const version = clean(url.searchParams.get("version"), 120);
      const sourceId = clean(url.searchParams.get("source_id"), 300);
      const artist = clean(url.searchParams.get("artist"), 300);
      const title = clean(url.searchParams.get("title"), 300);

      let row = null;
      if (sourceId) {
        row = await env.DB.prepare(
          `SELECT artist,title,artist_key,title_key,version,duration_sec,bpm,energy,source,source_id,updated_at
           FROM tracks WHERE source_id=? LIMIT 1`
        ).bind(sourceId).first();
      } else {
        if (!artistKey || !titleKey) return json({ error: "artist_key and title_key are required" }, 400);
        row = await env.DB.prepare(
          `SELECT artist,title,artist_key,title_key,version,duration_sec,bpm,energy,source,source_id,updated_at
           FROM tracks WHERE artist_key=? AND title_key=? AND version=? LIMIT 1`
        ).bind(artistKey, titleKey, version).first();
      }

      if (!row && artistKey && titleKey && artist && title) {
        const resolved = await deezerResolve(artist, title).catch(() => null);
        if (resolved) {
          await upsertResolved(env, { artistKey, titleKey, version, artist, title }, resolved).catch(() => null);
          row = {
            artist: resolved.artist,
            title: resolved.title,
            artist_key: artistKey,
            title_key: titleKey,
            version,
            duration_sec: resolved.duration_sec,
            bpm: resolved.bpm,
            energy: null,
            source: resolved.source,
            source_id: resolved.source_id,
            updated_at: new Date().toISOString()
          };
        }
      }

      if (!row) return json({ found: false }, 404, { "cache-control": "public, max-age=180" });
      return json({ found: true, ...row }, 200, { "cache-control": "public, max-age=86400" });
    }

    if (request.method === "POST" && url.pathname === "/api/v1/track") {
      const auth = request.headers.get("authorization") || "";
      if (!env.WRITE_TOKEN || auth !== `Bearer ${env.WRITE_TOKEN}`) return json({ error: "unauthorized" }, 401);
      let body;
      try { body = await request.json(); } catch { return json({ error: "invalid json" }, 400); }

      const artist = clean(body.artist), title = clean(body.title);
      const artistKey = clean(body.artist_key), titleKey = clean(body.title_key);
      const version = clean(body.version, 120);
      const duration = finiteNumber(body.duration_sec), bpm = finiteNumber(body.bpm), energy = finiteNumber(body.energy);
      const source = clean(body.source, 120), sourceId = clean(body.source_id, 300);
      if (!artist || !title || !artistKey || !titleKey) return json({ error: "artist/title/artist_key/title_key required" }, 400);
      if (bpm !== null && (bpm < 30 || bpm > 300)) return json({ error: "bpm out of range" }, 400);
      if (energy !== null && (energy < 0 || energy > 1)) return json({ error: "energy out of range" }, 400);

      await env.DB.prepare(
        `INSERT INTO tracks
          (artist,title,artist_key,title_key,version,duration_sec,bpm,energy,source,source_id,updated_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
         ON CONFLICT(artist_key,title_key,version)
         DO UPDATE SET
           artist=excluded.artist,title=excluded.title,
           duration_sec=COALESCE(excluded.duration_sec,tracks.duration_sec),
           bpm=COALESCE(excluded.bpm,tracks.bpm),energy=COALESCE(excluded.energy,tracks.energy),
           source=COALESCE(NULLIF(excluded.source,''),tracks.source),
           source_id=COALESCE(NULLIF(excluded.source_id,''),tracks.source_id),updated_at=CURRENT_TIMESTAMP`
      ).bind(artist,title,artistKey,titleKey,version,duration,bpm,energy,source,sourceId).run();
      return json({ ok: true });
    }

    return json({ error: "not found" }, 404);
  }
};
