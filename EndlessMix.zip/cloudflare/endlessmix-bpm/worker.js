const H={"content-type":"application/json"};
const R=(x,s=200)=>new Response(JSON.stringify(x),{status:s,headers:H});
const C=x=>String(x||"").trim();
const K=x=>C(x).normalize("NFKD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/đ/g,"dj").replace(/[^a-z0-9\u00c0-\u024f]+/g," ").trim();

let ready;
async function init(DB){
  if(ready)return ready;
  ready=DB.batch([
    DB.prepare(`CREATE TABLE IF NOT EXISTS bpm_cache(
      artist_key TEXT NOT NULL,title_key TEXT NOT NULL,version TEXT NOT NULL DEFAULT '',
      artist TEXT,title TEXT,bpm REAL,source TEXT,source_id TEXT,updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY(artist_key,title_key,version))`),
    DB.prepare(`CREATE TABLE IF NOT EXISTS fonoteka_songs(
      artist_key TEXT NOT NULL,artist TEXT,title TEXT NOT NULL,title_key TEXT NOT NULL,
      PRIMARY KEY(artist_key,title_key))`)
  ]).catch(e=>{ready=null;throw e});
  return ready;
}

async function deezer(artist,title){
  const q=encodeURIComponent('artist:"'+artist.replace(/"/g,'')+'" track:"'+title.replace(/"/g,'')+'"');
  let r;
  try{r=await fetch('https://api.deezer.com/search?q='+q)}catch(e){return {down:true}};
  if(!r.ok)return {down:true};
  const j=await r.json();
  const hit=j.data&&j.data[0];
  if(!hit)return {};
  let d;
  try{d=await fetch('https://api.deezer.com/track/'+hit.id).then(x=>x.json())}catch(e){return {down:true}};
  const bpm=Number(d.bpm);
  if(!(bpm>=30&&bpm<=300))return {};
  return {bpm,artist:(d.artist&&d.artist.name)||artist,title:d.title_short||d.title||title,id:'deezer:'+hit.id};
}

async function canonical(DB,ak,raw){
  const rk=K(raw);
  const q=await DB.prepare('SELECT title,title_key FROM fonoteka_songs WHERE artist_key=?').bind(ak).all();
  const a=(q.results||[]).sort((x,y)=>y.title_key.length-x.title_key.length);
  for(const x of a)if(x.title_key&&rk.indexOf(x.title_key)>=0)return x.title;
  return raw;
}

export default{
  async fetch(req,env){
    try{await init(env.DB)}catch(e){return R({ok:false,error:'db_init'},500)}
    const u=new URL(req.url);

    if(u.pathname==='/'||u.pathname==='/health')
      return R({ok:true,schema:3,bpm:'deezer',fonoteka:'background'});

    if(u.pathname==='/api/v1/fonoteka/artist'||u.pathname==='/api/v1/fonoteka'){
      const artist=C(u.searchParams.get('artist'));
      const ak=C(u.searchParams.get('artist_key'))||K(artist);
      const offset=Math.max(0,Number(u.searchParams.get('offset')||0)|0);
      if(!artist||!ak)return R({error:'artist'},400);

      // ONE MusicBrainz request per Worker call. Android paces calls >1 s apart.
      const q=encodeURIComponent('artist:"'+artist.replace(/"/g,'')+'"');
      let r;
      try{r=await fetch('https://musicbrainz.org/ws/2/recording/?query='+q+'&fmt=json&limit=100&offset='+offset,
        {headers:{'accept':'application/json','user-agent':'EndlessMix/4.5'}})}catch(e){return R({ok:false},503)};
      if(!r.ok)return R({ok:false,upstream:r.status},503);
      const j=await r.json();
      const rows=j.recordings||[];
      const puts=[];
      for(const x of rows){
        if(!x.title)continue;
        puts.push(env.DB.prepare('INSERT OR IGNORE INTO fonoteka_songs(artist_key,artist,title,title_key) VALUES(?,?,?,?)')
          .bind(ak,artist,x.title,K(x.title)));
      }
      if(puts.length)await env.DB.batch(puts);
      const total=Number(j['recording-count']||0);
      const next=offset+rows.length<total?offset+rows.length:null;
      return R({ok:true,artist,imported:puts.length,total_count:total,next_offset:next});
    }

    if(u.pathname==='/api/v1/track'){
      const artist=C(u.searchParams.get('artist'));
      const title=C(u.searchParams.get('title'));
      const ak=C(u.searchParams.get('artist_key'))||K(artist);
      const tk=C(u.searchParams.get('title_key'))||K(title);
      const v=C(u.searchParams.get('version'));
      if(!artist||!title||!ak||!tk)return R({error:'artist/title'},400);

      const hit=await env.DB.prepare('SELECT bpm,source,artist,title FROM bpm_cache WHERE artist_key=? AND title_key=? AND version=?')
        .bind(ak,tk,v).first();
      if(hit&&hit.bpm)return R({found:true,bpm:hit.bpm,source:hit.source||'cache',artist:hit.artist||artist,title:hit.title||title});

      // Compatibility read from the older D1 table if it exists.
      try{
        const old=await env.DB.prepare('SELECT bpm,source,artist,title FROM tracks WHERE artist_key=? AND title_key=? LIMIT 1').bind(ak,tk).first();
        if(old&&old.bpm)return R({found:true,bpm:old.bpm,source:old.source||'cache',artist:old.artist||artist,title:old.title||title});
      }catch(e){}

      let searchTitle=title;
      try{searchTitle=await canonical(env.DB,ak,title)}catch(e){}
      const z=await deezer(artist,searchTitle);
      if(z.down)return R({found:false,service_available:false},503);
      if(!z.bpm)return R({found:false,service_available:true},404);

      await env.DB.prepare(`INSERT OR REPLACE INTO bpm_cache
        (artist_key,title_key,version,artist,title,bpm,source,source_id,updated_at)
        VALUES(?,?,?,?,?,?,?, ?,CURRENT_TIMESTAMP)`)
        .bind(ak,tk,v,z.artist,z.title,z.bpm,'deezer',z.id).run();
      return R({found:true,bpm:z.bpm,source:'deezer',artist:z.artist,title:z.title});
    }

    return R({error:'not found'},404);
  }
};
