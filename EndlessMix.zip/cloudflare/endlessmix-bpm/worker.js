const H={"content-type":"application/json"};
const R=(x,s=200)=>new Response(JSON.stringify(x),{status:s,headers:H});
const C=x=>String(x||"").trim();
const K=x=>C(x).normalize("NFKD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/đ/g,"dj").replace(/[^\p{L}\p{N}]+/gu," ").replace(/\s+/g," ").trim();

// Fonoteka canonicalization: collapse all decorated versions to the base song.
// Only LIVE and COVER remain distinct variants.
function FONOTITLE(x){
  const raw=C(x);
  const live=/(^|[\s(\[\-])live([\s)\]\-]|$)/i.test(raw);
  const cover=/(^|[\s(\[\-])cover([\s)\]\-]|$)/i.test(raw);
  let base=raw
    .replace(/\([^)]*\)/g,' ')
    .replace(/\[[^\]]*\]/g,' ')
    .replace(/\s[-–—:]\s(?:remaster(?:ed)?|remix|mix|radio edit|edit|version|acoustic|instrumental|demo|mono|stereo|extended|official|video|audio|lyrics?|visuali[sz]er).*$/i,' ')
    .replace(/\s+/g,' ')
    .trim();
  if(!base)base=raw;
  const title=base+(live?' (Live)':'')+(cover?' (Cover)':'');
  return {title:title,key:K(title)};
}

let ready;
async function init(DB){
  if(ready)return ready;
  ready=DB.batch([
    DB.prepare(`CREATE TABLE IF NOT EXISTS bpm_cache(
      artist_key TEXT NOT NULL,title_key TEXT NOT NULL,version TEXT NOT NULL DEFAULT '',
      artist TEXT,title TEXT,bpm REAL,source TEXT,source_id TEXT,updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY(artist_key,title_key,version))`),
    DB.prepare(`CREATE TABLE IF NOT EXISTS fonoteka_songs(
      artist_key TEXT NOT NULL,artist TEXT,title TEXT NOT NULL,title_key TEXT NOT NULL,
      PRIMARY KEY(artist_key,title_key))`)
  ]).catch(e=>{ready=null;throw e});
  return ready;
}

async function deezer(artist,title){
  const q=encodeURIComponent('artist:"'+artist.replace(/"/g,'')+'" track:"'+title.replace(/"/g,'')+'"');
  let r;
  try{r=await fetch('https://api.deezer.com/search?q='+q)}catch(e){return {down:true}};
  if(!r.ok)return {down:true};
  const j=await r.json();
  const hit=j.data&&j.data[0];
  if(!hit)return {};
  let d;
  try{d=await fetch('https://api.deezer.com/track/'+hit.id).then(x=>x.json())}catch(e){return {down:true}};
  const bpm=Number(d.bpm);
  if(!(bpm>=30&&bpm<=300))return {};
  return {bpm,artist:(d.artist&&d.artist.name)||artist,title:d.title_short||d.title||title,id:'deezer:'+hit.id};
}

function identityTokens(x){
  const stop=new Set(['official','video','audio','lyrics','lyric','music','session','sessions','vol','volume','remaster','remastered','version']);
  return K(x).split(' ').filter(t=>t&&t.length>1&&!stop.has(t));
}
function titleSimilarity(a,b){
  const A=identityTokens(a),B=identityTokens(b);
  if(!A.length||!B.length)return 0;
  const as=new Set(A),bs=new Set(B);
  let common=0;for(const t of as)if(bs.has(t))common++;
  const union=new Set([...as,...bs]).size||1;
  let score=common/union;
  const numsA=A.filter(t=>/^\d+$/.test(t)),numsB=B.filter(t=>/^\d+$/.test(t));
  if(numsA.length&&numsB.length){
    if(numsA.some(n=>numsB.includes(n)))score+=0.18; else score-=0.35;
  }
  if(K(a).includes(K(b))||K(b).includes(K(a)))score+=0.25;
  return score;
}
async function canonical(DB,ak,raw){
  const q=await DB.prepare('SELECT title,title_key FROM fonoteka_songs WHERE artist_key=?').bind(ak).all();
  const rows=q.results||[];
  let best=null,bestScore=0;
  for(const x of rows){
    if(!x.title)continue;
    const sc=titleSimilarity(raw,x.title);
    if(sc>bestScore){best=x;bestScore=sc}
  }
  // Universal fuzzy canonicalization: conservative enough to require meaningful token overlap,
  // but tolerant of aliases, diacritics, reordered decorations and BZRP/Vol-style catalog names.
  return best&&bestScore>=0.55?best.title:raw;
}

export default{
  async fetch(req,env){
    try{await init(env.DB)}catch(e){return R({ok:false,error:'db_init'},500)}
    const u=new URL(req.url);

    if(u.pathname==='/'||u.pathname==='/health')
      return R({ok:true,schema:4,bpm:'deezer',fonoteka:'universal-identity'});

    if(u.pathname==='/api/v1/fonoteka/artist'||u.pathname==='/api/v1/fonoteka'){
      const artist=C(u.searchParams.get('artist'));
      const ak=C(u.searchParams.get('artist_key'))||K(artist);
      const offset=Math.max(0,Number(u.searchParams.get('offset')||0)|0);
      if(!artist||!ak)return R({error:'artist'},400);

      // ONE MusicBrainz request per Worker call. Android paces calls >1 s apart.
      const safeArtist=artist.replace(/"/g,'');
      const q=encodeURIComponent('(artist:"'+safeArtist+'" OR artistname:"'+safeArtist+'" OR creditname:"'+safeArtist+'")');
      let r;
      try{r=await fetch('https://musicbrainz.org/ws/2/recording/?query='+q+'&fmt=json&limit=100&offset='+offset,
        {headers:{'accept':'application/json','user-agent':'EndlessMix/4.5'}})}catch(e){return R({ok:false},503)};
      if(!r.ok)return R({ok:false,upstream:r.status},503);
      const j=await r.json();
      const rows=j.recordings||[];
      const puts=[];
      const wantedKey=K(artist);
      for(const x of rows){
        if(!x.title)continue;
        const credits=(x['artist-credit']||[]).map(c=>K((c.artist&&c.artist.name)||c.name||'')).filter(Boolean);
        // Search is radar only: only recordings whose actual MusicBrainz artist credit contains
        // the requested artist are admitted into this artist's Fonoteka lane.
        if(credits.length&&!credits.some(c=>c===wantedKey||c.includes(wantedKey)||wantedKey.includes(c)))continue;
        const ft=FONOTITLE(x.title);
        puts.push(env.DB.prepare('INSERT OR IGNORE INTO fonoteka_songs(artist_key,artist,title,title_key) VALUES(?,?,?,?)')
          .bind(ak,artist,ft.title,ft.key));
      }
      if(puts.length)await env.DB.batch(puts);
      const total=Number(j['recording-count']||0);
      const next=offset+rows.length<total?offset+rows.length:null;
      return R({ok:true,artist,imported:puts.length,total_count:total,next_offset:next});
    }

    if(u.pathname==='/api/v1/track'){
      const artist=C(u.searchParams.get('artist'));
      const title=C(u.searchParams.get('title'));
      const ak=C(u.searchParams.get('artist_key'))||K(artist);
      const tk=C(u.searchParams.get('title_key'))||K(title);
      const v=C(u.searchParams.get('version'));
      if(!artist||!title||!ak||!tk)return R({error:'artist/title'},400);

      const hit=await env.DB.prepare('SELECT bpm,source,artist,title FROM bpm_cache WHERE artist_key=? AND title_key=? AND version=?')
        .bind(ak,tk,v).first();
      if(hit&&hit.bpm)return R({found:true,bpm:hit.bpm,source:hit.source||'cache',artist:hit.artist||artist,title:hit.title||title});

      // Compatibility read from the older D1 table if it exists.
      try{
        const old=await env.DB.prepare('SELECT bpm,source,artist,title FROM tracks WHERE artist_key=? AND title_key=? LIMIT 1').bind(ak,tk).first();
        if(old&&old.bpm)return R({found:true,bpm:old.bpm,source:old.source||'cache',artist:old.artist||artist,title:old.title||title});
      }catch(e){}

      let searchTitle=title;
      try{searchTitle=await canonical(env.DB,ak,title)}catch(e){}
      const z=await deezer(artist,searchTitle);
      if(z.down)return R({found:false,service_available:false},503);
      if(!z.bpm)return R({found:false,service_available:true},404);

      await env.DB.prepare(`INSERT OR REPLACE INTO bpm_cache
        (artist_key,title_key,version,artist,title,bpm,source,source_id,updated_at)
        VALUES(?,?,?,?,?,?,?, ?,CURRENT_TIMESTAMP)`)
        .bind(ak,tk,v,z.artist,z.title,z.bpm,'deezer',z.id).run();
      return R({found:true,bpm:z.bpm,source:'deezer',artist:z.artist,title:z.title});
    }

    return R({error:'not found'},404);
  }
};
