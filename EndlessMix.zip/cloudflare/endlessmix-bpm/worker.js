const JSON_HEADERS = { "content-type": "application/json; charset=utf-8" };

function json(data, status = 200, extra = {}) {
  return new Response(JSON.stringify(data), { status, headers: { ...JSON_HEADERS, ...extra } });
}

function clean(v, max = 500) {
  return String(v ?? "").trim().slice(0, max);
}

function finiteNumber(v) {
  if (v === null || v === undefined || v === "") return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.method === "GET" && (url.pathname === "/" || url.pathname === "/health")) {
      return json({ ok: true, service: "endlessmix-bpm", schema: 1 });
    }

    if (request.method === "GET" && url.pathname === "/api/v1/track") {
      const artistKey = clean(url.searchParams.get("artist_key"));
      const titleKey = clean(url.searchParams.get("title_key"));
      const version = clean(url.searchParams.get("version"), 120);
      const sourceId = clean(url.searchParams.get("source_id"), 300);

      let row = null;
      if (sourceId) {
        row = await env.DB.prepare(
          `SELECT artist,title,artist_key,title_key,version,duration_sec,bpm,energy,source,source_id,updated_at
           FROM tracks WHERE source_id = ? LIMIT 1`
        ).bind(sourceId).first();
      } else {
        if (!artistKey || !titleKey) return json({ error: "artist_key and title_key are required" }, 400);
        row = await env.DB.prepare(
          `SELECT artist,title,artist_key,title_key,version,duration_sec,bpm,energy,source,source_id,updated_at
           FROM tracks WHERE artist_key = ? AND title_key = ? AND version = ? LIMIT 1`
        ).bind(artistKey, titleKey, version).first();
      }

      if (!row) return json({ found: false }, 404, { "cache-control": "public, max-age=300" });
      return json({ found: true, ...row }, 200, { "cache-control": "public, max-age=86400" });
    }

    // Curated/server-side writes only. Never embed WRITE_TOKEN in the Android APK.
    if (request.method === "POST" && url.pathname === "/api/v1/track") {
      const auth = request.headers.get("authorization") || "";
      if (!env.WRITE_TOKEN || auth !== `Bearer ${env.WRITE_TOKEN}`) return json({ error: "unauthorized" }, 401);

      let body;
      try { body = await request.json(); } catch { return json({ error: "invalid json" }, 400); }
      const artist = clean(body.artist);
      const title = clean(body.title);
      const artistKey = clean(body.artist_key);
      const titleKey = clean(body.title_key);
      const version = clean(body.version, 120);
      const duration = finiteNumber(body.duration_sec);
      const bpm = finiteNumber(body.bpm);
      const energy = finiteNumber(body.energy);
      const source = clean(body.source, 120);
      const sourceId = clean(body.source_id, 300);

      if (!artist || !title || !artistKey || !titleKey) return json({ error: "artist/title/artist_key/title_key required" }, 400);
      if (bpm !== null && (bpm < 30 || bpm > 300)) return json({ error: "bpm out of range" }, 400);
      if (energy !== null && (energy < 0 || energy > 1)) return json({ error: "energy out of range" }, 400);

      await env.DB.prepare(
        `INSERT INTO tracks (artist,title,artist_key,title_key,version,duration_sec,bpm,energy,source,source_id,updated_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
         ON CONFLICT(artist_key,title_key,version) DO UPDATE SET
           artist=excluded.artist, title=excluded.title, duration_sec=COALESCE(excluded.duration_sec,tracks.duration_sec),
           bpm=COALESCE(excluded.bpm,tracks.bpm), energy=COALESCE(excluded.energy,tracks.energy),
           source=COALESCE(NULLIF(excluded.source,''),tracks.source),
           source_id=COALESCE(NULLIF(excluded.source_id,''),tracks.source_id), updated_at=CURRENT_TIMESTAMP`
      ).bind(artist, title, artistKey, titleKey, version, duration, bpm, energy, source, sourceId).run();

      return json({ ok: true });
    }

    return json({ error: "not found" }, 404);
  }
};
