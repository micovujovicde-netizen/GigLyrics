const J={headers:{"content-type":"application/json"}};
const out=(x,s=200)=>new Response(JSON.stringify(x),{...J,status:s});
const c=v=>String(v??"").trim();
const key=v=>c(v).normalize("NFKD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/đ/g,"dj").replace(/[^\p{L}\p{N}]+/gu," ").replace(/\s+/g," ").trim();

let dbReady=null;
function initDb(env){
  if(dbReady) return dbReady;
  dbReady=env.DB.batch([
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS tracks (id INTEGER PRIMARY KEY AUTOINCREMENT,artist TEXT NOT NULL,title TEXT NOT NULL,artist_key TEXT NOT NULL,title_key TEXT NOT NULL,version TEXT DEFAULT '',duration_sec INTEGER,bpm REAL,energy REAL,source TEXT,source_id TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(artist_key,title_key,version))`),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS fonoteka_artists (artist_key TEXT PRIMARY KEY,artist TEXT NOT NULL,mbid TEXT,recording_count INTEGER DEFAULT 0,last_synced_at TEXT,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS fonoteka_songs (id INTEGER PRIMARY KEY AUTOINCREMENT,artist_key TEXT NOT NULL,artist TEXT NOT NULL,title TEXT NOT NULL,title_key TEXT NOT NULL,mbid TEXT,first_release_date TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(artist_key,title_key))`),
    env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_fono_artist ON fonoteka_songs(artist_key)`),
    env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_fono_title ON fonoteka_songs(title_key)`)
  ]).catch(e=>{dbReady=null;throw e});
  return dbReady;
}

function title(v){
  return c(v)
    .replace(/\s*[\[(](official|official music video|official video|official audio|lyrics?|audio|from\b).*?[\])]\s*/gi," ")
    .replace(/\s+(feat\.?|ft\.?|featuring)\s+.+$/i,"")
    .replace(/\s*-\s*(official\s*)?(music\s*)?(video|audio|lyrics?).*$/i,"")
    .replace(/\s+/g," ")
    .trim();
}

async function deezer(artist,track){
  artist=c(artist); track=title(track);
  if(!artist||!track) return {type:"nf"};
  const q=`artist:"${artist.replace(/"/g,"")}" track:"${track.replace(/"/g,"")}"`;
  let r;
  try{ r=await fetch("https://api.deezer.com/search?q="+encodeURIComponent(q)); }
  catch(e){ return {type:"down",msg:String(e)}; }
  if(!r.ok) return {type:"down",status:r.status};

  const j=await r.json().catch(()=>null);
  const rows=Array.isArray(j?.data)?j.data:[];
  if(!rows.length) return {type:"nf"};

  let best=rows[0];
  for(const x of rows){
    if(key(x?.artist?.name)===key(artist) && key(x?.title_short||x?.title)===key(track)){ best=x; break; }
  }

  let d;
  try{
    const x=await fetch("https://api.deezer.com/track/"+best.id);
    if(!x.ok) return {type:"down",status:x.status};
    d=await x.json();
  }catch(e){ return {type:"down",msg:String(e)}; }

  const bpm=Number(d?.bpm);
  if(!Number.isFinite(bpm)||bpm<30||bpm>300) return {type:"nf"};

  return {type:"ok",bpm,artist:d?.artist?.name||artist,title:d?.title_short||d?.title||track,source_id:"deezer:"+(d?.id||best.id)};
}

async function mbFetch(url){
  let r;
  try{
    r=await fetch(url,{headers:{
      "accept":"application/json",
      "user-agent":"EndlessMix/4.5 (MusicBrainz Fonoteka enrichment)"
    }});
  }catch(e){ return {type:"down",msg:String(e)}; }
  if(!r.ok) return {type:"down",status:r.status};
  const j=await r.json().catch(()=>null);
  if(!j) return {type:"down",msg:"bad_json"};
  return {type:"ok",json:j};
}

async function findMbArtist(env,artist,artistKey){
  try{
    const cached=await env.DB.prepare("SELECT mbid,artist FROM fonoteka_artists WHERE artist_key=? LIMIT 1").bind(artistKey).first();
    if(cached?.mbid) return {type:"ok",mbid:cached.mbid,artist:cached.artist||artist,cached:true};
  }catch(e){}

  const q=encodeURIComponent(`artist:"${artist.replace(/"/g,"")}"`);
  const z=await mbFetch(`https://musicbrainz.org/ws/2/artist/?query=${q}&fmt=json&limit=5`);
  if(z.type!=="ok") return z;
  const rows=Array.isArray(z.json?.artists)?z.json.artists:[];
  if(!rows.length) return {type:"nf"};
  let best=rows.find(x=>key(x?.name)===key(artist))||rows[0];
  if(!best?.id) return {type:"nf"};
  try{
    await env.DB.prepare("INSERT INTO fonoteka_artists (artist_key,artist,mbid,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(artist_key) DO UPDATE SET artist=excluded.artist,mbid=excluded.mbid,updated_at=CURRENT_TIMESTAMP")
      .bind(artistKey,best.name||artist,best.id).run();
  }catch(e){}
  return {type:"ok",mbid:best.id,artist:best.name||artist,cached:false};
}

async function importMbArtistPage(env,artist,artistKey,offset){
  const a=await findMbArtist(env,artist,artistKey);
  if(a.type!=="ok") return a;
  const limit=100;
  const url=`https://musicbrainz.org/ws/2/recording?artist=${encodeURIComponent(a.mbid)}&fmt=json&limit=${limit}&offset=${offset}`;
  const z=await mbFetch(url);
  if(z.type!=="ok") return z;
  const rows=Array.isArray(z.json?.recordings)?z.json.recordings:[];
  const total=Number(z.json?.["recording-count"]||0);
  const stmts=[];
  for(const r of rows){
    const t=c(r?.title); if(!t) continue;
    const tk=key(t); if(!tk) continue;
    stmts.push(env.DB.prepare(
      "INSERT INTO fonoteka_songs (artist_key,artist,title,title_key,mbid,first_release_date,updated_at) VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(artist_key,title_key) DO UPDATE SET title=excluded.title,mbid=COALESCE(excluded.mbid,fonoteka_songs.mbid),first_release_date=COALESCE(excluded.first_release_date,fonoteka_songs.first_release_date),updated_at=CURRENT_TIMESTAMP"
    ).bind(artistKey,a.artist,t,tk,r?.id||null,r?.["first-release-date"]||null));
  }
  if(stmts.length){
    try{ await env.DB.batch(stmts); }catch(e){ return {type:"down",msg:"db_batch"}; }
  }
  const next=(offset+rows.length<total && rows.length>0)?offset+rows.length:null;
  try{
    await env.DB.prepare("UPDATE fonoteka_artists SET artist=?,recording_count=?,last_synced_at=CASE WHEN ? IS NULL THEN CURRENT_TIMESTAMP ELSE last_synced_at END,updated_at=CURRENT_TIMESTAMP WHERE artist_key=?")
      .bind(a.artist,total,next,artistKey).run();
  }catch(e){}
  return {type:"ok",artist:a.artist,mbid:a.mbid,imported:stmts.length,total_count:total,next_offset:next};
}

async function fonotekaTitle(env,artistKey,rawTrack){
  const rk=key(rawTrack);
  if(!rk) return null;
  let rows=[];
  try{
    const q=await env.DB.prepare("SELECT title,title_key FROM fonoteka_songs WHERE artist_key=? ORDER BY length(title_key) DESC LIMIT 500").bind(artistKey).all();
    rows=Array.isArray(q?.results)?q.results:[];
  }catch(e){ return null; }
  for(const r of rows){
    const tk=c(r?.title_key);
    if(tk && (rk===tk || rk.includes(tk))) return c(r?.title)||null;
  }
  return null;
}

export default {
  async fetch(req,env){
    const u=new URL(req.url);
    try{ await initDb(env); }catch(e){ return out({ok:false,error:"db_init"},500); }

    if(u.pathname==="/"||u.pathname==="/health")
      return out({ok:true,service:"endlessmix-bpm",schema:3,query:"ARTIST + TRACK",fonoteka:"MusicBrainz -> D1"});

    if(req.method==="GET"&&(u.pathname==="/api/v1/fonoteka/artist"||u.pathname==="/api/v1/fonoteka")){
      const artist=c(u.searchParams.get("artist"));
      const ak=c(u.searchParams.get("artist_key"))||key(artist);
      const offset=Math.max(0,Number(u.searchParams.get("offset")||0)|0);
      if(!artist||!ak) return out({error:"artist required"},400);

      if(offset===0){
        try{
          const row=await env.DB.prepare("SELECT artist,mbid,recording_count,last_synced_at FROM fonoteka_artists WHERE artist_key=? LIMIT 1").bind(ak).first();
          if(row?.last_synced_at){
            const age=Date.now()-Date.parse(row.last_synced_at+"Z");
            if(Number.isFinite(age)&&age<30*24*60*60*1000)
              return out({ok:true,cached:true,artist:row.artist||artist,mbid:row.mbid||null,imported:0,total_count:row.recording_count||0,next_offset:null});
          }
        }catch(e){}
      }

      const z=await importMbArtistPage(env,artist,ak,offset);
      if(z.type==="down") return out({ok:false,service_available:false,reason:z},503);
      if(z.type!=="ok") return out({ok:false,service_available:true},404);
      return out({ok:true,cached:false,artist:z.artist,mbid:z.mbid,imported:z.imported,total_count:z.total_count,next_offset:z.next_offset});
    }

    if(req.method!=="GET"||u.pathname!=="/api/v1/track")
      return out({error:"not found"},404);

    const artist=c(u.searchParams.get("artist"));
    const track=c(u.searchParams.get("title"));
    const ak=c(u.searchParams.get("artist_key"));
    const tk=c(u.searchParams.get("title_key"));
    const version=c(u.searchParams.get("version"));

    if(!ak||!tk) return out({error:"keys required"},400);

    let row=null;
    try{
      row=await env.DB.prepare("SELECT * FROM tracks WHERE artist_key=? AND title_key=? AND version=? LIMIT 1").bind(ak,tk,version).first();
    }catch(e){ return out({error:"db"},500); }

    if(row?.bpm) return out({found:true,...row});

    const canonical=await fonotekaTitle(env,ak,track);
    const z=await deezer(artist,canonical||track);
    if(z.type==="down") return out({found:false,service_available:false,reason:z},503);
    if(z.type!=="ok") return out({found:false,service_available:true,fonoteka_title:canonical||null},404);

    try{
      await env.DB.prepare(
        "INSERT INTO tracks (artist,title,artist_key,title_key,version,bpm,source,source_id,updated_at) VALUES(?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(artist_key,title_key,version) DO UPDATE SET bpm=excluded.bpm,source=excluded.source,source_id=excluded.source_id,updated_at=CURRENT_TIMESTAMP"
      ).bind(z.artist,z.title,ak,tk,version,z.bpm,"deezer",z.source_id).run();
    }catch(e){}

    return out({found:true,artist:z.artist,title:z.title,artist_key:ak,title_key:tk,version,bpm:z.bpm,source:"deezer",source_id:z.source_id,fonoteka_title:canonical||null});
  }
};
