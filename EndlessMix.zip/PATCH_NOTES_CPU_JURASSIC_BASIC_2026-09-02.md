# CPU fix — BASIC must not wake DECK J/Jurassic

BB evidence showed a ~5.64 s gap between `BPM_PREFETCH_ENTER` and `BPM_PREFETCH` while F was explicitly skipped. The gap came from the first `deckJ.metadata(...)` call lazily parsing the 9.3 MB `qem_track_vault_seed.json` on the lifecycle/main path.

Fix:
- BASIC / ONE SONG physical-deck BPM prefetch no longer touches Deck J/Jurassic at all.
- Deck J metadata remains QEM authority only.
- When QEM does use Deck J metadata, lookup/first parse is dispatched off MAIN via `Dispatchers.Default`.
- New BB marker: `BPM_PRIMARY_VAULT_SKIP ... reason=qem_only_authority`.
- Existing A/B F analyzer skip remains unchanged.

No UI, transition, discovery, or deck-ownership logic changed in this patch.
