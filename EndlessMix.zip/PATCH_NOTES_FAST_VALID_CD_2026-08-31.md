# FAST VALID C/D — 2026-08-31

Minimal QEM backstage discovery efficiency patch. Playback/transition/Safety Belt are untouched.

- Per-artist YouTube attempt is tightly bounded: up to 6 results per query, 8 distinct total, 2.75 s max inside the existing global deadline.
- An artist that yields no usable candidate enters a short 45 s backstage cooldown so repeated discovery restarts rotate to another artist instead of re-running the same noisy PARTY/CELEBRATION results.
- If every artist is cooling down, the full pool becomes eligible again so cooldown can never starve discovery.
- Successful artist attempts clear their cooldown immediately.
- C/D still keep the existing depth=3, fill only missing holes, use distinct artists inside a batch, and never replace already-prepared READY work merely for a better rank.
- REGION / STYLE / ERA / history / BORDER / song-type hard gates are unchanged.
- A/B playback, crossfade, Champagne, Deck Z, and continuity Safety Belt are unchanged.

New BB marker: `QEM_ARTIST_COOLDOWN artist=... ms=45000`.
