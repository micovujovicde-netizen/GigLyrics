# ENDLESSMIX --- MUSIC HOTEL CLEANUP MASTER MEMO

## Internal refactor guide --- 2026-08-31

### GLAVNI ZADATAK

Pospremiti EndlessMix "muzički hotel": razmrsiti veliki
`MixerActivity.kt` u čistu, logičnu i održivu mašineriju.

OVO NIJE REDIZAJN DJ LOGIKE. OVO NIJE DODAVANJE NOVIH FUNKCIJA. OVO NIJE
PRILIKA ZA "POPRAVLJANJE" ponašanja koje već radi.

Cilj je: ISTO ponašanje aplikacije, ali jasna podjela odgovornosti,
manje petlji i manji rizik da izmjena jednog sistema pokvari drugi.

### SVETO PRAVILO

A/B playback i kontinuitet muzike su svetinja.

-   Nikad ne prekidati ACTIVE pjesmu zbog refaktora.
-   Nikad ne mijenjati postojeće transition/mix-out ponašanje usput.
-   Nikad ne prazniti READY_NEXT/parkirani kandidat prije nego postoji
    potvrđena zamjena.
-   Dead air je veći kvar od nesavršenog izbora pjesme.
-   AI/discovery smije raditi u backstageu; fizički playback mora ostati
    jednostavan i pouzdan.
-   Refaktor mora biti postepen i build-safe.
-   Poslije svakog značajnog reza: GitHub build/test prije sljedećeg
    velikog reza.
-   Ako rez promijeni ponašanje, vratiti ga i napraviti manji rez.

### CILJNA ARHITEKTURA

`MixerActivity.kt` treba na kraju biti RECEPCIJA: - Android lifecycle -
view binding / UI događaji - prosljeđivanje komandi odgovarajućim
controllerima - prikaz stanja

Ne treba da bude vlasnik DJ logike.

Ciljne cjeline:

1.  `PlaybackController`
    -   Jedini kontrolisani ulaz prema fizičkim A/B playerima.
    -   Load/play/pause/seek/state fizičkih deckova.
    -   ACTIVE/FREE/READY_NEXT fizičko stanje.
    -   Ne radi discovery, ranking ili BPM odluke.
2.  `TransitionEngine`
    -   Kada počinje transition.
    -   Crossfade tok i završetak handoffa.
    -   Dead-air recovery vezan za transition/playback.
    -   Ne traži pjesme po internetu.
    -   Ne odlučuje muzički ukus.
3.  `BasicDiscoveryEngine`
    -   Isključivo BASIC ENDLESS discovery.
    -   Vlastiti jobs/pool/queue/fallback/ranking kontekst.
    -   Ne smije curiti u QEM.
    -   Ne dira ACTIVE player.
4.  `QemEngine`
    -   Isključivo QUICK ENDLESS MIX.
    -   REGION / COUNTRY / STYLE / ERA / LIVE / COVER / OFFICIAL / PARTY
        pravila.
    -   Vlastiti jobs, candidate pool, generation/ownership, READY_NEXT
        priprema i QEM queue logika.
    -   BASIC i QEM moraju ostati potpuno odvojeni discovery motori.
    -   Mode switch nasljeđuje samo trenutno ACTIVE; stari discovery
        state se invalidira.
5.  `HistoryGuard`
    -   Jedini vlasnik anti-repeat odluka.
    -   Played-song hard ban: 20 stvarno odsviranih pjesama.
    -   Played-artist hard ban: 15 stvarno odsviranih pjesama.
    -   Persistent preko restarta.
    -   Canonicalizacija i featured/duet/collaboration performer-set
        poređenje.
    -   Search result nije "played"; istorija se puni stvarnim
        playbackom.
6.  `AidjSyncEngine`
    -   🍾 BPM/beat/phase matematika i odluka SYNC_READY / SYNC_SKIP.
    -   Ne smije direktno posjedovati A/B ExoPlayere.
    -   ACTIVE se ne premotava/restartuje radi synca.
    -   Prilagođava se pjesma koja ULAZI.
    -   Ako nema dovoljno pouzdanja: običan siguran transition.
7.  `DeckZController`
    -   TTS / render / FX / reverb / BPM echo / busy-ready stanje / duck
        faktor.
    -   Deck Z nema pravo da upravlja A/B playbackom.
    -   Dok govori, muzika se samo duckuje i poslije glatko vraća.
    -   MASTER se ne mijenja.
8.  `UI`
    -   Samo prikazuje stanje i šalje korisničke komande.
    -   UI ne treba sadržati discovery/state-machine poslovnu logiku.

### C/D BACKSTAGE PRAVILO

A/B = fizički playback. C/D = virtualni backstage sanduci.

-   C priprema budući A.
-   D priprema budući B.
-   Cap 3 kandidata po sanduku.
-   Kad se jedan potroši, dopuni samo nedostajući slot.
-   Kad je pun, worker spava.
-   Teški discovery/ranking/metadata poslovi ostaju van A/B playback
    puta.
-   READY_NEXT koji je validan je sticky: ne mijenjati ga samo zato što
    je kasnije pronađen "bolji" kandidat.

### KRITIČNE POSTOJEĆE GARANCIJE KOJE REFAKTOR NE SMIJE IZGUBITI

-   ACTIVE track je zaštićen do transition/mix-out prozora.
-   Posljednjih 30 s ACTIVE pjesme je continuity protection window.
-   Postojeći playable NEXT ima prioritet nad banovima ako bi
    alternativa napravila dead air.
-   QEM parked/queued candidate se ne briše u dead-air recoveryju.
-   Ako `qemQueued` postoji, prvo njega handoffovati FREE decku; tek ako
    ga stvarno nema ide nova discovery potraga.
-   QEM `STATE_ENDED` treba prvo konzumirati postojeći queued/C-D
    kandidat, a ne nepotrebno pokretati novu mrežnu potragu.
-   Waiting deck se ne prazni prije potvrđene zamjene.
-   Instant-next strelica postoji samo kada je suprotni deck zaista
    READY_NEXT i bezbjedan.
-   Manual ADD TO MIX ostaje zaštićen dok ne odsvira.
-   Originalna dva seeda ostaju zaštićena dok oba ne odsviraju.
-   Startup: samo jedan deck PLAYING; drugi READY_NEXT.
-   Network/Fonoteka/BPM greške moraju biti non-fatal za playback.
-   Black-box flight recorder ostaje kanonski dio aplikacije.

### PARTY / FILTER PRAVILA KOJA SE NE SMIJU SLUČAJNO PROMIJENITI

-   SLOW DANCE PARTY i JUST A PARTY ostaju QEM funkcije.
-   SLOW koristi track-level dokaz; artist reputation/search rank nije
    admission evidence.
-   Nema TOP-1/TOP-3 fallbacka za SLOW.
-   Search je radar, ne dokaz.
-   REGION/STYLE/ERA i identity hard-gates ostaju tamo gdje već
    pripadaju.
-   Fonoteka boost smije rangirati samo kandidata koji je već
    prošao hard gate.
-   Custom BPM/energy PARTY gating nije odobren pravac i ne vraćati ga
    usput.

### REFAKTOR STRATEGIJA

Raditi kao hirurg, ne kao bager.

Faza A --- najmanje rizične čiste komponente: - HistoryGuard -
DeckZController - AidjSyncEngine decision math - pomoćni
pure-data/pure-function blokovi

Faza B --- PlaybackController: - prvo tanki wrapper oko postojećeg
ponašanja - Activity poziva controller - ne mijenjati state
transitions - tek nakon zelenog builda premještati ownership

Faza C --- TransitionEngine: - izdvajati postojeću transition/recovery
logiku bez "poboljšavanja" - posebno paziti na QEM parked candidate i
dead-air recovery

Faza D --- BasicDiscoveryEngine: - izdvojiti BASIC bez dodira QEM-a -
potvrditi da BASIC i dalje kontinuirano puni waiting deck

Faza E --- QemEngine: - posljednji veliki rez - sačuvati
generation/ownership/cancellation semantiku - sačuvati C/D queue i
sticky READY_NEXT - testirati mode switch, PARTY, filtere, network
failure i end-of-track recovery

Faza F --- UI cleanup: - tek kada poslovna logika više nije u
Activityju - MixerActivity ostaje lifecycle + binding + routing

### ŠTA NE RADITI TOKOM ČIŠĆENJA

-   Ne prepisivati cijeli state machine od nule.
-   Ne uvoditi novi watchdog/lease sistem samo zato što "izgleda
    elegantnije".
-   Ne mijenjati crossfade trajanje, BPM pravila, filtere, ranking ili
    UI dizajn.
-   Ne spajati BASIC i QEM u zajednički candidate pipeline.
-   Ne premještati više velikih rizičnih sistema odjednom bez zelenog
    build checkpointa.
-   Ne brisati "čudan" kod dok nije jasno zašto postoji; može biti
    safety workaround.
-   Ne čistiti logove/black-box tragove dok traje refaktor.
-   Ne optimizovati performanse prije nego je ownership jasan.

### BUILD / TEST CHECKPOINT POSLIJE SVAKOG REZA

Minimalno provjeriti:

1.  App se otvara.
2.  A/B startup: samo jedan PLAYING.
3.  Waiting deck dobija READY_NEXT.
4.  A→B transition radi.
5.  B→A transition radi.
6.  Poslije transitiona FREE deck se ponovo puni.
7.  10+ automatskih pjesama bez dead air.
8.  BASIC radi kontinuirano.
9.  QEM radi kontinuirano.
10. BASIC↔QEM switch ne dira ACTIVE.
11. Instant-next radi samo kada je NEXT spreman.
12. ADD TO MIX nije izgubljen.
13. Persistent song/artist bans rade.
14. Featured artist ne zaobilazi artist ban.
15. Fonoteka/network failure ne zaustavlja muziku.
16. 🍾 bez sigurnog grida pada na običan transition.
17. Deck Z govori bez pauziranja/restartovanja A/B.
18. Black box bilježi relevantne događaje.

### TRENUTNI CHECKPOINT / KONTEKST

Originalni `MixerActivity.kt` pregledan je kao vrlo veliki centralni
čvor (\~8.4k linija). Projekat već ima neke zdravo izdvojene komponente
(`BeatGridAnalyzer`, `CloudBpmRepository`, `QemFonoteka`,
`PlaybackRuntime` itd.), pa cilj nije rušenje svega nego nastavak
separacije.

Napravljen je prvi CLEANUP PHASE 1 pokušaj u kojem su započeta
izdvajanja: - HistoryGuard - DeckZController - AidjSyncEngine - početni
TransitionEngine

Taj ZIP treba tretirati kao REFACTOR TEST/CHECKPOINT dok ne prođe
stvarni GitHub Android build. Ne proglašavati ga novom stabilnom bazom
samo zato što je statički uredniji.

Ako build padne: - popraviti samo compile/integration grešku nastalu
refaktorom; - ne koristiti build failure kao povod za dodatno mijenjanje
DJ ponašanja.

Ako build prođe: - zaključati taj ZIP kao novi cleanup checkpoint; - tek
onda nastaviti sljedeći rez.

### KRAJNJA SLIKA

MixerActivity = recepcija. PlaybackController = gramofoni.
TransitionEngine = DJ ruke na crossfaderu. BasicDiscoveryEngine = BASIC
muzički selektor. QemEngine = QUICK muzički selektor. C/D = backstage
sanduci. HistoryGuard = vratar koji pamti ko je već bio. AidjSyncEngine
= ritmički tehničar. DeckZController = spiker. Fonoteka/metadata =
biblioteka znanja. Black boxes = avionski zapisivači.

Svi imaju jednu odgovornost. Niko osim playback sloja ne smije nasumično
dirati gramofone.

## GLAVNA REČENICA ZA SVAKI NAREDNI RAD

"NE MIJENJAJ KAKO ENDLESSMIX SVIRA --- SAMO NAPRAVI DA BUDE JASNO KO JE
ZA ŠTA ODGOVORAN."

## DECK Z — REGIONALNI TTS ROUTER (ZAKLJUČANO)

- Umjesto jednog globalnog TTS glasa, Deck Z treba imati regionalno/jezički svjestan TTS router.
- `DeckZController` ostaje strukturno isti; iza njega se dodaje `VoiceProvider` / TTS routing sloj.
- Preferirati kvalitetne native/regionalne glasove za GLOBAL/ENGLISH, EX-YU, ITALIAN, LATINO i druge podržane zemlje/jezike kako ih budemo dodavali.
- Glas birati prvenstveno po jeziku same Deck Z najave, uz REGION/COUNTRY sesije kao kontekst; nikad slijepo po nacionalnosti izvođača.
- Koristiti lokalizovane announcement template-e tako da jedna najava idealno ide jednim koherentnim jezikom i glasom.
- Držati broj provider-a malim i upravljivim (otprilike 2–3 maksimalno), uz caching/lokalni audio gdje je praktično.
- Pad regionalnog TTS provider-a nikad ne smije blokirati ili odlagati muziku: fallback na drugi prikladan glas ili preskočiti govor.
- Ovo je buduće Deck Z poboljšanje i ne smije remetiti trenutni Music Hotel cleanup niti A/B playback safety.

## JEDAN OBJEDINJENI BLACK BOX (ZAKLJUČANO)

- U sljedećem funkcionalnom ZIP-u vratiti/providjeti jedno jedino BB dugme/report.
- Taj jedan BB mora pokrivati puni relevantni lanac: A/B playback state, BASIC/QEM discovery, C/D queue/handoff, transition/dead-air recovery, Fonoteka/network probleme, BPM/AIDJ sync kada je relevantan, Deck Z/TTS događaje i crash/runtime dijagnostiku.
- BB mora biti bounded rolling ring buffer, približno zadnjih 5 minuta meaningful događaja.
- Stari događaji se automatski odbacuju; ne praviti beskonačne logove.
- Ne spamovati svaki frame/tick; snimati state promjene, ownership, queue/handoff, reject reason, recovery, network/fatal i sync odluke.
- Cilj je da jedan kompaktan BB izvještaj bude dovoljan za dijagnostiku bez zatrpavanja korisnika ili ChatGPT-a ogromnim tekstom.

## IMPLEMENTED CHECKPOINT — UNIFIED BB (2026-08-31)
- One visible `BLACK BOX · 5 MIN` button is now present in the main mixer UI and remains usable under LOCK.
- It merges existing PLAYBACK/QEM, FONOTEKA, BPM, and AIDJ/DECK-Z recorders into one chronological report.
- The displayed/copied report contains only events from roughly the last 5 minutes (max 260 recent merged events), preventing giant diagnostic dumps.
- COPY ALL and CLEAR ALL operate across the unified report / all four underlying bounded recorders.
- No discovery, transition, filter, BPM, Deck Z, or A/B playback behavior was changed for this patch.

## IMPLEMENTED EXPERIMENT — DECK Z REGIONAL VOICE ALGORITHM (2026-08-31)
- Added `DeckZVoiceRouter`: Deck Z now routes requested speech locale through exact-country voice -> regional compatible voice -> same-language voice -> controlled English/default fallback.
- Country selection is the strongest signal when present, allowing distinctions such as Spain/Mexico, Portugal/Brazil, Serbia/Croatia/Bosnia/Montenegro, Germany/Austria/Switzerland, and country-specific Arabic accents.
- Added `DeckZAnnouncementRouter`: the announcement text language is paired with the selected speech locale so Z does not feed Croatian text to a Slovenian voice, Hindi text to Urdu/Bengali/etc., or Russian text to Ukrainian/Belarusian voices.
- Voice scoring prefers exact locale, then compatible language, engine quality, live-safe offline/on-device availability, and a restrained male-voice hint.
- No TTS download/install/network request is allowed to block music. If the desired voice is unavailable, Z falls back or skips according to existing busy/ready behavior; A/B remain sovereign.
- This uses voices exposed by the Android TTS engine already installed on the device. It does NOT yet add external cloud TTS provider API keys/services.

## NEXT UPDATE — BB-CONFIRMED CONTINUITY PACKAGE (2026-08-31)
- QEM discovery may not remain `discovery=true` indefinitely with no queued/READY candidate. A stale backstage discovery is cancelled/restarted after a bounded stall interval; ACTIVE A/B is untouched.
- Dead-air recovery has one physical owner: the `expected`/recovery deck. When neither A nor B is playing and discovery finally returns a candidate, that candidate is handed directly to the recovery owner instead of being merely parked. Parallel/stale completion must never prepare both physical decks for the same recovery generation.
- Existing parked/queued NEXT is sacred during recovery: consume it first; only search fresh when truly empty.
- Recovery media continuity outranks BPM/FIRST_BEAT/Fonoteka enrichment. Once playable media is READY on the recovery owner it starts through the existing safe READY callback.
- Repeated dead-air logging is throttled; BB should show progress (`QEM_DISCOVERY_STALL_RESTART`, `DEAD_AIR_CANDIDATE_HANDOFF`) rather than identical ARM spam.
- QEM RESET direction: cancel only the uncommitted ENTER/START NEW MIX attempt and restore the last committed QEM filter/session as though ENTER never happened. Never stop ACTIVE audio or throw away the only safe READY_NEXT continuity candidate.
- Video popup: show a rotating loading circle during YouTube startup/buffering; remove it on actual playback, close, or error. Visual only; A/B is untouched.
- Deck Z manual locale wiring is confirmed fixed (`requested=hr-HR`). `engine_default` after a correct regional request is now a voice-availability/provider issue, not a locale-routing issue.

## 2026-08-31 — FREE deck visual cleanup + continuity-first enrichment
- When a completed transition frees A/B, immediately replace the finished track's stale UI with `PREPARING NEXT…`, empty waveform and blank time. This is UI-only; do not clear/stop the transport/store in this step.
- QEM handoff gives Champagne BPM/Fonoteka/F enrichment a bounded 4 s budget. If enrichment is still unresolved, a stream-ready/current-session/non-repeat candidate may occupy the FREE deck immediately; enrichment continues backstage and SYNC stays unsafe until evidence exists.
- A completed BPM result inside the budget keeps the existing Champagne admission gate. A/B transition code is unchanged.

## 2026-08-31 — FREE deck continuous liveness watchdog
Confirmed from unified BB: the old 2.5s/10s refill rechecks ended before the 18s QEM stale-discovery threshold, so a FREE deck could remain PREPARING NEXT for an entire active song while discovery stayed active only on paper. Keep rechecking the same FREE deck at bounded 10s intervals; each tick reuses requestNextPlease/ensureQemDiscoveryLiveness and may restart only stale backstage QEM discovery. Never touch ACTIVE A/B or transition. FREE deck time label must stay blank (no stale negative time from the previous media item).

## MUSIC HOTEL — continuity coordinator housekeeping (2026-08-31)
- FREE-deck refill timing/cancellation is now owned by `QemFreeDeckWatchdog`, not an inline long-lived loop in `MixerActivity`.
- The helper is intentionally powerless over A/B: snapshot in, `NEXT PLEASE` callback out. No player, transition, BPM, Fonoteka, ranking or filter ownership.
- One watch per physical deck prevents stale timers crossing ownership cycles.
- Watch cadence is 2.5 s, 10 s total, then every 10 s for as long as the same deck remains FREE, so the existing 18 s discovery liveness guard can fire repeatedly if needed.
- Stop only when a candidate really claims `LOADING_NEXT`; re-arm if resolve fails back to FREE.
- Sacred rule preserved: do not change how EndlessMix plays; make ownership clearer and continuity safer.

## MUSIC HOTEL — FREE room ownership / liveness lock (2026-08-31)
- A validated QEM candidate crossing C/D -> physical A/B claims the target immediately as `LOADING_NEXT` before refresh/prepare; stop that deck's FREE watchdog at the same boundary. This prevents a second NEXT PLEASE from replacing a candidate already entering the deck.
- FREE-deck continuity age belongs to the physical vacancy, not to one internal search attempt. While the same deck remains genuinely FREE, the dedicated watchdog may restart only the backstage QEM discovery at restrained ~20 s intervals even if inner attempts rotate/reset their own age.
- Never use this recovery to touch the audible A/B transport, fade, Champagne transition, BORDER admission, or Fonoteka policy.

## Music Hotel — QEM extraction phase 1 (2026-08-31)
- QEM mutable session/backstage state is no longer owned directly by `MixerActivity`.
- New `QemEngine` owns QEM session selection state, candidate provenance/stamps, parked NEXT, waiting-deck ownership, discovery lifecycle counters/job, virtual C/D crates and handoff jobs.
- `MixerActivity` remains the physical A/B boundary and still calls the existing QEM discovery/admission functions during this phase; no playback/search/filter behavior was intentionally changed.
- `QemEngine` owns no ExoPlayer and may never stop/seek/clear/restart A/B.
- This is an incremental extraction checkpoint. Move QEM policy/search functions behind the engine only after continuity tests remain clean.

## GLOBAL MIX OUTPUT POLICY — 2026-08-31
- CROSSFADE is now a central app-wide physical mix policy, analogous to MASTER: every automatic mode uses the longest established QEM blend, 12 seconds.
- BASIC/QEM/Champagne may decide transition trigger/cue/sync timing, but must not invent a different physical fade duration.
- MASTER 100% retains a central -3 dB digital output reserve (`0.7079458x`) to preserve normalization/mix headroom.
- Both values live in `AudioMixPolicy`; do not duplicate them inside discovery motors or UI modes.

## VIDEO DEFAULT KEY — NO CUSTOM SYNC (2026-08-31)
- Remove/avoid all custom YouTube-to-A/B synchronization correction. No video `seekTo()` based on A/B position, no polling loop, no later corrective seek.
- YouTube/video runs with its default timing behavior. The confirmed loading spinner remains.
- A/B audio is never touched for video behavior. Video remains a non-critical visual layer only.

## DECK Z — WORLD VOICE ZONES (2026-08-31)
- Deck Z speech routing uses linguistic WORLD VOICE ZONES instead of rigid one-country/one-voice silos. This changes TTS routing only; music REGION/COUNTRY discovery stays untouched.
- BCS is the canonical shared zone: Bosnia and Herzegovina + Montenegro + Croatia + Serbia use one compatible BCS voice pool (`bs/hr/sr/sr-ME` and compatible engine tags).
- Apply the same principle worldwide: Spanish accents share a Spanish pool, Portuguese accents share a Portuguese pool, English accents share an English pool, Arabic accents share an Arabic pool, and similarly for other genuinely compatible language families/variants. Never combine unrelated languages merely because countries are nearby.
- Routing priority: user's/device's selected installed voice when it belongs to the requested voice zone -> exact locale/accent -> another compatible voice in the same zone/language -> controlled fallback -> English only as last resort.
- One good installed natural voice for a compatible zone is preferred over forcing a poor country-specific voice. Missing TTS voices must never block/delay A/B.


## CURATOR PLACEMENT — MIĆO VUJOVIĆ / ŠIZOFRENIJA
- Explicitly approved: **Mićo Vujović – Šizofrenija** -> `EX_YU / DANCE / 2000s`.
- `mico_vujovic` is included in the EX-YU DANCE 2000s artist pool so the track is discoverable there.

## DEVICE HISTORY — USER-NEXT SCORE PENALTY
- When the user presses contextual NEXT while a song is actually playing, record one local DEVICE HISTORY skip strike for that specific song.
- NEXT does NOT permanently ban the song on the first press. Each strike progressively reduces that song's future ranking/selection score.
- On the THIRD NEXT-skip of the same canonical song, its rating/selection score becomes 0 and it is effectively excluded from future automatic discovery.
- The strike/penalty belongs only to the song, never to the artist.
- This DEVICE HISTORY signal is strictly local: never upload, sync, learn via Fonoteka/server, or transmit it anywhere else.
- It should survive uninstall/reinstall once durable SAF DEVICE HISTORY storage is implemented/available.
- Recording a strike is non-critical/background-safe and must never delay or alter A/B playback or the NEXT transition.

## CURATOR RATINGS / EX-YU TRACK RULES
- Mićo Vujović — Šizofrenija: EX-YU / DANCE / 2000s, curator rating 75%.
- Mićo Vujović — Ceste: eligible in EX-YU / POP-FOLK, curator rating 75%.
- EX-YU artists are NOT penalized for having English artist names. The rule applies only to individual song titles.
- Individual EX-YU songs whose titles are genuinely English-language should be LOW PRIORITY in normal EX-YU discovery rather than globally excluded. Use a conservative title-language signal; do not punish ASCII BCS titles just because they lack diacritics. Continuity fallback may still use a valid low-priority track.

## CONTINUITY SAFETY BELT / ALARM REPLAY — LOCKED 2026-08-31
Dead air is P0. Normal discovery/queue/C-D/READY_NEXT remains authoritative. If ACTIVE reaches <=15 s and the opposite physical deck is still FREE without a playable NEXT, EndlessMix may use a previously confirmed-playable track from the current session as an emergency replay. Prefer session song #2, then #3, then another prior safe track; never replay the currently ACTIVE song. If a waiting deck is still stuck LOADING_NEXT and not physically playable at <=5 s, that waiting-deck load alone may be abandoned for the emergency replay. This one rescue may bypass normal repeat-history/QEM provenance only for the replay load; all normal rules resume immediately afterward. ACTIVE A/B is never stopped/seeked/reloaded by the belt. BB must log CONTINUITY_ALARM_REPLAY and, for the last-call stuck-load case, CONTINUITY_ALARM_STUCK_NEXT.

## 2026-09-02 — POST-BB MASTER KEY: PHYSICAL DECK OWNERSHIP

One governing invariant overrides recovery, discovery, BPM/energy enrichment and handoff convenience:

**A/B track content may change only when the physical target deck is truly FREE, except for the exact candidate that already owns that deck in LOADING_NEXT. `!isPlaying` is never write permission.**

Consequences:
- PLAYING / ACTIVE is immutable.
- READY_NEXT / committed incoming is immutable.
- A deck participating in an A/B transition is immutable from FADE_START through transition completion.
- BASIC, QEM, Deck J, C/D, sedative, dead-air recovery, late resolver callbacks and metadata/BPM jobs must all pass the same ownership firewall before any A/B refresh/resolve-commit/prepare/replacement.
- The first user-selected ONE SONG goes directly to the deck like ADD TO MIX; discovery validation must not delay that first command.
- After actual audible play, the canonical song is banned for the rest of the current mix.
- Credited artist(s) are hard-banned for at least the next 5 played positions/transitions; dirty YouTube title/uploader identity must not bypass this ban.
- REGION / COUNTRY / STYLE / DECADE remain narrow discovery/search boundaries for future candidates.
- BPM / ENERGY are soft metadata/ranking guidance by default, never a reason to stall playback.
- Physical A/B may read cached fallback BPM, but a cache miss must not launch the heavy local F decoder/FFT analyzer; heavy enrichment belongs backstage.

## 2026-09-02 — FINAL AUTOMATIC A/B ADMISSION (LOCKED)

- MASTER DECK OWNERSHIP remains the first law: automatic content writes only to a truly FREE deck
  (or the exact same LOADING_NEXT owner finishing its own commit); PLAYING/READY_NEXT/transition decks are immutable.
- Every AUTOMATIC future candidate, regardless of BASIC/QEM/J/C-D/cache/recovery/resolver path, must pass
  `automaticPhysicalAdmissionAllowed()` immediately before physical A/B claim/commit.
- Admission is checked twice for async loading: pre-claim and immediately before commit, closing the race where
  first-song playback/history becomes authoritative while NEXT is resolving.
- Same composition is current-mix hard banned. Identity ignores spacing/punctuation/metadata so `Sexbomb` and
  `Sex Bomb` are the same song; dirty YouTube suffixes such as Official Video / Full Cover / Lyrics do not create
  a new song identity.
- Original first seed song(s) are also protected at the final gate before the first playback callback arrives.
- Performer history remains hard for at least the next 5 played positions; seed performer protection is repeated
  at the final A/B boundary during the initial five selections.
- First ONE SONG / explicit manual selection remains direct user authority and is not delayed by automatic gates.
- BASIC/ONE SONG must not wake Deck J/Jurassic metadata vault for BPM. Physical A/B do not launch local F analysis
  on metadata cache miss. BPM/ENERGY remain soft enrichment for the general ONE SONG path.
- A patch is never called finished merely because local code changed; complete candidate -> identity -> handoff ->
  physical A/B paths must be inspected for bypasses before producing the ZIP.
