# ENDLESSMIX --- MUSIC HOTEL CLEANUP MASTER MEMO

## Internal refactor guide --- 2026-08-31

### GLAVNI ZADATAK

Pospremiti EndlessMix "muzički hotel": razmrsiti veliki
`MixerActivity.kt` u čistu, logičnu i održivu mašineriju.

OVO NIJE REDIZAJN DJ LOGIKE. OVO NIJE DODAVANJE NOVIH FUNKCIJA. OVO NIJE
PRILIKA ZA "POPRAVLJANJE" ponašanja koje već radi.

Cilj je: ISTO ponašanje aplikacije, ali jasna podjela odgovornosti,
manje petlji i manji rizik da izmjena jednog sistema pokvari drugi.

### SVETO PRAVILO

A/B playback i kontinuitet muzike su svetinja.

-   Nikad ne prekidati ACTIVE pjesmu zbog refaktora.
-   Nikad ne mijenjati postojeće transition/mix-out ponašanje usput.
-   Nikad ne prazniti READY_NEXT/parkirani kandidat prije nego postoji
    potvrđena zamjena.
-   Dead air je veći kvar od nesavršenog izbora pjesme.
-   AI/discovery smije raditi u backstageu; fizički playback mora ostati
    jednostavan i pouzdan.
-   Refaktor mora biti postepen i build-safe.
-   Poslije svakog značajnog reza: GitHub build/test prije sljedećeg
    velikog reza.
-   Ako rez promijeni ponašanje, vratiti ga i napraviti manji rez.

### CILJNA ARHITEKTURA

`MixerActivity.kt` treba na kraju biti RECEPCIJA: - Android lifecycle -
view binding / UI događaji - prosljeđivanje komandi odgovarajućim
controllerima - prikaz stanja

Ne treba da bude vlasnik DJ logike.

Ciljne cjeline:

1.  `PlaybackController`
    -   Jedini kontrolisani ulaz prema fizičkim A/B playerima.
    -   Load/play/pause/seek/state fizičkih deckova.
    -   ACTIVE/FREE/READY_NEXT fizičko stanje.
    -   Ne radi discovery, ranking ili BPM odluke.
2.  `TransitionEngine`
    -   Kada počinje transition.
    -   Crossfade tok i završetak handoffa.
    -   Dead-air recovery vezan za transition/playback.
    -   Ne traži pjesme po internetu.
    -   Ne odlučuje muzički ukus.
3.  `BasicDiscoveryEngine`
    -   Isključivo BASIC ENDLESS discovery.
    -   Vlastiti jobs/pool/queue/fallback/ranking kontekst.
    -   Ne smije curiti u QEM.
    -   Ne dira ACTIVE player.
4.  `QemEngine`
    -   Isključivo QUICK ENDLESS MIX.
    -   REGION / COUNTRY / STYLE / ERA / LIVE / COVER / OFFICIAL / PARTY
        pravila.
    -   Vlastiti jobs, candidate pool, generation/ownership, READY_NEXT
        priprema i QEM queue logika.
    -   BASIC i QEM moraju ostati potpuno odvojeni discovery motori.
    -   Mode switch nasljeđuje samo trenutno ACTIVE; stari discovery
        state se invalidira.
5.  `HistoryGuard`
    -   Jedini vlasnik anti-repeat odluka.
    -   Played-song hard ban: 20 stvarno odsviranih pjesama.
    -   Played-artist hard ban: 15 stvarno odsviranih pjesama.
    -   Persistent preko restarta.
    -   Canonicalizacija i featured/duet/collaboration performer-set
        poređenje.
    -   Search result nije "played"; istorija se puni stvarnim
        playbackom.
6.  `AidjSyncEngine`
    -   🍾 BPM/beat/phase matematika i odluka SYNC_READY / SYNC_SKIP.
    -   Ne smije direktno posjedovati A/B ExoPlayere.
    -   ACTIVE se ne premotava/restartuje radi synca.
    -   Prilagođava se pjesma koja ULAZI.
    -   Ako nema dovoljno pouzdanja: običan siguran transition.
7.  `DeckZController`
    -   TTS / render / FX / reverb / BPM echo / busy-ready stanje / duck
        faktor.
    -   Deck Z nema pravo da upravlja A/B playbackom.
    -   Dok govori, muzika se samo duckuje i poslije glatko vraća.
    -   MASTER se ne mijenja.
8.  `UI`
    -   Samo prikazuje stanje i šalje korisničke komande.
    -   UI ne treba sadržati discovery/state-machine poslovnu logiku.

### C/D BACKSTAGE PRAVILO

A/B = fizički playback. C/D = virtualni backstage sanduci.

-   C priprema budući A.
-   D priprema budući B.
-   Cap 3 kandidata po sanduku.
-   Kad se jedan potroši, dopuni samo nedostajući slot.
-   Kad je pun, worker spava.
-   Teški discovery/ranking/metadata poslovi ostaju van A/B playback
    puta.
-   READY_NEXT koji je validan je sticky: ne mijenjati ga samo zato što
    je kasnije pronađen "bolji" kandidat.

### KRITIČNE POSTOJEĆE GARANCIJE KOJE REFAKTOR NE SMIJE IZGUBITI

-   ACTIVE track je zaštićen do transition/mix-out prozora.
-   Posljednjih 30 s ACTIVE pjesme je continuity protection window.
-   Postojeći playable NEXT ima prioritet nad banovima ako bi
    alternativa napravila dead air.
-   QEM parked/queued candidate se ne briše u dead-air recoveryju.
-   Ako `qemQueued` postoji, prvo njega handoffovati FREE decku; tek ako
    ga stvarno nema ide nova discovery potraga.
-   QEM `STATE_ENDED` treba prvo konzumirati postojeći queued/C-D
    kandidat, a ne nepotrebno pokretati novu mrežnu potragu.
-   Waiting deck se ne prazni prije potvrđene zamjene.
-   Instant-next strelica postoji samo kada je suprotni deck zaista
    READY_NEXT i bezbjedan.
-   Manual ADD TO MIX ostaje zaštićen dok ne odsvira.
-   Originalna dva seeda ostaju zaštićena dok oba ne odsviraju.
-   Startup: samo jedan deck PLAYING; drugi READY_NEXT.
-   Network/Fonoteka/BPM greške moraju biti non-fatal za playback.
-   Black-box flight recorder ostaje kanonski dio aplikacije.

### PARTY / FILTER PRAVILA KOJA SE NE SMIJU SLUČAJNO PROMIJENITI

-   SLOW DANCE PARTY i JUST A PARTY ostaju QEM funkcije.
-   SLOW koristi track-level dokaz; artist reputation/search rank nije
    admission evidence.
-   Nema TOP-1/TOP-3 fallbacka za SLOW.
-   Search je radar, ne dokaz.
-   REGION/STYLE/ERA i identity hard-gates ostaju tamo gdje već
    pripadaju.
-   Favorites/Fonoteka boost smije rangirati samo kandidata koji je već
    prošao hard gate.
-   Custom BPM/energy PARTY gating nije odobren pravac i ne vraćati ga
    usput.

### REFAKTOR STRATEGIJA

Raditi kao hirurg, ne kao bager.

Faza A --- najmanje rizične čiste komponente: - HistoryGuard -
DeckZController - AidjSyncEngine decision math - pomoćni
pure-data/pure-function blokovi

Faza B --- PlaybackController: - prvo tanki wrapper oko postojećeg
ponašanja - Activity poziva controller - ne mijenjati state
transitions - tek nakon zelenog builda premještati ownership

Faza C --- TransitionEngine: - izdvajati postojeću transition/recovery
logiku bez "poboljšavanja" - posebno paziti na QEM parked candidate i
dead-air recovery

Faza D --- BasicDiscoveryEngine: - izdvojiti BASIC bez dodira QEM-a -
potvrditi da BASIC i dalje kontinuirano puni waiting deck

Faza E --- QemEngine: - posljednji veliki rez - sačuvati
generation/ownership/cancellation semantiku - sačuvati C/D queue i
sticky READY_NEXT - testirati mode switch, PARTY, filtere, network
failure i end-of-track recovery

Faza F --- UI cleanup: - tek kada poslovna logika više nije u
Activityju - MixerActivity ostaje lifecycle + binding + routing

### ŠTA NE RADITI TOKOM ČIŠĆENJA

-   Ne prepisivati cijeli state machine od nule.
-   Ne uvoditi novi watchdog/lease sistem samo zato što "izgleda
    elegantnije".
-   Ne mijenjati crossfade trajanje, BPM pravila, filtere, ranking ili
    UI dizajn.
-   Ne spajati BASIC i QEM u zajednički candidate pipeline.
-   Ne premještati više velikih rizičnih sistema odjednom bez zelenog
    build checkpointa.
-   Ne brisati "čudan" kod dok nije jasno zašto postoji; može biti
    safety workaround.
-   Ne čistiti logove/black-box tragove dok traje refaktor.
-   Ne optimizovati performanse prije nego je ownership jasan.

### BUILD / TEST CHECKPOINT POSLIJE SVAKOG REZA

Minimalno provjeriti:

1.  App se otvara.
2.  A/B startup: samo jedan PLAYING.
3.  Waiting deck dobija READY_NEXT.
4.  A→B transition radi.
5.  B→A transition radi.
6.  Poslije transitiona FREE deck se ponovo puni.
7.  10+ automatskih pjesama bez dead air.
8.  BASIC radi kontinuirano.
9.  QEM radi kontinuirano.
10. BASIC↔QEM switch ne dira ACTIVE.
11. Instant-next radi samo kada je NEXT spreman.
12. ADD TO MIX nije izgubljen.
13. Persistent song/artist bans rade.
14. Featured artist ne zaobilazi artist ban.
15. Fonoteka/network failure ne zaustavlja muziku.
16. 🍾 bez sigurnog grida pada na običan transition.
17. Deck Z govori bez pauziranja/restartovanja A/B.
18. Black box bilježi relevantne događaje.

### TRENUTNI CHECKPOINT / KONTEKST

Originalni `MixerActivity.kt` pregledan je kao vrlo veliki centralni
čvor (\~8.4k linija). Projekat već ima neke zdravo izdvojene komponente
(`BeatGridAnalyzer`, `CloudBpmRepository`, `QemFonoteka`,
`PlaybackRuntime` itd.), pa cilj nije rušenje svega nego nastavak
separacije.

Napravljen je prvi CLEANUP PHASE 1 pokušaj u kojem su započeta
izdvajanja: - HistoryGuard - DeckZController - AidjSyncEngine - početni
TransitionEngine

Taj ZIP treba tretirati kao REFACTOR TEST/CHECKPOINT dok ne prođe
stvarni GitHub Android build. Ne proglašavati ga novom stabilnom bazom
samo zato što je statički uredniji.

Ako build padne: - popraviti samo compile/integration grešku nastalu
refaktorom; - ne koristiti build failure kao povod za dodatno mijenjanje
DJ ponašanja.

Ako build prođe: - zaključati taj ZIP kao novi cleanup checkpoint; - tek
onda nastaviti sljedeći rez.

### KRAJNJA SLIKA

MixerActivity = recepcija. PlaybackController = gramofoni.
TransitionEngine = DJ ruke na crossfaderu. BasicDiscoveryEngine = BASIC
muzički selektor. QemEngine = QUICK muzički selektor. C/D = backstage
sanduci. HistoryGuard = vratar koji pamti ko je već bio. AidjSyncEngine
= ritmički tehničar. DeckZController = spiker. Fonoteka/metadata =
biblioteka znanja. Black boxes = avionski zapisivači.

Svi imaju jednu odgovornost. Niko osim playback sloja ne smije nasumično
dirati gramofone.

## GLAVNA REČENICA ZA SVAKI NAREDNI RAD

"NE MIJENJAJ KAKO ENDLESSMIX SVIRA --- SAMO NAPRAVI DA BUDE JASNO KO JE
ZA ŠTA ODGOVORAN."

## DECK Z — REGIONALNI TTS ROUTER (ZAKLJUČANO)

- Umjesto jednog globalnog TTS glasa, Deck Z treba imati regionalno/jezički svjestan TTS router.
- `DeckZController` ostaje strukturno isti; iza njega se dodaje `VoiceProvider` / TTS routing sloj.
- Preferirati kvalitetne native/regionalne glasove za GLOBAL/ENGLISH, EX-YU, ITALIAN, LATINO i druge podržane zemlje/jezike kako ih budemo dodavali.
- Glas birati prvenstveno po jeziku same Deck Z najave, uz REGION/COUNTRY sesije kao kontekst; nikad slijepo po nacionalnosti izvođača.
- Koristiti lokalizovane announcement template-e tako da jedna najava idealno ide jednim koherentnim jezikom i glasom.
- Držati broj provider-a malim i upravljivim (otprilike 2–3 maksimalno), uz caching/lokalni audio gdje je praktično.
- Pad regionalnog TTS provider-a nikad ne smije blokirati ili odlagati muziku: fallback na drugi prikladan glas ili preskočiti govor.
- Ovo je buduće Deck Z poboljšanje i ne smije remetiti trenutni Music Hotel cleanup niti A/B playback safety.

## JEDAN OBJEDINJENI BLACK BOX (ZAKLJUČANO)

- U sljedećem funkcionalnom ZIP-u vratiti/providjeti jedno jedino BB dugme/report.
- Taj jedan BB mora pokrivati puni relevantni lanac: A/B playback state, BASIC/QEM discovery, C/D queue/handoff, transition/dead-air recovery, Fonoteka/network probleme, BPM/AIDJ sync kada je relevantan, Deck Z/TTS događaje i crash/runtime dijagnostiku.
- BB mora biti bounded rolling ring buffer, približno zadnjih 5 minuta meaningful događaja.
- Stari događaji se automatski odbacuju; ne praviti beskonačne logove.
- Ne spamovati svaki frame/tick; snimati state promjene, ownership, queue/handoff, reject reason, recovery, network/fatal i sync odluke.
- Cilj je da jedan kompaktan BB izvještaj bude dovoljan za dijagnostiku bez zatrpavanja korisnika ili ChatGPT-a ogromnim tekstom.

## IMPLEMENTED CHECKPOINT — UNIFIED BB (2026-08-31)
- One visible `BLACK BOX · 5 MIN` button is now present in the main mixer UI and remains usable under LOCK.
- It merges existing PLAYBACK/QEM, FONOTEKA, BPM, and AIDJ/DECK-Z recorders into one chronological report.
- The displayed/copied report contains only events from roughly the last 5 minutes (max 260 recent merged events), preventing giant diagnostic dumps.
- COPY ALL and CLEAR ALL operate across the unified report / all four underlying bounded recorders.
- No discovery, transition, filter, BPM, Deck Z, or A/B playback behavior was changed for this patch.
