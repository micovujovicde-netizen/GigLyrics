# Deck J supply truth fix

Observed runtime contradiction:
- DECK_J_HIT appeared repeatedly,
- then Deck J reported zero supplied tracks and startup showed "No playable tracks".

Root cause:
- Whole local stages were wrapped in `withTimeoutOrNull`.
- NewPipe/searchRepo work is not always cancellation-cooperative.
- A stage could cross its timeout, finish with valid hits, log those hits, and still be returned as NULL.
- The supplier fallback then re-entered the local vault instead of going directly to live/network search.

Fix:
- Removed whole-stage timeout wrappers from Deck-J supply.
- `qemFindTracksWorker` remains responsible for its own bounded deadline/search attempts.
- Completed J hits are never discarded merely because a blocking extractor overran the nominal stage clock.
- Added `skipVault` so supplier fallback cannot re-run the already-exhausted local vault.
- PARTY BPM hard gate/ranking now applies in STRICT and LOCAL RELAXED alike.
- Added DECK_J_STAGE_RESULT logs so each stage's actual returned count is explicit.

Authority remains:
Human ADD TO MIX > A/B sanctuary > Deck J > J transport > passive C/D.
