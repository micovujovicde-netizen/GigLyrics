# Artist history window = 5

- Persistent song hard-ban remains 20 played tracks.
- Persistent artist hard-ban changed from 15 to 5 played tracks.
- History remains device-local and persistent through app restarts.
