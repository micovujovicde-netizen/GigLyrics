# MONSTER J v2 URL HUNTER — 2026-09-01

- Android Deck J seed replaced with the 31,435-track lean Monster J runtime catalog.
- URL hydration now uses a persisted rotating cursor across the whole missing-URL catalog.
- Fixes the old first-30 starvation/stall bug.
- Hydration remains background-only: it runs only with ACTIVE music + opposite READY_NEXT and no fade/discovery/handoff.
- Batch: 3 candidates, up to 8 search results each, 4-second bounded search.
- Direct URLs are persisted only after exact canonical title + border/version validation.
- No expiring googlevideo stream URL is stored.
- No supplier/Cloud BPM/F BPM/TempoAnalyzer/BASIC/C-D worker was restored.
