# ONE SONG lock chain — 2026-09-01

- ONE SONG selected track is the sole session authority, even if an older track is still physically ACTIVE.
- Hard candidate admission order: REGION/COUNTRY scene -> STYLE -> DECADE.
- BPM and ENERGY are evaluated only after hard identity admission and act as musical-neighbour ranking signals.
- Seed decade comes from Deck J metadata first, then explicit title year.
- Discovery queries carry the locked decade when known.
- During an active A/B fade, automatic discovery has zero write authority over either physical deck; late candidates are parked for the next FREE slot.
- Session generation invalidation remains authoritative against stale BASIC/QEM callbacks.
