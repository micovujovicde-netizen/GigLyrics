# LOVE SONGS — QEM continuity/search hygiene — 2026-09-01

- Confirmed LOVE SONGS and JUST A PARTY already share the same QEM discovery ownership, discovery job/generation, C/D crates, FREE-deck watchdog and handoff path. No second engine was added.
- Fixed one LOVE-only starvation point in the shared PARTY metadata-ranking stage: LOVE server BPM/energy ranking is now truly soft and can no longer delete otherwise-valid discovered candidates merely because their known BPM is outside the preferred lane.
- LOVE keeps ENERGY:BPM ranking at 2.5:1. BPM distance from ~80 remains a soft score only; lower server energy remains the stronger preference.
- LOVE query/BORDER/history/version gates are unchanged. JUST A PARTY's Champagne 118..138 hard BPM gate is unchanged.
- A/B playback, ACTIVE protection, transition timing, READY_NEXT stickiness, FREE-deck watchdog cadence, QEM ownership and handoff behavior are untouched.
- Music Hotel rule: metadata may rank backstage candidates, but it may not create dead air by emptying a valid candidate batch.
