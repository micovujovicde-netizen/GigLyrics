# A/B DUMB LOCK + STARTUP PRELOAD

- A/B physical decks are playback endpoints. `isPlaying=false` is never ownership release.
- A/B ownership is released only by explicit `STATE_ENDED` or completed transition bookkeeping.
- Removed observer reclaim that could FREE a logical PLAYING deck after a transient false callback.
- User `ADD TO MIX` is the explicit override, but only for the non-ACTIVE physical slot; it may replace waiting NEXT.
- Automatic discovery/metadata/analysis/recovery cannot use transient playback state to overwrite A/B.
- Deck-J seed data is preloaded once on `Dispatchers.Default` at app startup and kept in memory.
- Startup preload is playback-neutral and logs `STARTUP_DATA_PRELOAD`.
