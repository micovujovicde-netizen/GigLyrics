# EndlessMix — Deck J authority

- Jurassic/KRDO is now named **Deck J**.
- Deck J is a logical metadata/discovery deck, not a physical player.
- A/B remain the only physical playback decks.
- Deck J is primary for track identity, BPM, ENERGY, year/decade and Spotify audio features.
- Legacy Fonoteka artist-pool emptiness no longer blocks Deck J.
- C/D are passive parking shelves only.
- C/D have no A/B destination rights, no admission rights, no ranking rights and no metadata authority.
- A/B ask for NEXT; Deck J decides; C/D may only hold an already J-approved candidate.
- Server/live and F analysis remain fallback only when J lacks sufficient local evidence.
