# Deck J style vocabulary bridge — 2026-09-01

Root cause from BB:
`DECK_J_LIGHTNING_POOL count=0` occurred before FAST filtering, proving tempo was not the cause.

Deck J now normalizes legacy QEM UI style vocabulary to Jurassic/Spotify vault vocabulary:
- POP_FOLK -> POP_FOLK / POP / FOLK
- DANCE <-> DANCE_HOUSE
- RNB / SOUL <-> RNB_SOUL
- REGGAE_CARIBBEAN <-> REGGAE
- RAP <-> HIP_HOP

This is vocabulary normalization, not a fallback worker and not a REGION relaxation.
No BASIC, C/D, supplier, cloud BPM, F BPM, PARTY or TempoAnalyzer engine was restored.

BB now logs exact Deck J REGION / COUNTRY / STYLE / ERA / TEMPO filters.
