# DECK J GLOBAL STYLE KEYRING — LOCKED 2026-09-01

One central translation layer now covers every current QEM/Fonoteka STYLE button:

Combined:
- POP_ROCK -> POP + ROCK
- HIP_HOP_RAP -> HIP_HOP + RAP
- RNB_HIP_HOP -> RNB/RNB_SOUL + HIP_HOP
- POP_FOLK -> POP + FOLK
- REGGAE_CARIBBEAN -> REGGAE
- DANCE/HOUSE -> DANCE + DANCE_HOUSE
- WORLD -> WORLD

Singles:
POP, ROCK, HIP_HOP, RAP, RNB, FOLK, COUNTRY, SOUL, JAZZ, BLUES,
INSTRUMENTAL, CLASSICAL.

Monster aliases LATIN/LATINO and METAL are also normalized for future catalog growth.

Rules:
- Translation happens only in Deck J's local style filter.
- Combined styles broaden only to their explicit musical components.
- REGION, COUNTRY, ERA and SLOW/MEDIUM/FAST remain independent hard dimensions.
- No cloud/server/analyzer authority added.
