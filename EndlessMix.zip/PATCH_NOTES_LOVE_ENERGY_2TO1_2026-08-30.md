# LOVE ENERGY:BPM 2:1

- 💚 LOVE/SLOW LOVE now uses a literal 2:1 admission vote: ENERGY gets 2 votes, BPM gets 1.
- Existing analyzer bands are reused; no new raw energy threshold was introduced.
- LOW/MIDDLE energy = 2 ENERGY votes. HIGH/VERY HIGH = 0 ENERGY votes.
- BPM <= 103 = 1 BPM vote; BPM > 103 = 0 BPM votes.
- Candidate passes LOVE feel at 2/3 or 3/3 votes, after mandatory track-level LOVE proof and version safety gates.
- Deezer/server BPM remains authoritative as the tempo measurement. Local F BPM is used only when server BPM is unavailable.
- Local half/double-time observations are logged but no longer hard-reject before the 2:1 decision.
- New diagnostic marker: LOVE_2TO1.
