# EndlessMix keychain implementation — 2026-09-01

Implemented only the locked "keychain" diagnostics/audio/LOVE changes on top of the supplied latest ZIP.

- Real persistent crash flight recorder: immutable `endlessmix_crash_<epoch>.txt` snapshot on uncaught fatal crash, merged recent BB tail, full stack trace and latest A/B/QEM state summary; delegates to Android's previous uncaught handler.
- Persistent process-session marker distinguishes `UNCLEAN_PROCESS_DEATH` from explicit `NORMAL_CLOSE`; next launch records `PREVIOUS_CRASH_FOUND`. Crash snapshot survives restart and is acknowledged on COPY or removed only on explicit CLEAR.
- Deck Z only: HIGH EQ 250 -> 500 mB; robot presence/low-cut +/-180 -> +/-270 mB; delay reduced another 15% from scale 0.90 -> 0.765, with matching clamp 130..329 ms. A/B and MASTER untouched.
- LOVE SONGS / SLOW DANCE PARTY ranking: ENERGY:BPM soft priority is 2.5:1 for server metadata among already-admitted candidates. Track-level LOVE/BALLAD gates remain unchanged.
