# FREE deck own-chair refill — 2026-09-02

- After transition, the just-freed physical A/B deck asks for NEXT after 120 ms instead of waiting 900 ms.
- While that same deck remains genuinely FREE, it re-asks the existing NEXT PLEASE path every 2 s for up to 30 s.
- This does not touch the ACTIVE deck, does not replace READY_NEXT, and does not add a second discovery engine.
- In QEM, each re-ask consumes parked/C-D work first; if no candidate exists and discovery has stopped, it restarts the existing QEM discovery immediately.
- Goal: prevent the FREE deck from remaining in the previous track's "chair" until dead-air recovery.
