# Device History + EX-YU curator rules

- Updated USER-NEXT behavior: each NEXT press during actual playback records one local-only per-song skip strike and progressively lowers that song’s future selection score. The first and second strikes are penalties, not bans; on the third skip the canonical song reaches 0 selection score and is effectively excluded. This never penalizes the artist and is never uploaded or sent to Fonoteka/server. Durable uninstall-surviving storage remains tied to the DEVICE HISTORY SAF implementation; this patch does not fake uninstall persistence with app-private storage.
- Mićo Vujović — Šizofrenija: 75% curator rating; EX-YU / DANCE / 2000s.
- Mićo Vujović — Ceste: 75% curator rating; added to EX-YU / POP-FOLK discoverability.
- Added conservative LOW PRIORITY ranking for likely English-language song titles in EX-YU sessions. Artist names are explicitly excluded from this penalty. It is ranking-only, not a hard gate.
- No A/B playback, transition, 12 s crossfade, BPM/FIRST_BEAT, Deck Z, or Fonoteka network behavior changed.
