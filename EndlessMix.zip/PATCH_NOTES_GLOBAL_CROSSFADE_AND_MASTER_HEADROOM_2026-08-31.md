# Global crossfade + central MASTER headroom — 2026-08-31

## Scope
Small Music Hotel cleanup. No discovery/filter/Fonoteka/QEM admission changes.

## Locked policy
- Every automatic A/B transition now uses one global physical crossfade duration: **12 seconds**.
- Modes may still decide *when* to trigger or how to beat-align, but they do not own separate fade durations.
- Final output has one central **-3 dB** digital headroom reserve at MASTER 100% (`0.7079458x`).
- Headroom is applied once at the common A/B output stage, not per discovery motor or mode.

## Architecture
Added `AudioMixPolicy.kt` as the single owner of:
- `GLOBAL_CROSSFADE_MS`
- `OUTPUT_HEADROOM_GAIN`

`MixerActivity` consumes the policy; QEM/BASIC/Champagne do not duplicate these values.

## Playback safety
- No changes to A/B ownership.
- No changes to seek/pause/start rules.
- No changes to QEM discovery, BORDER gates, BPM, Fonoteka, FIRST_BEAT, or history.
- Champagne beat-sync remains free to choose cue/phase timing, but its blend duration is the same global 12 s.
