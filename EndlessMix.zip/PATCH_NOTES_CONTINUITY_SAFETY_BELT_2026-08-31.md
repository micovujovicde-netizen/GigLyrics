# EndlessMix — Continuity Safety Belt / Alarm Replay — 2026-08-31

## Purpose
Dead air is a P0 failure. Normal QEM/BASIC discovery, C/D crates, parked NEXT, READY_NEXT and the final sanctuary remain the primary path. This patch adds one final emergency layer only when those paths have failed close to the end of ACTIVE.

## Safety Belt rule
- At <= 15 s remaining, if the opposite physical deck is still FREE and has no playable NEXT, EndlessMix may reuse a track that already genuinely played in the current session.
- Preference order is session song #2, then #3, then another previously played safe track.
- The currently ACTIVE track is never eligible.
- If an existing LOADING_NEXT is still not physically playable at <= 5 s, only that waiting-deck load may be abandoned and replaced by the emergency replay.
- The emergency replay temporarily bypasses normal repeat-history/provenance admission only for that one physical rescue load. Normal discovery/history rules resume immediately.
- The rescue does not touch/seek/restart the ACTIVE deck and does not run before the normal final window.
- A late normal QEM/BASIC candidate cannot overwrite the emergency owner because the target is claimed as LOADING_NEXT immediately.

## Black Box
- `CONTINUITY_ALARM_REPLAY target=A|B source=session_history slot=2|3|... reason=no_ready_next ...`
- `CONTINUITY_ALARM_STUCK_NEXT ... action=replace_with_replay` only for the <=5 s last-call case.

## Build fix included
The EX-YU English-title priority code referenced `qemEngine.sessionRegionKeys`, but QemEngine did not yet own that session field. `sessionRegionKeys` is now part of QemEngine, is set with QEM filter commitment, cleared with QEM session teardown, and saved/restored with controller state.

## Sacred boundary
No change to normal A/B ownership, 12 s global crossfade, QEM/BASIC ranking policy, BORDER admission, BPM/FIRST_BEAT, Fonoteka, Deck Z or video behavior. The belt exists only so repetition wins over silence in an actual continuity emergency.
