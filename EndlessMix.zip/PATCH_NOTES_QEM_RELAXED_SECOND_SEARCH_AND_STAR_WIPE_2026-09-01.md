# QEM relaxed second search + favorite-star wipe — 2026-09-01

## QEM continuity rule
- First FREE-deck discovery pass remains STRICT and uses the user's exact QEM selection.
- If the same physical A/B deck is still FREE after 10 seconds, the watchdog restarts only backstage QEM discovery in RELAXED mode.
- REGION remains hard in RELAXED mode.
- RELAXED discovery widens the Fonoteka artist pool to the selected REGION across country/style/era and uses a broad `<artist> music` search query.
- Piano/instrumental and LOVE title-negative admission gates no longer hard-reject the RELAXED pass.
- For JUST A PARTY, 118–138 BPM is strict on the first pass but becomes soft on the RELAXED continuity pass; it may still inform later sync/ranking, but it cannot cause silence.
- Identity/BORDER proof, non-song rejection, duration sanity and persistent anti-repeat safety remain intact.
- Any successful QEM handoff resets discovery back to STRICT for the next FREE-deck cycle.
- Added BB markers showing STRICT/RELAXED attempt lane and outcome.

## Favorite stars
- Removed favorite star overlay, buttons, anchors, click handling and ranking boost.
- Removed the unused local favorite store source and old favorite-star patch notes.
- No A/B playback, transition, instant-NEXT or crossfader behavior was changed by this removal.
