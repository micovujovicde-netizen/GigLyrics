# QEM-only UI cut

Visible automatic-mode controls:
- QEM only.

Hidden from the mixer UI:
- ENDLESS MIX
- 1 ARTIST MIX
- BLACK BOX

The former QUICK ENDLESS MIX button is now labeled QEM and centered as the sole automatic-mode entry.

Implementation note:
The hidden legacy view IDs remain in XML with visibility=gone so existing ViewBinding/runtime references cannot break compilation during this first clean-cut step. This is intentional. A later engine rewrite can physically remove legacy code once QEM-only behavior is proven.
