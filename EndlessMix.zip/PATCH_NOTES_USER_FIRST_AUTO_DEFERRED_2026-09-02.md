# USER-first ONE SONG lifecycle fix — 2026-09-02

## Cause
`startOneSongAutoQemMix()` called `startEndlessMix()` before the selected USER URL had resolved and started playing. That activated AUTO continuity/recovery while A was still unresolved, producing repeated `DEAD_AIR_RECOVERY_ARM` and allowing AUTO state to exist without a playable USER owner.

## Patch
- ONE SONG phase 1 now runs with `AutoDiscoveryMotor.NONE` and `endlessActive == false`.
- The exact selected USER URL is loaded into A and allowed to resolve/prepare/play without Endless/QEM discovery or dead-air recovery.
- `armAutoQemFromUserTrack()` still requires the exact USER URL to be physically `isPlaying`.
- Only after that exact URL is playing are the virtual QEM preset and old QEM ENTER path invoked.
- No resolver fallback, replacement URL, BPM, waveform, chair-lock, QEM discovery, or continuity logic was changed.

## Expected BB
Before USER playback there should be no `DEAD_AIR_RECOVERY_ARM` from ONE SONG startup.
Successful path should look like:
`ONE_SONG_START ... auto=DEFERRED_UNTIL_USER_PLAYING` -> `TRACK_RESOLVE_OK` -> `PLAYER_STATE ... isPlaying=true` -> `ONE_SONG_QEM_PRESET` -> `ONE_SONG_QEM_AUTO_ENTER`.
If the selected URL fails resolution, AUTO/QEM should not start.
