# Deck J durable URL hydration

Purpose: make the 5,208-track offline J catalog progressively transport-ready without slowing START or NEXT.

- Packaged seed: 5,208 identities; 4 currently have preverified canonical YouTube watch URLs.
- Device-local durable cache: qem_track_vault_urls.jsonl.
- Cache stores canonical YouTube WATCH URLs only, never expiring googlevideo stream URLs.
- Every normal J exact-identity hit and Lightning cold-start hit persists its validated watch URL.
- Background hydration runs only while one deck is PLAYING and the opposite deck is READY_NEXT, with no fade, J discovery, transport or handoff.
- Any urgent music work preempts hydration immediately.
- Hydration validates exact canonical title + artist border and rejects obvious live/concert/karaoke/cover/tribute/tutorial variants unless they are part of the catalog identity.

Authority: ADD TO MIX > A/B sanctuary > Deck J > J transport > passive C/D > URL hydration.
