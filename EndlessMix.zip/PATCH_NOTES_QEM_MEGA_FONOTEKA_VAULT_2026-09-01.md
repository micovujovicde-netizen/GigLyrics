# QEM Mega Fonoteka Vault — 2026-09-01

Surgical backstage-only addition. A/B playback, transition timing, READY_NEXT continuity and HistoryGuard rules are unchanged.

- Added `assets/qem_track_vault_seed.json` with the 1,600-song Mega Fonoteka seed.
- Added `QemTrackVault`: immutable APK seed + persistent device-learned `qem_track_vault_learned.jsonl`.
- The vault stores only song identity and QEM provenance; never stream URLs and never played-history events.
- QEM now tries exact vault song identities before broad artist discovery, but every hit is freshly searched and must still pass current identity/BORDER, duration, history and party/slow-dance admission gates.
- REGION/COUNTRY/STYLE/ERA filtering is applied to vault picks. The existing RELAXED continuity lane still keeps REGION as the hard musical fence.
- Only C/D backstage search passes teach the persistent vault (`learnToVault=true`). Learned entries come from candidates which already passed the current QEM candidate guards.
- Learned shelf is deduplicated, append-only for low write cost, bounded to 12,000 entries and compacted when large.
- Session COUNTRY is now frozen in `QemEngine` and restored across Activity recreation so vault filtering cannot drift after the QEM drawer resets.
