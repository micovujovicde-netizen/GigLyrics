# EndlessMix — 3 keys + Dinomamut

- Embedded `KRDO_MAMUTA_I_TIRANOSAURUSA.json` (1,635 identities / 70 country labels) as the QEM local vault seed.
- Urgent QEM NEXT now gets a dedicated bounded LOCAL VAULT pass before broad live discovery.
- If local vault misses, existing live discovery remains the safe fallback. No imaginary server-read API was added: the current Worker endpoint supports Fonoteka learning/targeted track checks, not candidate-list retrieval.
- C/D keep learning validated discoveries into the persistent local vault; existing Cloud Fonoteka enrichment continues to feed the server without owning playback.
- Artist rank flattened further: rank is now only a mild familiarity hint, with a fairness floor/boost for artists outside the recent QEM artist set.
- REGION, BORDER/identity, playability and persistent anti-repeat remain unchanged.
- A/B playback, transition timing, Champagne/BPM and Deck Z were not changed.
