# EndlessMix — FINAL A/B Admission Gate — 2026-09-02

## Why
BB/runtime showed that MASTER DECK OWNERSHIP was working, but an automatic NEXT still loaded
`Sex Bomb – Tom Jones ft. Mousse T. | Full Cover with Lyrics` after the first selected/playing track
`Tom Jones & Mousse T - Sexbomb`. The old repeat checks lived in discovery paths and could be bypassed
or race the first `actually played` callback.

## Canonical rule
Every AUTOMATIC future candidate must pass one FINAL admission gate immediately before it can claim or
commit physical A/B, regardless of BASIC/QEM/J/C-D/cache/recovery/resolver source.

## Changes
- Added `automaticPhysicalAdmissionAllowed()` as the final playback-boundary gate.
- Added startup-race protection against the current original seed song(s), not only persisted played history.
- Same-song identity is spacing/punctuation/metadata tolerant: `Sexbomb` == `Sex Bomb`; dirty title suffixes
  such as Official Video / Full Cover / Lyrics cannot create a new composition identity.
- Existing current-mix played-song lifetime ban and >=5 played-position performer ban remain authoritative.
- Existing first-five seed-performer protection is repeated at the final A/B boundary so bypass paths cannot
  immediately schedule the seed artist before history catches up.
- Automatic loader checks admission twice: before claim/resolve and again immediately before async commit.
  The second check closes races where the ACTIVE song begins playing while NEXT is resolving.
- Direct live QEM atomic handoff, 1 ARTIST atomic handoff and legacy 1 ARTIST live replacement also pass
  the final admission gate before direct `MixerStore.setA/B()`.
- Rejected automatic candidates release only their own pending claim, are removed from selection claims,
  and trigger another discovery without touching ACTIVE.

## Preserved
- First/user-selected ONE SONG remains direct and bypasses automatic admission.
- Manual ADD TO MIX authority remains explicit.
- MASTER DECK OWNERSHIP / transition firewall remains unchanged.
- A/B F-analyzer cache-miss skip remains unchanged.
- BASIC does not wake QEM Deck J/Jurassic metadata vault for BPM.
- BPM/ENERGY remain soft for the general ONE SONG path.
