# LOVE low-energy-only gate — 2026-08-30

- LOVE keeps ENERGY:BPM weighting at 3:1.
- Only LOW energy earns the three LOVE energy votes.
- MIDDLE/HIGH/VERY HIGH energy earns zero LOVE energy votes and therefore cannot pass the 3-of-4 LOVE feel vote.
- Other tempo/energy filters remain unchanged.
