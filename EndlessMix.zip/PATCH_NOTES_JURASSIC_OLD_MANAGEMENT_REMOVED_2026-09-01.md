# Jurassic old-management removal — 2026-09-01

Observed BB symptom after a healthy A→B transition: FREE deck A remained empty for 130+ seconds while QEM repeatedly logged QEM_LOCAL_VAULT_MISS and restarted RELAXED discovery.

Root cause: QemTrackVault.pick() required every vault entry to map back into the legacy QemFonoteka session artistPool. Therefore KRDO/Jurassic could contain a valid track identity and metadata yet still be vetoed before exact-track resolution.

Fix:
- KRDO/Jurassic vault is now a first-class artist authority.
- Fonoteka artistPool enriches a matching vault artist when available, but cannot veto a local vault identity.
- A synthetic ArtistChoice is created from the vault entry when Fonoteka has no matching artist.
- Vault candidate budget raised from 8 to 24 minimum so a small number of noisy YouTube results do not exhaust the local lane.
- Verified youtube_url entries bypass search and go straight to the existing resolver/validation path.
- Added QEM_LOCAL_VAULT_CANDIDATES diagnostic.
- A/B playback, transition, repeat protection and BORDER validation remain unchanged.
