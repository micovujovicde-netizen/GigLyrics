# EndlessMix — Music Hotel continuity coordinator (2026-08-31)

Small, conservative housekeeping pass. No A/B transport, fade curve, transition timing, QEM filters, ranking, BPM gate or Fonoteka policy was changed.

## What moved out of MixerActivity

- Added `QemFreeDeckWatchdog.kt`.
- It owns only the timing/cancellation of FREE-deck refill checks.
- It receives a read-only snapshot from `MixerActivity` and can only call the existing `requestNextPlease(isA)` path.
- It has no ExoPlayer access, no candidate-selection logic, no filter knowledge and no ability to pause/seek/clear A/B.

## Safety cleanup

- One watchdog job per physical deck. Starting a new watch cancels an older watch for that same deck, preventing stale transition-era timers from leaking into a later ownership cycle.
- The watch now truly continues for as long as the same deck remains FREE: 2.5 s, 10 s total, then every 10 s. This lets the existing 18 s QEM discovery-stall guard actually fire even during long songs.
- Monitoring stops when a real candidate claims `LOADING_NEXT`, not merely when a candidate enters the load function. Rejected/stale candidates therefore cannot accidentally disable continuity monitoring.
- If stream resolution fails and the deck returns to FREE, continuity monitoring is re-armed.
- All watchdog jobs are cancelled with the Activity lifecycle.

## Sacred boundary

A/B playback, crossfade/transition behavior and ACTIVE-track protection are unchanged. This pass only gives the existing NEXT PLEASE/liveness mechanism a smaller, clearer owner.
