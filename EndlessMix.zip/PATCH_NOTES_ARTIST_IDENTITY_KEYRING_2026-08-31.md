# EndlessMix — Artist Identity Resolver keyring (2026-08-31)

Implemented the locked C/D artist-identity rule without touching A/B playback or weakening QEM admission gates.

- Added verified alias identity: `Voodoo Popeye` ↔ `Vudu Popaj` ↔ `Woodoo Popeye` (existing TBF/Đogani/Hiljson groups retained).
- Full title-side collaboration credits (`feat.`, `ft.`, `featuring`, `with`, `duet`, `vs`, `x`, `&`) count as strong artist identity evidence. This allows cases such as wanted `Miach` with `GRŠE - FANTAZIJA ft. MIACH`.
- Artist identity is evidence-scored, exact/canonical only; there is no global fuzzy BORDER relaxation.
- Ambiguous/generic artist identities (`Moby Dick`, `Models`, `Connect`, `ET`, `VIP`, `Luna`) require corroborating evidence. A generic word/title hit alone is not enough.
- Strong uploader/channel identity and verified uploader status can corroborate a structured artist/title or participant credit.
- Existing bounded C/D artist cooldown remains: a completed artist attempt with no usable candidate rotates away instead of immediately hammering the same junk results.
- REGION / STYLE / ERA / history / non-song / playability gates remain independent and unchanged.
