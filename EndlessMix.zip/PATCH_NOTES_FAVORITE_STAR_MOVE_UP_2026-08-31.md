# Favorite star position

- Moved only favoriteA/favoriteB 24dp upward visually and for touch handling.
- Purpose: keep the tiny gold favorite star fully outside the NEXT button visual zone.
- No change to favorite behavior, A/B playback, NEXT behavior, QEM, C/D, Deck Z, or transitions.
