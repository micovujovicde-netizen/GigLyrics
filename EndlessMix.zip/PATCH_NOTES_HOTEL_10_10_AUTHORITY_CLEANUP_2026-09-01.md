# EndlessMix — HOTEL 10/10 authority cleanup

## Locked authority map
1. Human ADD TO MIX — highest insertion authority; protected until played.
2. A/B — physical playback only. No discovery/ranking/filter decisions.
3. Deck J — sole QEM selection, admission and primary metadata authority.
4. J transport — sole automatic QEM bridge into a FREE A/B deck.
5. C/D — pooled passive reserve shelves only. They never search and never choose A/B.
6. Deck Z — speech/ducking only; no track-selection rights.
7. Continuity/dead-air — safety observer. It may ask NEXT PLEASE, never restart/rerank/select J.

## Removed hazards
- Removed obsolete watchdog-era state: discoveryStallMs, searchNotBeforeMs, relaxedDiscovery.
- Removed independent virtual C/D discovery worker; no second J search can race urgent NEXT.
- All normal QEM startup/refill paths now use one Deck-J supply pipeline:
  LOCAL STRICT -> LOCAL RELAXED -> supplier fallback.
- LOCAL RELAXED keeps REGION, STYLE, PARTY, PIANO and INSTRUMENTAL identity hard.
- Removed relaxed slow-dance bypass.
- Removed relaxed Champagne known-BPM bypass.
- QEM queued candidates are no longer injected directly by continuity observers; they route through requestNextPlease/J transport.
- QEM airlock rejection no longer clears an unrelated parked candidate.
- Mode/filter ownership changes cancel all stale J backstage handoff jobs.
- AUTO owner recovery recognizes Quick/J even when the legacy Fonoteka artist pool is empty.
- Cold two-seed startup has a 15 s bounded preload barrier instead of an infinite wait.

## Intentionally unchanged
- A/B transition/crossfade engine.
- manual ADD TO MIX protection.
- Deck Z rights and audio ducking.
- persistent song/artist history.
- final READY_NEXT dead-air start safety.
