# Restore BB analysis button
- Restored the existing BLACK BOX · 5 MIN button to the visible mixer UI.
- Existing BLACK BOX analysis/click logic was left intact.
- QEM remains the sole visible automatic mix mode; BB is diagnostic/analysis, not an automatic discovery mode.
