# ONE SONG — CLEVER CALM

- First song is absolute playback authority.
- Removed Deck J / Dinomamut metadata lookup from ONE SONG startup. The large lazy vault must never be opened on the live startup path.
- Removed the extra delayed legacy-detach cleanup job while the first song is playing. Session invalidation already happens in startEndlessMix.
- ONE SONG discovery wait is silent and passive: no WAIT logging/polling work.
- Exactly one delayed completion event arms discovery after 3 seconds.
- REGION + STYLE come from the lightweight seed classifier; DECADE only from an explicit year in the selected result at this stage.
- BPM/ENERGY remain later backstage work and never gate first-song playback.
- Added Magla Bend as a strong EX-YU seed signal.
- No new watchdog, alarm, retry loop, or recovery architecture.
