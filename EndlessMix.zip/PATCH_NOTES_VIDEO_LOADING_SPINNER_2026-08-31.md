# Video loading spinner — 2026-08-31

- Keep a small indeterminate spinner centered over the YouTube WebView while the embedded player is loading/buffering its first frame.
- Hide the spinner only when the YouTube IFrame API reports `PLAYING`.
- Hide it on player error as well so no permanent spinner can remain.
- Visual layer only: no A/B playback, transition, discovery, seek, or audio behavior was changed.
