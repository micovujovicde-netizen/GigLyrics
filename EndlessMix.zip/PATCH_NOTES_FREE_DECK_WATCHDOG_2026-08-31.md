# FREE Deck Watchdog — 2026-08-31

- Confirmed BB failure: FREE deck rechecks at 2.5s and 10s stopped before the 18s QEM discovery-stall threshold.
- Replaced the two one-shot checks with bounded continuing FREE-deck liveness checks.
- Every tick uses the existing NEXT PLEASE / QEM liveness path; only stale backstage discovery can be cancelled/restarted.
- ACTIVE A/B playback, fade, transition, seek and crossfader logic are untouched.
- FREE deck remaining-time label is blanked so stale values such as `-0:08` cannot remain beside `PREPARING NEXT…`.
