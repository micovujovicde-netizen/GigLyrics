# 💚 LOVE SONGS — locked algorithm deployed

- Track-level LOVE/BALLAD proof is mandatory; search relevance and artist reputation are never admission evidence.
- LOVE discovery terms are radar only and remain subordinate to REGION / COUNTRY / STYLE / ERA.
- Deezer/D1 BPM is authoritative. Known BPM > 103 is rejected; known BPM <= 103 skips local BPM and double-time verification.
- If Deezer BPM is unavailable, E/F may perform low-priority local tempo analysis with octave normalization disabled for LOVE.
- Local 52–79 BPM estimates are checked at 2×; a 118–158 doubled pulse plus high measured energy is rejected as likely dance half-time.
- Energy is independent from tempo. Obvious high-energy dance/club/remix versions are rejected; strong non-dance power ballads are not rejected merely for a strong chorus.
- Club/dance/house/techno/EDM remixes, nightcore, sped-up, hardstyle and festival versions are hard rejected from LOVE.
- LOVE analysis is bounded/low-priority and never touches ACTIVE playback. In the final continuity sanctuary, analysis failure may not create dead air.
- Existing JUST A PARTY 118–138 BPM lane, A/B playback, Stražar and Hotel Manager are left intact.
