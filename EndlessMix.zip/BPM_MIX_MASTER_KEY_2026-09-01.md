# ENDLESSMIX — BPM MIX MASTER KEY — LOCKED 2026-09-01

## LAW #0 — COLD START IS SACRED
START NEW MIX must never wait for BPM, ENERGY, FIRST_BEAT, silence/pre-roll detection,
confidence, beat-grid work, or SYNC. Find playable music, buffer safely, PLAY first.
Heavy analysis begins only after music is already running.

## AUTHORITY
- Deck J owns automatic QEM selection, metadata, background enrichment, and analysis scheduling.
- A/B are dumb physical playback decks only.
- SYNC consumes already-prepared data and computes a transition plan; it is not discovery.
- Background analysis can improve the mix but can never decide whether music continues.
- If analysis is missing/late/uncertain, use the ordinary crossfade. Never wait, never dead-air.

## BPM + ENERGY
- Spotify/Jurassic/Monster J BPM/ENERGY remain authoritative when present.
- Local analyzer is fallback enrichment only and must not overwrite authoritative J metadata.
- SLOW/MEDIUM/FAST should prefer matching known metadata.
- UNKNOWN BPM/ENERGY must never make cold start impossible and may be used as continuity fallback.
- The local analyzer runs only after playback begins and when A/B have a safe runway.

## FIRST_STABLE_BEAT
FIRST_BEAT does not mean the first transient.
It means the first beat of the first clearly stable rhythmic zone.
Ignore speech, applause, synth sweeps, pickups, drum fills, isolated guitar/percussion hits,
and other unstable intro transients.

Candidate stable zone:
- require about 8 consecutive stable beat intervals minimum;
- confirm over at least ~2 bars, preferably ~4 for high-confidence SYNC;
- reject a short early pulse that disappears;
- entering several seconds later is preferable to a false early cue;
- store FIRST_STABLE_BEAT plus confidence; target use threshold about 0.75.

## SILENCE / PRE-ROLL RESET
An early near-silence of about >=1.0 second can mark the end of an ad/spoken pre-roll.
Do not semantically classify an advertisement; detect the useful structure:
suspect pre-roll -> >=1 s silence -> stable musical zone.
After a valid reset, discard earlier FIRST_BEAT candidates and search again after the silence.
Do not trigger this reset when a long stable musical phrase already existed before the pause.

## IDEAL FLOW
J candidate/metadata
-> background local analysis after PLAY
-> SILENCE/PRE-ROLL RESET
-> STABLE RHYTHM SEARCH
-> FIRST_STABLE_BEAT + confidence
-> SYNC PLAN
-> A/B execute

## INITIAL SYNC PHILOSOPHY
First make phrase/beat-aligned transitions at original playback speed.
Do not make time-stretch/tempo trim a dependency. A small +/-2–3% trim may be added later
as a separate optional layer only after the base machine is robust.

## DECK J BRANCH GROWTH
When the selected REGION/COUNTRY/STYLE/ERA branch is thin, Deck J may use bounded background
search to grow that exact branch. Search is radar only: every learned track must still pass
the current J/QEM hard gates. Branch growth never owns current NEXT and runs only with safe runway.

## PRIME DIRECTIVE
BPM/SYNC improves the mix. It never decides whether the music continues.
