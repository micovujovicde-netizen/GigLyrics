# Jurassic primary metadata integration — 2026-09-01

- KRDO/Jurassic exact canonical artist+title metadata is now consulted before network BPM lookup or local F analysis.
- When local BPM exists, it is used immediately for A/B UI, BPM evidence, PARTY and Champagne BPM paths; network and F fallback are skipped.
- Local metadata exposed together: BPM, energy, Spotify ID/URL, year, decade, danceability, valence, loudness, acousticness, instrumentalness.
- For tracks with a matched Spotify year, QEM ERA filtering uses the derived decade (`1950s` ... `2020s`) as primary decade evidence. Existing EVERGREEN tag is preserved as an additional semantic tag.
- If Jurassic has no exact metadata for a track, existing cloud -> F fallback behavior remains unchanged.
- Playback/continuity/A-B state machine is untouched.
