# BORDER identity + Deck Z PLAY-context patch — 2026-08-31

- BORDER stays strict; no global fuzzy relaxation.
- Added verified identity aliases: TBF ↔ The Beat Fleet; Đogani/Djogani ↔ Đogani/Djogani Fantastico; Hiljson Mandela ↔ common Hilj$on metadata spelling.
- Accept exact multi-token `Artist-Song` title prefixes even when YouTube omits spaces around the dash (e.g. `Bad Copy- Žurka`).
- Featured/collaboration credits continue through canonical credit parsing.
- Deck Z now treats committed `qemEngine.sessionRegionKeys` as authoritative PLAY context before transient UI/quick-region state. EX_YU session therefore requests the BCS voice zone instead of falling back to en-US.
- No A/B playback, transition, 12 s crossfade, BPM/FIRST_BEAT, Fonoteka, safety-belt, or discovery timing changes.
