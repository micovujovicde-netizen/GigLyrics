# Fonoteka build-time combiner

During GitHub Actions APK builds, `app:preBuild` first runs `tools/fonoteka_combiner.py`.

Order:
1. Read the existing 1,758-artist Fonoteka.
2. Fetch concrete tracks for every artist from the iTunes Search API.
3. Attach song-level style and release-era metadata from each concrete track result.
4. Preserve manually curated LOVE/PARTY pen membership and existing song data.
5. Run a bounded YouTube exact-match pass with yt-dlp and store real view counts when available.
6. Rank only songs with captured YouTube view counts; unresolved songs keep null rank.
7. Write the enriched JSON into `app/src/main/assets/fonoteka.json` before APK packaging.

The Android app does not run the combiner. It receives the resulting catalog as an APK asset.

Environment knobs for GitHub Actions:
- `FONOTEKA_SONGS_PER_ARTIST` (default 30)
- `FONOTEKA_WORKERS` (default 8)
- `FONOTEKA_YOUTUBE` (default 1; set 0 to disable YouTube enrichment)
- `FONOTEKA_YOUTUBE_ARTISTS` (default 250; bounded to protect normal APK build time)

Important: song identity/style coverage is filled for the whole artist registry on every GitHub build. YouTube views are a ranking enrichment and are intentionally bounded during a normal build because YouTube anti-bot/rate limits make thousands of searches unsafe in one APK build. No view count is fabricated: unresolved songs retain null values.
