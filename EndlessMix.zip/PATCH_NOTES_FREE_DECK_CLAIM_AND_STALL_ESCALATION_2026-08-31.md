# EndlessMix — FREE deck ownership + stall escalation patch (2026-08-31)

Scope is deliberately narrow. A/B playback, fade timing, Champagne transition, BORDER rules,
Fonoteka admission and ranking were not changed.

## 1. QEM handoff now claims the physical deck before prepare

The BB proved that a validated candidate could already be in TRACK_PREPARE while the FREE-deck
watchdog still observed the deck as FREE. That allowed another NEXT PLEASE to arrive and churn the
first candidate (example: Zedd -> One Kiss).

At the C/D -> A/B handoff boundary, the target now immediately becomes LOADING_NEXT, its pending
URL is published, and that deck's watchdog is stopped before the existing load path runs.

BB marker:
`QEM_HANDOFF_CLAIM deck=A|B state=LOADING_NEXT ...`

Sticky LOADING_NEXT / READY_NEXT ownership remains unchanged and now starts at the true handoff
boundary.

## 2. FREE-deck liveness is measured by physical vacancy, not one inner search attempt

QEM may rotate search attempts, resetting the old discovery-age timer while the physical deck stays
empty. The small QemFreeDeckWatchdog already owns the continuous FREE interval, so at 20 s and each
20 s thereafter it asks MixerActivity to restart only the backstage QEM discovery job.

BB markers:
`FREE_DECK_DISCOVERY_RESTART target=A|B emptyMs=...`
`FREE_DECK_DISCOVERY_KICK target=A|B emptyMs=...`

The ACTIVE player is never paused, sought, cleared, reloaded or otherwise touched by this escalation.
