# ONE SONG QEM — no fonoteka gate

- Removed `no_fonoteka_profile` as a reason to skip automatic QEM.
- The old fonoteka remains the first classification source when it knows the artist.
- If it does not, the selected track is classified by the existing scene/region classifier and a lightweight style fallback.
- Region mapping covers EX-YU, Anglo, Francophone, Hispanic/Latino, Lusophone, German/DACH, Italian, Greek, Turkish, Arabic, South Asian, Eastern European, Korean and Japanese lanes. Unknown scene falls back to GLOBAL instead of stopping.
- COUNTRY remains released and all decades remain enabled.
- ROCK still cannot travel alone: it expands to POP_ROCK + DANCE.
- FOLK remains restricted to FOLK + POP_FOLK.
- The user-selected song is untouched; only future QEM discovery is affected.
