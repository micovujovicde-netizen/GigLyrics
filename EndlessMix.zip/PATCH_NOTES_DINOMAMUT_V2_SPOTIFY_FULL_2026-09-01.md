# Dinomamut v2 — Spotify299 full metadata merge

Base: latest EndlessMix.zip (includes Dinomamut v1.1 and Deck Z high-frequency/delay patch).

Imported from spotify299.zip / spotify299.txt:
- 74,660 chart rows
- 4,247 unique Spotify track IDs
- 3,573 new canonical artist+title tracks added
- 27 existing Dinomamut tracks enriched by exact canonical artist+title match
- 5,208 total tracks in seed after merge

Stored when available: Spotify track ID, BPM/tempo, danceability, energy, key, mode, time signature, loudness, speechiness, acousticness, instrumentalness, liveness, valence, duration, release date, explicit/collab, track/album/artist popularity, album label/type/image, artist images/followers/genres, and summarized chart rank/streams/week span.

No expiring audio stream URLs are stored. Existing Dinomamut v1.1 regional classifications are preserved. spotify299 has no country/market column, so newly added track region is conservatively inferred from artist genres; unknown/default is ANGLO.

No A/B, crossfade, Deck Z, BPM runtime pipeline, QEM continuity, or history code changed in this merge.
