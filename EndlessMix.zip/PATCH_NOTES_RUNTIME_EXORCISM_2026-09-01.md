# Runtime exorcism — 2026-09-01

Live automatic path is now:
QEM -> Deck J local selection/metadata -> URL resolve/cache -> FREE A/B -> PLAY

Removed from runtime:
- C/D virtual crates and reserve shelves.
- Synchronous network supplier fallback from Deck-J START/NEXT supply.
- Playback-triggered cloud/F BPM fallback from A/B metadata prefetch.
- Generic prepared-track local tempo analyzer gate.
- Hidden BASIC, 1 ARTIST and legacy START AUTO click entry points.
- BASIC resurrection after a QEM miss.

A/B remain physical playback only.
ADD TO MIX remains human authority.
Deck Z remains voice/duck only.
Persistent history remains song 20 / artist 5.
