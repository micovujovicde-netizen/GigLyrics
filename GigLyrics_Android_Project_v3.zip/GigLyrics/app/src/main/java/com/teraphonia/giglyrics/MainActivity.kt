package com.teraphonia.giglyrics

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GigLyricsApp(this) }
    }
}

data class Entry(
    val name: String,
    val uri: Uri,
    val isDirectory: Boolean,
    val pathLabel: String = ""
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GigLyricsApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("giglyrics", Context.MODE_PRIVATE) }

    var rootUri by remember {
        mutableStateOf(prefs.getString("root_uri", null)?.let(Uri::parse))
    }
    var currentUri by remember {
        mutableStateOf(prefs.getString("last_folder_uri", null)?.let(Uri::parse))
    }
    var currentTitle by remember { mutableStateOf("Gig Lyrics") }
    var entries by remember { mutableStateOf(emptyList<Entry>()) }

    var openedText by remember { mutableStateOf<String?>(null) }
    var openedTitle by remember { mutableStateOf("") }

    var fontSize by remember {
        mutableFloatStateOf(prefs.getFloat("font_size", 28f))
    }

    var searchQuery by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf(emptyList<Entry>()) }
    var searching by remember { mutableStateOf(false) }

    val folderHistory = remember { mutableStateListOf<Uri>() }

    fun listFolder(uri: Uri) {
        val folder = DocumentFile.fromTreeUri(context, uri)
        if (folder == null || !folder.isDirectory) return
        currentTitle = folder.name ?: "Folder"
        entries = folder.listFiles()
            .filter { it.isDirectory || (it.isFile && it.name?.lowercase()?.endsWith(".txt") == true) }
            .mapNotNull { f ->
                val n = f.name ?: return@mapNotNull null
                Entry(n, f.uri, f.isDirectory)
            }
            .sortedWith(compareBy<Entry> { !it.isDirectory }.thenBy { it.name.lowercase() })
        currentUri = uri
        prefs.edit().putString("last_folder_uri", uri.toString()).apply()
    }

    fun readText(uri: Uri): String {
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                BufferedReader(InputStreamReader(input)).readText()
            } ?: ""
        } catch (e: Exception) {
            "Ne mogu da otvorim fajl.\n\n${e.message ?: ""}"
        }
    }

    fun recursiveSearch(root: DocumentFile, query: String): List<Entry> {
        if (query.isBlank()) return emptyList()
        val q = query.trim().lowercase()
        val found = mutableListOf<Entry>()

        fun walk(folder: DocumentFile, path: String) {
            for (f in folder.listFiles()) {
                val name = f.name ?: continue
                if (f.isDirectory) {
                    walk(f, if (path.isBlank()) name else "$path / $name")
                } else if (name.lowercase().endsWith(".txt")) {
                    if (name.lowercase().contains(q)) {
                        found += Entry(
                            name = name,
                            uri = f.uri,
                            isDirectory = false,
                            pathLabel = path
                        )
                    }
                }
            }
        }

        walk(root, "")
        return found.sortedBy { it.name.lowercase() }
    }

    fun doSearch(query: String) {
        searchQuery = query
        val r = rootUri ?: return
        val root = DocumentFile.fromTreeUri(context, r) ?: return
        searching = query.isNotBlank()
        searchResults = if (searching) recursiveSearch(root, query) else emptyList()
    }

    val folderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}

            rootUri = uri
            currentUri = uri
            folderHistory.clear()
            searchQuery = ""
            searching = false
            searchResults = emptyList()

            prefs.edit()
                .putString("root_uri", uri.toString())
                .putString("last_folder_uri", uri.toString())
                .apply()

            listFolder(uri)
        }
    }

    val voiceSearchLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()

        if (!spoken.isNullOrBlank()) {
            doSearch(spoken)
        }
    }

    fun launchVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Kaži ime pjesme")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        }
        voiceSearchLauncher.launch(intent)
    }

    LaunchedEffect(Unit) {
        val start = currentUri ?: rootUri
        if (start != null) listFolder(start)
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color.Black,
            surface = Color.Black,
            onBackground = Color.White,
            onSurface = Color.White,
            primary = Color.White,
            onPrimary = Color.Black
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color.Black
        ) {
            if (openedText != null) {
                BackHandler { openedText = null }

                Column(Modifier.fillMaxSize()) {
                    TopAppBar(
                        title = {
                            Text(
                                openedTitle.removeSuffix(".txt"),
                                maxLines = 1
                            )
                        },
                        navigationIcon = {
                            TextButton(onClick = { openedText = null }) {
                                Text("←", fontSize = 28.sp)
                            }
                        },
                        actions = {
                            TextButton(
                                onClick = {
                                    fontSize = (fontSize - 2f).coerceAtLeast(16f)
                                    prefs.edit().putFloat("font_size", fontSize).apply()
                                }
                            ) { Text("A−", fontSize = 18.sp) }

                            TextButton(
                                onClick = {
                                    fontSize = (fontSize + 2f).coerceAtMost(60f)
                                    prefs.edit().putFloat("font_size", fontSize).apply()
                                }
                            ) { Text("A+", fontSize = 18.sp) }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color.Black,
                            titleContentColor = Color.White
                        )
                    )

                    Text(
                        text = openedText ?: "",
                        color = Color.White,
                        fontSize = fontSize.sp,
                        lineHeight = (fontSize * 1.35f).sp,
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 18.dp, vertical = 14.dp)
                    )
                }
            } else {
                BackHandler(enabled = searching || folderHistory.isNotEmpty()) {
                    if (searching) {
                        searchQuery = ""
                        searching = false
                        searchResults = emptyList()
                    } else if (folderHistory.isNotEmpty()) {
                        val previous = folderHistory.removeAt(folderHistory.lastIndex)
                        listFolder(previous)
                    }
                }

                Column(Modifier.fillMaxSize()) {
                    TopAppBar(
                        title = { Text(if (searching) "Search" else currentTitle, maxLines = 1) },
                        navigationIcon = {
                            if (searching || folderHistory.isNotEmpty()) {
                                TextButton(onClick = {
                                    if (searching) {
                                        searchQuery = ""
                                        searching = false
                                        searchResults = emptyList()
                                    } else {
                                        val previous = folderHistory.removeAt(folderHistory.lastIndex)
                                        listFolder(previous)
                                    }
                                }) {
                                    Text("←", fontSize = 28.sp)
                                }
                            }
                        },
                        actions = {
                            TextButton(onClick = { folderPicker.launch(rootUri) }) {
                                Text("FOLDER")
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color.Black,
                            titleContentColor = Color.White
                        )
                    )

                    if (rootUri == null) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Button(onClick = { folderPicker.launch(null) }) {
                                Text("IZABERI GLAVNI FOLDER")
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { doSearch(it) },
                                placeholder = { Text("Traži pjesmu…") },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = Color.White,
                                    unfocusedBorderColor = Color.DarkGray,
                                    cursorColor = Color.White,
                                    focusedPlaceholderColor = Color.Gray,
                                    unfocusedPlaceholderColor = Color.Gray
                                )
                            )

                            Spacer(Modifier.width(8.dp))

                            FilledTonalButton(
                                onClick = { launchVoiceSearch() },
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp)
                            ) {
                                Text("🎤", fontSize = 22.sp)
                            }
                        }

                        val listToShow = if (searching) searchResults else entries

                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            items(listToShow, key = { it.uri.toString() }) { item ->
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (item.isDirectory) {
                                                currentUri?.let { folderHistory.add(it) }
                                                listFolder(item.uri)
                                            } else {
                                                openedTitle = item.name
                                                openedText = readText(item.uri)
                                            }
                                        }
                                        .padding(horizontal = 20.dp, vertical = 12.dp)
                                ) {
                                    Text(
                                        text = if (item.isDirectory) "›  ${item.name}" else item.name.removeSuffix(".txt"),
                                        color = Color.White,
                                        fontSize = 23.sp,
                                        fontWeight = if (item.isDirectory) FontWeight.SemiBold else FontWeight.Normal
                                    )

                                    if (searching && item.pathLabel.isNotBlank()) {
                                        Text(
                                            text = item.pathLabel,
                                            color = Color.Gray,
                                            fontSize = 13.sp,
                                            modifier = Modifier.padding(top = 2.dp)
                                        )
                                    }
                                }
                            }

                            if (searching && searchResults.isEmpty()) {
                                item {
                                    Text(
                                        text = "Nema rezultata.",
                                        color = Color.Gray,
                                        fontSize = 18.sp,
                                        modifier = Modifier.padding(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
