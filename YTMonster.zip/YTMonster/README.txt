YTMonster 1.0.0

Private Android utility project.

Core flow:
- LOAD CSV with columns Folder,Song,Artist
- AUTO START loads visible YouTube searches one row at a time
- A concrete youtube.com/watch?v=... navigation is canonicalized and saved as SONG - ARTIST.yt
- Watchdog: 20s reload, 40s restart search, 60s retry/check behavior
- Human verification / CAPTCHA is never bypassed; row moves to CHECK
- Successful .yt files are written immediately
- EXPORT .YT ZIP creates folder structure ZIP
- Sample 1500-song BrakeMonster CSV is included in app/src/main/assets

Important limitation:
This source intentionally does not scrape hidden YouTube endpoints or bypass YouTube verification.
A fully unattended selector of the first search result is NOT implemented because doing that robustly without an API would require scraping/DOM automation against third-party content.
The app is structured so a compliant resolver can be added later.

Build:
Android Studio / Gradle, JDK 17.
