# YTMonster V2 — 2.0.4 (5)

Standalone Android application using the YouTube Data API v3. Search supports PARTY, BALLAD, INST and DJ MIX categories, country/region selection, and worldwide mode. Results are filtered for public, embeddable videos and displayed as a selectable list of up to seven. DJ MIX results are verified from video metadata and must be at least 30 minutes long. Normal searches exclude long mixes and video results of 30 minutes or more.

Selected individual videos export as one-item playlist folders. Selected YouTube playlists export their playable individual tracks in source order. Direct playlist loading remains available. API keys are supplied by the user, stored in app-private preferences after an API request succeeds, and hidden from the screen afterward. API quotas and regional/embedding restrictions apply.

ZIP export currently writes `.yt` URL shortcut files. The supplied source has no BrakeMonster `.bmq` specification, parser or encryption code, so `.bmq` compatibility is not implemented or claimed. This project has no ZIP import implementation. It does not download or store media files, and contains no Cloudflare, payment or advertising implementation.

Fixed a Java compile error in the category-button loop (local variable name collided with the `onCreate(Bundle b)` parameter).
