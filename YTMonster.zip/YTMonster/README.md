# YTMonster V2 — 2.0.5 (6)

Standalone Android application using the YouTube Data API v3. Search supports PARTY, BALLAD, INST and DJ MIX categories, country/region selection, and worldwide mode. Results are filtered for public, embeddable videos and displayed as a selectable list of up to seven. DJ MIX results are verified from video metadata and must be at least 30 minutes long. Normal searches exclude long mixes and video results of 30 minutes or more.

Selected individual videos export as one-item playlist folders. Selected YouTube playlists export their playable individual tracks in source order. Direct playlist loading remains available. API keys are supplied by the user, stored in app-private preferences after an API request succeeds, and hidden from the screen afterward. API quotas and regional/embedding restrictions apply.

ZIP export currently writes `.yt` URL shortcut files. The supplied source has no BrakeMonster `.bmq` specification, parser or encryption code, so `.bmq` compatibility is not implemented or claimed. This project has no ZIP import implementation. It does not download or store media files, and contains no Cloudflare, payment or advertising implementation.

Fixed a Java compile error in the category-button loop (local variable name collided with the `onCreate(Bundle b)` parameter).

## GENRE / DECADE restoration (2.0.5)
Restored the original twelve GENRE and eight DECADE controls below the PARTY/BALLAD/INST/DJ MIX row.
Each filter can be toggled independently; multiple genres and decades remain selected simultaneously.
The active selections are included in the actual YouTube search query, including DJ MIX searches.
The search field may be blank if at least one genre or decade is selected. Search clears only the text, not the filters.
All other search, export, import, appearance and API workflows are intentionally unchanged.
Java-only regression checks for the filter logic passed (17 assertions); full Android build and live API search were not run locally.
