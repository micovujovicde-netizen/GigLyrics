# YTMonster V2 — Direct Playlist ZIP

Independent Android app. **Version 2.0.0 (1)**. Uses YouTube Data API v3 for public playlistItems (50 per page), preserves playlist order, and creates `.yt` text files containing the exact original watch URL. No CSV, search, candidate filters, replacement, or media downloading. Private/deleted entries are skipped. User supplies own API key, stored in app-private preferences. Export uses Android Storage Access Framework; ZIP has a folder named after the playlist.

## Build
Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3. Run `gradle :app:assembleDebug` from `YTMonster/`, or use bundled GitHub Actions workflow. This source archive is **not an APK**.

## Important
YouTube API quotas and restrictions apply. This tool creates only URL shortcut `.yt` files, not downloads of video or audio. No live device/API build validation was performed here.
