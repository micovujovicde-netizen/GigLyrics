# YTMonster 2.0.6 — Country/language relevance fix

Scope: language-aware country search ONLY. UI and the existing category, genre, decade, API and ZIP/export controls are unchanged.

- `regionCode` is now a geographic availability hint, **not** proof of the language of a playlist.
- Country-specific text is added to the search term and `relevanceLanguage` used where a specific language is applicable.
- For normal music playlists, sample up to 12 **actual track titles** per candidate via `playlistItems.list` and reject clearly foreign-language or unverified playlists. Where titles give insufficient evidence, consult `videos.list(part=snippet)` for available language metadata.
- Cap verification at 24 candidate playlists per search. Metadata lookups use inexpensive `playlistItems.list` / `videos.list` requests, rather than more costly `search.list` requests. Authentication/quota errors surface to the UI.
- Direct playlist import is unchanged; the user may explicitly load their own link.
- DJ MIX is one video rather than a traditional playlist; single-video language hints are applied where possible. Instrumental music is exempt from spoken-language filtering because it has no sung language.

LIMITATIONS: YouTube does not supply a reliable audio-language label for every video or playlist. This is best-effort metadata/title-based matching, NOT audio transcription or verified song language. Serbian, Bosnian, Montenegrin and Croatian share language features; filtering by language cannot guarantee artists are from a specific country. Results with ambiguous evidence may be omitted. No Android build/device/network API test was possible in this environment; Java-only language tests passed.
