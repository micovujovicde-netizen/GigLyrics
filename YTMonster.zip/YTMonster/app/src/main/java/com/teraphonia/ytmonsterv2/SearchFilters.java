package com.teraphonia.ytmonsterv2;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Locale;

/** The original multi-select GENRE and DECADE search controls, independent of the UI. */
final class SearchFilters {
  static final String[] GENRES = {
      "POP", "ROCK", "DANCE", "BLUES", "R&B", "COUNTRY",
      "JAZZ", "SOUL", "METAL", "FOLK", "DISCO", "EDM"
  };
  static final String[] DECADES = {
      "50s", "60s", "70s", "80s", "90s", "00s", "10s", "20s"
  };

  private final LinkedHashSet<String> genres = new LinkedHashSet<>();
  private final LinkedHashSet<String> decades = new LinkedHashSet<>();

  boolean toggleGenre(String genre) {
    if (!contains(GENRES, genre)) throw new IllegalArgumentException("Unknown genre: " + genre);
    return toggle(genres, genre);
  }

  boolean toggleDecade(String decade) {
    if (!contains(DECADES, decade)) throw new IllegalArgumentException("Unknown decade: " + decade);
    return toggle(decades, decade);
  }

  boolean hasSelections() { return !genres.isEmpty() || !decades.isEmpty(); }

  String buildQuery(String submitted, String category) {
    StringBuilder result = new StringBuilder(submitted.trim());
    switch (category) {
      case "PARTY": append(result, "party dance music"); break;
      case "BALLAD": append(result, "ballad slow song"); break;
      case "INST": append(result, "instrumental music"); break;
      case "DJ MIX": append(result, "continuous DJ mix"); break;
      default: throw new IllegalArgumentException("Unknown category: " + category);
    }
    // YouTube search.list supports the pipe (|) OR operator. Use one API query,
    // not one paid search per selected genre/decade combination.
    if (!genres.isEmpty()) append(result, joined(genres));
    if (!decades.isEmpty()) {
      ArrayList<String> years = new ArrayList<>();
      for (String decade : decades) years.add(expandDecade(decade));
      append(result, joined(years));
    }
    return result.toString().trim();
  }

  private static String expandDecade(String shortYear) {
    String prefix = shortYear.substring(0, 2);
    int decade = Integer.parseInt(prefix);
    int year = decade >= 50 ? 1900 + decade : 2000 + decade;
    return String.format(Locale.ROOT, "%ds", year);
  }

  private static String joined(Iterable<String> values) {
    StringBuilder result = new StringBuilder();
    for (String value : values) {
      if (result.length() > 0) result.append('|');
      result.append(value);
    }
    return result.toString();
  }

  private static void append(StringBuilder result, String value) {
    if (result.length() > 0) result.append(' ');
    result.append(value);
  }

  private static boolean toggle(LinkedHashSet<String> selected, String value) {
    if (selected.remove(value)) return false;
    selected.add(value);
    return true;
  }

  private static boolean contains(String[] values, String value) {
    for (String candidate : values) if (candidate.equals(value)) return true;
    return false;
  }
}
