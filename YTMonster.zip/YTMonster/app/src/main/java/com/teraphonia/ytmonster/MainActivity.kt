package com.teraphonia.ytmonster

import android.app.Activity
import androidx.appcompat.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.app.PictureInPictureParams
import android.os.Build
import android.util.Rational
import android.view.WindowManager
import java.util.zip.ZipInputStream
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import java.io.*
import java.net.URLEncoder
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class Track(val folder:String, val song:String, val artist:String)
enum class RowState { PENDING, FOUND, RETRY, CHECK }

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var progressText: TextView
    private lateinit var counters: TextView
    private lateinit var current: TextView
    private lateinit var progress: ProgressBar
    private val tracks = mutableListOf<Track>()
    private val states = mutableListOf<RowState>()
    private var index = 0
    private var running = false
    private var paused = false
    private var activityVisible = true
    private var inPip = false
    private var attempt = 0
    private var lastProgressAt = 0L
    private var searchToken = 0
    private var checkedToken = -1
    private val handler = Handler(Looper.getMainLooper())

    private val pickCsv = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) loadCsv(uri)
    }
    private val importZip = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importCollection(uri)
    }
    private val exportZip = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) writeZip(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
        web=findViewById(R.id.web); status=findViewById(R.id.status)
        progressText=findViewById(R.id.progressText); counters=findViewById(R.id.counters)
        current=findViewById(R.id.current); progress=findViewById(R.id.progress)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = true
        web.webViewClient = object: WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u=request?.url?.toString().orEmpty()
                // If normal user navigation reaches a concrete watch URL, save it.
                if (running && !paused && activityVisible && u.startsWith("https://www.youtube.com/watch?v=")) {
                    val id = Regex("""[?&]v=([A-Za-z0-9_-]{11})""").find(u)?.groupValues?.get(1)
                    if (id != null) {
                        saveFound("https://www.youtube.com/watch?v=$id")
                        return true
                    }
                }
                return false
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                if (running && !paused && activityVisible && url?.contains("/results?")==true) {
                    handler.postDelayed({ inspectResults(searchToken) }, 1600)
                }
            }
        }

        findViewById<Button>(R.id.loadCsv).setOnClickListener { pickCsv.launch(arrayOf("text/*","text/csv","application/csv")) }
        findViewById<Button>(R.id.start).setOnClickListener { startAuto() }
        findViewById<Button>(R.id.pause).setOnClickListener { togglePause() }
        findViewById<Button>(R.id.importZip).setOnClickListener {
            if (running && !paused) togglePause()
            importZip.launch(arrayOf("application/zip", "application/octet-stream"))
        }
        findViewById<Button>(R.id.popup).setOnClickListener { openPip() }
        findViewById<Button>(R.id.stop).setOnClickListener { running=false; paused=false; setAwake(false); saveSession(); status.text="STOPPED · progress saved" }
        findViewById<Button>(R.id.export).setOnClickListener { exportZip.launch("YTMonster_Collection.zip") }

        loadBundledCsv()
        restoreSession()
        handler.post(watchdog)
    }

    private fun loadBundledCsv() {
        try {
            val lines=assets.open("BrakeMonster_1500_Song_Master_FILLED.csv").bufferedReader(Charsets.UTF_8).readLines()
            populateTracks(lines)
            status.text="READY · ${tracks.size} songs · import ZIP or AUTO START"
        } catch (e: Exception) { status.text="CSV ERROR · ${e.message}" }
    }

    private fun populateTracks(lines: List<String>) {
        tracks.clear(); states.clear(); index=0
        lines.drop(1).forEach { line ->
            val c=parseCsv(line)
            if(c.size>=3 && c.take(3).all { it.isNotBlank() }) {
                val t=Track(c[0],c[1],c[2]); tracks+=t
                states+=if (validYt(File(filesDir,"yt/${safe(t.folder)}/${safe(t.song)} - ${safe(t.artist)}.yt"))) RowState.FOUND else RowState.PENDING
            }
        }
        updateUi()
    }

    private fun loadCsv(uri: Uri) {
        if(running) { Toast.makeText(this,"Pause/stop AUTO before changing CSV",Toast.LENGTH_LONG).show(); return }
        val lines=contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readLines() } ?: return
        populateTracks(lines)
        saveSession(); status.text="CSV LOADED · ${tracks.size} songs"
    }

    private fun parseCsv(line:String):List<String>{
        val out=mutableListOf<String>(); val b=StringBuilder(); var q=false; var i=0
        while(i<line.length){
            val ch=line[i]
            if(ch=='"'){
                if(q && i+1<line.length && line[i+1]=='"'){ b.append('"'); i++ } else q=!q
            } else if(ch==',' && !q){ out+=b.toString(); b.clear() } else b.append(ch)
            i++
        }; out+=b.toString(); return out
    }

    private fun startAuto(){
        if(tracks.isEmpty()){ Toast.makeText(this,"Load CSV first",Toast.LENGTH_LONG).show(); return }
        if (running && paused) { togglePause(); return }
        if (running) return
        running=true; paused=false; setAwake(true)
        index = states.indexOfFirst { it != RowState.FOUND }.let { if(it<0) tracks.size else it }
        attempt=0; processCurrent()
    }

    private fun processCurrent(){
        if(!running || paused || !activityVisible) return
        if(index>=tracks.size){
            // Unresolved rows are CHECK; finish instead of looping forever.
            running=false; setAwake(false); status.text="DONE · EXPORT ZIP"; updateUi(); return
        }
        while(index<tracks.size && states[index]==RowState.FOUND) index++
        if(index>=tracks.size){ running=false; setAwake(false); status.text="DONE · EXPORT ZIP"; updateUi(); return }
        val t=tracks[index]
        current.text="${t.song} — ${t.artist}"
        val query=URLEncoder.encode("${t.song} ${t.artist} official","UTF-8")
        searchToken++
        checkedToken = -1
        lastProgressAt=System.currentTimeMillis()
        status.text="SEARCHING ${index+1}/${tracks.size} · WATCHDOG 🟢"
        web.loadUrl("https://www.youtube.com/results?search_query=$query")
        saveSession(); updateUi()
    }

    // Read visible search-result links only. Never run video playback or bypass verification.
    private fun inspectResults(token: Int) {
        if (!running || paused || !activityVisible || token != searchToken || index !in tracks.indices) return
        if (checkedToken == token) return
        val js = """(function(){return JSON.stringify(Array.from(document.querySelectorAll('a[href*="watch?v="]')).map(a=>({href:a.href,title:(a.getAttribute('title')||a.getAttribute('aria-label')||a.innerText||a.closest('ytd-video-renderer, ytd-rich-grid-media')?.innerText||'').slice(0,250)})).filter(x=>x.href&&x.title).slice(0,35));})()"""
        web.evaluateJavascript(js) { encoded ->
            if (!running || paused || !activityVisible || token != searchToken || index !in tracks.indices) return@evaluateJavascript
            val raw = try { org.json.JSONTokener(encoded).nextValue() as? String ?: "[]" } catch (_:Exception) { "[]" }
            val a = try { JSONArray(raw) } catch (_:Exception) { JSONArray() }
            val t=tracks[index]
            fun norm(v:String)=v.lowercase(java.util.Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}]+")," ").trim()
            val song=norm(t.song); val artist=norm(t.artist)
            val artistTokens=artist.split(' ').filter{it.length>2}
            var bestUrl:String?=null; var bestScore=-100
            for (i in 0 until a.length()) {
                val o=a.optJSONObject(i)?:continue
                val title=norm(o.optString("title"))
                val url=o.optString("href")
                val id=Regex("[?&]v=([A-Za-z0-9_-]{11})").find(url)?.groupValues?.get(1)?:continue
                if (!title.contains(song) || artistTokens.none { title.contains(it) }) continue
                var score=10
                if(title.contains(artist))score+=6
                if(title.contains("official"))score+=4
                if(title.contains("audio"))score+=2
                if(title.contains("live") && !song.contains("live"))score-=5
                if(title.contains("cover") || title.contains("karaoke") || title.contains("reaction"))score-=12
                if(score>bestScore){bestScore=score;bestUrl="https://www.youtube.com/watch?v=$id"}
            }
            if(bestUrl!=null && bestScore>=10){ checkedToken=token; saveFound(bestUrl!!) }
            else { checkedToken=token; status.text="NO CONFIDENT MATCH · RETRY" }
        }
    }

    // One bounded retry per row; no endless reload of the same page.
    private val watchdog=object:Runnable{
        override fun run(){
            if(running && !paused && activityVisible && index in tracks.indices){
                val age=System.currentTimeMillis()-lastProgressAt
                val url=web.url.orEmpty()
                val human=url.contains("consent",true) || url.contains("sorry",true) || web.title.orEmpty().contains("captcha",true)
                if(human){
                    states[index]=RowState.CHECK; index++; attempt=0; processCurrent()
                } else if(age>18000){
                    if(attempt>=1){ states[index]=RowState.CHECK; index++; attempt=0; processCurrent() }
                    else { attempt++; states[index]=RowState.RETRY; processCurrent() }
                } else if(age>6000 && checkedToken!=searchToken){ inspectResults(searchToken) }
            }
            handler.postDelayed(this,3000)
        }
    }

    private fun saveFound(url:String){
        if(index !in tracks.indices) return
        val t=tracks[index]
        val dir=File(filesDir,"yt/${safe(t.folder)}").apply{mkdirs()}
        File(dir,"${safe(t.song)} - ${safe(t.artist)}.yt").writeText(url+"\n")
        states[index]=RowState.FOUND; index++; attempt=0
        saveSession(); updateUi(); processCurrent()
    }

    private fun safe(s:String)=s.replace(Regex("""[\\/:*?"<>|]"""),"_").trim()

    private fun saveSession(){
        val p=getSharedPreferences("ytm",MODE_PRIVATE)
        p.edit().putBoolean("paused",paused).putInt("index",index)
            .putString("states",states.joinToString(","){it.name}).apply()
    }

    private fun restoreSession(){
        // Bundled CSV is loaded on every launch; imported/generated .yt files are authoritative.
        index=states.indexOfFirst { it!=RowState.FOUND }.let { if(it<0) tracks.size else it }
        status.text="READY · ${states.count{it==RowState.FOUND}} saved · AUTO START to continue"
        updateUi()
    }

    private fun updateUi(){
        val found=states.count{it==RowState.FOUND}; val retry=states.count{it==RowState.RETRY}; val check=states.count{it==RowState.CHECK}
        progressText.text="${minOf(index+1,tracks.size)} / ${tracks.size}"
        counters.text="FOUND $found   ·   RETRY $retry   ·   CHECK $check"
        progress.progress=if(tracks.isEmpty())0 else (found*1000/tracks.size)
    }

    private fun validYt(file:File):Boolean = try {
        file.isFile && Regex("^https://www\\.youtube\\.com/watch\\?v=[A-Za-z0-9_-]{11}\\s*$").matches(file.readText().trim())
    } catch (_:Exception) { false }

    private fun importCollection(uri:Uri) {
        if(running && !paused) togglePause()
        var added=0; var skipped=0; var invalid=0
        val base=File(filesDir,"yt").canonicalFile
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                ZipInputStream(BufferedInputStream(input)).use { zip ->
                    while(true) {
                        val entry=zip.nextEntry ?: break
                        if(entry.isDirectory || !entry.name.endsWith(".yt",true)) { zip.closeEntry(); continue }
                        val name=entry.name.replace('\\','/')
                        val parts=name.split('/').filter { it.isNotBlank() }
                        if(parts.size!=2 || parts.any { it==".." || it=="." } || parts[0].contains(':')) { invalid++; zip.closeEntry(); continue }
                        val target=File(base,parts.joinToString("/"))
                        if(!target.canonicalPath.startsWith(base.path+File.separator)) { invalid++; zip.closeEntry(); continue }
                        val bytes=ByteArrayOutputStream(); val buf=ByteArray(4096)
                        while(bytes.size()<1024) { val n=zip.read(buf,0,minOf(buf.size,1024-bytes.size())); if(n<0)break; bytes.write(buf,0,n) }
                        val value=bytes.toString("UTF-8").trim()
                        if(!Regex("^https://www\\.youtube\\.com/watch\\?v=[A-Za-z0-9_-]{11}$").matches(value)) { invalid++; zip.closeEntry(); continue }
                        if(validYt(target)) skipped++ else { target.parentFile?.mkdirs(); target.writeText(value+"\n"); added++ }
                        zip.closeEntry()
                    }
                }
            }
            tracks.forEachIndexed { i,t ->
                if(validYt(File(base,"${safe(t.folder)}/${safe(t.song)} - ${safe(t.artist)}.yt"))) states[i]=RowState.FOUND
            }
            index=states.indexOfFirst { it!=RowState.FOUND }.let { if(it<0) tracks.size else it }
            attempt=0; checkedToken=-1; searchToken++
            web.stopLoading()
            saveSession(); updateUi()
            status.text="IMPORT · +$added · existing $skipped · invalid $invalid"
            Toast.makeText(this,"Imported $added; skipped $skipped; invalid $invalid",Toast.LENGTH_LONG).show()
        } catch(e:Exception) { status.text="IMPORT ERROR · ${e.message}" }
    }

    private fun togglePause() {
        if(!running) { status.text="Not running · press AUTO START"; return }
        paused=!paused
        if(paused) {
            searchToken++ // invalidate pending WebView/JS callbacks before import
            web.stopLoading()
            setAwake(false); status.text="PAUSED · safe to import/export"
        }
        else { setAwake(true); attempt=0; processCurrent() }
        findViewById<Button>(R.id.pause).text=if(paused)"RESUME" else "PAUSE"
        saveSession()
    }

    private fun setAwake(enabled:Boolean) {
        if(enabled) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun openPip() {
        if (Build.VERSION.SDK_INT >= 26 && packageManager.hasSystemFeature("android.software.picture_in_picture")) {
            try {
                val params = PictureInPictureParams.Builder().setAspectRatio(Rational(1, 1)).build()
                val entered = enterPictureInPictureMode(params)
                if (!entered) status.text = "PiP not available on this device"
            } catch (e: Exception) { status.text = "PiP unavailable: ${e.message}" }
        } else status.text = "PiP not supported on this device"
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode:Boolean, newConfig:android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode,newConfig)
        inPip=isInPictureInPictureMode
    }

    override fun onPause() {
        super.onPause()
        if(!inPip && !isInPictureInPictureMode) { activityVisible=false; if(running && !paused) status.text="BACKGROUND · watchdog suspended" }
    }
    override fun onResume() {
        super.onResume(); activityVisible=true
        if(running && !paused && ::web.isInitialized) { attempt=0; processCurrent() }
    }
    override fun onDestroy() { setAwake(false); handler.removeCallbacks(watchdog); super.onDestroy() }

    private fun writeZip(uri:Uri){
        contentResolver.openOutputStream(uri)?.use { os ->
            ZipOutputStream(BufferedOutputStream(os)).use { z ->
                val base=File(filesDir,"yt")
                if(base.exists()) base.walkTopDown().filter{it.isFile && it.extension=="yt"}.forEach { f ->
                    val name=f.relativeTo(base).invariantSeparatorsPath
                    z.putNextEntry(ZipEntry(name)); f.inputStream().use{it.copyTo(z)}; z.closeEntry()
                }
            }
        }
        Toast.makeText(this,"ZIP exported",Toast.LENGTH_LONG).show()
    }
}
