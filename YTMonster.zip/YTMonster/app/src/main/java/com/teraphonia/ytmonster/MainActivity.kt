package com.teraphonia.ytmonster

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.*
import java.net.URLEncoder
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class Track(val folder:String, val song:String, val artist:String)
enum class RowState { PENDING, FOUND, RETRY, CHECK }

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var progressText: TextView
    private lateinit var counters: TextView
    private lateinit var current: TextView
    private lateinit var progress: ProgressBar
    private val tracks = mutableListOf<Track>()
    private val states = mutableListOf<RowState>()
    private var index = 0
    private var running = false
    private var attempt = 0
    private var lastProgressAt = 0L
    private val handler = Handler(Looper.getMainLooper())

    private val pickCsv = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) loadCsv(uri)
    }
    private val exportZip = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) writeZip(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
        web=findViewById(R.id.web); status=findViewById(R.id.status)
        progressText=findViewById(R.id.progressText); counters=findViewById(R.id.counters)
        current=findViewById(R.id.current); progress=findViewById(R.id.progress)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = true
        web.webViewClient = object: WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u=request?.url?.toString().orEmpty()
                // If normal user navigation reaches a concrete watch URL, save it.
                if (running && u.startsWith("https://www.youtube.com/watch?v=")) {
                    val id = Regex("""[?&]v=([A-Za-z0-9_-]{11})""").find(u)?.groupValues?.get(1)
                    if (id != null) {
                        saveFound("https://www.youtube.com/watch?v=$id")
                        return true
                    }
                }
                return false
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                lastProgressAt=System.currentTimeMillis()
                status.text="RUNNING · WATCHDOG 🟢"
            }
        }

        findViewById<Button>(R.id.loadCsv).setOnClickListener { pickCsv.launch(arrayOf("text/*","text/csv","application/csv")) }
        findViewById<Button>(R.id.start).setOnClickListener { startAuto() }
        findViewById<Button>(R.id.stop).setOnClickListener { running=false; status.text="STOPPED · progress saved" }
        findViewById<Button>(R.id.export).setOnClickListener { exportZip.launch("YTMonster_Collection.zip") }

        restoreSession()
        handler.post(watchdog)
    }

    private fun loadCsv(uri: Uri) {
        tracks.clear(); states.clear(); index=0
        contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.useLines { seq ->
            seq.drop(1).forEach { line ->
                val c=parseCsv(line)
                if(c.size>=3 && c[0].isNotBlank() && c[1].isNotBlank() && c[2].isNotBlank()){
                    tracks += Track(c[0],c[1],c[2]); states += RowState.PENDING
                }
            }
        }
        getSharedPreferences("ytm",MODE_PRIVATE).edit().clear().apply()
        updateUi(); status.text="CSV LOADED · ${tracks.size} songs"
    }

    private fun parseCsv(line:String):List<String>{
        val out=mutableListOf<String>(); val b=StringBuilder(); var q=false; var i=0
        while(i<line.length){
            val ch=line[i]
            if(ch=='"'){
                if(q && i+1<line.length && line[i+1]=='"'){ b.append('"'); i++ } else q=!q
            } else if(ch==',' && !q){ out+=b.toString(); b.clear() } else b.append(ch)
            i++
        }; out+=b.toString(); return out
    }

    private fun startAuto(){
        if(tracks.isEmpty()){ Toast.makeText(this,"Load CSV first",Toast.LENGTH_LONG).show(); return }
        running=true
        index = states.indexOfFirst { it != RowState.FOUND }.let { if(it<0) 0 else it }
        attempt=0; processCurrent()
    }

    private fun processCurrent(){
        if(!running) return
        if(index>=tracks.size){
            val retry=states.indexOfFirst { it==RowState.RETRY }
            if(retry>=0){ index=retry; attempt=0; processCurrent(); return }
            running=false; status.text="DONE · EXPORT ZIP"; updateUi(); return
        }
        if(states[index]==RowState.FOUND){ index++; processCurrent(); return }
        val t=tracks[index]
        current.text="${t.song} — ${t.artist}"
        val query=URLEncoder.encode("${t.song} ${t.artist} official","UTF-8")
        lastProgressAt=System.currentTimeMillis()
        status.text="SEARCHING ${index+1}/${tracks.size} · WATCHDOG 🟢"
        web.loadUrl("https://www.youtube.com/results?search_query=$query")
        saveSession(); updateUi()
    }

    // Watchdog: ordinary stalls retry; after 3 tries move row to CHECK and continue.
    // It intentionally does not attempt to bypass CAPTCHA, consent, or other human verification.
    private val watchdog=object:Runnable{
        override fun run(){
            if(running && tracks.isNotEmpty()){
                val age=System.currentTimeMillis()-lastProgressAt
                val url=web.url.orEmpty()
                val human=url.contains("consent",true) || url.contains("sorry",true) || web.title.orEmpty().contains("captcha",true)
                if(human){
                    states[index]=RowState.CHECK; index++; attempt=0
                    status.text="HUMAN CHECK skipped · continuing"; processCurrent()
                } else if(age>60000){
                    attempt++
                    if(attempt>=3){ states[index]=RowState.CHECK; index++; attempt=0; processCurrent() }
                    else { states[index]=RowState.RETRY; web.stopLoading(); processCurrent() }
                } else if(age>40000){
                    web.stopLoading(); processCurrent()
                } else if(age>20000){
                    web.reload(); lastProgressAt=System.currentTimeMillis()
                }
            }
            handler.postDelayed(this,5000)
        }
    }

    private fun saveFound(url:String){
        if(index !in tracks.indices) return
        val t=tracks[index]
        val dir=File(filesDir,"yt/${safe(t.folder)}").apply{mkdirs()}
        File(dir,"${safe(t.song)} - ${safe(t.artist)}.yt").writeText(url+"\n")
        states[index]=RowState.FOUND; index++; attempt=0
        saveSession(); updateUi(); processCurrent()
    }

    private fun safe(s:String)=s.replace(Regex("""[\\/:*?"<>|]"""),"_").trim()

    private fun saveSession(){
        val p=getSharedPreferences("ytm",MODE_PRIVATE)
        p.edit().putInt("index",index)
            .putString("states",states.joinToString(","){it.name}).apply()
    }

    private fun restoreSession(){
        // CSV itself must be reloaded after process death; generated .yt files remain on disk.
        status.text="READY · generated files survive restart"
    }

    private fun updateUi(){
        val found=states.count{it==RowState.FOUND}; val retry=states.count{it==RowState.RETRY}; val check=states.count{it==RowState.CHECK}
        progressText.text="${minOf(index+1,tracks.size)} / ${tracks.size}"
        counters.text="FOUND $found   ·   RETRY $retry   ·   CHECK $check"
        progress.progress=if(tracks.isEmpty())0 else (found*1000/tracks.size)
    }

    private fun writeZip(uri:Uri){
        contentResolver.openOutputStream(uri)?.use { os ->
            ZipOutputStream(BufferedOutputStream(os)).use { z ->
                val base=File(filesDir,"yt")
                if(base.exists()) base.walkTopDown().filter{it.isFile && it.extension=="yt"}.forEach { f ->
                    val name=f.relativeTo(base).invariantSeparatorsPath
                    z.putNextEntry(ZipEntry(name)); f.inputStream().use{it.copyTo(z)}; z.closeEntry()
                }
            }
        }
        Toast.makeText(this,"ZIP exported",Toast.LENGTH_LONG).show()
    }
}
