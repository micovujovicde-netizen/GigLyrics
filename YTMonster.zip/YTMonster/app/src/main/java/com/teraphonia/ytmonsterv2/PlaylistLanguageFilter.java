package com.teraphonia.ytmonsterv2;

import java.text.Normalizer;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Conservative, low-quota language relevance filter for YouTube playlist samples.
 * Uses song titles and optional YouTube language metadata, NOT regionCode as proof.
 * Can return UNKNOWN; language of actual audio cannot be guaranteed from metadata.
 */
final class PlaylistLanguageFilter {
  private PlaylistLanguageFilter() {}

  static String forRegion(String country) {
    if (country == null) return null;
    switch (country) {
      case "RS": case "ME": case "BA": case "HR": return "sh"; // shared BCS title vocabulary
      case "SI": return "sl";
      case "US": case "GB": case "CA": case "AU": return "en";
      case "DE": return "de";
      case "FR": return "fr";
      case "IT": return "it";
      case "ES": case "MX": return "es";
      case "BR": return "pt";
      case "JP": return "ja";
      // India has several major languages; do not assume all Indian music is Hindi.
      case "IN": return null;
      default: return null;
    }
  }

  static String relevanceLanguage(String country) {
    String lang = forRegion(country);
    if (lang == null) return null;
    return lang.equals("sh") ? ("HR".equals(country) ? "hr" : ("BA".equals(country) ? "bs" : "sr")) : lang;
  }

  static String queryHint(String country) {
    if (country == null) return "";
    switch (country) {
      case "RS": return "srpska muzika";
      case "ME": return "crnogorska muzika";
      case "BA": return "bosanska muzika";
      case "HR": return "hrvatska glazba";
      case "SI": return "slovenska glasba";
      case "DE": return "deutsche musik";
      case "FR": return "musique française";
      case "IT": return "musica italiana";
      case "ES": return "música española";
      case "MX": return "música mexicana";
      case "BR": return "música brasileira";
      case "JP": return "日本の音楽";
      case "IN": return "Indian music";
      default: return "";
    }
  }

  private static final Set<String> BCS = words(
      "ljubav volim voli volis volim tebe tebi meni moja moje moj tvoje tvoja zivot zivota " +
      "sreca sretan srecan nesreca srce srca srce moje noc noci nocas oci duso dusa " +
      "kuca kuce zena zene covek covjek ljudi devojka djevojka djevojko beograd " +
      "srbija srpska bosna bosanski hrvatska crna gora zagreb sarajevo podgorica " +
      "kada kad ako nije nisam nismo nemoj nikad nikada sam si smo sebi svijet svet " +
      "samo opet gde gdje zasto zasto ljubavi nema ima bili bila s tobom moja draga " +
      "dobro dosla dosao pjesma pesma jedina zauvek zauvijek suze suza boli bol " +
      "daleko tuzna tuga novi novo stara stari sve sto sto necu hocu ceca seka " +
      "zidovi crno zlatno kolo narodna narodnjaci domaca domaci srpski " +
      "hrvatski bosanski crnogorski balkan balkanski exyu kafana kafanske narodnih");
  private static final Set<String> EN = words(
      "kids children wedding party happy songs song music dance dancing best hits love " +
      "summer winter tonight forever together dream dreaming never always feeling feel " +
      "your mine sweet heart broken baby girl boy beautiful world sunshine english " +
      "birthday christmas rockstar another somebody everybody dancefloor top popular");
  private static final Set<String> DE = words("liebe herz nacht dich mein meine deine leben musik deutsch deutsche lieder schlager heute immer nie traume traum");
  private static final Set<String> FR = words("amour coeur nuit toi moi pour avec sans toujours jamais chanson chansons musique francais francaise belle vie");
  private static final Set<String> IT = words("amore cuore notte vita per sempre mia mio senza con bella canzone canzoni musica italiana");
  private static final Set<String> ES = words("amor corazon noche vida para contigo sin siempre nunca canciones cancion musica espanol latina latina corazon");
  private static final Set<String> PT = words("amor coracao noite vida para voce comigo sem sempre nunca cancao cancoes musica brasileira saudade");
  private static final Set<String> SL = words("ljubezen srce noc zate moj moja tvoje pesem pesmi glasba slovenska sreca vedno nikoli zivljenje");
  private static Set<String> words(String list) {
    HashSet<String> set = new HashSet<>();
    for (String word : list.split("\\s+")) set.add(word);
    return set;
  }
  private static String normalized(String value) {
    if (value == null) return "";
    String s = Normalizer.normalize(value.toLowerCase(Locale.ROOT), Normalizer.Form.NFD);
    return s.replaceAll("\\p{M}", "").replace('đ','d').replace('ß','s');
  }
  private static Set<String> tokenSet(String title) {
    Set<String> found = new HashSet<>();
    for (String t : normalized(title).split("[^\\p{L}]+")) if (t.length() > 1) found.add(t);
    return found;
  }
  private static boolean matchesLanguageTag(String tag, String expected) {
    if (tag == null || tag.isEmpty()) return false;
    String t = tag.toLowerCase(Locale.ROOT).replace('_','-').split("-")[0];
    if (expected.equals("sh")) return t.equals("sr") || t.equals("hr") || t.equals("bs") || t.equals("cnr") || t.equals("sh");
    return expected.equals(t);
  }
  private static int dictionaryCount(Set<String> tokens, Set<String> vocabulary) {
    int count = 0;
    for (String w : tokens) if (vocabulary.contains(w)) count++;
    return count;
  }
  private static Set<String> dictionary(String lang) {
    switch (lang) {
      case "sh": return BCS;
      case "en": return EN;
      case "de": return DE;
      case "fr": return FR;
      case "it": return IT;
      case "es": return ES;
      case "pt": return PT;
      case "sl": return SL;
      default: return new HashSet<>();
    }
  }

  /** +1 relevant, -1 mismatched, 0 no sufficient signal. */
  static int classifyTitle(String title, String languageTag, String expected) {
    if (expected == null) return 1;
    if (languageTag != null && !languageTag.trim().isEmpty()) {
      // Real metadata is stronger than a translated/English marketing title.
      return matchesLanguageTag(languageTag, expected) ? 1 : -1;
    }
    String original = title == null ? "" : title;
    if (expected.equals("ja") && original.matches(".*[\\u3040-\\u30ff\\u4e00-\\u9fff].*")) return 1;
    if (expected.equals("sh") && original.matches(".*[абвгдђежзијклљмнњопрстћуфхцчџшАБВГДЂЕЖЗИЈКЛЉМНЊОПРСТЋУФХЦЧЏШ].*")) return 1;
    Set<String> tokens = tokenSet(original);
    int matched = dictionaryCount(tokens, dictionary(expected));
    int english = dictionaryCount(tokens, EN);
    if (matched >= 1 && matched >= english) return 1;
    if (!expected.equals("en") && english >= 2 && matched == 0) return -1;
    if (expected.equals("en") && dictionaryCount(tokens, BCS) >= 2 && english == 0) return -1;
    return 0;
  }

  static boolean clearlyWrongLanguage(List<String> sampledTrackTitles, String expected) {
    int yes=0,no=0;
    for (String title : sampledTrackTitles) {
      int result = classifyTitle(title, null, expected);
      if(result>0) yes++;
      if(result<0) no++;
    }
    return no >= 3 && yes == 0;
  }

  /** Accept only if sampled track names/metadata show positive language evidence. */
  static boolean matchesPlaylist(List<String> sampledTrackTitles, String expected) {
    if (expected == null) return true;
    int yes = 0, no = 0;
    for (String title : sampledTrackTitles) {
      int c = classifyTitle(title, null, expected);
      if (c > 0) yes++;
      if (c < 0) no++;
    }
    return yes >= 2 && yes > no;
  }
}
