package com.teraphonia.ytmonsterv2;

import android.app.*;
import android.os.*;
import android.net.Uri;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

public class MainActivity extends Activity {
  private EditText keyInput, linkInput, searchInput;
  private TextView keyLabel;
  private LinearLayout resultsBox;
  private Spinner countrySpinner;
  private int mode=0;
  private String category="PARTY";
  private String activeRegionCode=null;
  private final ArrayList<Candidate> candidates=new ArrayList<>();
  private Button[] categoryButtons=new Button[4];
  private Button enterButton;
  private TextView status;
  private Button fetchButton, exportButton;
  private final ArrayList<Track> tracks = new ArrayList<>();
  private String folderName="YouTube Playlist";
  private volatile boolean busy=false;
  private static final int CREATE_ZIP=27;
  private static class Candidate {
    String id,title,kind; long views,duration; int relevance;
    Candidate(String i,String t,String k,long v,long d,int r){id=i;title=t;kind=k;views=v;duration=d;relevance=r;}
  }
  private static class Track { final String title,id; Track(String t,String i){title=t;id=i;} }

  @Override public void onCreate(Bundle b){ super.onCreate(b);
    LinearLayout outer=new LinearLayout(this);outer.setOrientation(1);outer.setPadding(22,20,22,12);outer.setBackgroundColor(Color.rgb(10,25,19));
    ScrollView sc=new ScrollView(this);sc.addView(outer);setContentView(sc);
    TextView heading=label("YT MONSTER V2",29,0xffa3ff68);outer.addView(heading);
    outer.addView(label("SEARCH",17,Color.WHITE));
    searchInput=field("Search songs, artists or playlists",false);searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);outer.addView(searchInput);
    LinearLayout catRow=new LinearLayout(this);catRow.setOrientation(LinearLayout.HORIZONTAL);outer.addView(catRow);
    String[] cats={"PARTY","BALLAD","INST","DJ MIX"};
    for(int i=0;i<cats.length;i++){final String c=cats[i];Button b=new Button(this);categoryButtons[i]=b;b.setText(c);b.setTextSize(12);b.setAllCaps(false);b.setPadding(1,0,1,0);catRow.addView(b,new LinearLayout.LayoutParams(0,54,1));b.setOnClickListener(v->selectCategory(c));}
    selectCategory("PARTY");
    outer.addView(label("COUNTRY / REGION",16,Color.WHITE));
    countrySpinner=new Spinner(this);String[] countries={"WORLDWIDE","USA","UK","CANADA","AUSTRALIA","GERMANY","FRANCE","ITALY","SPAIN","SERBIA","MONTENEGRO","CROATIA","BOSNIA","SLOVENIA","JAPAN","INDIA","BRAZIL","MEXICO","OTHER"};
    ArrayAdapter<String> ca=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,countries);countrySpinner.setAdapter(ca);outer.addView(countrySpinner);
    enterButton=button("SEARCH",outer);enterButton.setOnClickListener(v->search());
    searchInput.setOnEditorActionListener((v,action,event)->{if(action==EditorInfo.IME_ACTION_SEARCH||(event!=null&&event.getKeyCode()==KeyEvent.KEYCODE_ENTER)){search();return true;}return false;});
    resultsBox=new LinearLayout(this);resultsBox.setOrientation(LinearLayout.VERTICAL);outer.addView(resultsBox);
    keyLabel=label("YOUTUBE DATA API V3 KEY",18,Color.WHITE);outer.addView(keyLabel);
    keyInput=field("Paste your API key",true);outer.addView(keyInput);
    String savedKey=getPreferences(0).getString("api_key","");keyInput.setText(savedKey);
    if(!savedKey.isEmpty()){keyInput.setVisibility(View.GONE);keyLabel.setVisibility(View.GONE);}
    outer.addView(label("DIRECT PLAYLIST LINK (optional)",18,Color.WHITE));
    linkInput=field("https://www.youtube.com/playlist?list=...",false);outer.addView(linkInput);
    fetchButton=button("LOAD PLAYLIST",outer);fetchButton.setOnClickListener(v->fetch());
    exportButton=button("EXPORT ZIP (.yt)",outer);exportButton.setEnabled(false);exportButton.setOnClickListener(v->{if(busy)return;openZipPicker();});
    status=label("Ready. Search for music or load a playlist.",19,Color.WHITE);outer.addView(status);
    restoreTracks();
  }
  private TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(0,12,0,12);return t;}
  private EditText field(String hint,boolean password){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(20);e.setHint(hint);e.setHintTextColor(0xffb1b1b1);e.setTextColor(Color.WHITE);e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xffa3ff68));if(password)e.setInputType(129);return e;}
  private Button button(String s,LinearLayout parent){Button b=new Button(this);b.setTextColor(Color.BLACK);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));b.setText(s);b.setTextSize(18);b.setAllCaps(false);parent.addView(b,new LinearLayout.LayoutParams(-1,72));return b;}
  private void setActive(Button b,boolean active){b.setTextColor(active?Color.WHITE:Color.BLACK);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(active?0xff277c42:Color.WHITE));}
  private void selectCategory(String c){category=c;for(int i=0;i<categoryButtons.length;i++)setActive(categoryButtons[i],new String[]{"PARTY","BALLAD","INST","DJ MIX"}[i].equals(c));}
  private String regionCode(){String c=(String)countrySpinner.getSelectedItem();Map<String,String> m=new HashMap<>();m.put("USA","US");m.put("UK","GB");m.put("CANADA","CA");m.put("AUSTRALIA","AU");m.put("GERMANY","DE");m.put("FRANCE","FR");m.put("ITALY","IT");m.put("SPAIN","ES");m.put("SERBIA","RS");m.put("MONTENEGRO","ME");m.put("CROATIA","HR");m.put("BOSNIA","BA");m.put("SLOVENIA","SI");m.put("JAPAN","JP");m.put("INDIA","IN");m.put("BRAZIL","BR");m.put("MEXICO","MX");return m.get(c);}
  private String apiKey(){String key=getPreferences(0).getString("api_key","");if(key.isEmpty()&&keyInput!=null)key=keyInput.getText().toString().trim();return key;}
  private String buildQuery(String submitted){StringBuilder q=new StringBuilder(submitted.trim());if(category.equals("PARTY"))q.append(" party dance music");else if(category.equals("BALLAD"))q.append(" ballad slow song");else if(category.equals("INST"))q.append(" instrumental music");else q.append(" continuous DJ mix");return q.toString().trim();}
  private int tokenScore(String title,String query,String searchCategory){String t=title.toLowerCase(Locale.ROOT);String[] words=query.toLowerCase(Locale.ROOT).split("\\W+");int score=0;for(String w:words)if(w.length()>1&&t.contains(w))score+=3;if(searchCategory.equals("DJ MIX")&&(t.contains("mix")||t.contains("dj")))score+=8;if(searchCategory.equals("BALLAD")&&(t.contains("ballad")||t.contains("love song")))score+=5;if(searchCategory.equals("INST")&&(t.contains("instrumental")||t.contains("karaoke")))score+=5;return score;}
  private void search(){if(busy)return;final String submitted=searchInput.getText().toString().trim();if(submitted.isEmpty()){report("Enter a search query.");return;}final String key=apiKey();if(key.isEmpty()){report("Enter your YouTube Data API key.");keyInput.requestFocus();return;}
    final String selectedCategory=category;final String country=regionCode();activeRegionCode=country;final String q=buildQuery(submitted);searchInput.setText("");
    busy=true;enterButton.setEnabled(false);exportButton.setEnabled(false);candidates.clear();tracks.clear();resultsBox.removeAllViews();report("Searching: "+q);
    new Thread(()->{try{
      if(selectedCategory.equals("DJ MIX"))searchVideos(q,key,country,selectedCategory,true);
      else {searchVideos(q,key,country,selectedCategory,false);searchPlaylists(q,key,country,selectedCategory);}
      if(candidates.isEmpty())report("No eligible results found.");else showTopResults();
    }catch(Exception e){report("SEARCH ERROR: "+safeMessage(e));}finally{busy=false;runOnUiThread(()->{enterButton.setEnabled(true);});}}).start();
  }
  private void searchVideos(String q,String key,String country,String searchCategory,boolean mixes)throws Exception{
    String params="part=snippet&type=video&maxResults=50&order=relevance&q="+enc(q)+(country==null?"":"&regionCode="+enc(country))+(mixes?"&videoDuration=long":"");
    JSONObject found=api("search",params,key);JSONArray rows=found.optJSONArray("items");if(rows==null)return;
    ArrayList<String> ids=new ArrayList<>();HashMap<String,String> titles=new HashMap<>();for(int i=0;i<rows.length();i++){JSONObject r=rows.getJSONObject(i);JSONObject idObj=r.optJSONObject("id");String id=idObj==null?"":idObj.optString("videoId","");if(id.matches("[A-Za-z0-9_-]{11}")&&!titles.containsKey(id)){ids.add(id);titles.put(id,r.getJSONObject("snippet").optString("title",id));}}
    Map<String,JSONObject> details=videoDetails(ids,key);for(int i=0;i<ids.size();i++){String id=ids.get(i);JSONObject v=details.get(id);if(v==null)continue;long min=mixes?1800:0,max=mixes?Long.MAX_VALUE:1799;if(!allowed(v,min,max))continue;String title=titles.get(id);if(!mixes&&isLongMixTitle(title))continue;long sec=duration(v);long views=v.optJSONObject("statistics")==null?0:v.getJSONObject("statistics").optLong("viewCount",0);candidates.add(new Candidate(id,title,mixes?"mix":"video",views,sec,tokenScore(title,q,searchCategory)+(50-i)));}
  }
  private void searchPlaylists(String q,String key,String country,String searchCategory)throws Exception{
    String params="part=snippet&type=playlist&maxResults=50&order=relevance&q="+enc(q)+(country==null?"":"&regionCode="+enc(country));JSONObject found=api("search",params,key);JSONArray rows=found.optJSONArray("items");if(rows==null)return;
    for(int i=0;i<rows.length();i++){JSONObject r=rows.getJSONObject(i);JSONObject idObj=r.optJSONObject("id");String id=idObj==null?"":idObj.optString("playlistId","");if(id.isEmpty())continue;String title=r.getJSONObject("snippet").optString("title","Playlist");if(isLongMixTitle(title))continue;boolean duplicate=false;for(Candidate c:candidates)if(c.id.equals(id)){duplicate=true;break;}if(!duplicate)candidates.add(new Candidate(id,title,"playlist",0,0,tokenScore(title,q,searchCategory)+(50-i)));}
  }
  private void showTopResults(){Collections.sort(candidates,(a,b)->Integer.compare(b.relevance,a.relevance));if(candidates.size()>7)candidates.subList(7,candidates.size()).clear();runOnUiThread(()->{resultsBox.removeAllViews();for(int i=0;i<candidates.size();i++){Candidate c=candidates.get(i);String detail=c.kind.equals("mix")?"DJ MIX · "+formatDuration(c.duration):c.kind.equals("playlist")?"YouTube playlist":"Individual track";Button b=new Button(this);b.setAllCaps(false);b.setTextSize(16);b.setText((i+1)+". "+c.title+"\n"+detail);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff245b3d));resultsBox.addView(b,new LinearLayout.LayoutParams(-1,-2));b.setOnClickListener(v->selectCandidate(c));}});}
  private void selectCandidate(Candidate c){if(busy)return;busy=true;exportButton.setEnabled(false);tracks.clear();folderName=c.title;saveTracks();report("Preparing: "+c.title);String key=apiKey();new Thread(()->{try{if(c.kind.equals("video")||c.kind.equals("mix")){tracks.add(new Track(c.title,c.id));saveTracks();}else{ArrayList<String> ids=playlistIds(c.id,key);appendPlaylistTracks(ids,key);}
      saveTracks();if(tracks.isEmpty())throw new Exception("No playable individual tracks were found.");report("Ready: "+tracks.size()+" items in “"+folderName+"”. Export ZIP when ready.");runOnUiThread(()->exportButton.setEnabled(true));
    }catch(Exception e){report("IMPORT ERROR: "+safeMessage(e));}finally{busy=false;}}).start();}
  private ArrayList<String> playlistIds(String id,String key)throws Exception{ArrayList<String> ids=new ArrayList<>();String token="";do{JSONObject page=api("playlistItems","part=contentDetails&maxResults=50&playlistId="+enc(id)+(token.isEmpty()?"":"&pageToken="+enc(token)),key);JSONArray rows=page.optJSONArray("items");if(rows==null)break;for(int i=0;i<rows.length();i++){String vid=rows.getJSONObject(i).getJSONObject("contentDetails").optString("videoId","");if(vid.matches("[A-Za-z0-9_-]{11}"))ids.add(vid);}token=page.optString("nextPageToken","");}while(!token.isEmpty());return ids;}
  private void appendPlaylistTracks(List<String> ids,String key)throws Exception{HashSet<String> seen=new HashSet<>();for(int i=0;i<ids.size();i+=50){List<String> page=ids.subList(i,Math.min(i+50,ids.size()));Map<String,JSONObject> info=videoDetails(page,key);for(String id:page){JSONObject v=info.get(id);if(v!=null&&allowed(v,0,1799)&&!isLongMixTitle(v.getJSONObject("snippet").optString("title",""))&&seen.add(id))tracks.add(new Track(v.getJSONObject("snippet").optString("title",id),id));}saveTracks();report("Prepared "+tracks.size()+" playlist items...");}}
  private Map<String,JSONObject> videoDetails(List<String> ids,String key)throws Exception{Map<String,JSONObject> map=new HashMap<>();for(int i=0;i<ids.size();i+=50){String joined=android.text.TextUtils.join(",",ids.subList(i,Math.min(i+50,ids.size())));JSONObject response=api("videos","part=snippet,contentDetails,status,statistics&id="+enc(joined),key);JSONArray rows=response.optJSONArray("items");if(rows!=null)for(int j=0;j<rows.length();j++){JSONObject v=rows.getJSONObject(j);map.put(v.optString("id"),v);}}return map;}
  private long duration(JSONObject v){try{return java.time.Duration.parse(v.getJSONObject("contentDetails").getString("duration")).getSeconds();}catch(Exception e){return 0;}}
  private boolean allowed(JSONObject v,long minSec,long maxSec){try{JSONObject status=v.getJSONObject("status"),content=v.getJSONObject("contentDetails");if(!status.optBoolean("embeddable",false)||!status.optString("privacyStatus","").equals("public"))return false;
    JSONObject restriction=content.optJSONObject("regionRestriction");String region=activeRegionCode;if(restriction!=null&&region!=null){JSONArray allowed=restriction.optJSONArray("allowed"),blocked=restriction.optJSONArray("blocked");if(allowed!=null&&!has(allowed,region))return false;if(blocked!=null&&has(blocked,region))return false;}
    long sec=duration(v);if(sec<minSec||sec>maxSec)return false;String title=v.getJSONObject("snippet").optString("title","");if(title.toLowerCase(Locale.ROOT).matches(".*\\blive\\b.*"))return false;return true;
  }catch(Exception e){return false;}}
  private boolean isLongMixTitle(String t){String s=t.toLowerCase(Locale.ROOT);return s.contains("dj mix")||s.contains("continuous mix")||s.contains("nonstop mix")||s.contains("non-stop mix")||s.contains("megamix")||s.contains("mega mix")||s.contains("full mix")||s.contains("1 hour mix")||s.contains("2 hour mix");}
  private String formatDuration(long sec){return String.format(Locale.ROOT,"%d:%02d:%02d",sec/3600,(sec%3600)/60,sec%60);}
  private boolean has(JSONArray a,String s){for(int i=0;i<a.length();i++)if(s.equals(a.optString(i)))return true;return false;}
  private void openZipPicker(){if(tracks.isEmpty()){report("No playlist items to export.");return;}Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");i.putExtra(Intent.EXTRA_TITLE,safe(folderName)+".zip");startActivityForResult(i,CREATE_ZIP);}
  private void report(String s){runOnUiThread(()->{if(status!=null)status.setText(s);});}
  private static String parseId(String raw){raw=raw.trim().replace("&amp;","&");if(raw.matches("^(PL|OLAK5uy_|UU|LL|RD|FL)[A-Za-z0-9_-]{8,}$"))return raw;try{Uri u=Uri.parse(raw);String host=u.getHost();if(host==null)return null;host=host.toLowerCase(Locale.ROOT);if(!(host.equals("youtube.com")||host.endsWith(".youtube.com")||host.equals("youtu.be")||host.equals("music.youtube.com")))return null;String id=u.getQueryParameter("list");if(id!=null&&id.matches("[A-Za-z0-9_-]{10,}"))return id;}catch(Exception ignored){}return null;}
  private void fetch(){if(busy)return;mode=0;String id=parseId(linkInput.getText().toString());if(id==null){report("Invalid playlist link. Use a YouTube link containing list=...");return;}String key=apiKey();if(key.isEmpty()){report("Enter your YouTube Data API v3 key.");return;}activeRegionCode=regionCode();busy=true;fetchButton.setEnabled(false);exportButton.setEnabled(false);tracks.clear();report("Loading playlist...");new Thread(()->{try{JSONObject info=api("playlists","part=snippet&id="+enc(id)+"&maxResults=1",key);JSONArray items=info.optJSONArray("items");if(items==null||items.length()==0)throw new Exception("Playlist unavailable or private.");folderName=items.getJSONObject(0).getJSONObject("snippet").optString("title","YouTube Playlist");saveTracks();ArrayList<String> ids=playlistIds(id,key);appendPlaylistTracks(ids,key);report("Ready: "+tracks.size()+" items in “"+folderName+"”.");runOnUiThread(()->exportButton.setEnabled(!tracks.isEmpty()));}catch(Exception e){report("ERROR: "+safeMessage(e));}finally{busy=false;runOnUiThread(()->fetchButton.setEnabled(true));}}).start();}
  private void hideKey(){runOnUiThread(()->{keyInput.setVisibility(View.GONE);keyLabel.setVisibility(View.GONE);});}
  private JSONObject api(String endpoint,String params,String key)throws Exception{URL url=new URL("https://www.googleapis.com/youtube/v3/"+endpoint+"?"+params+"&key="+enc(key));HttpURLConnection c=(HttpURLConnection)url.openConnection();c.setConnectTimeout(15000);c.setReadTimeout(25000);c.setRequestProperty("Accept","application/json");int code=c.getResponseCode();InputStream stream=code<400?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=stream.read(b))!=-1)out.write(b,0,n);c.disconnect();JSONObject data=new JSONObject(out.toString("UTF-8"));if(code>=400){JSONObject err=data.optJSONObject("error");throw new Exception("YouTube API "+code+": "+(err==null?"request failed":err.optString("message","request failed")));}getPreferences(0).edit().putString("api_key",key).apply();hideKey();return data;}
  private static String enc(String s)throws Exception{return URLEncoder.encode(s,"UTF-8");}
  private static String safe(String s){s=s.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]","_");return s.isEmpty()?"Untitled":s;}
  private String safeMessage(Exception e){String m=e.getMessage();return m==null?"Request failed":m.replaceAll("(?i)(key=)[^&\\s]+","$1[hidden]");}
  private void saveTracks(){try{JSONArray a=new JSONArray();for(Track t:tracks){JSONObject x=new JSONObject();x.put("title",t.title);x.put("id",t.id);a.put(x);}getPreferences(0).edit().putString("saved_tracks",a.toString()).putString("saved_folder",folderName).apply();}catch(Exception ignored){}}
  private void restoreTracks(){try{String raw=getPreferences(0).getString("saved_tracks","");if(raw.isEmpty())return;JSONArray a=new JSONArray(raw);for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);String id=x.optString("id");if(id.matches("[A-Za-z0-9_-]{11}"))tracks.add(new Track(x.optString("title",id),id));}folderName=getPreferences(0).getString("saved_folder","YouTube Playlist");exportButton.setEnabled(!tracks.isEmpty());if(!tracks.isEmpty())status.setText("Restored "+tracks.size()+" saved items in “"+folderName+"”.");}catch(Exception ignored){}}
  private static String validWatch(String id){return id.matches("[A-Za-z0-9_-]{11}")?"https://www.youtube.com/watch?v="+id:null;}
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request!=CREATE_ZIP||result!=RESULT_OK||data==null)return;Uri dest=data.getData();exportButton.setEnabled(false);report("Creating ZIP...");new Thread(()->{try(OutputStream stream=getContentResolver().openOutputStream(dest);ZipOutputStream zip=new ZipOutputStream(stream)){HashSet<String> names=new HashSet<>();String root=safe(folderName)+"/";int i=0;for(Track t:tracks){String url=validWatch(t.id);if(url==null)continue;String base=safe(t.title);String name=root+base+".yt";int k=2;while(!names.add(name))name=root+base+" ("+(k++)+").yt";zip.putNextEntry(new ZipEntry(name));zip.write((url+"\n").getBytes(StandardCharsets.UTF_8));zip.closeEntry();i++;if(i%50==0)report("ZIP: "+i+" / "+tracks.size());}report("Done: "+i+" .yt files in playlist folder “"+safe(folderName)+"”.");}catch(Exception e){report("ZIP ERROR: "+safeMessage(e));}finally{runOnUiThread(()->exportButton.setEnabled(!tracks.isEmpty()));}}).start();}
}
