package com.teraphonia.ytmonsterv2;

import android.app.*;
import android.os.*;
import android.net.Uri;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

public class MainActivity extends Activity {
  private EditText keyInput, linkInput, filesPerFolderInput;
  private TextView status;
  private Button fetchButton, exportButton;
  private final ArrayList<Track> tracks = new ArrayList<>();
  private String folderName="YouTube Playlist";
  private volatile boolean busy=false;
  private static final int CREATE_ZIP=27;
  private static class Track { final String title,id; Track(String t,String i){title=t;id=i;} }
  @Override public void onCreate(Bundle b){ super.onCreate(b);
    LinearLayout outer=new LinearLayout(this);outer.setOrientation(1);outer.setPadding(22,20,22,12);outer.setBackgroundColor(Color.rgb(10,25,19));
    ScrollView sc=new ScrollView(this);sc.addView(outer);setContentView(sc);
    TextView heading=label("YT MONSTER V2",29,0xffa3ff68);outer.addView(heading);
    outer.addView(label("DIRECT PLAYLIST  →  .YT ZIP",19,Color.WHITE));
    outer.addView(label("Samo javne YouTube playliste. Bez CSV-a, pretrage i zamjene snimaka.",17,0xffc9e1cf));
    outer.addView(label("YOUTUBE DATA API V3 KEY",18,Color.WHITE));
    keyInput=field("Zalijepi svoj API ključ",true);outer.addView(keyInput);
    keyInput.setText(getPreferences(0).getString("api_key",""));
    outer.addView(label("PASTE YT PLAYLIST LINK",18,Color.WHITE));
    linkInput=field("https://www.youtube.com/playlist?list=...",false);outer.addView(linkInput);
    outer.addView(label("FILES PER LIST / PJESAMA PO FOLDERU",18,Color.WHITE));
    filesPerFolderInput=field("50",false);filesPerFolderInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);filesPerFolderInput.setText("50");outer.addView(filesPerFolderInput);
    fetchButton=button("UČITAJ PLAYLISTU",outer);fetchButton.setOnClickListener(v->fetch());
    exportButton=button("PRŽI .YT ZIP",outer);exportButton.setEnabled(false);exportButton.setOnClickListener(v->{if(folderLimit()<1)return;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");i.putExtra(Intent.EXTRA_TITLE,safe(folderName)+".zip");startActivityForResult(i,CREATE_ZIP);});
    status=label("Spreman. Učitaj playlistu.",19,Color.WHITE);outer.addView(status);
  }
  private TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(0,15,0,15);return t;}
  private EditText field(String hint,boolean password){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(20);e.setHint(hint);e.setHintTextColor(0xffb1b1b1);e.setTextColor(Color.WHITE);e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xffa3ff68));if(password)e.setInputType(129);return e;}
  private Button button(String s,LinearLayout parent){Button b=new Button(this);b.setText(s);b.setTextSize(19);b.setAllCaps(false);parent.addView(b,new LinearLayout.LayoutParams(-1,80));return b;}
  private int folderLimit(){try{int n=Integer.parseInt(filesPerFolderInput.getText().toString().trim());if(n<1||n>100000){report("Unesi broj pjesama po folderu od 1 do 100000.");return -1;}return n;}catch(Exception e){report("Unesi ispravan broj pjesama po folderu.");return -1;}}
  private void report(String s){runOnUiThread(()->status.setText(s));}
  private static String parseId(String raw){
    raw=raw.trim().replace("&amp;","&");
    if(raw.matches("^(PL|OLAK5uy_|UU|LL|RD|FL)[A-Za-z0-9_-]{8,}$"))return raw;
    try {Uri u=Uri.parse(raw);String host=u.getHost();if(host==null)return null;host=host.toLowerCase(Locale.ROOT);if(!(host.equals("youtube.com")||host.endsWith(".youtube.com")||host.equals("youtu.be")||host.equals("music.youtube.com")))return null;
      String id=u.getQueryParameter("list");if(id!=null&&id.matches("[A-Za-z0-9_-]{10,}"))return id;
    }catch(Exception ignored){}return null;
  }
  private void fetch(){if(busy)return;String id=parseId(linkInput.getText().toString());if(id==null){report("Neispravan link playliste. Koristi SHARE link cijele playliste koji sadrži list=...");return;}
    String key=keyInput.getText().toString().trim();if(key.isEmpty()){report("Unesi YouTube Data API v3 ključ.");return;}
    getPreferences(0).edit().putString("api_key",key).apply();busy=true;fetchButton.setEnabled(false);exportButton.setEnabled(false);tracks.clear();report("Učitavam playlistu...");
    new Thread(()->{try{
      JSONObject info=api("playlists", "part=snippet&id="+enc(id)+"&maxResults=1",key);
      JSONArray items=info.optJSONArray("items");if(items==null||items.length()==0)throw new Exception("Playlista nije javna ili nije dostupna.");
      folderName=items.getJSONObject(0).getJSONObject("snippet").optString("title","YouTube Playlist");
      String token="";int skipped=0;int pages=0;
      do{String args="part=snippet,contentDetails&maxResults=50&playlistId="+enc(id)+(token.isEmpty()?"":"&pageToken="+enc(token));
        JSONObject page=api("playlistItems",args,key);JSONArray entries=page.getJSONArray("items");
        for(int j=0;j<entries.length();j++){JSONObject row=entries.getJSONObject(j);JSONObject sn=row.optJSONObject("snippet");if(sn==null){skipped++;continue;}
          String title=sn.optString("title","");String videoId=sn.optJSONObject("resourceId")==null?"":sn.getJSONObject("resourceId").optString("videoId","");
          if(videoId.matches("[A-Za-z0-9_-]{11}")&&!title.equalsIgnoreCase("Deleted video")&&!title.equalsIgnoreCase("Private video"))tracks.add(new Track(title,videoId));else skipped++;
        }
        token=page.optString("nextPageToken","");pages++;final int count=tracks.size();report("Učitano: "+count+" videa; stranica: "+pages+". Nastavljam...");
        if(pages>500)throw new Exception("Previše stranica; zaustavljeno radi sigurnosti.");
      }while(!token.isEmpty());
      final int total=tracks.size(),lost=skipped;report("SPREMNO: "+folderName+"\n"+total+" videa za .yt ZIP. Preskočeno nedostupnih: "+lost+".\nPritisni PRŽI .YT ZIP.");
      runOnUiThread(()->exportButton.setEnabled(total>0));
    }catch(Exception e){report("GREŠKA: "+e.getMessage());}finally{busy=false;runOnUiThread(()->fetchButton.setEnabled(true));}}).start();
  }
  private JSONObject api(String endpoint,String params,String key)throws Exception{
    URL url=new URL("https://www.googleapis.com/youtube/v3/"+endpoint+"?"+params+"&key="+enc(key));
    HttpURLConnection c=(HttpURLConnection)url.openConnection();c.setConnectTimeout(15000);c.setReadTimeout(25000);c.setRequestProperty("Accept","application/json");
    int code=c.getResponseCode();InputStream stream=code<400?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=stream.read(b))!=-1)out.write(b,0,n);c.disconnect();JSONObject data=new JSONObject(out.toString("UTF-8"));
    if(code>=400){JSONObject err=data.optJSONObject("error");throw new Exception("YouTube API "+code+": "+(err==null?"unknown":err.optString("message","unknown")));}return data;
  }
  private static String enc(String s)throws Exception{return java.net.URLEncoder.encode(s,"UTF-8");}
  private static String safe(String s){s=s.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]"," ").replaceAll("\\s+"," ").trim();if(s.length()>110)s=s.substring(0,110).trim();return s.isEmpty()?"Untitled":s;}
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request!=CREATE_ZIP||result!=RESULT_OK||data==null)return;
    final int limit=folderLimit();if(limit<1)return;android.net.Uri dest=data.getData();exportButton.setEnabled(false);report("Pržim ZIP...");new Thread(()->{
      try(OutputStream stream=getContentResolver().openOutputStream(dest);ZipOutputStream zip=new ZipOutputStream(stream)){
        HashSet<String> names=new HashSet<>();String rootName=safe(folderName);int i=0;
        for(Track t:tracks){String folder=rootName+((i/limit)+1)+"/";String base=safe(t.title);String name=folder+base+".yt";int k=2;while(!names.add(name))name=folder+base+" ("+(k++)+").yt";
          zip.putNextEntry(new ZipEntry(name));zip.write(("https://www.youtube.com/watch?v="+t.id+"\n").getBytes(StandardCharsets.UTF_8));zip.closeEntry();i++;
          if(i%50==0){final int done=i;report("ZIP: "+done+" / "+tracks.size());}
        }report("GOTOVO! "+i+" .yt fajlova u "+((i+limit-1)/limit)+" foldera u ZIP-u.");
      }catch(Exception e){report("ZIP GREŠKA: "+e.getMessage());}finally{runOnUiThread(()->exportButton.setEnabled(!tracks.isEmpty()));}
    }).start();
  }
}
