package com.teraphonia.ytmonsterv2;

import android.app.*;
import android.os.*;
import android.net.Uri;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

public class MainActivity extends Activity {
  private EditText keyInput, linkInput, filesPerFolderInput, searchInput, minInput, maxInput;
  private LinearLayout resultsBox, genresBox, decadesBox;
  private Spinner countrySpinner;
  private int mode=0;
  private final LinkedHashSet<String> genres=new LinkedHashSet<>(), decades=new LinkedHashSet<>();
  private final ArrayList<Candidate> candidates=new ArrayList<>();
  private Button songSearchButton, mixSearchButton, enterButton;
  private int selectedSearchMode=1;
  private TextView status;
  private Button fetchButton, exportButton;
  private final ArrayList<Track> tracks = new ArrayList<>();
  private String folderName="YouTube Playlist";
  private volatile boolean busy=false;
  private static final int CREATE_ZIP=27;
  private static class Candidate {String id,title;long views;int count;boolean chosen=true; Candidate(String i,String t,long v,int n){id=i;title=t;views=v;count=n;}}
  private static class Track { final String title,id; Track(String t,String i){title=t;id=i;} }
  @Override public void onCreate(Bundle b){ super.onCreate(b);
    LinearLayout outer=new LinearLayout(this);outer.setOrientation(1);outer.setPadding(22,20,22,12);outer.setBackgroundColor(Color.rgb(10,25,19));
    ScrollView sc=new ScrollView(this);sc.addView(outer);setContentView(sc);
    TextView heading=label("YT MONSTER V2",29,0xffa3ff68);outer.addView(heading);
    outer.addView(label("PLAYLIST SEARCH",17,Color.WHITE));
    searchInput=field("Search playlists / mixes",false);outer.addView(searchInput);
    outer.addView(label("GENRE — više izbora",17,Color.WHITE));
    genresBox=new LinearLayout(this);genresBox.setOrientation(LinearLayout.VERTICAL);outer.addView(genresBox);
    addFilters(genresBox,new String[]{"POP","ROCK","DANCE","BLUES","R&B","COUNTRY","JAZZ","SOUL","METAL","FOLK","DISCO","EDM"},genres);
    outer.addView(label("DECADE — više izbora",17,Color.WHITE));
    decadesBox=new LinearLayout(this);decadesBox.setOrientation(LinearLayout.VERTICAL);outer.addView(decadesBox);
    addFilters(decadesBox,new String[]{"50s","60s","70s","80s","90s","00s","10s","20s"},decades);
    outer.addView(label("COUNTRIES (search hint)",17,Color.WHITE));
    countrySpinner=new Spinner(this);String[] countries={"ALL COUNTRIES","USA","UK","CANADA","AUSTRALIA","GERMANY","FRANCE","ITALY","SPAIN","SERBIA","MONTENEGRO","CROATIA","BOSNIA","SLOVENIA","OTHER"};
    ArrayAdapter<String> ca=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,countries);countrySpinner.setAdapter(ca);outer.addView(countrySpinner);
    outer.addView(label("SONGS PER PLAYLIST (MIN / MAX)",17,Color.WHITE));
    LinearLayout range=new LinearLayout(this);outer.addView(range);
    minInput=field("MIN",false);maxInput=field("MAX",false);
    minInput.setInputType(2);maxInput.setInputType(2);
    range.addView(minInput,new LinearLayout.LayoutParams(0,70,1));range.addView(maxInput,new LinearLayout.LayoutParams(0,70,1));
    songSearchButton=button("SEARCH 1",outer);
    mixSearchButton=button("SEARCH MIX",outer);
    songSearchButton.setOnClickListener(v->selectSearchMode(1));
    mixSearchButton.setOnClickListener(v->selectSearchMode(2));
    enterButton=button("ENTER",outer);enterButton.setOnClickListener(v->search(selectedSearchMode));
    selectSearchMode(1);
    resultsBox=new LinearLayout(this);resultsBox.setOrientation(LinearLayout.VERTICAL);
    outer.addView(label("DIRECT PLAYLIST LINK (original option)",18,Color.WHITE));
    outer.addView(label("YOUTUBE DATA API V3 KEY",18,Color.WHITE));
    keyInput=field("Zalijepi svoj API ključ",true);outer.addView(keyInput);
    keyInput.setText(getPreferences(0).getString("api_key",""));
    outer.addView(label("PASTE YT PLAYLIST LINK",18,Color.WHITE));
    linkInput=field("https://www.youtube.com/playlist?list=...",false);outer.addView(linkInput);
    outer.addView(label("FILES PER LIST / PJESAMA PO FOLDERU",18,Color.WHITE));
    filesPerFolderInput=field("50",false);filesPerFolderInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);filesPerFolderInput.setText("50");outer.addView(filesPerFolderInput);
    fetchButton=button("UČITAJ PLAYLISTU",outer);fetchButton.setOnClickListener(v->fetch());
    exportButton=button("PRŽI .YT ZIP",outer);exportButton.setEnabled(false);exportButton.setOnClickListener(v->{if(folderLimit()<1||busy)return;if(mode==0){openZipPicker();return;}busy=true;exportButton.setEnabled(false);new Thread(()->{try{prepareSelection(keyInput.getText().toString().trim());runOnUiThread(()->{if(!tracks.isEmpty())openZipPicker();else report("Nema dostupnih videa.");});}catch(Exception e){report("FILTER GREŠKA: "+e.getMessage());}finally{busy=false;runOnUiThread(()->exportButton.setEnabled(true));}}).start();});
    status=label("Spreman. Učitaj playlistu.",19,Color.WHITE);outer.addView(status);
  }
  private TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(0,15,0,15);return t;}
  private EditText field(String hint,boolean password){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(20);e.setHint(hint);e.setHintTextColor(0xffb1b1b1);e.setTextColor(Color.WHITE);e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xffa3ff68));if(password)e.setInputType(129);return e;}
  private Button button(String s,LinearLayout parent){Button b=new Button(this);b.setTextColor(Color.BLACK);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));b.setText(s);b.setTextSize(19);b.setAllCaps(false);parent.addView(b,new LinearLayout.LayoutParams(-1,80));return b;}
  private void setActive(Button b,boolean active){b.setTextColor(active?Color.WHITE:Color.BLACK);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(active?0xffc62828:Color.WHITE));}
  private void selectSearchMode(int m){selectedSearchMode=m;setActive(songSearchButton,m==1);setActive(mixSearchButton,m==2);}
  private void addFilters(LinearLayout box,String[] options,LinkedHashSet<String> selected){
    for(int i=0;i<options.length;i+=3){LinearLayout row=new LinearLayout(this);box.addView(row);
      for(int j=i;j<Math.min(i+3,options.length);j++){String option=options[j];Button b=new Button(this);b.setText(option);b.setTextSize(13);b.setAllCaps(false);b.setTextColor(Color.BLACK);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));
        row.addView(b,new LinearLayout.LayoutParams(0,58,1));b.setOnClickListener(v->{if(selected.remove(option)){b.setTextColor(Color.BLACK);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));}else{selected.add(option);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xffc62828));}});
      }
    }
  }
  private int number(EditText e,int fallback){try{String s=e.getText().toString().trim();return s.isEmpty()?fallback:Integer.parseInt(s);}catch(Exception ex){return -1;}}
  private String query(){StringBuilder q=new StringBuilder(searchInput.getText().toString().trim());for(String g:genres)q.append(" ").append(g);for(String d:decades)q.append(" ").append(d);String country=countrySpinner.getSelectedItem().toString();if(!country.equals("ALL COUNTRIES"))q.append(" ").append(country);if(mode==2)q.append(" music mix");else q.append(" music playlist");return q.toString().trim();}
  private void search(int newMode){if(busy)return;String key=keyInput.getText().toString().trim();if(key.isEmpty()){report("Unesi YouTube Data API ključ.");return;}
    int min=number(minInput,0),max=number(maxInput,999999);if(min<0||max<min){report("Provjeri MIN / MAX.");return;}
    mode=newMode;getPreferences(0).edit().putString("api_key",key).apply();busy=true;enterButton.setEnabled(false);exportButton.setEnabled(false);candidates.clear();tracks.clear();resultsBox.removeAllViews();String q=query();report("Tražim: "+q);
    new Thread(()->{try{
      String endpoint=mode==1?"playlist":"video";
      JSONObject found=api("search","part=snippet&type="+endpoint+"&maxResults=50&q="+enc(q)+(mode==2?"&videoDuration=long":""),key);
      JSONArray rows=found.optJSONArray("items");if(rows==null)throw new Exception("Nema rezultata.");
      if(mode==2){ArrayList<String> ids=new ArrayList<>();HashMap<String,String> titles=new HashMap<>();for(int i=0;i<rows.length();i++){JSONObject r=rows.getJSONObject(i);String id=r.getJSONObject("id").optString("videoId","");if(id.matches("[A-Za-z0-9_-]{11}")){ids.add(id);titles.put(id,r.getJSONObject("snippet").optString("title","Mix"));}}
        Map<String,JSONObject> data=videoDetails(ids,key);for(String id:ids){JSONObject v=data.get(id);if(v==null||!allowed(v,900,Long.MAX_VALUE))continue;candidates.add(new Candidate(id,titles.get(id),v.getJSONObject("statistics").optLong("viewCount",0),1));}
      }else{
        ArrayList<String> ids=new ArrayList<>();HashMap<String,String> titles=new HashMap<>();for(int i=0;i<rows.length();i++){JSONObject r=rows.getJSONObject(i);String id=r.getJSONObject("id").optString("playlistId","");if(!id.isEmpty()){ids.add(id);titles.put(id,r.getJSONObject("snippet").optString("title","Playlist"));}}
        // Stop at the first matching playlist instead of auditing every search result.
        // YouTube playlist search does not expose playlist view counts.
        for(String id:ids){
          report("Tražim prvu odgovarajuću playlistu...");
          JSONObject p=api("playlists","part=contentDetails&id="+enc(id),key);
          JSONArray arr=p.optJSONArray("items");if(arr==null||arr.length()==0)continue;
          int count=arr.getJSONObject(0).getJSONObject("contentDetails").optInt("itemCount",0);
          if(count<min||count>max)continue;
          ArrayList<String> vids=playlistIds(id,key,50);
          Map<String,JSONObject> details=videoDetails(vids,key);
          boolean playable=false;
          for(String vid:vids){JSONObject v=details.get(vid);if(v!=null&&allowed(v,0,479)){playable=true;break;}}
          if(playable){candidates.add(new Candidate(id,titles.get(id),0,count));break;}
        }
      }
      Collections.sort(candidates,(a,b)->Long.compare(b.views,a.views));
      if(candidates.isEmpty()){report("Nema odgovarajućih dostupnih rezultata.");}
      else{
        Candidate first=candidates.get(0);candidates.clear();candidates.add(first);
        report("Pronađeno: "+first.title+". Uvozim...");
        prepareSelection(key);
        if(tracks.isEmpty())report("Nema dostupnih numera u prvoj playlisti.");
        else runOnUiThread(()->{report("Spremno "+tracks.size()+" numera. Izaberi gdje da sačuvam ZIP.");openZipPicker();});
      }
    }catch(Exception e){report("SEARCH GREŠKA: "+e.getMessage());}finally{busy=false;runOnUiThread(()->{enterButton.setEnabled(true);});}}).start();
  }
  private ArrayList<String> playlistIds(String id,String key,int limit)throws Exception{ArrayList<String> ids=new ArrayList<>();String token="";do{JSONObject page=api("playlistItems","part=contentDetails&maxResults=50&playlistId="+enc(id)+(token.isEmpty()?"":"&pageToken="+enc(token)),key);JSONArray rows=page.optJSONArray("items");if(rows==null)break;for(int i=0;i<rows.length();i++){String vid=rows.getJSONObject(i).getJSONObject("contentDetails").optString("videoId","");if(vid.matches("[A-Za-z0-9_-]{11}"))ids.add(vid);}token=page.optString("nextPageToken","");}while(!token.isEmpty()&&ids.size()<limit);return ids;}
  private Map<String,JSONObject> videoDetails(List<String> ids,String key)throws Exception{Map<String,JSONObject> map=new HashMap<>();for(int i=0;i<ids.size();i+=50){String joined=android.text.TextUtils.join(",",ids.subList(i,Math.min(i+50,ids.size())));JSONObject response=api("videos","part=snippet,contentDetails,status,statistics&id="+enc(joined),key);JSONArray rows=response.optJSONArray("items");if(rows!=null)for(int j=0;j<rows.length();j++){JSONObject v=rows.getJSONObject(j);map.put(v.optString("id"),v);}}return map;}
  private boolean allowed(JSONObject v,long minSec,long maxSec){try{JSONObject status=v.getJSONObject("status"),content=v.getJSONObject("contentDetails");if(!status.optBoolean("embeddable",false)||!status.optString("privacyStatus","").equals("public"))return false;
    JSONObject restriction=content.optJSONObject("regionRestriction");if(restriction!=null){JSONArray allowed=restriction.optJSONArray("allowed");JSONArray blocked=restriction.optJSONArray("blocked");if(allowed!=null&&!has(allowed,"ME"))return false;if(blocked!=null&&has(blocked,"ME"))return false;}
    long sec=java.time.Duration.parse(content.getString("duration")).getSeconds();if(sec<minSec||sec>maxSec)return false;
    String title=v.getJSONObject("snippet").optString("title","");if(mode==1&&title.toLowerCase(Locale.ROOT).matches(".*\\blive\\b.*"))return false;return true;
  }catch(Exception e){return false;}}
  private boolean has(JSONArray a,String s){for(int i=0;i<a.length();i++)if(s.equals(a.optString(i)))return true;return false;}
  private void prepareSelection(String key)throws Exception{ArrayList<Candidate> selected=new ArrayList<>();for(Candidate c:candidates)if(c.chosen)selected.add(c);if(selected.isEmpty())throw new Exception("Nijedan rezultat nije označen.");tracks.clear();HashSet<String> seen=new HashSet<>();
    for(Candidate c:selected){if(mode==2){if(seen.add(c.id))tracks.add(new Track(c.title,c.id));}else{ArrayList<String> ids=playlistIds(c.id,key,10000);Map<String,JSONObject> info=videoDetails(ids,key);for(String id:ids){JSONObject v=info.get(id);if(v!=null&&allowed(v,0,479)&&seen.add(id))tracks.add(new Track(v.getJSONObject("snippet").optString("title",id),id));}}report("Spremno "+tracks.size()+" numera...");}folderName=mode==2?"YTMonster Mixes":"YTMonster Songs";
  }
  private void openZipPicker(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");i.putExtra(Intent.EXTRA_TITLE,safe(folderName)+".zip");startActivityForResult(i,CREATE_ZIP);}
  private int folderLimit(){try{int n=Integer.parseInt(filesPerFolderInput.getText().toString().trim());if(n<1||n>100000){report("Unesi broj pjesama po folderu od 1 do 100000.");return -1;}return n;}catch(Exception e){report("Unesi ispravan broj pjesama po folderu.");return -1;}}
  private void report(String s){runOnUiThread(()->status.setText(s));}
  private static String parseId(String raw){
    raw=raw.trim().replace("&amp;","&");
    if(raw.matches("^(PL|OLAK5uy_|UU|LL|RD|FL)[A-Za-z0-9_-]{8,}$"))return raw;
    try {Uri u=Uri.parse(raw);String host=u.getHost();if(host==null)return null;host=host.toLowerCase(Locale.ROOT);if(!(host.equals("youtube.com")||host.endsWith(".youtube.com")||host.equals("youtu.be")||host.equals("music.youtube.com")))return null;
      String id=u.getQueryParameter("list");if(id!=null&&id.matches("[A-Za-z0-9_-]{10,}"))return id;
    }catch(Exception ignored){}return null;
  }
  private void fetch(){if(busy)return;mode=0;candidates.clear();resultsBox.removeAllViews();String id=parseId(linkInput.getText().toString());if(id==null){report("Neispravan link playliste. Koristi SHARE link cijele playliste koji sadrži list=...");return;}
    String key=keyInput.getText().toString().trim();if(key.isEmpty()){report("Unesi YouTube Data API v3 ključ.");return;}
    getPreferences(0).edit().putString("api_key",key).apply();busy=true;fetchButton.setEnabled(false);exportButton.setEnabled(false);tracks.clear();report("Učitavam playlistu...");
    new Thread(()->{try{
      JSONObject info=api("playlists", "part=snippet&id="+enc(id)+"&maxResults=1",key);
      JSONArray items=info.optJSONArray("items");if(items==null||items.length()==0)throw new Exception("Playlista nije javna ili nije dostupna.");
      folderName=items.getJSONObject(0).getJSONObject("snippet").optString("title","YouTube Playlist");
      String token="";int skipped=0;int pages=0;
      do{String args="part=snippet,contentDetails&maxResults=50&playlistId="+enc(id)+(token.isEmpty()?"":"&pageToken="+enc(token));
        JSONObject page=api("playlistItems",args,key);JSONArray entries=page.getJSONArray("items");
        for(int j=0;j<entries.length();j++){JSONObject row=entries.getJSONObject(j);JSONObject sn=row.optJSONObject("snippet");if(sn==null){skipped++;continue;}
          String title=sn.optString("title","");String videoId=sn.optJSONObject("resourceId")==null?"":sn.getJSONObject("resourceId").optString("videoId","");
          if(videoId.matches("[A-Za-z0-9_-]{11}")&&!title.equalsIgnoreCase("Deleted video")&&!title.equalsIgnoreCase("Private video"))tracks.add(new Track(title,videoId));else skipped++;
        }
        token=page.optString("nextPageToken","");pages++;final int count=tracks.size();report("Učitano: "+count+" videa; stranica: "+pages+". Nastavljam...");
        if(pages>500)throw new Exception("Previše stranica; zaustavljeno radi sigurnosti.");
      }while(!token.isEmpty());
      final int total=tracks.size(),lost=skipped;report("SPREMNO: "+folderName+"\n"+total+" videa za .yt ZIP. Preskočeno nedostupnih: "+lost+".\nPritisni PRŽI .YT ZIP.");
      runOnUiThread(()->exportButton.setEnabled(total>0));
    }catch(Exception e){report("GREŠKA: "+e.getMessage());}finally{busy=false;runOnUiThread(()->fetchButton.setEnabled(true));}}).start();
  }
  private JSONObject api(String endpoint,String params,String key)throws Exception{
    URL url=new URL("https://www.googleapis.com/youtube/v3/"+endpoint+"?"+params+"&key="+enc(key));
    HttpURLConnection c=(HttpURLConnection)url.openConnection();c.setConnectTimeout(15000);c.setReadTimeout(25000);c.setRequestProperty("Accept","application/json");
    int code=c.getResponseCode();InputStream stream=code<400?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=stream.read(b))!=-1)out.write(b,0,n);c.disconnect();JSONObject data=new JSONObject(out.toString("UTF-8"));
    if(code>=400){JSONObject err=data.optJSONObject("error");throw new Exception("YouTube API "+code+": "+(err==null?"unknown":err.optString("message","unknown")));}return data;
  }
  private static String enc(String s)throws Exception{return java.net.URLEncoder.encode(s,"UTF-8");}
  private static String safe(String s){s=s.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]"," ").replaceAll("\\s+"," ").trim();if(s.length()>110)s=s.substring(0,110).trim();return s.isEmpty()?"Untitled":s;}
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request!=CREATE_ZIP||result!=RESULT_OK||data==null)return;
    final int limit=folderLimit();if(limit<1)return;android.net.Uri dest=data.getData();exportButton.setEnabled(false);report("Pržim ZIP...");new Thread(()->{
      try(OutputStream stream=getContentResolver().openOutputStream(dest);ZipOutputStream zip=new ZipOutputStream(stream)){
        HashSet<String> names=new HashSet<>();String rootName=safe(folderName);int i=0;
        for(Track t:tracks){String folder=rootName+((i/limit)+1)+"/";String base=safe(t.title);String name=folder+base+".yt";int k=2;while(!names.add(name))name=folder+base+" ("+(k++)+").yt";
          zip.putNextEntry(new ZipEntry(name));zip.write(("https://www.youtube.com/watch?v="+t.id+"\n").getBytes(StandardCharsets.UTF_8));zip.closeEntry();i++;
          if(i%50==0){final int done=i;report("ZIP: "+done+" / "+tracks.size());}
        }report("GOTOVO! "+i+" .yt fajlova u "+((i+limit-1)/limit)+" foldera u ZIP-u.");
      }catch(Exception e){report("ZIP GREŠKA: "+e.getMessage());}finally{runOnUiThread(()->exportButton.setEnabled(!tracks.isEmpty()));}
    }).start();
  }
}
