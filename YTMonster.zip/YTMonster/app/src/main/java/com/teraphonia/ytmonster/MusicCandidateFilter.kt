package com.teraphonia.ytmonster

import java.text.Normalizer
import java.util.Locale

/** Conservative adaptation of EndlessMix's canonical-identity and negative-keyword checks.
 * No fuzzy artist substitutions: uncertain videos must be skipped, not silently saved.
 */
object MusicCandidateFilter {
    fun norm(raw:String):String {
        val lowered=raw.lowercase(Locale.ROOT).replace("đ","dj")
        return Normalizer.normalize(lowered,Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"),"")
            .replace(Regex("[^\\p{L}\\p{N}]+")," ")
            .replace(Regex("\\s+")," ").trim()
    }
    private val reject=Regex("""\b(live|livestream|live stream|concert|concerts|koncert|koncertni|koncertna|koncertno|uzivo|nastup|nastupi|gostovanje|gostovanja|gostuje|gostovao|gostovala|emisija|emisije|emisiji|televizija|televizijski|tv nastup|tv gostovanje|festival|performance|unplugged|acoustic session|session|cover|covered|tribute|karaoke|instrumental cover|reaction|reacts|tutorial|lesson|type beat|remix|remixed|sped up|slowed|nightcore|mashup|medley|mix|dj set|tv show|tv emisija|emisija|intervju|interview|talk show|audicija|takmicenje|zvezde granda|pinkove zvezde|the voice|idol|x factor|rehearsal|proba|fan made|fanmade|parody|parodija|tribute night|radio show|podcast|full album|full concert|lyrics translation|dance class|zumba|workout|choreography|crowd dancing|snimak sa svadbe|svadba|wedding|kafana live)\b""")
    private val decorations=Regex("""\b(official|music video|video clip|audio|lyrics|lyric video|visualizer|hd|hq|4k|vevo|topic|remastered|remaster)\b""")
    fun accept(rawTitle:String,song:String,artist:String,context:String=""):Boolean {
        val title=norm(rawTitle)
        if(reject.containsMatchIn(title) || reject.containsMatchIn(norm(context))) return false
        val expectedSong=norm(song); val expectedArtist=norm(artist)
        if(expectedSong.isBlank() || expectedArtist.isBlank()) return false
        val clean=decorations.replace(title," ").replace(Regex("\\s+")," ").trim()
        // Require full phrase identity rather than a single artist token.
        fun containsPhrase(text:String, phrase:String)= (" $text ").contains(" $phrase ")
        if(!containsPhrase(clean,expectedSong)) return false
        val artists=expectedArtist.split(Regex("\\s+(?:feat|ft|and|i|with)\\s+|\\s*[&,]\\s*"))
            .filter{it.isNotBlank()}
        if(artists.isEmpty() || artists.none{containsPhrase(clean,it)}) return false
        return true
    }
    /** YouTube displays localized, abbreviated view counts. -1 means unavailable. */
    fun parseViews(raw:String):Long {
        val t=Normalizer.normalize(raw.lowercase(Locale.ROOT).replace("đ", "dj"), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        val m=Regex("""(\d+(?:[ .]\d+)?)(?:\s*)(billion|million|thousand|milijardi|miliona|milion|hiljada|tisuca|mil|mln|mlrd|bn|k|m|b)?\s*(?:views|view|pregleda|pregledi|pregledov|visualizaciones|aufrufe)?""").find(t) ?: return -1
        val hasViewLabel=Regex("""views|view|pregled|visualizaciones|aufrufe""").containsMatchIn(t)
        val unit=m.groupValues[2]
        if (!hasViewLabel && unit.isEmpty()) return -1
        val amount=m.groupValues[1].replace(" ", "").toDoubleOrNull() ?: return -1
        val multiplier=when(unit) {
            "billion","milijardi","mlrd","bn","b" -> 1_000_000_000.0
            "million","miliona","milion","mil","mln","m" -> 1_000_000.0
            "thousand","hiljada","tisuca","k" -> 1_000.0
            else -> 1.0
        }
        return (amount*multiplier).toLong()
    }
    fun score(rawTitle:String,artist:String):Int {
        val title=norm(rawTitle)
        var score=10
        if(title.contains("official"))score+=8
        if(title.contains("audio"))score+=5
        if(title.contains("vevo") || title.contains("topic"))score+=4
        if(title.contains(norm(artist)))score+=4
        return score
    }
}
