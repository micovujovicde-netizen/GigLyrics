plugins { id("com.android.application") }
android { namespace = "com.teraphonia.ytmonsterv2"; compileSdk = 35
 defaultConfig { applicationId = "com.teraphonia.ytmonsterv2"; minSdk = 26; targetSdk = 32; versionCode = 7; versionName = "2.0.6" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
