package com.terafon.pausemix

import com.terafon.pausemix.model.TrackRef
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.StreamInfoItem

class SearchRepository {
    fun search(query: String): List<TrackRef> {
        val service = ServiceList.YouTube
        val extractor = service.getSearchExtractor(query)
        extractor.fetchPage()

        return extractor.initialPage.items
            .filterIsInstance<StreamInfoItem>()
            .filter { !it.isLive }
            .take(25)
            .map {
                TrackRef(
                    title = it.name ?: "Untitled",
                    uploader = it.uploaderName ?: "",
                    url = it.url,
                    durationSeconds = it.duration
                )
            }
    }
}
