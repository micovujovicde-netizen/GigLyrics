package com.teraphonia.giglyrics

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.documentfile.provider.DocumentFile
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.Normalizer
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GigLyricsApp(this) }
    }
}

data class Entry(
    val name: String,
    val uri: Uri,
    val isDirectory: Boolean,
    val pathLabel: String = ""
)

data class NavLocation(
    val folderUri: Uri,
    val fileUri: Uri? = null,
    val fileName: String? = null
)

data class LibraryIndex(
    val songs: List<Entry>,
    val folders: Map<String, List<Entry>>
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GigLyricsApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("giglyrics", Context.MODE_PRIVATE) }

    var rootUri by remember {
        mutableStateOf(prefs.getString("root_uri", null)?.let(Uri::parse))
    }
    var currentUri by remember {
        mutableStateOf(prefs.getString("last_folder_uri", null)?.let(Uri::parse))
    }
    var currentTitle by remember { mutableStateOf("GigLyrics") }
    var entries by remember { mutableStateOf(emptyList<Entry>()) }

    var openedText by remember { mutableStateOf<String?>(null) }
    var openedTitle by remember { mutableStateOf("") }
    var openedFileUri by remember { mutableStateOf<Uri?>(null) }

    var fontSize by remember {
        mutableFloatStateOf(prefs.getFloat("font_size", 28f))
    }
    var listFontSize by remember {
        mutableFloatStateOf(prefs.getFloat("list_font_size", 23f))
    }

    var searchQuery by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf(emptyList<Entry>()) }
    var searching by remember { mutableStateOf(false) }

    var webSearchQuery by remember { mutableStateOf("") }
    var webSearchUrl by remember { mutableStateOf<String?>(null) }
    var showWebSearch by remember { mutableStateOf(false) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var extractedLyrics by remember { mutableStateOf<String?>(null) }
    var extractedTitle by remember { mutableStateOf("") }
    var autoExtractActive by remember { mutableStateOf(false) }
    var autoExtractTriedText by remember { mutableStateOf(false) }
    var autoCandidateOpened by remember { mutableStateOf(false) }
    var candidateChoices by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var candidateChoiceQuery by remember { mutableStateOf("") }
    var downloadedLyricsUri by remember { mutableStateOf<Uri?>(null) }
    var songIndex by remember { mutableStateOf(emptyList<Entry>()) }
    var folderCache by remember { mutableStateOf<Map<String, List<Entry>>>(emptyMap()) }
    var indexReady by remember { mutableStateOf(false) }
    var indexGeneration by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()

    val backHistory = remember { mutableStateListOf<NavLocation>() }
    val forwardHistory = remember { mutableStateListOf<NavLocation>() }

    fun listFolder(uri: Uri) {
        val cached = folderCache[uri.toString()]
        if (cached != null) {
            entries = cached
            currentUri = uri
            openedText = null
            openedTitle = ""
            openedFileUri = null
            currentTitle = if (uri == rootUri) "GigLyrics" else (
                DocumentFile.fromTreeUri(context, uri)?.name ?: "Folder"
            )
            prefs.edit().putString("last_folder_uri", uri.toString()).apply()
            return
        }

        // Fallback only while the background cache is still being built.
        val folder = DocumentFile.fromTreeUri(context, uri)
        if (folder == null || !folder.isDirectory) return
        currentTitle = folder.name ?: "Folder"
        entries = folder.listFiles()
            .filter { it.isDirectory || (it.isFile && it.name?.lowercase()?.endsWith(".txt") == true) }
            .mapNotNull { f ->
                val n = f.name ?: return@mapNotNull null
                Entry(n, f.uri, f.isDirectory)
            }
            .sortedWith(compareBy<Entry> { !it.isDirectory }.thenBy { it.name.lowercase() })
        currentUri = uri
        openedText = null
        openedTitle = ""
        openedFileUri = null
        prefs.edit().putString("last_folder_uri", uri.toString()).apply()
    }

    fun readText(uri: Uri): String {
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                BufferedReader(InputStreamReader(input)).readText()
            } ?: ""
        } catch (e: Exception) {
            "Ne mogu da otvorim fajl.\n\n${e.message ?: ""}"
        }
    }

    fun currentLocation(): NavLocation? {
        val folder = currentUri ?: return null
        return if (openedText != null && openedFileUri != null) {
            NavLocation(folder, openedFileUri, openedTitle)
        } else {
            NavLocation(folder)
        }
    }

    fun applyLocation(location: NavLocation) {
        searchQuery = ""
        searching = false
        searchResults = emptyList()

        if (currentUri != location.folderUri || entries.isEmpty()) {
            listFolder(location.folderUri)
        } else {
            openedText = null
            openedTitle = ""
            openedFileUri = null
        }

        if (location.fileUri != null) {
            openedFileUri = location.fileUri
            openedTitle = location.fileName ?: "Tekst"
            openedText = readText(location.fileUri)
        }
    }

    fun navigateTo(location: NavLocation) {
        currentLocation()?.let { backHistory.add(it) }
        forwardHistory.clear()
        applyLocation(location)
    }

    fun goBack() {
        if (showWebSearch) {
            showWebSearch = false
            extractedLyrics = null
            webSearchUrl = null
            autoExtractActive = false
            autoExtractTriedText = false
            autoCandidateOpened = false
            candidateChoices = emptyList()
            candidateChoiceQuery = ""
            return
        }
        if (searching) {
            searchQuery = ""
            searching = false
            searchResults = emptyList()
            return
        }
        if (backHistory.isNotEmpty()) {
            currentLocation()?.let { forwardHistory.add(it) }
            val previous = backHistory.removeAt(backHistory.lastIndex)
            applyLocation(previous)
        }
    }

    fun goForward() {
        if (forwardHistory.isNotEmpty()) {
            currentLocation()?.let { backHistory.add(it) }
            val next = forwardHistory.removeAt(forwardHistory.lastIndex)
            applyLocation(next)
        }
    }

    fun goHome() {
        val root = rootUri ?: return
        if (currentUri == root && openedText == null && !searching && !showWebSearch) return
        showWebSearch = false
        extractedLyrics = null
        webSearchUrl = null
        autoExtractActive = false
        autoExtractTriedText = false
        autoCandidateOpened = false
        currentLocation()?.let { backHistory.add(it) }
        forwardHistory.clear()
        searchQuery = ""
        searching = false
        searchResults = emptyList()
        listFolder(root)
    }

    fun normalizeSearchText(value: String): String {
        val decomposed = Normalizer.normalize(value, Normalizer.Form.NFD)
        return decomposed
            .replace("\\p{Mn}+".toRegex(), "")
            .lowercase()
            .replace(".txt", "")
            .replace("[-_]+".toRegex(), " ")
            .replace("\\s+".toRegex(), " ")
            .trim()
    }

    suspend fun buildLibraryIndex(rootUriValue: Uri): LibraryIndex = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(context, rootUriValue)
            ?: return@withContext LibraryIndex(emptyList(), emptyMap())

        val songs = mutableListOf<Entry>()
        val folders = mutableMapOf<String, List<Entry>>()

        fun walk(folder: DocumentFile, path: String) {
            val rawChildren = folder.listFiles()
                .filter { it.isDirectory || (it.isFile && it.name?.lowercase()?.endsWith(".txt") == true) }

            val children = rawChildren
                .mapNotNull { f ->
                    val name = f.name ?: return@mapNotNull null
                    Entry(name, f.uri, f.isDirectory, path)
                }
                .sortedWith(compareBy<Entry> { !it.isDirectory }.thenBy { it.name.lowercase() })

            folders[folder.uri.toString()] = children

            for (child in rawChildren) {
                val name = child.name ?: continue
                if (child.isDirectory) {
                    val childPath = if (path.isBlank()) name else "$path / $name"
                    walk(child, childPath)
                } else if (child.isFile && name.lowercase().endsWith(".txt")) {
                    songs += Entry(name, child.uri, false, path)
                }
            }
        }

        walk(root, "")
        LibraryIndex(
            songs = songs.sortedBy { it.name.lowercase() },
            folders = folders
        )
    }

    fun refreshSongIndex(uri: Uri) {
        val generation = indexGeneration + 1
        indexGeneration = generation
        indexReady = false
        scope.launch {
            val built = buildLibraryIndex(uri)
            if (indexGeneration == generation) {
                songIndex = built.songs
                folderCache = built.folders
                indexReady = true

                // If the user is still on a folder that was opened before caching finished,
                // replace its slow SAF listing with the cached version immediately.
                currentUri?.let { current ->
                    built.folders[current.toString()]?.let { cached ->
                        if (openedText == null) entries = cached
                    }
                }

                if (searchQuery.isNotBlank()) {
                    val q = normalizeSearchText(searchQuery)
                    searchResults = built.songs.filter { normalizeSearchText(it.name).contains(q) }
                }
            }
        }
    }

    fun doSearch(query: String) {
        searchQuery = query
        searching = query.isNotBlank()
        if (!searching) {
            searchResults = emptyList()
            return
        }

        val q = normalizeSearchText(query)
        searchResults = if (indexReady) {
            songIndex.filter { normalizeSearchText(it.name).contains(q) }
        } else {
            emptyList()
        }
    }

    fun ensureDownloadedLyricsFolder(root: Uri): Uri? {
        return try {
            val rootFolder = DocumentFile.fromTreeUri(context, root) ?: return null
            val existing = rootFolder.listFiles().firstOrNull {
                it.isDirectory && it.name.equals("Downloaded Lyrics", ignoreCase = true)
            }
            val folder = existing ?: rootFolder.createDirectory("Downloaded Lyrics")
            folder?.uri.also { downloadedLyricsUri = it }
        } catch (_: Exception) {
            null
        }
    }

    fun webSearchUrlFor(query: String, suffix: String): String {
        val encoded = URLEncoder.encode("${query.trim()} $suffix", StandardCharsets.UTF_8.toString())
        return "https://www.google.com/search?q=$encoded"
    }

    fun launchWebSearch(query: String) {
        val clean = query.trim()
        if (clean.isBlank()) return
        webSearchQuery = clean
        extractedLyrics = null
        extractedTitle = clean

        // Step 1: automatic extraction. Search stays invisible while GigLyrics tries
        // the first useful text result. If that fails, the same WebView becomes
        // Step 2: the visible in-app web fallback.
        autoExtractActive = true
        autoExtractTriedText = false
        autoCandidateOpened = false
        candidateChoices = emptyList()
        candidateChoiceQuery = clean
        webSearchUrl = webSearchUrlFor(clean, "lyrics")
        showWebSearch = true
    }

    fun lyricsExtractionJs(): String = """

            (function() {
              function clean(t) {
                return (t || '')
                  .replace(/\\r/g, '')
                  .replace(/[ \\t]+\\n/g, '\\n')
                  .replace(/\\n[ \\t]+/g, '\\n')
                  .replace(/\\n{3,}/g, '\\n\\n')
                  .trim();
              }
              const specific = [
                '[data-lyrics-container="true"]',
                '.lyrics', '#lyrics', '.lyric', '#lyric',
                '[class*="lyrics"]', '[id*="lyrics"]'
              ];
              for (const sel of specific) {
                const nodes = Array.from(document.querySelectorAll(sel));
                if (nodes.length) {
                  const t = clean(nodes.map(n => n.innerText).join('\\n'));
                  if (t.length > 120) return t;
                }
              }

              const clone = document.body.cloneNode(true);
              clone.querySelectorAll('script,style,noscript,nav,header,footer,form,button,svg,canvas,iframe,aside').forEach(n => n.remove());
              const candidates = Array.from(clone.querySelectorAll('main,article,section,div,pre'));
              let best = '';
              let bestScore = -1e9;
              for (const el of candidates) {
                const t = clean(el.innerText);
                if (t.length < 120 || t.length > 18000) continue;
                const lines = t.split('\\n').map(x => x.trim()).filter(Boolean);
                if (lines.length < 4) continue;
                const shortLines = lines.filter(x => x.length >= 2 && x.length <= 90).length;
                const veryLong = lines.filter(x => x.length > 180).length;
                const noise = (t.match(/cookie|privacy|sign in|subscribe|advertis|menu|share|facebook|instagram/gi) || []).length;
                const score = shortLines * 5 + lines.length * 2 - veryLong * 8 - noise * 15 + Math.min(t.length, 4000) / 200;
                if (score > bestScore) { bestScore = score; best = t; }
              }
              return best || clean(clone.innerText);
            })();
        """.trimIndent()

    fun applyExtractedResult(web: WebView, result: String?, automatic: Boolean) {
        try {
            val value = if (result == null || result == "null") "" else
                org.json.JSONTokener(result).nextValue() as? String ?: ""

            val cleanedLines = value
                .lines()
                .map { it.trim() }
                .filter { it.isNotBlank() }

            val menuNoise = cleanedLines.count {
                val l = it.lowercase()
                l == "svi tekstovi" ||
                l.startsWith("poslušaj na") ||
                l.startsWith("listen on") ||
                l == "home" ||
                l == "menu" ||
                l == "lyrics" ||
                l == "tekst"
            }

            val usefulLines = cleanedLines.count { it.length in 8..140 }
            val looksLikeLyrics =
                value.length >= 180 &&
                cleanedLines.size >= 6 &&
                usefulLines >= 5 &&
                menuNoise <= 1

            if (!looksLikeLyrics) {
                if (automatic) {
                    // Auto mode failed: leave the current page open as the web fallback.
                    autoExtractActive = false
                    autoCandidateOpened = false
                    Toast.makeText(context, "Auto extract failed — web fallback", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Lyrics not found on this page", Toast.LENGTH_SHORT).show()
                }
            } else {
                extractedLyrics = value
                val pageTitle = web.title.orEmpty()
                    .replace(" - Google Search", "", ignoreCase = true)
                    .trim()
                extractedTitle = if (pageTitle.isNotBlank()) pageTitle else webSearchQuery
                autoExtractActive = false
                autoCandidateOpened = false
            }
        } catch (_: Exception) {
            if (automatic) {
                autoExtractActive = false
                autoCandidateOpened = false
                Toast.makeText(context, "Auto extract failed — web fallback", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Could not extract lyrics", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun extractLyricsFromWeb() {
        val web = webViewRef ?: return
        web.evaluateJavascript(lyricsExtractionJs()) { result ->
            applyExtractedResult(web, result, automatic = false)
        }
    }

    fun saveExtractedLyrics() {
        val text = extractedLyrics?.trim().orEmpty()
        val root = rootUri ?: return
        if (text.isBlank()) return
        val folderUri = downloadedLyricsUri ?: ensureDownloadedLyricsFolder(root)
        val folder = folderUri?.let { DocumentFile.fromTreeUri(context, it) }
        if (folder == null) {
            Toast.makeText(context, "Could not create Downloaded Lyrics", Toast.LENGTH_SHORT).show()
            return
        }
        val base = (if (webSearchQuery.isNotBlank()) webSearchQuery else extractedTitle)
            .replace(Regex("[\\\\/:*?\"<>|]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .ifBlank { "Lyrics" }
        val filename = "$base.txt"
        try {
            val existing = folder.listFiles().firstOrNull { it.isFile && it.name.equals(filename, true) }
            val file = existing ?: folder.createFile("text/plain", filename)
            if (file == null) throw IllegalStateException("File could not be created")
            context.contentResolver.openOutputStream(file.uri, "wt")?.use { out ->
                out.write(text.toByteArray(Charsets.UTF_8))
            } ?: throw IllegalStateException("File could not be written")
            Toast.makeText(context, "Saved to Downloaded Lyrics", Toast.LENGTH_SHORT).show()
            refreshSongIndex(root)
        } catch (e: Exception) {
            Toast.makeText(context, "Save failed: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
        }
    }

    val folderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) {}

            rootUri = uri
            backHistory.clear()
            forwardHistory.clear()
            searchQuery = ""
            searching = false
            searchResults = emptyList()

            prefs.edit()
                .putString("root_uri", uri.toString())
                .putString("last_folder_uri", uri.toString())
                .apply()

            ensureDownloadedLyricsFolder(uri)
            listFolder(uri)
            refreshSongIndex(uri)
        }
    }

    val voiceSearchLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
        if (!spoken.isNullOrBlank()) doSearch(spoken)
    }

    val webVoiceSearchLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
        if (!spoken.isNullOrBlank()) launchWebSearch(spoken)
    }

    fun launchVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Kaži ime pjesme")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        }
        voiceSearchLauncher.launch(intent)
    }

    fun launchWebVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Say song name")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        }
        webVoiceSearchLauncher.launch(intent)
    }

    fun openDonate() {
        context.startActivity(
            Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://wise.com/pay/me/milanv607?utm_source=request_flow")
            )
        )
    }

    LaunchedEffect(Unit) {
        val savedRoot = rootUri

        if (savedRoot == null) {
            // First launch: the app must ask for its root folder before showing the browser.
            folderPicker.launch(null)
        } else {
            val rootFolder = DocumentFile.fromTreeUri(context, savedRoot)

            if (rootFolder == null || !rootFolder.isDirectory || !rootFolder.canRead()) {
                // The old folder was removed or Android revoked access. Ask again.
                prefs.edit()
                    .remove("root_uri")
                    .remove("last_folder_uri")
                    .apply()
                rootUri = null
                currentUri = null
                folderPicker.launch(null)
            } else {
                // Every fresh app launch starts at HOME/root. Never reopen the last song/folder.
                backHistory.clear()
                forwardHistory.clear()
                searchQuery = ""
                searching = false
                searchResults = emptyList()
                listFolder(savedRoot)
                refreshSongIndex(savedRoot)

                if (rootFolder.canWrite()) {
                    ensureDownloadedLyricsFolder(savedRoot)
                } else {
                    // Older GigLyrics versions persisted read-only access. Web saving needs
                    // one re-selection of the same root so Android can persist write access too.
                    folderPicker.launch(savedRoot)
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color.Black,
            surface = Color.Black,
            onBackground = Color.White,
            onSurface = Color.White,
            primary = Color.White,
            onPrimary = Color.Black
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color.Black
        ) {
            val isRoot = rootUri != null && currentUri == rootUri && openedText == null && !showWebSearch

            BackHandler(enabled = showWebSearch || searching || backHistory.isNotEmpty()) { goBack() }

            Column(Modifier.fillMaxSize()) {
                if (rootUri == null) {
                    // If the user cancels the Android picker, keep the app here instead of
                    // pretending there is already a root folder.
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        OutlinedButton(onClick = { folderPicker.launch(null) }) {
                            Text("IZABERI GLAVNI FOLDER", color = Color.White)
                        }
                    }
                } else if (showWebSearch) {
                    if (extractedLyrics != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { extractedLyrics = null }) {
                                Text("Web", color = Color.White, fontSize = 18.sp)
                            }
                            Text(
                                text = extractedTitle.ifBlank { webSearchQuery },
                                color = Color.White,
                                fontSize = 36.sp,
                                maxLines = 1,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(
                                onClick = { saveExtractedLyrics() },
                                modifier = Modifier.height(58.dp)
                            ) {
                                Text(
                                    "Save",
                                    color = Color(0xFF4CAF50),
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                        Text(
                            text = extractedLyrics ?: "",
                            color = Color.White,
                            fontSize = fontSize.sp,
                            lineHeight = (fontSize * 1.35f).sp,
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                                .padding(horizontal = 18.dp, vertical = 8.dp)
                        )
                    } else {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(68.dp)
                                .padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "🌍  ${webSearchQuery.ifBlank { "Web lyrics" }}",
                                color = Color.White,
                                fontSize = 18.sp,
                                maxLines = 1,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(
                                onClick = { extractLyricsFromWeb() },
                                modifier = Modifier.height(58.dp)
                            ) {
                                Text(
                                    "Extract lyrics",
                                    color = Color(0xFF4CAF50),
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                        if (candidateChoices.isNotEmpty()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 18.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = "Choose the right song",
                                    color = Color.White,
                                    fontSize = 20.sp
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    text = candidateChoiceQuery,
                                    color = Color.Gray,
                                    fontSize = 14.sp
                                )
                                Spacer(Modifier.height(8.dp))

                                candidateChoices.forEach { (title, urlValue) ->
                                    Text(
                                        text = title,
                                        color = Color.White,
                                        fontSize = 17.sp,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                candidateChoices = emptyList()
                                                autoExtractActive = true
                                                autoCandidateOpened = true
                                                webSearchUrl = urlValue
                                                webViewRef?.loadUrl(urlValue)
                                            }
                                            .padding(vertical = 10.dp)
                                    )
                                }

                                Divider(color = Color.DarkGray)
                                Text(
                                    text = "Show web results",
                                    color = Color.Gray,
                                    fontSize = 15.sp,
                                    modifier = Modifier
                                        .clickable {
                                            candidateChoices = emptyList()
                                            autoExtractActive = false
                                        }
                                        .padding(vertical = 10.dp)
                                )
                            }
                        }

                        if (autoExtractActive) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    CircularProgressIndicator(color = Color.White)
                                    Spacer(Modifier.height(14.dp))
                                    Text("Finding lyrics…", color = Color.White, fontSize = 18.sp)
                                }
                            }
                        }

                        AndroidView(
                            factory = { ctx ->
                                WebView(ctx).apply {
                                    settings.javaScriptEnabled = true
                                    settings.domStorageEnabled = true
                                    settings.loadsImagesAutomatically = true
                                    webViewClient = object : WebViewClient() {
                                        override fun onPageFinished(view: WebView, url: String?) {
                                            super.onPageFinished(view, url)
                                            if (webSearchQuery.isBlank()) return

                                            val current = url.orEmpty()

                                            if (autoExtractActive && current.contains("google.", ignoreCase = true)) {
                                                // Search page: first detect a true no-results page.
                                                view.evaluateJavascript(
                                                    "(document.body && document.body.innerText ? document.body.innerText : '').toLowerCase()"
                                                ) { bodyJson ->
                                                    val body = try {
                                                        org.json.JSONTokener(bodyJson).nextValue() as? String ?: ""
                                                    } catch (_: Exception) { "" }

                                                    val noResults = body.contains("did not match any documents") ||
                                                        body.contains("no results found") ||
                                                        body.contains("nema rezultata")

                                                    if (noResults && !autoExtractTriedText) {
                                                        autoExtractTriedText = true
                                                        val fallback = webSearchUrlFor(webSearchQuery, "text")
                                                        webSearchUrl = fallback
                                                        view.loadUrl(fallback)
                                                        return@evaluateJavascript
                                                    }

                                                    // Collect a few normal text-page candidates instead of
                                                    // silently choosing the first hit. This avoids opening the
                                                    // wrong song when several artists use the same title.
                                                    val collectResultsJs = """
                                                        (function() {
                                                          const out = [];
                                                          const seen = new Set();
                                                          const links = Array.from(document.querySelectorAll('a[href]'));
                                                          for (const a of links) {
                                                            const h = (a.href || '').trim();
                                                            if (!/^https?:/i.test(h)) continue;
                                                            const low = h.toLowerCase();
                                                            if (low.includes('google.')) continue;
                                                            if (low.includes('youtube.com') || low.includes('youtu.be')) continue;
                                                            if (low.includes('/video') || low.includes('/shorts')) continue;
                                                            if (seen.has(h)) continue;

                                                            let label = (a.innerText || '').replace(/\\s+/g, ' ').trim();
                                                            if (label.length < 3) continue;
                                                            if (label.length > 120) label = label.slice(0, 120);

                                                            seen.add(h);
                                                            out.push({title: label, url: h});
                                                            if (out.length >= 5) break;
                                                          }
                                                          return JSON.stringify(out);
                                                        })();
                                                    """.trimIndent()

                                                    view.evaluateJavascript(collectResultsJs) { candidatesJson ->
                                                        try {
                                                            val outer = if (candidatesJson == null || candidatesJson == "null") "" else
                                                                org.json.JSONTokener(candidatesJson).nextValue() as? String ?: ""
                                                            val arr = org.json.JSONArray(outer)
                                                            val parsed = buildList {
                                                                for (i in 0 until arr.length()) {
                                                                    val item = arr.optJSONObject(i) ?: continue
                                                                    val title = item.optString("title").trim()
                                                                    val urlValue = item.optString("url").trim()
                                                                    if (title.isNotBlank() && urlValue.isNotBlank()) {
                                                                        add(title to urlValue)
                                                                    }
                                                                }
                                                            }

                                                            if (parsed.size == 1) {
                                                                autoCandidateOpened = true
                                                                view.loadUrl(parsed.first().second)
                                                            } else if (parsed.isNotEmpty()) {
                                                                candidateChoices = parsed
                                                                autoExtractActive = false
                                                            } else if (!autoExtractTriedText) {
                                                                autoExtractTriedText = true
                                                                val fallback = webSearchUrlFor(webSearchQuery, "text")
                                                                webSearchUrl = fallback
                                                                view.loadUrl(fallback)
                                                            } else {
                                                                autoExtractActive = false
                                                                Toast.makeText(context, "Web fallback", Toast.LENGTH_SHORT).show()
                                                            }
                                                        } catch (_: Exception) {
                                                            autoExtractActive = false
                                                            Toast.makeText(context, "Web fallback", Toast.LENGTH_SHORT).show()
                                                        }
                                                    }
                                                }
                                            } else if (autoExtractActive && autoCandidateOpened) {
                                                // Candidate text page: try extracting immediately.
                                                view.evaluateJavascript(lyricsExtractionJs()) { result ->
                                                    applyExtractedResult(view, result, automatic = true)
                                                }
                                            }
                                        }
                                    }
                                    setBackgroundColor(android.graphics.Color.BLACK)
                                    webViewRef = this
                                    webSearchUrl?.let { loadUrl(it) }
                                }
                            },
                            update = { view ->
                                webViewRef = view
                                val target = webSearchUrl
                                if (target != null && view.url != target && view.url.isNullOrBlank()) {
                                    view.loadUrl(target)
                                }
                            },
                            modifier = if (autoExtractActive || candidateChoices.isNotEmpty()) {
                                Modifier
                                    .fillMaxWidth()
                                    .height(1.dp)
                            } else {
                                Modifier
                                    .weight(1f)
                                    .fillMaxWidth()
                            }
                        )
                    }
                } else if (openedText != null) {
                    // Reader: only the controls that directly help on stage.
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = openedTitle.removeSuffix(".txt"),
                            color = Color.White,
                            fontSize = 18.sp,
                            maxLines = 1,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Center
                        )

                        TextButton(
                            onClick = {
                                fontSize = (fontSize - 2f).coerceAtLeast(16f)
                                prefs.edit().putFloat("font_size", fontSize).apply()
                            }
                        ) { Text("A−", color = Color.White, fontSize = 18.sp) }

                        TextButton(
                            onClick = {
                                fontSize = (fontSize + 2f).coerceAtMost(60f)
                                prefs.edit().putFloat("font_size", fontSize).apply()
                            }
                        ) { Text("A+", color = Color.White, fontSize = 18.sp) }
                    }

                    Text(
                        text = openedText ?: "",
                        color = Color.White,
                        fontSize = fontSize.sp,
                        lineHeight = (fontSize * 1.35f).sp,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 18.dp, vertical = 8.dp)
                    )
                } else {
                    if (isRoot) {
                        // Home: larger muted banner, two stage-friendly search rows, then folders.
                        Image(
                            painter = painterResource(id = R.drawable.giglyrics_piano_banner),
                            contentDescription = "GigLyrics",
                            contentScale = ContentScale.FillWidth,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .padding(start = 8.dp, end = 0.dp, top = 2.dp, bottom = 0.dp)
                        )

                        BoxWithConstraints(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp)
                        ) {
                            // Both text fields are exactly the same width. On smaller screens
                            // the width shrinks just enough to keep the large mic buttons usable.
                            val safeHalfWidth = (maxWidth - 192.dp).coerceAtLeast(120.dp)
                            val searchFieldWidth = (maxWidth * 0.50f).coerceAtMost(safeHalfWidth)

                            Column(Modifier.fillMaxWidth()) {
                                // LOCAL: starts at the left edge. Thin field, oversized mic.
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedTextField(
                                        value = searchQuery,
                                        onValueChange = { doSearch(it) },
                                        placeholder = { Text("Search lyrics", fontSize = 21.sp) },
                                        singleLine = true,
                                        shape = RoundedCornerShape(14.dp),
                                        textStyle = LocalTextStyle.current.copy(fontSize = 24.sp),
                                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                        keyboardActions = KeyboardActions(
                                            onSearch = { doSearch(searchQuery) },
                                            onDone = { doSearch(searchQuery) }
                                        ),
                                        modifier = Modifier
                                            .width(searchFieldWidth)
                                            .heightIn(min = 60.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedTextColor = Color.White,
                                            unfocusedTextColor = Color.White,
                                            focusedBorderColor = Color.White,
                                            unfocusedBorderColor = Color.White,
                                            cursorColor = Color.White,
                                            focusedPlaceholderColor = Color(0xFFB0B0B0),
                                            unfocusedPlaceholderColor = Color(0xFFB0B0B0)
                                        )
                                    )

                                    Spacer(Modifier.width(8.dp))

                                    Surface(
                                        modifier = Modifier
                                            .size(96.dp)
                                            .clickable { launchVoiceSearch() },
                                        color = Color.Black,
                                        contentColor = Color.White,
                                        shape = RoundedCornerShape(18.dp),
                                        border = androidx.compose.foundation.BorderStroke(2.dp, Color.White)
                                    ) {
                                        MicGlyph(Modifier.fillMaxSize().padding(13.dp))
                                    }

                                    Column(
                                        modifier = Modifier.width(46.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        TextButton(
                                            onClick = {
                                                listFontSize = (listFontSize + 2f).coerceAtMost(48f)
                                                prefs.edit().putFloat("list_font_size", listFontSize).apply()
                                            },
                                            modifier = Modifier.size(44.dp),
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text("+", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Light)
                                        }
                                        TextButton(
                                            onClick = {
                                                listFontSize = (listFontSize - 2f).coerceAtLeast(16f)
                                                prefs.edit().putFloat("list_font_size", listFontSize).apply()
                                            },
                                            modifier = Modifier.size(44.dp),
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text("−", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Light)
                                        }
                                    }
                                }

                                Spacer(Modifier.height(2.dp))

                                // WEB: mirrored layout; the text field itself reaches the right edge.
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    Surface(
                                        modifier = Modifier
                                            .size(96.dp)
                                            .clickable { launchWebVoiceSearch() },
                                        color = Color.Black,
                                        contentColor = Color.White,
                                        shape = RoundedCornerShape(18.dp),
                                        border = androidx.compose.foundation.BorderStroke(2.dp, Color.White)
                                    ) {
                                        MicGlyph(Modifier.fillMaxSize().padding(13.dp))
                                    }

                                    Spacer(Modifier.width(6.dp))

                                    Surface(
                                        modifier = Modifier
                                            .size(72.dp)
                                            .clickable { launchWebSearch(webSearchQuery) },
                                        color = Color.Black,
                                        contentColor = Color.White,
                                        shape = RoundedCornerShape(16.dp),
                                        border = androidx.compose.foundation.BorderStroke(2.dp, Color.White)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text("🌍", fontSize = 35.sp)
                                        }
                                    }

                                    Spacer(Modifier.width(6.dp))

                                    OutlinedTextField(
                                        value = webSearchQuery,
                                        onValueChange = { webSearchQuery = it },
                                        placeholder = { Text("Web search", fontSize = 21.sp) },
                                        singleLine = true,
                                        shape = RoundedCornerShape(14.dp),
                                        textStyle = LocalTextStyle.current.copy(fontSize = 24.sp),
                                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                        keyboardActions = KeyboardActions(
                                            onSearch = { launchWebSearch(webSearchQuery) },
                                            onDone = { launchWebSearch(webSearchQuery) }
                                        ),
                                        modifier = Modifier
                                            .width(searchFieldWidth)
                                            .heightIn(min = 60.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedTextColor = Color.White,
                                            unfocusedTextColor = Color.White,
                                            focusedBorderColor = Color.White,
                                            unfocusedBorderColor = Color.White,
                                            cursorColor = Color.White,
                                            focusedPlaceholderColor = Color(0xFFB0B0B0),
                                            unfocusedPlaceholderColor = Color(0xFFB0B0B0)
                                        )
                                    )
                                }
                            }
                        }

                        val homeList = if (searching) {
                            searchResults
                        } else {
                            entries.filterNot {
                                it.isDirectory && it.name.equals("Downloaded Lyrics", ignoreCase = true)
                            }
                        }

                        if (!searching && rootUri != null) {
                            Spacer(Modifier.height(14.dp))
                            Box(
                                modifier = Modifier
                                    .align(Alignment.CenterHorizontally)
                                    .fillMaxWidth(0.46f)
                                    .height(40.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color(0xFF242424))
                                    .clickable {
                                        val folder = downloadedLyricsUri
                                            ?: rootUri?.let { ensureDownloadedLyricsFolder(it) }
                                        if (folder != null) navigateTo(NavLocation(folder))
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Downloaded Lyrics",
                                    color = Color.White,
                                    fontSize = 21.sp,
                                    fontWeight = FontWeight.Medium,
                                    textAlign = TextAlign.Center
                                )
                            }
                            Spacer(Modifier.height(10.dp))
                        }

                        HomeBrowserList(
                            listToShow = homeList,
                            searching = searching,
                            listFontSize = listFontSize,
                            modifier = Modifier.weight(1f),
                            showDownloaded = false,
                            onDownloadedClick = {
                                val folder = downloadedLyricsUri ?: rootUri?.let { ensureDownloadedLyricsFolder(it) }
                                if (folder != null) navigateTo(NavLocation(folder))
                            },
                            onEntryClick = { item ->
                                if (item.isDirectory) {
                                    currentUri?.let { navigateTo(NavLocation(item.uri)) }
                                } else {
                                    val folder = currentUri ?: rootUri
                                    if (folder != null) {
                                        navigateTo(NavLocation(folder, item.uri, item.name))
                                    }
                                }
                            }
                        )
                    } else {
                        // Inside folders: deliberately minimal.
                        Text(
                            text = currentTitle,
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        )

                        BrowserList(
                            listToShow = if (searching) searchResults else entries,
                            searching = searching,
                            listFontSize = listFontSize,
                            modifier = Modifier.weight(1f),
                            onEntryClick = { item ->
                                if (item.isDirectory) {
                                    navigateTo(NavLocation(item.uri))
                                } else {
                                    val folder = currentUri ?: return@BrowserList
                                    navigateTo(NavLocation(folder, item.uri, item.name))
                                }
                            }
                        )
                    }
                }

                // Stage controls: back, HOME, donate, forward.
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(104.dp)
                        .padding(horizontal = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = { goBack() },
                        enabled = searching || backHistory.isNotEmpty(),
                        modifier = Modifier.size(92.dp),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        NavChevron(
                            pointsRight = false,
                            modifier = Modifier.size(82.dp)
                        )
                    }

                    TextButton(
                        onClick = { goHome() },
                        enabled = rootUri != null && !isRoot,
                        modifier = Modifier.size(76.dp),
                        contentPadding = PaddingValues(8.dp)
                    ) {
                        HomeGlyph(Modifier.fillMaxSize())
                    }

                    Column(
                        modifier = Modifier
                            .clickable { openDonate() }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("♥", color = Color(0xFFE53935), fontSize = 36.sp, lineHeight = 34.sp)
                        Text(
                            "Donate",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontFamily = FontFamily.Cursive,
                            lineHeight = 20.sp
                        )
                    }

                    TextButton(
                        onClick = { goForward() },
                        enabled = forwardHistory.isNotEmpty(),
                        modifier = Modifier.size(92.dp),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        NavChevron(
                            pointsRight = true,
                            modifier = Modifier.size(82.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeBrowserList(
    listToShow: List<Entry>,
    searching: Boolean,
    listFontSize: Float,
    modifier: Modifier = Modifier,
    showDownloaded: Boolean,
    onDownloadedClick: () -> Unit,
    onEntryClick: (Entry) -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(vertical = 8.dp)
    ) {
        items(listToShow, key = { it.uri.toString() }) { item ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onEntryClick(item) }
                    .padding(horizontal = 18.dp, vertical = 13.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (item.isDirectory) "›  ${item.name}" else item.name.removeSuffix(".txt"),
                    color = Color.White,
                    fontSize = listFontSize.sp,
                    fontWeight = if (item.isDirectory) FontWeight.SemiBold else FontWeight.Normal,
                    textAlign = TextAlign.Center
                )
                if (searching && item.pathLabel.isNotBlank()) {
                    Text(
                        text = item.pathLabel,
                        color = Color.Gray,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }

        if (showDownloaded) {
            item(key = "__downloaded_lyrics__") {
                Column(Modifier.fillMaxWidth()) {
                    HorizontalDivider(
                        modifier = Modifier.padding(horizontal = 32.dp, vertical = 4.dp),
                        thickness = 1.dp,
                        color = Color(0xFF555555)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Downloaded Lyrics",
                        color = Color(0xFFD0D0D0),
                        fontSize = (listFontSize - 6f).coerceAtLeast(12f).sp,
                        fontWeight = FontWeight.Normal,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onDownloadedClick() }
                            .padding(horizontal = 18.dp, vertical = 8.dp)
                    )
                }
            }
        }

        if (searching && listToShow.isEmpty()) {
            item {
                Text(
                    text = "Nema rezultata.",
                    color = Color.Gray,
                    fontSize = 18.sp,
                    modifier = Modifier.fillMaxWidth().padding(20.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun BrowserList(
    listToShow: List<Entry>,
    searching: Boolean,
    listFontSize: Float,
    modifier: Modifier = Modifier,
    onEntryClick: (Entry) -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(vertical = 8.dp)
    ) {
        items(listToShow, key = { it.uri.toString() }) { item ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onEntryClick(item) }
                    .padding(horizontal = 18.dp, vertical = 13.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (item.isDirectory) "›  ${item.name}" else item.name.removeSuffix(".txt"),
                    color = Color.White,
                    fontSize = listFontSize.sp,
                    fontWeight = if (item.isDirectory) FontWeight.SemiBold else FontWeight.Normal,
                    textAlign = TextAlign.Center
                )

                if (searching && item.pathLabel.isNotBlank()) {
                    Text(
                        text = item.pathLabel,
                        color = Color.Gray,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }

        if (searching && listToShow.isEmpty()) {
            item {
                Text(
                    text = "Nema rezultata.",
                    color = Color.Gray,
                    fontSize = 18.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun NavChevron(
    pointsRight: Boolean,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val insetX = size.width * 0.28f
        val insetY = size.height * 0.18f
        val centerY = size.height / 2f
        val leftX = insetX
        val rightX = size.width - insetX
        val tipX = if (pointsRight) rightX else leftX
        val outerX = if (pointsRight) leftX else rightX

        val path = Path().apply {
            moveTo(outerX, insetY)
            lineTo(tipX, centerY)
            lineTo(outerX, size.height - insetY)
        }

        drawPath(
            path = path,
            color = Color.White,
            style = Stroke(
                width = size.minDimension * 0.095f,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }
}

@Composable
private fun HomeGlyph(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val stroke = size.minDimension * 0.10f
        val left = size.width * 0.20f
        val right = size.width * 0.80f
        val roofY = size.height * 0.43f
        val peakY = size.height * 0.18f
        val bottomY = size.height * 0.82f
        val cx = size.width / 2f

        val roof = Path().apply {
            moveTo(left, roofY)
            lineTo(cx, peakY)
            lineTo(right, roofY)
        }
        drawPath(
            path = roof,
            color = Color.White,
            style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        val body = Path().apply {
            moveTo(size.width * 0.28f, roofY * 0.95f)
            lineTo(size.width * 0.28f, bottomY)
            lineTo(size.width * 0.72f, bottomY)
            lineTo(size.width * 0.72f, roofY * 0.95f)
        }
        drawPath(
            path = body,
            color = Color.White,
            style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        drawLine(
            color = Color.White,
            start = Offset(size.width * 0.46f, bottomY),
            end = Offset(size.width * 0.46f, size.height * 0.62f),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color.White,
            start = Offset(size.width * 0.46f, size.height * 0.62f),
            end = Offset(size.width * 0.60f, size.height * 0.62f),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color.White,
            start = Offset(size.width * 0.60f, size.height * 0.62f),
            end = Offset(size.width * 0.60f, bottomY),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
    }
}

@Composable
private fun MiniMicLogo(modifier: Modifier = Modifier) {
    MicGlyph(modifier)
}

@Composable
private fun MicGlyph(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val top = h * 0.12f
        val bottom = h * 0.58f
        val radius = w * 0.18f

        drawRoundRect(
            color = Color.White,
            topLeft = Offset(cx - radius, top),
            size = androidx.compose.ui.geometry.Size(radius * 2f, bottom - top),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius)
        )

        drawArc(
            color = Color.White,
            startAngle = 0f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = Offset(w * 0.20f, h * 0.26f),
            size = androidx.compose.ui.geometry.Size(w * 0.60f, h * 0.48f),
            style = Stroke(width = w * 0.08f, cap = StrokeCap.Round)
        )

        drawLine(
            color = Color.White,
            start = Offset(cx, h * 0.70f),
            end = Offset(cx, h * 0.88f),
            strokeWidth = w * 0.08f,
            cap = StrokeCap.Round
        )

        drawLine(
            color = Color.White,
            start = Offset(w * 0.34f, h * 0.88f),
            end = Offset(w * 0.66f, h * 0.88f),
            strokeWidth = w * 0.08f,
            cap = StrokeCap.Round
        )
    }
}
