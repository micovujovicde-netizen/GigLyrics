# Gig Lyrics — v1.23 BETA

Minimalistički Android browser za veliku kolekciju `.txt` lyrics fajlova.

## Šta radi
- Native Android app
- Dark mode uvijek
- Prikazuje samo foldere i `.txt` fajlove
- Bez datuma, veličine fajla, metadata i sličnog
- Folderi uvijek idu prvi
- Otvara tekst preko cijelog ekrana
- `A−` / `A+` mijenjaju veličinu teksta
- Pamti izabrani glavni folder
- Pamti posljednji folder
- Pamti veličinu fonta
- Search po imenu pjesme kroz sve podfoldere
- Google/Android voice search preko mikrofona: izgovoriš ime pjesme i dobiješ rezultate

## Kako radi pristup fajlovima
Prvi put biraš glavni lyrics folder kroz Android folder picker.
App zatim čuva trajnu read dozvolu, tako da ne treba stalno da pita za potvrdu.

## Build
1. Otvori folder `GigLyrics` u Android Studio.
2. Sačekaj Gradle sync.
3. Build > Build App Bundles or APKs > Build APK(s).
4. APK će biti u `app/build/outputs/apk/debug/`.

## Napomena za voice search
Voice search koristi Android/Google speech recognizer koji već postoji na uređaju.
Ako uređaj nema speech recognition servis, mikrofon neće moći da pokrene pretragu.

## Minimalni Android
Android 8.0 (API 26) ili noviji.


## v1.23 BETA
- Local i Web search su u dva odvojena reda.
- Search polja su iste širine i malo tanja.
- Local search počinje uz lijevi kraj; Web search završava uz desni kraj.
- Mikrofoni su povećani radi lakšeg pogađanja na bini.
- Enter/Search na Android tastaturi odmah pokreće odgovarajuću pretragu.
- Voice search automatski pokreće pretragu kad završi prepoznavanje govora.
- Banner je veći, a Downloaded Lyrics je vizuelno odvojeniji od search zone.

## v1.24 BETA
- Piano banner is darker and visually quieter.
- Keyboard artwork continues as a very dim background behind the search area and root folder listing.
- Local/Web search rows have more balanced visual weight while keeping Local anchored left and Web anchored right.
- Search fields remain the same length and slightly thinner; microphone buttons stay oversized for stage use.
- Downloaded Lyrics is separated further from the search area.
- Search controls use a darker translucent surface so the background can continue without hurting readability.


## v1.26 BETA
- Continuous ultra-dim piano wallpaper across the full home screen, including behind the bottom stage controls.
- Removed the mid-screen wallpaper cutoff.
- Embedded WebView uses Android algorithmic darkening/force-dark when supported.
- Web pages also receive a black document/theme background after load to reduce bright white flashes on stage.
