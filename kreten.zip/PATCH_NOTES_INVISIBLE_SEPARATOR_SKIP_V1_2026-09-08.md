# INVISIBLE_SEPARATOR_SKIP_V1 — 2026-09-08

Minimal Cecil/Whisper continuity patch only.

- Added one shared sanitizer for separator lines before `stageIgnoreLine()` evaluates them.
- Treats BOM (`U+FEFF`), zero-width space (`U+200B`), and NBSP (`U+00A0`) as blank/separator content.
- `stagePhysicalBlank()` now uses the same sanitizer, so header detection and Cecil/Whisper line walking agree.
- No threshold, matcher, NEXT/NEXT2 evidence, microphone, UI, or max-advance rule was changed.
- Targeted simulation confirms invisible separators and structural labels consume zero recognition steps; lookahead lands on the next real lyric line.
