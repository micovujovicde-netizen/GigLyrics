# Stage singer watermark visibility +30%

- Increased the existing singer/studio-mic watermark visibility by exactly 30% relative to its prior values.
- Original artwork, geometry, position, three-row slicing, lyric bars, and lyric text are unchanged.
- Toolbar gear/mic remain unchanged.
- Cecil and Whisper sync logic are untouched.

Opacity values:
- 0.055 -> 0.0715
- 0.038 -> 0.0494
- 0.045 -> 0.0585
