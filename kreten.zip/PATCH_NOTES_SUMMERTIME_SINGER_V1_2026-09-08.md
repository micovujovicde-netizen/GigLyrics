# Summertime singer watermark V1
- Replaced only the three-row cue watermark silhouette with the approved reference proportions.
- Female singer stays compact on the right with raised bun and open singing mouth.
- Condenser studio microphone and round pop filter sit immediately to her left.
- Preserved the previously approved +30% relative visibility values exactly.
- No changes to cue colors/text, Cecil, Whisper, sync matching, or touch tutorial timing/size.
