# MIC lifecycle rearm removed — 2026-09-12

- Removed the ON_START / ON_STOP microphone lifecycle rearm introduced in MIC_LIFECYCLE_REARM_V1.
- Removed `stageLifecycleActive` from the capture DisposableEffect.
- Restored the capture effect trigger/guard to the pre-rearm behavior.
- Cecil matcher, thresholds, anti-jump, NEXT/NEXT2, gain, NoiseSuppressor, UI tracking, and existing restart-token behavior are otherwise untouched.
