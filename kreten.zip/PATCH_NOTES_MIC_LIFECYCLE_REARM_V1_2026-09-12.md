# MIC lifecycle rearm V1 — 2026-09-12

- Fixes stage microphone becoming silent after screen OFF/background and return.
- ON_STOP disposes the active Cecil/Whisper AudioRecord capture.
- ON_START creates a fresh capture session automatically when SYNC was already ON and a song is open.
- Current lyric line/highlight is preserved.
- Cecil/Whisper matcher, thresholds, anti-jump, NEXT/NEXT2, gain and NoiseSuppressor rules are unchanged.
- Black Box logs lifecycle release/rearm events.
