# Toolbar LUX icons V1 — 2026-09-08

- Restored/preserved the existing singer + studio-mic watermark in the three lyric cue bars exactly as it was in the incoming ZIP.
- Reworked only the top toolbar SETTINGS gear and LYR SYNC microphone to match the approved LUX render direction.
- Gear: metallic silver face, subtle warm/gold edge, stronger dimensional highlights.
- LYR SYNC mic: compact vintage/studio microphone with metallic shading and grille detail.
- Cecil/Whisper matching, cue colors, singer watermark, sync hint timing, and lyric behavior are untouched.
