# Stage singer watermark V1 — 2026-09-08

- Keeps the Cecil/Whisper 10/10 recognition logic untouched.
- Keeps the existing three-color LUX cue geometry and colors untouched.
- Adds one minimalist monochrome singer + studio microphone watermark across the three highlighted lyric rows.
- Microphone is on the LEFT, singer is on the RIGHT.
- Artwork is very low-opacity and drawn before lyric text, so yellow lyric glyphs remain fully unobstructed.
- Artwork is sliced across the three physical cue rows so it reads as one continuous image rather than three repeated icons.
- Existing polished top toolbar (green SYNC ON / white OFF, mic icon, gear) preserved.
