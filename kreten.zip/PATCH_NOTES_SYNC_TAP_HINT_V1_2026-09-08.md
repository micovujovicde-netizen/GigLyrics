# SYNC tap hint V1 — 2026-09-08

- Trigger: explicit LYR SYNC OFF -> ON only (including first permission grant).
- Duration: exactly 3.5 s.
- 0.0–1.5 s: subtle white fingertip taps near the middle of the lyric area with a soft ripple.
- 1.5–3.0 s: same fingertip taps near the lower lyric area.
- 3.0–3.5 s: gentle fade-out.
- Overlay is draw-only and cannot consume touch input.
- No changes to Cecil/Whisper recognition, thresholds, NEXT/NEXT2, stage line logic, locked singer watermark, or highlight geometry.
