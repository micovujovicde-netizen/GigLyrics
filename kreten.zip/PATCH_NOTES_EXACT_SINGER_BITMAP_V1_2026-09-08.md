# EXACT SINGER BITMAP V1 — 2026-09-08

- Replaced the approximate Compose vector singer with the exact user-supplied black/white singer artwork.
- Preserved the requested composition: condenser microphone + pop filter on the left, singer profile on the right.
- Artwork occupies the right ~43% of the three-row cue and spans all three highlighted rows as one continuous image.
- Bitmap is a transparent watermark drawn before lyric glyphs; yellow lyrics remain dominant.
- Cecil, Whisper, NEXT/NEXT2, cue colors, tap hint, toolbar and all recognition logic are untouched.
