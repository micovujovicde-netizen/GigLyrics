# LyrGig v69 — responsive phone/tablet UI

- One APK now chooses a compact phone face below 600dp width and the existing roomy tablet face at 600dp+.
- Phone: compact Local/Web controls, smaller title/chrome, wider Downloaded pill, shorter bottom navigation, preserved large touch targets.
- Tablet: keeps the existing larger stage-friendly proportions and user-adjustable folder font.
- Music-stand wallpaper uses Fit on phones and existing FillBounds on tablets.
- Voice engines, matching, anti-jump, duplicate logic, smart header, and Whisper 2.8 s / 280 ms timing are untouched.
