# Whisper latency micro-tune v63

- Whisper rolling audio window: 2.8 s -> 2.0 s.
- Whisper decode cadence: 600 ms -> 400 ms.
- Matcher, recycle V3, duplicate handling, and all Cecil logic unchanged.
- Goal: reduce perceived lyric-follow lag without loosening NEXT admission further.
