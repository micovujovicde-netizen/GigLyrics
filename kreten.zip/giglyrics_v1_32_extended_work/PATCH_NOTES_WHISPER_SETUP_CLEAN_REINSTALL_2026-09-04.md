# Whisper EX-YU setup button + reinstall cleanup

- Cecil/Vosk code is untouched.
- Setup has a large explicit `DOWNLOAD ŠAPTAČ • ~100 MB` button with live percentage.
- Whisper model remains app-private under `filesDir/whisper/yu-tiny-int8`.
- On APK reinstall/update (package `lastUpdateTime` changes), the old Whisper model is deleted before warmup. This prevents an orphaned ~100 MB model surviving repeated install-over cycles.
- Android uninstall also deletes app-private `filesDir`/`cacheDir` normally.
