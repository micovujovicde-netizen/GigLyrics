# FRANKI BETA — Omnilingual v2

- Experimental build name: **FRANKI BETA**.
- Removed Vosk/Cecil/Polish from this experimental branch only. Keep the previous Cecil build as GOLD backup.
- One optional sherpa-onnx Omnilingual ASR v2 300M INT8 listener for all languages.
- Model is **not bundled** and is **never auto-downloaded**. First MIC/LIVE SYNC use asks the user before downloading (~235 MB compressed).
- Once installed it runs locally/offline from app-private storage.
- The proven lyric tracker remains linear: CURRENT / NEXT / NEXT+1 only.
- Microphone stays continuously open; Omnilingual offline ASR is fed overlapping rolling windows in a separate decoder thread.
- This is a beta acoustic test, not a release checkpoint.
