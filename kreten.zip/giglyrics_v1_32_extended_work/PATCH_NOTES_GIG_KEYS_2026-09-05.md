# Gig tuning keys — 2026-09-05

Applied without changing Cecil/Vosk or Whisper matcher confidence thresholds.

1. Cecil lookahead: CURRENT + NEXT only; no NEXT+1.
2. Cecil and Whisper anti-jump: one recognition result advances at most one lyric line.
3. Whisper latency: 2 s rolling audio window, decode attempt every 600 ms.
4. One-word ENTER: one confident CURRENT-line word may advance +1 for both Cecil and Whisper. If the only evidence is shared with NEXT, require additional CURRENT-line evidence. Repeated words are fresh after line advance.
5. Whisper accepted audio is consumed while preserving newer audio recorded during inference, preventing stale-word re-use across lines.
6. Visual highlight: always two physically adjacent displayed rows (N and N+1), independent of matcher filtering; rolling window moves with stageLineIndex.
7. Setup voice button label remains ENG + EX/YU.
8. Cleaner/restore UI and engine remain removed.
