# LyrGig all Vosk languages V1 — 2026-09-13

- Every listed voice language now maps to a real Vosk model package.
- Added per-language DOWNLOAD / progress / READY / UNLOAD state.
- Installed Vosk languages are selectable in SONG LANGUAGE and load on demand.
- Manual non-English Vosk language selection persists across songs instead of being overwritten by English/Montenegrin auto-detection.
- English and Montenegrin keep their existing behavior; Montenegrin remains the Whisper lane.
- Removed the dead "not wired yet" behavior.
