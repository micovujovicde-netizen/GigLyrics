# LyrGig v99 — Lyrics Cleanup decision gate

- Keeps filename/title-only identification.
- Groups live/remaster/acoustic/radio/official-video variants of the same artist+song as one identity.
- Title-only filename auto-accepts when plausible hits collapse to one real artist+song identity.
- Genuine different artist/song identities remain in the end-of-run choice popup.
- ARTIST - SONG filenames can auto-accept the clear best identity even when multiple editions exist.
- No Cecil or Whisper voice-engine logic changed.
- Artist shorthand/initials are accepted for matching (for example A. Lukas -> Aca Lukas).
