# LyrGig v98 — Lyrics Cleanup metadata-only identity

- Filename/title identity remains the only discovery signal.
- Strip bracketed annotations and tonal/chord tokens before search and output naming.
- Standardized metadata is only ARTIST - SONG.
- A confirmed title/artist identity is no longer rejected when provider lyric fetch fails.
- If lyrics are unavailable, keep the original TXT text in the separate LyrGig Library and mark identity as identified/pending clean; UPDATE EXISTING SONGS still uses only fully cleaned `done` entries.
- Cecil/Whisper voice logic untouched.
