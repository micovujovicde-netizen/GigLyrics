# MIC BOOST +4 dB V1 — 2026-09-05

- Fixed +4 dB microphone PCM gain for both English and Montenegrin / EX-YU stage voice engines.
- Gain is applied before ASR only and clamped to prevent numeric overflow.
- Cecil/Whisper lyric matcher, anti-jump, duplicate-line and 2.8 s / 280 ms timing rules are unchanged.
- English capture uses the same VOICE_RECOGNITION 16 kHz mono source but feeds boosted PCM directly to Vosk so the boost can be applied.
