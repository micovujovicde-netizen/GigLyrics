# GigLyrics v1.33 beta — NEXT LINE

- Adds microphone-driven NEXT LINE mode only in the opened-lyrics reader.
- No font-size or line-height increase is applied by NEXT LINE.
- Active/next lyric line: dark red background + yellow text.
- When speech recognition matches the highlighted line, highlight advances to the next non-empty line.
- Tapping any lyric line while MIC ON manually repositions the tracker.
- Existing Local/Web search voice buttons are unchanged.
- Adds RECORD_AUDIO permission.

This is a beta experiment. Android speech recognition quality while singing with live background music varies by device and venue.
