# v66 — Whisper latency 2.8 s / 280 ms

Timing-only change from v65:
- Whisper rolling audio context remains 2.8 seconds.
- Whisper decode cadence changes from 310 ms to 280 ms.
- Whisper matching/recycle/duplicate logic unchanged.
- Cecil logic unchanged.
