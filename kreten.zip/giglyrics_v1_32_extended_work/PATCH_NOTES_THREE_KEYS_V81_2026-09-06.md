# LyrGig v81 — three locked keys

1. Whisper now scores CURRENT + NEXT + NEXT2. NEXT2 is evidence only; every recognition result still advances at most one valid lyric line. Cecil matcher is untouched.
2. Global lyric display now highlights three physically adjacent rows. Text remains yellow; bars are orange, red, purple.
3. Existing music-stand bitmap is unchanged; opacity increased by 30% relative, from 0.16 to 0.208.
