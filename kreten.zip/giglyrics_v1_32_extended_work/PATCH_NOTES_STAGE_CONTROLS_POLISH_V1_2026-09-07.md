# LyrGig v87 — Stage controls polish

- Six MIC gain steps: +7, +5, +2, 0, -2, -5 dB; default fallback is 0 dB.
- Quiet gig label above the gain stack; Loud gig below.
- Gain tap target consumes the whole row to prevent first-tap fall-through into folders.
- Stage control renamed to LYR SYNC ON/OFF while retaining the microphone symbol.
- When LYR SYNC is OFF, the three lyric tracking bars are hidden.
- Tracking bars get slightly rounded corners; matching logic unchanged.
- Tablet Downloaded label font increased slightly; phone unchanged.
- LyrGig title uses the green gain LED color, is slightly larger/thinner, alpha 0.80.
- Cecil and Whisper matching helpers are not modified. NEXT2 threshold remains 0.17.
