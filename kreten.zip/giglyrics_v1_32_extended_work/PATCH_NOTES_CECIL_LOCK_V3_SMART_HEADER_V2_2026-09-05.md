# Cecil lock V3 + smart header V2

- Version bumped to 56 / 1.56-cecil-lock-v3 so CI/install cannot silently reuse the old package version.
- Smart one-line header separator accepts true blank, NBSP, zero-width space, and BOM-only lines.
- Cecil now uses a local committed decision cursor, so repeated Vosk callbacks cannot re-fire the same transition while Compose state catches up.
- Cecil one-word NEXT evidence is evaluated only from the newly appended Vosk tail, not from the cumulative transcript.
- Whole-line matcher remains CURRENT + NEXT only; CURRENT-best cannot advance.
- Whisper path unchanged.
