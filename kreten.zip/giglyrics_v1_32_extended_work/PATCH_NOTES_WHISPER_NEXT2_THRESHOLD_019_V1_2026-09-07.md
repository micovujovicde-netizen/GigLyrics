# v88 — Whisper NEXT2 threshold 0.19

- Changed Whisper NEXT2 evidence threshold from 0.17 to 0.19.
- NEXT2 remains evidence only and can advance only CURRENT -> NEXT.
- NEXT matcher gate remains 0.46 / 0.04.
- NEXT2 margin remains 0.01.
- Cecil matcher unchanged.
- Whisper cadence 2.8 s / 280 ms unchanged.
