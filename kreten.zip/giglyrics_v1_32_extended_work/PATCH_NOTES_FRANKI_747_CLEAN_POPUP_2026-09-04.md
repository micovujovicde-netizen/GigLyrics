# FRANKI 747 clean popup

- Removed SELECT MODEL FOLDER from the Franki flow.
- Removed the GitHub release-page WebView from the user flow.
- FRANKI 747 now opens as a small clean in-app popup.
- The popup contains one large DOWNLOAD 747 button plus a close control.
- Download still goes directly to app-private model storage.
- Archive is unpacked there and removed after successful installation.
