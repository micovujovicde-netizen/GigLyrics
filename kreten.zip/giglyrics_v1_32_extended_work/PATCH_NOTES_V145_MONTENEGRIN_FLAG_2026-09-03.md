# GigLyrics 1.45 — Montenegrin flag placement

- Montenegrin is the second NEXT LINE language, immediately below English.
- User-facing label is `🇲🇪 Montenegrin`.
- Montenegrin is intentionally the only language row with a flag.
- Existing 75% NEXT LINE threshold, text filters, Vosk English listener, and scroll behavior are unchanged.
