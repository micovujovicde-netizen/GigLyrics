# LyrGig visual polish v68
- User-visible engine names removed; voice rows show languages only.
- User-visible GigLyrics branding changed to LyrGig.
- Piano background replaced with a similarly subdued music-stand bitmap.
- Launcher icon changed from microphone to music stand.
- Voice matching, timing (2.8 s / 280 ms), duplicate logic and smart-header logic intentionally untouched.
