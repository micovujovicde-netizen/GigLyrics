# LyrGig v97 — Lyrics Cleanup title-only identification

- Song identification now uses only the TXT filename/title. Lyric text is not used as identity evidence.
- `Artist - Title.txt` uses both filename hints; `Title.txt` searches by title.
- One convincing candidate is accepted automatically and standardized to `A. Artist - Title.txt`.
- Multiple plausible candidates are persisted as a durable `choice` checkpoint and shown after the scan for a user tap.
- No plausible candidate remains unresolved; Cleanup never guesses.
- Lyrics are fetched only after a metadata candidate is selected, then cleaned into the separate `LyrGig Library` as before.
- Existing originals remain untouched until explicit UPDATE EXISTING.
- Cecil/Whisper voice matching code is unchanged.
