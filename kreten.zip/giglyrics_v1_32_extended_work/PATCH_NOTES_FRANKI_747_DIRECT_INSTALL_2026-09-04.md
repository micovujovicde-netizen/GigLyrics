# FRANKI 747 direct installer — 2026-09-04

- Replaces external-browser download with a built-in FRANKI browser/install screen.
- Large `DOWNLOAD 747` button downloads the official Sherpa-ONNX omnilingual archive directly into app-private cache.
- The `.tar.bz2` archive is unpacked inside the app; only `model.int8.onnx` and `tokens.txt` are installed into `files/franki/omnilingual-v2-int8`.
- Temporary archive/cache is deleted after install or failure. Nothing is left in Android Downloads.
- Existing manual `SELECT MODEL FOLDER` remains as a fallback.
- Adds Apache Commons Compress for tar+bzip2 extraction.
- Bumps app to 1.60 / versionCode 60.
