# TXT Renamer Tool V1 — 2026-09-07

- Added Setup/Settings -> TOOLS -> TXT RENAMER.
- Four English form buttons:
  - John Smith - Song (Key)
  - J. Smith - Song (Key)
  - Song - John Smith (Key)
  - Song - J. Smith (Key)
- Recursively scans selected folder and .txt files only.
- Normalizes spacing/dashes, artist-first output, full first name to initial when requested.
- Tonality/key is normalized to parentheses when recognized in (), [], {}, <>, mixed closing brackets, or standalone at filename end.
- Whitelist includes Balkan/German notation such as Cis, Dis, Fis, Gis and mol/m variants, plus international #/b forms.
- If no key exists, none is added.
- PREVIEW before RENAME; unsupported/ambiguous files are skipped.
- UNDO LAST RENAME included.
- BB logs folder selection, preview count, apply count, and undo count.
- Cecil/Whisper matching logic unchanged.
