# v77 — Phone home gear spacing

- PHONE ONLY: moved the Settings gear farther above the existing + / − controls.
- + / − positions unchanged.
- Tablet layout unchanged.
- No voice matcher/timing changes.
