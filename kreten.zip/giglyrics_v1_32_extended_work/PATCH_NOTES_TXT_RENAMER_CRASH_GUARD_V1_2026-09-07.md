# TXT Renamer crash guard v1

- Guard every SAF rename operation individually so one provider/filename failure cannot escape the coroutine and restart/crash the app.
- Guard the whole APPLY and UNDO jobs with try/finally and always release busy state.
- Preserve successful renames and report skipped failures.
- Keep Cecil/Whisper matcher and timing logic unchanged.
