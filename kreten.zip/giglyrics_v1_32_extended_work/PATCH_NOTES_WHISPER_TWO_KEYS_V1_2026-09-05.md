# Whisper TWO KEYS v1 — 2026-09-05

- Cecil v58 logic is intentionally untouched.
- Whisper key #1: one characteristic word from NEXT may advance immediately without requiring the whole-line matcher to beat CURRENT.
- Whisper key #2: noisy/fuzzy matching is allowed only heard -> NEXT, with conservative edit/core recovery for tiny-Whisper stage mangling.
- Generic EX-YU words still cannot advance alone; they require two independent NEXT hits.
- CURRENT sharing is exact-normalized only; fuzzy matching is never used against CURRENT.
- Anti-jump remains max +1 valid lyric line per recognition result.
- Whole-line fallback remains CURRENT + NEXT only.
