# Phone Polish V1 (2026-09-05)

Phone-only UI polish. Tablet layout unchanged.

- Stage toolbar respects phone status bar and uses compact title/MIC/settings/font controls.
- Phone Settings stacks language status and DOWNLOAD/UNLOAD vertically to prevent wrapping/collisions.
- Phone download errors are shown as a friendly retry message instead of raw transport text.
- Phone bottom Back/Home/Donate/Next controls are lifted above the navigation bar.
- Recognition engine logic, Cecil/Whisper matcher behavior, duplicate handling, smart header, and Whisper 2.8 s / 280 ms timing are unchanged.
