# LUX 3-row gradient highlight v1 — 2026-09-06

- Kept the existing orange -> red -> purple 3-row cue language.
- Dimmed the three base highlight colors by 20%.
- Blended adjacent rows with matching intermediate shades so the bars flow into each other as one continuous LUX cue.
- Yellow highlighted lyric font remains exactly `0xFFFFFF00`; no font clarity/color change.
- Display-only change. Cecil/Whisper matcher rules, thresholds, timing and +1 advance limits are untouched.
- Version: 1.86-lux-gradient-highlight-v1 (86).
