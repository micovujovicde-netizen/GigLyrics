# LyrGig v100 — Cleanup BB trace

- Reuses the existing Black Box as the Lyrics Cleanup diagnostic recorder while Cleanup runs.
- BB is reset when Cleanup starts.
- Logs FILE, parsed filename hints, search queries, provider hit counts, top candidates/scores, decision branch, and final status.
- No Cecil/Whisper recognition logic changed.
