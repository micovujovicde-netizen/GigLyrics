# LyrGig v101 — Cleanup bracket fix

- Fixes runtime `PatternSyntaxException` in filename metadata cleanup.
- Replaces regex-based removal of `(...)`, `[...]`, `{...}` with a small deterministic scanner.
- Preserves title-only Cleanup logic and BB tracing.
- Cecil/Whisper logic intentionally untouched.
