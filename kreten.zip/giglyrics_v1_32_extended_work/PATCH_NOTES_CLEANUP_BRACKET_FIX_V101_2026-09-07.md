# LyrGig v101 — Cleanup bracket fix

- Fixes runtime `PatternSyntaxException` in filename metadata cleanup.
- Replaces regex-based removal of `(...)`, `[...]`, `{...}` with a small deterministic scanner.
- Cecil/Whisper logic intentionally untouched.
