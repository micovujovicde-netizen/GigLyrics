# LyrGig v79 — MIC gain selector +2/+5/+7 dB

- Replaced selector values with +2 dB, +5 dB, +7 dB in top-to-bottom order.
- Default/fallback gain is +5 dB.
- Selection remains persistent via mic_gain_db preference.
- Same selected gain feeds both Cecil and Whisper capture paths.
- No matcher, anti-jump, or Whisper 2.8 s / 280 ms timing changes.
- UI geometry otherwise unchanged.
