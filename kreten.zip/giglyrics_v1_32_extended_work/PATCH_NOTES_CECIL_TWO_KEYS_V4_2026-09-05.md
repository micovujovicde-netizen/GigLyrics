# Cecil Two Keys V4 — 2026-09-05

- Key 1 — NEW TAIL / NEXT: one characteristic word that just arrived in the Vosk tail and belongs only to NEXT may advance +1 even while the cumulative Vosk line score still prefers CURRENT.
- Key 2 — FUZZY TAIL WORD: small Vosk mistakes are tolerated only for NEW-tail words compared with NEXT words (examples: moonl→moon, astars→stars, jupter→jupiter).
- Common English words cannot trigger on one word; they still need two independent NEXT hits.
- The local Cecil decision cursor/stale-callback guard remains intact, so one accepted transition cannot repeatedly fire while Compose catches up.
- Full matcher remains CURRENT+NEXT only and advances only when NEXT itself wins.
- Smart one-line header separator remains unchanged.
- Whisper was not changed.
