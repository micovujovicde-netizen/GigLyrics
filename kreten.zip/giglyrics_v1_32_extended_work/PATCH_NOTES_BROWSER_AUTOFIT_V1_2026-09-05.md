# v70 — Browser auto-fit V1

UI-only folder-browser polish.

- Long folder/song names stay on one line.
- Only the individual long entry reduces its font size, down to 16sp if needed.
- Normal entries retain the user-selected browser font size.
- Applied to both HomeBrowserList and BrowserList.
- Voice engines, recognition/matching, duplicate guard, smart header, and Whisper 2.8s / 280ms timing are unchanged.
