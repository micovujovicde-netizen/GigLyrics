# GigLyrics v1.44

- NEXT LINE advances only after at least 75% of expected lyric words are recognized.
- Matching remains strictly linear and ordered.
- Existing structural text filters are unchanged.
- Added user-facing Montenegrin 🇲🇪 language row in Setup for the future BCS model download path.
- English Vosk download/offline behavior unchanged.
