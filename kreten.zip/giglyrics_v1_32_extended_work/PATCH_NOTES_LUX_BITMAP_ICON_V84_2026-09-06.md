# LyrGig v84
- Replaced HOME wallpaper with the approved pre-dimmed LUX music-stand/open-blank-book PNG.
- Wallpaper is rendered 1:1 with alpha 1.0; no additional app opacity filter.
- Replaced launcher icon source with the approved original non-dimmed blank-page LUX image.
- Whisper/Cecil matcher logic unchanged.
