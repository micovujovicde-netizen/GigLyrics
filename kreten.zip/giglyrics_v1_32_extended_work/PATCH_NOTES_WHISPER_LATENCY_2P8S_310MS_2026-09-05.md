# Whisper latency 2.8 s / 310 ms

- Whisper rolling audio window: 2.8 seconds.
- Whisper decode cadence: 310 ms.
- Recycle V3, duplicate logic, and Cecil logic unchanged.
