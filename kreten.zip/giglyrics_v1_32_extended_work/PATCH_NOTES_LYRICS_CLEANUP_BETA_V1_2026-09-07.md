# LyrGig v94 — Lyrics Cleanup BETA v1

- TOOLS now exposes **LYRICS CLEANUP — BETA** instead of the filename-only TXT Renamer.
- Cleanup is implemented in a separate `LyricsCleanupEngine.kt` motor. It does not call LyrGig's WebView/browser search path and does not touch Cecil/Whisper.
- It reuses only the already-authorized Local Lyrics SAF root.
- It identifies candidates from characteristic lyric lines through its own direct HTTPS Genius lookup and verifies candidates against fetched lyric text.
- High-confidence matches are cleaned and written to a separate `LyrGig Library` folder; originals remain untouched during cleanup.
- Durable JSON checkpoint `.lyrgig_cleanup_manifest.json` is stored inside that library so progress survives app/process shutdown and can be recovered after reinstall once the same Local Lyrics root is authorized again.
- Generated `LyrGig Library` is excluded from the normal LyrGig local-song index to avoid duplicate search results before update.
- After cleanup, the tool offers an explicit **UPDATE EXISTING SONGS** confirmation. Only that action writes cleaned text back to existing files and attempts the canonical `J. Smith - Song.txt` rename.
- Uncertain songs are skipped, never guessed.
- Existing TXT Renamer implementation remains dormant in source for rollback comparison but has no TOOLS entry.
