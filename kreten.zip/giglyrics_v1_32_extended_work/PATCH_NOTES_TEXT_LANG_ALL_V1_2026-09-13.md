# TEXT_LANG_ALL_V1 — 2026-09-13

- Replaced the old English-vs-Montenegrin lyric detector with a universal text-language router for the languages exposed by Setup.
- Script detection covers Chinese, Japanese, Korean, Greek, Georgian, Gujarati, Telugu, Hindi, Arabic/Persian, Russian/Ukrainian/Kazakh/Kyrgyz/Tajik.
- Latin-script language profiles cover Montenegrin, English, Italian, Spanish, Portuguese, French, German, Dutch, Catalan, Turkish, Swedish, Czech, Polish, Esperanto, Filipino/Tagalog, Breton, Vietnamese and Uzbek.
- Added orthography/diacritic weighting to reduce collisions between related Latin-script languages.
- Every opened song is now detected before microphone startup. Montenegrin routes to Whisper; any other detected installed language routes to its Vosk model and Cecil.
- Ambiguous/too-short Latin text conservatively falls back to English; manual language selection remains available.
- Indian English is not text-distinguishable from English by lyrics alone, so ordinary English text resolves to English; the Indian English model remains manually selectable.
- Arabic Tunisian uses dialect-specific lexical hints and otherwise falls back to Arabic; manual selection remains available for ambiguous dialect text.
- Added BUILD marker: TEXT_LANG_ALL_V1.
