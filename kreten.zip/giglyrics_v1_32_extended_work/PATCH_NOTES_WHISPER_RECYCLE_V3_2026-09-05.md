# Whisper Recycle V3 — v62

- Cecil remains untouched/frozen.
- Whisper NEXT recycle tier loosened further.
- Characteristic NEXT words 6+ letters may match on a 2-letter surviving core.
- Larger edit-distance and length-gap tolerance for mangled tiny-Whisper output.
- Generic/common words retain the old strict rules.
- Whole-line matcher, duplicate-line micro key, 2.8 s context, 600 ms cadence, and max +1 valid lyric line per recognition result remain unchanged.
- CURRENT ambiguity protection intentionally stays at V2 strictness so the wider NEXT tolerance actually has effect.
