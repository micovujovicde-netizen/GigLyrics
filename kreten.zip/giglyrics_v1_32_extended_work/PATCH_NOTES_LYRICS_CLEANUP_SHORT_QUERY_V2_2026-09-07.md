# LyrGig v95 — Lyrics Cleanup short-query V2

- Lyrics Cleanup remains a completely separate engine.
- Search queries are now deliberately short lyric fingerprints: normally 5–9 words, maximum 10 words / 72 characters.
- Long candidate lines get a second short window instead of sending a long block.
- Candidate verification still compares fetched lyrics against the full source, so shorter search does not weaken the final confidence gate.
- Existing `uncertain` manifest entries are retried; already completed `done` entries remain checkpointed.
- Cecil and Whisper matching/timing logic is untouched.
