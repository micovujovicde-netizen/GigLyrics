# Franki fast sync patch

Small, conservative latency patch:
- decode cadence: 1300 ms -> 650 ms
- minimum audio before decode: 1000 ms -> 500 ms
- keeps the existing bounded rolling audio buffer
- keeps matching limited to current + next two lyric lines
- no busy loop and no whole-song rescanning
