plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.teraphonia.giglyrics"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.teraphonia.giglyrics"
        minSdk = 26
        targetSdk = 35
        versionCode = 97
        versionName = "1.97-lyrics-cleanup-title-only-v1"
        manifestPlaceholders["lyricsMatcherBaseUrl"] = project.providers.gradleProperty("LYRGIG_MATCHER_BASE_URL").orElse("").get()

        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    signingConfigs {
        create("stableDebug") {
            storeFile = file("stable-debug.keystore")
            storePassword = "giglyrics123"
            keyAlias = "giglyrics"
            keyPassword = "giglyrics123"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("stableDebug")
        }
    }

    buildFeatures {
        compose = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.01.00"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    implementation("com.alphacephei:vosk-android:0.3.75@aar")
    implementation("com.github.k2-fsa:sherpa-onnx:v1.13.4")
    implementation("net.java.dev.jna:jna:5.18.1@aar")
    debugImplementation("androidx.compose.ui:ui-tooling")
}


kotlin {
    jvmToolchain(17)
}
