package com.teraphonia.giglyrics

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.os.Process

/**
 * BB2: event-only flight recorder.
 * No live rendering, no partial/HOLD/matcher-score spam, no CPU sampler.
 * The event vocabulary mirrors app/src/main/assets/bb2_matrix.js.
 */
object BB2 {
    private const val FILE_NAME = "bb2.log"
    private const val MAX_BYTES = 128 * 1024L
    private const val KEEP_BYTES = 64 * 1024
    private val lock = Any()
    private val allowed = setOf(
        "APP_START", "SONG_OPEN", "MIC_STATE", "ENGINE_SWITCH", "MODEL_LOAD",
        "MODEL_CLOSE", "RECOGNIZER", "ADVANCE", "ERROR", "CPU_SAMPLE"
    )

    data class CpuReading(val processPct: Double, val devicePct: Double, val cores: Int)

    fun cpuReading(): CpuReading? = runCatching {
        fun totalAndIdle(): Pair<Long, Long> {
            val parts = File("/proc/stat").bufferedReader().use { it.readLine() }
                .trim().split(Regex("\\s+"))
            val values = parts.drop(1).take(8).map { it.toLong() }
            return values.sum() to values[3]
        }
        val wall1 = android.os.SystemClock.elapsedRealtime()
        val proc1 = Process.getElapsedCpuTime()
        val (total1, idle1) = totalAndIdle()
        Thread.sleep(250)
        val wall2 = android.os.SystemClock.elapsedRealtime()
        val proc2 = Process.getElapsedCpuTime()
        val (total2, idle2) = totalAndIdle()
        val wallMs = (wall2 - wall1).coerceAtLeast(1L)
        val processPct = (proc2 - proc1).toDouble() / (wallMs * Runtime.getRuntime().availableProcessors()) * 100.0
        val totalTicks = (total2 - total1).coerceAtLeast(1L)
        val idleTicks = (idle2 - idle1).coerceAtLeast(0L)
        val devicePct = (totalTicks - idleTicks).toDouble() / totalTicks * 100.0
        CpuReading(processPct.coerceIn(0.0, 100.0), devicePct.coerceIn(0.0, 100.0), Runtime.getRuntime().availableProcessors())
    }.getOrNull()

    fun snapshot(context: Context): String = synchronized(lock) {
        runCatching {
            val file = File(context.filesDir, FILE_NAME)
            if (file.exists()) file.readText(Charsets.UTF_8) else "BB2 is empty."
        }.getOrElse { "BB2 read error: ${it.message ?: "unknown"}" }
    }

    fun event(context: Context, type: String, vararg fields: Pair<String, Any?>) {
        if (type !in allowed) return
        val stamp = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())
        val body = buildString {
            append(stamp).append("  ").append(type)
            fields.forEach { (key, value) ->
                append(' ').append(key).append('=')
                append(value?.toString()?.replace("\\n", " ")?.replace("\\r", " ") ?: "null")
            }
            append('\n')
        }
        synchronized(lock) {
            runCatching {
                val file = File(context.filesDir, FILE_NAME)
                if (file.exists() && file.length() > MAX_BYTES) {
                    val bytes = file.readBytes()
                    val start = (bytes.size - KEEP_BYTES).coerceAtLeast(0)
                    file.writeBytes(bytes.copyOfRange(start, bytes.size))
                }
                file.appendText(body, Charsets.UTF_8)
            }
        }
    }
}
