package com.teraphonia.giglyrics

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.os.Bundle
import android.text.Html
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.Locale

/**
 * LYRICS CLEANUP BETA
 *
 * Completely independent of LyrGig's WebView/browser/search path and voice engines.
 * The only shared input is the already-authorized Local Lyrics SAF root.
 * Originals are read-only during CLEANUP. Results + durable checkpoint live in
 * a separate "LyrGig Library" folder. Existing songs change only after an
 * explicit UPDATE EXISTING action.
 */
object LyricsCleanupEngine {
    const val LIBRARY_DIR = "LyrGig Library"
    private const val MANIFEST_NAME = ".lyrgig_cleanup_manifest.json"
    private const val MANIFEST_VERSION = 3
    private const val USER_AGENT = "LyrGig-LyricsCleanup/2.0 (Android)"
    private const val MATCHER_META_KEY = "com.teraphonia.giglyrics.LYRICS_MATCHER_BASE_URL"

    data class Progress(
        val done: Int,
        val total: Int,
        val identified: Int,
        val uncertain: Int,
        val current: String
    )

    data class Summary(
        val total: Int,
        val identified: Int,
        val uncertain: Int,
        val failed: Int,
        val updateReady: Int,
        val completed: Boolean
    )

    private data class SourceSong(
        val uri: Uri,
        val relativePath: String,
        val name: String
    )

    private data class Candidate(
        val id: String,
        val artist: String,
        val title: String,
        val lyrics: String?,
        val source: String,
        val sourceUrl: String? = null
    )

    private interface LookupProvider {
        val name: String
        fun search(context: Context, queries: List<String>, originalName: String): List<Candidate>
        fun fetchLyrics(candidate: Candidate): String?
    }

    /**
     * Commercial/global path: the app talks only to one LyrGig matcher backend.
     * The backend is free to aggregate licensed/global providers per market
     * (US/Europe/China/India/etc.) without shipping provider credentials in APK.
     * Configure it with manifest placeholder / Gradle property LYRIG_MATCHER_BASE_URL.
     */
    private object BackendProvider : LookupProvider {
        override val name = "lyrgig-backend"

        override fun search(context: Context, queries: List<String>, originalName: String): List<Candidate> {
            val base = matcherBaseUrl(context) ?: return emptyList()
            val payload = JSONObject()
                .put("queries", JSONArray().apply { queries.take(6).forEach { put(it) } })
                .put("filenameHint", originalName)
                .put("maxCandidates", 12)
                .put("client", "android")
                .put("schema", 1)
            val body = httpPostJson("${base.trimEnd('/')}/v1/identify", payload.toString()) ?: return emptyList()
            val json = runCatching { JSONObject(body) }.getOrNull() ?: return emptyList()
            val arr = json.optJSONArray("candidates") ?: return emptyList()
            val out = mutableListOf<Candidate>()
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val artist = item.optString("artist").trim()
                val title = item.optString("title").trim()
                if (artist.isBlank() || title.isBlank()) continue
                val source = item.optString("source", name).ifBlank { name }
                val externalId = item.optString("id").ifBlank { "$artist|$title" }
                val lyrics = item.optString("lyrics").takeIf { it.isNotBlank() }
                val url = item.optString("url").takeIf { it.startsWith("https://") }
                out += Candidate("$source:$externalId", artist, title, lyrics, source, url)
            }
            return out
        }

        override fun fetchLyrics(candidate: Candidate): String? = candidate.lyrics
    }

    /**
     * BETA fallback only, retained so the current prototype still has something
     * useful to test before a global backend URL is configured. It is isolated
     * behind the same provider interface and can be disabled/removed without
     * touching Cleanup or the rest of LyrGig.
     */
    private object GeniusBetaProvider : LookupProvider {
        override val name = "genius-beta"

        override fun search(context: Context, queries: List<String>, originalName: String): List<Candidate> {
            val out = LinkedHashMap<String, Candidate>()
            queries.take(6).forEach { query ->
                val hits = runCatching { geniusSearch(query) }.getOrElse {
                    emptyList()
                }
                hits.take(5).forEach { out.putIfAbsent(it.id, it) }
            }
            return out.values.toList()
        }

        override fun fetchLyrics(candidate: Candidate): String? {
            candidate.lyrics?.let { return it }
            val url = candidate.sourceUrl ?: return null
            return fetchGeniusLyrics(url)
        }
    }

    private data class Match(
        val candidate: Candidate,
        val lyrics: String?,
        val confidence: Double
    )

    data class Choice(val artist: String, val title: String, val token: String)
    data class AmbiguousSong(val sourcePath: String, val sourceName: String, val choices: List<Choice>)

    fun cleanup(
        context: Context,
        rootUri: Uri,
        onProgress: (Progress) -> Unit = {}
    ): Summary {
        val root = DocumentFile.fromTreeUri(context, rootUri)
            ?: return Summary(0, 0, 0, 1, 0, false)
        val library = root.findFile(LIBRARY_DIR)?.takeIf { it.isDirectory }
            ?: root.createDirectory(LIBRARY_DIR)
            ?: return Summary(0, 0, 0, 1, 0, false)


        val manifest = loadManifest(context, library)
        manifest.put("completed", false)
        saveManifest(context, library, manifest)
        val entries = manifest.optJSONObject("entries") ?: JSONObject().also { manifest.put("entries", it) }
        val sources = mutableListOf<SourceSong>()
        collectSources(root, "", sources)

        var identified = 0
        var uncertain = 0
        var failed = 0

        sources.forEachIndexed { index, song ->
            onProgress(Progress(index, sources.size, identified, uncertain, song.name))
            val sourceText = readText(context, song.uri)
            if (sourceText.isNullOrBlank()) {
                failed++
                putManifestEntry(entries, song, "", "failed", null, null, null, 0.0, "empty/unreadable")
                saveManifest(context, library, manifest)
                return@forEachIndexed
            }

            val fingerprint = sha256(sourceText)
            val previous = entries.optJSONObject(song.relativePath)
            if (previous != null && previous.optString("fingerprint") == fingerprint && previous.optString("status") == "done") {
                identified++
                return@forEachIndexed
            }

            val matchResult = runCatching { identifyFromFilename(context, song, entries, fingerprint) }
            matchResult.exceptionOrNull()?.let {  }
            val match = matchResult.getOrNull()
            if (match == null) {
                val stagedChoice = entries.optJSONObject(song.relativePath)?.optString("status") == "choice"
                uncertain++
                if (!stagedChoice) putManifestEntry(entries, song, fingerprint, "uncertain", null, null, null, 0.0, null)
            } else {
                val cleanArtist = metadataOnly(match.candidate.artist)
                val cleanTitle = metadataOnly(match.candidate.title)
                val outputName = buildOutputName(cleanArtist, cleanTitle)
                val fetched = match.lyrics?.let { cleanLyrics(it) }
                val hasCleanLyrics = fetched != null && fetched.lineSequence().count { it.isNotBlank() } >= 6
                val textForLibrary = if (hasCleanLyrics) fetched!! else sourceText
                val ok = writeLibraryFile(context, library, outputName, textForLibrary)
                if (ok) {
                    identified++
                    putManifestEntry(
                        entries, song, fingerprint, if (hasCleanLyrics) "done" else "identified", cleanArtist,
                        cleanTitle, outputName, match.confidence,
                        if (hasCleanLyrics) null else "identity confirmed; provider lyrics unavailable/pending clean"
                    )
                } else {
                    failed++
                    putManifestEntry(
                        entries, song, fingerprint, "failed", cleanArtist,
                        cleanTitle, outputName, match.confidence, "library write failed"
                    )
                }
            }
            saveManifest(context, library, manifest)
        }

        manifest.put("completed", true)
        saveManifest(context, library, manifest)
        val updateReady = countStatus(entries, "done")
        onProgress(Progress(sources.size, sources.size, identified, uncertain, "Done"))
        return Summary(sources.size, identified, uncertain, failed, updateReady, true)
    }

    fun status(context: Context, rootUri: Uri): Summary {
        val root = DocumentFile.fromTreeUri(context, rootUri) ?: return Summary(0, 0, 0, 0, 0, false)
        val library = root.findFile(LIBRARY_DIR)?.takeIf { it.isDirectory } ?: return Summary(0, 0, 0, 0, 0, false)
        val manifest = loadManifest(context, library)
        val entries = manifest.optJSONObject("entries") ?: JSONObject()
        var done = 0
        var identifiedPending = 0
        var uncertain = 0
        var failed = 0
        val keys = entries.keys()
        while (keys.hasNext()) {
            when (entries.optJSONObject(keys.next())?.optString("status")) {
                "done" -> done++
                "identified" -> identifiedPending++
                "uncertain", "choice" -> uncertain++
                "failed" -> failed++
            }
        }
        val identifiedTotal = done + identifiedPending
        return Summary(identifiedTotal + uncertain + failed, identifiedTotal, uncertain, failed, done, manifest.optBoolean("completed", false))
    }

    fun updateExisting(
        context: Context,
        rootUri: Uri,
        onProgress: (done: Int, total: Int, current: String) -> Unit = { _, _, _ -> }
    ): Pair<Int, Int> {
        val root = DocumentFile.fromTreeUri(context, rootUri) ?: return 0 to 0
        val library = root.findFile(LIBRARY_DIR)?.takeIf { it.isDirectory } ?: return 0 to 0
        val manifest = loadManifest(context, library)
        val entries = manifest.optJSONObject("entries") ?: return 0 to 0
        val ready = mutableListOf<Pair<String, JSONObject>>()
        val keys = entries.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val item = entries.optJSONObject(key) ?: continue
            if (item.optString("status") == "done" && item.optString("outputName").isNotBlank()) ready += key to item
        }

        var ok = 0
        var failed = 0
        ready.forEachIndexed { index, (relativePath, item) ->
            val original = findByRelativePath(root, relativePath)
            val output = library.findFile(item.optString("outputName"))
            onProgress(index, ready.size, original?.name ?: relativePath)
            if (original == null || output == null) {
                failed++
                item.put("updateStatus", "missing")
                saveManifest(context, library, manifest)
                return@forEachIndexed
            }
            val cleaned = readText(context, output.uri)
            if (cleaned.isNullOrBlank() || !writeText(context, original.uri, cleaned)) {
                failed++
                item.put("updateStatus", "write_failed")
                saveManifest(context, library, manifest)
                return@forEachIndexed
            }

            val desired = item.optString("outputName")
            val renamed = if (original.name == desired) original.uri else runCatching {
                DocumentsContract.renameDocument(context.contentResolver, original.uri, desired)
            }.getOrNull()
            if (renamed != null) {
                ok++
                item.put("updateStatus", "updated")
                item.put("updatedName", desired)
            } else {
                // Text is already safely updated; library copy remains the rollback source.
                ok++
                item.put("updateStatus", "updated_text_rename_skipped")
            }
            saveManifest(context, library, manifest)
        }
        onProgress(ready.size, ready.size, "Done")
        manifest.put("lastUpdateApplied", System.currentTimeMillis())
        saveManifest(context, library, manifest)
        return ok to failed
    }

    /**
     * V99 rule: discovery is filename/title ONLY; decision gate groups edition variants. Lyrics are never used to identify a song.
     * A unique convincing metadata candidate is automatic. Multiple plausible candidates are
     * persisted for a user tap after the scan; no guessing.
     */
    private fun identifyFromFilename(
        context: Context, song: SourceSong, entries: JSONObject, fingerprint: String
    ): Match? {
        val base = metadataOnly(song.name.removeSuffix(".txt"))
        if (base.isBlank()) return null
        val split = base.split(Regex("\\s+-\\s+"), limit = 2)
        val artistHint = if (split.size == 2) metadataOnly(split[0]) else ""
        val titleHint = if (split.size == 2) metadataOnly(split[1]) else base
        if (titleHint.isBlank()) {
            return null
        }

        val queries = buildList {
            add(base)
            if (artistHint.isNotBlank()) add("$titleHint $artistHint")
            if (titleHint != base) add(titleHint)
        }.distinctBy { normalize(it) }

        val providers: List<LookupProvider> = buildList {
            if (matcherBaseUrl(context) != null) add(BackendProvider)
            add(GeniusBetaProvider)
        }
        val found = LinkedHashMap<String, Pair<LookupProvider, Candidate>>()
        providers.forEach { provider ->
            val hitsResult = runCatching { provider.search(context, queries, song.name) }
            hitsResult.exceptionOrNull()?.let {  }
            val hits = hitsResult.getOrDefault(emptyList()).take(12)
            hits.forEach { found.putIfAbsent(it.id, provider to it) }
        }
        if (found.isEmpty()) {
            return null
        }

        val titleN = normalizeBare(titleHint)
        val artistN = normalizeBare(artistHint)
        val plausible = found.values.mapNotNull { pair ->
            val c = pair.second
            val ct = normalizeBare(metadataOnly(c.title))
            val ca = normalizeBare(metadataOnly(c.artist))
            val titleScore = tokenSimilarity(titleN, ct)
            val artistScore = if (artistN.isBlank()) 0.0 else artistHintSimilarity(artistN, ca)
            val titleOk = titleScore >= 0.82 || ct == titleN
            val artistOk = artistN.isBlank() || artistScore >= 0.55
            if (titleOk && artistOk) Triple(pair.first, c, (titleScore * 0.75 + if (artistN.isBlank()) 0.20 else artistScore * 0.25)) else null
        }.sortedByDescending { it.third }

        plausible.take(5).forEachIndexed { i, (_, c, score) ->
        }
        if (plausible.isEmpty()) {
            return null
        }

        // V99 decision gate: live/remaster/acoustic/etc. editions of the SAME artist+song
        // are one identity, not separate songs.  A title-only filename auto-accepts only
        // when all plausible hits collapse to one real artist+song identity; genuinely
        // different artists stay for the end-of-run user choice popup.
        val identityGroups = plausible.groupBy { (_, c, _) ->
            normalizeBare(metadataOnly(c.artist)) + "|" + canonicalSongIdentityTitle(c.title)
        }
        val grouped = identityGroups.values.map { group ->
            group.maxByOrNull { it.third }!!
        }.sortedByDescending { it.third }

        val chosen = when {
            grouped.size == 1 -> grouped.first()
            artistN.isNotBlank() -> {
                // With ARTIST - SONG in the filename, prefer the best matching artist/title
                // identity even if providers returned several editions of that recording.
                val best = grouped.first()
                val second = grouped.getOrNull(1)
                val bestArtist = normalizeBare(metadataOnly(best.second.artist))
                val bestArtistScore = artistHintSimilarity(artistN, bestArtist)
                val clearArtist = bestArtistScore >= 0.72
                val clearLead = second == null || best.third >= second.third + 0.06
                if (clearArtist && (best.third >= 0.82 || clearLead)) best else null
            }
            else -> null
        }

        if (chosen == null) {
            val choices = JSONArray()
            grouped.take(8).forEach { (provider, c, score) ->
                choices.put(JSONObject()
                    .put("id", c.id).put("artist", metadataOnly(c.artist)).put("title", metadataOnly(c.title))
                    .put("provider", provider.name).put("source", c.source).put("url", c.sourceUrl ?: "").put("lyrics", c.lyrics ?: "")
                    .put("score", score))
            }
            putManifestEntry(entries, song, fingerprint, "choice", null, titleHint, null, grouped.first().third, "multiple real artist/song matches")
            entries.optJSONObject(song.relativePath)?.put("choices", choices)
            return null
        }
        val lyrics = runCatching { chosen.first.fetchLyrics(chosen.second) }.getOrNull()
        return Match(chosen.second, lyrics, chosen.third.coerceIn(0.0, 1.0))
    }

    private fun normalizeBare(value: String): String = normalize(value).trim()

    private fun canonicalSongIdentityTitle(value: String): String {
        var title = normalizeBare(metadataOnly(value))
        // Provider result titles sometimes keep edition words outside brackets.
        // They do not make a different song identity for Cleanup matching.
        val editionTail = Regex("(?i)\\b(?:live|remaster(?:ed)?(?:\\s+\\d{4})?|acoustic|radio\\s+edit|single\\s+version|album\\s+version|official\\s+(?:video|audio)|lyrics?|karaoke|instrumental)\\b.*$")
        title = title.replace(editionTail, " ").replace(Regex("\\s+"), " ").trim()
        return title
    }

    private fun artistHintSimilarity(hintRaw: String, candidateRaw: String): Double {
        val hint = normalizeBare(hintRaw)
        val candidate = normalizeBare(candidateRaw)
        if (hint.isBlank() || candidate.isBlank()) return 0.0
        if (hint == candidate) return 1.0
        if (candidate.contains(hint) || hint.contains(candidate)) return 0.86

        val h = hint.split(' ').filter { it.isNotBlank() }
        val c = candidate.split(' ').filter { it.isNotBlank() }
        if (h.isEmpty() || c.isEmpty()) return 0.0

        // Common gig-library shorthand: "A. Lukas" -> "Aca Lukas", "M. Jackson" -> "Michael Jackson".
        if (h.last() == c.last()) {
            if (h.size == 1) return 0.82
            val hp = h.dropLast(1)
            val cp = c.dropLast(1)
            val initialsFit = hp.all { ht ->
                cp.any { ct -> ht == ct || (ht.length == 1 && ct.startsWith(ht)) }
            }
            if (initialsFit) return 0.92
            return maxOf(0.72, tokenSimilarity(hint, candidate))
        }
        return tokenSimilarity(hint, candidate)
    }

    private fun tokenSimilarity(a: String, b: String): Double {
        if (a.isBlank() || b.isBlank()) return 0.0
        if (a == b) return 1.0
        val aa = a.split(' ').filter { it.isNotBlank() }.toSet()
        val bWords = b.split(' ').filter { it.isNotBlank() }.toSet()
        if (aa.isEmpty() || bWords.isEmpty()) return 0.0
        return aa.intersect(bWords).size.toDouble() / aa.union(bWords).size.toDouble()
    }

    fun pendingChoices(context: Context, rootUri: Uri): List<AmbiguousSong> {
        val root = DocumentFile.fromTreeUri(context, rootUri) ?: return emptyList()
        val library = root.findFile(LIBRARY_DIR)?.takeIf { it.isDirectory } ?: return emptyList()
        val entries = loadManifest(context, library).optJSONObject("entries") ?: return emptyList()
        val out = mutableListOf<AmbiguousSong>()
        val keys = entries.keys()
        while (keys.hasNext()) {
            val path = keys.next()
            val e = entries.optJSONObject(path) ?: continue
            if (e.optString("status") != "choice") continue
            val arr = e.optJSONArray("choices") ?: continue
            val choices = (0 until arr.length()).mapNotNull { i ->
                val c = arr.optJSONObject(i) ?: return@mapNotNull null
                val artist = c.optString("artist").trim(); val title = c.optString("title").trim()
                if (artist.isBlank() || title.isBlank()) null else Choice(artist, title, "$path#$i")
            }
            if (choices.isNotEmpty()) out += AmbiguousSong(path, e.optString("sourceName", path), choices)
        }
        return out
    }

    fun resolveChoice(context: Context, rootUri: Uri, token: String): Boolean {
        val cut = token.lastIndexOf('#'); if (cut <= 0) return false
        val path = token.substring(0, cut); val index = token.substring(cut + 1).toIntOrNull() ?: return false
        val root = DocumentFile.fromTreeUri(context, rootUri) ?: return false
        val library = root.findFile(LIBRARY_DIR)?.takeIf { it.isDirectory } ?: return false
        val manifest = loadManifest(context, library); val entries = manifest.optJSONObject("entries") ?: return false
        val e = entries.optJSONObject(path) ?: return false; val c = e.optJSONArray("choices")?.optJSONObject(index) ?: return false
        val candidate = Candidate(c.optString("id"), metadataOnly(c.optString("artist")), metadataOnly(c.optString("title")), c.optString("lyrics").takeIf { it.isNotBlank() }, c.optString("source"), c.optString("url").takeIf { it.startsWith("https://") })
        val provider: LookupProvider = if (c.optString("provider") == BackendProvider.name) BackendProvider else GeniusBetaProvider
        val lyrics = runCatching { provider.fetchLyrics(candidate) }.getOrNull()
        val cleaned = lyrics?.let { cleanLyrics(it) }
        val hasCleanLyrics = cleaned != null && cleaned.lineSequence().count { it.isNotBlank() } >= 6
        val original = findByRelativePath(root, path)
        val originalText = original?.let { readText(context, it.uri) }
        val textForLibrary = if (hasCleanLyrics) cleaned!! else originalText ?: return false
        val outputName = buildOutputName(candidate.artist, candidate.title)
        if (!writeLibraryFile(context, library, outputName, textForLibrary)) return false
        e.put("status", if (hasCleanLyrics) "done" else "identified")
            .put("artist", candidate.artist).put("title", candidate.title)
            .put("outputName", outputName)
            .put("error", if (hasCleanLyrics) JSONObject.NULL else "identity confirmed; provider lyrics unavailable/pending clean")
            .put("resolvedAt", System.currentTimeMillis())
        e.remove("choices"); saveManifest(context, library, manifest); return true
    }


    private fun buildSearchQueries(anchors: List<String>): List<String> {
        val out = mutableListOf<String>()
        anchors.forEach { anchor ->
            val words = anchor
                .replace(Regex("[\\[\\]{}()]"), " ")
                .replace(Regex("\\s+"), " ")
                .trim()
                .split(' ')
                .filter { it.isNotBlank() }
            if (words.size < 4) return@forEach

            // First shot: one compact characteristic phrase, normally 5–9 words.
            val width = words.size.coerceIn(5, 9)
            val start = ((words.size - width) / 2).coerceAtLeast(0)
            out += words.subList(start, start + width).joinToString(" ")

            // Second shot for a long line: a different short window, never a verse block.
            if (words.size >= 10) {
                val secondWidth = words.size.coerceIn(6, 9)
                val secondStart = (words.size - secondWidth).coerceAtLeast(0)
                out += words.subList(secondStart, secondStart + secondWidth).joinToString(" ")
            }
        }
        return out
            .map { it.trim().take(72) }
            .filter { it.split(Regex("\\s+")).size in 4..10 }
            .distinctBy { normalize(it) }
    }

    private fun selectAnchors(text: String): List<String> {
        val all = text.lines()
            .map { it.trim() }
            .filter { line ->
                line.length in 18..110 &&
                    !line.startsWith("[") &&
                    !line.matches(Regex("(?i)^(verse|chorus|refren|strofa|bridge|intro|outro)\\b.*")) &&
                    line.split(Regex("\\s+")).size >= 4 &&
                    line.count { it.isLetter() } >= 12
            }
        if (all.isEmpty()) return emptyList()
        val start = (all.size * 0.22).toInt().coerceAtMost(all.lastIndex)
        val end = (all.size * 0.82).toInt().coerceAtLeast(start + 1).coerceAtMost(all.size)
        val middle = all.subList(start, end)
        return middle
            .withIndex()
            .sortedByDescending { (_, line) -> anchorScore(line) }
            .map { it.value }
            .distinctBy { normalize(it) }
            .take(3)
    }

    private fun anchorScore(line: String): Int {
        val unique = line.lowercase(Locale.ROOT).split(Regex("\\W+")).filter { it.length > 3 }.distinct().size
        val punctuationBonus = if (line.any { it == ',' || it == '?' || it == '!' }) 4 else 0
        return unique * 7 + line.length.coerceAtMost(80) / 4 + punctuationBonus
    }

    private fun geniusSearch(anchor: String): List<Candidate> {
        val q = URLEncoder.encode(anchor, StandardCharsets.UTF_8.name())
        val body = httpGet("https://genius.com/api/search/multi?per_page=5&q=$q") ?: return emptyList()
        val json = runCatching { JSONObject(body) }.getOrNull() ?: return emptyList()
        val sections = json.optJSONObject("response")?.optJSONArray("sections") ?: return emptyList()
        val out = mutableListOf<Candidate>()
        for (i in 0 until sections.length()) {
            val hits = sections.optJSONObject(i)?.optJSONArray("hits") ?: continue
            for (j in 0 until hits.length()) {
                val result = hits.optJSONObject(j)?.optJSONObject("result") ?: continue
                val id = result.optLong("id", -1L)
                val title = result.optString("title").trim()
                val artist = result.optJSONObject("primary_artist")?.optString("name")?.trim().orEmpty()
                val url = result.optString("url").trim()
                if (id > 0 && title.isNotBlank() && artist.isNotBlank() && url.startsWith("https://")) {
                    out += Candidate("genius:$id", artist, title, null, "genius-beta", url)
                }
            }
        }
        return out.distinctBy { it.id }
    }

    private fun fetchGeniusLyrics(url: String): String? {
        val html = httpGet(url) ?: return null
        val re = Regex("<div[^>]*data-lyrics-container=[\\\"']true[\\\"'][^>]*>(.*?)</div>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        val blocks = re.findAll(html).map { it.groupValues[1] }.toList()
        if (blocks.isEmpty()) return null
        val joined = blocks.joinToString("\n\n") { raw ->
            val withBreaks = raw
                .replace(Regex("(?i)<br\\s*/?>"), "\n")
                .replace(Regex("(?i)</p\\s*>"), "\n")
            Html.fromHtml(withBreaks, Html.FROM_HTML_MODE_LEGACY).toString()
        }
        return joined.trim().takeIf { it.length > 80 }
    }

    private fun scoreMatch(
        sourceText: String,
        anchors: List<String>,
        originalName: String,
        candidate: Candidate,
        fetchedLyrics: String
    ): Double {
        val fetchedNorm = normalize(fetchedLyrics)
        var anchorScore = 0.0
        anchors.forEach { anchor ->
            val a = normalize(anchor)
            if (a.length >= 12 && fetchedNorm.contains(a)) {
                anchorScore += 0.36
            } else {
                val words = a.split(' ').filter { it.length > 3 }.toSet()
                val hit = words.count { fetchedNorm.contains(" $it ") || fetchedNorm.startsWith("$it ") || fetchedNorm.endsWith(" $it") }
                if (words.isNotEmpty() && hit.toDouble() / words.size >= 0.82) anchorScore += 0.22
            }
        }
        val sourceWords = normalize(sourceText).split(' ').filter { it.length > 3 }.toSet()
        val fetchedWords = fetchedNorm.split(' ').filter { it.length > 3 }.toSet()
        val overlap = if (sourceWords.isEmpty()) 0.0 else sourceWords.intersect(fetchedWords).size.toDouble() / sourceWords.size
        val nameNorm = normalize(originalName.removeSuffix(".txt"))
        var hint = 0.0
        if (nameNorm.contains(normalize(candidate.title))) hint += 0.06
        val artistTokens = normalize(candidate.artist).split(' ').filter { it.length > 2 }
        if (artistTokens.any { nameNorm.contains(it) }) hint += 0.04
        return (anchorScore + overlap.coerceAtMost(0.20) + hint).coerceAtMost(1.0)
    }

    private fun cleanLyrics(raw: String): String {
        val lines = raw.replace("\r", "").lines()
        val out = mutableListOf<String>()
        for (lineRaw in lines) {
            var line = lineRaw.trim()
            if (line.isBlank()) {
                if (out.isNotEmpty() && out.last().isNotBlank()) out += ""
                continue
            }
            line = line
                .replace(Regex("(?i)^\\d+\\s*Contributors?.*$"), "")
                .replace(Regex("(?i)^Translations?.*$"), "")
                .replace(Regex("(?i)^You might also like$"), "")
                .replace(Regex("(?i)^Embed$"), "")
                .replace(Regex("(?i)\\s*Embed$"), "")
                .trim()
            if (line.isBlank()) continue
            out += line
        }
        while (out.lastOrNull()?.isBlank() == true) out.removeAt(out.lastIndex)
        return out.joinToString("\n")
            .replace(Regex("\n{3,}"), "\n\n")
            .trim() + "\n"
    }

    private fun metadataOnly(value: String): String = stripBracketedMetadata(value)
        // Cleanup V101: avoid Android PatternSyntaxException from brace/bracket regexes.
        // Keep only ARTIST + SONG metadata; bracketed notes are removed by a tiny scanner.
        .replace(Regex("(?i)(?:^|\\s)[A-G](?:#|b)?m?(?:aj|min|dim|aug|sus[24]?)?(?=\\s|$)"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun stripBracketedMetadata(value: String): String {
        val out = StringBuilder(value.length)
        var round = 0
        var square = 0
        var curly = 0
        value.forEach { ch ->
            when (ch) {
                '(' -> round++
                ')' -> if (round > 0) round-- else if (square == 0 && curly == 0) out.append(ch)
                '[' -> square++
                ']' -> if (square > 0) square-- else if (round == 0 && curly == 0) out.append(ch)
                '{' -> curly++
                '}' -> if (curly > 0) curly-- else if (round == 0 && square == 0) out.append(ch)
                else -> if (round == 0 && square == 0 && curly == 0) out.append(ch)
            }
        }
        return out.toString()
    }

    private fun buildOutputName(artist: String, title: String): String {
        val shortArtist = shortenArtist(metadataOnly(artist))
        return "${safeName(shortArtist)} - ${safeName(metadataOnly(title))}.txt"
    }

    private fun shortenArtist(artistRaw: String): String {
        val artist = artistRaw.replace(Regex("\\s+"), " ").trim()
        val words = artist.split(' ').filter { it.isNotBlank() }
        if (words.size <= 1) return artist
        val prefix = words.dropLast(1).joinToString(" ") { word ->
            val c = word.firstOrNull { it.isLetterOrDigit() }
            if (c == null) word else "${c.uppercaseChar()}."
        }
        return "$prefix ${words.last()}"
    }

    private fun safeName(value: String): String = value
        .replace(Regex("[\\\\/:*?\"<>|]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
        .take(120)
        .ifBlank { "Unknown" }

    private fun collectSources(folder: DocumentFile, path: String, out: MutableList<SourceSong>) {
        folder.listFiles().forEach { child ->
            val name = child.name ?: return@forEach
            if (child.isDirectory) {
                if (name == LIBRARY_DIR) return@forEach
                val childPath = if (path.isBlank()) name else "$path/$name"
                collectSources(child, childPath, out)
            } else if (child.isFile && name.lowercase(Locale.ROOT).endsWith(".txt")) {
                val relative = if (path.isBlank()) name else "$path/$name"
                out += SourceSong(child.uri, relative, name)
            }
        }
    }

    private fun findByRelativePath(root: DocumentFile, relativePath: String): DocumentFile? {
        var current: DocumentFile = root
        val parts = relativePath.split('/').filter { it.isNotBlank() }
        if (parts.isEmpty()) return null
        parts.dropLast(1).forEach { part ->
            current = current.findFile(part)?.takeIf { it.isDirectory } ?: return null
        }
        return current.findFile(parts.last())?.takeIf { it.isFile }
    }

    private fun putManifestEntry(
        entries: JSONObject,
        song: SourceSong,
        fingerprint: String,
        status: String,
        artist: String?,
        title: String?,
        outputName: String?,
        confidence: Double,
        error: String?
    ) {
        val obj = JSONObject()
            .put("sourceName", song.name)
            .put("sourcePath", song.relativePath)
            .put("fingerprint", fingerprint)
            .put("status", status)
            .put("confidence", confidence)
            .put("updatedAt", System.currentTimeMillis())
        if (artist != null) obj.put("artist", artist)
        if (title != null) obj.put("title", title)
        if (outputName != null) obj.put("outputName", outputName)
        if (error != null) obj.put("error", error)
        entries.put(song.relativePath, obj)
    }

    private fun countStatus(entries: JSONObject, status: String): Int {
        var count = 0
        val keys = entries.keys()
        while (keys.hasNext()) if (entries.optJSONObject(keys.next())?.optString("status") == status) count++
        return count
    }

    private fun loadManifest(context: Context, library: DocumentFile): JSONObject {
        val file = library.findFile(MANIFEST_NAME) ?: return newManifest()
        val text = readText(context, file.uri) ?: return newManifest()
        return runCatching { JSONObject(text) }.getOrElse { newManifest() }
    }

    private fun newManifest(): JSONObject = JSONObject()
        .put("version", MANIFEST_VERSION)
        .put("completed", false)
        .put("entries", JSONObject())

    private fun saveManifest(context: Context, library: DocumentFile, manifest: JSONObject) {
        val file = library.findFile(MANIFEST_NAME)
            ?: library.createFile("application/json", MANIFEST_NAME)
            ?: return
        writeText(context, file.uri, manifest.toString())
    }

    private fun writeLibraryFile(context: Context, library: DocumentFile, name: String, text: String): Boolean {
        val file = library.findFile(name) ?: library.createFile("text/plain", name) ?: return false
        return writeText(context, file.uri, text)
    }

    private fun readText(context: Context, uri: Uri): String? = runCatching {
        context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
    }.getOrNull()

    private fun writeText(context: Context, uri: Uri, text: String): Boolean = runCatching {
        context.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(text) }
            ?: error("openOutputStream returned null")
        true
    }.getOrDefault(false)

    private fun sha256(text: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun normalize(value: String): String {
        val decomposed = java.text.Normalizer.normalize(value, java.text.Normalizer.Form.NFD)
        return " " + decomposed
            .replace(Regex("\\p{Mn}+"), "")
            .lowercase(Locale.ROOT)
            .replace('đ', 'd')
            .replace(Regex("[^a-z0-9čćžšđ]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim() + " "
    }

    private fun matcherBaseUrl(context: Context): String? {
        val meta: Bundle = runCatching {
            context.packageManager.getApplicationInfo(context.packageName, android.content.pm.PackageManager.GET_META_DATA).metaData
        }.getOrNull() ?: return null
        return meta.getString(MATCHER_META_KEY)?.trim()?.takeIf { it.startsWith("https://") }
    }

    private fun httpPostJson(url: String, json: String): String? {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12_000
            readTimeout = 15_000
            requestMethod = "POST"
            doOutput = true
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", USER_AGENT)
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        return try {
            OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { it.write(json) }
            val code = connection.responseCode
            if (code !in 200..299) return null
            connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (_: Exception) {
            null
        } finally {
            connection.disconnect()
        }
    }

    private fun httpGet(url: String): String? {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12_000
            readTimeout = 12_000
            requestMethod = "GET"
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", USER_AGENT)
            setRequestProperty("Accept", "application/json,text/html,*/*")
            setRequestProperty("Accept-Language", "en-US,en;q=0.8")
        }
        return try {
            val code = connection.responseCode
            if (code !in 200..299) return null
            connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (_: Exception) {
            null
        } finally {
            connection.disconnect()
        }
    }
}
