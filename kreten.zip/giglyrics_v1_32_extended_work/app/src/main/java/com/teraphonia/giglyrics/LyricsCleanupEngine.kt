package com.teraphonia.giglyrics

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.text.Html
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.Locale

/**
 * LYRICS CLEANUP BETA
 *
 * Completely independent of LyrGig's WebView/browser/search path and voice engines.
 * The only shared input is the already-authorized Local Lyrics SAF root.
 * Originals are read-only during CLEANUP. Results + durable checkpoint live in
 * a separate "LyrGig Library" folder. Existing songs change only after an
 * explicit UPDATE EXISTING action.
 */
object LyricsCleanupEngine {
    const val LIBRARY_DIR = "LyrGig Library"
    private const val MANIFEST_NAME = ".lyrgig_cleanup_manifest.json"
    private const val MANIFEST_VERSION = 1
    private const val USER_AGENT = "LyrGig-LyricsCleanup/1.0 (Android)"

    data class Progress(
        val done: Int,
        val total: Int,
        val identified: Int,
        val uncertain: Int,
        val current: String
    )

    data class Summary(
        val total: Int,
        val identified: Int,
        val uncertain: Int,
        val failed: Int,
        val updateReady: Int,
        val completed: Boolean
    )

    private data class SourceSong(
        val uri: Uri,
        val relativePath: String,
        val name: String
    )

    private data class Candidate(
        val id: Long,
        val artist: String,
        val title: String,
        val url: String
    )

    private data class Match(
        val candidate: Candidate,
        val lyrics: String,
        val confidence: Double
    )

    fun cleanup(
        context: Context,
        rootUri: Uri,
        onProgress: (Progress) -> Unit = {}
    ): Summary {
        val root = DocumentFile.fromTreeUri(context, rootUri)
            ?: return Summary(0, 0, 0, 1, 0, false)
        val library = root.findFile(LIBRARY_DIR)?.takeIf { it.isDirectory }
            ?: root.createDirectory(LIBRARY_DIR)
            ?: return Summary(0, 0, 0, 1, 0, false)

        val manifest = loadManifest(context, library)
        manifest.put("completed", false)
        saveManifest(context, library, manifest)
        val entries = manifest.optJSONObject("entries") ?: JSONObject().also { manifest.put("entries", it) }
        val sources = mutableListOf<SourceSong>()
        collectSources(root, "", sources)

        var identified = 0
        var uncertain = 0
        var failed = 0

        sources.forEachIndexed { index, song ->
            onProgress(Progress(index, sources.size, identified, uncertain, song.name))
            val sourceText = readText(context, song.uri)
            if (sourceText.isNullOrBlank()) {
                failed++
                putManifestEntry(entries, song, "", "failed", null, null, null, 0.0, "empty/unreadable")
                saveManifest(context, library, manifest)
                return@forEachIndexed
            }

            val fingerprint = sha256(sourceText)
            val previous = entries.optJSONObject(song.relativePath)
            if (previous != null && previous.optString("fingerprint") == fingerprint && previous.optString("status") == "done") {
                identified++
                return@forEachIndexed
            }

            val match = runCatching { identifyFromLyrics(sourceText, song.name) }.getOrNull()
            if (match == null) {
                uncertain++
                putManifestEntry(entries, song, fingerprint, "uncertain", null, null, null, 0.0, null)
            } else {
                val cleaned = cleanLyrics(match.lyrics)
                if (cleaned.lineSequence().count { it.isNotBlank() } < 6) {
                    uncertain++
                    putManifestEntry(entries, song, fingerprint, "uncertain", null, null, null, match.confidence, "cleaned text too short")
                } else {
                    val outputName = buildOutputName(match.candidate.artist, match.candidate.title)
                    val ok = writeLibraryFile(context, library, outputName, cleaned)
                    if (ok) {
                        identified++
                        putManifestEntry(
                            entries, song, fingerprint, "done", match.candidate.artist,
                            match.candidate.title, outputName, match.confidence, null
                        )
                    } else {
                        failed++
                        putManifestEntry(
                            entries, song, fingerprint, "failed", match.candidate.artist,
                            match.candidate.title, outputName, match.confidence, "library write failed"
                        )
                    }
                }
            }
            saveManifest(context, library, manifest)
        }

        manifest.put("completed", true)
        saveManifest(context, library, manifest)
        val updateReady = countStatus(entries, "done")
        onProgress(Progress(sources.size, sources.size, identified, uncertain, "Done"))
        return Summary(sources.size, identified, uncertain, failed, updateReady, true)
    }

    fun status(context: Context, rootUri: Uri): Summary {
        val root = DocumentFile.fromTreeUri(context, rootUri) ?: return Summary(0, 0, 0, 0, 0, false)
        val library = root.findFile(LIBRARY_DIR)?.takeIf { it.isDirectory } ?: return Summary(0, 0, 0, 0, 0, false)
        val manifest = loadManifest(context, library)
        val entries = manifest.optJSONObject("entries") ?: JSONObject()
        var done = 0
        var uncertain = 0
        var failed = 0
        val keys = entries.keys()
        while (keys.hasNext()) {
            when (entries.optJSONObject(keys.next())?.optString("status")) {
                "done" -> done++
                "uncertain" -> uncertain++
                "failed" -> failed++
            }
        }
        return Summary(done + uncertain + failed, done, uncertain, failed, done, manifest.optBoolean("completed", false))
    }

    fun updateExisting(
        context: Context,
        rootUri: Uri,
        onProgress: (done: Int, total: Int, current: String) -> Unit = { _, _, _ -> }
    ): Pair<Int, Int> {
        val root = DocumentFile.fromTreeUri(context, rootUri) ?: return 0 to 0
        val library = root.findFile(LIBRARY_DIR)?.takeIf { it.isDirectory } ?: return 0 to 0
        val manifest = loadManifest(context, library)
        val entries = manifest.optJSONObject("entries") ?: return 0 to 0
        val ready = mutableListOf<Pair<String, JSONObject>>()
        val keys = entries.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val item = entries.optJSONObject(key) ?: continue
            if (item.optString("status") == "done" && item.optString("outputName").isNotBlank()) ready += key to item
        }

        var ok = 0
        var failed = 0
        ready.forEachIndexed { index, (relativePath, item) ->
            val original = findByRelativePath(root, relativePath)
            val output = library.findFile(item.optString("outputName"))
            onProgress(index, ready.size, original?.name ?: relativePath)
            if (original == null || output == null) {
                failed++
                item.put("updateStatus", "missing")
                saveManifest(context, library, manifest)
                return@forEachIndexed
            }
            val cleaned = readText(context, output.uri)
            if (cleaned.isNullOrBlank() || !writeText(context, original.uri, cleaned)) {
                failed++
                item.put("updateStatus", "write_failed")
                saveManifest(context, library, manifest)
                return@forEachIndexed
            }

            val desired = item.optString("outputName")
            val renamed = if (original.name == desired) original.uri else runCatching {
                DocumentsContract.renameDocument(context.contentResolver, original.uri, desired)
            }.getOrNull()
            if (renamed != null) {
                ok++
                item.put("updateStatus", "updated")
                item.put("updatedName", desired)
            } else {
                // Text is already safely updated; library copy remains the rollback source.
                ok++
                item.put("updateStatus", "updated_text_rename_skipped")
            }
            saveManifest(context, library, manifest)
        }
        onProgress(ready.size, ready.size, "Done")
        manifest.put("lastUpdateApplied", System.currentTimeMillis())
        saveManifest(context, library, manifest)
        return ok to failed
    }

    private fun identifyFromLyrics(sourceText: String, originalName: String): Match? {
        val anchors = selectAnchors(sourceText)
        if (anchors.isEmpty()) return null
        val candidates = LinkedHashMap<Long, Candidate>()
        anchors.take(3).forEach { anchor ->
            geniusSearch(anchor).take(5).forEach { candidates.putIfAbsent(it.id, it) }
        }
        if (candidates.isEmpty()) return null

        var best: Match? = null
        candidates.values.take(10).forEach { candidate ->
            val fetched = fetchGeniusLyrics(candidate.url) ?: return@forEach
            val confidence = scoreMatch(sourceText, anchors, originalName, candidate, fetched)
            if (confidence >= 0.78 && (best == null || confidence > best!!.confidence)) {
                best = Match(candidate, fetched, confidence)
            }
        }
        return best
    }

    private fun selectAnchors(text: String): List<String> {
        val all = text.lines()
            .map { it.trim() }
            .filter { line ->
                line.length in 18..110 &&
                    !line.startsWith("[") &&
                    !line.matches(Regex("(?i)^(verse|chorus|refren|strofa|bridge|intro|outro)\\b.*")) &&
                    line.split(Regex("\\s+")).size >= 4 &&
                    line.count { it.isLetter() } >= 12
            }
        if (all.isEmpty()) return emptyList()
        val start = (all.size * 0.22).toInt().coerceAtMost(all.lastIndex)
        val end = (all.size * 0.82).toInt().coerceAtLeast(start + 1).coerceAtMost(all.size)
        val middle = all.subList(start, end)
        return middle
            .withIndex()
            .sortedByDescending { (_, line) -> anchorScore(line) }
            .map { it.value }
            .distinctBy { normalize(it) }
            .take(3)
    }

    private fun anchorScore(line: String): Int {
        val unique = line.lowercase(Locale.ROOT).split(Regex("\\W+")).filter { it.length > 3 }.distinct().size
        val punctuationBonus = if (line.any { it == ',' || it == '?' || it == '!' }) 4 else 0
        return unique * 7 + line.length.coerceAtMost(80) / 4 + punctuationBonus
    }

    private fun geniusSearch(anchor: String): List<Candidate> {
        val q = URLEncoder.encode(anchor, StandardCharsets.UTF_8.name())
        val body = httpGet("https://genius.com/api/search/multi?per_page=5&q=$q") ?: return emptyList()
        val json = runCatching { JSONObject(body) }.getOrNull() ?: return emptyList()
        val sections = json.optJSONObject("response")?.optJSONArray("sections") ?: return emptyList()
        val out = mutableListOf<Candidate>()
        for (i in 0 until sections.length()) {
            val hits = sections.optJSONObject(i)?.optJSONArray("hits") ?: continue
            for (j in 0 until hits.length()) {
                val result = hits.optJSONObject(j)?.optJSONObject("result") ?: continue
                val id = result.optLong("id", -1L)
                val title = result.optString("title").trim()
                val artist = result.optJSONObject("primary_artist")?.optString("name")?.trim().orEmpty()
                val url = result.optString("url").trim()
                if (id > 0 && title.isNotBlank() && artist.isNotBlank() && url.startsWith("https://")) {
                    out += Candidate(id, artist, title, url)
                }
            }
        }
        return out.distinctBy { it.id }
    }

    private fun fetchGeniusLyrics(url: String): String? {
        val html = httpGet(url) ?: return null
        val re = Regex("<div[^>]*data-lyrics-container=[\\\"']true[\\\"'][^>]*>(.*?)</div>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        val blocks = re.findAll(html).map { it.groupValues[1] }.toList()
        if (blocks.isEmpty()) return null
        val joined = blocks.joinToString("\n\n") { raw ->
            val withBreaks = raw
                .replace(Regex("(?i)<br\\s*/?>"), "\n")
                .replace(Regex("(?i)</p\\s*>"), "\n")
            Html.fromHtml(withBreaks, Html.FROM_HTML_MODE_LEGACY).toString()
        }
        return joined.trim().takeIf { it.length > 80 }
    }

    private fun scoreMatch(
        sourceText: String,
        anchors: List<String>,
        originalName: String,
        candidate: Candidate,
        fetchedLyrics: String
    ): Double {
        val fetchedNorm = normalize(fetchedLyrics)
        var anchorScore = 0.0
        anchors.forEach { anchor ->
            val a = normalize(anchor)
            if (a.length >= 12 && fetchedNorm.contains(a)) {
                anchorScore += 0.36
            } else {
                val words = a.split(' ').filter { it.length > 3 }.toSet()
                val hit = words.count { fetchedNorm.contains(" $it ") || fetchedNorm.startsWith("$it ") || fetchedNorm.endsWith(" $it") }
                if (words.isNotEmpty() && hit.toDouble() / words.size >= 0.82) anchorScore += 0.22
            }
        }
        val sourceWords = normalize(sourceText).split(' ').filter { it.length > 3 }.toSet()
        val fetchedWords = fetchedNorm.split(' ').filter { it.length > 3 }.toSet()
        val overlap = if (sourceWords.isEmpty()) 0.0 else sourceWords.intersect(fetchedWords).size.toDouble() / sourceWords.size
        val nameNorm = normalize(originalName.removeSuffix(".txt"))
        var hint = 0.0
        if (nameNorm.contains(normalize(candidate.title))) hint += 0.06
        val artistTokens = normalize(candidate.artist).split(' ').filter { it.length > 2 }
        if (artistTokens.any { nameNorm.contains(it) }) hint += 0.04
        return (anchorScore + overlap.coerceAtMost(0.20) + hint).coerceAtMost(1.0)
    }

    private fun cleanLyrics(raw: String): String {
        val lines = raw.replace("\r", "").lines()
        val out = mutableListOf<String>()
        for (lineRaw in lines) {
            var line = lineRaw.trim()
            if (line.isBlank()) {
                if (out.isNotEmpty() && out.last().isNotBlank()) out += ""
                continue
            }
            line = line
                .replace(Regex("(?i)^\\d+\\s*Contributors?.*$"), "")
                .replace(Regex("(?i)^Translations?.*$"), "")
                .replace(Regex("(?i)^You might also like$"), "")
                .replace(Regex("(?i)^Embed$"), "")
                .replace(Regex("(?i)\\s*Embed$"), "")
                .trim()
            if (line.isBlank()) continue
            out += line
        }
        while (out.lastOrNull()?.isBlank() == true) out.removeAt(out.lastIndex)
        return out.joinToString("\n")
            .replace(Regex("\n{3,}"), "\n\n")
            .trim() + "\n"
    }

    private fun buildOutputName(artist: String, title: String): String {
        val shortArtist = shortenArtist(artist)
        return "${safeName(shortArtist)} - ${safeName(title)}.txt"
    }

    private fun shortenArtist(artistRaw: String): String {
        val artist = artistRaw.replace(Regex("\\s+"), " ").trim()
        val words = artist.split(' ').filter { it.isNotBlank() }
        if (words.size <= 1) return artist
        val prefix = words.dropLast(1).joinToString(" ") { word ->
            val c = word.firstOrNull { it.isLetterOrDigit() }
            if (c == null) word else "${c.uppercaseChar()}."
        }
        return "$prefix ${words.last()}"
    }

    private fun safeName(value: String): String = value
        .replace(Regex("[\\\\/:*?\"<>|]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
        .take(120)
        .ifBlank { "Unknown" }

    private fun collectSources(folder: DocumentFile, path: String, out: MutableList<SourceSong>) {
        folder.listFiles().forEach { child ->
            val name = child.name ?: return@forEach
            if (child.isDirectory) {
                if (name == LIBRARY_DIR) return@forEach
                val childPath = if (path.isBlank()) name else "$path/$name"
                collectSources(child, childPath, out)
            } else if (child.isFile && name.lowercase(Locale.ROOT).endsWith(".txt")) {
                val relative = if (path.isBlank()) name else "$path/$name"
                out += SourceSong(child.uri, relative, name)
            }
        }
    }

    private fun findByRelativePath(root: DocumentFile, relativePath: String): DocumentFile? {
        var current: DocumentFile = root
        val parts = relativePath.split('/').filter { it.isNotBlank() }
        if (parts.isEmpty()) return null
        parts.dropLast(1).forEach { part ->
            current = current.findFile(part)?.takeIf { it.isDirectory } ?: return null
        }
        return current.findFile(parts.last())?.takeIf { it.isFile }
    }

    private fun putManifestEntry(
        entries: JSONObject,
        song: SourceSong,
        fingerprint: String,
        status: String,
        artist: String?,
        title: String?,
        outputName: String?,
        confidence: Double,
        error: String?
    ) {
        val obj = JSONObject()
            .put("sourceName", song.name)
            .put("sourcePath", song.relativePath)
            .put("fingerprint", fingerprint)
            .put("status", status)
            .put("confidence", confidence)
            .put("updatedAt", System.currentTimeMillis())
        if (artist != null) obj.put("artist", artist)
        if (title != null) obj.put("title", title)
        if (outputName != null) obj.put("outputName", outputName)
        if (error != null) obj.put("error", error)
        entries.put(song.relativePath, obj)
    }

    private fun countStatus(entries: JSONObject, status: String): Int {
        var count = 0
        val keys = entries.keys()
        while (keys.hasNext()) if (entries.optJSONObject(keys.next())?.optString("status") == status) count++
        return count
    }

    private fun loadManifest(context: Context, library: DocumentFile): JSONObject {
        val file = library.findFile(MANIFEST_NAME) ?: return newManifest()
        val text = readText(context, file.uri) ?: return newManifest()
        return runCatching { JSONObject(text) }.getOrElse { newManifest() }
    }

    private fun newManifest(): JSONObject = JSONObject()
        .put("version", MANIFEST_VERSION)
        .put("completed", false)
        .put("entries", JSONObject())

    private fun saveManifest(context: Context, library: DocumentFile, manifest: JSONObject) {
        val file = library.findFile(MANIFEST_NAME)
            ?: library.createFile("application/json", MANIFEST_NAME)
            ?: return
        writeText(context, file.uri, manifest.toString())
    }

    private fun writeLibraryFile(context: Context, library: DocumentFile, name: String, text: String): Boolean {
        val file = library.findFile(name) ?: library.createFile("text/plain", name) ?: return false
        return writeText(context, file.uri, text)
    }

    private fun readText(context: Context, uri: Uri): String? = runCatching {
        context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
    }.getOrNull()

    private fun writeText(context: Context, uri: Uri, text: String): Boolean = runCatching {
        context.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(text) }
            ?: error("openOutputStream returned null")
        true
    }.getOrDefault(false)

    private fun sha256(text: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun normalize(value: String): String {
        val decomposed = java.text.Normalizer.normalize(value, java.text.Normalizer.Form.NFD)
        return " " + decomposed
            .replace(Regex("\\p{Mn}+"), "")
            .lowercase(Locale.ROOT)
            .replace('đ', 'd')
            .replace(Regex("[^a-z0-9čćžšđ]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim() + " "
    }

    private fun httpGet(url: String): String? {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12_000
            readTimeout = 12_000
            requestMethod = "GET"
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", USER_AGENT)
            setRequestProperty("Accept", "application/json,text/html,*/*")
            setRequestProperty("Accept-Language", "en-US,en;q=0.8")
        }
        return try {
            val code = connection.responseCode
            if (code !in 200..299) return null
            connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (_: Exception) {
            null
        } finally {
            connection.disconnect()
        }
    }
}
