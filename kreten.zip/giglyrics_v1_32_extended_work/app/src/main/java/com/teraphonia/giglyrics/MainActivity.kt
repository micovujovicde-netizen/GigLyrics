package com.teraphonia.giglyrics

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.zIndex
import androidx.documentfile.provider.DocumentFile
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FileInputStream
import java.io.BufferedInputStream
import java.io.FilterInputStream
import java.io.InputStream
import java.util.zip.ZipInputStream
import java.util.concurrent.atomic.AtomicBoolean
import java.text.Normalizer
import java.net.URLEncoder
import java.net.URL
import java.net.HttpURLConnection
import java.nio.charset.StandardCharsets
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineOmnilingualAsrCtcModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GigLyricsApp(this) }
    }
}

data class Entry(
    val name: String,
    val uri: Uri,
    val isDirectory: Boolean,
    val pathLabel: String = ""
)

data class NavLocation(
    val folderUri: Uri,
    val fileUri: Uri? = null,
    val fileName: String? = null
)

data class LibraryIndex(
    val songs: List<Entry>,
    val folders: Map<String, List<Entry>>
)

data class ConversionCandidate(
    val file: DocumentFile,
    val parent: DocumentFile
)

private fun stageNormalize(text: String): String = Normalizer.normalize(text.lowercase(Locale.getDefault()), Normalizer.Form.NFD)
    .replace(Regex("\\p{Mn}+"), "")
    .replace(Regex("[^\\p{L}\\p{N}']+"), " ")
    .trim()
    .replace(Regex("\\s+"), " ")

private fun stageEngineText(text: String, language: String): String {
    // FRANKI BETA: one multilingual ear for every visible language.
    // The tracker still compares only CURRENT / NEXT / NEXT+1.
    return stageNormalize(text)
}

private fun detectStageLanguage(text: String): String {
    val raw = text.lowercase(Locale.ROOT)

    // Any native BCS letter is a strong signal.
    if (raw.any { it == 'č' || it == 'ć' || it == 'š' || it == 'ž' || it == 'đ' }) {
        return "🇲🇪 Montenegrin"
    }

    // Decide from the whole lyric, never from a single line.
    val words = stageNormalize(raw).split(' ').filter { it.length > 1 }
    if (words.isEmpty()) return "English"

    // Strong BCS / EX-YU words, including common ASCII-typed lyric forms.
    val bcsHints = setOf(
        "ja","ti","on","ona","ono","mi","vi","oni","one",
        "sam","si","je","smo","ste","su","nisam","nisi","nije","nismo","niste","nisu",
        "ne","da","ali","kad","kada","gdje","gde","kud","kuda","zasto","zašto",
        "sto","što","ko","kao","jer","ako","dok","pa","sad","sada","opet",
        "moja","moje","moj","moju","tvoja","tvoje","tvoj","njena","njen","njega","njoj",
        "ljubav","srce","noc","dan","zivot","voli","volim","volis","volio","voleo",
        "pjesma","pesma","samo","bez","tebe","mene","meni","tebi","nama","vama","nas","vas",
        "bio","bila","bilo","bili","biti","imam","imas","ima","imamo","imate","imaju",
        "rekao","rekla","kazem","kažem","kaze","kaže","druze","druže","brate","brat",
        "dva","tri","jedan","jedna","zena","žena","devojka","djevojka","cura",
        "sedeo","sjedio","sedim","sjedim","stolom","zajedno","nikad","uvek","uvijek",
        "nisam","necu","neću","hoću","hocu","hoću","zelim","želim","mogao","mogu"
    )
    val englishHints = setOf(
        "the","and","you","your","yours","i","me","my","mine","we","us","our",
        "love","baby","heart","girl","boy","is","are","was","were","be","been",
        "to","of","in","on","for","with","without","from","at","by",
        "dont","do","does","did","not","never","always","when","where","why","how",
        "this","that","these","those","what","who","can","could","will","would",
        "say","said","tell","come","go","know","want","need","feel","night","day"
    )

    val bcsScore = words.count { it in bcsHints }
    val enScore = words.count { it in englishHints }

    // A whole song only needs a few independent BCS hits to enter the EX-YU lane.
    // English remains the safe default for ambiguous/international text.
    return if (bcsScore >= 3 && bcsScore > enScore) "🇲🇪 Montenegrin" else "English"
}

private fun stageIgnoreLine(raw: String): Boolean {
    val t = raw.trim().replace(Regex("\\s+"), " ")
    if (t.isBlank()) return true
    if (t.matches(Regex("^[\\-_=*~.·•:;|/\\\\()\\[\\]{}<>]+$"))) return true
    val bare = t
        .trim('(', ')', '[', ']', '{', '}', '<', '>', '-', '_', '*', '.', ':', ';')
        .trim()
        .lowercase(Locale.ROOT)
        .replace(Regex("\\s+"), " ")
    if (bare.isBlank()) return true
    if (bare.matches(Regex("^(x\\s*)?[2-9]\\s*x?$"))) return true
    val structural = Regex(
        "^(ref\\.?|refren|refrain|chorus|coro|rit\\.?|ritornello|estribillo|estribilho|refrão|refrao|" +
        "verse|verso|strofa|estrofa|strophe|couplet|bridge|puente|ponte|intro|outro|solo|instrumental|" +
        "interlude|interludio|pre[ -]?chorus|post[ -]?chorus|hook|coda)(\\s*[:.-]?\\s*(x?\\s*[2-9]|[2-9]\\s*x))?$",
        RegexOption.IGNORE_CASE
    )
    return structural.matches(bare)
}

private fun stageTokenClose(aRaw: String, bRaw: String): Boolean {
    val a = stageNormalize(aRaw)
    val b = stageNormalize(bRaw)
    if (a == b) return true
    if (a.length < 3 || b.length < 3) return false
    if (a.startsWith(b) || b.startsWith(a)) return minOf(a.length, b.length) >= 4

    // Tiny Levenshtein distance for Polish-ear cognates:
    // nasim/naszym, tako/tak, druze/druże, etc.
    val prev = IntArray(b.length + 1) { it }
    val cur = IntArray(b.length + 1)
    for (i in 1..a.length) {
        cur[0] = i
        for (j in 1..b.length) {
            val cost = if (a[i - 1] == b[j - 1]) 0 else 1
            cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
        }
        for (j in prev.indices) prev[j] = cur[j]
    }
    val dist = prev[b.length]
    val limit = when {
        maxOf(a.length, b.length) <= 4 -> 1
        maxOf(a.length, b.length) <= 7 -> 2
        else -> 3
    }
    return dist <= limit
}

private fun stageLineMatchScore(heard: String, expected: String): Double {
    val h = stageNormalize(heard)
    val e = stageNormalize(expected)
    if (h.length < 3 || e.length < 3) return 0.0
    if (h == e) return 1.0
    if (h.contains(e) || e.contains(h)) {
        val short = minOf(h.length, e.length)
        val long = maxOf(h.length, e.length)
        if (short >= 7) return 0.82 + 0.18 * short.toDouble() / long
    }

    val hw = h.split(' ').filter { it.length > 1 }
    val ew = e.split(' ').filter { it.length > 1 }
    if (hw.isEmpty() || ew.isEmpty()) return 0.0

    val used = BooleanArray(hw.size)
    var common = 0
    for (want in ew) {
        val j = hw.indices.firstOrNull { !used[it] && stageTokenClose(hw[it], want) }
        if (j != null) {
            used[j] = true
            common++
        }
    }
    if (common == 0) return 0.0
    val precision = common.toDouble() / hw.size
    val recall = common.toDouble() / ew.size
    val overlap = common.toDouble() / minOf(hw.size, ew.size)
    return 0.45 * overlap + 0.35 * recall + 0.20 * precision
}

private const val FRANKI_ARCHIVE_URL = "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-omnilingual-asr-1600-languages-300M-ctc-v2-int8-2026-02-05.tar.bz2"
private const val FRANKI_RELEASE_PAGE_URL = "https://github.com/k2-fsa/sherpa-onnx/releases/tag/asr-models"
private const val FRANKI_MODEL_DIR = "franki/omnilingual-v2-int8"
private const val FRANKI_DOWNLOAD_LABEL = "~292 MB"

private fun findInstalledFranki(context: Context): File? {
    val dir = File(context.filesDir, FRANKI_MODEL_DIR)
    val model = File(dir, "model.int8.onnx")
    val tokens = File(dir, "tokens.txt")
    return dir.takeIf {
        model.isFile && model.length() > 0L &&
        tokens.isFile && tokens.length() > 0L
    }
}

private fun clearIncompleteFranki(context: Context) {
    val dir = File(context.filesDir, FRANKI_MODEL_DIR)
    if (dir.exists() && findInstalledFranki(context) == null) {
        dir.deleteRecursively()
    }
    File(context.cacheDir, "franki-747.tar.bz2").delete()
    File(context.cacheDir, "franki-747-unpacked").deleteRecursively()
    File(context.cacheDir, "franki-import").deleteRecursively()
}

private fun createFrankiRecognizer(modelDir: File): OfflineRecognizer {
    val config = OfflineRecognizerConfig(
        modelConfig = OfflineModelConfig(
            omnilingual = OfflineOmnilingualAsrCtcModelConfig(
                model = File(modelDir, "model.int8.onnx").absolutePath,
            ),
            tokens = File(modelDir, "tokens.txt").absolutePath,
            numThreads = 2,
            provider = "cpu",
        ),
        decodingMethod = "greedy_search",
    )
    return OfflineRecognizer(config = config)
}

private fun downloadFrankiFile(url: String, out: File, onBytes: (Long, Long) -> Unit) {
    out.parentFile?.mkdirs()
    val connection = (URL(url).openConnection() as HttpURLConnection).apply {
        connectTimeout = 20_000
        readTimeout = 120_000
        instanceFollowRedirects = true
        requestMethod = "GET"
        setRequestProperty("User-Agent", "GigLyrics/1.60 Android")
    }
    try {
        connection.connect()
        if (connection.responseCode !in 200..299) error("Download HTTP ${connection.responseCode}")
        val total = connection.contentLengthLong
        var done = 0L
        BufferedInputStream(connection.inputStream).use { input ->
            FileOutputStream(out).use { output ->
                val buffer = ByteArray(1024 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count == -1) break
                    if (count == 0) continue
                    output.write(buffer, 0, count)
                    done += count
                    onBytes(done, total)
                }
                output.fd.sync()
            }
        }
        // A dropped GitHub connection can still leave a large-looking archive.
        // Never feed a truncated .tar.bz2 to the installer.
        if (total > 0L && done != total) {
            out.delete()
            error("747 download incomplete: $done / $total bytes")
        }
    } finally {
        connection.disconnect()
    }
}

private class FrankiProgressInputStream(
    input: InputStream,
    private val totalBytes: Long,
    private val onPercent: (Int) -> Unit,
) : FilterInputStream(input) {
    private var bytesRead = 0L
    private var lastPercent = -1

    private fun report(delta: Int) {
        if (delta <= 0) return
        bytesRead += delta
        if (totalBytes <= 0L) return
        val percent = ((bytesRead * 100L) / totalBytes).toInt().coerceIn(0, 100)
        if (percent != lastPercent) {
            lastPercent = percent
            onPercent(percent)
        }
    }

    override fun read(): Int {
        val value = super.read()
        if (value >= 0) report(1)
        return value
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        val count = super.read(buffer, offset, length)
        report(count)
        return count
    }
}

private fun extractFrankiArchive(archive: File, outDir: File, onProgress: (Int) -> Unit) {
    outDir.deleteRecursively()
    if (!outDir.mkdirs()) error("Could not prepare FRANKI install folder")

    var foundModel = false
    var foundTokens = false
    FileInputStream(archive).use { raw ->
        FrankiProgressInputStream(raw, archive.length()) { compressedPct ->
            // Extraction occupies 5..90% of the installer bar.  This tracks
            // compressed bytes consumed, so the UI keeps moving while BZip2
            // is doing CPU-heavy work instead of appearing frozen at 5%.
            onProgress(5 + ((compressedPct * 85) / 100))
        }.use { progressRaw ->
            BufferedInputStream(progressRaw, 1024 * 1024).use { buffered ->
                BZip2CompressorInputStream(buffered, true).use { bz ->
                    TarArchiveInputStream(bz).use { tar ->
                        var entry = tar.nextTarEntry
                        while (entry != null) {
                            if (!entry.isDirectory) {
                                val name = entry.name.substringAfterLast('/')
                                val target = when (name) {
                                    "model.int8.onnx" -> File(outDir, "model.int8.onnx")
                                    "tokens.txt" -> File(outDir, "tokens.txt")
                                    else -> null
                                }
                                if (target != null) {
                                    val expectedBytes = entry.size
                                    var writtenBytes = 0L
                                    FileOutputStream(target).use { output ->
                                        val buffer = ByteArray(1024 * 1024)
                                        while (true) {
                                            val n = tar.read(buffer)
                                            if (n == -1) break
                                            if (n == 0) continue
                                            output.write(buffer, 0, n)
                                            writtenBytes += n
                                        }
                                        output.fd.sync()
                                    }
                                    // Validate against TAR metadata, not an arbitrary model-size guess.
                                    if (expectedBytes > 0L && writtenBytes != expectedBytes) {
                                        error("FRANKI $name unpack incomplete: $writtenBytes / $expectedBytes bytes")
                                    }
                                    if (name == "model.int8.onnx") foundModel = true
                                    if (name == "tokens.txt") foundTokens = true
                                }
                            }
                            entry = tar.nextTarEntry
                        }
                    }
                }
            }
        }
    }
    if (!foundModel) error("model.int8.onnx not found inside 747 archive")
    if (!foundTokens) error("tokens.txt not found inside 747 archive")
}

private fun downloadAndInstallFranki(
    context: Context,
    onProgress: (Int) -> Unit,
    onInstalling: (Int) -> Unit,
): File {
    findInstalledFranki(context)?.let { return it }

    val finalDir = File(context.filesDir, FRANKI_MODEL_DIR)
    val archive = File(context.cacheDir, "franki-747.tar.bz2")
    val unpacked = File(context.cacheDir, "franki-747-unpacked")
    archive.delete()
    unpacked.deleteRecursively()

    try {
        var last = -1
        downloadFrankiFile(FRANKI_ARCHIVE_URL, archive) { done, total ->
            if (total > 0L) {
                val pct = ((done * 100L) / total).toInt().coerceIn(0, 100)
                if (pct != last) {
                    last = pct
                    onProgress(pct)
                }
            }
        }
        if (archive.length() < 200_000_000L) error("747 download looks incomplete")
        onProgress(100)
        onInstalling(5)

        extractFrankiArchive(archive, unpacked) { pct ->
            onInstalling(pct)
        }

        val model = File(unpacked, "model.int8.onnx")
        val tokens = File(unpacked, "tokens.txt")
        if (!model.isFile || model.length() <= 0L) error("FRANKI model file is missing")
        if (!tokens.isFile || tokens.length() <= 0L) error("FRANKI tokens file is missing")

        finalDir.deleteRecursively()
        finalDir.parentFile?.mkdirs()
        if (!unpacked.renameTo(finalDir)) {
            if (!finalDir.mkdirs()) error("Could not create FRANKI model folder")
            model.copyTo(File(finalDir, "model.int8.onnx"), overwrite = true)
            tokens.copyTo(File(finalDir, "tokens.txt"), overwrite = true)
        }
        onInstalling(100)
        return findInstalledFranki(context) ?: error("FRANKI install verification failed")
    } finally {
        archive.delete()
        if (unpacked.exists() && unpacked.absolutePath != finalDir.absolutePath) unpacked.deleteRecursively()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GigLyricsApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("giglyrics", Context.MODE_PRIVATE) }

    var rootUri by remember {
        mutableStateOf(prefs.getString("root_uri", null)?.let(Uri::parse))
    }
    var currentUri by remember {
        mutableStateOf(prefs.getString("last_folder_uri", null)?.let(Uri::parse))
    }
    var currentTitle by remember { mutableStateOf("GigLyrics") }
    var entries by remember { mutableStateOf(emptyList<Entry>()) }

    var openedText by remember { mutableStateOf<String?>(null) }
    var openedTitle by remember { mutableStateOf("") }
    var openedFileUri by remember { mutableStateOf<Uri?>(null) }

    // NEXT LINE: deliberately simple, linear stage tracker.
    var stageMicOn by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }
    var stageLineIndex by remember { mutableIntStateOf(-1) }
    var stageRestartToken by remember { mutableIntStateOf(0) }

    // FRANKI BETA: one optional Omnilingual v2 INT8 ear for every language.
    // It is NOT bundled in the APK; user explicitly downloads it only if LIVE SYNC is wanted.
    var frankiRecognizer by remember { mutableStateOf<OfflineRecognizer?>(null) }
    var frankiLoading by remember { mutableStateOf(false) }
    var frankiProgress by remember { mutableIntStateOf(0) }
    var frankiInstalling by remember { mutableStateOf(false) }
    var frankiError by remember { mutableStateOf<String?>(null) }
    var showFrankiDownloadPrompt by remember {
        mutableStateOf(!prefs.getBoolean("voice_sync_offer_seen", false) && findInstalledFranki(context) == null)
    }
    var showFrankiBrowser by remember { mutableStateOf(false) }
    var stageWarmupDone by remember { mutableStateOf(false) }

    var showSetup by remember { mutableStateOf(false) }
    var stageLanguage by remember { mutableStateOf(prefs.getString("stage_language", "English") ?: "English") }

    var fontSize by remember {
        mutableFloatStateOf(prefs.getFloat("font_size", 28f))
    }
    var listFontSize by remember {
        mutableFloatStateOf(prefs.getFloat("list_font_size", 23f))
    }

    var searchQuery by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf(emptyList<Entry>()) }
    var searching by remember { mutableStateOf(false) }

    var webSearchQuery by remember { mutableStateOf("") }
    var webSearchUrl by remember { mutableStateOf<String?>(null) }
    var showWebSearch by remember { mutableStateOf(false) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var extractedLyrics by remember { mutableStateOf<String?>(null) }
    var extractedTitle by remember { mutableStateOf("") }
    var autoExtractActive by remember { mutableStateOf(false) }
    var autoExtractTriedText by remember { mutableStateOf(false) }
    var autoCandidateOpened by remember { mutableStateOf(false) }
    var candidateChoices by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var candidateChoiceQuery by remember { mutableStateOf("") }
    var downloadedLyricsUri by remember { mutableStateOf<Uri?>(null) }
    var songIndex by remember { mutableStateOf(emptyList<Entry>()) }
    var folderCache by remember { mutableStateOf<Map<String, List<Entry>>>(emptyMap()) }
    var indexReady by remember { mutableStateOf(false) }
    var indexGeneration by remember { mutableIntStateOf(0) }

    // First-run / new-file conversion prompt. This stays off the stage UI and only
    // appears when there are newly added supported documents without a .txt twin.
    var showConvertPrompt by remember { mutableStateOf(false) }
    var convertPromptFirstRun by remember { mutableStateOf(false) }
    var pendingConvertibleFiles by remember { mutableStateOf<List<ConversionCandidate>>(emptyList()) }
    var convertingFiles by remember { mutableStateOf(false) }
    var conversionStatus by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()

    val backHistory = remember { mutableStateListOf<NavLocation>() }
    val forwardHistory = remember { mutableStateListOf<NavLocation>() }

    fun listFolder(uri: Uri) {
        val cached = folderCache[uri.toString()]
        if (cached != null) {
            entries = cached
            currentUri = uri
            openedText = null
            openedTitle = ""
            openedFileUri = null
            currentTitle = if (uri == rootUri) "GigLyrics" else (
                DocumentFile.fromTreeUri(context, uri)?.name ?: "Folder"
            )
            prefs.edit().putString("last_folder_uri", uri.toString()).apply()
            return
        }

        // Fallback only while the background cache is still being built.
        val folder = DocumentFile.fromTreeUri(context, uri)
        if (folder == null || !folder.isDirectory) return
        currentTitle = folder.name ?: "Folder"
        entries = folder.listFiles()
            .filter { it.isDirectory || (it.isFile && it.name?.lowercase()?.endsWith(".txt") == true) }
            .mapNotNull { f ->
                val n = f.name ?: return@mapNotNull null
                Entry(n, f.uri, f.isDirectory)
            }
            .sortedWith(compareBy<Entry> { !it.isDirectory }.thenBy { it.name.lowercase() })
        currentUri = uri
        openedText = null
        openedTitle = ""
        openedFileUri = null
        prefs.edit().putString("last_folder_uri", uri.toString()).apply()
    }

    fun readText(uri: Uri): String {
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                BufferedReader(InputStreamReader(input)).readText()
            } ?: ""
        } catch (e: Exception) {
            "Ne mogu da otvorim fajl.\n\n${e.message ?: ""}"
        }
    }

    fun currentLocation(): NavLocation? {
        val folder = currentUri ?: return null
        return if (openedText != null && openedFileUri != null) {
            NavLocation(folder, openedFileUri, openedTitle)
        } else {
            NavLocation(folder)
        }
    }

    fun applyLocation(location: NavLocation) {
        searchQuery = ""
        searching = false
        searchResults = emptyList()

        if (currentUri != location.folderUri || entries.isEmpty()) {
            listFolder(location.folderUri)
        } else {
            openedText = null
            openedTitle = ""
            openedFileUri = null
        }

        if (location.fileUri != null) {
            openedFileUri = location.fileUri
            openedTitle = location.fileName ?: "Tekst"
            openedText = readText(location.fileUri)
        }
    }

    fun navigateTo(location: NavLocation) {
        currentLocation()?.let { backHistory.add(it) }
        forwardHistory.clear()
        applyLocation(location)
    }

    fun goBack() {
        if (showWebSearch) {
            showWebSearch = false
            extractedLyrics = null
            webSearchUrl = null
            autoExtractActive = false
            autoExtractTriedText = false
            autoCandidateOpened = false
            candidateChoices = emptyList()
            candidateChoiceQuery = ""
            return
        }
        if (searching) {
            searchQuery = ""
            searching = false
            searchResults = emptyList()
            return
        }
        if (backHistory.isNotEmpty()) {
            currentLocation()?.let { forwardHistory.add(it) }
            val previous = backHistory.removeAt(backHistory.lastIndex)
            applyLocation(previous)
        }
    }

    fun goForward() {
        if (forwardHistory.isNotEmpty()) {
            currentLocation()?.let { backHistory.add(it) }
            val next = forwardHistory.removeAt(forwardHistory.lastIndex)
            applyLocation(next)
        }
    }

    fun goHome() {
        val root = rootUri ?: return
        if (currentUri == root && openedText == null && !searching && !showWebSearch) return
        showWebSearch = false
        extractedLyrics = null
        webSearchUrl = null
        autoExtractActive = false
        autoExtractTriedText = false
        autoCandidateOpened = false
        currentLocation()?.let { backHistory.add(it) }
        forwardHistory.clear()
        searchQuery = ""
        searching = false
        searchResults = emptyList()
        listFolder(root)
    }

    fun normalizeSearchText(value: String): String {
        val decomposed = Normalizer.normalize(value, Normalizer.Form.NFD)
        return decomposed
            .replace("\\p{Mn}+".toRegex(), "")
            .lowercase()
            .replace(".txt", "")
            .replace("[-_]+".toRegex(), " ")
            .replace("\\s+".toRegex(), " ")
            .trim()
    }

    suspend fun buildLibraryIndex(rootUriValue: Uri): LibraryIndex = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(context, rootUriValue)
            ?: return@withContext LibraryIndex(emptyList(), emptyMap())

        val songs = mutableListOf<Entry>()
        val folders = mutableMapOf<String, List<Entry>>()

        fun walk(folder: DocumentFile, path: String) {
            val rawChildren = folder.listFiles()
                .filter { it.isDirectory || (it.isFile && it.name?.lowercase()?.endsWith(".txt") == true) }

            val children = rawChildren
                .mapNotNull { f ->
                    val name = f.name ?: return@mapNotNull null
                    Entry(name, f.uri, f.isDirectory, path)
                }
                .sortedWith(compareBy<Entry> { !it.isDirectory }.thenBy { it.name.lowercase() })

            folders[folder.uri.toString()] = children

            for (child in rawChildren) {
                val name = child.name ?: continue
                if (child.isDirectory) {
                    val childPath = if (path.isBlank()) name else "$path / $name"
                    walk(child, childPath)
                } else if (child.isFile && name.lowercase().endsWith(".txt")) {
                    songs += Entry(name, child.uri, false, path)
                }
            }
        }

        walk(root, "")
        LibraryIndex(
            songs = songs.sortedBy { it.name.lowercase() },
            folders = folders
        )
    }

    fun refreshSongIndex(uri: Uri) {
        val generation = indexGeneration + 1
        indexGeneration = generation
        indexReady = false
        scope.launch {
            val built = buildLibraryIndex(uri)
            if (indexGeneration == generation) {
                songIndex = built.songs
                folderCache = built.folders
                indexReady = true

                // If the user is still on a folder that was opened before caching finished,
                // replace its slow SAF listing with the cached version immediately.
                currentUri?.let { current ->
                    built.folders[current.toString()]?.let { cached ->
                        if (openedText == null) entries = cached
                    }
                }

                if (searchQuery.isNotBlank()) {
                    val q = normalizeSearchText(searchQuery)
                    searchResults = built.songs.filter { normalizeSearchText(it.name).contains(q) }
                }
            }
        }
    }

    fun doSearch(query: String) {
        searchQuery = query
        searching = query.isNotBlank()
        if (!searching) {
            searchResults = emptyList()
            return
        }

        val q = normalizeSearchText(query)
        searchResults = if (indexReady) {
            songIndex.filter { normalizeSearchText(it.name).contains(q) }
        } else {
            emptyList()
        }
    }

    val convertibleExtensions = setOf("pdf", "docx", "rtf", "md", "markdown", "html", "htm", "lyr", "lrc", "srt", "vtt", "odt", "chordpro", "cho", "pro")

    fun baseName(name: String): String = name.substringBeforeLast('.', name).trim()

    fun supportedForConversion(file: DocumentFile): Boolean {
        if (!file.isFile) return false
        val name = file.name ?: return false
        val ext = name.substringAfterLast('.', "").lowercase()
        return ext in convertibleExtensions
    }

    fun scanConvertibleFiles(root: Uri): List<ConversionCandidate> {
        val rootFolder = DocumentFile.fromTreeUri(context, root) ?: return emptyList()
        val pending = mutableListOf<ConversionCandidate>()

        fun walk(folder: DocumentFile) {
            val children = try { folder.listFiles().toList() } catch (_: Exception) { emptyList() }
            val txtBases = children
                .filter { it.isFile && it.name?.lowercase()?.endsWith(".txt") == true }
                .mapNotNull { it.name?.let(::baseName)?.lowercase() }
                .toSet()

            for (child in children) {
                if (child.isDirectory) {
                    walk(child)
                } else if (supportedForConversion(child)) {
                    val name = child.name ?: continue
                    if (baseName(name).lowercase() !in txtBases) pending += ConversionCandidate(child, folder)
                }
            }
        }

        walk(rootFolder)
        return pending.sortedBy { it.file.name?.lowercase() ?: "" }
    }

    fun pendingFingerprint(files: List<ConversionCandidate>): String = files
        .map { it.file.uri.toString() }
        .sorted()
        .joinToString("|")
        .hashCode()
        .toString()

    fun stripHtml(raw: String): String = raw
        .replace(Regex("(?is)<script.*?</script>"), " ")
        .replace(Regex("(?is)<style.*?</style>"), " ")
        .replace(Regex("(?i)<br\\s*/?>"), "\n")
        .replace(Regex("(?i)</p\\s*>"), "\n\n")
        .replace(Regex("<[^>]+>"), " ")
        .replace("&nbsp;", " ")
        .replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
        .replace(Regex("[ \\t]+\\n"), "\n")
        .replace(Regex("\\n{3,}"), "\n\n")
        .trim()

    fun stripRtf(raw: String): String {
        var t = raw
            .replace(Regex("\\\\par[d]?\\b ?"), "\n")
            .replace(Regex("\\\\line\\b ?"), "\n")
            .replace(Regex("\\\\tab\\b ?"), "\t")
            .replace(Regex("\\\\'[0-9a-fA-F]{2}")) { m ->
                try { byteArrayOf(m.value.substring(2).toInt(16).toByte()).toString(Charsets.ISO_8859_1) }
                catch (_: Exception) { "" }
            }
        t = t.replace(Regex("\\\\[a-zA-Z]+-?\\d* ?"), "")
            .replace("{", "")
            .replace("}", "")
            .replace(Regex("\\n{3,}"), "\n\n")
        return t.trim()
    }

    fun stripTimedText(raw: String): String {
        return raw
            .replace("\uFEFF", "")
            // LRC timestamps, including multiple timestamps at the start of one line.
            .replace(Regex("(?m)^(?:\\[\\d{1,3}:\\d{2}(?:[.:]\\d{1,3})?\\]\\s*)+"), "")
            // Common LRC metadata tags are not lyrics.
            .replace(Regex("(?im)^\\[(?:ar|ti|al|by|offset|re|ve|length):.*?\\]\\s*$"), "")
            // SRT/VTT cue numbers and timing lines.
            .replace(Regex("(?m)^\\s*\\d+\\s*$"), "")
            .replace(Regex("(?m)^\\s*(?:\\d{1,2}:)?\\d{2}:\\d{2}[.,]\\d{3}\\s*-->\\s*(?:\\d{1,2}:)?\\d{2}:\\d{2}[.,]\\d{3}.*$"), "")
            .replace(Regex("(?im)^WEBVTT.*$"), "")
            .replace(Regex("(?im)^NOTE(?:\\s.*)?$"), "")
            .replace(Regex("<[^>]+>"), "")
            .replace(Regex("[ \\t]+\\n"), "\n")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()
    }

    fun stripChordPro(raw: String): String {
        return raw
            // Remove ChordPro control/directive lines while preserving lyric and chord lines.
            .replace(Regex("(?m)^\\s*\\{[^}]+}\\s*$"), "")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()
    }

    fun extractOdtText(uri: Uri): String {
        context.contentResolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (entry.name == "content.xml") {
                        val out = ByteArrayOutputStream()
                        val buf = ByteArray(8192)
                        while (true) {
                            val n = zip.read(buf)
                            if (n <= 0) break
                            out.write(buf, 0, n)
                        }
                        val xml = out.toString(Charsets.UTF_8.name())
                        return xml
                            .replace(Regex("(?i)</text:p>"), "\n")
                            .replace(Regex("(?i)</text:h>"), "\n")
                            .replace(Regex("(?i)<text:line-break[^>]*/>"), "\n")
                            .replace(Regex("(?i)<text:tab[^>]*/>"), "\t")
                            .replace(Regex("<[^>]+>"), "")
                            .replace("&amp;", "&")
                            .replace("&lt;", "<")
                            .replace("&gt;", ">")
                            .replace("&quot;", "\"")
                            .replace("&apos;", "'")
                            .replace(Regex("\\n{3,}"), "\n\n")
                            .trim()
                    }
                    entry = zip.nextEntry
                }
            }
        }
        return ""
    }

    fun extractDocxText(uri: Uri): String {
        context.contentResolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (entry.name == "word/document.xml") {
                        val out = ByteArrayOutputStream()
                        val buf = ByteArray(8192)
                        while (true) {
                            val n = zip.read(buf)
                            if (n <= 0) break
                            out.write(buf, 0, n)
                        }
                        val xml = out.toString(Charsets.UTF_8.name())
                        return xml
                            .replace(Regex("(?i)</w:p>"), "\n")
                            .replace(Regex("(?i)<w:tab[^>]*/>"), "\t")
                            .replace(Regex("<[^>]+>"), "")
                            .replace("&amp;", "&")
                            .replace("&lt;", "<")
                            .replace("&gt;", ">")
                            .replace("&quot;", "\"")
                            .replace("&apos;", "'")
                            .replace(Regex("\\n{3,}"), "\n\n")
                            .trim()
                    }
                    entry = zip.nextEntry
                }
            }
        }
        return ""
    }

    fun extractSupportedFile(file: DocumentFile): String {
        val name = file.name ?: return ""
        val ext = name.substringAfterLast('.', "").lowercase()
        return try {
            when (ext) {
                "pdf" -> {
                    context.contentResolver.openInputStream(file.uri)?.use { input ->
                        PDDocument.load(input).use { doc -> PDFTextStripper().getText(doc).trim() }
                    }.orEmpty()
                }
                "docx" -> extractDocxText(file.uri)
                "odt" -> extractOdtText(file.uri)
                "rtf" -> context.contentResolver.openInputStream(file.uri)?.bufferedReader()?.use { stripRtf(it.readText()) }.orEmpty()
                "html", "htm" -> context.contentResolver.openInputStream(file.uri)?.bufferedReader()?.use { stripHtml(it.readText()) }.orEmpty()
                "md", "markdown", "lyr" -> context.contentResolver.openInputStream(file.uri)?.bufferedReader()?.use { it.readText().trim() }.orEmpty()
                "lrc", "srt", "vtt" -> context.contentResolver.openInputStream(file.uri)?.bufferedReader()?.use { stripTimedText(it.readText()) }.orEmpty()
                "chordpro", "cho", "pro" -> context.contentResolver.openInputStream(file.uri)?.bufferedReader()?.use { stripChordPro(it.readText()) }.orEmpty()
                else -> ""
            }
        } catch (_: Exception) {
            ""
        }
    }

    suspend fun convertFiles(files: List<ConversionCandidate>): Pair<Int, Int> = withContext(Dispatchers.IO) {
        var converted = 0
        var failed = 0
        files.forEach { candidate ->
            val source = candidate.file
            try {
                val text = extractSupportedFile(source).trim()
                val parent = candidate.parent
                if (text.isBlank() || !parent.canWrite()) {
                    failed++
                } else {
                    val targetName = baseName(source.name ?: "Lyrics") + ".txt"
                    val existing = parent.listFiles().firstOrNull { it.isFile && it.name.equals(targetName, true) }
                    val target = existing ?: parent.createFile("text/plain", targetName)
                    if (target == null) {
                        failed++
                    } else {
                        context.contentResolver.openOutputStream(target.uri, "wt")?.use { out ->
                            out.write(text.toByteArray(Charsets.UTF_8))
                        } ?: throw IllegalStateException("Could not write")
                        converted++
                    }
                }
            } catch (_: Exception) {
                failed++
            }
        }
        converted to failed
    }

    fun checkForConvertibleFiles(root: Uri, firstRun: Boolean = false) {
        scope.launch {
            val pending = withContext(Dispatchers.IO) { scanConvertibleFiles(root) }
            pendingConvertibleFiles = pending
            if (pending.isEmpty()) {
                prefs.edit().putString("convert_pending_fingerprint", "").apply()
                return@launch
            }
            val fingerprint = pendingFingerprint(pending)
            val dismissed = prefs.getString("convert_pending_fingerprint", "")
            if (firstRun || fingerprint != dismissed) {
                convertPromptFirstRun = firstRun
                showConvertPrompt = true
            }
        }
    }

    fun ensureDownloadedLyricsFolder(root: Uri): Uri? {
        return try {
            val rootFolder = DocumentFile.fromTreeUri(context, root) ?: return null
            val existing = rootFolder.listFiles().firstOrNull {
                it.isDirectory && it.name.equals("Downloaded Lyrics", ignoreCase = true)
            }
            val folder = existing ?: rootFolder.createDirectory("Downloaded Lyrics")
            folder?.uri.also { downloadedLyricsUri = it }
        } catch (_: Exception) {
            null
        }
    }

    fun webSearchUrlFor(query: String, suffix: String): String {
        val encoded = URLEncoder.encode("${query.trim()} $suffix -site:youtube.com -site:youtu.be -site:music.youtube.com", StandardCharsets.UTF_8.toString())
        return "https://www.google.com/search?q=$encoded"
    }

    fun launchWebSearch(query: String) {
        val clean = query.trim()
        if (clean.isBlank()) return
        webSearchQuery = clean
        extractedLyrics = null
        extractedTitle = clean

        // Step 1: automatic extraction. Search stays invisible while GigLyrics tries
        // the first useful text result. If that fails, the same WebView becomes
        // Step 2: the visible in-app web fallback.
        autoExtractActive = true
        autoExtractTriedText = false
        autoCandidateOpened = false
        candidateChoices = emptyList()
        candidateChoiceQuery = clean
        webSearchUrl = webSearchUrlFor(clean, "lyrics")
        showWebSearch = true
    }

    fun lyricsExtractionJs(): String = """

            (function() {
              function clean(t) {
                return (t || '')
                  .replace(/\\r/g, '')
                  .replace(/[ \\t]+\\n/g, '\\n')
                  .replace(/\\n[ \\t]+/g, '\\n')
                  .replace(/\\n{3,}/g, '\\n\\n')
                  .trim();
              }
              const specific = [
                '[data-lyrics-container="true"]',
                '.lyrics', '#lyrics', '.lyric', '#lyric',
                '[class*="lyrics"]', '[id*="lyrics"]'
              ];
              for (const sel of specific) {
                const nodes = Array.from(document.querySelectorAll(sel));
                if (nodes.length) {
                  const t = clean(nodes.map(n => n.innerText).join('\\n'));
                  if (t.length > 120) return t;
                }
              }

              const clone = document.body.cloneNode(true);
              clone.querySelectorAll('script,style,noscript,nav,header,footer,form,button,svg,canvas,iframe,aside').forEach(n => n.remove());
              const candidates = Array.from(clone.querySelectorAll('main,article,section,div,pre'));
              let best = '';
              let bestScore = -1e9;
              for (const el of candidates) {
                const t = clean(el.innerText);
                if (t.length < 120 || t.length > 18000) continue;
                const lines = t.split('\\n').map(x => x.trim()).filter(Boolean);
                if (lines.length < 4) continue;
                const shortLines = lines.filter(x => x.length >= 2 && x.length <= 90).length;
                const veryLong = lines.filter(x => x.length > 180).length;
                const noise = (t.match(/cookie|privacy|sign in|subscribe|advertis|menu|share|facebook|instagram/gi) || []).length;
                const score = shortLines * 5 + lines.length * 2 - veryLong * 8 - noise * 15 + Math.min(t.length, 4000) / 200;
                if (score > bestScore) { bestScore = score; best = t; }
              }
              return best || clean(clone.innerText);
            })();
        """.trimIndent()

    fun applyExtractedResult(web: WebView, result: String?, automatic: Boolean) {
        try {
            val value = if (result == null || result == "null") "" else
                org.json.JSONTokener(result).nextValue() as? String ?: ""

            val cleanedLines = value
                .lines()
                .map { it.trim() }
                .filter { it.isNotBlank() }

            val menuNoise = cleanedLines.count {
                val l = it.lowercase()
                l == "svi tekstovi" ||
                l.startsWith("poslušaj na") ||
                l.startsWith("listen on") ||
                l == "home" ||
                l == "menu" ||
                l == "lyrics" ||
                l == "tekst"
            }

            val usefulLines = cleanedLines.count { it.length in 8..140 }
            val looksLikeLyrics =
                value.length >= 180 &&
                cleanedLines.size >= 6 &&
                usefulLines >= 5 &&
                menuNoise <= 1

            if (!looksLikeLyrics) {
                if (automatic) {
                    // Auto mode failed: leave the current page open as the web fallback.
                    autoExtractActive = false
                    autoCandidateOpened = false
                    Toast.makeText(context, "Auto extract failed — web fallback", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Lyrics not found on this page", Toast.LENGTH_SHORT).show()
                }
            } else {
                extractedLyrics = value
                val pageTitle = web.title.orEmpty()
                    .replace(" - Google Search", "", ignoreCase = true)
                    .trim()
                extractedTitle = if (pageTitle.isNotBlank()) pageTitle else webSearchQuery
                autoExtractActive = false
                autoCandidateOpened = false
            }
        } catch (_: Exception) {
            if (automatic) {
                autoExtractActive = false
                autoCandidateOpened = false
                Toast.makeText(context, "Auto extract failed — web fallback", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Could not extract lyrics", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun extractLyricsFromWeb() {
        val web = webViewRef ?: return
        web.evaluateJavascript(lyricsExtractionJs()) { result ->
            applyExtractedResult(web, result, automatic = false)
        }
    }

    fun saveExtractedLyrics() {
        val text = extractedLyrics?.trim().orEmpty()
        val root = rootUri ?: return
        if (text.isBlank()) return
        val folderUri = downloadedLyricsUri ?: ensureDownloadedLyricsFolder(root)
        val folder = folderUri?.let { DocumentFile.fromTreeUri(context, it) }
        if (folder == null) {
            Toast.makeText(context, "Could not create Downloaded Lyrics", Toast.LENGTH_SHORT).show()
            return
        }
        val base = (if (webSearchQuery.isNotBlank()) webSearchQuery else extractedTitle)
            .replace(Regex("[\\\\/:*?\"<>|]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .ifBlank { "Lyrics" }
        val filename = "$base.txt"
        try {
            val existing = folder.listFiles().firstOrNull { it.isFile && it.name.equals(filename, true) }
            val file = existing ?: folder.createFile("text/plain", filename)
            if (file == null) throw IllegalStateException("File could not be created")
            context.contentResolver.openOutputStream(file.uri, "wt")?.use { out ->
                out.write(text.toByteArray(Charsets.UTF_8))
            } ?: throw IllegalStateException("File could not be written")
            Toast.makeText(context, "Saved to Downloaded Lyrics", Toast.LENGTH_SHORT).show()
            refreshSongIndex(root)
        } catch (e: Exception) {
            Toast.makeText(context, "Save failed: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
        }
    }

    suspend fun installFrankiFromFolder(uri: Uri) {
        if (frankiLoading) return
        frankiLoading = true
        frankiProgress = 0
        frankiInstalling = true
        frankiError = null
        try {
            val modelDir = withContext(Dispatchers.IO) {
                val root = DocumentFile.fromTreeUri(context, uri)
                    ?: error("Could not open selected folder")

                fun findNamed(dir: DocumentFile, name: String, depth: Int = 0): DocumentFile? {
                    if (depth > 3) return null
                    dir.listFiles().firstOrNull { it.isFile && it.name.equals(name, ignoreCase = true) }?.let { return it }
                    for (child in dir.listFiles()) {
                        if (child.isDirectory) findNamed(child, name, depth + 1)?.let { return it }
                    }
                    return null
                }

                val modelDoc = findNamed(root, "model.int8.onnx")
                    ?: error("model.int8.onnx not found in selected folder")
                val tokensDoc = findNamed(root, "tokens.txt")
                    ?: error("tokens.txt not found in selected folder")

                val finalDir = File(context.filesDir, FRANKI_MODEL_DIR)
                val tempDir = File(context.cacheDir, "franki-import")
                tempDir.deleteRecursively()
                if (!tempDir.mkdirs()) error("Could not prepare FRANKI import folder")
                val tempModel = File(tempDir, "model.int8.onnx")
                val tempTokens = File(tempDir, "tokens.txt")

                fun copyDoc(doc: DocumentFile, out: File, startPct: Int, endPct: Int) {
                    val total = doc.length().coerceAtLeast(1L)
                    var done = 0L
                    context.contentResolver.openInputStream(doc.uri)?.use { input ->
                        FileOutputStream(out).use { output ->
                            val buf = ByteArray(1024 * 1024)
                            while (true) {
                                val n = input.read(buf)
                                if (n <= 0) break
                                output.write(buf, 0, n)
                                done += n
                                val pct = startPct + ((done * (endPct - startPct)) / total).toInt()
                                frankiProgress = pct.coerceIn(startPct, endPct)
                            }
                        }
                    } ?: error("Could not read ${doc.name}")
                }

                copyDoc(modelDoc, tempModel, 0, 95)
                copyDoc(tokensDoc, tempTokens, 95, 98)
                if (tempModel.length() < 100_000_000L) error("FRANKI model file looks incomplete")
                if (tempTokens.length() < 1_000L) error("FRANKI tokens file looks incomplete")

                finalDir.deleteRecursively()
                if (!finalDir.parentFile.exists()) finalDir.parentFile.mkdirs()
                if (!tempDir.renameTo(finalDir)) {
                    if (!finalDir.mkdirs()) error("Could not create FRANKI model folder")
                    tempModel.copyTo(File(finalDir, "model.int8.onnx"), overwrite = true)
                    tempTokens.copyTo(File(finalDir, "tokens.txt"), overwrite = true)
                    tempDir.deleteRecursively()
                }
                frankiProgress = 99
                if (findInstalledFranki(context) == null) error("FRANKI install verification failed")
                finalDir
            }
            frankiRecognizer = withContext(Dispatchers.IO) { createFrankiRecognizer(modelDir) }
            frankiProgress = 100
            prefs.edit().putBoolean("voice_sync_offer_seen", true).apply()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            frankiError = e.message ?: "FRANKI model import failed"
        } finally {
            frankiInstalling = false
            frankiLoading = false
        }
    }

    fun startFranki747Install() {
        if (frankiLoading || frankiRecognizer != null) return
        clearIncompleteFranki(context)
        prefs.edit().putBoolean("voice_sync_offer_seen", true).apply()
        frankiLoading = true
        frankiInstalling = false
        frankiProgress = 0
        frankiError = null
        scope.launch {
            try {
                val modelDir = withContext(Dispatchers.IO) {
                    downloadAndInstallFranki(
                        context = context,
                        onProgress = { pct -> scope.launch {
                            frankiInstalling = false
                            frankiProgress = pct
                        } },
                        onInstalling = { pct -> scope.launch {
                            frankiInstalling = true
                            frankiProgress = pct
                        } },
                    )
                }
                frankiRecognizer = withContext(Dispatchers.IO) { createFrankiRecognizer(modelDir) }
                frankiInstalling = false
                frankiProgress = 100
                frankiError = null
                showFrankiBrowser = false
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                frankiError = e.message ?: "747 install failed"
                frankiInstalling = false
            } finally {
                frankiLoading = false
            }
        }
    }

    fun openFrankiDownload() {
        prefs.edit().putBoolean("voice_sync_offer_seen", true).apply()
        frankiError = null
        showFrankiBrowser = true
    }

    LaunchedEffect(Unit) {
        stageWarmupDone = false
        try {
            // Never auto-download. Only warm a model the user has already chosen to install.
            val existing = findInstalledFranki(context)
            if (existing != null) {
                try {
                    frankiRecognizer = withContext(Dispatchers.IO) { createFrankiRecognizer(existing) }
                    frankiProgress = 100
                } catch (e: Exception) {
                    frankiError = e.message ?: "FRANKI listener could not be loaded"
                }
            }
        } finally {
            stageWarmupDone = true
        }
    }

    val stageLines = remember(openedText) { (openedText ?: "").lines() }
    fun nextStageLine(fromExclusive: Int): Int {
        var i = (fromExclusive + 1).coerceAtLeast(0)
        while (i < stageLines.size) {
            if (!stageIgnoreLine(stageLines[i])) return i
            i++
        }
        return -1
    }

    LaunchedEffect(openedText) {
        // Keep the user's MIC state across songs. New song only resets the lyric cursor.
        stageLineIndex = nextStageLine(-1)
        openedText?.let { text ->
            val detected = detectStageLanguage(text)
            stageLanguage = detected
            prefs.edit().putString("stage_language", detected).apply()
            if (stageMicOn) stageRestartToken++
        }
    }

    val stagePermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            stageMicOn = true
            stageRestartToken++
        } else {
            Toast.makeText(context, "Microphone permission is required", Toast.LENGTH_SHORT).show()
        }
    }

    val currentStageLineIndex by rememberUpdatedState(stageLineIndex)
    DisposableEffect(stageMicOn, openedText, frankiRecognizer, stageRestartToken) {
        val recognizer = frankiRecognizer
        if (!stageMicOn || openedText == null || stageLineIndex !in stageLines.indices || recognizer == null) {
            onDispose { }
        } else {
            val running = AtomicBoolean(true)
            val sampleRate = 16000
            val windowSamples = sampleRate * 5
            val shared = FloatArray(windowSamples)
            val sharedCount = intArrayOf(0)
            val lock = Any()

            fun consumeHeard(heardRaw: String) {
                val heard = stageNormalize(heardRaw)
                if (heard.isBlank()) return
                val current = currentStageLineIndex
                if (current !in stageLines.indices) return

                val candidates = mutableListOf(current)
                var probe = current
                repeat(2) {
                    probe = nextStageLine(probe)
                    if (probe >= 0) candidates.add(probe)
                }
                val scored = candidates.mapNotNull { idx ->
                    val expected = stageLines.getOrNull(idx) ?: return@mapNotNull null
                    idx to stageLineMatchScore(heard, stageEngineText(expected, stageLanguage))
                }
                val best = scored.maxByOrNull { it.second } ?: return
                val runnerUp = scored.filter { it.first != best.first }.maxOfOrNull { it.second } ?: 0.0
                // Beta is intentionally slightly more tolerant than Cecil because the universal model
                // is decoded from overlapping rolling windows instead of Vosk grammar partials.
                if (best.second < 0.48 || best.second - runnerUp < 0.05) return
                val n = nextStageLine(best.first)
                if (n >= 0 && n > current) {
                    (context as? ComponentActivity)?.runOnUiThread { stageLineIndex = n }
                }
            }

            val minBytes = AudioRecord.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(sampleRate / 2)
            var audioRecord: AudioRecord? = null

            val recordThread = Thread({
                try {
                    audioRecord = AudioRecord(
                        MediaRecorder.AudioSource.VOICE_RECOGNITION,
                        sampleRate,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        minBytes * 2
                    )
                    val ar = audioRecord ?: return@Thread
                    val buf = ShortArray(1600) // 100 ms
                    ar.startRecording()
                    while (running.get()) {
                        val n = ar.read(buf, 0, buf.size)
                        if (n <= 0) continue
                        synchronized(lock) {
                            if (sharedCount[0] + n > shared.size) {
                                val drop = sharedCount[0] + n - shared.size
                                System.arraycopy(shared, drop, shared, 0, sharedCount[0] - drop)
                                sharedCount[0] -= drop
                            }
                            for (i in 0 until n) shared[sharedCount[0] + i] = buf[i] / 32768.0f
                            sharedCount[0] += n
                        }
                    }
                } catch (e: Exception) {
                    (context as? ComponentActivity)?.runOnUiThread {
                        Toast.makeText(context, "FRANKI mic: ${e.message ?: "listener error"}", Toast.LENGTH_LONG).show()
                    }
                } finally {
                    runCatching { audioRecord?.stop() }
                    runCatching { audioRecord?.release() }
                    audioRecord = null
                }
            }, "FrankiAudio")

            val decodeThread = Thread({
                try {
                    while (running.get()) {
                        Thread.sleep(650)
                        val snapshot = synchronized(lock) {
                            val count = sharedCount[0]
                            if (count < sampleRate / 2) null else shared.copyOfRange(0, count)
                        } ?: continue
                        val stream = recognizer.createStream()
                        try {
                            stream.acceptWaveform(samples = snapshot, sampleRate = sampleRate)
                            recognizer.decode(stream)
                            consumeHeard(recognizer.getResult(stream).text)
                        } finally {
                            runCatching { stream.release() }
                        }
                    }
                } catch (_: InterruptedException) {
                } catch (e: Exception) {
                    (context as? ComponentActivity)?.runOnUiThread {
                        Toast.makeText(context, "FRANKI decode: ${e.message ?: "recognizer error"}", Toast.LENGTH_LONG).show()
                    }
                }
            }, "FrankiDecode")

            recordThread.start()
            decodeThread.start()

            onDispose {
                running.set(false)
                recordThread.interrupt()
                decodeThread.interrupt()
                runCatching { audioRecord?.stop() }
            }
        }
    }

    val folderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) {}

            rootUri = uri
            backHistory.clear()
            forwardHistory.clear()
            searchQuery = ""
            searching = false
            searchResults = emptyList()

            prefs.edit()
                .putString("root_uri", uri.toString())
                .putString("last_folder_uri", uri.toString())
                .apply()

            ensureDownloadedLyricsFolder(uri)
            listFolder(uri)
            refreshSongIndex(uri)
            checkForConvertibleFiles(uri, firstRun = true)
        }
    }

    val voiceSearchLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
        if (!spoken.isNullOrBlank()) doSearch(spoken)
    }

    val webVoiceSearchLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
        if (!spoken.isNullOrBlank()) launchWebSearch(spoken)
    }

    fun launchVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Kaži ime pjesme")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        }
        voiceSearchLauncher.launch(intent)
    }

    fun launchWebVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Say song name")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        }
        webVoiceSearchLauncher.launch(intent)
    }

    fun configureWebViewForDarkStage(webView: WebView) {
        val webSettings = webView.settings
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(webSettings, true)
        } else if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            WebSettingsCompat.setForceDark(webSettings, WebSettingsCompat.FORCE_DARK_ON)
        }
        webView.setBackgroundColor(android.graphics.Color.BLACK)
    }

    fun openDonate() {
        context.startActivity(
            Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://wise.com/pay/me/milanv607?utm_source=request_flow")
            )
        )
    }

    LaunchedEffect(Unit) {
        PDFBoxResourceLoader.init(context)

        // v1.32: one-time tiny reduction so existing users also get the slightly
        // calmer listing size without losing their personal +/- adjustment history.
        if (!prefs.getBoolean("v132_list_font_adjusted", false)) {
            listFontSize = (listFontSize - 1f).coerceAtLeast(16f)
            prefs.edit()
                .putFloat("list_font_size", listFontSize)
                .putBoolean("v132_list_font_adjusted", true)
                .apply()
        }

        val savedRoot = rootUri

        if (savedRoot == null) {
            // First launch: the app must ask for its root folder before showing the browser.
            folderPicker.launch(null)
        } else {
            val rootFolder = DocumentFile.fromTreeUri(context, savedRoot)

            if (rootFolder == null || !rootFolder.isDirectory || !rootFolder.canRead()) {
                // The old folder was removed or Android revoked access. Ask again.
                prefs.edit()
                    .remove("root_uri")
                    .remove("last_folder_uri")
                    .apply()
                rootUri = null
                currentUri = null
                folderPicker.launch(null)
            } else {
                // Every fresh app launch starts at HOME/root. Never reopen the last song/folder.
                backHistory.clear()
                forwardHistory.clear()
                searchQuery = ""
                searching = false
                searchResults = emptyList()
                listFolder(savedRoot)
                refreshSongIndex(savedRoot)
                checkForConvertibleFiles(savedRoot, firstRun = false)

                if (rootFolder.canWrite()) {
                    ensureDownloadedLyricsFolder(savedRoot)
                } else {
                    // Older GigLyrics versions persisted read-only access. Web saving needs
                    // one re-selection of the same root so Android can persist write access too.
                    folderPicker.launch(savedRoot)
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color.Black,
            surface = Color.Black,
            onBackground = Color.White,
            onSurface = Color.White,
            primary = Color.White,
            onPrimary = Color.Black
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color.Black
        ) {
            val isRoot = rootUri != null && currentUri == rootUri && openedText == null && !showWebSearch

            LaunchedEffect(isRoot) {
                if (isRoot) rootUri?.let { checkForConvertibleFiles(it, firstRun = false) }
            }

            BackHandler(enabled = showWebSearch || searching || backHistory.isNotEmpty()) { goBack() }

            Box(Modifier.fillMaxSize()) {
                if (showFrankiBrowser) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .zIndex(50f)
                            .background(Color(0xCC000000)),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 28.dp),
                            color = Color(0xFF111111),
                            shape = RoundedCornerShape(24.dp),
                            tonalElevation = 10.dp
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        "FRANKI 747",
                                        color = Color(0xFFFFC107),
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(Modifier.weight(1f))
                                    TextButton(
                                        onClick = { if (!frankiLoading) showFrankiBrowser = false },
                                        enabled = !frankiLoading
                                    ) {
                                        Text("✕", color = Color.White, fontSize = 22.sp)
                                    }
                                }

                                Spacer(Modifier.height(18.dp))

                                Button(
                                    onClick = { startFranki747Install() },
                                    enabled = !frankiLoading && frankiRecognizer == null,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(76.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFFFFC107)
                                    )
                                ) {
                                    Text(
                                        when {
                                            frankiRecognizer != null -> "✓ 747 READY • OFFLINE"
                                            frankiLoading && frankiInstalling -> "UNPACKING 747  ${frankiProgress}%"
                                            frankiLoading -> "DOWNLOADING 747  ${frankiProgress}%"
                                            else -> "DOWNLOAD 747"
                                        },
                                        color = Color.Black,
                                        fontSize = 22.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                if (frankiError != null) {
                                    Spacer(Modifier.height(12.dp))
                                    Text(
                                        frankiError ?: "",
                                        color = Color(0xFFFF6B6B),
                                        fontSize = 15.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }

                if (showFrankiDownloadPrompt) {
                    AlertDialog(
                        onDismissRequest = {
                            prefs.edit().putBoolean("voice_sync_offer_seen", true).apply()
                            showFrankiDownloadPrompt = false
                        },
                        title = { Text("AUTOMATIC VOICE LYRICS SYNC", color = Color.White, fontSize = 23.sp) },
                        text = {
                            Text(
                                "Do you want to install Automatic Voice Lyrics Sync? The optional offline voice model is about $FRANKI_DOWNLOAD_LABEL. GigLyrics works normally without it.",
                                color = Color(0xFFD0D0D0),
                                fontSize = 17.sp
                            )
                        },
                        confirmButton = {
                            TextButton(onClick = {
                                showFrankiDownloadPrompt = false
                                openFrankiDownload()
                                showSetup = true
                            }) { Text("INSTALL", color = Color(0xFFFFC107), fontSize = 18.sp) }
                        },
                        dismissButton = {
                            TextButton(onClick = {
                                prefs.edit().putBoolean("voice_sync_offer_seen", true).apply()
                                showFrankiDownloadPrompt = false
                            }) { Text("NOT NOW", color = Color.White, fontSize = 18.sp) }
                        },
                        containerColor = Color(0xFF111111)
                    )
                }

                if (showSetup) {
                    val frankiInstalled = frankiRecognizer != null
                    AlertDialog(
                        onDismissRequest = { showSetup = false },
                        title = { Text("⚙  Setup", color = Color.White, fontSize = 24.sp) },
                        text = {
                            Column {
                                Text("AUTOMATIC VOICE LYRICS SYNC", color = Color(0xFFFFC107), fontSize = 18.sp)
                                Spacer(Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable(enabled = !frankiLoading) {
                                            if (!frankiInstalled) openFrankiDownload()
                                        }
                                        .padding(vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        if (frankiInstalled) "●" else "○",
                                        color = if (frankiInstalled) Color(0xFFFFC107) else Color(0xFF777777),
                                        fontSize = 18.sp
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text("Universal • English + EX-YU + 1600+ languages", color = Color.White, fontSize = 17.sp)
                                        Text(
                                            when {
                                                frankiInstalled -> "$FRANKI_DOWNLOAD_LABEL • INSTALLED • OFFLINE"
                                                frankiLoading && frankiInstalling -> "⟳  INSTALLING ${frankiProgress}%"
                                                frankiLoading -> "WORKING ${frankiProgress}%"
                                                frankiError != null -> "NOT INSTALLED • ${frankiError}"
                                                else -> "NOT INSTALLED • OPTIONAL"
                                            },
                                            color = if (frankiInstalled) Color(0xFFBDBDBD) else Color(0xFF888888),
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                                if (!frankiInstalled) {
                                    Button(
                                        onClick = { openFrankiDownload() },
                                        enabled = !frankiLoading,
                                        modifier = Modifier.fillMaxWidth().height(58.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFC107))
                                    ) {
                                        Text(
                                            "DOWNLOAD 747",
                                            color = Color.Black,
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                } else {
                                    Text("READY • OFFLINE", color = Color(0xFFBDBDBD), fontSize = 13.sp)
                                }
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = { showSetup = false }) { Text("DONE", color = Color.White) }
                        },
                        containerColor = Color(0xFF111111)
                    )
                }

                if (showConvertPrompt) {
                    AlertDialog(
                        onDismissRequest = {
                            prefs.edit().putString(
                                "convert_pending_fingerprint",
                                pendingFingerprint(pendingConvertibleFiles)
                            ).apply()
                            showConvertPrompt = false
                        },
                        title = {
                            Text(
                                if (convertPromptFirstRun) "Prepare your lyrics?" else "New files found",
                                color = Color.White
                            )
                        },
                        text = {
                            Column {
                                Text(
                                    if (convertPromptFirstRun)
                                        "Convert supported files to GigLyrics text?"
                                    else
                                        "Convert new supported files to GigLyrics text?",
                                    color = Color.White,
                                    fontSize = 19.sp
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    "PDF, DOCX, RTF, Markdown and HTML. Original files stay unchanged.",
                                    color = Color(0xFFBDBDBD),
                                    fontSize = 14.sp
                                )
                                if (convertingFiles) {
                                    Spacer(Modifier.height(12.dp))
                                    LinearProgressIndicator(Modifier.fillMaxWidth())
                                    if (conversionStatus.isNotBlank()) {
                                        Spacer(Modifier.height(6.dp))
                                        Text(conversionStatus, color = Color(0xFFBDBDBD), fontSize = 13.sp)
                                    }
                                }
                            }
                        },
                        confirmButton = {
                            TextButton(
                                enabled = !convertingFiles,
                                onClick = {
                                    val filesNow = pendingConvertibleFiles
                                    convertingFiles = true
                                    conversionStatus = "Converting ${filesNow.size} file(s)…"
                                    scope.launch {
                                        val (ok, failed) = convertFiles(filesNow)
                                        convertingFiles = false
                                        showConvertPrompt = false
                                        conversionStatus = ""
                                        prefs.edit().putString("convert_pending_fingerprint", "").apply()
                                        rootUri?.let { root ->
                                            listFolder(root)
                                            refreshSongIndex(root)
                                        }
                                        val msg = if (failed == 0) {
                                            "Converted $ok file(s)"
                                        } else {
                                            "Converted $ok • skipped $failed"
                                        }
                                        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                    }
                                }
                            ) { Text("Convert", color = Color.White) }
                        },
                        dismissButton = {
                            TextButton(
                                enabled = !convertingFiles,
                                onClick = {
                                    prefs.edit().putString(
                                        "convert_pending_fingerprint",
                                        pendingFingerprint(pendingConvertibleFiles)
                                    ).apply()
                                    showConvertPrompt = false
                                }
                            ) { Text("Not now", color = Color(0xFFBDBDBD)) }
                        },
                        containerColor = Color(0xFF111111)
                    )
                }

                // ONE bitmap wallpaper for the entire HOME screen.
                // No section owns a separate copy: the same bitmap sits under banner space,
                // Local/Web search, folders and the bottom stage controls.
                if (isRoot) {
                    Image(
                        painter = painterResource(id = R.drawable.giglyrics_piano_banner),
                        contentDescription = null,
                        contentScale = ContentScale.FillBounds,
                        alignment = Alignment.Center,
                        modifier = Modifier
                            .matchParentSize()
                            .alpha(0.16f)
                    )
                }

                if (openedText == null && !showWebSearch && rootUri != null) {
                    TextButton(
                        onClick = { showSetup = true },
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 4.dp, end = 6.dp)
                            .size(52.dp)
                            .zIndex(5f),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("⚙", color = Color.White.copy(alpha = 0.88f), fontSize = 28.sp)
                    }
                }

                Column(Modifier.fillMaxSize()) {
                if (rootUri == null) {
                    // If the user cancels the Android picker, keep the app here instead of
                    // pretending there is already a root folder.
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        OutlinedButton(onClick = { folderPicker.launch(null) }) {
                            Text("IZABERI GLAVNI FOLDER", color = Color.White)
                        }
                    }
                } else if (showWebSearch) {
                    if (extractedLyrics != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { extractedLyrics = null }) {
                                Text("Web", color = Color.White, fontSize = 18.sp)
                            }
                            Text(
                                text = extractedTitle.ifBlank { webSearchQuery },
                                color = Color.White,
                                fontSize = 36.sp,
                                maxLines = 1,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(
                                onClick = { saveExtractedLyrics() },
                                modifier = Modifier.height(58.dp)
                            ) {
                                Text(
                                    "Save",
                                    color = Color(0xFF4CAF50),
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                        Text(
                            text = extractedLyrics ?: "",
                            color = Color.White,
                            fontSize = fontSize.sp,
                            lineHeight = (fontSize * 1.35f).sp,
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                                .padding(horizontal = 18.dp, vertical = 8.dp)
                        )
                    } else {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(68.dp)
                                .padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "🌍  ${webSearchQuery.ifBlank { "Web lyrics" }}",
                                color = Color.White,
                                fontSize = 18.sp,
                                maxLines = 1,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(
                                onClick = { extractLyricsFromWeb() },
                                modifier = Modifier.height(58.dp)
                            ) {
                                Text(
                                    "Extract lyrics",
                                    color = Color(0xFF4CAF50),
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                        if (candidateChoices.isNotEmpty()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 18.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = "Choose the right song",
                                    color = Color.White,
                                    fontSize = 20.sp
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    text = candidateChoiceQuery,
                                    color = Color.Gray,
                                    fontSize = 14.sp
                                )
                                Spacer(Modifier.height(8.dp))

                                candidateChoices.forEach { (title, urlValue) ->
                                    Text(
                                        text = title,
                                        color = Color.White,
                                        fontSize = 17.sp,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                candidateChoices = emptyList()
                                                autoExtractActive = true
                                                autoCandidateOpened = true
                                                webSearchUrl = urlValue
                                                webViewRef?.loadUrl(urlValue)
                                            }
                                            .padding(vertical = 10.dp)
                                    )
                                }

                                Divider(color = Color.DarkGray)
                                Text(
                                    text = "Show web results",
                                    color = Color.Gray,
                                    fontSize = 15.sp,
                                    modifier = Modifier
                                        .clickable {
                                            candidateChoices = emptyList()
                                            autoExtractActive = false
                                        }
                                        .padding(vertical = 10.dp)
                                )
                            }
                        }

                        if (autoExtractActive) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    CircularProgressIndicator(color = Color.White)
                                    Spacer(Modifier.height(14.dp))
                                    Text("Finding lyrics…", color = Color.White, fontSize = 18.sp)
                                }
                            }
                        }

                        AndroidView(
                            factory = { ctx ->
                                WebView(ctx).apply {
                                    settings.javaScriptEnabled = true
                                    settings.domStorageEnabled = true
                                    settings.loadsImagesAutomatically = true
                                    configureWebViewForDarkStage(this)
                                    webViewClient = object : WebViewClient() {
                                        override fun onPageFinished(view: WebView, url: String?) {
                                            super.onPageFinished(view, url)

                                            // Keep the embedded browser stage-dark even when a page does not
                                            // advertise its own dark theme. Algorithmic darkening above does
                                            // most of the work; this removes white flashes/backgrounds.
                                            view.evaluateJavascript(
                                                """
                                                (function() {
                                                  try {
                                                    document.documentElement.style.colorScheme = 'dark';
                                                    document.documentElement.style.backgroundColor = '#000000';
                                                    if (document.body) document.body.style.backgroundColor = '#000000';
                                                    var meta = document.querySelector('meta[name=\"theme-color\"]');
                                                    if (!meta) {
                                                      meta = document.createElement('meta');
                                                      meta.name = 'theme-color';
                                                      document.head && document.head.appendChild(meta);
                                                    }
                                                    if (meta) meta.content = '#000000';
                                                  } catch (e) {}
                                                })();
                                                """.trimIndent(),
                                                null
                                            )

                                            if (webSearchQuery.isBlank()) return

                                            val current = url.orEmpty()

                                            if (autoExtractActive && current.contains("google.", ignoreCase = true)) {
                                                // Search page: first detect a true no-results page.
                                                view.evaluateJavascript(
                                                    "(document.body && document.body.innerText ? document.body.innerText : '').toLowerCase()"
                                                ) { bodyJson ->
                                                    val body = try {
                                                        org.json.JSONTokener(bodyJson).nextValue() as? String ?: ""
                                                    } catch (_: Exception) { "" }

                                                    val noResults = body.contains("did not match any documents") ||
                                                        body.contains("no results found") ||
                                                        body.contains("nema rezultata")

                                                    if (noResults && !autoExtractTriedText) {
                                                        autoExtractTriedText = true
                                                        val fallback = webSearchUrlFor(webSearchQuery, "text")
                                                        webSearchUrl = fallback
                                                        view.loadUrl(fallback)
                                                        return@evaluateJavascript
                                                    }

                                                    // Collect a few normal text-page candidates instead of
                                                    // silently choosing the first hit. This avoids opening the
                                                    // wrong song when several artists use the same title.
                                                    val collectResultsJs = """
                                                        (function() {
                                                          const out = [];
                                                          const seen = new Set();
                                                          const links = Array.from(document.querySelectorAll('a[href]'));
                                                          for (const a of links) {
                                                            const h = (a.href || '').trim();
                                                            if (!/^https?:/i.test(h)) continue;
                                                            const low = h.toLowerCase();
                                                            if (low.includes('google.')) continue;
                                                            if (low.includes('youtube.com') || low.includes('youtu.be')) continue;
                                                            if (low.includes('/video') || low.includes('/shorts')) continue;
                                                            if (seen.has(h)) continue;

                                                            let label = (a.innerText || '').replace(/\\s+/g, ' ').trim();
                                                            if (label.length < 3) continue;
                                                            if (label.length > 120) label = label.slice(0, 120);

                                                            seen.add(h);
                                                            out.push({title: label, url: h});
                                                            if (out.length >= 5) break;
                                                          }
                                                          return JSON.stringify(out);
                                                        })();
                                                    """.trimIndent()

                                                    view.evaluateJavascript(collectResultsJs) { candidatesJson ->
                                                        try {
                                                            val outer = if (candidatesJson == null || candidatesJson == "null") "" else
                                                                org.json.JSONTokener(candidatesJson).nextValue() as? String ?: ""
                                                            val arr = org.json.JSONArray(outer)
                                                            val parsed = buildList {
                                                                for (i in 0 until arr.length()) {
                                                                    val item = arr.optJSONObject(i) ?: continue
                                                                    val title = item.optString("title").trim()
                                                                    val urlValue = item.optString("url").trim()
                                                                    if (title.isNotBlank() && urlValue.isNotBlank()) {
                                                                        add(title to urlValue)
                                                                    }
                                                                }
                                                            }

                                                            if (parsed.size == 1) {
                                                                autoCandidateOpened = true
                                                                view.loadUrl(parsed.first().second)
                                                            } else if (parsed.isNotEmpty()) {
                                                                candidateChoices = parsed
                                                                autoExtractActive = false
                                                            } else if (!autoExtractTriedText) {
                                                                autoExtractTriedText = true
                                                                val fallback = webSearchUrlFor(webSearchQuery, "text")
                                                                webSearchUrl = fallback
                                                                view.loadUrl(fallback)
                                                            } else {
                                                                autoExtractActive = false
                                                                Toast.makeText(context, "Web fallback", Toast.LENGTH_SHORT).show()
                                                            }
                                                        } catch (_: Exception) {
                                                            autoExtractActive = false
                                                            Toast.makeText(context, "Web fallback", Toast.LENGTH_SHORT).show()
                                                        }
                                                    }
                                                }
                                            } else if (autoExtractActive && autoCandidateOpened) {
                                                // Candidate text page: try extracting immediately.
                                                view.evaluateJavascript(lyricsExtractionJs()) { result ->
                                                    applyExtractedResult(view, result, automatic = true)
                                                }
                                            }
                                        }
                                    }
                                    webViewRef = this
                                    webSearchUrl?.let { loadUrl(it) }
                                }
                            },
                            update = { view ->
                                webViewRef = view
                                val target = webSearchUrl
                                if (target != null && view.url != target && view.url.isNullOrBlank()) {
                                    view.loadUrl(target)
                                }
                            },
                            modifier = if (autoExtractActive || candidateChoices.isNotEmpty()) {
                                Modifier
                                    .fillMaxWidth()
                                    .height(1.dp)
                            } else {
                                Modifier
                                    .weight(1f)
                                    .fillMaxWidth()
                            }
                        )
                    }
                } else if (openedText != null) {
                    // Reader: simple linear NEXT LINE tracker. No searching ahead, no GPS logic.
                    val lyricListState = rememberLazyListState()
                    LaunchedEffect(stageLineIndex, stageMicOn) {
                        if (stageMicOn && stageLineIndex >= 0) {
                            val layout = lyricListState.layoutInfo
                            val visible = layout.visibleItemsInfo
                            if (visible.isNotEmpty()) {
                                val viewportStart = layout.viewportStartOffset
                                val viewportEnd = layout.viewportEndOffset
                                val viewportHeight = (viewportEnd - viewportStart).coerceAtLeast(1)
                                val twoThirdsY = viewportStart + (viewportHeight * 2 / 3)
                                val gentlePageStep = (viewportHeight / 4).toFloat()
                                val target = visible.firstOrNull { it.index == stageLineIndex }

                                if (target != null) {
                                    val targetCenter = target.offset + target.size / 2
                                    if (targetCenter >= twoThirdsY) {
                                        // Teleprompter-style movement: the line walks down through
                                        // the page; only at 2/3 do we gently lift the page by 1/4.
                                        lyricListState.animateScrollBy(gentlePageStep)
                                    }
                                } else if (stageLineIndex > visible.last().index) {
                                    // Ignored blank/ref lines can make the next lyric land just
                                    // beyond the viewport. Reveal it gently, without jumping to top.
                                    lyricListState.animateScrollBy(gentlePageStep)
                                }
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(58.dp)
                            .padding(horizontal = 8.dp)
                    ) {
                        Text(
                            text = openedTitle.removeSuffix(".txt"),
                            color = Color.White,
                            fontSize = 18.sp,
                            maxLines = 1,
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .fillMaxWidth(0.38f),
                            textAlign = TextAlign.Start
                        )

                        Button(
                            onClick = {
                                if (stageMicOn) {
                                    stageMicOn = false
                                } else if (frankiRecognizer == null) {
                                    if (frankiLoading) {
                                        Toast.makeText(context, if (frankiInstalling) "FRANKI installing ${frankiProgress}%…" else "FRANKI downloading ${frankiProgress}%…", Toast.LENGTH_SHORT).show()
                                    } else {
                                        showSetup = true
                                    }
                                } else if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                    stageMicOn = true
                                    if (stageLineIndex < 0) stageLineIndex = nextStageLine(-1)
                                    stageRestartToken++
                                } else {
                                    stagePermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            },
                            modifier = Modifier
                                .align(Alignment.Center)
                                .width(150.dp)
                                .height(52.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text(if (stageMicOn) "🎤  MIC ON" else if (frankiLoading && frankiInstalling) "⟳  ${frankiProgress}%" else if (frankiLoading) "🎤  ${frankiProgress}%" else "🎤  MIC OFF", fontSize = 17.sp)
                        }

                        Row(modifier = Modifier.align(Alignment.CenterEnd), verticalAlignment = Alignment.CenterVertically) {
                            TextButton(
                                onClick = { showSetup = true },
                                modifier = Modifier.size(48.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) { Text("⚙", color = Color.White, fontSize = 26.sp) }
                            TextButton(onClick = {
                                fontSize = (fontSize - 2f).coerceAtLeast(16f)
                                prefs.edit().putFloat("font_size", fontSize).apply()
                            }) { Text("A−", color = Color.White, fontSize = 18.sp) }
                            TextButton(onClick = {
                                fontSize = (fontSize + 2f).coerceAtMost(60f)
                                prefs.edit().putFloat("font_size", fontSize).apply()
                            }) { Text("A+", color = Color.White, fontSize = 18.sp) }
                        }
                    }

                    LazyColumn(
                        state = lyricListState,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(horizontal = 18.dp, vertical = 8.dp)
                    ) {
                        items(stageLines.size) { index ->
                            val highlighted = stageMicOn && index == stageLineIndex
                            Text(
                                text = stageLines[index],
                                color = if (highlighted) Color(0xFFFFFF00) else Color.White,
                                fontSize = fontSize.sp,
                                lineHeight = (fontSize * 1.35f).sp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(if (highlighted) Color(0xFFB34700) else Color.Transparent)
                                    .clickable(enabled = !stageIgnoreLine(stageLines[index])) {
                                        stageLineIndex = index
                                        if (stageMicOn) stageRestartToken++
                                    }
                                    .padding(horizontal = if (highlighted) 6.dp else 0.dp, vertical = 1.dp)
                            )
                        }
                    }
                } else {
                    if (isRoot) {
                        // Home content floats over the single root-level bitmap wallpaper.
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        ) {
                            Column(Modifier.fillMaxSize()) {
                                // Stage title over the single wallpaper. Keep it high and easy to spot.
                                Text(
                                    text = "GigLyrics",
                                    color = Color.White.copy(alpha = 0.72f),
                                    fontSize = 42.sp,
                                    fontWeight = FontWeight.Normal,
                                    fontFamily = FontFamily.Cursive,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 10.dp, bottom = 18.dp)
                                )

                                BoxWithConstraints(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp)
                                ) {
                                    // One shared width = Local and Web fields are exactly the same length.
                                    val safeHalfWidth = (maxWidth - 204.dp).coerceAtLeast(120.dp)
                                    val searchFieldWidth = (maxWidth * 0.50f).coerceAtMost(safeHalfWidth)

                                    Column(Modifier.fillMaxWidth()) {
                                        // LOCAL: anchored to the left edge.
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            OutlinedTextField(
                                                value = searchQuery,
                                                onValueChange = { doSearch(it) },
                                                placeholder = { Text("Local lyrics", fontSize = 21.sp) },
                                                singleLine = true,
                                                shape = RoundedCornerShape(14.dp),
                                                textStyle = LocalTextStyle.current.copy(fontSize = 24.sp),
                                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                                keyboardActions = KeyboardActions(
                                                    onSearch = { doSearch(searchQuery) },
                                                    onDone = { doSearch(searchQuery) }
                                                ),
                                                modifier = Modifier
                                                    .width(searchFieldWidth)
                                                    .heightIn(min = 58.dp),
                                                colors = OutlinedTextFieldDefaults.colors(
                                                    focusedTextColor = Color.White,
                                                    unfocusedTextColor = Color.White,
                                                    focusedBorderColor = Color.White,
                                                    unfocusedBorderColor = Color.White,
                                                    cursorColor = Color.White,
                                                    focusedPlaceholderColor = Color(0xFFB0B0B0),
                                                    unfocusedPlaceholderColor = Color(0xFFB0B0B0),
                                                    focusedContainerColor = Color.Black.copy(alpha = 0.88f),
                                                    unfocusedContainerColor = Color.Black.copy(alpha = 0.82f)
                                                )
                                            )

                                            Spacer(Modifier.width(8.dp))

                                            Surface(
                                                modifier = Modifier
                                                    .size(98.dp)
                                                    .clickable { launchVoiceSearch() },
                                                color = Color.Black.copy(alpha = 0.90f),
                                                contentColor = Color.White,
                                                shape = RoundedCornerShape(18.dp),
                                                border = androidx.compose.foundation.BorderStroke(2.dp, Color.White)
                                            ) {
                                                MicGlyph(Modifier.fillMaxSize().padding(13.dp))
                                            }

                                            // Keep text-size controls away from the mic so they are easy to tap on stage.
                                            Spacer(Modifier.weight(1f))

                                            Column(
                                                modifier = Modifier.width(72.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Surface(
                                                    modifier = Modifier
                                                        .width(66.dp)
                                                        .height(56.dp)
                                                        .clickable {
                                                            listFontSize = (listFontSize + 2f).coerceAtMost(48f)
                                                            prefs.edit().putFloat("list_font_size", listFontSize).apply()
                                                        },
                                                    color = Color.Black.copy(alpha = 0.78f),
                                                    contentColor = Color.White,
                                                    shape = RoundedCornerShape(15.dp),
                                                    border = androidx.compose.foundation.BorderStroke(1.5.dp, Color.White)
                                                ) {
                                                    Box(contentAlignment = Alignment.Center) {
                                                        Text("+", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Light)
                                                    }
                                                }
                                                Surface(
                                                    modifier = Modifier
                                                        .width(66.dp)
                                                        .height(56.dp)
                                                        .clickable {
                                                            listFontSize = (listFontSize - 2f).coerceAtLeast(16f)
                                                            prefs.edit().putFloat("list_font_size", listFontSize).apply()
                                                        },
                                                    color = Color.Black.copy(alpha = 0.78f),
                                                    contentColor = Color.White,
                                                    shape = RoundedCornerShape(15.dp),
                                                    border = androidx.compose.foundation.BorderStroke(1.5.dp, Color.White)
                                                ) {
                                                    Box(contentAlignment = Alignment.Center) {
                                                        Text("−", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Light)
                                                    }
                                                }
                                            }
                                        }

                                        Spacer(Modifier.height(8.dp))

                                        // WEB: mirrored visual weight; field is anchored to the right edge.
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.End
                                        ) {
                                            Surface(
                                                modifier = Modifier
                                                    .size(98.dp)
                                                    .clickable { launchWebVoiceSearch() },
                                                color = Color.Black.copy(alpha = 0.90f),
                                                contentColor = Color.White,
                                                shape = RoundedCornerShape(18.dp),
                                                border = androidx.compose.foundation.BorderStroke(2.dp, Color.White)
                                            ) {
                                                MicGlyph(Modifier.fillMaxSize().padding(13.dp))
                                            }

                                            Spacer(Modifier.width(8.dp))

                                            Surface(
                                                modifier = Modifier
                                                    .size(68.dp)
                                                    .clickable { launchWebSearch(webSearchQuery) },
                                                color = Color.Black.copy(alpha = 0.90f),
                                                contentColor = Color.White,
                                                shape = RoundedCornerShape(16.dp),
                                                border = androidx.compose.foundation.BorderStroke(2.dp, Color.White)
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Text("🌍", fontSize = 33.sp)
                                                }
                                            }

                                            Spacer(Modifier.width(8.dp))

                                            OutlinedTextField(
                                                value = webSearchQuery,
                                                onValueChange = { webSearchQuery = it },
                                                placeholder = { Text("Web lyrics", fontSize = 21.sp) },
                                                singleLine = true,
                                                shape = RoundedCornerShape(14.dp),
                                                textStyle = LocalTextStyle.current.copy(fontSize = 24.sp),
                                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                                keyboardActions = KeyboardActions(
                                                    onSearch = { launchWebSearch(webSearchQuery) },
                                                    onDone = { launchWebSearch(webSearchQuery) }
                                                ),
                                                modifier = Modifier
                                                    .width(searchFieldWidth)
                                                    .heightIn(min = 58.dp),
                                                colors = OutlinedTextFieldDefaults.colors(
                                                    focusedTextColor = Color.White,
                                                    unfocusedTextColor = Color.White,
                                                    focusedBorderColor = Color.White,
                                                    unfocusedBorderColor = Color.White,
                                                    cursorColor = Color.White,
                                                    focusedPlaceholderColor = Color(0xFFB0B0B0),
                                                    unfocusedPlaceholderColor = Color(0xFFB0B0B0),
                                                    focusedContainerColor = Color.Black.copy(alpha = 0.88f),
                                                    unfocusedContainerColor = Color.Black.copy(alpha = 0.82f)
                                                )
                                            )
                                        }
                                    }
                                }

                                val homeList = if (searching) {
                                    searchResults
                                } else {
                                    entries.filterNot {
                                        it.isDirectory && it.name.equals("Downloaded Lyrics", ignoreCase = true)
                                    }
                                }

                                if (!searching && rootUri != null) {
                                    // More separation from search so Downloaded Lyrics reads as library, not search.
                                    Spacer(Modifier.height(34.dp))
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.CenterHorizontally)
                                            .fillMaxWidth(0.46f)
                                            .height(40.dp)
                                            .clip(RoundedCornerShape(16.dp))
                                            .background(Color(0xFF1E1E1E).copy(alpha = 0.88f))
                                            .clickable {
                                                val folder = downloadedLyricsUri
                                                    ?: rootUri?.let { ensureDownloadedLyricsFolder(it) }
                                                if (folder != null) navigateTo(NavLocation(folder))
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "Downloaded",
                                            color = Color(0xFFD0D0D0),
                                            fontSize = 21.sp,
                                            fontWeight = FontWeight.Medium,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                    Spacer(Modifier.height(18.dp))
                                }

                                HomeBrowserList(
                                    listToShow = homeList,
                                    searching = searching,
                                    listFontSize = listFontSize,
                                    modifier = Modifier.weight(1f),
                                    showDownloaded = false,
                                    onDownloadedClick = {
                                        val folder = downloadedLyricsUri ?: rootUri?.let { ensureDownloadedLyricsFolder(it) }
                                        if (folder != null) navigateTo(NavLocation(folder))
                                    },
                                    onEntryClick = { item ->
                                        if (item.isDirectory) {
                                            currentUri?.let { navigateTo(NavLocation(item.uri)) }
                                        } else {
                                            val folder = currentUri ?: rootUri
                                            if (folder != null) {
                                                navigateTo(NavLocation(folder, item.uri, item.name))
                                            }
                                        }
                                    }
                                )
                            }
                        }
                    } else {
                        // Inside folders: deliberately minimal.
                        Text(
                            text = currentTitle,
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        )

                        BrowserList(
                            listToShow = if (searching) searchResults else entries,
                            searching = searching,
                            listFontSize = listFontSize,
                            modifier = Modifier.weight(1f),
                            onEntryClick = { item ->
                                if (item.isDirectory) {
                                    navigateTo(NavLocation(item.uri))
                                } else {
                                    val folder = currentUri ?: return@BrowserList
                                    navigateTo(NavLocation(folder, item.uri, item.name))
                                }
                            }
                        )
                    }
                }

                // Stage controls: back, HOME, donate, forward.
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(104.dp)
                        .padding(horizontal = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = { goBack() },
                        enabled = searching || backHistory.isNotEmpty(),
                        modifier = Modifier.size(92.dp),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        NavChevron(
                            pointsRight = false,
                            modifier = Modifier.size(82.dp)
                        )
                    }

                    TextButton(
                        onClick = { goHome() },
                        enabled = rootUri != null && !isRoot,
                        modifier = Modifier.size(76.dp),
                        contentPadding = PaddingValues(8.dp)
                    ) {
                        HomeGlyph(Modifier.fillMaxSize())
                    }

                    Column(
                        modifier = Modifier
                            .clickable { openDonate() }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("♥", color = Color(0xFFE53935), fontSize = 36.sp, lineHeight = 34.sp)
                        Text(
                            "Donate",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontFamily = FontFamily.Cursive,
                            lineHeight = 20.sp
                        )
                    }

                    TextButton(
                        onClick = { goForward() },
                        enabled = forwardHistory.isNotEmpty(),
                        modifier = Modifier.size(92.dp),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        NavChevron(
                            pointsRight = true,
                            modifier = Modifier.size(82.dp)
                        )
                    }
                }
            }
            

                if (!stageWarmupDone) {
                    Surface(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 14.dp)
                            .zIndex(50f),
                        color = Color.Black.copy(alpha = 0.88f),
                        shape = RoundedCornerShape(18.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF666666))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp,
                                color = Color(0xFFFFC107)
                            )
                            Spacer(Modifier.width(9.dp))
                            Text("LYRIC SYNC LOADING…", color = Color.White, fontSize = 14.sp)
                        }
                    }
                }
}
        }
    }
}

@Composable
private fun HomeBrowserList(
    listToShow: List<Entry>,
    searching: Boolean,
    listFontSize: Float,
    modifier: Modifier = Modifier,
    showDownloaded: Boolean,
    onDownloadedClick: () -> Unit,
    onEntryClick: (Entry) -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(vertical = 8.dp)
    ) {
        items(listToShow, key = { it.uri.toString() }) { item ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onEntryClick(item) }
                    .padding(horizontal = 18.dp, vertical = 13.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (item.isDirectory) "›  ${item.name}" else item.name.removeSuffix(".txt"),
                    color = Color.White,
                    fontSize = listFontSize.sp,
                    fontWeight = if (item.isDirectory) FontWeight.SemiBold else FontWeight.Normal,
                    textAlign = TextAlign.Center
                )
                if (searching && item.pathLabel.isNotBlank()) {
                    Text(
                        text = item.pathLabel,
                        color = Color.Gray,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }

        if (showDownloaded) {
            item(key = "__downloaded_lyrics__") {
                Column(Modifier.fillMaxWidth()) {
                    HorizontalDivider(
                        modifier = Modifier.padding(horizontal = 32.dp, vertical = 4.dp),
                        thickness = 1.dp,
                        color = Color(0xFF555555)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Downloaded",
                        color = Color(0xFFD0D0D0),
                        fontSize = (listFontSize - 6f).coerceAtLeast(12f).sp,
                        fontWeight = FontWeight.Normal,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onDownloadedClick() }
                            .padding(horizontal = 18.dp, vertical = 8.dp)
                    )
                }
            }
        }

        if (searching && listToShow.isEmpty()) {
            item {
                Text(
                    text = "Nema rezultata.",
                    color = Color.Gray,
                    fontSize = 18.sp,
                    modifier = Modifier.fillMaxWidth().padding(20.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun BrowserList(
    listToShow: List<Entry>,
    searching: Boolean,
    listFontSize: Float,
    modifier: Modifier = Modifier,
    onEntryClick: (Entry) -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(vertical = 8.dp)
    ) {
        items(listToShow, key = { it.uri.toString() }) { item ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onEntryClick(item) }
                    .padding(horizontal = 18.dp, vertical = 13.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (item.isDirectory) "›  ${item.name}" else item.name.removeSuffix(".txt"),
                    color = Color.White,
                    fontSize = listFontSize.sp,
                    fontWeight = if (item.isDirectory) FontWeight.SemiBold else FontWeight.Normal,
                    textAlign = TextAlign.Center
                )

                if (searching && item.pathLabel.isNotBlank()) {
                    Text(
                        text = item.pathLabel,
                        color = Color.Gray,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }

        if (searching && listToShow.isEmpty()) {
            item {
                Text(
                    text = "Nema rezultata.",
                    color = Color.Gray,
                    fontSize = 18.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun NavChevron(
    pointsRight: Boolean,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val insetX = size.width * 0.28f
        val insetY = size.height * 0.18f
        val centerY = size.height / 2f
        val leftX = insetX
        val rightX = size.width - insetX
        val tipX = if (pointsRight) rightX else leftX
        val outerX = if (pointsRight) leftX else rightX

        val path = Path().apply {
            moveTo(outerX, insetY)
            lineTo(tipX, centerY)
            lineTo(outerX, size.height - insetY)
        }

        drawPath(
            path = path,
            color = Color.White,
            style = Stroke(
                width = size.minDimension * 0.095f,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }
}

@Composable
private fun HomeGlyph(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val stroke = size.minDimension * 0.10f
        val left = size.width * 0.20f
        val right = size.width * 0.80f
        val roofY = size.height * 0.43f
        val peakY = size.height * 0.18f
        val bottomY = size.height * 0.82f
        val cx = size.width / 2f

        val roof = Path().apply {
            moveTo(left, roofY)
            lineTo(cx, peakY)
            lineTo(right, roofY)
        }
        drawPath(
            path = roof,
            color = Color.White,
            style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        val body = Path().apply {
            moveTo(size.width * 0.28f, roofY * 0.95f)
            lineTo(size.width * 0.28f, bottomY)
            lineTo(size.width * 0.72f, bottomY)
            lineTo(size.width * 0.72f, roofY * 0.95f)
        }
        drawPath(
            path = body,
            color = Color.White,
            style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        drawLine(
            color = Color.White,
            start = Offset(size.width * 0.46f, bottomY),
            end = Offset(size.width * 0.46f, size.height * 0.62f),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color.White,
            start = Offset(size.width * 0.46f, size.height * 0.62f),
            end = Offset(size.width * 0.60f, size.height * 0.62f),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color.White,
            start = Offset(size.width * 0.60f, size.height * 0.62f),
            end = Offset(size.width * 0.60f, bottomY),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
    }
}

@Composable
private fun MiniMicLogo(modifier: Modifier = Modifier) {
    MicGlyph(modifier)
}

@Composable
private fun MicGlyph(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val top = h * 0.12f
        val bottom = h * 0.58f
        val radius = w * 0.18f

        drawRoundRect(
            color = Color.White,
            topLeft = Offset(cx - radius, top),
            size = androidx.compose.ui.geometry.Size(radius * 2f, bottom - top),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius)
        )

        drawArc(
            color = Color.White,
            startAngle = 0f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = Offset(w * 0.20f, h * 0.26f),
            size = androidx.compose.ui.geometry.Size(w * 0.60f, h * 0.48f),
            style = Stroke(width = w * 0.08f, cap = StrokeCap.Round)
        )

        drawLine(
            color = Color.White,
            start = Offset(cx, h * 0.70f),
            end = Offset(cx, h * 0.88f),
            strokeWidth = w * 0.08f,
            cap = StrokeCap.Round
        )

        drawLine(
            color = Color.White,
            start = Offset(w * 0.34f, h * 0.88f),
            end = Offset(w * 0.66f, h * 0.88f),
            strokeWidth = w * 0.08f,
            cap = StrokeCap.Round
        )
    }
}
