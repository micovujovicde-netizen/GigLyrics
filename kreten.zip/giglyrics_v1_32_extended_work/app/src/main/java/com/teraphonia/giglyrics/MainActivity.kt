package com.teraphonia.giglyrics

import android.content.Context
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.net.Uri
import android.provider.DocumentsContract
import android.os.Bundle
import android.os.SystemClock
import android.Manifest
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import android.webkit.WebView
import android.media.AudioRecord
import android.media.AudioFormat
import android.media.MediaRecorder
import android.media.audiofx.NoiseSuppressor
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.zIndex
import androidx.documentfile.provider.DocumentFile
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.BufferedInputStream
import java.util.zip.ZipInputStream
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.net.URLEncoder
import java.net.URL
import java.net.HttpURLConnection
import java.nio.charset.StandardCharsets
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import org.vosk.android.RecognitionListener as VoskRecognitionListener
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineWhisperModelConfig
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        BB2.event(this, "APP_START")
        BB2.startUiWatchdog(this)
        setContent { LyrGigApp(this) }
    }

    override fun onDestroy() {
        BB2.stopUiWatchdog()
        super.onDestroy()
    }
}

data class Entry(
    val name: String,
    val uri: Uri,
    val isDirectory: Boolean,
    val pathLabel: String = ""
)

data class NavLocation(
    val folderUri: Uri,
    val fileUri: Uri? = null,
    val fileName: String? = null
)

data class LibraryIndex(
    val songs: List<Entry>,
    val folders: Map<String, List<Entry>>
)

data class ConversionCandidate(
    val file: DocumentFile,
    val parent: DocumentFile
)

data class RenamerPreviewItem(
    val uri: Uri,
    val oldName: String,
    val newName: String
)

enum class TxtRenameMode(val label: String) {
    ARTIST_FULL("John Smith - Song (Key)"),
    ARTIST_SHORT("J. Smith - Song (Key)"),
    SONG_ARTIST_FULL("Song - John Smith (Key)"),
    SONG_ARTIST_SHORT("Song - J. Smith (Key)")
}

private fun renamerCleanSpaces(value: String): String = value
    .replace(Regex("\\s+"), " ")
    .trim()
    .trim('-', '–', '—', '_', ' ')
    .trim()

private fun renamerIsKey(raw: String): Boolean {
    val v = raw.trim().replace("♯", "#").replace("♭", "b")
    if (v.isBlank()) return false
    // Balkan/German + international spellings. Deliberately whitelist-only.
    return Regex(
        "(?i)^(?:[a-h](?:is|es|s)?(?:mol|m)?|[a-g](?:#|b)(?:mol|m)?|[a-g](?:mol|m)?)$"
    ).matches(v)
}

private fun renamerExtractKey(baseName: String): Pair<String, String?> {
    var base = baseName.trim()
    // Bracketed tonalities at the end: (), [], {}, <> and common mixed bracket mistakes.
    val bracket = Regex("\\s*[\\(\\[\\{<]+\\s*([^\\)\\]\\}>]+?)\\s*[\\)\\]\\}>]+\\s*$")
        .find(base)
    if (bracket != null && renamerIsKey(bracket.groupValues[1])) {
        return base.removeRange(bracket.range).trim() to bracket.groupValues[1].trim()
    }
    // Standalone key at the end, with or without a stray dash.
    val tail = Regex("(?i)(?:\\s*[-–—]+\\s*|\\s+)([A-H](?:is|es|s)?(?:mol|m)?|[A-G](?:#|b)(?:mol|m)?|[A-G](?:mol|m)?)\\s*$")
        .find(base)
    if (tail != null && renamerIsKey(tail.groupValues[1])) {
        return base.removeRange(tail.range).trim() to tail.groupValues[1].trim()
    }
    return base to null
}

private fun renamerCanonicalKey(raw: String): String {
    val v = raw.trim().replace("♯", "#").replace("♭", "b")
    if (v.isBlank()) return v
    return v.substring(0, 1).uppercase(Locale.ROOT) + v.substring(1).lowercase(Locale.ROOT)
}

private fun renamerNormalizeShortArtist(artistRaw: String): String? {
    var artist = renamerCleanSpaces(artistRaw)
    if (artist.isBlank()) return null
    artist = artist.replace(Regex("^([\\p{L}])\\.(?=\\p{L})"), "$1. ")
    val parts = artist.split(Regex("\\s+")).filter { it.isNotBlank() }.toMutableList()
    if (parts.isEmpty()) return null
    if (Regex("^[\\p{L}]$").matches(parts[0])) parts[0] = parts[0] + "."
    return parts.joinToString(" ")
}

private fun renamerShortArtist(artistRaw: String): String? {
    val artist = renamerCleanSpaces(artistRaw)
    if (artist.isBlank()) return null
    val parts = artist.split(Regex("\\s+")).filter { it.isNotBlank() }
    if (parts.size < 2) return artist
    val first = parts.first()
    if (Regex("^[\\p{L}]\\.$").matches(first)) return artist
    val initial = first.firstOrNull { it.isLetter() } ?: return null
    return "$initial. ${parts.drop(1).joinToString(" ")}" 
}

private fun renamerBuildName(fileName: String, mode: TxtRenameMode): String? {
    if (!fileName.endsWith(".txt", ignoreCase = true)) return null
    val rawBase = fileName.dropLast(4)
    val (withoutKey, key) = renamerExtractKey(rawBase)
    val pieces = withoutKey.split(Regex("\\s*[-–—]+\\s*"), limit = 2)
        .map(::renamerCleanSpaces)
    if (pieces.size != 2 || pieces.any { it.isBlank() }) return null

    val artistRaw: String
    val songRaw: String
    when (mode) {
        TxtRenameMode.ARTIST_FULL, TxtRenameMode.ARTIST_SHORT -> {
            artistRaw = pieces[0]
            songRaw = pieces[1]
        }
        TxtRenameMode.SONG_ARTIST_FULL, TxtRenameMode.SONG_ARTIST_SHORT -> {
            songRaw = pieces[0]
            artistRaw = pieces[1]
        }
    }
    val artist = when (mode) {
        TxtRenameMode.ARTIST_FULL, TxtRenameMode.SONG_ARTIST_FULL -> renamerShortArtist(artistRaw)
        TxtRenameMode.ARTIST_SHORT, TxtRenameMode.SONG_ARTIST_SHORT -> renamerNormalizeShortArtist(artistRaw)
    } ?: return null
    val song = renamerCleanSpaces(songRaw)
    if (artist.isBlank() || song.isBlank()) return null
    val keySuffix = key?.let { " (${renamerCanonicalKey(it)})" }.orEmpty()
    return "$artist - $song$keySuffix.txt"
}

private fun renamerCollect(folder: DocumentFile, mode: TxtRenameMode, out: MutableList<RenamerPreviewItem>) {
    folder.listFiles().forEach { child ->
        when {
            child.isDirectory -> renamerCollect(child, mode, out)
            child.isFile && child.name?.endsWith(".txt", ignoreCase = true) == true -> {
                val old = child.name ?: return@forEach
                val proposed = renamerBuildName(old, mode) ?: return@forEach
                if (proposed != old) out += RenamerPreviewItem(child.uri, old, proposed)
            }
        }
    }
}

private fun stageNormalize(text: String): String = Normalizer.normalize(text.lowercase(Locale.getDefault()), Normalizer.Form.NFD)
    .replace(Regex("\\p{Mn}+"), "")
    .replace(Regex("[^\\p{L}\\p{N}']+"), " ")
    .trim()
    .replace(Regex("\\s+"), " ")

private fun bcsToPolish(text: String): String {
    // Keep the visible lyric untouched. This string exists only for the Polish Vosk ear.
    // Longest combinations first.
    return text.lowercase(Locale.ROOT)
        .replace("dž", "dż")
        .replace("lj", "l")
        .replace("nj", "ń")
        .replace("đ", "dź")
        .replace("č", "cz")
        .replace("ć", "ć")
        .replace("š", "sz")
        .replace("ž", "ż")
}

private fun stageEngineText(text: String, language: String): String {
    // Cecil English and Whisper EX-YU both match against normalised visible lyrics.
    return stageNormalize(text)
}

private data class StageLanguageProfile(
    val label: String,
    val hints: Set<String>,
    val strongHints: Set<String> = emptySet(),
)

private fun stageLanguageProfileScore(words: List<String>, profile: StageLanguageProfile): Double {
    if (words.isEmpty()) return 0.0
    val counts = words.groupingBy { it }.eachCount()
    var score = 0.0
    profile.hints.forEach { word ->
        val n = counts[word] ?: 0
        if (n > 0) score += 1.0 + minOf(n - 1, 2) * 0.35
    }
    profile.strongHints.forEach { word ->
        val n = counts[word] ?: 0
        if (n > 0) score += 2.2 + minOf(n - 1, 2) * 0.55
    }
    return score
}

private val STAGE_LATIN_LANGUAGE_PROFILES = listOf(
    StageLanguageProfile(
        "Montenegrin",
        setOf("ja","ti","on","ona","mi","vi","oni","sam","si","je","smo","ste","su","ne","da","ali","kad","kada","gdje","gde","sto","ko","kao","jer","ako","dok","pa","sad","sada","opet","moj","moja","moje","tvoj","tvoja","tvoje","samo","bez","tebe","mene","meni","tebi","nama","vama","bio","bila","bilo","bili","imam","imas","ima","nikad","uvek","uvijek","hocu","zelim"),
        setOf("ljubav","srce","noc","zivot","volim","volis","pjesma","pesma","djevojka","devojka","brate","druze","zajedno","necu","hoću","želim","čovjek","covjek")
    ),
    StageLanguageProfile(
        "English",
        setOf("the","and","you","your","i","me","my","we","our","love","baby","heart","girl","boy","is","are","was","were","be","to","of","in","on","for","with","from","at","by","dont","do","does","did","not","never","always","when","where","why","how","this","that","what","who","can","could","will","would","say","said","tell","come","go","know","want","need","feel","night","day"),
        setOf("ain't","im","ive","youre","we're","they're")
    ),
    StageLanguageProfile(
        "Italian",
        setOf("che","non","di","e","la","il","lo","gli","le","un","una","per","con","sono","sei","era","come","ma","piu","qui","quando","dove","cosa","tutto","niente","mio","mia","tuo","tua","amore","vita","cuore","notte","giorno","ancora","sempre","mai"),
        setOf("sara","perche","anche","senza","questa","questo","della","delle","degli","alla","sulla","nel","nella","paese")
    ),
    StageLanguageProfile(
        "Spanish",
        setOf("que","de","la","el","los","las","un","una","y","no","si","yo","tu","mi","me","te","se","por","para","con","sin","como","pero","cuando","donde","todo","nada","amor","vida","corazon","noche","dia","siempre","nunca","quiero","eres","soy","esta","estoy"),
        setOf("porque","tambien","aqui","alla","contigo","conmigo","quieres","puedo","tengo")
    ),
    StageLanguageProfile(
        "Portuguese / Brazilian Portuguese",
        setOf("que","de","da","do","das","dos","o","a","os","as","um","uma","e","nao","sim","eu","tu","voce","me","te","se","por","para","com","sem","como","mas","quando","onde","tudo","nada","amor","vida","coracao","noite","dia","sempre","nunca","quero","sou","esta"),
        setOf("porque","tambem","aqui","voce","meu","minha","seu","sua","pra","gente")
    ),
    StageLanguageProfile(
        "French",
        setOf("je","tu","il","elle","nous","vous","ils","elles","le","la","les","un","une","de","des","du","et","ou","mais","pas","ne","que","qui","dans","sur","avec","sans","pour","par","mon","ma","mes","ton","ta","tes","amour","coeur","nuit","jour","toujours","jamais","suis","est","sont"),
        setOf("cest","jai","toi","moi","encore","pourquoi","quand","comme","rien")
    ),
    StageLanguageProfile(
        "German",
        setOf("ich","du","er","sie","wir","ihr","der","die","das","ein","eine","und","oder","aber","nicht","kein","ist","sind","war","mit","ohne","fur","von","zu","im","in","auf","mein","meine","dein","deine","liebe","herz","nacht","tag","immer","nie","wenn","wo","wie","was","wer"),
        setOf("dich","mich","noch","doch","weil","denn","heute","morgen")
    ),
    StageLanguageProfile(
        "Dutch",
        setOf("ik","jij","je","hij","zij","wij","we","jullie","de","het","een","en","of","maar","niet","geen","is","zijn","was","met","zonder","voor","van","naar","in","op","mijn","jouw","liefde","hart","nacht","dag","altijd","nooit","wanneer","waar","hoe","wat","wie"),
        setOf("mij","jou","nog","omdat","hier","daar","heb","heeft")
    ),
    StageLanguageProfile(
        "Catalan",
        setOf("jo","tu","ell","ella","nosaltres","vosaltres","el","la","els","les","un","una","i","o","pero","no","si","de","del","amb","sense","per","com","quan","on","tot","res","amor","vida","cor","nit","dia","sempre","mai","soc","ets","es"),
        setOf("aixo","aquesta","aquest","teva","meva","perque","aqui")
    ),
    StageLanguageProfile(
        "Turkish",
        setOf("ben","sen","o","biz","siz","onlar","ve","veya","ama","degil","bir","bu","su","ile","icin","gibi","ne","neden","nasil","nerede","zaman","ask","kalp","gece","gun","hep","hic","beni","seni","benim","senin","var","yok"),
        setOf("cok","simdi","sonra","belki","seviyorum","sevgi","yalniz")
    ),
    StageLanguageProfile(
        "Swedish",
        setOf("jag","du","han","hon","vi","ni","de","det","den","en","ett","och","eller","men","inte","ar","var","med","utan","for","fran","till","i","pa","min","mitt","din","ditt","karlek","hjarta","natt","dag","alltid","aldrig","nar","var","hur","vad","vem"),
        setOf("mig","dig","har","dar","igen","bara")
    ),
    StageLanguageProfile(
        "Czech",
        setOf("ja","ty","on","ona","my","vy","oni","a","nebo","ale","ne","ano","je","jsou","byl","byla","s","bez","pro","od","do","v","na","muj","moje","tvuj","tvoje","laska","srdce","noc","den","vzdy","nikdy","kdy","kde","jak","co","kdo"),
        setOf("jsem","jsi","jeste","protoze","tady","tam","tebe","mne")
    ),
    StageLanguageProfile(
        "Polish",
        setOf("ja","ty","on","ona","my","wy","oni","i","lub","ale","nie","tak","jest","sa","byl","byla","z","bez","dla","od","do","w","na","moj","moja","twoj","twoja","milosc","serce","noc","dzien","zawsze","nigdy","kiedy","gdzie","jak","co","kto"),
        setOf("jestem","jestes","jeszcze","dlaczego","tutaj","tam","ciebie","mnie")
    ),
    StageLanguageProfile(
        "Esperanto",
        setOf("mi","vi","li","si","ni","ili","kaj","au","sed","ne","jes","estas","estis","kun","sen","por","de","al","en","sur","mia","via","amo","koro","nokto","tago","ciam","neniam","kiam","kie","kiel","kio","kiu"),
        setOf("ankau","tamen","hodiau","morgau","eble","volas")
    ),
    StageLanguageProfile(
        "Filipino / Tagalog",
        setOf("ako","ikaw","siya","kami","tayo","kayo","sila","ang","ng","mga","at","o","pero","hindi","oo","ay","sa","para","mula","may","wala","ko","mo","niya","natin","pagibig","puso","gabi","araw","lagi","kailanman","kapag","saan","paano","ano","sino"),
        setOf("mahal","mahalin","bakit","dito","doon","aking","iyong")
    ),
    StageLanguageProfile(
        "Breton",
        setOf("me","te","eñ","hi","ni","c'hwi","int","ha","pe","met","ket","ya","eo","gant","hep","evit","eus","da","e","war","ma","da","karantez","kalon","noz","deiz","bepred","biken","pa","pelec'h","penaos","petra","piv"),
        setOf("amañ","aze","rak","c'hoazh")
    ),
    StageLanguageProfile(
        "Vietnamese",
        setOf("toi","ban","anh","em","chung","va","hoac","nhung","khong","co","la","cua","cho","voi","tu","trong","tren","mot","nay","do","yeu","tim","dem","ngay","luon","khongbao","khi","dau","sao","gi","ai"),
        setOf("minh","chungta","nguoi","tinhyeu","bao gio")
    ),
    StageLanguageProfile(
        "Uzbek",
        setOf("men","sen","u","biz","siz","ular","va","yoki","lekin","emas","ha","bir","bu","bilan","uchun","dan","ga","ichida","ustida","mening","sening","sevgi","yurak","tun","kun","doim","hech","qachon","qayerda","qanday","nima","kim"),
        setOf("sevaman","nega","hozir","yana","faqat")
    )
)

private fun detectStageLanguage(text: String): String {
    val raw = text.lowercase(Locale.ROOT)
    val letters = raw.filter { it.isLetter() }
    if (letters.isEmpty()) return "English"

    fun countRange(start: Int, end: Int): Int = letters.count { it.code in start..end }
    fun ratio(count: Int): Double = count.toDouble() / letters.length.coerceAtLeast(1)

    val hangul = countRange(0xAC00, 0xD7AF) + countRange(0x1100, 0x11FF)
    if (ratio(hangul) > 0.18) return "Korean"

    val kana = countRange(0x3040, 0x30FF)
    val han = countRange(0x4E00, 0x9FFF)
    if (ratio(kana) > 0.05) return "Japanese"
    if (ratio(han) > 0.18) return "Chinese"

    val greek = countRange(0x0370, 0x03FF)
    if (ratio(greek) > 0.18) return "Greek"

    val georgian = countRange(0x10A0, 0x10FF) + countRange(0x2D00, 0x2D2F)
    if (ratio(georgian) > 0.18) return "Georgian"

    val gujarati = countRange(0x0A80, 0x0AFF)
    if (ratio(gujarati) > 0.18) return "Gujarati"

    val telugu = countRange(0x0C00, 0x0C7F)
    if (ratio(telugu) > 0.18) return "Telugu"

    val devanagari = countRange(0x0900, 0x097F)
    if (ratio(devanagari) > 0.18) return "Hindi"

    val arabic = countRange(0x0600, 0x06FF) + countRange(0x0750, 0x077F)
    if (ratio(arabic) > 0.18) {
        // Persian has several letters that standard Arabic does not use.
        if (raw.any { it in setOf('پ','چ','ژ','گ','ک','ی') }) return "Farsi / Persian"
        val normalizedArabic = raw.replace(Regex("[^\\p{L}]+"), " ")
        val tunisianHints = setOf("شنوة","علاش","برشة","توا","هكا","هاذي","موش","باش","نحب","عندي")
        if (normalizedArabic.split(' ').count { it in tunisianHints } >= 2) return "Arabic Tunisian"
        return "Arabic"
    }

    val cyrillic = countRange(0x0400, 0x04FF)
    if (ratio(cyrillic) > 0.18) {
        if (raw.any { it in setOf('ї','є','ґ') }) return "Ukrainian"
        if (raw.any { it in setOf('ә','ғ','қ','ұ','һ','і') }) return "Kazakh"
        val cyrWords = raw.replace(Regex("[^\\p{L}]+"), " ").split(' ').filter { it.length > 1 }
        val tajikHints = setOf("ман","ту","ӯ","мо","шумо","онҳо","ва","не","аст","ҳаст","барои","бо","аз","дар","дил","ишқ","шаб","рӯз","ҳамеша","ҳеҷ")
        if (cyrWords.count { it in tajikHints } >= 3 || raw.any { it in setOf('ҷ','ҳ','ӯ','қ','ғ','ӣ') }) return "Tajik"
        val ukrainianHints = setOf("я","ти","він","вона","ми","ви","вони","і","але","не","так","є","був","була","з","без","для","від","до","у","на","мій","твій","кохання","серце","ніч","день","завжди","ніколи")
        if (cyrWords.count { it in ukrainianHints } >= 3) return "Ukrainian"
        val kyrgyzHints = setOf("мен","сен","ал","биз","силер","алар","жана","же","бирок","эмес","ооба","бир","бул","менен","үчүн","жүрөк","сүйүү","түн","күн","дайыма")
        if (cyrWords.count { it in kyrgyzHints } >= 3) return "Kyrgyz"
        val kazakhHints = setOf("мен","сен","ол","біз","сіз","олар","және","немесе","бірақ","емес","иә","бір","бұл","менен","үшін","жүрек","махаббат","түн","күн","әрқашан")
        if (cyrWords.count { it in kazakhHints } >= 3) return "Kazakh"
        return "Russian"
    }

    val words = stageNormalize(raw)
        .split(' ')
        .filter { it.length > 1 }
        .take(500)
    if (words.isEmpty()) return "English"

    fun orthographyBonus(label: String): Double = when (label) {
        "Montenegrin" -> raw.count { it == 'đ' }.coerceAtMost(3) * 2.0 + raw.count { it == 'ć' }.coerceAtMost(3) * 0.7
        "Czech" -> raw.count { it in "řěůťďň" }.coerceAtMost(5) * 1.8
        "Polish" -> raw.count { it in "ąćęłńóśźż" }.coerceAtMost(5) * 1.5
        "German" -> raw.count { it in "äöüß" }.coerceAtMost(5) * 1.5
        "Spanish" -> raw.count { it in "ñ¿¡" }.coerceAtMost(5) * 1.5
        "Portuguese / Brazilian Portuguese" -> raw.count { it in "ãõ" }.coerceAtMost(5) * 1.8
        "French" -> raw.count { it in "œç" }.coerceAtMost(5) * 1.5
        "Turkish" -> raw.count { it in "ğış" }.coerceAtMost(5) * 1.8
        "Swedish" -> raw.count { it in "åäö" }.coerceAtMost(5) * 1.5
        "Esperanto" -> raw.count { it in "ĉĝĥĵŝŭ" }.coerceAtMost(5) * 2.0
        "Vietnamese" -> raw.count { it in "ăâđêôơưáàảãạấầẩẫậắằẳẵặéèẻẽẹếềểễệíìỉĩịóòỏõọốồổỗộớờởỡợúùủũụứừửữựýỳỷỹỵ" }.coerceAtMost(8) * 1.4
        else -> 0.0
    }

    val scored = STAGE_LATIN_LANGUAGE_PROFILES
        .map { profile -> profile.label to (stageLanguageProfileScore(words, profile) + orthographyBonus(profile.label)) }
        .sortedByDescending { it.second }
    val best = scored.firstOrNull() ?: return "English"
    val runner = scored.getOrNull(1)?.second ?: 0.0

    // Require several independent clues and a useful margin. If the lyric is too short or
    // internationally worded, English is the conservative fallback and the manual selector remains available.
    if (best.second >= 4.0 && best.second >= runner + 1.25) return best.first

    // Extra rescue for clearly Vietnamese text: diacritics are highly distinctive but stageNormalize removes them.
    val vietnameseMarks = raw.count { it in "ăâđêôơưáàảãạấầẩẫậắằẳẵặéèẻẽẹếềểễệíìỉĩịóòỏõọốồổỗộớờởỡợúùủũụứừửữựýỳỷỹỵ" }
    if (vietnameseMarks >= 3) return "Vietnamese"

    return "English"
}

private fun stageSanitizeInvisibleSeparators(raw: String): String =
    raw.replace("\uFEFF", "").replace("\u200B", "").replace("\u00A0", " ")

private fun stageIgnoreLine(raw: String): Boolean {
    val t = stageSanitizeInvisibleSeparators(raw).trim().replace(Regex("\\s+"), " ")
    if (t.isBlank()) return true
    if (t.matches(Regex("^[\\-_=*~.·•:;|/\\\\()\\[\\]{}<>]+$"))) return true
    val bare = t
        .trim('(', ')', '[', ']', '{', '}', '<', '>', '-', '_', '*', '.', ':', ';')
        .trim()
        .lowercase(Locale.ROOT)
        .replace(Regex("\\s+"), " ")
    if (bare.isBlank()) return true
    if (bare.matches(Regex("^(x\\s*)?[2-9]\\s*x?$"))) return true
    val structural = Regex(
        "^(ref\\.?|refren|refrain|chorus|coro|rit\\.?|ritornello|estribillo|estribilho|refrão|refrao|" +
        "verse|verso|strofa|estrofa|strophe|couplet|bridge|puente|ponte|intro|outro|solo|instrumental|" +
        "interlude|interludio|pre[ -]?chorus|post[ -]?chorus|hook|coda)(\\s*[:.-]?\\s*(x?\\s*[2-9]|[2-9]\\s*x))?$",
        RegexOption.IGNORE_CASE
    )
    return structural.matches(bare)
}

private fun stageTokenClose(aRaw: String, bRaw: String): Boolean {
    val a = stageNormalize(aRaw)
    val b = stageNormalize(bRaw)
    if (a == b) return true
    if (a.length < 3 || b.length < 3) return false
    if (a.startsWith(b) || b.startsWith(a)) return minOf(a.length, b.length) >= 4

    // Tiny Levenshtein distance for Polish-ear cognates:
    // nasim/naszym, tako/tak, druze/druże, etc.
    val prev = IntArray(b.length + 1) { it }
    val cur = IntArray(b.length + 1)
    for (i in 1..a.length) {
        cur[0] = i
        for (j in 1..b.length) {
            val cost = if (a[i - 1] == b[j - 1]) 0 else 1
            cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
        }
        for (j in prev.indices) prev[j] = cur[j]
    }
    val dist = prev[b.length]
    val limit = when {
        maxOf(a.length, b.length) <= 4 -> 1
        maxOf(a.length, b.length) <= 7 -> 2
        else -> 3
    }
    return dist <= limit
}

private fun stageLineMatchScore(heard: String, expected: String): Double {
    val h = stageNormalize(heard)
    val e = stageNormalize(expected)
    if (h.length < 3 || e.length < 3) return 0.0
    if (h == e) return 1.0
    if (h.contains(e) || e.contains(h)) {
        val short = minOf(h.length, e.length)
        val long = maxOf(h.length, e.length)
        if (short >= 7) return 0.82 + 0.18 * short.toDouble() / long
    }

    val hw = h.split(' ').filter { it.length > 1 }
    val ew = e.split(' ').filter { it.length > 1 }
    if (hw.isEmpty() || ew.isEmpty()) return 0.0

    val used = BooleanArray(hw.size)
    var common = 0
    for (want in ew) {
        val j = hw.indices.firstOrNull { !used[it] && stageTokenClose(hw[it], want) }
        if (j != null) {
            used[j] = true
            common++
        }
    }
    if (common == 0) return 0.0
    val precision = common.toDouble() / hw.size
    val recall = common.toDouble() / ew.size
    val overlap = common.toDouble() / minOf(hw.size, ew.size)
    return 0.45 * overlap + 0.35 * recall + 0.20 * precision
}

private const val VOSK_ENGLISH_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
private const val VOSK_ENGLISH_DIR = "vosk/en-us-small-0.15"
private const val VOSK_POLISH_URL = "https://alphacephei.com/vosk/models/vosk-model-small-pl-0.22.zip"
private const val VOSK_POLISH_DIR = "vosk/pl-small-0.22"


private data class VoskLanguageSpec(
    val label: String,
    val modelName: String,
    val installDir: String,
    val downloadSize: String,
)

private val VOSK_LANGUAGE_SPECS = listOf(
    VoskLanguageSpec("English", "vosk-model-small-en-us-0.15", VOSK_ENGLISH_DIR, "40 MB"),
    VoskLanguageSpec("Indian English", "vosk-model-small-en-in-0.4", "vosk/en-in-small-0.4", "36 MB"),
    VoskLanguageSpec("Chinese", "vosk-model-small-cn-0.22", "vosk/cn-small-0.22", "42 MB"),
    VoskLanguageSpec("Russian", "vosk-model-small-ru-0.22", "vosk/ru-small-0.22", "45 MB"),
    VoskLanguageSpec("French", "vosk-model-small-fr-0.22", "vosk/fr-small-0.22", "41 MB"),
    VoskLanguageSpec("German", "vosk-model-small-de-0.15", "vosk/de-small-0.15", "45 MB"),
    VoskLanguageSpec("Spanish", "vosk-model-small-es-0.42", "vosk/es-small-0.42", "39 MB"),
    VoskLanguageSpec("Portuguese / Brazilian Portuguese", "vosk-model-small-pt-0.3", "vosk/pt-small-0.3", "31 MB"),
    VoskLanguageSpec("Greek", "vosk-model-el-gr-0.7", "vosk/el-gr-0.7", "1.1 GB"),
    VoskLanguageSpec("Turkish", "vosk-model-small-tr-0.3", "vosk/tr-small-0.3", "35 MB"),
    VoskLanguageSpec("Vietnamese", "vosk-model-small-vn-0.4", "vosk/vn-small-0.4", "32 MB"),
    VoskLanguageSpec("Italian", "vosk-model-small-it-0.22", "vosk/it-small-0.22", "48 MB"),
    VoskLanguageSpec("Dutch", "vosk-model-small-nl-0.22", "vosk/nl-small-0.22", "39 MB"),
    VoskLanguageSpec("Catalan", "vosk-model-small-ca-0.4", "vosk/ca-small-0.4", "42 MB"),
    VoskLanguageSpec("Arabic", "vosk-model-ar-mgb2-0.4", "vosk/ar-mgb2-0.4", "318 MB"),
    VoskLanguageSpec("Arabic Tunisian", "vosk-model-small-ar-tn-0.1-linto", "vosk/ar-tn-small-0.1-linto", "158 MB"),
    VoskLanguageSpec("Farsi / Persian", "vosk-model-small-fa-0.42", "vosk/fa-small-0.42", "53 MB"),
    VoskLanguageSpec("Filipino / Tagalog", "vosk-model-tl-ph-generic-0.6", "vosk/tl-ph-generic-0.6", "320 MB"),
    VoskLanguageSpec("Ukrainian", "vosk-model-small-uk-v3-nano", "vosk/uk-v3-nano", "73 MB"),
    VoskLanguageSpec("Kazakh", "vosk-model-small-kz-0.42", "vosk/kz-small-0.42", "58 MB"),
    VoskLanguageSpec("Swedish", "vosk-model-small-sv-rhasspy-0.15", "vosk/sv-small-rhasspy-0.15", "289 MB"),
    VoskLanguageSpec("Japanese", "vosk-model-small-ja-0.22", "vosk/ja-small-0.22", "48 MB"),
    VoskLanguageSpec("Esperanto", "vosk-model-small-eo-0.42", "vosk/eo-small-0.42", "42 MB"),
    VoskLanguageSpec("Hindi", "vosk-model-small-hi-0.22", "vosk/hi-small-0.22", "42 MB"),
    VoskLanguageSpec("Czech", "vosk-model-small-cs-0.4-rhasspy", "vosk/cs-small-0.4-rhasspy", "44 MB"),
    VoskLanguageSpec("Polish", "vosk-model-small-pl-0.22", VOSK_POLISH_DIR, "50 MB"),
    VoskLanguageSpec("Uzbek", "vosk-model-small-uz-0.22", "vosk/uz-small-0.22", "49 MB"),
    VoskLanguageSpec("Korean", "vosk-model-small-ko-0.22", "vosk/ko-small-0.22", "82 MB"),
    VoskLanguageSpec("Breton", "vosk-model-br-0.8", "vosk/br-0.8", "70 MB"),
    VoskLanguageSpec("Gujarati", "vosk-model-small-gu-0.42", "vosk/gu-small-0.42", "100 MB"),
    VoskLanguageSpec("Tajik", "vosk-model-small-tg-0.22", "vosk/tg-small-0.22", "50 MB"),
    VoskLanguageSpec("Telugu", "vosk-model-small-te-0.42", "vosk/te-small-0.42", "58 MB"),
    VoskLanguageSpec("Kyrgyz", "vosk-model-small-ky-0.42", "vosk/ky-small-0.42", "49 MB"),
    VoskLanguageSpec("Georgian", "vosk-model-small-ka-0.42", "vosk/ka-small-0.42", "45 MB"),
)

private val VOSK_LANGUAGE_BY_LABEL = VOSK_LANGUAGE_SPECS.associateBy { it.label }
private const val MONTENEGRIN_DOWNLOAD_SIZE = "104 MB"
private fun voskModelUrl(spec: VoskLanguageSpec) = "https://alphacephei.com/vosk/models/${spec.modelName}.zip"
private val CECIL_GENERIC_ENGLISH_WORDS = setOf(
    "a", "an", "the", "and", "or", "but", "if", "then", "than", "so",
    "i", "you", "he", "she", "it", "we", "they", "me", "my", "your", "his", "her", "our", "their",
    "this", "that", "these", "those", "what", "when", "where", "who", "why", "how",
    "is", "are", "am", "was", "were", "be", "been", "being", "do", "does", "did",
    "have", "has", "had", "will", "would", "can", "could", "should", "may", "might", "must",
    "in", "on", "at", "to", "of", "for", "from", "with", "without", "by", "as",
    "not", "no", "yes", "let"
).map(::stageNormalize).toSet()

private fun cecilEditDistance(a: String, b: String): Int {
    if (a == b) return 0
    if (a.isEmpty()) return b.length
    if (b.isEmpty()) return a.length
    val prev = IntArray(b.length + 1) { it }
    val cur = IntArray(b.length + 1)
    for (i in 1..a.length) {
        cur[0] = i
        for (j in 1..b.length) {
            val cost = if (a[i - 1] == b[j - 1]) 0 else 1
            cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
        }
        for (j in prev.indices) prev[j] = cur[j]
    }
    return prev[b.length]
}

private fun cecilTailWordMatchesExpected(gotRaw: String, expectedRaw: String): Boolean {
    val got = stageNormalize(gotRaw).replace(" ", "")
    val expected = stageNormalize(expectedRaw).replace(" ", "")
    if (got == expected) return true
    if (expected.length < 4 || got.length < 3) return false

    // Cecil key #2: tolerate small Vosk stage-noise ONLY on the newly arrived tail
    // against words from NEXT. Examples: moonl->moon, astars->stars, jupter->jupiter.
    if (got.contains(expected) && got.length - expected.length <= 2) return true
    if (expected.contains(got) && expected.length - got.length <= 1) return true

    val maxLen = maxOf(got.length, expected.length)
    val limit = when {
        maxLen <= 5 -> 1
        maxLen <= 8 -> 2
        else -> 2
    }
    return kotlin.math.abs(got.length - expected.length) <= limit &&
        cecilEditDistance(got, expected) <= limit
}

private fun cecilNextLineAdvanceReady(heardRaw: String, currentRaw: String, nextRaw: String?): Boolean {
    if (nextRaw.isNullOrBlank()) return false
    val heardWords = stageNormalize(heardRaw).split(' ').filter { it.length > 1 }
    val currentWords = stageNormalize(currentRaw).split(' ').filter { it.length > 1 }
    val nextWords = stageNormalize(nextRaw).split(' ').filter { it.length > 1 }
    if (heardWords.isEmpty() || nextWords.isEmpty()) return false

    // IMPORTANT: heardRaw is the NEW Vosk tail, never the cumulative hypothesis.
    val matchedNext = nextWords.filter { want ->
        heardWords.any { got -> cecilTailWordMatchesExpected(got, want) }
    }.distinct()
    if (matchedNext.isEmpty()) return false

    // KEY #2 is intentionally one-way: fuzzy tolerance is ONLY tail -> NEXT.
    // Do not use fuzzy matching to decide whether a NEXT word is shared with CURRENT;
    // otherwise pairs like CURRENT "sing" / NEXT "spring" become falsely "shared".
    fun sharedWithCurrent(word: String): Boolean {
        val normalizedWord = stageNormalize(word)
        return currentWords.any { cur -> stageNormalize(cur) == normalizedWord }
    }

    fun specific(word: String): Boolean =
        word.length >= 4 &&
        word !in WHISPER_GENERIC_WORDS &&
        word !in CECIL_GENERIC_ENGLISH_WORDS &&
        !sharedWithCurrent(word)

    // Cecil key #1: one characteristic word that arrived NOW and belongs only to NEXT
    // is enough by itself. The cumulative CURRENT score is deliberately irrelevant.
    if (matchedNext.any(::specific)) return true

    // Generic/common words are never a one-word trigger. Require two independent
    // NEXT hits, with at least one word not shared with CURRENT.
    return matchedNext.size >= 2 && matchedNext.any { !sharedWithCurrent(it) }
}

private fun micGainAmplitude(db: Int): Float = when (db) {
    -5 -> 0.5623413f
    -2 -> 0.7943282f
    0 -> 1.0f
    2 -> 1.2589254f
    5 -> 1.7782794f
    7 -> 2.2387211f
    else -> 1.0f
}

private val WHISPER_GENERIC_WORDS = setOf(
    "i", "a", "ali", "da", "je", "ja", "se", "si", "sam", "smo", "su", "ste",
    "ti", "te", "to", "tu", "u", "na", "ne", "ni", "no", "pa", "po", "za", "od",
    "do", "sa", "s", "mi", "me", "mu", "ga", "joj", "on", "ona", "ono", "ko",
    "kad", "kada", "kao", "sto", "što"
).map(::stageNormalize).toSet()

private fun whisperNoisyExpectedWordMatch(gotRaw: String, expectedRaw: String): Boolean {
    // Whisper key #2: tolerate the kind of tiny-model stage mangling seen live
    // (extra/glued letters, a dropped letter, or a small phonetic spelling error),
    // but ONLY while comparing heard audio with words from NEXT.
    val got = stageNormalize(gotRaw).replace("'", "").replace(" ", "")
    val expected = stageNormalize(expectedRaw).replace("'", "").replace(" ", "")
    if (got == expected) return true
    if (expected.length < 4 || got.length < 4) return false

    // Clear expected core inside a noisy token: sgitarom -> gitarom, vrelae -> vrela.
    if (got.contains(expected) && got.length - expected.length <= 2) return true
    // One dropped edge/inner letter is common, but never let a 3-letter fragment
    // impersonate a 4-letter NEXT word (e.g. and -> hand).
    if (got.length >= 4 && expected.contains(got) && expected.length - got.length <= 1) return true

    // Tiny Whisper often invents one noisy leading consonant while keeping the word core.
    // Example: djena -> zena. Require a strong 3-letter suffix core.
    if (got.length >= 4 && expected.length >= 4 &&
        kotlin.math.abs(got.length - expected.length) <= 1 &&
        got.takeLast(3) == expected.takeLast(3) &&
        cecilEditDistance(got, expected) <= 2) return true

    val maxLen = maxOf(got.length, expected.length)
    val limit = when {
        maxLen <= 5 -> 1
        maxLen <= 8 -> 2
        else -> 2
    }
    return kotlin.math.abs(got.length - expected.length) <= 1 &&
        cecilEditDistance(got, expected) <= limit
}

private fun whisperRecycleSpecificWordMatch(gotRaw: String, expectedRaw: String): Boolean {
    // Recycling V3: NEXT gets looser brakes only for a characteristic word.
    // Tiny Whisper is allowed to damage more of the word, but random garbage still
    // needs a recognizable text core before it can move the lyric cursor.
    if (whisperNoisyExpectedWordMatch(gotRaw, expectedRaw)) return true
    val got = stageNormalize(gotRaw).replace("'", "").replace(" ", "")
    val expected = stageNormalize(expectedRaw).replace("'", "").replace(" ", "")
    if (expected.length < 5 || got.length < 3) return false

    // V2 demanded a 3-letter core. V3 accepts a 2-letter core for longer NEXT words,
    // because live tiny-Whisper often preserves only fragments (e.g. br/ra/ci) while
    // destroying the rest. Shorter words still need the stronger 3-letter core.
    val coreLen = if (expected.length >= 6) 2 else 3
    val sharedCore = expected.windowed(coreLen, 1, partialWindows = false).any { got.contains(it) }
    if (!sharedCore) return false

    val maxLen = maxOf(got.length, expected.length)
    val lengthGap = kotlin.math.abs(got.length - expected.length)
    val editLimit = when {
        maxLen <= 5 -> 2
        maxLen <= 7 -> 3
        maxLen <= 10 -> 4
        else -> 5
    }
    val gapLimit = when {
        maxLen <= 5 -> 2
        maxLen <= 8 -> 3
        else -> 4
    }
    return lengthGap <= gapLimit && cecilEditDistance(got, expected) <= editLimit
}

private fun whisperRecycleCouldBeCurrent(gotRaw: String, currentRaw: String): Boolean {
    // Keep CURRENT ambiguity protection at the older V2 strictness. Deliberately do
    // NOT widen it together with NEXT, otherwise the extra recycling room would cancel
    // itself and v61 would feel unchanged in live use.
    if (whisperNoisyExpectedWordMatch(gotRaw, currentRaw)) return true
    val got = stageNormalize(gotRaw).replace("'", "").replace(" ", "")
    val current = stageNormalize(currentRaw).replace("'", "").replace(" ", "")
    if (current.length < 5 || got.length < 4) return false
    val maxLen = maxOf(got.length, current.length)
    val lengthGap = kotlin.math.abs(got.length - current.length)
    val editLimit = when {
        maxLen <= 6 -> 2
        maxLen <= 9 -> 3
        else -> 4
    }
    val gapLimit = when {
        maxLen <= 6 -> 1
        maxLen <= 9 -> 2
        else -> 3
    }
    return lengthGap <= gapLimit && cecilEditDistance(got, current) <= editLimit
}

private fun whisperNextLineAdvanceReady(heardRaw: String, currentRaw: String, nextRaw: String?): Boolean {
    if (nextRaw.isNullOrBlank()) return false
    val heardWords = stageNormalize(heardRaw).split(' ').filter { it.length > 1 }
    val currentWords = stageNormalize(currentRaw).split(' ').filter { it.length > 1 }
    val nextWords = stageNormalize(nextRaw).split(' ').filter { it.length > 1 }
    if (heardWords.isEmpty() || nextWords.isEmpty()) return false

    // Same safety lesson as Cecil v58: fuzzy tolerance is one-way, heard -> NEXT.
    // CURRENT sharing is exact-normalized only, so harmless near-neighbours do not
    // accidentally cancel a genuine NEXT word.
    fun sharedWithCurrent(word: String): Boolean {
        val normalizedWord = stageNormalize(word).replace("'", "")
        return currentWords.any { cur -> stageNormalize(cur).replace("'", "") == normalizedWord }
    }

    fun specific(word: String): Boolean =
        word.length >= 4 && word !in WHISPER_GENERIC_WORDS && !sharedWithCurrent(word)

    // Whisper key #1 + recycling tier: generic/shared NEXT words keep the old strict
    // matcher; only a characteristic NEXT word gets the extra garbage tolerance.
    val matchedNext = nextWords.filter { want ->
        val isSpecific = specific(want)
        heardWords.any { got ->
            if (!isSpecific) {
                whisperNoisyExpectedWordMatch(got, want)
            } else if (whisperNoisyExpectedWordMatch(got, want)) {
                true // preserve the exact v60 Whisper key
            } else {
                // The looser recycle tier is new. Never use it when this heard garbage
                // can also be explained by CURRENT; ambiguity must HOLD, not jump.
                val looksLikeCurrent = currentWords.any { cur -> whisperRecycleCouldBeCurrent(got, cur) }
                !looksLikeCurrent && whisperRecycleSpecificWordMatch(got, want)
            }
        }
    }.distinct()
    if (matchedNext.isEmpty()) return false

    if (matchedNext.any(::specific)) return true

    // Common words still need two independent NEXT hits; a single "da/je/i/na..."
    // cannot move the highlight by itself.
    return matchedNext.size >= 2 && matchedNext.any { !sharedWithCurrent(it) }
}


// MICRO KEY: identical CURRENT -> NEXT lines need proof of a second sung pass.
// This helper is intentionally dormant for every non-identical pair.
private fun stageDuplicateLinePair(currentRaw: String, nextRaw: String?): Boolean {
    if (nextRaw.isNullOrBlank()) return false
    val current = stageNormalize(currentRaw)
    val next = stageNormalize(nextRaw)
    return current.isNotBlank() && current == next
}

private fun stageDuplicateSequenceCount(
    heardRaw: String,
    expectedRaw: String,
    matcher: (String, String) -> Boolean
): Int {
    val heard = stageNormalize(heardRaw).split(' ').filter { it.length > 1 }
    val expected = stageNormalize(expectedRaw).split(' ').filter { it.length > 1 }
    if (heard.isEmpty() || expected.isEmpty() || heard.size < expected.size) return 0
    var count = 0
    var i = 0
    while (i <= heard.size - expected.size) {
        var ok = true
        for (j in expected.indices) {
            if (!matcher(heard[i + j], expected[j])) {
                ok = false
                break
            }
        }
        if (ok) {
            count++
            i += expected.size // non-overlapping whole-line occurrences only
        } else {
            i++
        }
    }
    return count
}

private const val WHISPER_YU_DIR = "whisper/yu-tiny-int8"
private const val WHISPER_YU_ENCODER_URL = "https://huggingface.co/csukuangfj/sherpa-onnx-whisper-tiny/resolve/main/tiny-encoder.int8.onnx?download=true"
private const val WHISPER_YU_DECODER_URL = "https://huggingface.co/csukuangfj/sherpa-onnx-whisper-tiny/resolve/main/tiny-decoder.int8.onnx?download=true"
private const val WHISPER_YU_TOKENS_URL = "https://huggingface.co/csukuangfj/sherpa-onnx-whisper-tiny/resolve/main/tiny-tokens.txt?download=true"

private fun findInstalledVoskEnglish(context: Context): File? {
    val dir = File(context.filesDir, VOSK_ENGLISH_DIR)
    return dir.takeIf { File(it, "am").isDirectory && File(it, "conf").isDirectory }
}

private fun findInstalledVoskPolish(context: Context): File? {
    val dir = File(context.filesDir, VOSK_POLISH_DIR)
    return dir.takeIf { File(it, "am").isDirectory && File(it, "conf").isDirectory }
}


private fun findInstalledVoskLanguage(context: Context, spec: VoskLanguageSpec): File? {
    val dir = File(context.filesDir, spec.installDir)
    return dir.takeIf { File(it, "am").isDirectory && File(it, "conf").isDirectory }
}

private fun downloadAndInstallVoskLanguage(
    context: Context,
    spec: VoskLanguageSpec,
    onProgress: (Int) -> Unit,
): File {
    findInstalledVoskLanguage(context, spec)?.let { return it }

    val safe = spec.modelName.replace(Regex("[^A-Za-z0-9._-]"), "_")
    val finalDir = File(context.filesDir, spec.installDir)
    val workRoot = File(context.cacheDir, "vosk-install-$safe")
    val zipFile = File(context.cacheDir, "$safe.zip")
    workRoot.deleteRecursively()
    zipFile.delete()
    if (!workRoot.mkdirs()) error("Could not prepare ${spec.label} model folder")

    try {
        val connection = (URL(voskModelUrl(spec)).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 180_000
            instanceFollowRedirects = true
            requestMethod = "GET"
            setRequestProperty("User-Agent", "LyrGig Voice Android")
        }
        try {
            connection.connect()
            if (connection.responseCode !in 200..299) error("Download HTTP ${connection.responseCode}")
            val total = connection.contentLengthLong
            BufferedInputStream(connection.inputStream).use { input ->
                FileOutputStream(zipFile).use { output ->
                    val buffer = ByteArray(128 * 1024)
                    var done = 0L
                    var lastPct = -1
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        if (count == 0) continue
                        output.write(buffer, 0, count)
                        done += count
                        if (total > 0L) {
                            val pct = ((done * 92L) / total).toInt().coerceIn(0, 92)
                            if (pct != lastPct) {
                                lastPct = pct
                                onProgress(pct)
                            }
                        }
                    }
                    output.fd.sync()
                }
            }
        } finally {
            connection.disconnect()
        }

        onProgress(93)
        ZipInputStream(BufferedInputStream(zipFile.inputStream())).use { zis ->
            var entry = zis.nextEntry
            val canonicalRoot = workRoot.canonicalFile
            while (entry != null) {
                val out = File(workRoot, entry.name).canonicalFile
                if (!out.path.startsWith(canonicalRoot.path + File.separator)) error("Unsafe model archive")
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { fos -> zis.copyTo(fos) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        val modelRoot = workRoot.walkTopDown().firstOrNull {
            it.isDirectory && File(it, "am").isDirectory && File(it, "conf").isDirectory
        } ?: error("Downloaded ${spec.label} model is incomplete")

        finalDir.parentFile?.mkdirs()
        finalDir.deleteRecursively()
        if (!modelRoot.renameTo(finalDir)) copyDirectory(modelRoot, finalDir)
        val installed = findInstalledVoskLanguage(context, spec)
            ?: error("${spec.label} model install verification failed")
        onProgress(100)
        return installed
    } catch (e: Exception) {
        if (findInstalledVoskLanguage(context, spec) == null) finalDir.deleteRecursively()
        throw e
    } finally {
        zipFile.delete()
        workRoot.deleteRecursively()
    }
}


private fun clearWhisperYuAfterReinstallOrUpdate(context: Context, prefs: android.content.SharedPreferences) {
    val packageStamp = try {
        context.packageManager.getPackageInfo(context.packageName, 0).lastUpdateTime
    } catch (_: Exception) {
        0L
    }
    if (packageStamp <= 0L) return
    val previousStamp = prefs.getLong("whisper_install_package_stamp", 0L)
    if (previousStamp != 0L && previousStamp != packageStamp) {
        File(context.filesDir, WHISPER_YU_DIR).deleteRecursively()
        File(context.cacheDir, "whisper-yu-install").deleteRecursively()
    }
    prefs.edit().putLong("whisper_install_package_stamp", packageStamp).apply()
}

private fun findInstalledWhisperYu(context: Context): File? {
    val dir = File(context.filesDir, WHISPER_YU_DIR)
    val encoder = File(dir, "tiny-encoder.int8.onnx")
    val decoder = File(dir, "tiny-decoder.int8.onnx")
    val tokens = File(dir, "tiny-tokens.txt")
    return dir.takeIf {
        encoder.isFile && encoder.length() > 8_000_000L &&
        decoder.isFile && decoder.length() > 60_000_000L &&
        tokens.isFile && tokens.length() > 300_000L
    }
}

private fun createWhisperYuRecognizer(modelDir: File): OfflineRecognizer {
    val config = OfflineRecognizerConfig(
        modelConfig = OfflineModelConfig(
            whisper = OfflineWhisperModelConfig(
                encoder = File(modelDir, "tiny-encoder.int8.onnx").absolutePath,
                decoder = File(modelDir, "tiny-decoder.int8.onnx").absolutePath,
                // Croatian is the closest explicit Whisper lane for the shared BCS lyric corpus.
                language = "hr",
                task = "transcribe",
                tailPaddings = 200,
            ),
            tokens = File(modelDir, "tiny-tokens.txt").absolutePath,
            numThreads = 2,
            provider = "cpu",
            modelType = "whisper",
        ),
        decodingMethod = "greedy_search",
    )
    return OfflineRecognizer(config = config)
}

private fun downloadToFile(url: String, out: File, onBytes: (Long, Long) -> Unit) {
    out.parentFile?.mkdirs()
    val part = File(out.parentFile, out.name + ".part")
    part.delete()
    val connection = (URL(url).openConnection() as HttpURLConnection).apply {
        connectTimeout = 20_000
        readTimeout = 120_000
        instanceFollowRedirects = true
        requestMethod = "GET"
        setRequestProperty("User-Agent", "LyrGig Voice Android")
    }
    try {
        connection.connect()
        if (connection.responseCode !in 200..299) error("Download HTTP ${connection.responseCode}")
        val total = connection.contentLengthLong
        var done = 0L
        BufferedInputStream(connection.inputStream).use { input ->
            FileOutputStream(part).use { output ->
                val buffer = ByteArray(1024 * 1024)
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    if (n == 0) continue
                    output.write(buffer, 0, n)
                    done += n
                    onBytes(done, total)
                }
                output.fd.sync()
            }
        }
        if (total > 0L && done != total) error("Incomplete download: $done / $total bytes")
        out.delete()
        if (!part.renameTo(out)) {
            part.copyTo(out, overwrite = true)
            part.delete()
        }
    } finally {
        connection.disconnect()
        part.delete()
    }
}

private fun downloadAndInstallWhisperYu(context: Context, onProgress: (Int) -> Unit): File {
    findInstalledWhisperYu(context)?.let { return it }
    val finalDir = File(context.filesDir, WHISPER_YU_DIR)
    finalDir.mkdirs()
    val parts = listOf(
        Triple(WHISPER_YU_ENCODER_URL, File(finalDir, "tiny-encoder.int8.onnx"), 0),
        Triple(WHISPER_YU_DECODER_URL, File(finalDir, "tiny-decoder.int8.onnx"), 15),
        Triple(WHISPER_YU_TOKENS_URL, File(finalDir, "tiny-tokens.txt"), 95),
    )
    try {
        parts.forEachIndexed { index, (url, file, base) ->
            val span = when (index) { 0 -> 15; 1 -> 80; else -> 5 }
            downloadToFile(url, file) { done, total ->
                val local = if (total > 0) ((done * span) / total).toInt() else 0
                onProgress((base + local).coerceIn(0, 99))
            }
        }
        val installed = findInstalledWhisperYu(context) ?: error("Voice model install verification failed")
        onProgress(100)
        return installed
    } catch (e: Exception) {
        // Delete only partial/bad Whisper files. Cecil is never touched.
        if (findInstalledWhisperYu(context) == null) finalDir.deleteRecursively()
        throw e
    }
}

private fun copyDirectory(source: File, target: File) {
    if (source.isDirectory) {
        if (!target.exists() && !target.mkdirs()) error("Could not create ${target.name}")
        source.listFiles()?.forEach { child -> copyDirectory(child, File(target, child.name)) }
    } else {
        target.parentFile?.mkdirs()
        source.inputStream().use { input -> target.outputStream().use { output -> input.copyTo(output) } }
    }
}

private fun downloadAndInstallVoskEnglish(context: Context, onProgress: (Int) -> Unit): File {
    findInstalledVoskEnglish(context)?.let { return it }

    val finalDir = File(context.filesDir, VOSK_ENGLISH_DIR)
    val workRoot = File(context.cacheDir, "vosk-en-install")
    val zipFile = File(context.cacheDir, "vosk-model-small-en-us-0.15.zip.part")
    workRoot.deleteRecursively()
    zipFile.delete()
    if (!workRoot.mkdirs()) error("Could not prepare model folder")

    try {
        val connection = (URL(VOSK_ENGLISH_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 60_000
            instanceFollowRedirects = true
            requestMethod = "GET"
        }
        connection.connect()
        if (connection.responseCode !in 200..299) error("Download HTTP ${connection.responseCode}")
        val total = connection.contentLengthLong
        BufferedInputStream(connection.inputStream).use { input ->
            FileOutputStream(zipFile).use { output ->
                val buffer = ByteArray(64 * 1024)
                var done = 0L
                var lastPct = -1
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    output.write(buffer, 0, count)
                    done += count
                    if (total > 0L) {
                        val pct = ((done * 100L) / total).toInt().coerceIn(0, 99)
                        if (pct != lastPct) {
                            lastPct = pct
                            onProgress(pct)
                        }
                    }
                }
            }
        }
        connection.disconnect()

        ZipInputStream(BufferedInputStream(zipFile.inputStream())).use { zis ->
            var entry = zis.nextEntry
            val canonicalRoot = workRoot.canonicalFile
            while (entry != null) {
                val out = File(workRoot, entry.name).canonicalFile
                if (!out.path.startsWith(canonicalRoot.path + File.separator)) error("Unsafe model archive")
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { fos -> zis.copyTo(fos) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        val modelRoot = workRoot.walkTopDown().firstOrNull {
            it.isDirectory && File(it, "am").isDirectory && File(it, "conf").isDirectory
        } ?: error("Downloaded English model is incomplete")

        finalDir.parentFile?.mkdirs()
        finalDir.deleteRecursively()
        if (!modelRoot.renameTo(finalDir)) copyDirectory(modelRoot, finalDir)
        if (findInstalledVoskEnglish(context) == null) error("English model install verification failed")
        onProgress(100)
        return finalDir
    } finally {
        zipFile.delete()
        workRoot.deleteRecursively()
    }
}

private fun downloadAndInstallVoskPolish(context: Context, onProgress: (Int) -> Unit): File {
    findInstalledVoskPolish(context)?.let { return it }

    val finalDir = File(context.filesDir, VOSK_POLISH_DIR)
    val workRoot = File(context.cacheDir, "vosk-pl-install")
    val zipFile = File(context.cacheDir, "vosk-model-small-pl-0.22.zip.part")
    workRoot.deleteRecursively()
    zipFile.delete()
    if (!workRoot.mkdirs()) error("Could not prepare model folder")

    try {
        val connection = (URL(VOSK_POLISH_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 60_000
            instanceFollowRedirects = true
            requestMethod = "GET"
        }
        connection.connect()
        if (connection.responseCode !in 200..299) error("Download HTTP ${connection.responseCode}")
        val total = connection.contentLengthLong
        BufferedInputStream(connection.inputStream).use { input ->
            FileOutputStream(zipFile).use { output ->
                val buffer = ByteArray(64 * 1024)
                var done = 0L
                var lastPct = -1
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    output.write(buffer, 0, count)
                    done += count
                    if (total > 0L) {
                        val pct = ((done * 100L) / total).toInt().coerceIn(0, 99)
                        if (pct != lastPct) {
                            lastPct = pct
                            onProgress(pct)
                        }
                    }
                }
            }
        }
        connection.disconnect()

        ZipInputStream(BufferedInputStream(zipFile.inputStream())).use { zis ->
            var entry = zis.nextEntry
            val canonicalRoot = workRoot.canonicalFile
            while (entry != null) {
                val out = File(workRoot, entry.name).canonicalFile
                if (!out.path.startsWith(canonicalRoot.path + File.separator)) error("Unsafe model archive")
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { fos -> zis.copyTo(fos) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        val modelRoot = workRoot.walkTopDown().firstOrNull {
            it.isDirectory && File(it, "am").isDirectory && File(it, "conf").isDirectory
        } ?: error("Downloaded Polish model is incomplete")

        finalDir.parentFile?.mkdirs()
        finalDir.deleteRecursively()
        if (!modelRoot.renameTo(finalDir)) copyDirectory(modelRoot, finalDir)
        if (findInstalledVoskPolish(context) == null) error("Polish model install verification failed")
        onProgress(100)
        return finalDir
    } finally {
        zipFile.delete()
        workRoot.deleteRecursively()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LyrGigApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("giglyrics", Context.MODE_PRIVATE) }
    // One APK, two responsive faces: phone below 600dp, tablet at 600dp and wider.
    val isPhoneLayout = LocalConfiguration.current.screenWidthDp < 600
    var rootUri by remember {
        mutableStateOf(prefs.getString("root_uri", null)?.let(Uri::parse))
    }
    var currentUri by remember {
        mutableStateOf(prefs.getString("last_folder_uri", null)?.let(Uri::parse))
    }
    var currentTitle by remember { mutableStateOf("LyrGig") }
    var entries by remember { mutableStateOf(emptyList<Entry>()) }

    var openedText by remember { mutableStateOf<String?>(null) }
    var openedTitle by remember { mutableStateOf("") }
    var openedFileUri by remember { mutableStateOf<Uri?>(null) }

    // NEXT LINE: deliberately simple, linear stage tracker.
    // MIC intent starts OFF. Once the user turns LYR SYNC ON, keep that intent
    // while browsing: the recorder itself is disposed whenever openedText == null,
    // and it starts again automatically when a song is opened. Manual OFF stays OFF.
    var stageMicOn by remember { mutableStateOf(false) }
    var stageLineIndex by remember { mutableIntStateOf(-1) }
    var stageRestartToken by remember { mutableIntStateOf(0) }

    // Vosk stage engine. The APK carries only the engine. English is downloaded
    // once after first launch, then stays fully offline in app-private storage.
    var voskEnglishModel by remember { mutableStateOf<Model?>(null) }
    var voskModelLoading by remember { mutableStateOf(false) }
    var voskModelProgress by remember { mutableIntStateOf(0) }
    var voskModelError by remember { mutableStateOf<String?>(null) }
    var voskActiveLanguage by remember { mutableStateOf<String?>(null) }
    // Tracks live Cecil/Vosk recognizers so a language hot-swap never closes a Model
    // while an AudioRecord/Recognizer thread is still using it.
    val cecilActiveRecognizers = remember { AtomicInteger(0) }
    val voskInstalled = remember { mutableStateMapOf<String, Boolean>() }
    val voskLanguageLoading = remember { mutableStateMapOf<String, Boolean>() }
    val voskLanguageProgress = remember { mutableStateMapOf<String, Int>() }
    val voskLanguageError = remember { mutableStateMapOf<String, String?>() }
    // Cecil stays untouched for English. Whisper tiny is a side-car listener only for EX-YU.
    var whisperYuRecognizer by remember { mutableStateOf<OfflineRecognizer?>(null) }
    var whisperYuLoading by remember { mutableStateOf(false) }
    var whisperYuProgress by remember { mutableIntStateOf(0) }
    var whisperYuError by remember { mutableStateOf<String?>(null) }

    // Up to three user-visible LIVE languages may stay hot in RAM.
    // Montenegrin counts as ONE slot; Polish is only its hidden engine.
    val maxLiveLanguages = 3
    var stageWarmupDone by remember { mutableStateOf(false) }

    var showSetup by remember { mutableStateOf(false) }
    var showBb2 by remember { mutableStateOf(false) }
    var bb2Snapshot by remember { mutableStateOf("") }
    var showCpuMonitor by remember { mutableStateOf(false) }
    var cpuReading by remember { mutableStateOf<BB2.CpuReading?>(null) }
    var showTxtRenamer by remember { mutableStateOf(false) }
    var showLyricsCleanup by remember { mutableStateOf(false) }
    var showLyricsCleanupUpdateConfirm by remember { mutableStateOf(false) }
    var lyricsCleanupBusy by remember { mutableStateOf(false) }
    var lyricsCleanupStatus by remember { mutableStateOf("") }
    var lyricsCleanupSummary by remember { mutableStateOf<LyricsCleanupEngine.Summary?>(null) }
    var lyricsCleanupChoices by remember { mutableStateOf<List<LyricsCleanupEngine.AmbiguousSong>>(emptyList()) }
    var lyricsCleanupChoiceBusy by remember { mutableStateOf(false) }
    var showToolsPopup by remember { mutableStateOf(false) }
    var showSongLanguagePopup by remember { mutableStateOf(false) }
    var txtRenameMode by remember { mutableStateOf<TxtRenameMode?>(null) }
    var txtRenamerPreview by remember { mutableStateOf<List<RenamerPreviewItem>>(emptyList()) }
    var txtRenamerBusy by remember { mutableStateOf(false) }
    var txtRenamerStatus by remember { mutableStateOf("") }
    var txtRenamerUndo by remember { mutableStateOf<List<RenamerPreviewItem>>(emptyList()) }
    var stageLanguage by remember { mutableStateOf(prefs.getString("stage_language", "English") ?: "English") }

    var fontSize by remember {
        mutableFloatStateOf(prefs.getFloat("font_size", 28f))
    }
    var listFontSize by remember {
        mutableFloatStateOf(prefs.getFloat("list_font_size", 23f))
    }
    val initialMicGainDb = remember {
        // One-time migration for the new six-step scale: v87 starts at the new neutral default.
        if (!prefs.getBoolean("mic_gain_scale_v2_initialized", false)) {
            prefs.edit()
                .putBoolean("mic_gain_scale_v2_initialized", true)
                .putInt("mic_gain_db", 0)
                .apply()
            0
        } else {
            prefs.getInt("mic_gain_db", 0).takeIf { it in setOf(-5, -2, 0, 2, 5, 7) } ?: 0
        }
    }
    val micGainDbRef = remember { AtomicInteger(initialMicGainDb) }
    var micGainDb by remember { mutableIntStateOf(initialMicGainDb) }
    val micClipUntilMs = remember { AtomicLong(0L) }
    var micClipping by remember { mutableStateOf(false) }
    var stageCleanOn by remember { mutableStateOf(prefs.getBoolean("stage_clean_on", false)) }

    fun setStageClean(on: Boolean) {
        stageCleanOn = on
        prefs.edit().putBoolean("stage_clean_on", on).apply()
    }

    LaunchedEffect(Unit) {
        while (true) {
            micClipping = System.currentTimeMillis() < micClipUntilMs.get()
            delay(100)
        }
    }

    fun setMicGainDb(db: Int) {
        if (db !in setOf(-5, -2, 0, 2, 5, 7)) return
        micGainDb = db
        micGainDbRef.set(db)
        prefs.edit().putInt("mic_gain_db", db).apply()
    }

    var searchQuery by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf(emptyList<Entry>()) }
    var searching by remember { mutableStateOf(false) }

    var webSearchQuery by remember { mutableStateOf("") }
    var webSearchUrl by remember { mutableStateOf<String?>(null) }
    var showWebSearch by remember { mutableStateOf(false) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var extractedLyrics by remember { mutableStateOf<String?>(null) }
    var extractedTitle by remember { mutableStateOf("") }
    var autoExtractActive by remember { mutableStateOf(false) }
    var autoExtractTriedText by remember { mutableStateOf(false) }
    var autoCandidateOpened by remember { mutableStateOf(false) }
    var candidateChoices by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var candidateChoiceQuery by remember { mutableStateOf("") }
    var downloadedLyricsUri by remember { mutableStateOf<Uri?>(null) }
    var songIndex by remember { mutableStateOf(emptyList<Entry>()) }
    var folderCache by remember { mutableStateOf<Map<String, List<Entry>>>(emptyMap()) }
    var indexReady by remember { mutableStateOf(false) }
    var indexGeneration by remember { mutableIntStateOf(0) }

    // First-run / new-file conversion prompt. This stays off the stage UI and only
    // appears when there are newly added supported documents without a .txt twin.
    var showConvertPrompt by remember { mutableStateOf(false) }
    var convertPromptFirstRun by remember { mutableStateOf(false) }
    var pendingConvertibleFiles by remember { mutableStateOf<List<ConversionCandidate>>(emptyList()) }
    var convertingFiles by remember { mutableStateOf(false) }
    var conversionStatus by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()

    val backHistory = remember { mutableStateListOf<NavLocation>() }
    val forwardHistory = remember { mutableStateListOf<NavLocation>() }

    fun listFolder(uri: Uri) {
        val cached = folderCache[uri.toString()]
        if (cached != null) {
            entries = cached
            currentUri = uri
            openedText = null
            openedTitle = ""
            openedFileUri = null
            currentTitle = if (uri == rootUri) "LyrGig" else (
                DocumentFile.fromTreeUri(context, uri)?.name ?: "Folder"
            )
            prefs.edit().putString("last_folder_uri", uri.toString()).apply()
            return
        }

        // Fallback only while the background cache is still being built.
        val folder = DocumentFile.fromTreeUri(context, uri)
        if (folder == null || !folder.isDirectory) return
        currentTitle = folder.name ?: "Folder"
        entries = folder.listFiles()
            .filter { it.isDirectory || (it.isFile && it.name?.lowercase()?.endsWith(".txt") == true) }
            .mapNotNull { f ->
                val n = f.name ?: return@mapNotNull null
                Entry(n, f.uri, f.isDirectory)
            }
            .sortedWith(compareBy<Entry> { !it.isDirectory }.thenBy { it.name.lowercase() })
        currentUri = uri
        openedText = null
        openedTitle = ""
        openedFileUri = null
        prefs.edit().putString("last_folder_uri", uri.toString()).apply()
    }

    fun readText(uri: Uri): String {
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                BufferedReader(InputStreamReader(input)).readText()
            } ?: ""
        } catch (e: Exception) {
            "Ne mogu da otvorim fajl.\n\n${e.message ?: ""}"
        }
    }

    fun currentLocation(): NavLocation? {
        val folder = currentUri ?: return null
        return if (openedText != null && openedFileUri != null) {
            NavLocation(folder, openedFileUri, openedTitle)
        } else {
            NavLocation(folder)
        }
    }

    fun applyLocation(location: NavLocation) {
        searchQuery = ""
        searching = false
        searchResults = emptyList()

        if (currentUri != location.folderUri || entries.isEmpty()) {
            listFolder(location.folderUri)
        } else {
            openedText = null
            openedTitle = ""
            openedFileUri = null
        }

        if (location.fileUri != null) {
            openedFileUri = location.fileUri
            openedTitle = location.fileName ?: "Tekst"
            openedText = readText(location.fileUri)
        }
    }

    fun navigateTo(location: NavLocation) {
        currentLocation()?.let { backHistory.add(it) }
        forwardHistory.clear()
        applyLocation(location)
    }

    fun goBack() {
        if (showWebSearch) {
            showWebSearch = false
            extractedLyrics = null
            webSearchUrl = null
            autoExtractActive = false
            autoExtractTriedText = false
            autoCandidateOpened = false
            candidateChoices = emptyList()
            candidateChoiceQuery = ""
            return
        }
        if (searching) {
            searchQuery = ""
            searching = false
            searchResults = emptyList()
            return
        }
        if (backHistory.isNotEmpty()) {
            currentLocation()?.let { forwardHistory.add(it) }
            val previous = backHistory.removeAt(backHistory.lastIndex)
            applyLocation(previous)
        }
    }

    fun goForward() {
        if (forwardHistory.isNotEmpty()) {
            currentLocation()?.let { backHistory.add(it) }
            val next = forwardHistory.removeAt(forwardHistory.lastIndex)
            applyLocation(next)
        }
    }

    fun goHome() {
        val root = rootUri ?: return
        if (currentUri == root && openedText == null && !searching && !showWebSearch) return
        showWebSearch = false
        extractedLyrics = null
        webSearchUrl = null
        autoExtractActive = false
        autoExtractTriedText = false
        autoCandidateOpened = false
        currentLocation()?.let { backHistory.add(it) }
        forwardHistory.clear()
        searchQuery = ""
        searching = false
        searchResults = emptyList()
        listFolder(root)
    }

    fun normalizeSearchText(value: String): String {
        val decomposed = Normalizer.normalize(value, Normalizer.Form.NFD)
        return decomposed
            .replace("\\p{Mn}+".toRegex(), "")
            .lowercase()
            .replace(".txt", "")
            .replace("[-_]+".toRegex(), " ")
            .replace("\\s+".toRegex(), " ")
            .trim()
    }

    suspend fun buildLibraryIndex(rootUriValue: Uri): LibraryIndex = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(context, rootUriValue)
            ?: return@withContext LibraryIndex(emptyList(), emptyMap())

        val songs = mutableListOf<Entry>()
        val folders = mutableMapOf<String, List<Entry>>()

        fun walk(folder: DocumentFile, path: String) {
            val rawChildren = folder.listFiles()
                .filter { child ->
                    val name = child.name
                    (child.isDirectory && name != LyricsCleanupEngine.LIBRARY_DIR) ||
                        (child.isFile && name?.lowercase()?.endsWith(".txt") == true)
                }

            val children = rawChildren
                .mapNotNull { f ->
                    val name = f.name ?: return@mapNotNull null
                    Entry(name, f.uri, f.isDirectory, path)
                }
                .sortedWith(compareBy<Entry> { !it.isDirectory }.thenBy { it.name.lowercase() })

            folders[folder.uri.toString()] = children

            for (child in rawChildren) {
                val name = child.name ?: continue
                if (child.isDirectory) {
                    if (name == LyricsCleanupEngine.LIBRARY_DIR) continue
                    val childPath = if (path.isBlank()) name else "$path / $name"
                    walk(child, childPath)
                } else if (child.isFile && name.lowercase().endsWith(".txt")) {
                    songs += Entry(name, child.uri, false, path)
                }
            }
        }

        walk(root, "")
        LibraryIndex(
            songs = songs.sortedBy { it.name.lowercase() },
            folders = folders
        )
    }

    fun refreshSongIndex(uri: Uri) {
        val generation = indexGeneration + 1
        indexGeneration = generation
        indexReady = false
        scope.launch {
            val built = buildLibraryIndex(uri)
            if (indexGeneration == generation) {
                songIndex = built.songs
                folderCache = built.folders
                indexReady = true

                // If the user is still on a folder that was opened before caching finished,
                // replace its slow SAF listing with the cached version immediately.
                currentUri?.let { current ->
                    built.folders[current.toString()]?.let { cached ->
                        if (openedText == null) entries = cached
                    }
                }

                if (searchQuery.isNotBlank()) {
                    val q = normalizeSearchText(searchQuery)
                    searchResults = built.songs.filter { normalizeSearchText(it.name).contains(q) }
                }
            }
        }
    }

    fun doSearch(query: String) {
        searchQuery = query
        searching = query.isNotBlank()
        if (!searching) {
            searchResults = emptyList()
            return
        }

        val q = normalizeSearchText(query)
        searchResults = if (indexReady) {
            songIndex.filter { normalizeSearchText(it.name).contains(q) }
        } else {
            emptyList()
        }
    }

    val convertibleExtensions = setOf("pdf", "docx", "rtf", "md", "markdown", "html", "htm", "lyr", "lrc", "srt", "vtt", "odt", "chordpro", "cho", "pro")

    fun baseName(name: String): String = name.substringBeforeLast('.', name).trim()

    fun supportedForConversion(file: DocumentFile): Boolean {
        if (!file.isFile) return false
        val name = file.name ?: return false
        val ext = name.substringAfterLast('.', "").lowercase()
        return ext in convertibleExtensions
    }

    fun scanConvertibleFiles(root: Uri): List<ConversionCandidate> {
        val rootFolder = DocumentFile.fromTreeUri(context, root) ?: return emptyList()
        val pending = mutableListOf<ConversionCandidate>()

        fun walk(folder: DocumentFile) {
            val children = try { folder.listFiles().toList() } catch (_: Exception) { emptyList() }
            val txtBases = children
                .filter { it.isFile && it.name?.lowercase()?.endsWith(".txt") == true }
                .mapNotNull { it.name?.let(::baseName)?.lowercase() }
                .toSet()

            for (child in children) {
                if (child.isDirectory) {
                    walk(child)
                } else if (supportedForConversion(child)) {
                    val name = child.name ?: continue
                    if (baseName(name).lowercase() !in txtBases) pending += ConversionCandidate(child, folder)
                }
            }
        }

        walk(rootFolder)
        return pending.sortedBy { it.file.name?.lowercase() ?: "" }
    }

    fun pendingFingerprint(files: List<ConversionCandidate>): String = files
        .map { it.file.uri.toString() }
        .sorted()
        .joinToString("|")
        .hashCode()
        .toString()

    fun stripHtml(raw: String): String = raw
        .replace(Regex("(?is)<script.*?</script>"), " ")
        .replace(Regex("(?is)<style.*?</style>"), " ")
        .replace(Regex("(?i)<br\\s*/?>"), "\n")
        .replace(Regex("(?i)</p\\s*>"), "\n\n")
        .replace(Regex("<[^>]+>"), " ")
        .replace("&nbsp;", " ")
        .replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
        .replace(Regex("[ \\t]+\\n"), "\n")
        .replace(Regex("\\n{3,}"), "\n\n")
        .trim()

    fun stripRtf(raw: String): String {
        var t = raw
            .replace(Regex("\\\\par[d]?\\b ?"), "\n")
            .replace(Regex("\\\\line\\b ?"), "\n")
            .replace(Regex("\\\\tab\\b ?"), "\t")
            .replace(Regex("\\\\'[0-9a-fA-F]{2}")) { m ->
                try { byteArrayOf(m.value.substring(2).toInt(16).toByte()).toString(Charsets.ISO_8859_1) }
                catch (_: Exception) { "" }
            }
        t = t.replace(Regex("\\\\[a-zA-Z]+-?\\d* ?"), "")
            .replace("{", "")
            .replace("}", "")
            .replace(Regex("\\n{3,}"), "\n\n")
        return t.trim()
    }

    fun stripTimedText(raw: String): String {
        return raw
            .replace("\uFEFF", "")
            // LRC timestamps, including multiple timestamps at the start of one line.
            .replace(Regex("(?m)^(?:\\[\\d{1,3}:\\d{2}(?:[.:]\\d{1,3})?\\]\\s*)+"), "")
            // Common LRC metadata tags are not lyrics.
            .replace(Regex("(?im)^\\[(?:ar|ti|al|by|offset|re|ve|length):.*?\\]\\s*$"), "")
            // SRT/VTT cue numbers and timing lines.
            .replace(Regex("(?m)^\\s*\\d+\\s*$"), "")
            .replace(Regex("(?m)^\\s*(?:\\d{1,2}:)?\\d{2}:\\d{2}[.,]\\d{3}\\s*-->\\s*(?:\\d{1,2}:)?\\d{2}:\\d{2}[.,]\\d{3}.*$"), "")
            .replace(Regex("(?im)^WEBVTT.*$"), "")
            .replace(Regex("(?im)^NOTE(?:\\s.*)?$"), "")
            .replace(Regex("<[^>]+>"), "")
            .replace(Regex("[ \\t]+\\n"), "\n")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()
    }

    fun stripChordPro(raw: String): String {
        return raw
            // Remove ChordPro control/directive lines while preserving lyric and chord lines.
            .replace(Regex("(?m)^\\s*\\{[^}]+}\\s*$"), "")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()
    }

    fun extractOdtText(uri: Uri): String {
        context.contentResolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (entry.name == "content.xml") {
                        val out = ByteArrayOutputStream()
                        val buf = ByteArray(8192)
                        while (true) {
                            val n = zip.read(buf)
                            if (n <= 0) break
                            out.write(buf, 0, n)
                        }
                        val xml = out.toString(Charsets.UTF_8.name())
                        return xml
                            .replace(Regex("(?i)</text:p>"), "\n")
                            .replace(Regex("(?i)</text:h>"), "\n")
                            .replace(Regex("(?i)<text:line-break[^>]*/>"), "\n")
                            .replace(Regex("(?i)<text:tab[^>]*/>"), "\t")
                            .replace(Regex("<[^>]+>"), "")
                            .replace("&amp;", "&")
                            .replace("&lt;", "<")
                            .replace("&gt;", ">")
                            .replace("&quot;", "\"")
                            .replace("&apos;", "'")
                            .replace(Regex("\\n{3,}"), "\n\n")
                            .trim()
                    }
                    entry = zip.nextEntry
                }
            }
        }
        return ""
    }

    fun extractDocxText(uri: Uri): String {
        context.contentResolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (entry.name == "word/document.xml") {
                        val out = ByteArrayOutputStream()
                        val buf = ByteArray(8192)
                        while (true) {
                            val n = zip.read(buf)
                            if (n <= 0) break
                            out.write(buf, 0, n)
                        }
                        val xml = out.toString(Charsets.UTF_8.name())
                        return xml
                            .replace(Regex("(?i)</w:p>"), "\n")
                            .replace(Regex("(?i)<w:tab[^>]*/>"), "\t")
                            .replace(Regex("<[^>]+>"), "")
                            .replace("&amp;", "&")
                            .replace("&lt;", "<")
                            .replace("&gt;", ">")
                            .replace("&quot;", "\"")
                            .replace("&apos;", "'")
                            .replace(Regex("\\n{3,}"), "\n\n")
                            .trim()
                    }
                    entry = zip.nextEntry
                }
            }
        }
        return ""
    }

    fun extractSupportedFile(file: DocumentFile): String {
        val name = file.name ?: return ""
        val ext = name.substringAfterLast('.', "").lowercase()
        return try {
            when (ext) {
                "pdf" -> {
                    context.contentResolver.openInputStream(file.uri)?.use { input ->
                        PDDocument.load(input).use { doc -> PDFTextStripper().getText(doc).trim() }
                    }.orEmpty()
                }
                "docx" -> extractDocxText(file.uri)
                "odt" -> extractOdtText(file.uri)
                "rtf" -> context.contentResolver.openInputStream(file.uri)?.bufferedReader()?.use { stripRtf(it.readText()) }.orEmpty()
                "html", "htm" -> context.contentResolver.openInputStream(file.uri)?.bufferedReader()?.use { stripHtml(it.readText()) }.orEmpty()
                "md", "markdown", "lyr" -> context.contentResolver.openInputStream(file.uri)?.bufferedReader()?.use { it.readText().trim() }.orEmpty()
                "lrc", "srt", "vtt" -> context.contentResolver.openInputStream(file.uri)?.bufferedReader()?.use { stripTimedText(it.readText()) }.orEmpty()
                "chordpro", "cho", "pro" -> context.contentResolver.openInputStream(file.uri)?.bufferedReader()?.use { stripChordPro(it.readText()) }.orEmpty()
                else -> ""
            }
        } catch (_: Exception) {
            ""
        }
    }

    suspend fun convertFiles(files: List<ConversionCandidate>): Pair<Int, Int> = withContext(Dispatchers.IO) {
        var converted = 0
        var failed = 0
        files.forEach { candidate ->
            val source = candidate.file
            try {
                val text = extractSupportedFile(source).trim()
                val parent = candidate.parent
                if (text.isBlank() || !parent.canWrite()) {
                    failed++
                } else {
                    val targetName = baseName(source.name ?: "Lyrics") + ".txt"
                    val existing = parent.listFiles().firstOrNull { it.isFile && it.name.equals(targetName, true) }
                    val target = existing ?: parent.createFile("text/plain", targetName)
                    if (target == null) {
                        failed++
                    } else {
                        context.contentResolver.openOutputStream(target.uri, "wt")?.use { out ->
                            out.write(text.toByteArray(Charsets.UTF_8))
                        } ?: throw IllegalStateException("Could not write")
                        converted++
                    }
                }
            } catch (_: Exception) {
                failed++
            }
        }
        converted to failed
    }

    fun checkForConvertibleFiles(root: Uri, firstRun: Boolean = false) {
        scope.launch {
            val pending = withContext(Dispatchers.IO) { scanConvertibleFiles(root) }
            pendingConvertibleFiles = pending
            if (pending.isEmpty()) {
                prefs.edit().putString("convert_pending_fingerprint", "").apply()
                return@launch
            }
            val fingerprint = pendingFingerprint(pending)
            val dismissed = prefs.getString("convert_pending_fingerprint", "")
            if (firstRun || fingerprint != dismissed) {
                convertPromptFirstRun = firstRun
                showConvertPrompt = true
            }
        }
    }

    fun ensureDownloadedLyricsFolder(root: Uri): Uri? {
        return try {
            val rootFolder = DocumentFile.fromTreeUri(context, root) ?: return null
            val existing = rootFolder.listFiles().firstOrNull {
                it.isDirectory && it.name.equals("Downloaded Lyrics", ignoreCase = true)
            }
            val folder = existing ?: rootFolder.createDirectory("Downloaded Lyrics")
            folder?.uri.also { downloadedLyricsUri = it }
        } catch (_: Exception) {
            null
        }
    }

    fun webSearchUrlFor(query: String, suffix: String): String {
        val encoded = URLEncoder.encode("${query.trim()} $suffix -site:youtube.com -site:youtu.be -site:music.youtube.com", StandardCharsets.UTF_8.toString())
        return "https://www.google.com/search?q=$encoded"
    }

    fun launchWebSearch(query: String) {
        val clean = query.trim()
        if (clean.isBlank()) return
        webSearchQuery = clean
        extractedLyrics = null
        extractedTitle = clean

        // Step 1: automatic extraction. Search stays invisible while LyrGig tries
        // the first useful text result. If that fails, the same WebView becomes
        // Step 2: the visible in-app web fallback.
        autoExtractActive = true
        autoExtractTriedText = false
        autoCandidateOpened = false
        candidateChoices = emptyList()
        candidateChoiceQuery = clean
        webSearchUrl = webSearchUrlFor(clean, "lyrics")
        showWebSearch = true
    }

    fun lyricsExtractionJs(): String = """

            (function() {
              function clean(t) {
                return (t || '')
                  .replace(/\\r/g, '')
                  .replace(/[ \\t]+\\n/g, '\\n')
                  .replace(/\\n[ \\t]+/g, '\\n')
                  .replace(/\\n{3,}/g, '\\n\\n')
                  .trim();
              }
              const specific = [
                '[data-lyrics-container="true"]',
                '.lyrics', '#lyrics', '.lyric', '#lyric',
                '[class*="lyrics"]', '[id*="lyrics"]'
              ];
              for (const sel of specific) {
                const nodes = Array.from(document.querySelectorAll(sel));
                if (nodes.length) {
                  const t = clean(nodes.map(n => n.innerText).join('\\n'));
                  if (t.length > 120) return t;
                }
              }

              const clone = document.body.cloneNode(true);
              clone.querySelectorAll('script,style,noscript,nav,header,footer,form,button,svg,canvas,iframe,aside').forEach(n => n.remove());
              const candidates = Array.from(clone.querySelectorAll('main,article,section,div,pre'));
              let best = '';
              let bestScore = -1e9;
              for (const el of candidates) {
                const t = clean(el.innerText);
                if (t.length < 120 || t.length > 18000) continue;
                const lines = t.split('\\n').map(x => x.trim()).filter(Boolean);
                if (lines.length < 4) continue;
                const shortLines = lines.filter(x => x.length >= 2 && x.length <= 90).length;
                const veryLong = lines.filter(x => x.length > 180).length;
                const noise = (t.match(/cookie|privacy|sign in|subscribe|advertis|menu|share|facebook|instagram/gi) || []).length;
                const score = shortLines * 5 + lines.length * 2 - veryLong * 8 - noise * 15 + Math.min(t.length, 4000) / 200;
                if (score > bestScore) { bestScore = score; best = t; }
              }
              return best || clean(clone.innerText);
            })();
        """.trimIndent()

    fun applyExtractedResult(web: WebView, result: String?, automatic: Boolean) {
        try {
            val value = if (result == null || result == "null") "" else
                org.json.JSONTokener(result).nextValue() as? String ?: ""

            val cleanedLines = value
                .lines()
                .map { it.trim() }
                .filter { it.isNotBlank() }

            val menuNoise = cleanedLines.count {
                val l = it.lowercase()
                l == "svi tekstovi" ||
                l.startsWith("poslušaj na") ||
                l.startsWith("listen on") ||
                l == "home" ||
                l == "menu" ||
                l == "lyrics" ||
                l == "tekst"
            }

            val usefulLines = cleanedLines.count { it.length in 8..140 }
            val looksLikeLyrics =
                value.length >= 180 &&
                cleanedLines.size >= 6 &&
                usefulLines >= 5 &&
                menuNoise <= 1

            if (!looksLikeLyrics) {
                if (automatic) {
                    // Auto mode failed: leave the current page open as the web fallback.
                    autoExtractActive = false
                    autoCandidateOpened = false
                    Toast.makeText(context, "Auto extract failed — web fallback", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Lyrics not found on this page", Toast.LENGTH_SHORT).show()
                }
            } else {
                extractedLyrics = value
                val pageTitle = web.title.orEmpty()
                    .replace(" - Google Search", "", ignoreCase = true)
                    .trim()
                extractedTitle = if (pageTitle.isNotBlank()) pageTitle else webSearchQuery
                autoExtractActive = false
                autoCandidateOpened = false
            }
        } catch (_: Exception) {
            if (automatic) {
                autoExtractActive = false
                autoCandidateOpened = false
                Toast.makeText(context, "Auto extract failed — web fallback", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Could not extract lyrics", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun extractLyricsFromWeb() {
        val web = webViewRef ?: return
        web.evaluateJavascript(lyricsExtractionJs()) { result ->
            applyExtractedResult(web, result, automatic = false)
        }
    }

    fun saveExtractedLyrics() {
        val text = extractedLyrics?.trim().orEmpty()
        val root = rootUri ?: return
        if (text.isBlank()) return
        val folderUri = downloadedLyricsUri ?: ensureDownloadedLyricsFolder(root)
        val folder = folderUri?.let { DocumentFile.fromTreeUri(context, it) }
        if (folder == null) {
            Toast.makeText(context, "Could not create Downloaded Lyrics", Toast.LENGTH_SHORT).show()
            return
        }
        val base = (if (webSearchQuery.isNotBlank()) webSearchQuery else extractedTitle)
            .replace(Regex("[\\\\/:*?\"<>|]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .ifBlank { "Lyrics" }
        val filename = "$base.txt"
        try {
            val existing = folder.listFiles().firstOrNull { it.isFile && it.name.equals(filename, true) }
            val file = existing ?: folder.createFile("text/plain", filename)
            if (file == null) throw IllegalStateException("File could not be created")
            context.contentResolver.openOutputStream(file.uri, "wt")?.use { out ->
                out.write(text.toByteArray(Charsets.UTF_8))
            } ?: throw IllegalStateException("File could not be written")
            Toast.makeText(context, "Saved to Downloaded Lyrics", Toast.LENGTH_SHORT).show()
            refreshSongIndex(root)
        } catch (e: Exception) {
            Toast.makeText(context, "Save failed: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
        }
    }

    suspend fun activateVoskLanguage(language: String) {
        val spec = VOSK_LANGUAGE_BY_LABEL[language] ?: return
        val modelDir = withContext(Dispatchers.IO) { findInstalledVoskLanguage(context, spec) }
        if (modelDir == null) {
            val oldLanguage = voskActiveLanguage
            val oldModel = voskEnglishModel
            if (stageMicOn && oldModel != null) stageRestartToken++
            var waitedMs = 0L
            while (cecilActiveRecognizers.get() > 0 && waitedMs < 1800L) {
                delay(30)
                waitedMs += 30L
            }
            val drained = cecilActiveRecognizers.get() == 0
            if (drained && oldModel != null) {
                val closeResult = runCatching { oldModel.close() }
                BB2.event(context, "MODEL_CLOSE", "language" to (oldLanguage ?: "unknown"), "reason" to "missing_new_model", "ok" to closeResult.isSuccess)
                voskEnglishModel = null
                voskActiveLanguage = null
            } else if (!drained) {
            }
            return
        }
        if (voskActiveLanguage == language && voskEnglishModel != null) return

        val oldLanguage = voskActiveLanguage
        val oldModel = voskEnglishModel
        BB2.event(context, "ENGINE_SWITCH", "from" to (oldLanguage ?: "none"), "to" to language)

        // First force the existing Cecil DisposableEffect to stop AudioRecord/Recognizer.
        if (stageMicOn && oldModel != null) stageRestartToken++

        // Do not close the native Vosk Model until the old recognizer thread confirms exit.
        var waitedMs = 0L
        while (cecilActiveRecognizers.get() > 0 && waitedMs < 1800L) {
            delay(30)
            waitedMs += 30L
        }
        val drained = cecilActiveRecognizers.get() == 0

        if (!drained) {
            // Safety first: never close a native Model still referenced by a live recognizer.
            return
        }

        if (oldModel != null) {
            val closeResult = runCatching { oldModel.close() }
            BB2.event(context, "MODEL_CLOSE", "language" to (oldLanguage ?: "unknown"), "reason" to "language_switch", "ok" to closeResult.isSuccess)
        }
        voskEnglishModel = null
        voskActiveLanguage = null

        val newModel = withContext(Dispatchers.IO) { Model(modelDir.absolutePath) }
        BB2.event(context, "MODEL_LOAD", "language" to language, "model" to spec.modelName)
        voskEnglishModel = newModel
        voskActiveLanguage = language
        voskModelProgress = 100
        voskModelError = null
    }

    suspend fun installVoskLanguage(language: String) {
        val spec = VOSK_LANGUAGE_BY_LABEL[language] ?: return
        if (voskLanguageLoading[language] == true) return
        voskLanguageLoading[language] = true
        voskLanguageProgress[language] = 0
        voskLanguageError[language] = null
        try {
            withContext(Dispatchers.IO) {
                downloadAndInstallVoskLanguage(context, spec) { pct -> voskLanguageProgress[language] = pct }
            }
            voskInstalled[language] = true
            voskLanguageProgress[language] = 100
            prefs.edit().putBoolean("voice_vosk_disabled_${spec.modelName}", false).apply()
            if (stageLanguage == language) activateVoskLanguage(language)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            voskLanguageError[language] = e.message ?: "$language model download failed"
            voskInstalled[language] = false
        } finally {
            voskLanguageLoading[language] = false
        }
    }

    suspend fun unloadVoskLanguage(language: String) {
        val spec = VOSK_LANGUAGE_BY_LABEL[language] ?: return
        if (stageLanguage == language && stageMicOn) {
            stageMicOn = false
            stageRestartToken++
        }
        if (voskActiveLanguage == language) {
            var waitedMs = 0L
            while (cecilActiveRecognizers.get() > 0 && waitedMs < 1800L) {
                delay(30)
                waitedMs += 30L
            }
            val oldModel = voskEnglishModel
            val drained = cecilActiveRecognizers.get() == 0
            if (drained && oldModel != null) {
                runCatching { oldModel.close() }
                    .onSuccess {  }
                    .onFailure {  }
                voskEnglishModel = null
                voskActiveLanguage = null
            }
        }
        withContext(Dispatchers.IO) { File(context.filesDir, spec.installDir).deleteRecursively() }
        voskInstalled[language] = false
        voskLanguageProgress[language] = 0
        voskLanguageError[language] = null
        prefs.edit().putBoolean("voice_vosk_disabled_${spec.modelName}", true).apply()
        if (language == "English") prefs.edit().putBoolean("voice_english_auto_disabled", true).apply()
    }

    suspend fun installEnglishModel() {
        if (voskModelLoading) return
        voskModelLoading = true
        voskModelProgress = 0
        voskModelError = null
        try {
            installVoskLanguage("English")
            if (voskInstalled["English"] != true) error(voskLanguageError["English"] ?: "English model download failed")
            activateVoskLanguage("English")
            voskModelProgress = 100
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            voskModelError = e.message ?: "English model download failed"
        } finally {
            voskModelLoading = false
        }
    }

    suspend fun installWhisperYu() {
        if (whisperYuLoading) return
        whisperYuLoading = true
        whisperYuProgress = 0
        whisperYuError = null
        try {
            val modelDir = withContext(Dispatchers.IO) {
                downloadAndInstallWhisperYu(context) { pct -> whisperYuProgress = pct }
            }
            whisperYuRecognizer = withContext(Dispatchers.IO) { createWhisperYuRecognizer(modelDir) }
            whisperYuProgress = 100
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            whisperYuError = e.message ?: "Montenegrin voice download failed"
        } finally {
            whisperYuLoading = false
        }
    }

    suspend fun unloadEnglishModel() {
        unloadVoskLanguage("English")
        voskModelProgress = 0
        voskModelError = null
    }

    suspend fun unloadWhisperYu() {
        if (stageLanguage.contains("Montenegrin", ignoreCase = true) && stageMicOn) {
            stageMicOn = false
            stageRestartToken++
        }
        whisperYuRecognizer = null
        whisperYuProgress = 0
        whisperYuError = null
        prefs.edit().putBoolean("voice_whisper_yu_auto_disabled", true).apply()
        withContext(Dispatchers.IO) { File(context.filesDir, WHISPER_YU_DIR).deleteRecursively() }
    }

    LaunchedEffect(Unit) {
        stageWarmupDone = false
        try {
            // Keep voice preparation non-blocking: the app opens immediately while both
            // primary stage languages prepare in parallel in the background.
            withContext(Dispatchers.IO) { clearWhisperYuAfterReinstallOrUpdate(context, prefs) }
            VOSK_LANGUAGE_SPECS.forEach { spec ->
                val installed = withContext(Dispatchers.IO) { findInstalledVoskLanguage(context, spec) != null }
                voskInstalled[spec.label] = installed
                voskLanguageProgress[spec.label] = if (installed) 100 else 0
                voskLanguageLoading[spec.label] = false
            }

            val englishJob = launch {
                val existingEnglish = findInstalledVoskEnglish(context)
                if (existingEnglish != null) {
                    try {
                        voskEnglishModel = withContext(Dispatchers.IO) { Model(existingEnglish.absolutePath) }
                        voskActiveLanguage = "English"
                        voskInstalled["English"] = true
                        voskModelProgress = 100
                    } catch (e: Exception) {
                        voskModelError = e.message ?: "English model could not be loaded"
                    }
                } else if (!prefs.getBoolean("voice_english_auto_disabled", false)) {
                    installEnglishModel()
                }
            }

            val whisperJob = launch {
                val existingWhisperYu = findInstalledWhisperYu(context)
                if (existingWhisperYu != null) {
                    try {
                        whisperYuRecognizer = withContext(Dispatchers.IO) { createWhisperYuRecognizer(existingWhisperYu) }
                        whisperYuProgress = 100
                    } catch (e: Exception) {
                        whisperYuError = e.message ?: "Montenegrin model could not be loaded"
                    }
                } else if (!prefs.getBoolean("voice_whisper_yu_auto_disabled", false)) {
                    installWhisperYu()
                }
            }

            englishJob.join()
            whisperJob.join()
            if (!stageLanguage.contains("Montenegrin", ignoreCase = true) && stageLanguage != "English" && voskInstalled[stageLanguage] == true) {
                try {
                    activateVoskLanguage(stageLanguage)
                } catch (e: Exception) {
                    voskLanguageError[stageLanguage] = e.message ?: "$stageLanguage model could not be loaded"
                }
            }
        } finally {
            stageWarmupDone = true
        }
    }

    val stageLines = remember(openedText) { (openedText ?: "").lines() }
    fun nextStageLine(fromExclusive: Int): Int {
        var i = (fromExclusive + 1).coerceAtLeast(0)
        while (i < stageLines.size) {
            if (!stageIgnoreLine(stageLines[i])) return i
            i++
        }
        return -1
    }

    fun stagePhysicalBlank(line: String): Boolean =
        stageSanitizeInvisibleSeparators(line).isBlank()

    fun initialStageLine(): Int {
        val first = nextStageLine(-1)
        if (first < 0) return -1

        // Smart one-line header rule. The separator may contain BOM / zero-width / NBSP
        // characters copied from old lyric files, so treat those as a physical blank too.
        if (first == 0 && stageLines.size > 1 && stagePhysicalBlank(stageLines[1])) {
            val afterHeader = nextStageLine(1)
            if (afterHeader >= 0) return afterHeader
        }
        return first
    }

    LaunchedEffect(openedText) {
        // LYR SYNC ON is the user's latch. Capture is silent while browsing because
        // the recorder is disposed when there is no opened song; opening a song resumes it.
        stageLineIndex = initialStageLine()
        if (openedText == null && stageMicOn) {
        }
        openedText?.let { text ->
            // Detect the lyric language before starting the microphone. Every supported
            // language routes to its own Vosk model; Montenegrin remains the Whisper lane.
            val detected = detectStageLanguage(text)
            stageLanguage = detected
            prefs.edit().putString("stage_language", detected).apply()
            if (detected.contains("Montenegrin", ignoreCase = true)) {
                val oldLanguage = voskActiveLanguage
                if (oldLanguage != null) BB2.event(context, "ENGINE_SWITCH", "from" to oldLanguage, "to" to "Whisper/Montenegrin")
                val oldModel = voskEnglishModel
                if (oldModel != null) {
                    if (stageMicOn) stageRestartToken++
                    var waitedMs = 0L
                    while (cecilActiveRecognizers.get() > 0 && waitedMs < 1800L) {
                        delay(30)
                        waitedMs += 30L
                    }
                    val drained = cecilActiveRecognizers.get() == 0
                    if (drained) {
                        val closeResult = runCatching { oldModel.close() }
                        BB2.event(context, "MODEL_CLOSE", "language" to (oldLanguage ?: "unknown"), "reason" to "switch_to_whisper", "ok" to closeResult.isSuccess)
                        voskEnglishModel = null
                        voskActiveLanguage = null
                    } else {
                    }
                }
            } else if (voskInstalled[detected] == true && voskActiveLanguage != detected) {
                try {
                    activateVoskLanguage(detected)
                } catch (e: Exception) {
                    voskLanguageError[detected] = e.message ?: "$detected model could not be loaded"
                }
            }
            val headerSep = stageLines.getOrNull(1)?.let(::stagePhysicalBlank) ?: false
            val first3 = stageLines.take(3).map { it.replace("\t", "↹").take(60) }
            BB2.event(context, "SONG_OPEN", "song" to openedTitle.removeSuffix(".txt"), "language" to detected, "engine" to if (detected.contains("Montenegrin", true)) "WHISPER" else "CECIL")
            if (stageMicOn) {
                stageRestartToken++
            }
        }
    }

    val stagePermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            stageMicOn = true
            BB2.event(context, "MIC_STATE", "state" to "ON", "reason" to "permission_granted")
            stageRestartToken++
        } else {
            Toast.makeText(context, "Microphone permission is required", Toast.LENGTH_SHORT).show()
        }
    }

    val currentStageLineIndex by rememberUpdatedState(stageLineIndex)
    DisposableEffect(stageMicOn, openedText, voskEnglishModel, whisperYuRecognizer, stageLanguage, stageRestartToken, stageCleanOn) {
        if (!stageMicOn || openedText == null || stageLineIndex !in stageLines.indices) {
            onDispose { }
        } else {
            val isYu = stageLanguage.contains("Montenegrin")

            if (isYu) {
                val recognizer = whisperYuRecognizer
                if (recognizer == null) {
                    Toast.makeText(
                        context,
                        whisperYuError ?: if (whisperYuLoading) "Preparing Montenegrin voice ${whisperYuProgress}%…" else "Montenegrin voice is not installed — open Settings",
                        Toast.LENGTH_SHORT
                    ).show()
                    onDispose { }
                } else {
                    // Whisper is intentionally isolated from Cecil. It only receives EX-YU microphone audio.
                    val running = AtomicBoolean(true)
                    val sampleRate = 16000
                    // KEY 3: 2.8 s rolling Whisper window; matcher thresholds stay unchanged.
                    val windowSamples = sampleRate * 28 / 10
                    val shared = FloatArray(windowSamples)
                    val sharedCount = intArrayOf(0)
                    val lock = Any()
                    var whisperDuplicateArmedLine = -1

                    fun consumeWhisper(heardRaw: String): Boolean {
                        val heard = stageNormalize(heardRaw)
                        if (heard.isBlank()) return false
                        val current = currentStageLineIndex
                        if (current !in stageLines.indices) return false

                        val n = nextStageLine(current)
                        val n2 = if (n >= 0) nextStageLine(n) else -1
                        val currentText = stageLines.getOrNull(current) ?: return false
                        val nextText = stageLines.getOrNull(n)
                        val next2Text = stageLines.getOrNull(n2)
                        val duplicatePair = n >= 0 && stageDuplicateLinePair(currentText, nextText)
                        if (!duplicatePair || whisperDuplicateArmedLine != current) {
                            if (!duplicatePair) whisperDuplicateArmedLine = -1
                        }

                        // LIVE NEXT trigger: advance only after evidence that singing entered NEXT.
                        // One characteristic NEXT word is enough; generic/shared words need more proof.
                        // Noisy glued tokens can recover a clear expected core (sgitarom -> gitarom).
                        val oneWordReady = whisperNextLineAdvanceReady(heard, currentText, nextText)

                        // Whisper latency key: inspect CURRENT + NEXT + NEXT2. NEXT2 is evidence only:
                        // even a clear NEXT2 match may advance only CURRENT -> NEXT, never two lines.
                        // Keep the existing score thresholds intact.
                        val candidates = mutableListOf(current)
                        if (n >= 0) candidates.add(n)
                        if (n2 >= 0) candidates.add(n2)
                        val scored = candidates.mapNotNull { idx ->
                            val expected = stageLines.getOrNull(idx) ?: return@mapNotNull null
                            idx to stageLineMatchScore(heard, stageEngineText(expected, stageLanguage))
                        }
                        val best = scored.maxByOrNull { it.second }
                        val runnerUp = scored.filter { it.first != best?.first }.maxOfOrNull { it.second } ?: 0.0
                        // NEXT keeps the proven v66/v81 gate. NEXT2 is latency evidence only,
                        // so its ramp is deliberately much looser: it may only move CURRENT -> NEXT.
                        // This catches Whisper when recognition arrives roughly one lyric line late
                        // without ever permitting a two-line jump.
                        val nextMatcherReady = best != null &&
                            best.first == n &&
                            best.second >= 0.46 && best.second - runnerUp >= 0.04
                        val next2EvidenceReady = best != null &&
                            best.first == n2 &&
                            best.second >= 0.19 && best.second - runnerUp >= 0.01
                        val fullMatcherReady = nextMatcherReady || next2EvidenceReady

                        // DUPLICATE-LINE micro key (Whisper): normal rules are untouched unless
                        // CURRENT and NEXT normalize to the exact same line. First we arm only
                        // after CURRENT itself is strongly heard. Then a second non-overlapping
                        // whole-line occurrence inside the rolling decode is proof of the new pass.
                        val duplicateScore = if (duplicatePair) stageLineMatchScore(heard, stageEngineText(currentText, stageLanguage)) else 0.0
                        val duplicateCount = if (duplicatePair) stageDuplicateSequenceCount(heard, currentText, ::whisperNoisyExpectedWordMatch) else 0
                        val duplicateAdvance = duplicatePair && whisperDuplicateArmedLine == current && duplicateCount >= 2
                        if (duplicatePair && whisperDuplicateArmedLine != current && duplicateScore >= 0.62) {
                            whisperDuplicateArmedLine = current
                        }

                        // Anti-jump: exactly one recognition result can advance at most ONE line.
                        // For an identical pair, ONLY the duplicate micro key may cross it.
                        val normalAdvance = !duplicatePair && (oneWordReady || fullMatcherReady)
                        if (n >= 0 && n > current && (normalAdvance || duplicateAdvance)) {
                            val reason = if (duplicateAdvance) "duplicate" else if (oneWordReady) "word" else if (next2EvidenceReady) "next2" else "matcher"
                            whisperDuplicateArmedLine = -1
                            BB2.event(context, "ADVANCE", "engine" to "WHISPER", "fromLine" to current, "toLine" to n, "reason" to reason)
                            (context as? ComponentActivity)?.runOnUiThread { stageLineIndex = n }
                            return true
                        } else {
                        }
                        return false
                    }

                    val minBytes = AudioRecord.getMinBufferSize(
                        sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
                    ).coerceAtLeast(sampleRate / 2)
                    var audioRecord: AudioRecord? = null
                    var whisperNoiseSuppressor: NoiseSuppressor? = null

                    val recordThread = Thread({
                        try {
                            audioRecord = AudioRecord(
                                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                                sampleRate,
                                AudioFormat.CHANNEL_IN_MONO,
                                AudioFormat.ENCODING_PCM_16BIT,
                                minBytes * 2
                            )
                            val ar = audioRecord ?: return@Thread
                            val nsAvailable = NoiseSuppressor.isAvailable()
                            if (stageCleanOn && nsAvailable) {
                                whisperNoiseSuppressor = runCatching { NoiseSuppressor.create(ar.audioSessionId) }.getOrNull()
                                runCatching { whisperNoiseSuppressor?.enabled = true }
                            }
                            val buf = ShortArray(1600)
                            ar.startRecording()
                            while (running.get()) {
                                val n = ar.read(buf, 0, buf.size)
                                if (n <= 0) continue
                                synchronized(lock) {
                                    if (sharedCount[0] + n > shared.size) {
                                        val drop = sharedCount[0] + n - shared.size
                                        System.arraycopy(shared, drop, shared, 0, sharedCount[0] - drop)
                                        sharedCount[0] -= drop
                                    }
                                    val gain = micGainAmplitude(micGainDbRef.get())
                                    var clipped = false
                                    for (i in 0 until n) {
                                        val amplified = (buf[i] / 32768.0f) * gain
                                        if (amplified > 1.0f || amplified < -1.0f) clipped = true
                                        shared[sharedCount[0] + i] = amplified.coerceIn(-1.0f, 1.0f)
                                    }
                                    if (clipped) micClipUntilMs.set(System.currentTimeMillis() + 650L)
                                    sharedCount[0] += n
                                }
                            }
                        } catch (e: Exception) {
                            BB2.event(context, "ERROR", "area" to "WHISPER_AUDIO", "message" to (e.message ?: "listener error"))
                            (context as? ComponentActivity)?.runOnUiThread {
                                Toast.makeText(context, "Voice input: ${e.message ?: "listener error"}", Toast.LENGTH_LONG).show()
                            }
                        } finally {
                            runCatching { audioRecord?.stop() }
                            runCatching { whisperNoiseSuppressor?.release() }
                            whisperNoiseSuppressor = null
                            runCatching { audioRecord?.release() }
                            audioRecord = null
                        }
                    }, "WhisperYuAudio")

                    val decodeThread = Thread({
                        try {
                            while (running.get()) {
                                Thread.sleep(280)
                                val snapshotPack = synchronized(lock) {
                                    val count = sharedCount[0]
                                    if (count < sampleRate) null else Pair(shared.copyOfRange(0, count), count)
                                } ?: continue
                                val snapshot = snapshotPack.first
                                val snapshotCount = snapshotPack.second
                                val stream = recognizer.createStream()
                                try {
                                    stream.acceptWaveform(samples = snapshot, sampleRate = sampleRate)
                                    recognizer.decode(stream)
                                    val advanced = consumeWhisper(recognizer.getResult(stream).text)
                                    if (advanced) {
                                        // Consume only audio that produced the accepted line. Newer audio
                                        // recorded during inference survives, so repeated words on NEXT
                                        // are heard as fresh evidence rather than stale duplicates.
                                        synchronized(lock) {
                                            val tail = (sharedCount[0] - snapshotCount).coerceAtLeast(0)
                                            if (tail > 0) {
                                                System.arraycopy(shared, snapshotCount, shared, 0, tail)
                                            }
                                            sharedCount[0] = tail
                                        }
                                    }
                                } finally {
                                    runCatching { stream.release() }
                                }
                            }
                        } catch (_: InterruptedException) {
                        } catch (e: Exception) {
                            BB2.event(context, "ERROR", "area" to "WHISPER_DECODE", "message" to (e.message ?: "recognizer error"))
                            (context as? ComponentActivity)?.runOnUiThread {
                                Toast.makeText(context, "Voice recognition: ${e.message ?: "recognizer error"}", Toast.LENGTH_LONG).show()
                            }
                        }
                    }, "WhisperYuDecode")

                    BB2.event(context, "RECOGNIZER", "engine" to "WHISPER", "state" to "OPEN", "language" to stageLanguage)
                    recordThread.start()
                    decodeThread.start()
                    onDispose {
                        BB2.event(context, "RECOGNIZER", "engine" to "WHISPER", "state" to "CLOSE", "language" to stageLanguage)
                        running.set(false)
                        recordThread.interrupt()
                        decodeThread.interrupt()
                        runCatching { audioRecord?.stop() }
                    }
                }
            } else {
                // CECIL: Vosk English engine. Matching/advance policy mirrors Whisper LIVE NEXT.
                val model = voskEnglishModel
                if (model == null) {
                    Toast.makeText(
                        context,
                        (if (stageLanguage == "English") voskModelError else voskLanguageError[stageLanguage])
                            ?: if ((stageLanguage == "English" && voskModelLoading) || voskLanguageLoading[stageLanguage] == true) "Preparing $stageLanguage listener…" else "$stageLanguage listener unavailable",
                        Toast.LENGTH_SHORT
                    ).show()
                    onDispose { }
                } else {
                    // Selected +2/+5/+7 dB input gain is applied only in the microphone capture layer.
                    // Cecil matcher / anti-jump / duplicate logic below remains unchanged.
                    val cecilAudioRunning = AtomicBoolean(true)
                    var cecilAudioRecord: AudioRecord? = null
                    var cecilNoiseSuppressor: NoiseSuppressor? = null
                    var cecilAudioThread: Thread? = null
                    var cecilRecognizer: Recognizer? = null
                    val cecilRecognizerCounted = AtomicBoolean(false)

                    // Decision cursor is local and is committed immediately. Compose may publish
                    // stageLineIndex a few callbacks later; Cecil must not re-fire from stale UI.
                    var cecilDecisionLine = currentStageLineIndex
                    var cecilPendingTarget = -1
                    var cecilPreviousHeard = ""
                    var cecilDuplicateArmedLine = -1
                    var cecilDuplicateBoundaryReady = false

                    fun cecilNewTail(heardRaw: String): String {
                        val now = stageNormalize(heardRaw)
                        val prev = cecilPreviousHeard
                        cecilPreviousHeard = now
                        if (prev.isBlank()) return now
                        val nw = now.split(' ').filter { it.isNotBlank() }
                        val pw = prev.split(' ').filter { it.isNotBlank() }
                        var common = 0
                        val lim = minOf(nw.size, pw.size)
                        while (common < lim && nw[common] == pw[common]) common++
                        return nw.drop(common).joinToString(" ")
                    }

                    fun consumeHypothesis(json: String?, key: String) {
                        if (json.isNullOrBlank()) return
                        val heard = runCatching { org.json.JSONObject(json).optString(key) }.getOrDefault("")
                        if (heard.isBlank()) return

                        val uiCurrent = currentStageLineIndex
                        if (uiCurrent !in stageLines.indices) return

                        // If UI caught up with our committed target, clear pending. If UI moved to
                        // some other row, it was a manual tap: manual selection always wins.
                        if (cecilPendingTarget >= 0 && uiCurrent == cecilPendingTarget) {
                            cecilDecisionLine = uiCurrent
                            cecilPendingTarget = -1
                        } else if (cecilPendingTarget < 0 && uiCurrent != cecilDecisionLine) {
                            cecilDecisionLine = uiCurrent
                            cecilPreviousHeard = ""
                            cecilDuplicateArmedLine = -1
                            cecilDuplicateBoundaryReady = false
                        }

                        val current = cecilDecisionLine
                        if (current !in stageLines.indices) return
                        val n = nextStageLine(current)
                        val currentText = stageLines.getOrNull(current) ?: return
                        val nextText = stageLines.getOrNull(n)
                        val duplicatePair = n >= 0 && stageDuplicateLinePair(currentText, nextText)
                        if (!duplicatePair) {
                            cecilDuplicateArmedLine = -1
                            cecilDuplicateBoundaryReady = false
                        } else if (cecilDuplicateArmedLine != current) {
                            cecilDuplicateBoundaryReady = false
                        }

                        // Vosk partials are cumulative. ONE-WORD evidence is evaluated only on the
                        // newly arrived tail, never on words already heard for CURRENT/older lines.
                        val newTail = cecilNewTail(heard)
                        val rawWordReady = cecilNextLineAdvanceReady(newTail, currentText, nextText)

                        // IMPORTANT: Vosk partials can arrive many times per second.
                        // Never run the full fuzzy matcher on every partial: that work used to
                        // execute on the UI thread and could freeze the lyric faders. Partials use
                        // only the cheap NEW-tail key; the full matcher runs only on complete text.
                        var fullMatcherReady = false
                        if (key == "text") {
                            val candidates = mutableListOf(current)
                            if (n >= 0) candidates.add(n)
                            val scored = candidates.mapNotNull { idx ->
                                val expected = stageLines.getOrNull(idx) ?: return@mapNotNull null
                                idx to stageLineMatchScore(heard, stageEngineText(expected, stageLanguage))
                            }
                            val best = scored.maxByOrNull { it.second }
                            val runnerUp = scored.filter { it.first != best?.first }.maxOfOrNull { it.second } ?: 0.0
                            fullMatcherReady = best != null && best.first == n &&
                                best.second >= 0.56 && best.second - runnerUp >= 0.06
                        }

                        // TWO-KEY CECIL LOCK:
                        // 1) characteristic evidence from the NEW tail may advance immediately,
                        //    even while cumulative Vosk still scores CURRENT higher;
                        // 2) fuzzy tolerance exists only inside that NEW-tail -> NEXT comparison.
                        // Full matcher remains independently locked to NEXT.
                        val nextWordReady = rawWordReady
                        val staleUi = uiCurrent != current

                        // DUPLICATE-LINE micro key (Cecil): dormant unless CURRENT == NEXT after
                        // normalization. First occurrence only arms. A second complete occurrence
                        // in the cumulative Vosk hypothesis, or a new post-final utterance that
                        // strongly matches the same line, is the required proof of a repeated pass.
                        var duplicateScore = 0.0
                        var duplicateCount = 0
                        if (duplicatePair && key == "text") {
                            duplicateScore = stageLineMatchScore(heard, stageEngineText(currentText, stageLanguage))
                            duplicateCount = stageDuplicateSequenceCount(heard, currentText, ::cecilTailWordMatchesExpected)
                        }
                        val duplicateAdvance = duplicatePair && cecilDuplicateArmedLine == current &&
                            (duplicateCount >= 2 || (cecilDuplicateBoundaryReady && duplicateScore >= 0.56))
                        if (duplicatePair && key == "text" && cecilDuplicateArmedLine != current && duplicateScore >= 0.62) {
                            cecilDuplicateArmedLine = current
                        }

                        val normalAdvance = !duplicatePair && (nextWordReady || fullMatcherReady)
                        if (n >= 0 && n > current && (normalAdvance || duplicateAdvance)) {
                            val reason = if (duplicateAdvance) "duplicate" else if (nextWordReady) "word" else "matcher"
                            cecilDecisionLine = n
                            cecilPendingTarget = n
                            cecilPreviousHeard = stageNormalize(heard)
                            cecilDuplicateArmedLine = -1
                            cecilDuplicateBoundaryReady = false
                            BB2.event(context, "ADVANCE", "engine" to "CECIL", "fromLine" to current, "toLine" to n, "reason" to reason)
                            stageLineIndex = n
                        } else {
                            if (duplicatePair && cecilDuplicateArmedLine == current && key == "text" && duplicateScore >= 0.56) {
                                cecilDuplicateBoundaryReady = true
                            }
                        }
                    }

                    val phrases = stageLines
                        .filterNot(::stageIgnoreLine)
                        .map { stageEngineText(it, stageLanguage) }
                        .filter { it.isNotBlank() }
                        .distinct()
                        .toMutableList()
                        .apply { add("[unk]") }
                    val grammar = org.json.JSONArray(phrases).toString()

                    try {
                        val recognizer = Recognizer(model, 16000.0f, grammar)
                        BB2.event(context, "RECOGNIZER", "engine" to "CECIL", "state" to "OPEN", "language" to stageLanguage)
                        cecilRecognizer = recognizer
                        val sampleRate = 16000
                        val minBytes = AudioRecord.getMinBufferSize(
                            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
                        ).coerceAtLeast(sampleRate / 2)
                        cecilAudioRecord = AudioRecord(
                            MediaRecorder.AudioSource.VOICE_RECOGNITION,
                            sampleRate,
                            AudioFormat.CHANNEL_IN_MONO,
                            AudioFormat.ENCODING_PCM_16BIT,
                            minBytes * 2
                        )
                        val ar = cecilAudioRecord ?: throw IllegalStateException("microphone unavailable")
                        val nsAvailable = NoiseSuppressor.isAvailable()
                        if (stageCleanOn && nsAvailable) {
                            cecilNoiseSuppressor = runCatching { NoiseSuppressor.create(ar.audioSessionId) }.getOrNull()
                            runCatching { cecilNoiseSuppressor?.enabled = true }
                        }
                        if (cecilRecognizerCounted.compareAndSet(false, true)) {
                            cecilActiveRecognizers.incrementAndGet()
                        }
                        cecilAudioThread = Thread({
                            try {
                                val raw = ShortArray(1600)
                                val boosted = ShortArray(1600)
                                ar.startRecording()
                                while (cecilAudioRunning.get()) {
                                    val nread = ar.read(raw, 0, raw.size)
                                    if (nread <= 0) continue
                                    val gain = micGainAmplitude(micGainDbRef.get())
                                    var clipped = false
                                    for (i in 0 until nread) {
                                        val amplified = raw[i] * gain
                                        if (amplified > Short.MAX_VALUE.toFloat() || amplified < Short.MIN_VALUE.toFloat()) clipped = true
                                        boosted[i] = amplified
                                            .toInt()
                                            .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                                            .toShort()
                                    }
                                    if (clipped) micClipUntilMs.set(System.currentTimeMillis() + 650L)
                                    val complete = recognizer.acceptWaveForm(boosted, nread)
                                    val json = if (complete) recognizer.result else recognizer.partialResult
                                    val key = if (complete) "text" else "partial"
                                    (context as? ComponentActivity)?.runOnUiThread {
                                        val t0 = SystemClock.elapsedRealtime()
                                        consumeHypothesis(json, key)
                                        val dt = SystemClock.elapsedRealtime() - t0
                                        if (dt >= 200L) {
                                            BB2.event(context, "CECIL_SLOW_MATCH", "durationMs" to dt, "key" to key)
                                        }
                                    }
                                }
                                val finalJson = recognizer.finalResult
                                (context as? ComponentActivity)?.runOnUiThread {
                                    consumeHypothesis(finalJson, "text")
                                }
                            } catch (_: InterruptedException) {
                            } catch (e: Exception) {
                                if (cecilAudioRunning.get()) {
                                    (context as? ComponentActivity)?.runOnUiThread {
                                        Toast.makeText(context, "English voice input: ${e.message ?: "listener error"}", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            } finally {
                                runCatching { ar.stop() }
                                runCatching { cecilNoiseSuppressor?.release() }
                                cecilNoiseSuppressor = null
                                runCatching { ar.release() }
                                runCatching { recognizer.close() }
                                BB2.event(context, "RECOGNIZER", "engine" to "CECIL", "state" to "CLOSE", "language" to stageLanguage)
                                if (cecilRecognizerCounted.compareAndSet(true, false)) {
                                    val activeAfterClose = cecilActiveRecognizers.decrementAndGet()
                                    if (activeAfterClose < 0) cecilActiveRecognizers.set(0)
                                }
                            }
                        }, "CecilAudioBoost4dB").also { it.start() }
                    } catch (e: Exception) {
                        BB2.event(context, "ERROR", "area" to "CECIL_START", "message" to (e.message ?: "unknown"))
                        runCatching { cecilRecognizer?.close() }
                        if (cecilRecognizerCounted.compareAndSet(true, false)) {
                            val activeAfterClose = cecilActiveRecognizers.decrementAndGet()
                            if (activeAfterClose < 0) cecilActiveRecognizers.set(0)
                        }
                        Toast.makeText(context, "$stageLanguage voice start failed: ${e.message ?: "unknown"}", Toast.LENGTH_LONG).show()
                    }

                    onDispose {
                        cecilAudioRunning.set(false)
                        cecilAudioThread?.interrupt()
                        runCatching { cecilAudioRecord?.stop() }
                        cecilAudioRecord = null
                        cecilAudioThread = null
                        cecilRecognizer = null
                    }
                }
            }
        }
    }

    val folderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) {}

            rootUri = uri
            backHistory.clear()
            forwardHistory.clear()
            searchQuery = ""
            searching = false
            searchResults = emptyList()

            prefs.edit()
                .putString("root_uri", uri.toString())
                .putString("last_folder_uri", uri.toString())
                .apply()

            ensureDownloadedLyricsFolder(uri)
            listFolder(uri)
            refreshSongIndex(uri)
            checkForConvertibleFiles(uri, firstRun = true)
        }
    }

    val voiceSearchLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
        if (!spoken.isNullOrBlank()) doSearch(spoken)
    }

    val webVoiceSearchLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
        if (!spoken.isNullOrBlank()) launchWebSearch(spoken)
    }

    fun launchVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Say the song title")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        }
        voiceSearchLauncher.launch(intent)
    }

    fun launchWebVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Say song name")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        }
        webVoiceSearchLauncher.launch(intent)
    }

    fun configureWebViewForDarkStage(webView: WebView) {
        val webSettings = webView.settings
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(webSettings, true)
        } else if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            WebSettingsCompat.setForceDark(webSettings, WebSettingsCompat.FORCE_DARK_ON)
        }
        webView.setBackgroundColor(android.graphics.Color.BLACK)
    }

    fun openDonate() {
        context.startActivity(
            Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://wise.com/pay/me/milanv607?utm_source=request_flow")
            )
        )
    }

    LaunchedEffect(Unit) {
        PDFBoxResourceLoader.init(context)

        // v1.32: one-time tiny reduction so existing users also get the slightly
        // calmer listing size without losing their personal +/- adjustment history.
        if (!prefs.getBoolean("v132_list_font_adjusted", false)) {
            listFontSize = (listFontSize - 1f).coerceAtLeast(16f)
            prefs.edit()
                .putFloat("list_font_size", listFontSize)
                .putBoolean("v132_list_font_adjusted", true)
                .apply()
        }

        val savedRoot = rootUri

        if (savedRoot == null) {
            // First launch: the app must ask for its root folder before showing the browser.
            folderPicker.launch(null)
        } else {
            val rootFolder = DocumentFile.fromTreeUri(context, savedRoot)

            if (rootFolder == null || !rootFolder.isDirectory || !rootFolder.canRead()) {
                // The old folder was removed or Android revoked access. Ask again.
                prefs.edit()
                    .remove("root_uri")
                    .remove("last_folder_uri")
                    .apply()
                rootUri = null
                currentUri = null
                folderPicker.launch(null)
            } else {
                // Every fresh app launch starts at HOME/root. Never reopen the last song/folder.
                backHistory.clear()
                forwardHistory.clear()
                searchQuery = ""
                searching = false
                searchResults = emptyList()
                listFolder(savedRoot)
                refreshSongIndex(savedRoot)
                checkForConvertibleFiles(savedRoot, firstRun = false)

                if (rootFolder.canWrite()) {
                    ensureDownloadedLyricsFolder(savedRoot)
                } else {
                    // Older LyrGig versions persisted read-only access. Web saving needs
                    // one re-selection of the same root so Android can persist write access too.
                    folderPicker.launch(savedRoot)
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color.Black,
            surface = Color.Black,
            onBackground = Color.White,
            onSurface = Color.White,
            primary = Color.White,
            onPrimary = Color.Black
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color.Black
        ) {
            val isRoot = rootUri != null && currentUri == rootUri && openedText == null && !showWebSearch

            LaunchedEffect(isRoot) {
                if (isRoot) rootUri?.let { checkForConvertibleFiles(it, firstRun = false) }
            }

            BackHandler(enabled = showWebSearch || searching || backHistory.isNotEmpty()) { goBack() }

            Box(Modifier.fillMaxSize()) {
                if (showBb2) {
                    AlertDialog(
                        onDismissRequest = { showBb2 = false },
                        title = { Text("BB2", color = Color.White, fontWeight = FontWeight.Bold) },
                        text = {
                            SelectionContainer {
                                Text(
                                    text = bb2Snapshot.ifBlank { "BB2 is empty." },
                                    color = Color.White,
                                    fontSize = if (isPhoneLayout) 11.sp else 13.sp,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(max = if (isPhoneLayout) 520.dp else 620.dp)
                                        .verticalScroll(rememberScrollState())
                                )
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("BB2", bb2Snapshot))
                                Toast.makeText(context, "BB2 copied", Toast.LENGTH_SHORT).show()
                            }) { Text("COPY", color = Color.White, fontWeight = FontWeight.Bold) }
                        },
                        dismissButton = {
                            TextButton(onClick = { showBb2 = false }) { Text("CLOSE", color = Color.White, fontWeight = FontWeight.Bold) }
                        },
                        containerColor = Color(0xFF101010)
                    )
                }

                if (showCpuMonitor) {
                    LaunchedEffect(Unit) {
                        while (showCpuMonitor) {
                            withContext(Dispatchers.IO) { BB2.cpuReading() }.let { reading ->
                                cpuReading = reading
                                reading?.let { r ->
                                    BB2.event(
                                        context,
                                        "CPU_SAMPLE",
                                        "processPct" to String.format(Locale.US, "%.1f", r.processPct),
                                        "devicePct" to String.format(Locale.US, "%.1f", r.devicePct),
                                        "cores" to r.cores
                                    )
                                }
                            }
                            delay(1000)
                        }
                    }
                    AlertDialog(
                        onDismissRequest = { showCpuMonitor = false },
                        title = { Text("BB2 · CPU", color = Color.White, fontWeight = FontWeight.Bold) },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("App CPU: ${cpuReading?.processPct?.let { String.format(Locale.US, "%.1f", it) } ?: "—"}%", color = Color.White)
                                Text("Device CPU: ${cpuReading?.devicePct?.let { String.format(Locale.US, "%.1f", it) } ?: "—"}%", color = Color.White)
                                Text("Cores: ${cpuReading?.cores ?: "—"}", color = Color.LightGray)
                                Text("Live monitor only — nothing is logged.", color = Color.Gray, fontSize = 12.sp)
                            }
                        },
                        confirmButton = { TextButton(onClick = { showCpuMonitor = false }) { Text("CLOSE", color = Color.White) } },
                        containerColor = Color(0xFF101010)
                    )
                }

                if (showSetup) {
                    val cecilLanguageCatalog = VOSK_LANGUAGE_SPECS.map { it.label }.filter { it != "English" }

                    AlertDialog(
                        onDismissRequest = { showSetup = false },
                        title = { Text("⚙  Settings", color = Color.White, fontSize = if (isPhoneLayout) 20.sp else 24.sp) },
                        text = {
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = if (isPhoneLayout) 560.dp else 520.dp)
                                    .verticalScroll(rememberScrollState())
                            ) {
                                Button(
                                    onClick = { showSetup = false; showToolsPopup = true },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF202020), contentColor = Color.White)
                                ) { Text("TOOLS", fontWeight = FontWeight.Bold) }

                                Spacer(Modifier.height(if (isPhoneLayout) 6.dp else 8.dp))
                                OutlinedButton(
                                    onClick = { showSetup = false; showSongLanguagePopup = true },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("SONG LANGUAGE: $stageLanguage", color = Color.White, fontWeight = FontWeight.Bold) }

                                HorizontalDivider(color = Color.White.copy(alpha = 0.12f), modifier = Modifier.padding(vertical = if (isPhoneLayout) 8.dp else 12.dp))
                                Text("VOICE LANGUAGES", color = Color(0xFFFFC107), fontSize = if (isPhoneLayout) 15.sp else 18.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(if (isPhoneLayout) 5.dp else 10.dp))

                                if (isPhoneLayout) {
                                    Column(Modifier.fillMaxWidth().padding(vertical = if (isPhoneLayout) 1.dp else 4.dp)) {
                                        Text(
                                            when {
                                                voskModelLoading -> "English — 40 MB — Loading ${voskModelProgress}%"
                                                voskInstalled["English"] == true -> "English — 40 MB — Ready"
                                                else -> "English — 40 MB — Not installed"
                                            },
                                            color = Color.White,
                                            fontSize = if (isPhoneLayout) 14.sp else 16.sp
                                        )
                                        if (voskInstalled["English"] == true) {
                                            TextButton(
                                                onClick = { (context as? ComponentActivity)?.lifecycleScope?.launch { unloadEnglishModel() } },
                                                modifier = Modifier.align(Alignment.End)
                                            ) { Text("UNLOAD", color = Color.White, fontSize = if (isPhoneLayout) 13.sp else 14.sp, fontWeight = FontWeight.Bold) }
                                        } else if (!voskModelLoading) {
                                            TextButton(
                                                onClick = {
                                                    prefs.edit().putBoolean("voice_english_auto_disabled", false).apply()
                                                    (context as? ComponentActivity)?.lifecycleScope?.launch { installEnglishModel() }
                                                },
                                                modifier = Modifier.align(Alignment.End)
                                            ) { Text("DOWNLOAD", color = Color.White, fontSize = if (isPhoneLayout) 13.sp else 14.sp, fontWeight = FontWeight.Bold) }
                                        }
                                    }
                                } else {
                                    Row(
                                        Modifier.fillMaxWidth().padding(vertical = 5.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            when {
                                                voskModelLoading -> "English — 40 MB — Loading ${voskModelProgress}%"
                                                voskInstalled["English"] == true -> "English — 40 MB — Ready"
                                                else -> "English — 40 MB — Not installed"
                                            },
                                            color = Color.White,
                                            fontSize = 17.sp,
                                            modifier = Modifier.weight(1f)
                                        )
                                        if (voskInstalled["English"] == true) {
                                            TextButton(onClick = {
                                                (context as? ComponentActivity)?.lifecycleScope?.launch { unloadEnglishModel() }
                                            }) { Text("UNLOAD", color = Color.White, fontSize = if (isPhoneLayout) 13.sp else 14.sp, fontWeight = FontWeight.Bold) }
                                        } else if (!voskModelLoading) {
                                            TextButton(onClick = {
                                                prefs.edit().putBoolean("voice_english_auto_disabled", false).apply()
                                                (context as? ComponentActivity)?.lifecycleScope?.launch { installEnglishModel() }
                                            }) { Text("DOWNLOAD", color = Color.White, fontSize = if (isPhoneLayout) 13.sp else 14.sp, fontWeight = FontWeight.Bold) }
                                        }
                                    }
                                }
                                voskModelError?.let { Text(it, color = Color(0xFFFF8A80), fontSize = 13.sp) }

                                HorizontalDivider(color = Color.White.copy(alpha = 0.12f), modifier = Modifier.padding(vertical = if (isPhoneLayout) 4.dp else 8.dp))

                                if (isPhoneLayout) {
                                    Column(Modifier.fillMaxWidth().padding(vertical = if (isPhoneLayout) 1.dp else 4.dp)) {
                                        Text(
                                            when {
                                                whisperYuLoading -> "Montenegrin — $MONTENEGRIN_DOWNLOAD_SIZE — Loading ${whisperYuProgress}%"
                                                whisperYuRecognizer != null -> "Montenegrin — $MONTENEGRIN_DOWNLOAD_SIZE — Ready"
                                                else -> "Montenegrin — $MONTENEGRIN_DOWNLOAD_SIZE — Not installed"
                                            },
                                            color = Color.White,
                                            fontSize = if (isPhoneLayout) 14.sp else 16.sp
                                        )
                                        if (whisperYuRecognizer != null) {
                                            TextButton(
                                                onClick = { (context as? ComponentActivity)?.lifecycleScope?.launch { unloadWhisperYu() } },
                                                modifier = Modifier.align(Alignment.End)
                                            ) { Text("UNLOAD", color = Color.White, fontWeight = FontWeight.Bold) }
                                        } else if (!whisperYuLoading) {
                                            TextButton(
                                                onClick = {
                                                    prefs.edit().putBoolean("voice_whisper_yu_auto_disabled", false).apply()
                                                    (context as? ComponentActivity)?.lifecycleScope?.launch { installWhisperYu() }
                                                },
                                                modifier = Modifier.align(Alignment.End)
                                            ) { Text("DOWNLOAD", color = Color.White, fontWeight = FontWeight.Bold) }
                                        }
                                    }
                                } else {
                                    Row(
                                        Modifier.fillMaxWidth().padding(vertical = 5.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            when {
                                                whisperYuLoading -> "Montenegrin — $MONTENEGRIN_DOWNLOAD_SIZE — Loading ${whisperYuProgress}%"
                                                whisperYuRecognizer != null -> "Montenegrin — $MONTENEGRIN_DOWNLOAD_SIZE — Ready"
                                                else -> "Montenegrin — $MONTENEGRIN_DOWNLOAD_SIZE — Not installed"
                                            },
                                            color = Color.White,
                                            fontSize = 17.sp,
                                            modifier = Modifier.weight(1f)
                                        )
                                        if (whisperYuRecognizer != null) {
                                            TextButton(onClick = {
                                                (context as? ComponentActivity)?.lifecycleScope?.launch { unloadWhisperYu() }
                                            }) { Text("UNLOAD", color = Color.White, fontWeight = FontWeight.Bold) }
                                        } else if (!whisperYuLoading) {
                                            TextButton(onClick = {
                                                prefs.edit().putBoolean("voice_whisper_yu_auto_disabled", false).apply()
                                                (context as? ComponentActivity)?.lifecycleScope?.launch { installWhisperYu() }
                                            }) { Text("DOWNLOAD", color = Color.White, fontWeight = FontWeight.Bold) }
                                        }
                                    }
                                }
                                whisperYuError?.let {
                                    Text(
                                        if (isPhoneLayout) "Download failed. Tap DOWNLOAD to try again." else it,
                                        color = Color(0xFFFF8A80),
                                        fontSize = if (isPhoneLayout) 12.sp else 13.sp
                                    )
                                }

                                cecilLanguageCatalog.forEach { language ->
                                    val downloadSize = VOSK_LANGUAGE_BY_LABEL[language]?.downloadSize ?: "?"
                                    val loading = voskLanguageLoading[language] == true
                                    val installed = voskInstalled[language] == true
                                    val progress = voskLanguageProgress[language] ?: 0
                                    HorizontalDivider(color = Color.White.copy(alpha = 0.12f), modifier = Modifier.padding(vertical = if (isPhoneLayout) 4.dp else 8.dp))
                                    if (isPhoneLayout) {
                                        Column(Modifier.fillMaxWidth().padding(vertical = 1.dp)) {
                                            Text(
                                                when {
                                                    loading -> "$language — $downloadSize — Loading $progress%"
                                                    installed -> "$language — $downloadSize — Ready"
                                                    else -> "$language — $downloadSize — Not installed"
                                                },
                                                color = Color.White,
                                                fontSize = 14.sp
                                            )
                                            if (installed) {
                                                TextButton(
                                                    onClick = { (context as? ComponentActivity)?.lifecycleScope?.launch { unloadVoskLanguage(language) } },
                                                    modifier = Modifier.align(Alignment.End)
                                                ) { Text("UNLOAD", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                                            } else if (!loading) {
                                                TextButton(
                                                    onClick = { (context as? ComponentActivity)?.lifecycleScope?.launch { installVoskLanguage(language) } },
                                                    modifier = Modifier.align(Alignment.End)
                                                ) { Text("DOWNLOAD", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                                            }
                                            voskLanguageError[language]?.let { Text(it ?: "", color = Color(0xFFFF8A80), fontSize = 12.sp) }
                                        }
                                    } else {
                                        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                when {
                                                    loading -> "$language — $downloadSize — Loading $progress%"
                                                    installed -> "$language — $downloadSize — Ready"
                                                    else -> "$language — $downloadSize — Not installed"
                                                },
                                                color = Color.White,
                                                fontSize = 17.sp,
                                                modifier = Modifier.weight(1f)
                                            )
                                            if (installed) {
                                                TextButton(onClick = { (context as? ComponentActivity)?.lifecycleScope?.launch { unloadVoskLanguage(language) } }) {
                                                    Text("UNLOAD", color = Color.White, fontWeight = FontWeight.Bold)
                                                }
                                            } else if (!loading) {
                                                TextButton(onClick = { (context as? ComponentActivity)?.lifecycleScope?.launch { installVoskLanguage(language) } }) {
                                                    Text("DOWNLOAD", color = Color.White, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                        voskLanguageError[language]?.let { Text(it ?: "", color = Color(0xFFFF8A80), fontSize = 13.sp) }
                                    }
                                }

                            }
                        },
                        confirmButton = {
                            TextButton(onClick = { showSetup = false }) { Text("DONE", color = Color.White) }
                        },
                        containerColor = Color(0xFF111111)
                    )
                }

                if (showToolsPopup) {
                    AlertDialog(
                        onDismissRequest = { showToolsPopup = false; showSetup = true },
                        title = { Text("Tools", color = Color.White) },
                        text = {
                            Column(Modifier.fillMaxWidth()) {
                                Button(
                                    onClick = {
                                        showToolsPopup = false
                                        showSetup = false
                                        showLyricsCleanup = true
                                        lyricsCleanupStatus = "Reading saved cleanup memo…"
                                        scope.launch {
                                            val saved = withContext(Dispatchers.IO) {
                                                rootUri?.let { LyricsCleanupEngine.status(context, it) }
                                            }
                                            lyricsCleanupSummary = saved
                                            lyricsCleanupStatus = when {
                                                rootUri == null -> "Local Lyrics folder is not selected."
                                                saved == null || saved.total == 0 -> "Ready. Originals will not be changed."
                                                saved.completed -> "Saved complete run: ${saved.identified} identified · ${saved.uncertain} uncertain · ${saved.failed} failed."
                                                else -> "Saved checkpoint: ${saved.identified} identified · ${saved.uncertain} uncertain · ${saved.failed} failed. Tap RESUME."
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF202020), contentColor = Color.White)
                                ) { Text("LYRICS CLEANUP — BETA", fontWeight = FontWeight.Bold) }
                            }
                        },
                        confirmButton = { TextButton(onClick = { showToolsPopup = false; showSetup = true }) { Text("CLOSE", color = Color.White) } },
                        containerColor = Color(0xFF111111)
                    )
                }

                if (showSongLanguagePopup) {
                    AlertDialog(
                        onDismissRequest = { showSongLanguagePopup = false; showSetup = true },
                        title = { Text("Song Language", color = Color.White) },
                        text = {
                            Column(Modifier.fillMaxWidth()) {
                                (listOf("English", "Montenegrin") + VOSK_LANGUAGE_SPECS.map { it.label }.filter { it != "English" }).forEach { language ->
                                    val selected = stageLanguage == language || (language.contains("Montenegrin") && stageLanguage.contains("Montenegrin"))
                                    val available = language.contains("Montenegrin") || voskInstalled[language] == true
                                    Button(
                                        onClick = {
                                            if (!available) {
                                                Toast.makeText(context, "$language is not installed — download it in Settings", Toast.LENGTH_SHORT).show()
                                                return@Button
                                            }
                                            stageLanguage = language
                                            prefs.edit().putString("stage_language", language).apply()
                                            showSongLanguagePopup = false
                                            showSetup = true
                                            if (language.contains("Montenegrin")) {
                                                if (stageMicOn) stageRestartToken++
                                            } else {
                                                (context as? ComponentActivity)?.lifecycleScope?.launch {
                                                    try {
                                                        activateVoskLanguage(language)
                                                        if (stageMicOn) stageRestartToken++
                                                    } catch (e: Exception) {
                                                        voskLanguageError[language] = e.message ?: "$language model could not be loaded"
                                                        Toast.makeText(context, voskLanguageError[language] ?: "Voice model load failed", Toast.LENGTH_LONG).show()
                                                    }
                                                }
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (selected) Color.White else Color(0xFF202020),
                                            contentColor = if (selected) Color.Black else Color.White
                                        )
                                    ) { Text(language, fontWeight = FontWeight.Bold) }
                                }
                                Spacer(Modifier.height(8.dp))
                            }
                        },
                        confirmButton = { TextButton(onClick = { showSongLanguagePopup = false; showSetup = true }) { Text("CLOSE", color = Color.White) } },
                        containerColor = Color(0xFF111111)
                    )
                }

                if (showLyricsCleanup) {
                    AlertDialog(
                        onDismissRequest = { showLyricsCleanup = false; showSetup = true },
                        title = { Text("Lyrics Cleanup — BETA", color = Color.White, fontSize = if (isPhoneLayout) 18.sp else 22.sp) },
                        text = {
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = if (isPhoneLayout) 520.dp else 500.dp)
                                    .verticalScroll(rememberScrollState())
                            ) {
                                Text(
                                    "Separate background engine. It reads the Local Lyrics folder you already approved, identifies songs only from TXT filenames/titles, and writes cleaned copies only into ‘${LyricsCleanupEngine.LIBRARY_DIR}’. LyrGig browser/search and the voice engines are not used.",
                                    color = Color(0xFFBDBDBD),
                                    fontSize = if (isPhoneLayout) 12.sp else 14.sp
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    "Original songs stay untouched until you explicitly choose UPDATE EXISTING. Progress is checkpointed inside the new library so a later run can resume instead of starting over.",
                                    color = Color.White,
                                    fontSize = if (isPhoneLayout) 12.sp else 14.sp
                                )
                                Spacer(Modifier.height(12.dp))
                                Button(
                                    enabled = !lyricsCleanupBusy && rootUri != null,
                                    onClick = {
                                        val root = rootUri ?: return@Button
                                        lyricsCleanupBusy = true
                                        lyricsCleanupStatus = "Starting separate cleanup engine…"
                                        scope.launch {
                                            try {
                                                val result = withContext(Dispatchers.IO) {
                                                    LyricsCleanupEngine.cleanup(context, root) { progress ->
                                                        scope.launch {
                                                            lyricsCleanupStatus = "${progress.done}/${progress.total} · ${progress.identified} identified · ${progress.uncertain} uncertain\n${progress.current}"
                                                        }
                                                    }
                                                }
                                                lyricsCleanupSummary = result
                                                lyricsCleanupStatus = "Done: ${result.identified} identified · ${result.uncertain} unresolved · ${result.failed} failed."
                                                val choices = withContext(Dispatchers.IO) { LyricsCleanupEngine.pendingChoices(context, root) }
                                                lyricsCleanupChoices = choices
                                                if (choices.isNotEmpty()) showLyricsCleanup = false
                                            } catch (e: Exception) {
                                                lyricsCleanupStatus = "Cleanup stopped safely. Open it again to resume."
                                            } finally {
                                                lyricsCleanupBusy = false
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF202020), contentColor = Color.White)
                                ) { Text(if (lyricsCleanupBusy) "WORKING…" else if ((lyricsCleanupSummary?.total ?: 0) > 0) "RESUME / CHECK AGAIN" else "START CLEANUP") }

                                if (lyricsCleanupStatus.isNotBlank()) {
                                    Spacer(Modifier.height(10.dp))
                                    Text(lyricsCleanupStatus, color = Color.White, fontSize = if (isPhoneLayout) 12.sp else 14.sp)
                                }

                                val summary = lyricsCleanupSummary
                                if (!lyricsCleanupBusy && summary != null && summary.completed && summary.updateReady > 0) {
                                    Spacer(Modifier.height(12.dp))
                                    HorizontalDivider(color = Color.White.copy(alpha = 0.12f))
                                    Spacer(Modifier.height(10.dp))
                                    Text(
                                        "${summary.updateReady} cleaned song(s) are ready in the separate library.",
                                        color = Color(0xFFFFC107),
                                        fontSize = if (isPhoneLayout) 12.sp else 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedButton(
                                        onClick = {
                                            showLyricsCleanup = false
                                            showLyricsCleanupUpdateConfirm = true
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) { Text("UPDATE EXISTING SONGS") }
                                }
                            }
                        },
                        confirmButton = {
                            TextButton(
                                onClick = { showLyricsCleanup = false; showSetup = true }
                            ) { Text(if (lyricsCleanupBusy) "RUN IN BACKGROUND" else "CLOSE", color = Color.White) }
                        },
                        containerColor = Color(0xFF111111)
                    )
                }

                if (lyricsCleanupChoices.isNotEmpty()) {
                    val pending = lyricsCleanupChoices.first()
                    AlertDialog(
                        onDismissRequest = { },
                        title = { Text(pending.sourceName.removeSuffix(".txt"), color = Color.White) },
                        text = {
                            Column(Modifier.fillMaxWidth().heightIn(max = if (isPhoneLayout) 480.dp else 520.dp).verticalScroll(rememberScrollState())) {
                                Text("More than one song matches this title. Tap the correct one.", color = Color(0xFFBDBDBD), fontSize = if (isPhoneLayout) 12.sp else 14.sp)
                                Spacer(Modifier.height(8.dp))
                                pending.choices.forEach { choice ->
                                    Button(
                                        enabled = !lyricsCleanupChoiceBusy,
                                        onClick = {
                                            val root = rootUri ?: return@Button
                                            lyricsCleanupChoiceBusy = true
                                            scope.launch {
                                                val ok = withContext(Dispatchers.IO) { LyricsCleanupEngine.resolveChoice(context, root, choice.token) }
                                                if (ok) {
                                                    lyricsCleanupChoices = withContext(Dispatchers.IO) { LyricsCleanupEngine.pendingChoices(context, root) }
                                                    lyricsCleanupSummary = withContext(Dispatchers.IO) { LyricsCleanupEngine.status(context, root) }
                                                    if (lyricsCleanupChoices.isEmpty()) {
                                                        lyricsCleanupStatus = "Choices finished. Review results, then UPDATE EXISTING when ready."
                                                        showLyricsCleanup = true
                                                    }
                                                } else {
                                                    lyricsCleanupStatus = "Could not fetch that candidate. Choose another result."
                                                }
                                                lyricsCleanupChoiceBusy = false
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF202020), contentColor = Color.White)
                                    ) { Text("${choice.artist} — ${choice.title}", fontWeight = FontWeight.Bold) }
                                }
                            }
                        },
                        dismissButton = {
                            TextButton(
                                enabled = !lyricsCleanupChoiceBusy,
                                onClick = {
                                    lyricsCleanupChoices = lyricsCleanupChoices.drop(1)
                                    if (lyricsCleanupChoices.isEmpty()) showLyricsCleanup = true
                                }
                            ) { Text("SKIP", color = Color(0xFFBDBDBD)) }
                        },
                        confirmButton = {},
                        containerColor = Color(0xFF111111)
                    )
                }

                if (showLyricsCleanupUpdateConfirm) {
                    AlertDialog(
                        onDismissRequest = {
                            if (!lyricsCleanupBusy) {
                                showLyricsCleanupUpdateConfirm = false
                                showLyricsCleanup = true
                            }
                        },
                        title = { Text("Update existing songs?", color = Color.White) },
                        text = {
                            Text(
                                "This is the first step that changes your existing lyric files. Clean copies remain in ${LyricsCleanupEngine.LIBRARY_DIR}. Continue?",
                                color = Color.White
                            )
                        },
                        confirmButton = {
                            Button(
                                enabled = !lyricsCleanupBusy,
                                onClick = {
                                    val root = rootUri ?: return@Button
                                    showLyricsCleanupUpdateConfirm = false
                                    showLyricsCleanup = true
                                    lyricsCleanupBusy = true
                                    lyricsCleanupStatus = "Updating existing songs…"
                                    scope.launch {
                                        try {
                                            val result = withContext(Dispatchers.IO) {
                                                LyricsCleanupEngine.updateExisting(context, root) { done, total, current ->
                                                    scope.launch { lyricsCleanupStatus = "UPDATE $done/$total\n$current" }
                                                }
                                            }
                                            lyricsCleanupStatus = "Update finished: ${result.first} updated · ${result.second} failed."
                                            runCatching { refreshSongIndex(root) }
                                        } catch (e: Exception) {
                                            lyricsCleanupStatus = "Update stopped safely. Library copies are unchanged."
                                        } finally {
                                            lyricsCleanupBusy = false
                                        }
                                    }
                                }
                            ) { Text("YES, UPDATE") }
                        },
                        dismissButton = {
                            TextButton(
                                enabled = !lyricsCleanupBusy,
                                onClick = {
                                    showLyricsCleanupUpdateConfirm = false
                                    showLyricsCleanup = true
                                }
                            ) { Text("NO", color = Color.White) }
                        },
                        containerColor = Color(0xFF111111)
                    )
                }

                if (showTxtRenamer) {
                    AlertDialog(
                        onDismissRequest = { if (!txtRenamerBusy) showTxtRenamer = false },
                        title = { Text("TXT Renamer", color = Color.White, fontSize = if (isPhoneLayout) 18.sp else 22.sp) },
                        text = {
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = if (isPhoneLayout) 560.dp else 620.dp)
                                    .verticalScroll(rememberScrollState())
                            ) {
                                Text(
                                    "Choose how artist/song are arranged. The renamer cleans spacing, dashes and key notation, then previews every change before renaming.",
                                    color = Color(0xFFBDBDBD),
                                    fontSize = if (isPhoneLayout) 12.sp else 14.sp
                                )
                                Spacer(Modifier.height(10.dp))

                                TxtRenameMode.values().forEach { mode ->
                                    val selected = txtRenameMode == mode
                                    Button(
                                        onClick = {
                                            txtRenameMode = mode
                                            txtRenamerPreview = emptyList()
                                            txtRenamerStatus = "Form selected: ${mode.label}"
                                        },
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (selected) Color.White else Color(0xFF202020),
                                            contentColor = if (selected) Color.Black else Color.White
                                        )
                                    ) {
                                        Text(mode.label, fontSize = if (isPhoneLayout) 13.sp else 15.sp)
                                    }
                                }

                                Spacer(Modifier.height(8.dp))
                                Button(
                                    enabled = !txtRenamerBusy && txtRenameMode != null && rootUri != null,
                                    onClick = {
                                        val mode = txtRenameMode ?: return@Button
                                        val folderUri = rootUri ?: return@Button
                                        txtRenamerBusy = true
                                        txtRenamerStatus = "Scanning Local Lyrics folders…"
                                        scope.launch {
                                            val result = withContext(Dispatchers.IO) {
                                                val root = DocumentFile.fromTreeUri(context, folderUri)
                                                if (root == null || !root.isDirectory || !root.canRead()) emptyList()
                                                else buildList { renamerCollect(root, mode, this) }
                                            }
                                            txtRenamerPreview = result
                                            txtRenamerStatus = if (result.isEmpty()) "Nothing to rename." else "${result.size} change(s) ready. Review, then tap RENAME."
                                            txtRenamerBusy = false
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text(if (txtRenamerBusy) "WORKING…" else "PREVIEW") }

                                if (txtRenamerStatus.isNotBlank()) {
                                    Spacer(Modifier.height(8.dp))
                                    Text(txtRenamerStatus, color = Color.White, fontSize = if (isPhoneLayout) 12.sp else 14.sp)
                                }

                                if (txtRenamerPreview.isNotEmpty()) {
                                    Spacer(Modifier.height(10.dp))
                                    txtRenamerPreview.take(80).forEach { item ->
                                        Text(item.oldName, color = Color(0xFFBDBDBD), fontSize = if (isPhoneLayout) 10.sp else 12.sp)
                                        Text("→ ${item.newName}", color = Color.White, fontSize = if (isPhoneLayout) 10.sp else 12.sp)
                                        Spacer(Modifier.height(5.dp))
                                    }
                                    if (txtRenamerPreview.size > 80) {
                                        Text("…and ${txtRenamerPreview.size - 80} more", color = Color(0xFFBDBDBD), fontSize = 12.sp)
                                    }

                                }

                                if (txtRenamerUndo.isNotEmpty()) {
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedButton(
                                        enabled = !txtRenamerBusy,
                                        onClick = {
                                            val batch = txtRenamerUndo
                                            txtRenamerBusy = true
                                            txtRenamerStatus = "Undoing…"
                                            scope.launch {
                                                try {
                                                    val success = withContext(Dispatchers.IO) {
                                                        var ok = 0
                                                        batch.forEach { item ->
                                                            val restored = runCatching {
                                                                DocumentsContract.renameDocument(context.contentResolver, item.uri, item.oldName) != null
                                                            }.getOrElse {
                                                                false
                                                            }
                                                            if (restored) ok++
                                                        }
                                                        ok
                                                    }
                                                    txtRenamerUndo = emptyList()
                                                    txtRenamerStatus = "$success of ${batch.size} file(s) restored."
                                                    rootUri?.let { runCatching { refreshSongIndex(it) } }
                                                } catch (e: Exception) {
                                                    txtRenamerStatus = "Undo stopped safely. Try again."
                                                } finally {
                                                    txtRenamerBusy = false
                                                }
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) { Text("UNDO LAST RENAME") }
                                }
                            }
                        },
                        confirmButton = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (txtRenamerPreview.isNotEmpty()) {
                                    Button(
                                        enabled = !txtRenamerBusy,
                                        onClick = {
                                            val batch = txtRenamerPreview
                                            txtRenamerBusy = true
                                            txtRenamerStatus = "Renaming…"
                                            scope.launch {
                                                try {
                                                    val (renamed, failed) = withContext(Dispatchers.IO) {
                                                        val ok = mutableListOf<RenamerPreviewItem>()
                                                        var bad = 0
                                                        batch.forEach { item ->
                                                            val renamedUri = runCatching {
                                                                DocumentsContract.renameDocument(context.contentResolver, item.uri, item.newName)
                                                            }.getOrElse {
                                                                null
                                                            }
                                                            if (renamedUri != null) ok += item.copy(uri = renamedUri) else bad++
                                                        }
                                                        ok.toList() to bad
                                                    }
                                                    txtRenamerUndo = renamed
                                                    txtRenamerPreview = emptyList()
                                                    txtRenamerStatus = if (failed == 0) {
                                                        "${renamed.size} of ${batch.size} file(s) renamed."
                                                    } else {
                                                        "${renamed.size} renamed, $failed skipped."
                                                    }
                                                    rootUri?.let { runCatching { refreshSongIndex(it) } }
                                                } catch (e: Exception) {
                                                    txtRenamerStatus = "Rename stopped safely. No app restart. Try again."
                                                } finally {
                                                    txtRenamerBusy = false
                                                }
                                            }
                                        }
                                    ) { Text("RENAME") }
                                }
                                TextButton(onClick = { if (!txtRenamerBusy) showTxtRenamer = false }) { Text("CLOSE", color = Color.White) }
                            }
                        },
                        containerColor = Color(0xFF111111)
                    )
                }

                if (voskModelLoading || whisperYuLoading) {
                    Surface(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 10.dp, start = 12.dp, end = 12.dp)
                            .zIndex(20f),
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0xEE171717),
                        tonalElevation = 6.dp
                    ) {
                        Row(
                            Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.5.dp)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(
                                    when {
                                        voskModelLoading && whisperYuLoading -> "Preparing English + Montenegrin…"
                                        voskModelLoading -> "Preparing English voice…"
                                        else -> "Preparing Montenegrin voice…"
                                    },
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text("This may take a few minutes.", color = Color(0xFFBDBDBD), fontSize = 13.sp)
                            }
                        }
                    }
                }

                if (showConvertPrompt) {
                    AlertDialog(
                        onDismissRequest = {
                            prefs.edit().putString(
                                "convert_pending_fingerprint",
                                pendingFingerprint(pendingConvertibleFiles)
                            ).apply()
                            showConvertPrompt = false
                        },
                        title = {
                            Text(
                                if (convertPromptFirstRun) "Prepare your lyrics?" else "New files found",
                                color = Color.White
                            )
                        },
                        text = {
                            Column {
                                Text(
                                    if (convertPromptFirstRun)
                                        "Convert supported files to LyrGig text?"
                                    else
                                        "Convert new supported files to LyrGig text?",
                                    color = Color.White,
                                    fontSize = 19.sp
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    "PDF, DOCX, RTF, Markdown and HTML. Original files stay unchanged.",
                                    color = Color(0xFFBDBDBD),
                                    fontSize = 14.sp
                                )
                                if (convertingFiles) {
                                    Spacer(Modifier.height(12.dp))
                                    LinearProgressIndicator(Modifier.fillMaxWidth())
                                    if (conversionStatus.isNotBlank()) {
                                        Spacer(Modifier.height(6.dp))
                                        Text(conversionStatus, color = Color(0xFFBDBDBD), fontSize = 13.sp)
                                    }
                                }
                            }
                        },
                        confirmButton = {
                            TextButton(
                                enabled = !convertingFiles,
                                onClick = {
                                    val filesNow = pendingConvertibleFiles
                                    convertingFiles = true
                                    conversionStatus = "Converting ${filesNow.size} file(s)…"
                                    scope.launch {
                                        val (ok, failed) = convertFiles(filesNow)
                                        convertingFiles = false
                                        showConvertPrompt = false
                                        conversionStatus = ""
                                        prefs.edit().putString("convert_pending_fingerprint", "").apply()
                                        rootUri?.let { root ->
                                            listFolder(root)
                                            refreshSongIndex(root)
                                        }
                                        val msg = if (failed == 0) {
                                            "Converted $ok file(s)"
                                        } else {
                                            "Converted $ok • skipped $failed"
                                        }
                                        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                    }
                                }
                            ) { Text("Convert", color = Color.White) }
                        },
                        dismissButton = {
                            TextButton(
                                enabled = !convertingFiles,
                                onClick = {
                                    prefs.edit().putString(
                                        "convert_pending_fingerprint",
                                        pendingFingerprint(pendingConvertibleFiles)
                                    ).apply()
                                    showConvertPrompt = false
                                }
                            ) { Text("Not now", color = Color(0xFFBDBDBD)) }
                        },
                        containerColor = Color(0xFF111111)
                    )
                }

                // ONE bitmap wallpaper for the entire HOME screen.
                // No section owns a separate copy: the same bitmap sits under banner space,
                // Local/Web search, folders and the bottom stage controls.
                if (isRoot) {
                    Image(
                        painter = painterResource(id = R.drawable.lyrgig_music_stand_banner),
                        contentDescription = null,
                        contentScale = if (isPhoneLayout) ContentScale.Fit else ContentScale.FillBounds,
                        alignment = Alignment.Center,
                        modifier = Modifier
                            .matchParentSize()
                            .alpha(1.0f)
                    )
                }

                if (openedText == null && !showWebSearch && rootUri != null && !isPhoneLayout) {
                    // Tablet keeps the existing top-right Settings button unchanged.
                    TextButton(
                        onClick = { showSetup = true },
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 4.dp, end = 6.dp)
                            .size(52.dp)
                            .zIndex(5f),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("⚙", color = Color.White.copy(alpha = 0.88f), fontSize = 28.sp)
                    }
                }

                Column(Modifier.fillMaxSize()) {
                if (rootUri == null) {
                    // If the user cancels the Android picker, keep the app here instead of
                    // pretending there is already a root folder.
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        OutlinedButton(onClick = { folderPicker.launch(null) }) {
                            Text("CHOOSE MAIN FOLDER", color = Color.White)
                        }
                    }
                } else if (showWebSearch) {
                    if (extractedLyrics != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { extractedLyrics = null }) {
                                Text("Web", color = Color.White, fontSize = 18.sp)
                            }
                            Text(
                                text = extractedTitle.ifBlank { webSearchQuery },
                                color = Color.White,
                                fontSize = 36.sp,
                                maxLines = 1,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(
                                onClick = { saveExtractedLyrics() },
                                modifier = Modifier.height(58.dp)
                            ) {
                                Text(
                                    "Save",
                                    color = Color(0xFF4CAF50),
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                        Text(
                            text = extractedLyrics ?: "",
                            color = Color.White,
                            fontSize = fontSize.sp,
                            lineHeight = (fontSize * 1.35f).sp,
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                                .padding(horizontal = 18.dp, vertical = 8.dp)
                        )
                    } else {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(68.dp)
                                .padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "🌍  ${webSearchQuery.ifBlank { "Web lyrics" }}",
                                color = Color.White,
                                fontSize = 18.sp,
                                maxLines = 1,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(
                                onClick = { extractLyricsFromWeb() },
                                modifier = Modifier.height(58.dp)
                            ) {
                                Text(
                                    "Extract lyrics",
                                    color = Color(0xFF4CAF50),
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                        if (candidateChoices.isNotEmpty()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 18.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = "Choose the right song",
                                    color = Color.White,
                                    fontSize = 20.sp
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    text = candidateChoiceQuery,
                                    color = Color.Gray,
                                    fontSize = 14.sp
                                )
                                Spacer(Modifier.height(8.dp))

                                candidateChoices.forEach { (title, urlValue) ->
                                    Text(
                                        text = title,
                                        color = Color.White,
                                        fontSize = 17.sp,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                candidateChoices = emptyList()
                                                autoExtractActive = true
                                                autoCandidateOpened = true
                                                webSearchUrl = urlValue
                                                webViewRef?.loadUrl(urlValue)
                                            }
                                            .padding(vertical = 10.dp)
                                    )
                                }

                                Divider(color = Color.DarkGray)
                                Text(
                                    text = "Show web results",
                                    color = Color.Gray,
                                    fontSize = 15.sp,
                                    modifier = Modifier
                                        .clickable {
                                            candidateChoices = emptyList()
                                            autoExtractActive = false
                                        }
                                        .padding(vertical = 10.dp)
                                )
                            }
                        }

                        if (autoExtractActive) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    CircularProgressIndicator(color = Color.White)
                                    Spacer(Modifier.height(14.dp))
                                    Text("Finding lyrics…", color = Color.White, fontSize = 18.sp)
                                }
                            }
                        }

                        AndroidView(
                            factory = { ctx ->
                                WebView(ctx).apply {
                                    settings.javaScriptEnabled = true
                                    settings.domStorageEnabled = true
                                    settings.loadsImagesAutomatically = true
                                    configureWebViewForDarkStage(this)
                                    webViewClient = object : WebViewClient() {
                                        override fun onPageFinished(view: WebView, url: String?) {
                                            super.onPageFinished(view, url)

                                            // Keep the embedded browser stage-dark even when a page does not
                                            // advertise its own dark theme. Algorithmic darkening above does
                                            // most of the work; this removes white flashes/backgrounds.
                                            view.evaluateJavascript(
                                                """
                                                (function() {
                                                  try {
                                                    document.documentElement.style.colorScheme = 'dark';
                                                    document.documentElement.style.backgroundColor = '#000000';
                                                    if (document.body) document.body.style.backgroundColor = '#000000';
                                                    var meta = document.querySelector('meta[name=\"theme-color\"]');
                                                    if (!meta) {
                                                      meta = document.createElement('meta');
                                                      meta.name = 'theme-color';
                                                      document.head && document.head.appendChild(meta);
                                                    }
                                                    if (meta) meta.content = '#000000';
                                                  } catch (e) {}
                                                })();
                                                """.trimIndent(),
                                                null
                                            )

                                            if (webSearchQuery.isBlank()) return

                                            val current = url.orEmpty()

                                            if (autoExtractActive && current.contains("google.", ignoreCase = true)) {
                                                // Search page: first detect a true no-results page.
                                                view.evaluateJavascript(
                                                    "(document.body && document.body.innerText ? document.body.innerText : '').toLowerCase()"
                                                ) { bodyJson ->
                                                    val body = try {
                                                        org.json.JSONTokener(bodyJson).nextValue() as? String ?: ""
                                                    } catch (_: Exception) { "" }

                                                    val noResults = body.contains("did not match any documents") ||
                                                        body.contains("no results found") ||
                                                        body.contains("nema rezultata")

                                                    if (noResults && !autoExtractTriedText) {
                                                        autoExtractTriedText = true
                                                        val fallback = webSearchUrlFor(webSearchQuery, "text")
                                                        webSearchUrl = fallback
                                                        view.loadUrl(fallback)
                                                        return@evaluateJavascript
                                                    }

                                                    // Collect a few normal text-page candidates instead of
                                                    // silently choosing the first hit. This avoids opening the
                                                    // wrong song when several artists use the same title.
                                                    val collectResultsJs = """
                                                        (function() {
                                                          const out = [];
                                                          const seen = new Set();
                                                          const links = Array.from(document.querySelectorAll('a[href]'));
                                                          for (const a of links) {
                                                            const h = (a.href || '').trim();
                                                            if (!/^https?:/i.test(h)) continue;
                                                            const low = h.toLowerCase();
                                                            if (low.includes('google.')) continue;
                                                            if (low.includes('youtube.com') || low.includes('youtu.be')) continue;
                                                            if (low.includes('/video') || low.includes('/shorts')) continue;
                                                            if (seen.has(h)) continue;

                                                            let label = (a.innerText || '').replace(/\\s+/g, ' ').trim();
                                                            if (label.length < 3) continue;
                                                            if (label.length > 120) label = label.slice(0, 120);

                                                            seen.add(h);
                                                            out.push({title: label, url: h});
                                                            if (out.length >= 5) break;
                                                          }
                                                          return JSON.stringify(out);
                                                        })();
                                                    """.trimIndent()

                                                    view.evaluateJavascript(collectResultsJs) { candidatesJson ->
                                                        try {
                                                            val outer = if (candidatesJson == null || candidatesJson == "null") "" else
                                                                org.json.JSONTokener(candidatesJson).nextValue() as? String ?: ""
                                                            val arr = org.json.JSONArray(outer)
                                                            val parsed = buildList {
                                                                for (i in 0 until arr.length()) {
                                                                    val item = arr.optJSONObject(i) ?: continue
                                                                    val title = item.optString("title").trim()
                                                                    val urlValue = item.optString("url").trim()
                                                                    if (title.isNotBlank() && urlValue.isNotBlank()) {
                                                                        add(title to urlValue)
                                                                    }
                                                                }
                                                            }

                                                            if (parsed.size == 1) {
                                                                autoCandidateOpened = true
                                                                view.loadUrl(parsed.first().second)
                                                            } else if (parsed.isNotEmpty()) {
                                                                candidateChoices = parsed
                                                                autoExtractActive = false
                                                            } else if (!autoExtractTriedText) {
                                                                autoExtractTriedText = true
                                                                val fallback = webSearchUrlFor(webSearchQuery, "text")
                                                                webSearchUrl = fallback
                                                                view.loadUrl(fallback)
                                                            } else {
                                                                autoExtractActive = false
                                                                Toast.makeText(context, "Web fallback", Toast.LENGTH_SHORT).show()
                                                            }
                                                        } catch (_: Exception) {
                                                            autoExtractActive = false
                                                            Toast.makeText(context, "Web fallback", Toast.LENGTH_SHORT).show()
                                                        }
                                                    }
                                                }
                                            } else if (autoExtractActive && autoCandidateOpened) {
                                                // Candidate text page: try extracting immediately.
                                                view.evaluateJavascript(lyricsExtractionJs()) { result ->
                                                    applyExtractedResult(view, result, automatic = true)
                                                }
                                            }
                                        }
                                    }
                                    webViewRef = this
                                    webSearchUrl?.let { loadUrl(it) }
                                }
                            },
                            update = { view ->
                                webViewRef = view
                                val target = webSearchUrl
                                if (target != null && view.url != target && view.url.isNullOrBlank()) {
                                    view.loadUrl(target)
                                }
                            },
                            modifier = if (autoExtractActive || candidateChoices.isNotEmpty()) {
                                Modifier
                                    .fillMaxWidth()
                                    .height(1.dp)
                            } else {
                                Modifier
                                    .weight(1f)
                                    .fillMaxWidth()
                            }
                        )
                    }
                } else if (openedText != null) {
                    // Reader: simple linear NEXT LINE tracker. No searching ahead, no GPS logic.
                    val lyricListState = rememberLazyListState()
                    LaunchedEffect(stageLineIndex, stageMicOn) {
                        if (stageMicOn && stageLineIndex >= 0) {
                            val layout = lyricListState.layoutInfo
                            val visible = layout.visibleItemsInfo
                            if (visible.isNotEmpty()) {
                                val viewportStart = layout.viewportStartOffset
                                val viewportEnd = layout.viewportEndOffset
                                val viewportHeight = (viewportEnd - viewportStart).coerceAtLeast(1)
                                val twoThirdsY = viewportStart + (viewportHeight * 2 / 3)
                                val gentlePageStep = (viewportHeight / 4).toFloat()
                                val target = visible.firstOrNull { it.index == stageLineIndex }

                                if (target != null) {
                                    val targetCenter = target.offset + target.size / 2
                                    if (targetCenter >= twoThirdsY) {
                                        // Teleprompter-style movement: the line walks down through
                                        // the page; only at 2/3 do we gently lift the page by 1/4.
                                        lyricListState.animateScrollBy(gentlePageStep)
                                    }
                                } else if (stageLineIndex > visible.last().index) {
                                    // Ignored blank/ref lines can make the next lyric land just
                                    // beyond the viewport. Reveal it gently, without jumping to top.
                                    lyricListState.animateScrollBy(gentlePageStep)
                                }
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .then(if (isPhoneLayout) Modifier.windowInsetsPadding(WindowInsets.statusBars) else Modifier)
                            .height(if (isPhoneLayout) 72.dp else 58.dp)
                            .padding(horizontal = if (isPhoneLayout) 6.dp else 8.dp)
                    ) {
                        TextButton(
                            onClick = {
                                bb2Snapshot = BB2.snapshot(context)
                                showBb2 = true
                            },
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .size(width = if (isPhoneLayout) 42.dp else 50.dp, height = if (isPhoneLayout) 40.dp else 48.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) { Text("BB2", color = Color(0xFFFFD38A), fontSize = if (isPhoneLayout) 10.sp else 12.sp, fontWeight = FontWeight.Bold) }

                        TextButton(
                            onClick = { showCpuMonitor = true },
                            modifier = Modifier.align(Alignment.CenterStart).padding(start = if (isPhoneLayout) 84.dp else 100.dp).size(if (isPhoneLayout) 40.dp else 48.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) { Text("CPU", color = Color(0xFF8AD8FF), fontSize = if (isPhoneLayout) 10.sp else 12.sp, fontWeight = FontWeight.Bold) }

                        TextButton(
                            onClick = { showSetup = true },
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .padding(start = if (isPhoneLayout) 42.dp else 50.dp)
                                .size(if (isPhoneLayout) 40.dp else 48.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) { Text("⚙", color = Color.White, fontSize = if (isPhoneLayout) 22.sp else 26.sp) }

                        Text(
                            text = openedTitle.removeSuffix(".txt"),
                            color = Color.White,
                            fontSize = if (isPhoneLayout) 15.sp else 18.sp,
                            maxLines = 1,
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .padding(start = if (isPhoneLayout) 84.dp else 100.dp)
                                .fillMaxWidth(if (isPhoneLayout) 0.20f else 0.27f),
                            textAlign = TextAlign.Start
                        )

                        Button(
                            onClick = {
                                if (stageMicOn) {
                                    stageMicOn = false
                                    BB2.event(context, "MIC_STATE", "state" to "OFF", "reason" to "user")
                                } else if (stageLanguage.contains("Montenegrin") && whisperYuRecognizer == null) {
                                    Toast.makeText(context, whisperYuError ?: if (whisperYuLoading) "Downloading Montenegrin voice ${whisperYuProgress}%…" else "Montenegrin voice is not installed — open Settings", Toast.LENGTH_SHORT).show()
                                } else if (!stageLanguage.contains("Montenegrin") && (voskEnglishModel == null || voskActiveLanguage != stageLanguage)) {
                                    val loading = voskLanguageLoading[stageLanguage] == true || (stageLanguage == "English" && voskModelLoading)
                                    val progress = if (stageLanguage == "English") voskModelProgress else (voskLanguageProgress[stageLanguage] ?: 0)
                                    val error = if (stageLanguage == "English") voskModelError else voskLanguageError[stageLanguage]
                                    Toast.makeText(context, error ?: if (loading) "Downloading $stageLanguage $progress%…" else "$stageLanguage voice is not installed or loaded — open Settings", Toast.LENGTH_SHORT).show()
                                } else if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                    stageMicOn = true
                                    BB2.event(context, "MIC_STATE", "state" to "ON", "reason" to "user")
                                    if (stageLineIndex < 0) stageLineIndex = initialStageLine()
                                    stageRestartToken++
                                } else {
                                    stagePermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            },
                            modifier = Modifier
                                .align(Alignment.Center)
                                .width(if (isPhoneLayout) 126.dp else 164.dp)
                                .height(if (isPhoneLayout) 48.dp else 54.dp)
                                .border(
                                    width = 2.dp,
                                    color = if (stageMicOn) Color(0xFF8DFF9B) else Color(0xFFB78A4A),
                                    shape = RoundedCornerShape(16.dp)
                                )
                                .background(
                                    brush = Brush.verticalGradient(
                                        if (stageMicOn) listOf(Color(0xFF124C25), Color(0xFF061B0C), Color.Black)
                                        else listOf(Color(0xFF4A4033), Color(0xFF17130F), Color.Black)
                                    ),
                                    shape = RoundedCornerShape(16.dp)
                                ),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.Transparent,
                                contentColor = if (stageMicOn) Color(0xFF72FF83) else Color(0xFFFFD38A)
                            ),
                            contentPadding = PaddingValues(horizontal = if (isPhoneLayout) 8.dp else 12.dp, vertical = 4.dp)
                        ) {
                            Text(
                                if (stageMicOn) "LYR SYNC  ON" else if (voskModelLoading) "LYR SYNC  ${voskModelProgress}%" else if (whisperYuLoading) "LYR SYNC  ${whisperYuProgress}%" else "LYR SYNC  OFF",
                                fontSize = if (isPhoneLayout) 12.sp else 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Row(modifier = Modifier.align(Alignment.CenterEnd), verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = {
                                fontSize = (fontSize - 2f).coerceAtLeast(16f)
                                prefs.edit().putFloat("font_size", fontSize).apply()
                            }) { Text("A−", color = Color.White, fontSize = if (isPhoneLayout) 15.sp else 18.sp) }
                            TextButton(onClick = {
                                fontSize = (fontSize + 2f).coerceAtMost(60f)
                                prefs.edit().putFloat("font_size", fontSize).apply()
                            }) { Text("A+", color = Color.White, fontSize = if (isPhoneLayout) 15.sp else 18.sp) }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        LazyColumn(
                            state = lyricListState,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 18.dp, vertical = 8.dp)
                        ) {
                        items(stageLines.size) { index ->
                            // VISUAL KEY: paint THREE PHYSICALLY ADJACENT displayed rows.
                            // This is display-only: matcher filtering still uses nextStageLine().
                            val visualNextLine = if (stageLineIndex in stageLines.indices && stageLineIndex + 1 < stageLines.size) stageLineIndex + 1 else -1
                            val visualThirdLine = if (stageLineIndex in stageLines.indices && stageLineIndex + 2 < stageLines.size) stageLineIndex + 2 else -1
                            // LUX highlight: same orange -> red -> purple language, dimmed 20%,
                            // but blended continuously so the three adjacent bars read as one stage cue.
                            val luxOrange = Color(0xFF8F3900)
                            val luxRed = Color(0xFF921616)
                            val luxPurple = Color(0xFF55167B)
                            val orangeRed = Color(0xFF912812)
                            val redPurple = Color(0xFF741649)
                            val highlightBrush = if (!stageMicOn) null else when (index) {
                                stageLineIndex -> Brush.verticalGradient(listOf(luxOrange, orangeRed))
                                visualNextLine -> Brush.verticalGradient(listOf(orangeRed, luxRed, redPurple))
                                visualThirdLine -> Brush.verticalGradient(listOf(redPurple, luxPurple))
                                else -> null
                            }
                            val highlighted = highlightBrush != null
                            val singerSliceBitmap = if (highlighted) {
                                val singerSlice = when (index) {
                                    stageLineIndex -> R.drawable.lyrgig_singer_top
                                    visualNextLine -> R.drawable.lyrgig_singer_mid
                                    else -> R.drawable.lyrgig_singer_bottom
                                }
                                remember(singerSlice) { ImageBitmap.imageResource(context.resources, singerSlice) }
                            } else null
                            Text(
                                text = stageLines[index],
                                color = if (highlighted) Color(0xFFFFFF00) else Color.White,
                                fontSize = fontSize.sp,
                                lineHeight = (fontSize * 1.35f).sp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .then(highlightBrush?.let { Modifier.clip(RoundedCornerShape(7.dp)).background(it) } ?: Modifier)
                                    .drawWithContent {
                                        singerSliceBitmap?.let { bitmap ->
                                            // Singer is paint-only: keep the lyric row geometry untouched.
                                            // Each bitmap is one vertical third of the same upright singer.
                                            // Draw that slice only in the right corner, preserving the 3-row composition.
                                            val singerWidth = (size.width * 0.24f).toInt()
                                            val singerLeft = size.width.toInt() - singerWidth
                                            drawImage(
                                                image = bitmap,
                                                dstOffset = androidx.compose.ui.unit.IntOffset(singerLeft, 0),
                                                dstSize = androidx.compose.ui.unit.IntSize(singerWidth, size.height.toInt()),
                                                alpha = 0.18f
                                            )
                                        }
                                        drawContent()
                                    }
                                    .clickable(enabled = !stageIgnoreLine(stageLines[index])) {
                                        stageLineIndex = index
                                        if (stageMicOn) stageRestartToken++
                                    }
                                    .padding(horizontal = if (highlighted) 6.dp else 0.dp, vertical = 1.dp)
                            )
                        }
                    }
                    }
                } else {
                    if (isRoot) {
                        // Home content floats over the single root-level bitmap wallpaper.
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        ) {
                            Column(
                                Modifier
                                    .fillMaxSize()
                                    // Phone only: keep the complete main/header content below Android status bar.
                                    // Bottom navigation is outside this column and remains untouched.
                                    .then(if (isPhoneLayout) Modifier.windowInsetsPadding(WindowInsets.statusBars) else Modifier)
                            ) {
                                // Phone: lower the whole main content slightly; bottom navigation stays fixed.
                                if (isPhoneLayout) Spacer(Modifier.height(18.dp))
                                // Stage title over the single wallpaper.
                                Text(
                                    text = "LyrGig",
                                    color = Color(0xFF00E676).copy(alpha = 0.80f),
                                    fontSize = if (isPhoneLayout) 36.sp else 45.sp,
                                    fontWeight = FontWeight.Light,
                                    fontFamily = FontFamily.Cursive,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(
                                            top = if (isPhoneLayout) 6.dp else 10.dp,
                                            bottom = if (isPhoneLayout) 10.dp else 18.dp
                                        )
                                )

                                BoxWithConstraints(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp)
                                ) {
                                    // One shared width = Local and Web fields are exactly the same length.
                                    // Phone keeps the same touch-first UI, but compacts chrome instead of
                                    // blindly shrinking the tablet screen. Android chooses this at runtime.
                                    val micSize = if (isPhoneLayout) 72.dp else 98.dp
                                    val globeSize = if (isPhoneLayout) 52.dp else 68.dp
                                    val sizeControlColumnWidth = if (isPhoneLayout) 52.dp else 72.dp
                                    val sizeControlWidth = if (isPhoneLayout) 48.dp else 66.dp
                                    val sizeControlHeight = if (isPhoneLayout) 46.dp else 56.dp
                                    val fieldMinHeight = if (isPhoneLayout) 54.dp else 58.dp
                                    val fieldPlaceholderSp = if (isPhoneLayout) 17.sp else 21.sp
                                    val fieldTextSp = if (isPhoneLayout) 20.sp else 24.sp
                                    val rowGap = if (isPhoneLayout) 6.dp else 8.dp
                                    val safeFieldWidth = if (isPhoneLayout) {
                                        (maxWidth - micSize - globeSize - 28.dp).coerceAtLeast(150.dp)
                                    } else {
                                        (maxWidth - 204.dp).coerceAtLeast(120.dp)
                                    }
                                    val searchFieldWidth = if (isPhoneLayout) {
                                        (maxWidth * 0.52f).coerceAtMost(safeFieldWidth)
                                    } else {
                                        (maxWidth * 0.50f).coerceAtMost(safeFieldWidth)
                                    }

                                    Column(Modifier.fillMaxWidth()) {
                                        // LOCAL: anchored to the left edge.
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            OutlinedTextField(
                                                value = searchQuery,
                                                onValueChange = { doSearch(it) },
                                                placeholder = { Text("Local lyrics", fontSize = fieldPlaceholderSp) },
                                                singleLine = true,
                                                shape = RoundedCornerShape(14.dp),
                                                textStyle = LocalTextStyle.current.copy(fontSize = fieldTextSp),
                                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                                keyboardActions = KeyboardActions(
                                                    onSearch = { doSearch(searchQuery) },
                                                    onDone = { doSearch(searchQuery) }
                                                ),
                                                modifier = Modifier
                                                    .width(searchFieldWidth)
                                                    .heightIn(min = fieldMinHeight),
                                                colors = OutlinedTextFieldDefaults.colors(
                                                    focusedTextColor = Color.White,
                                                    unfocusedTextColor = Color.White,
                                                    focusedBorderColor = Color.White,
                                                    unfocusedBorderColor = Color.White,
                                                    cursorColor = Color.White,
                                                    focusedPlaceholderColor = Color(0xFFB0B0B0),
                                                    unfocusedPlaceholderColor = Color(0xFFB0B0B0),
                                                    focusedContainerColor = Color.Black.copy(alpha = 0.88f),
                                                    unfocusedContainerColor = Color.Black.copy(alpha = 0.82f)
                                                )
                                            )

                                            Spacer(Modifier.width(rowGap))

                                            Surface(
                                                modifier = Modifier
                                                    .size(micSize)
                                                    .clickable { launchVoiceSearch() },
                                                color = Color.Black.copy(alpha = 0.90f),
                                                contentColor = Color.White,
                                                shape = RoundedCornerShape(18.dp),
                                                border = androidx.compose.foundation.BorderStroke(2.dp, Color.White)
                                            ) {
                                                MicGlyph(Modifier.fillMaxSize().padding(if (isPhoneLayout) 10.dp else 13.dp))
                                            }

                                            // Keep text-size controls away from the mic so they are easy to tap on stage.
                                            Spacer(Modifier.weight(1f))

                                            Box(
                                                modifier = Modifier.width(sizeControlColumnWidth)
                                            ) {
                                                Column(
                                                    modifier = Modifier.width(sizeControlColumnWidth),
                                                    horizontalAlignment = Alignment.CenterHorizontally,
                                                    verticalArrangement = Arrangement.spacedBy(if (isPhoneLayout) 6.dp else 8.dp)
                                                ) {
                                                    Surface(
                                                        modifier = Modifier
                                                            .width(sizeControlWidth)
                                                            .height(sizeControlHeight)
                                                            .clickable {
                                                                listFontSize = (listFontSize + 2f).coerceAtMost(48f)
                                                                prefs.edit().putFloat("list_font_size", listFontSize).apply()
                                                            },
                                                        color = Color.Black.copy(alpha = 0.78f),
                                                        contentColor = Color.White,
                                                        shape = RoundedCornerShape(15.dp),
                                                        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color.White)
                                                    ) {
                                                        Box(contentAlignment = Alignment.Center) {
                                                            Text("+", color = Color.White, fontSize = if (isPhoneLayout) 28.sp else 32.sp, fontWeight = FontWeight.Light)
                                                        }
                                                    }
                                                    Surface(
                                                        modifier = Modifier
                                                            .width(sizeControlWidth)
                                                            .height(sizeControlHeight)
                                                            .clickable {
                                                                listFontSize = (listFontSize - 2f).coerceAtLeast(16f)
                                                                prefs.edit().putFloat("list_font_size", listFontSize).apply()
                                                            },
                                                        color = Color.Black.copy(alpha = 0.78f),
                                                        contentColor = Color.White,
                                                        shape = RoundedCornerShape(15.dp),
                                                        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color.White)
                                                    ) {
                                                        Box(contentAlignment = Alignment.Center) {
                                                            Text("−", color = Color.White, fontSize = if (isPhoneLayout) 28.sp else 32.sp, fontWeight = FontWeight.Light)
                                                        }
                                                    }
                                                }

                                                if (isPhoneLayout) {
                                                    // Phone only: Settings sits clearly ABOVE +/− with breathing room,
                                                    // without changing the existing +/− positions.
                                                    TextButton(
                                                        onClick = { showSetup = true },
                                                        modifier = Modifier
                                                            .align(Alignment.TopCenter)
                                                            .offset(y = (-58).dp)
                                                            .size(sizeControlWidth)
                                                            .zIndex(6f),
                                                        contentPadding = PaddingValues(0.dp)
                                                    ) {
                                                        Text("⚙", color = Color.White.copy(alpha = 0.88f), fontSize = 25.sp)
                                                    }
                                                }
                                            }
                                        }

                                        Spacer(Modifier.height(if (isPhoneLayout) 6.dp else 8.dp))

                                        // WEB: mirrored visual weight; field is anchored to the right edge.
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.End
                                        ) {
                                            Surface(
                                                modifier = Modifier
                                                    .size(micSize)
                                                    .clickable { launchWebVoiceSearch() },
                                                color = Color.Black.copy(alpha = 0.90f),
                                                contentColor = Color.White,
                                                shape = RoundedCornerShape(18.dp),
                                                border = androidx.compose.foundation.BorderStroke(2.dp, Color.White)
                                            ) {
                                                MicGlyph(Modifier.fillMaxSize().padding(if (isPhoneLayout) 10.dp else 13.dp))
                                            }

                                            Spacer(Modifier.width(rowGap))

                                            Surface(
                                                modifier = Modifier
                                                    .size(globeSize)
                                                    .clickable { launchWebSearch(webSearchQuery) },
                                                color = Color.Black.copy(alpha = 0.90f),
                                                contentColor = Color.White,
                                                shape = RoundedCornerShape(16.dp),
                                                border = androidx.compose.foundation.BorderStroke(2.dp, Color.White)
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Text("🌍", fontSize = if (isPhoneLayout) 26.sp else 33.sp)
                                                }
                                            }

                                            Spacer(Modifier.width(rowGap))

                                            OutlinedTextField(
                                                value = webSearchQuery,
                                                onValueChange = { webSearchQuery = it },
                                                placeholder = { Text("Web lyrics", fontSize = fieldPlaceholderSp) },
                                                singleLine = true,
                                                shape = RoundedCornerShape(14.dp),
                                                textStyle = LocalTextStyle.current.copy(fontSize = fieldTextSp),
                                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                                keyboardActions = KeyboardActions(
                                                    onSearch = { launchWebSearch(webSearchQuery) },
                                                    onDone = { launchWebSearch(webSearchQuery) }
                                                ),
                                                modifier = Modifier
                                                    .width(searchFieldWidth)
                                                    .heightIn(min = fieldMinHeight),
                                                colors = OutlinedTextFieldDefaults.colors(
                                                    focusedTextColor = Color.White,
                                                    unfocusedTextColor = Color.White,
                                                    focusedBorderColor = Color.White,
                                                    unfocusedBorderColor = Color.White,
                                                    cursorColor = Color.White,
                                                    focusedPlaceholderColor = Color(0xFFB0B0B0),
                                                    unfocusedPlaceholderColor = Color(0xFFB0B0B0),
                                                    focusedContainerColor = Color.Black.copy(alpha = 0.88f),
                                                    unfocusedContainerColor = Color.Black.copy(alpha = 0.82f)
                                                )
                                            )
                                        }
                                    }
                                }

                                val homeList = if (searching) {
                                    searchResults
                                } else {
                                    entries.filterNot {
                                        it.isDirectory && it.name.equals("Downloaded Lyrics", ignoreCase = true)
                                    }
                                }

                                // Library area + tiny live MIC trim. The three gain buttons begin at
                                // the same left edge as Local lyrics (12 dp) and run downward from Downloaded.
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .weight(1f)
                                ) {
                                    Column(Modifier.fillMaxSize()) {
                                        if (!searching && rootUri != null) {
                                            // More separation from search so Downloaded Lyrics reads as library, not search.
                                            Spacer(Modifier.height(if (isPhoneLayout) 18.dp else 34.dp))
                                            Box(
                                                modifier = Modifier
                                                    .align(Alignment.CenterHorizontally)
                                                    .fillMaxWidth(if (isPhoneLayout) 0.68f else 0.46f)
                                                    .height(if (isPhoneLayout) 38.dp else 40.dp)
                                                    .clip(RoundedCornerShape(16.dp))
                                                    .background(Color(0xFF1E1E1E).copy(alpha = 0.88f))
                                                    .clickable {
                                                        val folder = downloadedLyricsUri
                                                            ?: rootUri?.let { ensureDownloadedLyricsFolder(it) }
                                                        if (folder != null) navigateTo(NavLocation(folder))
                                                    },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = "Downloaded",
                                                    color = Color(0xFFD0D0D0),
                                                    fontSize = if (isPhoneLayout) 18.sp else 24.sp,
                                                    fontWeight = FontWeight.Medium,
                                                    textAlign = TextAlign.Center
                                                )
                                            }
                                            Spacer(Modifier.height(if (isPhoneLayout) 10.dp else 18.dp))
                                        }

                                        HomeBrowserList(
                                            listToShow = homeList,
                                            searching = searching,
                                            listFontSize = listFontSize,
                                            modifier = Modifier.weight(1f),
                                            showDownloaded = false,
                                            onDownloadedClick = {
                                                val folder = downloadedLyricsUri ?: rootUri?.let { ensureDownloadedLyricsFolder(it) }
                                                if (folder != null) navigateTo(NavLocation(folder))
                                            },
                                            onEntryClick = { item ->
                                                if (item.isDirectory) {
                                                    currentUri?.let { navigateTo(NavLocation(item.uri)) }
                                                } else {
                                                    val folder = currentUri ?: rootUri
                                                    if (folder != null) {
                                                        navigateTo(NavLocation(folder, item.uri, item.name))
                                                    }
                                                }
                                            }
                                        )
                                    }

                                    if (!searching && rootUri != null) {
                                        val stageButtonWidth = if (isPhoneLayout) 58.dp else 72.dp
                                        val stageButtonHeight = if (isPhoneLayout) 22.dp else 27.dp
                                        val stageLedSize = if (isPhoneLayout) 7.dp else 9.dp
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier
                                                .align(Alignment.TopEnd)
                                                .padding(
                                                    end = 12.dp,
                                                    top = if (isPhoneLayout) 18.dp else 34.dp
                                                )
                                                .height(stageButtonHeight)
                                                .zIndex(5f)
                                                .clickable { setStageClean(!stageCleanOn) }
                                        ) {
                                            Surface(
                                                modifier = Modifier
                                                    .width(stageButtonWidth)
                                                    .height(stageButtonHeight),
                                                color = if (stageCleanOn) Color.White else Color.Transparent,
                                                contentColor = if (stageCleanOn) Color.Black else Color.White,
                                                shape = RoundedCornerShape(if (isPhoneLayout) 8.dp else 9.dp),
                                                border = androidx.compose.foundation.BorderStroke(
                                                    1.dp,
                                                    if (stageCleanOn) Color.White else Color.White.copy(alpha = 0.38f)
                                                )
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Text(
                                                        text = "Stage",
                                                        color = if (stageCleanOn) Color.Black else Color.White.copy(alpha = 0.82f),
                                                        fontSize = if (isPhoneLayout) 9.sp else 11.sp,
                                                        fontWeight = FontWeight.Medium,
                                                        maxLines = 1
                                                    )
                                                }
                                            }
                                            Spacer(Modifier.width(if (isPhoneLayout) 10.dp else 12.dp))
                                            if (stageCleanOn) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(stageLedSize)
                                                        .clip(androidx.compose.foundation.shape.CircleShape)
                                                        .background(Color(0xFF00E676))
                                                )
                                            } else {
                                                Spacer(Modifier.size(stageLedSize))
                                            }
                                        }

                                        val gainButtonWidth = if (isPhoneLayout) 58.dp else 72.dp
                                        val gainButtonHeight = if (isPhoneLayout) 22.dp else 27.dp
                                        val gainLedSize = if (isPhoneLayout) 7.dp else 9.dp
                                        val gainRowWidth = gainButtonWidth + (if (isPhoneLayout) 28.dp else 34.dp)
                                        Column(
                                            modifier = Modifier
                                                .align(Alignment.TopStart)
                                                .padding(
                                                    start = 12.dp,
                                                    top = if (isPhoneLayout) 18.dp else 34.dp
                                                )
                                                .zIndex(5f),
                                            horizontalAlignment = Alignment.Start,
                                            verticalArrangement = Arrangement.spacedBy(if (isPhoneLayout) 4.dp else 5.dp)
                                        ) {
                                            Text(
                                                text = "Quiet gig",
                                                color = Color.White.copy(alpha = 0.72f),
                                                fontSize = if (isPhoneLayout) 9.sp else 11.sp,
                                                fontWeight = FontWeight.Light,
                                                modifier = Modifier.width(gainButtonWidth),
                                                textAlign = TextAlign.Center
                                            )
                                            for (gain in listOf(7, 5, 2, 0, -2, -5)) {
                                                val selected = micGainDb == gain
                                                val label = when {
                                                    gain > 0 -> "+${gain} dB"
                                                    gain < 0 -> "${gain} dB"
                                                    else -> "0 dB"
                                                }
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    modifier = Modifier
                                                        .width(gainRowWidth)
                                                        .height(gainButtonHeight)
                                                        // Whole row consumes the tap so the first gain press cannot fall through
                                                        // to the folder list underneath during recomposition.
                                                        .clickable { setMicGainDb(gain) }
                                                ) {
                                                    Surface(
                                                        modifier = Modifier
                                                            .width(gainButtonWidth)
                                                            .height(gainButtonHeight),
                                                        color = if (selected) Color.White else Color.Transparent,
                                                        contentColor = if (selected) Color.Black else Color.White,
                                                        shape = RoundedCornerShape(if (isPhoneLayout) 8.dp else 9.dp),
                                                        border = androidx.compose.foundation.BorderStroke(
                                                            1.dp,
                                                            if (selected) Color.White else Color.White.copy(alpha = 0.38f)
                                                        )
                                                    ) {
                                                        Box(contentAlignment = Alignment.Center) {
                                                            Text(
                                                                text = label,
                                                                color = if (selected) Color.Black else Color.White.copy(alpha = 0.82f),
                                                                fontSize = if (isPhoneLayout) 9.sp else 11.sp,
                                                                fontWeight = FontWeight.Medium,
                                                                maxLines = 1
                                                            )
                                                        }
                                                    }
                                                    Spacer(Modifier.width(if (isPhoneLayout) 10.dp else 12.dp))
                                                    if (selected) {
                                                        Box(
                                                            modifier = Modifier
                                                                .size(gainLedSize)
                                                                .clip(androidx.compose.foundation.shape.CircleShape)
                                                                .background(if (micClipping) Color(0xFFFF2D2D) else Color(0xFF00E676))
                                                        )
                                                    } else {
                                                        Spacer(Modifier.size(gainLedSize))
                                                    }
                                                }
                                            }
                                            Text(
                                                text = "Loud gig",
                                                color = Color.White.copy(alpha = 0.72f),
                                                fontSize = if (isPhoneLayout) 9.sp else 11.sp,
                                                fontWeight = FontWeight.Light,
                                                modifier = Modifier.width(gainButtonWidth),
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        // Inside folders: deliberately minimal.
                        Text(
                            text = currentTitle,
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        )

                        BrowserList(
                            listToShow = if (searching) searchResults else entries,
                            searching = searching,
                            listFontSize = listFontSize,
                            modifier = Modifier.weight(1f),
                            onEntryClick = { item ->
                                if (item.isDirectory) {
                                    navigateTo(NavLocation(item.uri))
                                } else {
                                    val folder = currentUri ?: return@BrowserList
                                    navigateTo(NavLocation(folder, item.uri, item.name))
                                }
                            }
                        )
                    }
                }

                // Stage controls: back, HOME, donate, forward.
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(if (isPhoneLayout) Modifier.windowInsetsPadding(WindowInsets.navigationBars) else Modifier)
                        .height(if (isPhoneLayout) 96.dp else 104.dp)
                        .padding(horizontal = 2.dp, vertical = if (isPhoneLayout) 8.dp else 0.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = { goBack() },
                        enabled = searching || backHistory.isNotEmpty(),
                        modifier = Modifier.size(if (isPhoneLayout) 72.dp else 92.dp),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        NavChevron(
                            pointsRight = false,
                            modifier = Modifier.size(if (isPhoneLayout) 62.dp else 82.dp)
                        )
                    }

                    TextButton(
                        onClick = { goHome() },
                        enabled = rootUri != null && !isRoot,
                        modifier = Modifier.size(if (isPhoneLayout) 62.dp else 76.dp),
                        contentPadding = PaddingValues(if (isPhoneLayout) 7.dp else 8.dp)
                    ) {
                        HomeGlyph(Modifier.fillMaxSize())
                    }

                    Column(
                        modifier = Modifier
                            .clickable { openDonate() }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("♥", color = Color(0xFFE53935), fontSize = if (isPhoneLayout) 31.sp else 36.sp, lineHeight = if (isPhoneLayout) 29.sp else 34.sp)
                        Text(
                            "Donate",
                            color = Color.White,
                            fontSize = if (isPhoneLayout) 15.sp else 18.sp,
                            fontFamily = FontFamily.Cursive,
                            lineHeight = if (isPhoneLayout) 17.sp else 20.sp
                        )
                    }

                    TextButton(
                        onClick = { goForward() },
                        enabled = forwardHistory.isNotEmpty(),
                        modifier = Modifier.size(if (isPhoneLayout) 72.dp else 92.dp),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        NavChevron(
                            pointsRight = true,
                            modifier = Modifier.size(if (isPhoneLayout) 62.dp else 82.dp)
                        )
                    }
                }
            }
            

                if (!stageWarmupDone) {
                    Surface(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 14.dp)
                            .zIndex(50f),
                        color = Color.Black.copy(alpha = 0.88f),
                        shape = RoundedCornerShape(18.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF666666))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp,
                                color = Color(0xFFFFC107)
                            )
                            Spacer(Modifier.width(9.dp))
                            Text("LYRIC SYNC LOADING…", color = Color.White, fontSize = 14.sp)
                        }
                    }
                }
}
        }
    }
}

@Composable
private fun BrowserEntryText(
    text: String,
    requestedFontSize: Float,
    fontWeight: FontWeight
) {
    // Browser polish: keep every song/folder title on one line. Only the long
    // entry shrinks; normal titles keep the user's chosen large browser font.
    val minimumFontSize = 16f
    var fittedFontSize by remember(text, requestedFontSize) {
        mutableStateOf(requestedFontSize)
    }

    Text(
        text = text,
        color = Color.White,
        fontSize = fittedFontSize.sp,
        fontWeight = fontWeight,
        textAlign = TextAlign.Center,
        maxLines = 1,
        softWrap = false,
        modifier = Modifier.fillMaxWidth(),
        onTextLayout = { result ->
            if (result.didOverflowWidth && fittedFontSize > minimumFontSize) {
                fittedFontSize = (fittedFontSize - 1f).coerceAtLeast(minimumFontSize)
            }
        }
    )
}

@Composable
private fun HomeBrowserList(
    listToShow: List<Entry>,
    searching: Boolean,
    listFontSize: Float,
    modifier: Modifier = Modifier,
    showDownloaded: Boolean,
    onDownloadedClick: () -> Unit,
    onEntryClick: (Entry) -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(vertical = 8.dp)
    ) {
        items(listToShow, key = { it.uri.toString() }) { item ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onEntryClick(item) }
                    .padding(horizontal = 18.dp, vertical = 13.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                BrowserEntryText(
                    text = if (item.isDirectory) "›  ${item.name}" else item.name.removeSuffix(".txt"),
                    requestedFontSize = listFontSize,
                    fontWeight = if (item.isDirectory) FontWeight.SemiBold else FontWeight.Normal
                )
                if (searching && item.pathLabel.isNotBlank()) {
                    Text(
                        text = item.pathLabel,
                        color = Color.Gray,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }

        if (showDownloaded) {
            item(key = "__downloaded_lyrics__") {
                Column(Modifier.fillMaxWidth()) {
                    HorizontalDivider(
                        modifier = Modifier.padding(horizontal = 32.dp, vertical = 4.dp),
                        thickness = 1.dp,
                        color = Color(0xFF555555)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Downloaded",
                        color = Color(0xFFD0D0D0),
                        fontSize = (listFontSize - 6f).coerceAtLeast(12f).sp,
                        fontWeight = FontWeight.Normal,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onDownloadedClick() }
                            .padding(horizontal = 18.dp, vertical = 8.dp)
                    )
                }
            }
        }

        if (searching && listToShow.isEmpty()) {
            item {
                Text(
                    text = "Nema rezultata.",
                    color = Color.Gray,
                    fontSize = 18.sp,
                    modifier = Modifier.fillMaxWidth().padding(20.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun BrowserList(
    listToShow: List<Entry>,
    searching: Boolean,
    listFontSize: Float,
    modifier: Modifier = Modifier,
    onEntryClick: (Entry) -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(vertical = 8.dp)
    ) {
        items(listToShow, key = { it.uri.toString() }) { item ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onEntryClick(item) }
                    .padding(horizontal = 18.dp, vertical = 13.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                BrowserEntryText(
                    text = if (item.isDirectory) "›  ${item.name}" else item.name.removeSuffix(".txt"),
                    requestedFontSize = listFontSize,
                    fontWeight = if (item.isDirectory) FontWeight.SemiBold else FontWeight.Normal
                )

                if (searching && item.pathLabel.isNotBlank()) {
                    Text(
                        text = item.pathLabel,
                        color = Color.Gray,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }

        if (searching && listToShow.isEmpty()) {
            item {
                Text(
                    text = "Nema rezultata.",
                    color = Color.Gray,
                    fontSize = 18.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun NavChevron(
    pointsRight: Boolean,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val insetX = size.width * 0.28f
        val insetY = size.height * 0.18f
        val centerY = size.height / 2f
        val leftX = insetX
        val rightX = size.width - insetX
        val tipX = if (pointsRight) rightX else leftX
        val outerX = if (pointsRight) leftX else rightX

        val path = Path().apply {
            moveTo(outerX, insetY)
            lineTo(tipX, centerY)
            lineTo(outerX, size.height - insetY)
        }

        drawPath(
            path = path,
            color = Color.White,
            style = Stroke(
                width = size.minDimension * 0.095f,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }
}

@Composable
private fun HomeGlyph(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val stroke = size.minDimension * 0.10f
        val left = size.width * 0.20f
        val right = size.width * 0.80f
        val roofY = size.height * 0.43f
        val peakY = size.height * 0.18f
        val bottomY = size.height * 0.82f
        val cx = size.width / 2f

        val roof = Path().apply {
            moveTo(left, roofY)
            lineTo(cx, peakY)
            lineTo(right, roofY)
        }
        drawPath(
            path = roof,
            color = Color.White,
            style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        val body = Path().apply {
            moveTo(size.width * 0.28f, roofY * 0.95f)
            lineTo(size.width * 0.28f, bottomY)
            lineTo(size.width * 0.72f, bottomY)
            lineTo(size.width * 0.72f, roofY * 0.95f)
        }
        drawPath(
            path = body,
            color = Color.White,
            style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        drawLine(
            color = Color.White,
            start = Offset(size.width * 0.46f, bottomY),
            end = Offset(size.width * 0.46f, size.height * 0.62f),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color.White,
            start = Offset(size.width * 0.46f, size.height * 0.62f),
            end = Offset(size.width * 0.60f, size.height * 0.62f),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color.White,
            start = Offset(size.width * 0.60f, size.height * 0.62f),
            end = Offset(size.width * 0.60f, bottomY),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
    }
}

@Composable
private fun MiniMicLogo(modifier: Modifier = Modifier) {
    MicGlyph(modifier)
}

@Composable
private fun MicGlyph(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val top = h * 0.12f
        val bottom = h * 0.58f
        val radius = w * 0.18f

        drawRoundRect(
            color = Color.White,
            topLeft = Offset(cx - radius, top),
            size = androidx.compose.ui.geometry.Size(radius * 2f, bottom - top),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius)
        )

        drawArc(
            color = Color.White,
            startAngle = 0f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = Offset(w * 0.20f, h * 0.26f),
            size = androidx.compose.ui.geometry.Size(w * 0.60f, h * 0.48f),
            style = Stroke(width = w * 0.08f, cap = StrokeCap.Round)
        )

        drawLine(
            color = Color.White,
            start = Offset(cx, h * 0.70f),
            end = Offset(cx, h * 0.88f),
            strokeWidth = w * 0.08f,
            cap = StrokeCap.Round
        )

        drawLine(
            color = Color.White,
            start = Offset(w * 0.34f, h * 0.88f),
            end = Offset(w * 0.66f, h * 0.88f),
            strokeWidth = w * 0.08f,
            cap = StrokeCap.Round
        )
    }
}
