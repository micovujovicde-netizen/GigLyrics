// BB2 MATRIX
// Reference-only event matrix for future BB2 work.
// No logger/runtime code is executed by this file.

const BB2_MATRIX = Object.freeze({
  version: "BB2_MATRIX_V1",
  enabledByDefault: false,

  events: Object.freeze({
    APP_START:      { id: 1,  fields: ["ts"] },
    SONG_OPEN:      { id: 2,  fields: ["ts", "song", "language", "engine"] },
    MIC_STATE:      { id: 3,  fields: ["ts", "state", "reason"] },
    ENGINE_SWITCH:  { id: 4,  fields: ["ts", "from", "to"] },
    MODEL_LOAD:     { id: 5,  fields: ["ts", "language", "model"] },
    MODEL_CLOSE:    { id: 6,  fields: ["ts", "language", "reason", "ok"] },
    RECOGNIZER:     { id: 7,  fields: ["ts", "engine", "state", "language"] },
    ADVANCE:        { id: 8,  fields: ["ts", "engine", "fromLine", "toLine", "reason"] },
    ERROR:          { id: 9,  fields: ["ts", "area", "message"] },
    CPU_SAMPLE:     { id: 10, fields: ["ts", "engine", "language", "processPct", "devicePct", "cores"] }
  }),

  // Intentionally NOT part of BB2:
  forbiddenSpam: Object.freeze([
    "CECIL_PARTIAL",
    "CECIL_HOLD",
    "WHISPER_HEARD",
    "WHISPER_HOLD",
    "MATCH_SCORE_TRACE",
    "LIVE_TEXT_RENDER"
  ])
});

if (typeof module !== "undefined") {
  module.exports = BB2_MATRIX;
}
