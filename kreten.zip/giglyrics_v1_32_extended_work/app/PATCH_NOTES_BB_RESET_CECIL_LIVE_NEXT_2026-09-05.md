# BB reset + Cecil LIVE NEXT — 2026-09-05

- BLACK BOX is cleared once at the start of each real app process/session, then immediately writes `=== APP SESSION START ===`. Activity recreation inside the same process does not erase it.
- Cecil keeps Vosk English audio/model path, but its lyric-advance policy now mirrors Whisper LIVE NEXT.
- Cecil may score only CURRENT + NEXT for the decision; advance requires evidence for NEXT.
- A characteristic NEXT word may advance +1. Generic/shared words alone do not.
- Cecil whole-line fallback now requires NEXT to be the best candidate; a strong CURRENT match can no longer advance.
- One Vosk recognition result still advances at most one valid lyric line.
