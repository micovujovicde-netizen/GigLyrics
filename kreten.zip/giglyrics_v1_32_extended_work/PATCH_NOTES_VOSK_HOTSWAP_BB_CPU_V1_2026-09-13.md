# VOSK_HOTSWAP_CLOSE_V1 + BB_RESET_CPU_V1

- Vosk language hot-swap now waits for the active Cecil recognizer to close before closing the old Vosk Model.
- Adds Black Box lifecycle evidence: VOSK_SWITCH_CHECK, VOSK_MODEL_CLOSE, VOSK_SWITCH_READY, CECIL_RECOGNIZER_OPEN/CLOSE.
- Switching from any Vosk language to Montenegrin/Whisper also closes the old Vosk Model after the recognizer drains.
- Black Box dialog now has RESET and CHECK buttons.
- CHECK writes current mic latch, song, detected language, engine, active Vosk model, and live Cecil recognizer count.
- Black Box records process CPU every 10 seconds while voice-follow is actively listening; includes process % and whole-device normalized %.
