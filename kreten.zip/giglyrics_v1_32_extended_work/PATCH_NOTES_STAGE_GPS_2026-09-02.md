# NEXT LINE — Stage GPS update

- Matching is local around the current lyric position, not global across the whole song.
- Search window: 16 lines backward / 24 lines forward.
- Backward matching intentionally supports shorthand repeats such as `Ref. 2x` where the chorus is written only once.
- Position is used as a tie-breaker for identical repeated choruses, preventing long accidental teleports.
- Stronger recognized speech can still move the cursor when the singer deliberately skips lines.
- After identifying the line currently sung, the following nonblank line becomes the highlighted NEXT line.
- NEXT LINE highlight remains orange with yellow text, no font-size change.
- Added a compact SM58-style handheld microphone drawing beside the MIC control.
