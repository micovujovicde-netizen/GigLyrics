# v93 — Settings tools popup + root-based TXT Renamer

- TOOLS is now a single button at the top of Settings; TXT RENAMER lives inside its popup.
- SONG LANGUAGE is a single Settings button opening a language popup. Current live choices are English and Montenegrin / EX-YU.
- TXT Renamer no longer asks for SELECT FOLDER. It uses the already persisted Local Lyrics SAF root and scans its existing folder tree.
- Actual rename/undo uses DocumentsContract.renameDocument on the existing SAF child URI.
- Cecil/Whisper matcher and timing logic were not intentionally changed.
