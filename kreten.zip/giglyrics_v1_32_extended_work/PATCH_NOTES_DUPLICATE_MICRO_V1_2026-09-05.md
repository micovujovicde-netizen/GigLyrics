# DUPLICATE_MICRO_V1 — 2026-09-05

Micro-only patch for identical consecutive lyric rows.

- Activates only when normalized CURRENT == normalized NEXT.
- Cecil: first sung occurrence arms the duplicate gate; only a second complete occurrence in cumulative Vosk, or a new strong post-final utterance, may advance exactly +1.
- Whisper: first strong occurrence arms; only two non-overlapping whole-line occurrences inside the rolling decode may advance exactly +1.
- For identical pairs the normal one-word/full-matcher path is suppressed, preventing the first occurrence from skipping prematurely.
- Non-identical rows keep the v59 Cecil and Whisper logic unchanged.
- Cecil two-key v58/v59 behavior and Whisper two-key v1 behavior are otherwise untouched.
