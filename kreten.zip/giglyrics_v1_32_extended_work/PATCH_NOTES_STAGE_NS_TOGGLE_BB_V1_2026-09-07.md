# v89 — Stage NS toggle + BB info

- Added a compact **Stage** button on the HOME screen to the right of Downloaded, matching the gain-button visual language.
- Green LED is lit while Stage is ON.
- Stage state persists in app preferences.
- Stage ON requests Android `NoiseSuppressor` on the actual `VOICE_RECOGNITION` AudioRecord session for both Whisper and Cecil when the device exposes it.
- BB logs the user toggle (`STAGE ON/OFF`) and per-engine runtime capability/result (`STAGE_INFO ... nsAvailable=... nsEnabled=...`).
- If the device does not expose NoiseSuppressor, recognition continues normally and BB records that it was unavailable.
- Whisper NEXT2 remains 0.19; Whisper/Cecil matching and anti-jump logic were not changed.
