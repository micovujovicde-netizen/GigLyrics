# MIC gain selector 4/2/0 dB — v78

- Replaces the fixed +4 dB input boost with a persistent 3-step selector: +4 dB / +2 dB / 0 dB.
- Applies identically to Cecil and Whisper before ASR; matcher/timing logic is untouched.
- Default for a fresh install is +2 dB; the last selection is remembered.
- Home screen: three small vertical controls aligned with the left edge of Local lyrics, beginning at the Downloaded row and extending downward.
- Button footprint is approximately one horizontal half of the Earth control: same width, about half height.
- OFF = transparent with a faint outline; ON = solid white with black text.
- No other UI/engine behavior intentionally changed.
