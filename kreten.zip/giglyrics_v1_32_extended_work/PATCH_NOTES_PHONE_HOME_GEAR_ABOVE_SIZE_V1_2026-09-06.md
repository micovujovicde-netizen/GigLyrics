# PHONE HOME GEAR ABOVE SIZE V1 — v75

- Phone HOME only: move Settings gear from Android status-bar area to immediately above the existing + / − text-size controls.
- + and − keep their existing layout positions; gear is overlaid above them.
- Tablet HOME Settings placement is unchanged.
- No other UI or voice-engine logic changed.
