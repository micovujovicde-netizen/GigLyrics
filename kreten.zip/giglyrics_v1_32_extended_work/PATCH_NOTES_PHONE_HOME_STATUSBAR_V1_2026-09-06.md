# LyrGig v74 — Phone home status-bar clearance

- PHONE ONLY: applies Android status-bar inset to the complete main/home content column.
- Keeps LyrGig title/settings area below phone system status icons.
- Bottom navigation bar is outside this column and unchanged.
- Tablet path is unchanged.
- Cecil/Whisper matcher/timing and MIC audio paths are unchanged.
