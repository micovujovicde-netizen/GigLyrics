# Whisper NEXT2 threshold 0.17 — v83

- Changed only the NEXT2 evidence absolute score threshold from 0.28 to 0.17.
- NEXT2 remains evidence only: it can advance CURRENT to NEXT only, never directly to NEXT2.
- Maximum advance per Whisper recognition result remains +1 valid lyric line.
- NEXT gate unchanged.
- Cecil matcher untouched.
- Whisper timing remains 2.8 s / 280 ms.
