# Whisper LIVE NEXT tuning — 2026-09-05

- Whisper advances only on evidence for NEXT, never merely because CURRENT was recognized.
- One characteristic NEXT word may advance +1.
- Generic/common words or words shared with CURRENT need additional NEXT-line evidence.
- Conservative noisy-token recovery accepts a clear expected word embedded with <=2 extra glued characters, e.g. `sgitarom -> gitarom`.
- Full matcher fallback may advance only when NEXT itself is the best candidate.
- Whisper rolling audio context increased from 2.0 s to 2.8 s; decode cadence stays 600 ms.
- Existing max-one-valid-line anti-jump guard remains.
- Cecil branch is not changed by this Whisper patch.
