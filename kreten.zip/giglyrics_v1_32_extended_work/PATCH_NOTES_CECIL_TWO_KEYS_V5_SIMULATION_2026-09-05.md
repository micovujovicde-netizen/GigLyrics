# Cecil TWO KEYS V5 — simulation correction

A pre-pack simulation exposed a real false-sharing edge case: CURRENT `sing` could fuzzy-match NEXT `spring`, preventing the intended NEXT-tail trigger.

Correction: fuzzy matching remains strictly one-way from the newly arrived Vosk tail to NEXT. The CURRENT-vs-NEXT "shared word" test is now exact-normalized only. This preserves noisy inputs such as `astars -> stars`, `starss -> stars`, and `jupter -> jupiter` without letting unrelated CURRENT words suppress a valid NEXT characteristic word.

Build marker: `BUILD CECIL_TWO_KEYS_V5 SMART_HEADER_V2 v58`.
