# Whisper latency 3.0 s / 350 ms — 2026-09-05

- Whisper rolling audio window: 2.0 s -> 3.0 s.
- Whisper decode cadence: 400 ms -> 350 ms.
- Whisper Recycle V3 unchanged.
- Duplicate micro unchanged.
- Cecil logic unchanged.
- Build marker: WHISPER_LATENCY_3S_350MS v64.
