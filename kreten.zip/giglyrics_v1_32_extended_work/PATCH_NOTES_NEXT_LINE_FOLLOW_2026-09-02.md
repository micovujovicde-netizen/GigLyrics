# GigLyrics NEXT LINE follow patch — 2026-09-02

- MIC tracking no longer requires strict line-by-line progression.
- Each recognition result searches forward from the current stage position.
- The nearest matching sung lyric wins; highlight moves to the next nonblank line.
- This naturally skips labels such as `Ref. 2x` and catches the singer after forward jumps.
- Repeated choruses prefer the nearest forward occurrence to reduce accidental large jumps.
- NEXT LINE highlight background changed from dark red to orange (`#B85A00`).
- Yellow lyric text and font size are unchanged.
