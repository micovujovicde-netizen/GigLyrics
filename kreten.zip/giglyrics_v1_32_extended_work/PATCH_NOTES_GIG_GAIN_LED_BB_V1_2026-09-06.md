# LyrGig v80 — GIG GAIN LED + BB V1

- Gain selector labels: Loud gig (+2 dB), Normal gig (+5 dB), Quiet gig (+7 dB).
- Compact elongated buttons; inactive option LED is invisible.
- Selected option LED is green and turns red for ~650 ms when post-gain PCM clipping is detected.
- Gain remains shared by Cecil and Whisper input paths; frozen matcher/timing logic is unchanged.
- Settings gets a BB button. BB opens the bounded internal Black Box log in a selectable text window with COPY and CLOSE.
- No main-screen redesign beyond the approved gain selector presentation.
