# v67 — UI Settings + automatic primary voice preparation

UI/setup-only pass around the locked v66 live engines.

- English/Cecil and Montenegrin/EX-YU/Whisper now prepare automatically in parallel in the background on first setup.
- Non-blocking startup indicator: “This may take a few minutes.”
- Settings is English-only and shows Ready/Loading/Not installed state.
- Ready primary models expose UNLOAD. Manual UNLOAD is respected and prevents immediate automatic re-download; DOWNLOAD restores it on demand.
- Added an English-language Cecil language catalog in Settings without changing the locked live matcher/engine path.
- Translated remaining user-facing Montenegrin button/prompt text to English.
- Cecil matcher, Whisper matcher/recycle, duplicate handling, smart header, and Whisper 2.8 s / 280 ms timing are unchanged.
