# FRANKI 747 clean retry patch

- DOWNLOAD 747 clears interrupted/incomplete Franki files before retry.
- A complete valid model is preserved.
- Old archive/unpack/import staging is cleared automatically.
- Installed-model detection validates minimum file sizes.
