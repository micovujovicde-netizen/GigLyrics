# PHONE HOME GEAR LOWER V1 — 2026-09-06

- Phone-only home-screen adjustment.
- Lowered the settings gear from y offset -52 dp to -36 dp.
- Gear remains above the + / - controls on the same right-side vertical.
- Tablet layout unchanged.
- No voice matcher/timing or other UI behavior changed.
