# LYRICS CLEANUP — GLOBAL PROVIDER V1 (v96)

- Cleanup remains completely separate from LyrGig WebView/search and from Cecil/Whisper.
- Added provider-neutral lookup interface.
- Preferred path: one LyrGig matcher backend (`LYRGIG_MATCHER_BASE_URL`) which can aggregate licensed/global providers per market without putting provider keys in the APK.
- GitHub/Gradle configuration: pass `-PLYRGIG_MATCHER_BASE_URL=https://your-matcher.example`.
- Backend contract: POST `/v1/identify` with short lyric fingerprint queries; returns `candidates` with artist/title/source/id and preferably lyrics.
- Genius is retained only as isolated BETA fallback while no global backend is configured.
- Fixed Kotlin regex escaping introduced in v95 (`\\s`, character-class escaping), which could break GitHub compilation.
- Version: 1.96-lyrics-cleanup-global-provider-v1 / code 96.
- MainActivity and frozen Cecil/Whisper logic are untouched.
