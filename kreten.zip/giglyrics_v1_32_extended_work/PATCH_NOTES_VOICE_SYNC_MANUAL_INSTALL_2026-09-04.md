# v1.59 Manual Automatic Voice Lyrics Sync install

- First app launch offers optional AUTOMATIC VOICE LYRICS SYNC once.
- NOT NOW is remembered; the offer does not nag on every launch.
- Setup always keeps the option available later.
- INSTALL opens the public sherpa-onnx Omnilingual model archive download.
- GigLyrics no longer tries to download/extract the large model itself.
- Setup provides SELECT MODEL FOLDER after the user extracts the archive.
- The app searches the selected folder (and up to 3 nested levels) for model.int8.onnx and tokens.txt, copies them into app-private storage with progress, verifies them, then starts the offline recognizer.
- MIC routes users to Setup when the voice model is not installed.
