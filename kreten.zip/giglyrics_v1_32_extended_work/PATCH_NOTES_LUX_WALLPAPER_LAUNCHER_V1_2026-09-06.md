# v84 — LUX wallpaper + launcher
- Replaced HOME music-stage bitmap with the approved final dim blank-book LUX image.
- Runtime wallpaper alpha is 1.0: no additional transparency/filter.
- Replaced launcher artwork with the approved original full-visibility blank-book LUX image, square-cropped only for Android launcher geometry.
- Whisper/Cecil matcher logic unchanged from v83.
