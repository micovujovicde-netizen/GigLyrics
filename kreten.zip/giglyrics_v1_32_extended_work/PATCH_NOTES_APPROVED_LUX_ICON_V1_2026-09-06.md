# APPROVED LUX ICON V1 — 2026-09-06

- Launcher icon source is the user-approved close crop of the blank open book + upper music stand + left warm stage light.
- No new artwork, text, frame, badge, or redesign added.
- Original transparent pixels are composited onto pure black before launcher use, so there are no white crop/background areas.
- Square 1024x1024 launcher bitmap; Android applies its normal launcher mask.
- App runtime, Cecil, Whisper, thresholds, timing, and HOME background are unchanged from v84.
