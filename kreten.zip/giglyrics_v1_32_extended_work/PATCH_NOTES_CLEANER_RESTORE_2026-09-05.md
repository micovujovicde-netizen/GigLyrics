# Cleaner / Restore engine — 2026-09-05

- Setup keeps one ĐŽČĆŠ button only.
- ĐŽČĆŠ RUN recursively processes .txt lyrics under the selected GigLyrics root.
- STRANE is hard-skipped.
- Originals of every changed file are backed up in app-private storage before writing.
- When RUN finishes, the same button becomes ĐŽČĆŠ BACK.
- BACK restores the backed-up originals and removes the backup set.
- No extra popup/toast is shown by RUN/BACK.
- CECIL + WHISPER remain merged into the existing single voice button.

This Android build uses a conservative offline diacritic lexicon plus whitespace/layout normalization; it does not embed an OpenAI API key.
