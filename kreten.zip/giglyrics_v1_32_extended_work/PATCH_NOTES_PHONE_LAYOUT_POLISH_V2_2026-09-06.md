# v73 phone layout polish V2
- Phone main/root content moved slightly lower; bottom navigation bar unchanged.
- Phone Settings typography and spacing compacted so substantially more content fits without wrapping/crowding.
- Song/stage Settings gear moved to the left side of the top control bar.
- Voice recognition matcher/timing logic unchanged.
