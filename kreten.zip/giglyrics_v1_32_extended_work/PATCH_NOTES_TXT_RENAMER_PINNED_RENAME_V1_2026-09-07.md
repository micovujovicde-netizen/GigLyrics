# TXT Renamer pinned RENAME — v91

- Fixes the TXT Renamer preview action being below the scroll viewport.
- After PREVIEW produces changes, RENAME is now pinned in the AlertDialog action row next to CLOSE.
- The rename operation itself is unchanged.
- No voice matcher/timing changes.
