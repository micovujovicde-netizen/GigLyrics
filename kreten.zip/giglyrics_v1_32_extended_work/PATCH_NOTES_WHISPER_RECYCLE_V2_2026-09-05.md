# Whisper recycle V2 — 2026-09-05

Micro-only change. Cecil logic untouched. Duplicate logic untouched.

Whisper gets a second, looser fuzzy tier only for characteristic NEXT words. Generic/common words keep the previous strict matcher, full-line thresholds are unchanged, and one recognition result still advances at most one valid lyric line.
