# Smart single-line header skip

On song open, if the file starts with exactly one physical non-blank line at index 0 and the next physical row is blank, that first row is treated as a header/metadata/title and the lyric cursor starts at the first valid line after the blank separator. Otherwise startup behavior is unchanged.
