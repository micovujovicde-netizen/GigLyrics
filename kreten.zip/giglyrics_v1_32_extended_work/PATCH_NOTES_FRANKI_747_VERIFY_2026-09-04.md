# FRANKI 747 installer fix

- Removed arbitrary 100 MB / 1 KB installed-file thresholds.
- Download now rejects a short HTTP body when Content-Length is known.
- TAR extraction now validates each selected file against the TAR entry size.
- Extraction read loop no longer treats a zero-byte read as EOF.
- Existing retry cleanup remains in place.
