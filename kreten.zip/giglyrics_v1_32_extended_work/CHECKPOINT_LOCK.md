# GigLyrics checkpoint lock — Cecil + Whisper YU

Base: v1.53 montpoland-segment-lock.

DO NOT TOUCH without explicit user instruction:
- CECIL/Vosk English recognition path and its matcher behavior.
- Main GigLyrics browsing/search/lyrics UI.

This experiment changes only the EX-YU listener:
- English remains CECIL (Vosk English).
- EX-YU routes to a separate Sherpa-ONNX Whisper tiny multilingual INT8 listener.
- Whisper model is NOT bundled in APK. Setup downloads encoder+decoder+tokens directly (~100 MB total) into app-private storage.
- No FRANKI / 747 code is included.

Rule for next patch: one change at a time; diff must not modify the locked Cecil branch.
