# Whisper NEXT2 loose ramp V1 — 2026-09-06

- Scope: Whisper only. Cecil matcher untouched.
- CURRENT + NEXT + NEXT2 remains the lookahead model.
- NEXT keeps the existing full matcher gate: score >= 0.46 and lead >= 0.04.
- NEXT2 is evidence-only and now deliberately much looser: score >= 0.28 and lead >= 0.01.
- NEXT2 can only cause CURRENT -> NEXT. It can never jump directly to NEXT2.
- BB adds `n2e=` and uses `reason=next2` when this path advances.
- Whisper rolling window remains 2.8 s / 280 ms.
- Global three-row highlight and music-stand visibility unchanged.
