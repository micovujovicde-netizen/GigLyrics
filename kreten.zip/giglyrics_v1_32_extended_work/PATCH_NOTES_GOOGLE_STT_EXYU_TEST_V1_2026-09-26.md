# Google STT EX-YU test lane — 2026-09-26

- Montenegrin/EX-YU LYR SYNC runtime now uses Android/Google SpeechRecognizer instead of Whisper.
- Cecil/Vosk path for all other configured languages is left intact.
- Google lane uses the same device-default locale as the existing voice-search feature.
- Cycle: listen -> partial/final result -> lyric matcher -> immediate restart (0 ms app delay).
- Busy/client errors use only a 120 ms safety retry.
- Existing CURRENT/NEXT/NEXT2 matching and +1 anti-jump behavior are retained for the EX-YU lane.
- BB2 logs START_REQUEST, READY, END_SPEECH and RESTART timings so STOP->START behavior can be measured on the real tablet.
- Old Whisper source is retained in this TEST source package as rollback code, but it is no longer auto-loaded/downloaded or used by Montenegrin LYR SYNC.
