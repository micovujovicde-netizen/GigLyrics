# Singer +10% visibility / LYR SYNC font fit

- Approved singer bitmap visibility increased by exactly 10% relative: alpha 0.130 -> 0.143.
- Singer bitmap, position, scale, cue bars and lyric text unchanged.
- LYR SYNC label font reduced only to fit inside the existing button: phone 13sp -> 11sp, tablet 16sp -> 14sp.
- Button dimensions, mic icon, Cecil, Whisper and 5.5s touch hint unchanged.
