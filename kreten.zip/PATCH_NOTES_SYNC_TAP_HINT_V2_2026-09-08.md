# SYNC tap hint V2 — 2026-09-08

- Keeps the existing OFF -> ON visual hint only; no matcher/playback behavior changed.
- Total animation duration increased from 3.5 s to 5.5 s.
- Center tap: 2.25 s.
- Lower tap: 2.25 s.
- Final fade: 1.0 s.
- Fingertip/touch drawing enlarged to exactly 250% of the previous geometry, including its tap ripple and motion scale.
- Overlay remains non-interactive and does not consume touches.
- Cecil, Whisper, NEXT/NEXT2, lyric-bar artwork, singer watermark, toolbar mic/gear are untouched by this patch.
