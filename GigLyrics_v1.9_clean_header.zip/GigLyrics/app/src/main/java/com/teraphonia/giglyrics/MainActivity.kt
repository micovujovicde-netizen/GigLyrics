package com.teraphonia.giglyrics

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.Normalizer
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GigLyricsApp(this) }
    }
}

data class Entry(
    val name: String,
    val uri: Uri,
    val isDirectory: Boolean,
    val pathLabel: String = ""
)

data class NavLocation(
    val folderUri: Uri,
    val fileUri: Uri? = null,
    val fileName: String? = null
)

data class LibraryIndex(
    val songs: List<Entry>,
    val folders: Map<String, List<Entry>>
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GigLyricsApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("giglyrics", Context.MODE_PRIVATE) }

    var rootUri by remember {
        mutableStateOf(prefs.getString("root_uri", null)?.let(Uri::parse))
    }
    var currentUri by remember {
        mutableStateOf(prefs.getString("last_folder_uri", null)?.let(Uri::parse))
    }
    var currentTitle by remember { mutableStateOf("GigLyrics") }
    var entries by remember { mutableStateOf(emptyList<Entry>()) }

    var openedText by remember { mutableStateOf<String?>(null) }
    var openedTitle by remember { mutableStateOf("") }
    var openedFileUri by remember { mutableStateOf<Uri?>(null) }

    var fontSize by remember {
        mutableFloatStateOf(prefs.getFloat("font_size", 28f))
    }
    var listFontSize by remember {
        mutableFloatStateOf(prefs.getFloat("list_font_size", 23f))
    }

    var searchQuery by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf(emptyList<Entry>()) }
    var searching by remember { mutableStateOf(false) }
    var songIndex by remember { mutableStateOf(emptyList<Entry>()) }
    var folderCache by remember { mutableStateOf<Map<String, List<Entry>>>(emptyMap()) }
    var indexReady by remember { mutableStateOf(false) }
    var indexGeneration by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()

    val backHistory = remember { mutableStateListOf<NavLocation>() }
    val forwardHistory = remember { mutableStateListOf<NavLocation>() }

    fun listFolder(uri: Uri) {
        val cached = folderCache[uri.toString()]
        if (cached != null) {
            entries = cached
            currentUri = uri
            openedText = null
            openedTitle = ""
            openedFileUri = null
            currentTitle = if (uri == rootUri) "GigLyrics" else (
                DocumentFile.fromTreeUri(context, uri)?.name ?: "Folder"
            )
            prefs.edit().putString("last_folder_uri", uri.toString()).apply()
            return
        }

        // Fallback only while the background cache is still being built.
        val folder = DocumentFile.fromTreeUri(context, uri)
        if (folder == null || !folder.isDirectory) return
        currentTitle = folder.name ?: "Folder"
        entries = folder.listFiles()
            .filter { it.isDirectory || (it.isFile && it.name?.lowercase()?.endsWith(".txt") == true) }
            .mapNotNull { f ->
                val n = f.name ?: return@mapNotNull null
                Entry(n, f.uri, f.isDirectory)
            }
            .sortedWith(compareBy<Entry> { !it.isDirectory }.thenBy { it.name.lowercase() })
        currentUri = uri
        openedText = null
        openedTitle = ""
        openedFileUri = null
        prefs.edit().putString("last_folder_uri", uri.toString()).apply()
    }

    fun readText(uri: Uri): String {
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                BufferedReader(InputStreamReader(input)).readText()
            } ?: ""
        } catch (e: Exception) {
            "Ne mogu da otvorim fajl.\n\n${e.message ?: ""}"
        }
    }

    fun currentLocation(): NavLocation? {
        val folder = currentUri ?: return null
        return if (openedText != null && openedFileUri != null) {
            NavLocation(folder, openedFileUri, openedTitle)
        } else {
            NavLocation(folder)
        }
    }

    fun applyLocation(location: NavLocation) {
        searchQuery = ""
        searching = false
        searchResults = emptyList()

        if (currentUri != location.folderUri || entries.isEmpty()) {
            listFolder(location.folderUri)
        } else {
            openedText = null
            openedTitle = ""
            openedFileUri = null
        }

        if (location.fileUri != null) {
            openedFileUri = location.fileUri
            openedTitle = location.fileName ?: "Tekst"
            openedText = readText(location.fileUri)
        }
    }

    fun navigateTo(location: NavLocation) {
        currentLocation()?.let { backHistory.add(it) }
        forwardHistory.clear()
        applyLocation(location)
    }

    fun goBack() {
        if (searching) {
            searchQuery = ""
            searching = false
            searchResults = emptyList()
            return
        }
        if (backHistory.isNotEmpty()) {
            currentLocation()?.let { forwardHistory.add(it) }
            val previous = backHistory.removeAt(backHistory.lastIndex)
            applyLocation(previous)
        }
    }

    fun goForward() {
        if (forwardHistory.isNotEmpty()) {
            currentLocation()?.let { backHistory.add(it) }
            val next = forwardHistory.removeAt(forwardHistory.lastIndex)
            applyLocation(next)
        }
    }

    fun goHome() {
        val root = rootUri ?: return
        if (currentUri == root && openedText == null && !searching) return
        currentLocation()?.let { backHistory.add(it) }
        forwardHistory.clear()
        searchQuery = ""
        searching = false
        searchResults = emptyList()
        listFolder(root)
    }

    fun normalizeSearchText(value: String): String {
        val decomposed = Normalizer.normalize(value, Normalizer.Form.NFD)
        return decomposed
            .replace("\\p{Mn}+".toRegex(), "")
            .lowercase()
            .replace(".txt", "")
            .replace("[-_]+".toRegex(), " ")
            .replace("\\s+".toRegex(), " ")
            .trim()
    }

    suspend fun buildLibraryIndex(rootUriValue: Uri): LibraryIndex = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(context, rootUriValue)
            ?: return@withContext LibraryIndex(emptyList(), emptyMap())

        val songs = mutableListOf<Entry>()
        val folders = mutableMapOf<String, List<Entry>>()

        fun walk(folder: DocumentFile, path: String) {
            val rawChildren = folder.listFiles()
                .filter { it.isDirectory || (it.isFile && it.name?.lowercase()?.endsWith(".txt") == true) }

            val children = rawChildren
                .mapNotNull { f ->
                    val name = f.name ?: return@mapNotNull null
                    Entry(name, f.uri, f.isDirectory, path)
                }
                .sortedWith(compareBy<Entry> { !it.isDirectory }.thenBy { it.name.lowercase() })

            folders[folder.uri.toString()] = children

            for (child in rawChildren) {
                val name = child.name ?: continue
                if (child.isDirectory) {
                    val childPath = if (path.isBlank()) name else "$path / $name"
                    walk(child, childPath)
                } else if (child.isFile && name.lowercase().endsWith(".txt")) {
                    songs += Entry(name, child.uri, false, path)
                }
            }
        }

        walk(root, "")
        LibraryIndex(
            songs = songs.sortedBy { it.name.lowercase() },
            folders = folders
        )
    }

    fun refreshSongIndex(uri: Uri) {
        val generation = indexGeneration + 1
        indexGeneration = generation
        indexReady = false
        scope.launch {
            val built = buildLibraryIndex(uri)
            if (indexGeneration == generation) {
                songIndex = built.songs
                folderCache = built.folders
                indexReady = true

                // If the user is still on a folder that was opened before caching finished,
                // replace its slow SAF listing with the cached version immediately.
                currentUri?.let { current ->
                    built.folders[current.toString()]?.let { cached ->
                        if (openedText == null) entries = cached
                    }
                }

                if (searchQuery.isNotBlank()) {
                    val q = normalizeSearchText(searchQuery)
                    searchResults = built.songs.filter { normalizeSearchText(it.name).contains(q) }
                }
            }
        }
    }

    fun doSearch(query: String) {
        searchQuery = query
        searching = query.isNotBlank()
        if (!searching) {
            searchResults = emptyList()
            return
        }

        val q = normalizeSearchText(query)
        searchResults = if (indexReady) {
            songIndex.filter { normalizeSearchText(it.name).contains(q) }
        } else {
            emptyList()
        }
    }

    val folderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}

            rootUri = uri
            backHistory.clear()
            forwardHistory.clear()
            searchQuery = ""
            searching = false
            searchResults = emptyList()

            prefs.edit()
                .putString("root_uri", uri.toString())
                .putString("last_folder_uri", uri.toString())
                .apply()

            listFolder(uri)
            refreshSongIndex(uri)
        }
    }

    val voiceSearchLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
        if (!spoken.isNullOrBlank()) doSearch(spoken)
    }

    fun launchVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Kaži ime pjesme")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        }
        voiceSearchLauncher.launch(intent)
    }

    fun openDonate() {
        context.startActivity(
            Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://wise.com/pay/me/milanv607?utm_source=request_flow")
            )
        )
    }

    LaunchedEffect(Unit) {
        val savedRoot = rootUri

        if (savedRoot == null) {
            // First launch: the app must ask for its root folder before showing the browser.
            folderPicker.launch(null)
        } else {
            val rootFolder = DocumentFile.fromTreeUri(context, savedRoot)

            if (rootFolder == null || !rootFolder.isDirectory || !rootFolder.canRead()) {
                // The old folder was removed or Android revoked access. Ask again.
                prefs.edit()
                    .remove("root_uri")
                    .remove("last_folder_uri")
                    .apply()
                rootUri = null
                currentUri = null
                folderPicker.launch(null)
            } else {
                // Every fresh app launch starts at HOME/root. Never reopen the last song/folder.
                backHistory.clear()
                forwardHistory.clear()
                searchQuery = ""
                searching = false
                searchResults = emptyList()
                listFolder(savedRoot)
                refreshSongIndex(savedRoot)
            }
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color.Black,
            surface = Color.Black,
            onBackground = Color.White,
            onSurface = Color.White,
            primary = Color.White,
            onPrimary = Color.Black
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color.Black
        ) {
            val isRoot = rootUri != null && currentUri == rootUri && openedText == null

            BackHandler(enabled = searching || backHistory.isNotEmpty()) { goBack() }

            Column(Modifier.fillMaxSize()) {
                if (rootUri == null) {
                    // If the user cancels the Android picker, keep the app here instead of
                    // pretending there is already a root folder.
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        OutlinedButton(onClick = { folderPicker.launch(null) }) {
                            Text("IZABERI GLAVNI FOLDER", color = Color.White)
                        }
                    }
                } else if (openedText != null) {
                    // Reader: only the controls that directly help on stage.
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = openedTitle.removeSuffix(".txt"),
                            color = Color.White,
                            fontSize = 18.sp,
                            maxLines = 1,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Center
                        )

                        TextButton(
                            onClick = {
                                fontSize = (fontSize - 2f).coerceAtLeast(16f)
                                prefs.edit().putFloat("font_size", fontSize).apply()
                            }
                        ) { Text("A−", color = Color.White, fontSize = 18.sp) }

                        TextButton(
                            onClick = {
                                fontSize = (fontSize + 2f).coerceAtMost(60f)
                                prefs.edit().putFloat("font_size", fontSize).apply()
                            }
                        ) { Text("A+", color = Color.White, fontSize = 18.sp) }
                    }

                    Text(
                        text = openedText ?: "",
                        color = Color.White,
                        fontSize = fontSize.sp,
                        lineHeight = (fontSize * 1.35f).sp,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 18.dp, vertical = 8.dp)
                    )
                } else {
                    if (isRoot) {
                        // Home/root: the piano artwork is the GigLyrics logo.
                        Image(
                            painter = painterResource(id = R.drawable.giglyrics_piano_banner),
                            contentDescription = "GigLyrics",
                            contentScale = ContentScale.FillWidth,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(142.dp)
                                .padding(horizontal = 24.dp, vertical = 4.dp)
                        )

                        Spacer(Modifier.height(74.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { doSearch(it) },
                                placeholder = { Text("Traži pjesmu…") },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                textStyle = LocalTextStyle.current.copy(fontSize = 24.sp),
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 64.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = Color.White,
                                    unfocusedBorderColor = Color.White,
                                    cursorColor = Color.White,
                                    focusedPlaceholderColor = Color.Gray,
                                    unfocusedPlaceholderColor = Color.Gray
                                )
                            )

                            Spacer(Modifier.width(12.dp))

                            Surface(
                                modifier = Modifier
                                    .size(116.dp)
                                    .clickable { launchVoiceSearch() },
                                color = Color.Black,
                                contentColor = Color.White,
                                shape = RoundedCornerShape(16.dp),
                                border = androidx.compose.foundation.BorderStroke(2.dp, Color.White)
                            ) {
                                MicGlyph(Modifier.fillMaxSize().padding(15.dp))
                            }

                            Spacer(Modifier.width(8.dp))

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                TextButton(
                                    onClick = {
                                        listFontSize = (listFontSize - 2f).coerceAtLeast(16f)
                                        prefs.edit().putFloat("list_font_size", listFontSize).apply()
                                    },
                                    modifier = Modifier.size(48.dp)
                                ) { Text("−", color = Color.White, fontSize = 25.sp) }

                                TextButton(
                                    onClick = {
                                        listFontSize = (listFontSize + 2f).coerceAtMost(48f)
                                        prefs.edit().putFloat("list_font_size", listFontSize).apply()
                                    },
                                    modifier = Modifier.size(48.dp)
                                ) { Text("+", color = Color.White, fontSize = 25.sp) }
                            }
                        }

                        BrowserList(
                            listToShow = if (searching) searchResults else entries,
                            searching = searching,
                            listFontSize = listFontSize,
                            modifier = Modifier.weight(1f),
                            onEntryClick = { item ->
                                if (item.isDirectory) {
                                    currentUri?.let { navigateTo(NavLocation(item.uri)) }
                                } else {
                                    val folder = currentUri ?: rootUri
                                    if (folder != null) {
                                        navigateTo(NavLocation(folder, item.uri, item.name))
                                    }
                                }
                            }
                        )
                    } else {
                        // Inside folders: deliberately minimal.
                        Text(
                            text = currentTitle,
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        )

                        BrowserList(
                            listToShow = if (searching) searchResults else entries,
                            searching = searching,
                            listFontSize = listFontSize,
                            modifier = Modifier.weight(1f),
                            onEntryClick = { item ->
                                if (item.isDirectory) {
                                    navigateTo(NavLocation(item.uri))
                                } else {
                                    val folder = currentUri ?: return@BrowserList
                                    navigateTo(NavLocation(folder, item.uri, item.name))
                                }
                            }
                        )
                    }
                }

                // Stage controls: back, HOME, donate, forward.
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(112.dp)
                        .padding(horizontal = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = { goBack() },
                        enabled = searching || backHistory.isNotEmpty(),
                        modifier = Modifier.size(100.dp),
                        contentPadding = PaddingValues(6.dp)
                    ) {
                        NavChevron(
                            pointsRight = false,
                            modifier = Modifier.size(88.dp)
                        )
                    }

                    TextButton(
                        onClick = { goHome() },
                        enabled = rootUri != null && !isRoot,
                        modifier = Modifier.size(82.dp),
                        contentPadding = PaddingValues(10.dp)
                    ) {
                        HomeGlyph(Modifier.fillMaxSize())
                    }

                    Column(
                        modifier = Modifier
                            .clickable { openDonate() }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("♥", color = Color(0xFFE53935), fontSize = 32.sp, lineHeight = 30.sp)
                        Text(
                            "Donate",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontFamily = FontFamily.Cursive,
                            lineHeight = 20.sp
                        )
                    }

                    TextButton(
                        onClick = { goForward() },
                        enabled = forwardHistory.isNotEmpty(),
                        modifier = Modifier.size(100.dp),
                        contentPadding = PaddingValues(6.dp)
                    ) {
                        NavChevron(
                            pointsRight = true,
                            modifier = Modifier.size(88.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BrowserList(
    listToShow: List<Entry>,
    searching: Boolean,
    listFontSize: Float,
    modifier: Modifier = Modifier,
    onEntryClick: (Entry) -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(vertical = 8.dp)
    ) {
        items(listToShow, key = { it.uri.toString() }) { item ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onEntryClick(item) }
                    .padding(horizontal = 18.dp, vertical = 13.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (item.isDirectory) "›  ${item.name}" else item.name.removeSuffix(".txt"),
                    color = Color.White,
                    fontSize = listFontSize.sp,
                    fontWeight = if (item.isDirectory) FontWeight.SemiBold else FontWeight.Normal,
                    textAlign = TextAlign.Center
                )

                if (searching && item.pathLabel.isNotBlank()) {
                    Text(
                        text = item.pathLabel,
                        color = Color.Gray,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }

        if (searching && listToShow.isEmpty()) {
            item {
                Text(
                    text = "Nema rezultata.",
                    color = Color.Gray,
                    fontSize = 18.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun NavChevron(
    pointsRight: Boolean,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val insetX = size.width * 0.28f
        val insetY = size.height * 0.18f
        val centerY = size.height / 2f
        val leftX = insetX
        val rightX = size.width - insetX
        val tipX = if (pointsRight) rightX else leftX
        val outerX = if (pointsRight) leftX else rightX

        val path = Path().apply {
            moveTo(outerX, insetY)
            lineTo(tipX, centerY)
            lineTo(outerX, size.height - insetY)
        }

        drawPath(
            path = path,
            color = Color.White,
            style = Stroke(
                width = size.minDimension * 0.095f,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }
}

@Composable
private fun HomeGlyph(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val stroke = size.minDimension * 0.10f
        val left = size.width * 0.20f
        val right = size.width * 0.80f
        val roofY = size.height * 0.43f
        val peakY = size.height * 0.18f
        val bottomY = size.height * 0.82f
        val cx = size.width / 2f

        val roof = Path().apply {
            moveTo(left, roofY)
            lineTo(cx, peakY)
            lineTo(right, roofY)
        }
        drawPath(
            path = roof,
            color = Color.White,
            style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        val body = Path().apply {
            moveTo(size.width * 0.28f, roofY * 0.95f)
            lineTo(size.width * 0.28f, bottomY)
            lineTo(size.width * 0.72f, bottomY)
            lineTo(size.width * 0.72f, roofY * 0.95f)
        }
        drawPath(
            path = body,
            color = Color.White,
            style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        drawLine(
            color = Color.White,
            start = Offset(size.width * 0.46f, bottomY),
            end = Offset(size.width * 0.46f, size.height * 0.62f),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color.White,
            start = Offset(size.width * 0.46f, size.height * 0.62f),
            end = Offset(size.width * 0.60f, size.height * 0.62f),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color.White,
            start = Offset(size.width * 0.60f, size.height * 0.62f),
            end = Offset(size.width * 0.60f, bottomY),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
    }
}

@Composable
private fun MiniMicLogo(modifier: Modifier = Modifier) {
    MicGlyph(modifier)
}

@Composable
private fun MicGlyph(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val top = h * 0.12f
        val bottom = h * 0.58f
        val radius = w * 0.18f

        drawRoundRect(
            color = Color.White,
            topLeft = Offset(cx - radius, top),
            size = androidx.compose.ui.geometry.Size(radius * 2f, bottom - top),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius)
        )

        drawArc(
            color = Color.White,
            startAngle = 0f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = Offset(w * 0.20f, h * 0.26f),
            size = androidx.compose.ui.geometry.Size(w * 0.60f, h * 0.48f),
            style = Stroke(width = w * 0.08f, cap = StrokeCap.Round)
        )

        drawLine(
            color = Color.White,
            start = Offset(cx, h * 0.70f),
            end = Offset(cx, h * 0.88f),
            strokeWidth = w * 0.08f,
            cap = StrokeCap.Round
        )

        drawLine(
            color = Color.White,
            start = Offset(w * 0.34f, h * 0.88f),
            end = Offset(w * 0.66f, h * 0.88f),
            strokeWidth = w * 0.08f,
            cap = StrokeCap.Round
        )
    }
}
