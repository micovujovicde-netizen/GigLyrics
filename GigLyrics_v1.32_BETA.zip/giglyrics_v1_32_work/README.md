# GigLyrics v1.32 BETA

Changes:
- Web lyrics search silently excludes YouTube / YouTube Music results.
- Slightly smaller default/listing text, including a one-time migration for existing installs.
- Root shortcut label shortened to “Downloaded”.
- First folder selection can convert supported PDF, DOCX, RTF, Markdown and HTML files into sibling .txt files; originals stay unchanged.
- When new supported files appear later, GigLyrics offers the same conversion again without adding controls to the HOME screen.
