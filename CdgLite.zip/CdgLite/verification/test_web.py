import sys, pathlib,base64,io,wave,struct,math,json

from playwright.sync_api import sync_playwright
b=io.BytesIO()
with wave.open(b,'wb') as w:
 w.setparams((1,2,8000,0,'NONE','NONE'));w.writeframes(b''.join(struct.pack('<h',int(math.sin(i*2*math.pi*440/8000)*1000)) for i in range(16000)))
data=base64.b64encode(b.getvalue()).decode()
html=f'<html><body><audio controls loop src="data:audio/wav;base64,{data}"></audio><iframe src="https://child.test/audio" width="300" height="100"></iframe></body></html>'
child=f'<html><body><audio controls loop src="data:audio/wav;base64,{data}"></audio></body></html>'
script=(pathlib.Path(__file__).resolve().parents[1]/'app/src/main/assets/web-audio.js').read_text(encoding='utf-8-sig')
bridge='''window.messages=[];window.cdgHost={postMessage(raw){const x=JSON.parse(raw);messages.push(x);if(x.type==='hello')queueMicrotask(()=>cdgHost.onmessage({data:JSON.stringify({command:'init',epoch:1})}));}};'''
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,args=['--autoplay-policy=no-user-gesture-required'])
 ctx=browser.new_context();ctx.add_init_script(bridge+'\n'+script)
 ctx.route('**/*',lambda route:route.fulfill(content_type='text/html',body=child if 'child.test' in route.request.url else html))
 page=ctx.new_page();page.goto('https://parent.test/audio');page.wait_for_function("messages.some(m=>m.type==='ready'&&m.score>0)")
 page.evaluate("document.querySelector('audio').play()")
 page.wait_for_function("document.querySelector('audio').paused")
 assert not page.evaluate("messages.some(m=>m.type==='playing')"),'Unsolicited playback must not take over'
 def cmd(frame,name,epoch):frame.evaluate('(d)=>cdgHost.onmessage({data:JSON.stringify(d)})',{'command':name,'epoch':epoch})
 cmd(page,'play',1);page.wait_for_function("messages.some(m=>m.type==='playing'&&m.user)&&!document.querySelector('audio').paused")
 cmd(page,'stop',2);page.wait_for_function("document.querySelector('audio').paused")
 frame=next(f for f in page.frames if 'child.test' in f.url)
 frame.wait_for_function("messages.some(m=>m.type==='ready'&&m.score>0)")
 cmd(frame,'play',2);frame.wait_for_function("messages.some(m=>m.type==='playing'&&m.epoch===2)&&!document.querySelector('audio').paused")
 cmd(frame,'stop',3);frame.wait_for_function("document.querySelector('audio').paused")
 print('PASS: actual Chromium HTML audio PLAY/STOP, blocked autoplay, cross-origin frame control and current epoch events')

 browser.close()
