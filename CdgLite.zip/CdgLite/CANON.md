CDGLITE 1.1 — CANON

This document is the canonical implementation specification for the
current CdgLite 1.1 fixes and new tasks.

GENERAL RULES - Preserve all currently working functions and UI unless
explicitly changed below. - Do not redesign unrelated code. - Make only
the minimum necessary changes. - Build and run relevant tests after
implementation. - Verify real UI/touch/navigation/playback state logic,
not only unit tests. - Do not finish until the final build passes.

BUGS

BUG 1 — LOCAL SEARCH Local Search is not recursive. Search must include
ALL subfolders below the relevant/root folder, at any depth. A track
must be found regardless of how deeply it is nested.

BUG 2 — HOME HOME must always return directly to the main/root CdgLite
screen. HOME navigation must NOT stop currently playing music and must
NOT close the local lyrics/CDG text popup.

BUG 3 — < BACK The < button must go back exactly ONE folder level. At
root it must not exit the app or perform an incorrect action.
Back/folder navigation must NOT stop currently playing music and must
NOT close the local lyrics/CDG text popup.

BUG 4 — CDG POPUP X X must immediately close the CDG popup. Touches on
the popup/buttons must NOT pass through and activate files/folders
underneath.

BUG 5 — MAIN VOLUME / WEB-YOUTUBE The same main Volume slider must
control local playback AND Web/YouTube playback. Volume changes must
take effect immediately while YouTube/Web audio is playing.

BUG 6 — PINCH FONT ZOOM Pinch font zoom must remain permanently
available. It controls ONLY the font size of folders, subfolders and
track/file names. Do NOT resize Local/Web search fields with pinch. The
selected font size must be saved persistently. If the app is
closed/killed and opened again, restore the last selected font size.
After reopening the app, pinch zoom must STILL be immediately available
so the user can continue increasing/decreasing the font. Never disable
or lock pinch after restart.

NEW TASKS

TASK 1 — < BUTTON SIZE Make the < Back button the same visual size and
touch-target size as HOME. The < symbol itself must be large and easy to
see.

TASK 2 — MIC AUTO ENTER For BOTH Local Search MIC and Web Search MIC: as
soon as speech recognition returns text and inserts it into its search
field, automatically execute that field’s Enter/Search. No second user
tap should be required.

TASK 3 — WEB POPUP PLAY/STOP In the center of the Web/YouTube popup add
one LARGE transparent playback control. When Web/YT is stopped/paused:
show ▶ PLAY. When Web/YT is playing: show ■ STOP. Keep it transparent
enough that it does not interfere with reading/viewing the content
behind it. Use the same central position and switch the icon according
to playback state.

TASK 4 — LOCAL MP3 TAP = PLAY/STOP First tap on an MP3 file -> PLAY.
Second tap on the SAME active MP3 -> STOP. Another tap -> PLAY again.
Show a SMALL playback-state symbol ONLY beside the currently active MP3
file: ▶ = active MP3 is playing ■ = active MP3 is stopped All other MP3
files must show NO ▶/■ symbol. When another MP3 becomes active, remove
the symbol from the previous file and move it to the new active file.

TASK 5 — LOCAL / WEB AUDIO HANDOFF Navigation must be independent from
playback. Browse, HOME and < Back must NOT stop music. Browse, HOME and
< Back must NOT close the currently displayed local lyrics/CDG text
popup.

When the user moves to WEB: close the local lyrics/CDG text popup
automatically, BUT keep the local MP3 playing. Do NOT stop the local MP3
merely because Web was opened.

Only when the user actually presses PLAY and Web/YouTube playback really
starts: stop the local MP3 and let Web/YT take over audio.

The reverse must work the same way: while YouTube/Web is playing,
browsing local folders/Home/Back does NOT by itself stop YouTube. Only
when the user actually starts a local MP3: immediately stop Web/YouTube
playback/audio, then start the local MP3.

Never allow both audio sources to play simultaneously. Audio handoff
happens on actual PLAY, NOT on navigation.

TASK 6 — LYRICS/TEXT FILE SUPPORT Support opening/reading: .lyr .lyr3
.srt .txt

Display their text in the lyrics/text popup. TXT files must support
manual touch scrolling up/down. TXT does NOT require automatic
lyric-follow synchronization. Manual scrolling must be smooth and must
not interrupt music playback.

FINAL ACCEPTANCE After implementing ALL bugs and ALL tasks: - preserve
unrelated working behavior - build the complete project - run relevant
tests - verify touch handling, folder navigation, popup behavior,
persistent pinch settings, Local/Web playback state and audio handoff -
do not finish until the final build passes - stop after the successful
final build