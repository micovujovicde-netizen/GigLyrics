# Third-party notices

## SoundTouch

KaraMonster uses SoundTouch for local-audio transpose (pitch shift with tempo held at 1.0).

- SoundTouch DSP: version 2.3.2 as exposed by the selected JNI wrapper; SoundTouch is licensed under LGPL-2.1.
- `com.tianscar.soundtouch` JNI wrapper: version 1.1.1; wrapper code is MIT licensed.

Before public/commercial distribution, keep the required LGPL notice/license and satisfy the LGPL distribution requirements for the dynamically linked SoundTouch native libraries, or obtain a commercial SoundTouch license if preferred.

## FluidSynth / fluidsynth-kmp

KaraMonster uses FluidSynth for built-in MIDI/KAR synthesis with a SoundFont instead of Android's device-dependent MIDI sound source.

- FluidSynth native libraries are LGPL-2.1.
- `dev.kotlinds:fluidsynth-kmp:1.1.0` wrapper code is Apache-2.0 and bundles FluidSynth for Android.
- The MIDI path uses FluidSynth high-quality (7th-order sinc) interpolation.

Keep the applicable FluidSynth LGPL notice/license and satisfy LGPL distribution requirements in public/commercial builds.

## GeneralUser GS

KaraMonster bundles GeneralUser GS v2.0.3 as its default GM/GS SoundFont for MIDI/KAR playback.

- Author: S. Christian Collins.
- The complete SoundFont may be used in software projects and for private or commercial music creation under the author's GeneralUser GS License v2.0.
- The author notes historical uncertainty about the origin of some old freely distributed samples; see the full bundled notice at `app/src/main/assets/third_party/GeneralUser-GS-LICENSE.txt` before commercial distribution.
