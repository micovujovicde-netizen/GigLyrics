# CdgLite 1.0

Novi, odvojeni Android app. Package: `com.teraphonia.cdglite`, pa se instalira pored LyrGig-a bez uninstall-a.

## Zaključani V1
- Lokalni browser/index za `.mp3`, rekurzivno kroz izabrani folder.
- Local Search po MP3 naslovu.
- Ako postoji istoimeni `.cdg` u istom folderu, prikazuje CD+G grafiku sinhrono sa MP3.
- CDG popup počinje na 1/4 ekrana.
- Tap po popupu ciklično: 1/4 -> 1/2 -> FULL -> 1/4.
- X desno gore zatvara popup i zaustavlja pjesmu.
- Bez TXT, voice-follow, web extracta, settings i ostalih LyrGig funkcija.

Napomena: standardni CD+G renderer pokriva memory/border preset, tile normal/XOR i CLUT komande. Scroll komande nijesu dio ovog minimalnog V1.
