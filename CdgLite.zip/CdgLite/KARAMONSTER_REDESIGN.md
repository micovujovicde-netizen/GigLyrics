# KaraMonster visual pass — 2026-09-30

This build keeps the existing CdgLite/KaraMonster behavior and applies the supplied visual references across the home, local lyrics and BREAK screens.

- HOME/root: purple glossy HOME/back/FOLDER controls, purple search controls, large KARA MONSTER logo, stronger right-side T-Rex background, and T-Rex folder badges.
- Local playback / lyrics: green stage controls with red accent; LRC and TXT half-screen panels get a subtle transparent T-Rex background behind readable white lyrics.
- BREAK: green stage controls, larger ORDER/RANDOM and REPEAT buttons, and polished transport controls matching the reference.
- Sidecar colors and playback/navigation logic are preserved.

Validation performed here: Kotlin delimiter balance, PNG asset integrity and ZIP CRC. Gradle/APK compilation could not run because Gradle 8.9 is not cached and the sandbox has no network access to download it.
