# KaraMonster design update

Black reading surfaces, lime green controls, red accents, wide HOME/back navigation,
responsive toolbar widths, large white browser text, supplied T-Rex launcher/folder artwork,
and consistent local, web, lyrics, extraction/save and BREAK controls.
Voice search remains beside the two home search fields. Transport bars scroll on narrow
screens so all existing actions remain reachable. Sidecar indicator colors remain unchanged.
The Android application ID and saved preferences are retained for existing installations.

Validation: XML resources parsed, Kotlin delimiters checked, ZIP CRC checked, and playback,
library and CDG decoder source files confirmed unchanged. APK compilation and Android UI
verification were not possible here: Gradle 8.9 is unavailable locally and network access
blocked downloading it. Run the existing GitHub APK build before installation.
