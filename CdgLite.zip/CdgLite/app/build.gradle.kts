import java.io.File
import java.net.URI
import java.security.MessageDigest

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.teraphonia.cdglite"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.teraphonia.cdglite"
        minSdk = 26
        targetSdk = 35
        versionCode = 9
        versionName = "1.4-ytfix-appreferrer"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
    buildFeatures { compose = true }
    signingConfigs.getByName("debug") {
        System.getenv("CDGLITE_DEBUG_KEYSTORE")?.let { storeFile = file(it) }
    }
    testOptions { unitTests.isIncludeAndroidResources = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
kotlin { jvmToolchain(17) }
dependencies {
    implementation("dev.kotlinds:fluidsynth-kmp:1.1.0")
    implementation("com.tianscar.soundtouch:soundtouch-jni-core:1.1.1")
    implementation("com.tianscar.soundtouch:soundtouch-jni-android:1.1.1")
    androidTestImplementation("androidx.test:runner:1.6.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.compose.ui:ui-test-junit4:1.7.6")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.7")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.14.1")
    testImplementation("androidx.compose.ui:ui-test-junit4")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
    implementation(platform("androidx.compose:compose-bom:2025.01.00"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.documentfile:documentfile:1.0.1")
    debugImplementation("androidx.compose.ui:ui-tooling")
}


// GeneralUser GS 2.0.3 is bundled into the APK automatically at build time.
// The source is pinned and SHA-256 verified so MIDI/KAR never depends on a runtime download.
val generalUserSoundFont = layout.projectDirectory.file("src/main/assets/GeneralUser-GS.sf2")
val generalUserSoundFontSha256 = "9575028c7a1f589f5770fccc8cff2734566af40cd26ed836944e9a5152688cfe"
val generalUserSoundFontUrl =
    "https://raw.githubusercontent.com/mrbumpy409/GeneralUser-GS/684543d5e5efaef08d02be50dcda8d552478fa60/GeneralUser-GS.sf2"

fun sha256(file: File): String {
    val digest = MessageDigest.getInstance("SHA-256")
    file.inputStream().buffered().use { input ->
        val buffer = ByteArray(256 * 1024)
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            digest.update(buffer, 0, read)
        }
    }
    return digest.digest().joinToString("") { "%02x".format(it.toInt() and 0xff) }
}

val bundleGeneralUserSoundFont by tasks.registering {
    outputs.file(generalUserSoundFont)
    outputs.upToDateWhen {
        val target = generalUserSoundFont.asFile
        target.exists() && runCatching { sha256(target) == generalUserSoundFontSha256 }.getOrDefault(false)
    }
    doLast {
        val target = generalUserSoundFont.asFile
        if (target.exists() && sha256(target) == generalUserSoundFontSha256) return@doLast
        target.parentFile.mkdirs()
        val temp = File(target.parentFile, "${target.name}.download")
        temp.delete()
        URI(generalUserSoundFontUrl).toURL().openStream().buffered().use { input ->
            temp.outputStream().buffered().use { output -> input.copyTo(output, 256 * 1024) }
        }
        val actual = sha256(temp)
        check(actual == generalUserSoundFontSha256) {
            "GeneralUser GS checksum mismatch: expected $generalUserSoundFontSha256, got $actual"
        }
        if (target.exists()) target.delete()
        check(temp.renameTo(target) || runCatching {
            temp.copyTo(target, overwrite = true)
            temp.delete()
            true
        }.getOrDefault(false)) { "Could not install GeneralUser-GS.sf2 into assets" }
    }
}

tasks.matching { it.name == "preBuild" }.configureEach {
    dependsOn(bundleGeneralUserSoundFont)
}
