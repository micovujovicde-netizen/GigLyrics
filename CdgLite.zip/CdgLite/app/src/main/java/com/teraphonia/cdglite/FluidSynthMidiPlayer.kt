package com.teraphonia.cdglite

import android.content.Context
import dev.kotlinds.fluidsynthkmp.AudioConfig
import dev.kotlinds.fluidsynthkmp.Interpolation
import dev.kotlinds.fluidsynthkmp.MidiFilePlayer
import java.io.File

/**
 * Built-in high quality GM/GS MIDI path.
 *
 * MIDI/KAR is synthesized by FluidSynth with the bundled GeneralUser GS SoundFont.
 * The user sees no extra controls: this transparently replaces Android's device-dependent
 * MIDI synthesizer while preserving the existing play/pause/seek/transpose UI.
 */
internal class FluidSynthMidiPlayer private constructor(
    private val native: MidiFilePlayer,
    private val timeMap: MidiTimeMap,
    private var volume: Float
) {
    val durationMs: Int get() = timeMap.tickToMs(native.durationTicks)
    val currentPositionMs: Int get() = timeMap.tickToMs(native.currentTick)
    val isPlaying: Boolean get() = native.isPlaying

    fun start() = native.play()

    fun pause() = native.pause()

    fun seekTo(positionMs: Int) {
        native.seekTo(timeMap.msToTick(positionMs))
    }

    fun setVolume(value: Float) {
        volume = value.coerceIn(0f, 1f)
        FluidSynthInternals.setRecommendedMix(native, volume)
    }

    fun release() {
        runCatching { native.close() }
    }

    companion object {
        private const val SOUNDFONT_ASSET = "GeneralUser-GS.sf2"

        fun create(context: Context, midiFile: File, midiBytes: ByteArray, volume: Float): FluidSynthMidiPlayer {
            val soundFont = ensureSoundFontFile(context)
            val timeMap = MidiTimeMap.parse(midiBytes)
            val player = MidiFilePlayer(
                soundFontPath = soundFont.absolutePath,
                midiPath = midiFile.absolutePath,
                config = AudioConfig(
                    sampleRate = 48_000,
                    interpolation = Interpolation.HIGH,
                    periodSize = 128,
                    periods = 3
                )
            )
            return FluidSynthMidiPlayer(player, timeMap, volume.coerceIn(0f, 1f)).also {
                FluidSynthInternals.setRecommendedMix(player, it.volume)
            }
        }

        @Synchronized
        private fun ensureSoundFontFile(context: Context): File {
            val dir = File(context.filesDir, "soundfonts").apply { mkdirs() }
            val target = File(dir, SOUNDFONT_ASSET)
            if (!target.exists() || target.length() < 30_000_000L) {
                val temp = File(dir, "$SOUNDFONT_ASSET.tmp")
                context.assets.open(SOUNDFONT_ASSET).use { input ->
                    temp.outputStream().use { output -> input.copyTo(output, 256 * 1024) }
                }
                if (target.exists()) target.delete()
                if (!temp.renameTo(target)) {
                    temp.copyTo(target, overwrite = true)
                    temp.delete()
                }
            }
            return target
        }
    }
}

/**
 * The public MidiFilePlayer API intentionally exposes only transport. These pinned 1.1.0
 * internals let KaraMonster apply GeneralUser GS' recommended FluidSynth mix and keep the
 * existing application volume working. If reflection ever stops matching, playback still works
 * with FluidSynth defaults; these calls simply become no-ops.
 */
private object FluidSynthInternals {
    private const val BASE_GAIN = 0.50f

    fun setRecommendedMix(player: MidiFilePlayer, appVolume: Float) {
        runCatching {
            val contextField = player.javaClass.getDeclaredField("context").apply { isAccessible = true }
            val fsContext = contextField.get(player)
            val synthPtr = fsContext.javaClass.getDeclaredField("synthPtr")
                .apply { isAccessible = true }
                .getLong(fsContext)

            val jniClass = Class.forName("dev.kotlinds.fluidsynthkmp.FluidSynthJni")
            val instance = jniClass.getDeclaredField("INSTANCE").apply { isAccessible = true }.get(null)

            invoke(jniClass, instance, "setGain", synthPtr, BASE_GAIN * appVolume.coerceIn(0f, 1f))
            // GeneralUser GS 2.0 recommended FluidSynth effects.
            invoke(jniClass, instance, "setReverbRoomSize", synthPtr, 0.50)
            invoke(jniClass, instance, "setReverbDamp", synthPtr, 0.30)
            invoke(jniClass, instance, "setReverbWidth", synthPtr, 0.80)
            invoke(jniClass, instance, "setReverbLevel", synthPtr, 0.70)
            invoke(jniClass, instance, "setChorusNr", synthPtr, 4)
            invoke(jniClass, instance, "setChorusLevel", synthPtr, 0.55)
            invoke(jniClass, instance, "setChorusSpeed", synthPtr, 0.36)
            invoke(jniClass, instance, "setChorusDepth", synthPtr, 3.60)
        }
    }

    private fun invoke(clazz: Class<*>, instance: Any, prefix: String, vararg args: Any) {
        val method = clazz.declaredMethods.firstOrNull {
            it.name == prefix && it.parameterCount == args.size
        } ?: return
        method.isAccessible = true
        method.invoke(instance, *args)
    }
}
