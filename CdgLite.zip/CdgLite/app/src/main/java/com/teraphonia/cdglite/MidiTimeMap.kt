package com.teraphonia.cdglite

import kotlin.math.roundToLong

/**
 * Converts Standard MIDI File ticks <-> milliseconds without touching the file.
 * Supports normal PPQ timing (including tempo changes) and SMPTE timing.
 */
internal class MidiTimeMap private constructor(
    private val ppq: Int?,
    private val ticksPerSecond: Double?,
    private val tempos: List<TempoPoint>
) {
    private data class TempoPoint(val tick: Long, val microsPerQuarter: Long, val microsAtTick: Double)

    fun tickToMs(tick: Long): Int {
        val safeTick = tick.coerceAtLeast(0L)
        val tps = ticksPerSecond
        val micros = if (tps != null) {
            safeTick.toDouble() * 1_000_000.0 / tps
        } else {
            val tpq = ppq ?: return 0
            val point = tempoAtTick(safeTick)
            point.microsAtTick + (safeTick - point.tick).toDouble() * point.microsPerQuarter / tpq
        }
        return (micros / 1000.0).roundToLong().coerceIn(0L, Int.MAX_VALUE.toLong()).toInt()
    }

    fun msToTick(ms: Int): Long {
        val micros = ms.coerceAtLeast(0).toDouble() * 1000.0
        val tps = ticksPerSecond
        return if (tps != null) {
            (micros * tps / 1_000_000.0).roundToLong().coerceAtLeast(0L)
        } else {
            val tpq = ppq ?: return 0L
            val point = tempoAtMicros(micros)
            (point.tick + (micros - point.microsAtTick) * tpq / point.microsPerQuarter)
                .roundToLong().coerceAtLeast(0L)
        }
    }

    private fun tempoAtTick(tick: Long): TempoPoint {
        var lo = 0
        var hi = tempos.lastIndex
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (tempos[mid].tick <= tick) lo = mid + 1 else hi = mid - 1
        }
        return tempos[hi.coerceAtLeast(0)]
    }

    private fun tempoAtMicros(micros: Double): TempoPoint {
        var lo = 0
        var hi = tempos.lastIndex
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (tempos[mid].microsAtTick <= micros) lo = mid + 1 else hi = mid - 1
        }
        return tempos[hi.coerceAtLeast(0)]
    }

    companion object {
        private const val DEFAULT_TEMPO_US = 500_000L

        fun parse(data: ByteArray): MidiTimeMap {
            require(data.size >= 14 && ascii(data, 0, 4) == "MThd") { "Not a Standard MIDI File" }
            val headerLength = readInt32(data, 4)
            require(headerLength >= 6 && 8 + headerLength <= data.size) { "Invalid MIDI header" }
            val divisionRaw = readU16(data, 12)

            // SMPTE timing: signed high byte is negative FPS, low byte = ticks/frame.
            if ((divisionRaw and 0x8000) != 0) {
                val signedFps = ((divisionRaw ushr 8) and 0xff).toByte().toInt()
                val ticksPerFrame = divisionRaw and 0xff
                require(ticksPerFrame > 0) { "Invalid SMPTE MIDI division" }
                val fps = when (-signedFps) {
                    24 -> 24.0
                    25 -> 25.0
                    29 -> 29.97
                    30 -> 30.0
                    else -> (-signedFps).toDouble().coerceAtLeast(1.0)
                }
                return MidiTimeMap(ppq = null, ticksPerSecond = fps * ticksPerFrame, tempos = emptyList())
            }

            val ppq = divisionRaw and 0x7fff
            require(ppq > 0) { "Invalid PPQ MIDI division" }
            val rawTempos = mutableListOf<Pair<Long, Long>>()
            rawTempos += 0L to DEFAULT_TEMPO_US

            var p = 8 + headerLength
            while (p + 8 <= data.size) {
                val type = ascii(data, p, 4)
                val length = readInt32(data, p + 4)
                val start = p + 8
                val end = start + length
                require(length >= 0 && end <= data.size) { "Invalid MIDI chunk" }
                if (type == "MTrk") collectTrackTempos(data, start, end, rawTempos)
                p = end
            }

            val sorted = rawTempos
                .withIndex()
                .sortedWith(compareBy<IndexedValue<Pair<Long, Long>>> { it.value.first }.thenBy { it.index })
                .map { it.value }

            // If multiple tempo events land at the same tick, use the last encountered event.
            val collapsed = mutableListOf<Pair<Long, Long>>()
            for ((tick, tempo) in sorted) {
                if (collapsed.isNotEmpty() && collapsed.last().first == tick) collapsed[collapsed.lastIndex] = tick to tempo
                else collapsed += tick to tempo
            }

            var previousTick = collapsed.first().first
            var previousTempo = collapsed.first().second
            var micros = 0.0
            val points = mutableListOf(TempoPoint(previousTick, previousTempo, 0.0))
            for (i in 1 until collapsed.size) {
                val (tick, tempo) = collapsed[i]
                micros += (tick - previousTick).toDouble() * previousTempo / ppq
                points += TempoPoint(tick, tempo, micros)
                previousTick = tick
                previousTempo = tempo
            }
            return MidiTimeMap(ppq = ppq, ticksPerSecond = null, tempos = points)
        }

        private fun collectTrackTempos(
            data: ByteArray,
            start: Int,
            end: Int,
            out: MutableList<Pair<Long, Long>>
        ) {
            var p = start
            var tick = 0L
            var runningStatus = -1
            while (p < end) {
                val delta = readVlq(data, p, end)
                tick += delta.first
                p = delta.second
                if (p >= end) break

                var status = data[p].toInt() and 0xff
                if (status < 0x80) {
                    if (runningStatus < 0) return
                    status = runningStatus
                } else {
                    p++
                    if (status in 0x80..0xef) runningStatus = status
                }

                when {
                    status in 0x80..0xef -> {
                        val type = status and 0xf0
                        val count = if (type == 0xc0 || type == 0xd0) 1 else 2
                        if (p + count > end) return
                        p += count
                    }
                    status == 0xff -> {
                        if (p >= end) return
                        val metaType = data[p++].toInt() and 0xff
                        val len = readVlq(data, p, end)
                        val length = len.first.toInt()
                        p = len.second
                        if (length < 0 || p + length > end) return
                        if (metaType == 0x51 && length == 3) {
                            val tempo = ((data[p].toInt() and 0xff) shl 16) or
                                ((data[p + 1].toInt() and 0xff) shl 8) or
                                (data[p + 2].toInt() and 0xff)
                            if (tempo > 0) out += tick to tempo.toLong()
                        }
                        p += length
                    }
                    status == 0xf0 || status == 0xf7 -> {
                        val len = readVlq(data, p, end)
                        val length = len.first.toInt()
                        p = len.second
                        if (length < 0 || p + length > end) return
                        p += length
                    }
                    else -> {
                        val count = when (status) {
                            0xf1, 0xf3 -> 1
                            0xf2 -> 2
                            0xf6, in 0xf8..0xff -> 0
                            else -> return
                        }
                        if (p + count > end) return
                        p += count
                    }
                }
            }
        }

        private fun readVlq(data: ByteArray, offset: Int, end: Int): Pair<Long, Int> {
            var p = offset
            var value = 0L
            repeat(4) {
                if (p >= end) throw IllegalArgumentException("Truncated MIDI VLQ")
                val b = data[p++].toInt() and 0xff
                value = (value shl 7) or (b and 0x7f).toLong()
                if ((b and 0x80) == 0) return value to p
            }
            throw IllegalArgumentException("Invalid MIDI VLQ")
        }

        private fun ascii(data: ByteArray, offset: Int, length: Int): String =
            data.copyOfRange(offset, offset + length).toString(Charsets.US_ASCII)

        private fun readU16(data: ByteArray, offset: Int): Int =
            ((data[offset].toInt() and 0xff) shl 8) or (data[offset + 1].toInt() and 0xff)

        private fun readInt32(data: ByteArray, offset: Int): Int =
            ((data[offset].toInt() and 0xff) shl 24) or
                ((data[offset + 1].toInt() and 0xff) shl 16) or
                ((data[offset + 2].toInt() and 0xff) shl 8) or
                (data[offset + 3].toInt() and 0xff)
    }
}
