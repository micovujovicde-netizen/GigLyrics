package com.teraphonia.cdglite

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Handler
import android.os.Looper
import com.tianscar.soundtouch.SoundTouch
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max

/**
 * High-quality local-audio transpose path.
 *
 * MediaExtractor/MediaCodec decode the selected file to PCM, SoundTouch changes pitch while
 * keeping tempo at 1.0, and AudioTrack renders the processed PCM. This deliberately avoids
 * MediaPlayer.PlaybackParams pitch shifting, whose quality varies between Android devices.
 *
 * The player is intentionally small and only owns audio-only local playback. Video keeps the
 * existing MediaPlayer path because replacing its audio renderer would also require a full A/V
 * synchronisation pipeline.
 */
internal class SoundTouchAudioPlayer(
    private val context: Context,
    private val uri: Uri,
    initialPitchSemitones: Int,
    initialPositionMs: Int = 0,
    private val onPrepared: (SoundTouchAudioPlayer) -> Unit,
    private val onCompletion: (SoundTouchAudioPlayer) -> Unit,
    private val onError: (SoundTouchAudioPlayer, Throwable) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private val stateLock = Any()

    @Volatile private var released = false
    @Volatile private var prepared = false
    @Volatile private var playing = false
    @Volatile private var pitchSemitones = initialPitchSemitones.coerceIn(-6, 6)
    @Volatile private var volume = 1f
    @Volatile private var pendingSeekMs = -1
    @Volatile private var audioTrack: AudioTrack? = null
    @Volatile private var sampleRate = 44_100
    @Volatile private var basePositionMs = initialPositionMs.coerceAtLeast(0)
    @Volatile private var playbackHeadBase = 0L

    @Volatile var durationMs: Int = 0
        private set

    val isPlaying: Boolean get() = playing && !released

    val currentPositionMs: Int
        get() {
            if (!prepared) return basePositionMs.coerceAtMost(durationMs.takeIf { it > 0 } ?: Int.MAX_VALUE)
            val track = audioTrack ?: return basePositionMs
            val now = unsignedHead(track.playbackHeadPosition)
            val frames = (now - playbackHeadBase) and 0xffffffffL
            val elapsed = if (sampleRate > 0) frames * 1000L / sampleRate else 0L
            val raw = basePositionMs.toLong() + elapsed
            return raw.coerceIn(0L, durationMs.takeIf { it > 0 }?.toLong() ?: raw).toInt()
        }

    private val worker = Thread({ runPlayback() }, "KaraMonster-SoundTouch").apply {
        isDaemon = true
        start()
    }

    fun start() {
        if (released) return
        playing = true
        runCatching { audioTrack?.play() }
    }

    fun pause() {
        if (released) return
        playing = false
        runCatching { audioTrack?.pause() }
    }

    fun setPitchSemitones(value: Int) {
        pitchSemitones = value.coerceIn(-6, 6)
    }

    fun setVolume(value: Float) {
        volume = value.coerceIn(0f, 1f)
        runCatching { audioTrack?.setVolume(volume) }
    }

    fun seekTo(valueMs: Int) {
        if (released) return
        pendingSeekMs = valueMs.coerceIn(0, durationMs.takeIf { it > 0 } ?: Int.MAX_VALUE)
    }

    fun release() {
        if (released) return
        released = true
        playing = false
        synchronized(stateLock) {
            runCatching { audioTrack?.pause() }
            runCatching { audioTrack?.flush() }
            runCatching { audioTrack?.release() }
            audioTrack = null
        }
        worker.interrupt()
    }

    private fun runPlayback() {
        var extractor: MediaExtractor? = null
        var codec: MediaCodec? = null
        var soundTouch: SoundTouch? = null
        try {
            extractor = MediaExtractor().also { it.setDataSource(context, uri, null) }
            val audioTrackIndex = (0 until extractor.trackCount).firstOrNull { index ->
                extractor.getTrackFormat(index).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: error("No audio track")
            extractor.selectTrack(audioTrackIndex)
            val sourceFormat = extractor.getTrackFormat(audioTrackIndex)
            val mime = sourceFormat.getString(MediaFormat.KEY_MIME) ?: error("Unknown audio format")
            sampleRate = sourceFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val channels = sourceFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            if (channels !in 1..2) error("Only mono/stereo transpose is supported")
            durationMs = if (sourceFormat.containsKey(MediaFormat.KEY_DURATION)) {
                (sourceFormat.getLong(MediaFormat.KEY_DURATION) / 1000L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
            } else 0
            basePositionMs = basePositionMs.coerceIn(0, durationMs.takeIf { it > 0 } ?: Int.MAX_VALUE)

            val rawPcm = mime == "audio/raw"
            var pcmEncoding = if (sourceFormat.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                sourceFormat.getInteger(MediaFormat.KEY_PCM_ENCODING)
            } else AudioFormat.ENCODING_PCM_16BIT

            if (!rawPcm) {
                // Ask Android decoders for 16-bit PCM. This keeps the SoundTouch path predictable.
                runCatching { sourceFormat.setInteger(MediaFormat.KEY_PCM_ENCODING, AudioFormat.ENCODING_PCM_16BIT) }
                codec = MediaCodec.createDecoderByType(mime).also {
                    it.configure(sourceFormat, null, null, 0)
                    it.start()
                }
            }

            soundTouch = makeSoundTouch(sampleRate, channels)
            val output = buildAudioTrack(sampleRate, channels)
            synchronized(stateLock) {
                if (released) {
                    output.release()
                    return
                }
                audioTrack = output
            }
            output.setVolume(volume)

            if (basePositionMs > 0) extractor.seekTo(basePositionMs * 1000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            playbackHeadBase = unsignedHead(output.playbackHeadPosition)
            prepared = true
            main.post { if (!released) onPrepared(this) }

            if (rawPcm) {
                runRawLoop(extractor, soundTouch, output, channels, pcmEncoding)
            } else {
                runCodecLoop(extractor, codec, soundTouch, output, channels) { encoding -> pcmEncoding = encoding }
            }
        } catch (t: Throwable) {
            if (!released) main.post { if (!released) onError(this, t) }
        } finally {
            prepared = false
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor?.release() }
            runCatching { soundTouch?.dispose() }
            synchronized(stateLock) {
                val at = audioTrack
                audioTrack = null
                runCatching { at?.pause() }
                runCatching { at?.flush() }
                runCatching { at?.release() }
            }
        }
    }

    private fun runRawLoop(
        extractor: MediaExtractor,
        soundTouch: SoundTouch,
        output: AudioTrack,
        channels: Int,
        pcmEncoding: Int
    ) {
        val input = ByteBuffer.allocateDirect(256 * 1024)
        while (!released) {
            applyPendingSeek(extractor, null, soundTouch, output)
            waitUntilPlaying(output)
            if (released) return

            input.clear()
            val count = extractor.readSampleData(input, 0)
            if (count < 0) {
                finishStream(soundTouch, output, channels)
                return
            }
            input.position(0)
            input.limit(count)
            feedDecodedPcm(input, pcmEncoding, soundTouch, output, channels)
            extractor.advance()
        }
    }

    private fun runCodecLoop(
        extractor: MediaExtractor,
        codec: MediaCodec,
        soundTouch: SoundTouch,
        output: AudioTrack,
        channels: Int,
        updateEncoding: (Int) -> Unit
    ) {
        val info = MediaCodec.BufferInfo()
        var inputEos = false
        var outputEos = false
        var pcmEncoding = AudioFormat.ENCODING_PCM_16BIT

        while (!released && !outputEos) {
            if (pendingSeekMs >= 0) {
                applyPendingSeek(extractor, codec, soundTouch, output)
                inputEos = false
                outputEos = false
            } else {
                applyPitchIfNeeded(soundTouch)
            }
            waitUntilPlaying(output)
            if (released) return

            if (!inputEos) {
                val inIndex = codec.dequeueInputBuffer(10_000)
                if (inIndex >= 0) {
                    val inputBuffer = codec.getInputBuffer(inIndex) ?: error("Decoder input buffer missing")
                    inputBuffer.clear()
                    val size = extractor.readSampleData(inputBuffer, 0)
                    if (size < 0) {
                        codec.queueInputBuffer(inIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        inputEos = true
                    } else {
                        codec.queueInputBuffer(inIndex, 0, size, extractor.sampleTime.coerceAtLeast(0L), 0)
                        extractor.advance()
                    }
                }
            }

            when (val outIndex = codec.dequeueOutputBuffer(info, 10_000)) {
                MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    val outFormat = codec.outputFormat
                    if (outFormat.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                        pcmEncoding = outFormat.getInteger(MediaFormat.KEY_PCM_ENCODING)
                        updateEncoding(pcmEncoding)
                    }
                }
                MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                else -> if (outIndex >= 0) {
                    val buffer = codec.getOutputBuffer(outIndex)
                    if (buffer != null && info.size > 0) {
                        val dup = buffer.duplicate().order(ByteOrder.nativeOrder())
                        dup.position(info.offset)
                        dup.limit(info.offset + info.size)
                        feedDecodedPcm(dup.slice().order(ByteOrder.nativeOrder()), pcmEncoding, soundTouch, output, channels)
                    }
                    outputEos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                    codec.releaseOutputBuffer(outIndex, false)
                }
            }
        }

        if (!released && outputEos) finishStream(soundTouch, output, channels)
    }

    private fun feedDecodedPcm(
        buffer: ByteBuffer,
        pcmEncoding: Int,
        soundTouch: SoundTouch,
        output: AudioTrack,
        channels: Int
    ) {
        val samples: ShortArray = when (pcmEncoding) {
            AudioFormat.ENCODING_PCM_FLOAT -> {
                val floats = buffer.order(ByteOrder.nativeOrder()).asFloatBuffer()
                ShortArray(floats.remaining()).also { dest ->
                    var i = 0
                    while (floats.hasRemaining()) {
                        val f = floats.get().coerceIn(-1f, 1f)
                        dest[i++] = (f * 32767f).toInt().toShort()
                    }
                }
            }
            AudioFormat.ENCODING_PCM_8BIT -> {
                ShortArray(buffer.remaining()).also { dest ->
                    var i = 0
                    while (buffer.hasRemaining()) {
                        val unsigned = buffer.get().toInt() and 0xff
                        dest[i++] = ((unsigned - 128) shl 8).toShort()
                    }
                }
            }
            else -> {
                val shorts = buffer.order(ByteOrder.nativeOrder()).asShortBuffer()
                ShortArray(shorts.remaining()).also { shorts.get(it) }
            }
        }
        if (samples.isEmpty()) return
        val frames = samples.size / channels
        if (frames <= 0) return
        soundTouch.putSamples(samples, 0, frames)
        drainSoundTouch(soundTouch, output, channels)
    }

    private fun drainSoundTouch(soundTouch: SoundTouch, output: AudioTrack, channels: Int) {
        val out = ShortArray(8192 * channels)
        while (!released) {
            val frames = soundTouch.receiveSamplesI16(out, 0, out.size / channels)
            if (frames <= 0) return
            writeFully(output, out, frames * channels)
        }
    }

    private fun finishStream(soundTouch: SoundTouch, output: AudioTrack, channels: Int) {
        soundTouch.flush()
        drainSoundTouch(soundTouch, output, channels)
        while (!released) {
            if (pendingSeekMs >= 0) return
            if (!playing) {
                Thread.sleep(10)
                continue
            }
            val now = unsignedHead(output.playbackHeadPosition)
            // AudioTrack's internal queue is considered drained once its head stops advancing to
            // the current write boundary. A short idle period avoids cutting the final SoundTouch tail.
            val p1 = now
            Thread.sleep(45)
            val p2 = unsignedHead(output.playbackHeadPosition)
            if (p2 == p1) break
        }
        if (!released) {
            playing = false
            basePositionMs = durationMs
            main.post { if (!released) onCompletion(this) }
        }
    }

    private fun writeFully(output: AudioTrack, samples: ShortArray, count: Int) {
        var offset = 0
        while (!released && offset < count) {
            while (!released && !playing) Thread.sleep(10)
            if (released) return
            val written = output.write(samples, offset, count - offset, AudioTrack.WRITE_BLOCKING)
            if (written < 0) error("AudioTrack write failed: $written")
            if (written == 0) Thread.yield() else offset += written
        }
    }

    private fun waitUntilPlaying(output: AudioTrack) {
        while (!released && !playing) Thread.sleep(10)
        if (!released && output.playState != AudioTrack.PLAYSTATE_PLAYING) output.play()
    }

    private fun applyPendingSeek(
        extractor: MediaExtractor,
        codec: MediaCodec?,
        soundTouch: SoundTouch,
        output: AudioTrack
    ) {
        val target = pendingSeekMs
        if (target < 0) {
            applyPitchIfNeeded(soundTouch)
            return
        }
        pendingSeekMs = -1
        val wasPlaying = playing
        runCatching { output.pause() }
        runCatching { output.flush() }
        runCatching { codec?.flush() }
        soundTouch.clear()
        extractor.seekTo(target * 1000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
        basePositionMs = target
        playbackHeadBase = unsignedHead(output.playbackHeadPosition)
        applyPitchIfNeeded(soundTouch, force = true)
        if (wasPlaying) runCatching { output.play() }
    }

    private var appliedPitch = Int.MIN_VALUE
    private fun applyPitchIfNeeded(soundTouch: SoundTouch, force: Boolean = false) {
        val wanted = pitchSemitones
        if (force || wanted != appliedPitch) {
            soundTouch.setPitchSemiTones(wanted.toFloat())
            soundTouch.setTempo(1f)
            appliedPitch = wanted
        }
    }

    private fun makeSoundTouch(rate: Int, channels: Int): SoundTouch = SoundTouch().apply {
        setSampleRate(rate.toLong())
        setChannels(channels.toLong())
        setTempo(1f)
        setPitchSemiTones(pitchSemitones.toFloat())
        // Quality first for stage playback: anti-aliasing ON, quick seek OFF.
        setSetting(SoundTouch.SETTING_USE_AA_FILTER, 1)
        setSetting(SoundTouch.SETTING_AA_FILTER_LENGTH, 64)
        setSetting(SoundTouch.SETTING_USE_QUICKSEEK, 0)
        appliedPitch = pitchSemitones
    }

    private fun buildAudioTrack(rate: Int, channels: Int): AudioTrack {
        val mask = if (channels == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
        val min = AudioTrack.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) error("Unsupported AudioTrack format")
        val bufferBytes = max(min * 4, rate * channels * 2 / 2)
        return AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(rate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(mask)
                    .build()
            )
            .setBufferSizeInBytes(bufferBytes)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setSessionId(AudioManager.AUDIO_SESSION_ID_GENERATE)
            .build()
    }

    private fun unsignedHead(value: Int): Long = value.toLong() and 0xffffffffL
}
