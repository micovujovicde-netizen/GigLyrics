package com.teraphonia.cdglite

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

@Composable
internal fun GigPlaylistPopup(
    store: GigPlaylistStore,
    selected: Int,
    onSelected: (Int) -> Unit,
    showHint: Boolean,
    onGestureLearned: () -> Unit,
    activeMediaUri: String?,
    activePlaying: Boolean,
    onPlay: (GhostTrack) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.background(Color(0xF20A0D0A)).padding(6.dp)) {
        Row(Modifier.fillMaxWidth()) {
            repeat(4) { index ->
                StoneButton(
                    onClick = { store.activate(index); onSelected(index) },
                    modifier = Modifier.weight(1f).height(68.dp),
                    active = store.activeIndex == index,
                    locked = store.activeIndex != index
                ) { Text("P${index + 1}", color = if (store.activeIndex == index) MonsterGreen else Color(0xFFD2D5CF), fontSize = 30.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Serif) }
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("P${selected + 1}  •  ${store.lists[selected].size} pjesama", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif, modifier = Modifier.weight(1f).padding(horizontal = 8.dp))
            MonsterButton(onClick = {
                val list = store.lists[selected]
                if (list.isNotEmpty()) {
                    val at = list.indexOfFirst { it.mediaUri == activeMediaUri }
                    onPlay(list[if (at <= 0) list.lastIndex else at - 1])
                }
            }, modifier = Modifier.width(62.dp).height(54.dp)) { Text("‹", fontSize = 30.sp, fontWeight = FontWeight.Black) }
            MonsterButton(onClick = {
                val list = store.lists[selected]
                if (list.isNotEmpty()) {
                    val at = list.indexOfFirst { it.mediaUri == activeMediaUri }
                    onPlay(list[if (at < 0 || at >= list.lastIndex) 0 else at + 1])
                }
            }, modifier = Modifier.width(62.dp).height(54.dp)) { Text("›", fontSize = 30.sp, fontWeight = FontWeight.Black) }
            StoneButton(onClick = {
                store.lock(selected)
                val next = (selected + 1) % 4
                store.activate(next)
                onSelected(next)
            }, modifier = Modifier.width(132.dp).height(58.dp), active = false) {
                Text("LOCK", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Serif)
            }
        }
        if (showHint && store.lists[selected].isNotEmpty()) {
            Text("DRŽI + ↑ / ↓   •   BRZO ← REMOVE", color = MonsterGreen, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth().background(Color(0xDD101610)).padding(8.dp))
        }
        LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(store.lists[selected], key = { _, g -> g.mediaUri }) { index, ghost ->
                var dragX by remember(ghost.mediaUri) { mutableFloatStateOf(0f) }
                var dragY by remember(ghost.mediaUri) { mutableFloatStateOf(0f) }
                val isActive = activeMediaUri == ghost.mediaUri
                Row(
                    Modifier.fillMaxWidth()
                        .background(if (isActive && activePlaying) Color(0xFF383838) else Color.Transparent)
                        .monsterRow()
                        .pointerInput(ghost.mediaUri, index, selected) {
                            detectDragGesturesAfterLongPress(
                                onDragStart = { dragX = 0f; dragY = 0f },
                                onDrag = { change, amount -> change.consume(); dragX += amount.x; dragY += amount.y },
                                onDragEnd = {
                                    when {
                                        dragX < -80.dp.toPx() && abs(dragX) > abs(dragY) -> store.remove(selected, index)
                                        dragY < -45.dp.toPx() && index > 0 -> store.move(selected, index, index - 1)
                                        dragY > 45.dp.toPx() && index < store.lists[selected].lastIndex -> store.move(selected, index, index + 1)
                                    }
                                    onGestureLearned()
                                }
                            )
                        }
                        .clickable { onPlay(ghost) }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${index + 1}.", color = MonsterGreen, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(44.dp))
                    Text(ghost.name, color = Color.White, fontSize = 23.sp, lineHeight = 29.sp, fontFamily = FontFamily.Serif, modifier = Modifier.weight(1f))
                    if (ghost.mediaUri.lowercase().contains(".yt")) Text("YT", color = Color.Red, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}
