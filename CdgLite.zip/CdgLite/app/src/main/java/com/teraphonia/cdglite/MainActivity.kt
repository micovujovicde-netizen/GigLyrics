package com.teraphonia.cdglite

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.WindowManager
import android.widget.Toast
import android.media.AudioManager
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.key.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.zIndex
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.*
import java.net.URLEncoder
import java.util.Locale

internal enum class PopupSize(val fraction: Float) {
    QUARTER(.25f), HALF(.5f), FULL(1f);
    fun next() = entries[(ordinal + 1) % entries.size]
    fun nextLabel() = when (this) { QUARTER -> "1/2"; HALF -> "FULL"; FULL -> "1/4" }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        volumeControlStream = AudioManager.STREAM_MUSIC
        val playback = ViewModelProvider(this)[PlaybackModel::class.java]
        setContent { CdgLite(playback) }
    }
}

@Composable
internal fun CdgLite(playback: PlaybackModel, libraryRoot: DocumentFile? = null) {
    val context = LocalContext.current
    val focus = LocalFocusManager.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("cdglite", 0) }
    var root by rememberSaveable { mutableStateOf(libraryRoot?.uri?.toString() ?: prefs.getString("root", null)) }
    var path by rememberSaveable { mutableStateOf(arrayListOf<String>()) }
    var breakRoot by rememberSaveable { mutableStateOf(prefs.getString("breakRoot", null)) }
    var breakPath by rememberSaveable { mutableStateOf(arrayListOf<String>()) }
    var breakVisible by rememberSaveable { mutableStateOf(false) }
    var breakFolders by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var breakSongs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var breakLoading by remember { mutableStateOf(false) }
    var breakError by remember { mutableStateOf<String?>(null) }
    var folders by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var texts by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var libraryError by remember { mutableStateOf<String?>(null) }
    var localSearchIndex by remember { mutableStateOf<List<LocalSearchEntry>?>(null) }
    var localSearchIndexRoot by remember { mutableStateOf<String?>(null) }
    var localSearchIndexError by remember { mutableStateOf<String?>(null) }
    var query by rememberSaveable { mutableStateOf("") }
    var submittedQuery by rememberSaveable { mutableStateOf("") }
    var webQuery by rememberSaveable { mutableStateOf("") }
    var karaokeVisible by rememberSaveable { mutableStateOf(false) }
    var lyricsVisible by rememberSaveable { mutableStateOf(false) }
    val glupan = playback.karaokeWeb
    val tupan = playback.lyricsWeb
    var browserSize by rememberSaveable { mutableStateOf(PopupSize.HALF) }
    var localFullscreen by rememberSaveable { mutableStateOf(false) }
    val audio = remember { context.getSystemService(android.content.Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var volume by remember { mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVolume) }
    val savedFontScale = prefs.getFloat("fontScale", 1f).let { if (it.isFinite()) it.coerceIn(.75f, 2.2f) else 1f }
    var fontScale by remember { mutableFloatStateOf(savedFontScale) }
    val listState = rememberLazyListState()

    fun showLibrary() { focus.clearFocus() }
    fun home() {
        showLibrary()
        breakVisible = false
        breakPath = arrayListOf()
        path = arrayListOf()
        query = ""
        submittedQuery = ""
        localFullscreen = false
        browserSize = PopupSize.HALF
        scope.launch { listState.scrollToItem(0) }
    }
    fun back() {
        showLibrary()
        if (localFullscreen) { localFullscreen = false; return }
        if ((karaokeVisible || lyricsVisible) && browserSize == PopupSize.FULL) { browserSize = PopupSize.HALF; return }
        if (breakVisible) {
            if (breakPath.isNotEmpty()) breakPath = ArrayList(breakPath.dropLast(1))
            else breakVisible = false
            return
        }
        if (path.isNotEmpty()) path = ArrayList(path.dropLast(1))
        query = ""
        submittedQuery = ""
    }
    fun runLocalSearch(raw: String) {
        showLibrary()
        val term = raw.trim()
        query = term
        submittedQuery = term
        scope.launch { listState.scrollToItem(0) }
    }
    fun localSearch() = runLocalSearch(query)
    fun runWebSearch(raw: String) {
        val term = raw.trim()
        if (term.isBlank()) return
        webQuery = term
        focus.clearFocus()
        playback.showCdg = false
        localFullscreen = false
        browserSize = PopupSize.HALF
        lyricsVisible = false
        tupan.close()
        karaokeVisible = true
        // GLUPAN: direct YouTube/NewPipe-style search route, with KARAOKE as a prefix.
        val karaokeQuery = "karaoke $term"
        glupan.open("https://www.youtube.com/results?search_query=" + URLEncoder.encode(karaokeQuery, "UTF-8"))
    }
    fun webSearch() = runWebSearch(webQuery)
    fun externalScreen() {
        val manager = context.getSystemService(android.content.Context.DISPLAY_SERVICE) as android.hardware.display.DisplayManager
        val display = manager.getDisplays(android.hardware.display.DisplayManager.DISPLAY_CATEGORY_PRESENTATION).firstOrNull()
        if (display == null) {
            Toast.makeText(context, "Spoji eksterni monitor / TV", Toast.LENGTH_SHORT).show()
        } else {
            // UI hook is ready. The dedicated external karaoke Presentation will attach here.
            Toast.makeText(context, "EXT SCREEN: ${display.name}", Toast.LENGTH_SHORT).show()
        }
    }
    fun openBreak() {
        showLibrary()
        breakPath = arrayListOf()
        breakVisible = true
        karaokeVisible = false
        lyricsVisible = false
        playback.showCdg = false
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                root = uri.toString()
                prefs.edit().putString("root", root).apply()
                home()
            } catch (_: SecurityException) { libraryError = "Nije odobren pristup folderu." }
        }
    }
    val breakPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                breakRoot = uri.toString()
                prefs.edit().putString("breakRoot", breakRoot).apply()
                openBreak()
            } catch (_: SecurityException) { breakError = "Nije odobren pristup BREAK folderu." }
        }
    }
    val localVoice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let(::runLocalSearch)
    }
    val webVoice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let(::runWebSearch)
    }
    fun voiceIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_PROMPT, "Naziv pjesme")
    }
    fun voice(web: Boolean) {
        try { if (web) webVoice.launch(voiceIntent()) else localVoice.launch(voiceIntent()) }
        catch (_: android.content.ActivityNotFoundException) { libraryError = "Glasovna pretraga nije dostupna na ovom uređaju." }
    }

    LaunchedEffect(Unit) {
        playback.setVolume(1f)
        while (isActive) {
            volume = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVolume
            delay(300)
        }
    }
    // Build one deep index in the background for the selected root. Subsequent local
    // searches are instant in-memory filters instead of another full SAF traversal.
    LaunchedEffect(root) {
        val target = root
        localSearchIndex = null
        localSearchIndexRoot = target
        localSearchIndexError = null
        if (target != null) {
            try {
                val rootDir = libraryRoot ?: DocumentFile.fromTreeUri(context, Uri.parse(target)) ?: error("Missing folder")
                localSearchIndex = buildLocalSearchIndex(rootDir)
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) {
                localSearchIndex = emptyList()
                localSearchIndexError = "Local search indeks nije mogao da se učita. Izaberi FOLDER ponovo."
            }
        }
    }

    LaunchedEffect(path, root, submittedQuery, localSearchIndex, localSearchIndexRoot) {
        folders = emptyList()
        songs = emptyList()
        texts = emptyList()
        libraryError = null
        val target = root
        if (target == null) {
            loading = false
            return@LaunchedEffect
        }

        // If the user searches immediately after opening the app, show progress only until
        // the one-time background index is ready. This effect reruns automatically then.
        if (submittedQuery.isNotBlank() && (localSearchIndexRoot != target || localSearchIndex == null)) {
            loading = true
            return@LaunchedEffect
        }

        loading = true
        try {
            if (submittedQuery.isNotBlank()) {
                songs = searchLocalIndex(localSearchIndex.orEmpty(), submittedQuery)
            } else {
                val result = withContext(Dispatchers.IO) {
                    var dir = libraryRoot ?: DocumentFile.fromTreeUri(context, Uri.parse(target)) ?: error("Missing folder")
                    for (name in path) { dir = dir.findFile(name) ?: error("Missing folder") }
                    scanFolder(dir, "")
                }
                folders = result.folders
                songs = result.songs
                texts = result.texts
            }
        } catch (e: CancellationException) { throw e }
        catch (_: Exception) { libraryError = "Folder nije dostupan. Izaberi ga ponovo pomoću FOLDER." }
        finally { loading = false }
    }
    LaunchedEffect(breakVisible, breakRoot, breakPath) {
        if (!breakVisible) return@LaunchedEffect
        breakFolders = emptyList()
        breakSongs = emptyList()
        breakError = null
        val target = breakRoot
        if (target == null) {
            breakLoading = false
            return@LaunchedEffect
        }
        breakLoading = true
        try {
            val result = withContext(Dispatchers.IO) {
                var dir = DocumentFile.fromTreeUri(context, Uri.parse(target)) ?: error("Missing BREAK folder")
                for (name in breakPath) dir = dir.findFile(name) ?: error("Missing BREAK subfolder")
                scanFolder(dir, "")
            }
            breakFolders = result.folders
            breakSongs = result.songs
        } catch (e: CancellationException) { throw e }
        catch (_: Exception) { breakError = "BREAK folder nije dostupan. Drži BREAK da izabereš ponovo." }
        finally { breakLoading = false }
    }

    DisposableEffect(playback.isPlaying, glupan.isPlaying, playback.breakIsPlaying) {
        val window = (context as? ComponentActivity)?.window
        if (playback.isPlaying || glupan.isPlaying || playback.breakIsPlaying) window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }
    BackHandler(true) { back() }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Column(Modifier.fillMaxSize().background(Color.Black).safeDrawingPadding().imePadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = { if (breakVisible) home() else if (root == null) picker.launch(null) else home() },
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier.width(144.dp).height(52.dp).testTag("home")
                ) { Text(if (root == null && !breakVisible) "SELECT FOLDER" else "HOME", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                Button(
                    onClick = { back() },
                    enabled = if (breakVisible) true else path.isNotEmpty() || localFullscreen || ((karaokeVisible || lyricsVisible) && browserSize == PopupSize.FULL),
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier.width(144.dp).height(52.dp).testTag("back")
                ) { Text("‹", fontSize = 40.sp) }
                Slider(value = volume, onValueChange = { volume = it; audio.setStreamVolume(AudioManager.STREAM_MUSIC, (it * maxVolume).toInt(), 0) }, modifier = Modifier.weight(1f).testTag("mainVolume"))
                TextButton(onClick = { if (breakVisible) breakPicker.launch(null) else picker.launch(null) }) { Text(if (breakVisible) "CHANGE" else "FOLDER") }
            }
            // CDG is part of the layout, not an overlay: the song list ends at its top edge.
            Column(Modifier.weight(1f).fillMaxWidth()) {
                Box((if (localFullscreen && playback.showCdg) Modifier.height(0.dp) else Modifier.weight(1f)).fillMaxWidth()) {
                if (breakVisible) {
                    BreakBrowser(
                        folders = breakFolders,
                        songs = breakSongs,
                        loading = breakLoading,
                        error = breakError,
                        path = breakPath,
                        playback = playback,
                        openFolder = { dir ->
                            dir.name?.let { name -> breakPath = ArrayList(breakPath + name) }
                        },
                        playSong = { song ->
                            playback.showCdg = false
                            playback.startBreakPlaylist(breakSongs.map { it.mp3 }, song.mp3)
                        },
                        modifier = Modifier.matchParentSize().zIndex(50f)
                    )
                }
                if (!breakVisible) {
                Column(Modifier.fillMaxSize().padding(horizontal = 10.dp)) {
                    if (path.isEmpty() && submittedQuery.isEmpty()) Text("CdgLite", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
                    if (path.isEmpty()) {
                        SearchRow(query, { query = it; if (it.isEmpty()) submittedQuery = "" }, "LOCAL SEARCH — FILES", "local", ::localSearch, { voice(false) })
                        SearchRow(webQuery, { webQuery = it }, "WEB KARAOKE SEARCH", "web", ::webSearch, { voice(true) })
                    }
                    val message = playback.error ?: libraryError ?: localSearchIndexError
                    if (message != null) Text(message, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp))
                    if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text(if (submittedQuery.isNotEmpty()) "${songs.size} rezultata u svim podfolderima" else "${folders.size} foldera • ${songs.size} pjesama", fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize().testTag("library").pointerInput(Unit) {
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false)
                                var pinching = false
                                do {
                                    val event = awaitPointerEvent()
                                    if (event.changes.count { it.pressed } >= 2) {
                                        pinching = true
                                        val zoom = event.calculateZoom()
                                        if (zoom.isFinite() && zoom > 0f) {
                                            val nextScale = fontScale * zoom
                                            fontScale = if (nextScale.isFinite()) nextScale.coerceIn(.75f, 2.2f) else 1f
                                            prefs.edit().putFloat("fontScale", fontScale).apply()
                                        }
                                        event.changes.forEach { it.consume() }
                                    }
                                } while (event.changes.any { it.pressed })
                                if (pinching) prefs.edit().putFloat("fontScale", fontScale).commit()
                            }
                        }
                    ) {
                        if (!loading && folders.isEmpty() && songs.isEmpty() && texts.isEmpty()) item {
                            Text(if (root == null) "Izaberi FOLDER sa muzikom." else "Nema pjesama. Pretraži drugi naziv ili izaberi folder.", modifier = Modifier.padding(16.dp))
                        }
                        itemsIndexed(folders, key = { _, item -> item.uri.toString() }) { index, dir ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "📁  ${dir.name ?: "Folder"}",
                                    color = Color.White,
                                    fontSize = (22 * fontScale).sp,
                                    lineHeight = (36 * fontScale).sp,
                                    softWrap = true,
                                    modifier = Modifier.weight(1f).clickable {
                                        path = ArrayList(path + (dir.name ?: return@clickable)); query = ""; submittedQuery = ""
                                        focus.clearFocus(); scope.launch { listState.scrollToItem(0) }
                                    }.padding(16.dp)
                                )
                                if (index == 0 && path.isEmpty() && submittedQuery.isEmpty()) {
                                    BreakButton(
                                        onClick = { if (breakRoot == null) breakPicker.launch(null) else openBreak() },
                                        onLongClick = { breakPicker.launch(null) }
                                    )
                                }
                            }
                        }
                        items(songs, key = { it.mp3.uri.toString() }) { song ->
                            Row(Modifier.fillMaxWidth().clickable {
                                showLibrary()
                                karaokeVisible = false
                                lyricsVisible = false
                                localFullscreen = false
                                if (playback.song?.mp3?.uri == song.mp3.uri && (playback.isPlaying || playback.preparing)) playback.stop()
                                else { playback.startLocal(song) }
                            }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    song.name,
                                    color = Color.White,
                                    fontSize = (22 * fontScale).sp,
                                    lineHeight = (36 * fontScale).sp,
                                    softWrap = true,
                                    modifier = Modifier.weight(1f)
                                )
                                if (playback.song?.mp3?.uri == song.mp3.uri) Text(if (playback.isPlaying) "▶" else "■", modifier = Modifier.padding(start = 8.dp).testTag("activeTrackState"), fontSize = 14.sp)
                                if (song.cdg != null) Text("CDG", color = Color.Green, modifier = Modifier.padding(start = 8.dp))
                                song.text?.let { sidecar ->
                                    val type = sidecar.extension().uppercase(Locale.ROOT)
                                    val labelColor = when (type) {
                                        "LRC" -> Color.Yellow
                                        "TXT" -> Color(0xFF4D9DFF)
                                        "SRT" -> Color(0xFFB97836)
                                        "LYR3" -> Color.Red
                                        else -> Color.Cyan
                                    }
                                    Text(type, color = labelColor,
                                        modifier = Modifier.padding(start = 8.dp).testTag("lyricsSidecarType"))
                                }
                            }
                        }
                    }
                }
                }
                // GLUPAN: karaoke browser. No EXTRACT button exists on this path.
                if (glupan.opened && !breakVisible) {
                    WebPanel(visible = karaokeVisible, size = browserSize) {
                        Browser(glupan, karaokeVisible, showExtract = false, onExtract = {})
                        if (karaokeVisible) {
                            glupan.message?.let { Text(it, modifier = Modifier.align(Alignment.BottomCenter).background(Color.Black.copy(alpha = .8f)).padding(8.dp)) }
                        }
                    }
                }
                // TUPAN: lyrics-only browser. The proven extract filter lives only here.
                if (tupan.opened && !breakVisible) {
                    WebPanel(visible = lyricsVisible, size = browserSize) {
                        Browser(tupan, lyricsVisible, showExtract = true, onExtract = {
                            tupan.extractLyrics { extracted ->
                                if (extracted != null && playback.previewExtractedLyrics(extracted)) {
                                    lyricsVisible = false
                                    tupan.close()
                                    playback.showCdg = true
                                } else Toast.makeText(context, "Lyrics nisu pronađeni na ovoj stranici", Toast.LENGTH_LONG).show()
                            }
                        })
                        if (lyricsVisible) {
                            tupan.message?.let { Text(it, modifier = Modifier.align(Alignment.BottomCenter).background(Color.Black.copy(alpha = .8f)).padding(8.dp)) }
                        }
                    }
                }
                }
                // Local monitor button is authoritative: when showCdg is false, the
                // CDG/TXT/LRC/SRT/LYR3 half-screen panel must really leave the layout.
                if (playback.showCdg && !breakVisible) {
                    CdgSurface {
                        val bitmap = playback.frame
                        if (playback.song?.isVideo == true && !playback.showTextOnly) {
                            LocalVideo(playback)
                        } else if (playback.activeTextSidecar != null || playback.activeEmbeddedLyrics || playback.extractedPreview) {
                            // TXT Sync Edit is intentionally isolated from LRC/SRT/LYR/LYR3.
                            if (playback.syncEditActive) SyncEditLyrics(playback)
                            else if (playback.timedLyrics.isNotEmpty() && !playback.showTextOnly) TimedLyrics(playback)
                            else Column(Modifier.fillMaxSize()) {
                                key(playback.activeTextSidecar?.uri, playback.activeEmbeddedLyrics, playback.lyricsText) {
                                    Text(playback.lyricsText ?: "Učitavanje…", color = Color.White, fontSize = 32.sp, lineHeight = 42.sp,
                                        modifier = Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState()).padding(14.dp).testTag("lyricsText"))
                                }
                                if (playback.extractedPreview) Button(
                                    onClick = {
                                        val text = playback.lyricsText.orEmpty()
                                        if (playback.saveExtractedLyrics(text)) Toast.makeText(context, "Lyrics saved", Toast.LENGTH_SHORT).show()
                                        else Toast.makeText(context, "Lyrics nisu sačuvani", Toast.LENGTH_LONG).show()
                                    },
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp).testTag("saveExtractedLyrics")
                                ) { Text("SAVE", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
                            }
                        } else if (bitmap != null) Image(bitmap.asImageBitmap(), "Karaoke tekst", Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                        else if (playback.song?.cdg != null) Text("Učitavanje CDG…", modifier = Modifier.align(Alignment.Center))
                        else Button(
                            onClick = {
                                val title = playback.song?.name.orEmpty()
                                if (title.isNotBlank()) {
                                    webQuery = title
                                    focus.clearFocus()
                                    browserSize = PopupSize.HALF
                                    karaokeVisible = false
                                    glupan.close()
                                    lyricsVisible = true
                                    playback.showCdg = false
                                    tupan.open("https://www.google.com/search?q=" + URLEncoder.encode("lyrics $title -site:youtube.com -site:youtu.be -site:music.youtube.com -site:vimeo.com -site:dailymotion.com -site:tiktok.com", "UTF-8"))
                                }
                            },
                            modifier = Modifier.align(Alignment.Center).testTag("findLyricsOnline")
                        ) { Text("Find lyrics online", fontSize = 22.sp) }
                    }
                }
            }
            if (breakVisible) BreakPlaybackBar(playback)
            else if (playback.breakTrack != null) { /* BREAK continues silently in the background UI. */ }
            else if (tupan.opened && lyricsVisible) LyricsBrowserBar(
                back = {
                    if (!tupan.goBack()) {
                        lyricsVisible = false
                        tupan.close()
                        browserSize = PopupSize.HALF
                        playback.showCdg = playback.song != null
                    }
                },
                toggleFullscreen = { browserSize = if (browserSize == PopupSize.FULL) PopupSize.HALF else PopupSize.FULL },
                isFullscreen = browserSize == PopupSize.FULL,
                externalScreen = ::externalScreen
            )
            else if (glupan.opened && (karaokeVisible || glupan.isPlaying || playback.song == null)) WebPlaybackBar(
                controller = glupan,
                visible = karaokeVisible,
                monitor = {
                    playback.showCdg = false
                    localFullscreen = false
                    karaokeVisible = !karaokeVisible
                    if (!karaokeVisible) browserSize = PopupSize.HALF
                },
                toggleFullscreen = {
                    karaokeVisible = true
                    browserSize = if (browserSize == PopupSize.FULL) PopupSize.HALF else PopupSize.FULL
                },
                isFullscreen = browserSize == PopupSize.FULL,
                externalScreen = ::externalScreen,
                back = {
                    if (!glupan.goBack()) { karaokeVisible = false; browserSize = PopupSize.HALF }
                }
            )
            else if (playback.song != null && playback.breakTrack == null) PlaybackBar(
                playback = playback,
                resume = {
                    if (!playback.isPlaying) glupan.stopForLocal()
                    playback.togglePause()
                },
                show = {
                    showLibrary()
                    playback.showCdg = !playback.showCdg
                    if (!playback.showCdg) localFullscreen = false
                },
                toggleFullscreen = {
                    playback.showCdg = true
                    localFullscreen = !localFullscreen
                },
                isFullscreen = localFullscreen,
                externalScreen = ::externalScreen
            )
        }
    }
}

@Composable
private fun BreakButton(onClick: () -> Unit, onLongClick: () -> Unit) {
    Box(
        Modifier
            .padding(end = 8.dp)
            .size(112.dp, 54.dp)
            .background(Color(0xff24313f))
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onClick() },
                    onLongPress = { onLongClick() }
                )
            }
            .testTag("breakButton"),
        contentAlignment = Alignment.Center
    ) {
        Text("BREAK PLAYER", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun BreakModeGlyph(
    glyph: String,
    selected: Boolean,
    description: String,
    tag: String,
    onClick: () -> Unit
) {
    Column(
        Modifier.width(72.dp).height(58.dp).clickable(onClick = onClick).testTag(tag),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(glyph, color = if (selected) Color.White else Color.Gray, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(description, color = if (selected) Color.White else Color.Gray, fontSize = 9.sp, maxLines = 1)
    }
}

@Composable
private fun BreakBrowser(
    folders: List<DocumentFile>,
    songs: List<Song>,
    loading: Boolean,
    error: String?,
    path: List<String>,
    playback: PlaybackModel,
    openFolder: (DocumentFile) -> Unit,
    playSong: (Song) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.background(Color.Black).padding(horizontal = 10.dp)) {
        Text(
            "BREAK",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
        )

        Text(
            if (path.isEmpty()) "BREAK folder" else "BREAK / ${path.joinToString(" / ")}",
            fontSize = 14.sp,
            color = Color.LightGray,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        Row(
            Modifier.fillMaxWidth().padding(vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.End
        ) {
            BreakModeGlyph(
                glyph = if (playback.breakRandom) "🔀" else "⇉",
                selected = true,
                description = if (playback.breakRandom) "RANDOM" else "ORDER",
                tag = "breakOrderRandom"
            ) { playback.updateBreakRandom(!playback.breakRandom) }
            BreakModeGlyph(
                glyph = "↻",
                selected = playback.breakRepeat,
                description = if (playback.breakRepeat) "REPEAT ON" else "REPEAT OFF",
                tag = "breakRepeat"
            ) { playback.updateBreakRepeat(!playback.breakRepeat) }
        }

        if (error != null) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp))
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        Text("${folders.size} foldera • ${songs.size} pjesama", fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))

        LazyColumn(Modifier.fillMaxSize().testTag("breakLibrary")) {
            items(folders, key = { it.uri.toString() }) { dir ->
                Text(
                    "📁  ${dir.name ?: "Folder"}",
                    color = Color.White,
                    fontSize = 24.sp,
                    lineHeight = 36.sp,
                    modifier = Modifier.fillMaxWidth().clickable { openFolder(dir) }.padding(16.dp)
                )
            }
            items(songs, key = { it.mp3.uri.toString() }) { song ->
                val active = playback.breakTrack?.uri == song.mp3.uri
                Row(
                    Modifier.fillMaxWidth().clickable { playSong(song) }.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        song.name,
                        color = Color.White,
                        fontSize = 24.sp,
                        lineHeight = 36.sp,
                        softWrap = true,
                        modifier = Modifier.weight(1f)
                    )
                    if (active) Text(if (playback.breakIsPlaying) "▶" else "Ⅱ", fontSize = 18.sp)
                }
            }
            if (!loading && folders.isEmpty() && songs.isEmpty()) item {
                Text("Nema audio fajlova u ovom folderu.", modifier = Modifier.padding(16.dp))
            }
        }
    }
}

@Composable
private fun BreakPlaybackBar(playback: PlaybackModel) {
    Column(Modifier.fillMaxWidth().background(Color(0xff18212b)).padding(horizontal = 10.dp)) {
        Text(
            playback.breakTrack?.name ?: "BREAK",
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp)
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(
                onClick = { playback.toggleBreakPause() },
                enabled = !playback.breakPreparing,
                modifier = Modifier.testTag("breakPause")
            ) { Text(if (playback.breakIsPlaying) "Ⅱ" else "▶", fontSize = 28.sp) }
            TextButton(onClick = { playback.stopBreak() }, modifier = Modifier.testTag("breakStop")) {
                Text("■", fontSize = 26.sp)
            }
            TextButton(onClick = { playback.nextBreak() }, modifier = Modifier.testTag("breakNext")) {
                Text("⏭", fontSize = 28.sp)
            }
            Spacer(Modifier.weight(1f))
            Text(
                if (playback.breakPreparing) "Učitavanje…" else "${time(playback.breakPosition)} / ${time(playback.breakDuration)}",
                fontSize = 12.sp
            )
        }
        Slider(
            value = if (playback.breakDuration > 0) playback.breakPosition.coerceIn(0, playback.breakDuration).toFloat() else 0f,
            onValueChange = { playback.seekBreakTo(it.toInt()) },
            valueRange = 0f..playback.breakDuration.coerceAtLeast(1).toFloat(),
            enabled = !playback.breakPreparing && playback.breakDuration > 0,
            modifier = Modifier.fillMaxWidth().testTag("breakSeek")
        )
    }
}

@Composable
internal fun ColumnScope.CdgSurface(content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxWidth().weight(1f).background(Color.Black).testTag("CDGPanel")) {
        Box(Modifier.fillMaxWidth().height(3.dp).align(Alignment.TopCenter).background(Color.White).zIndex(5f))
        Box(Modifier.fillMaxSize().padding(top = 3.dp), content = content)
    }
}

@Composable
private fun BoxScope.LocalVideo(playback: PlaybackModel) {
    Column(Modifier.fillMaxSize()) {
        AndroidView(
            factory = { context -> SurfaceView(context).apply {
                holder.addCallback(object : SurfaceHolder.Callback {
                    override fun surfaceCreated(holder: SurfaceHolder) { playback.setVideoSurface(holder) }
                    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) = Unit
                    override fun surfaceDestroyed(holder: SurfaceHolder) { playback.setVideoSurface(null) }
                })
            } },
            modifier = Modifier.fillMaxWidth().weight(if (playback.lyricsText == null) 1f else .68f)
        )
        playback.lyricsText?.let { lyrics ->
            Box(Modifier.fillMaxWidth().weight(.32f)) {
                if (playback.timedLyrics.isNotEmpty()) TimedLyrics(playback)
                else key(playback.popupTitle, lyrics) {
                    Text(lyrics, color = Color.White, fontSize = 30.sp, lineHeight = 40.sp,
                        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp))
                }
            }
        }
    }
}

@Composable
private fun SyncEditLyrics(playback: PlaybackModel) {
    val context = LocalContext.current
    val lines = playback.syncLines
    val next = playback.syncNextIndex
    val state = rememberLazyListState()
    LaunchedEffect(next, lines) {
        if (next in lines.indices) state.animateScrollToItem(next)
    }

    val finger = rememberInfiniteTransition(label = "syncFinger")
    val fingerAlpha by finger.animateFloat(
        initialValue = .35f,
        targetValue = .82f,
        animationSpec = infiniteRepeatable(tween(450), RepeatMode.Reverse),
        label = "syncFingerAlpha"
    )
    val fingerMove by finger.animateFloat(
        initialValue = 0f,
        targetValue = 10f,
        animationSpec = infiniteRepeatable(tween(450), RepeatMode.Reverse),
        label = "syncFingerMove"
    )

    Column(Modifier.fillMaxSize()) {
        LazyColumn(
            state = state,
            modifier = Modifier.fillMaxWidth().weight(1f).testTag("syncEditLyrics"),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            items(lines.size) { index ->
                val line = lines[index]
                if (line.isBlank()) Spacer(Modifier.height(14.dp))
                else Box(
                    Modifier.fillMaxWidth().heightIn(min = 54.dp)
                        .background(if (index == next && !playback.syncEditFinished) Color(0xff242424) else Color.Transparent)
                        .clickable(enabled = !playback.syncEditFinished && index == next) { playback.tapSyncLine(index) }
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Text(
                        line,
                        color = if (playback.syncTimes.getOrNull(index) != null) Color.LightGray else Color.White,
                        fontSize = 32.sp,
                        lineHeight = 42.sp,
                        fontWeight = if (index == next && !playback.syncEditFinished) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.fillMaxWidth().padding(end = 66.dp)
                    )
                    if (playback.syncFingerVisible && index == next && !playback.syncEditFinished) {
                        Text(
                            "👆",
                            fontSize = 46.sp,
                            modifier = Modifier.align(Alignment.CenterEnd).alpha(fingerAlpha)
                                .graphicsLayer { translationY = fingerMove }
                                .testTag("syncFinger")
                        )
                    }
                }
            }
        }
        if (playback.syncEditFinished) {
            Button(
                onClick = {
                    if (playback.saveSyncEdit()) Toast.makeText(context, "SYNC saved", Toast.LENGTH_SHORT).show()
                    else Toast.makeText(context, "Nisu svi TXT redovi tapnuti — pokreni SYNC EDIT ponovo", Toast.LENGTH_LONG).show()
                },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp).testTag("saveSyncEdit")
            ) { Text("SAVE", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun TimedLyrics(playback: PlaybackModel) {
    val lines = playback.timedLyrics
    val active = lines.indexOfLast { it.startMs <= playback.position }.coerceAtLeast(0)
    val state = rememberLazyListState()
    LaunchedEffect(active, lines) { if (lines.isNotEmpty()) state.animateScrollToItem(active) }
    LazyColumn(state = state, modifier = Modifier.fillMaxSize().testTag("timedLyrics"),
        contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        items(lines.size) { index ->
            Text(lines[index].text, color = Color.White,
                fontSize = 32.sp, lineHeight = 42.sp, fontWeight = if (index == active) FontWeight.Bold else FontWeight.Normal)
        }
    }
}

@Composable
internal fun SearchRow(value: String, change: (String) -> Unit, label: String, tag: String, submit: () -> Unit, voice: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value, change, singleLine = true, label = { Text(label, fontSize = 12.sp) },
            modifier = Modifier.weight(1f).testTag("${tag}Search").onPreviewKeyEvent {
                if (it.key == Key.Enter || it.key == Key.NumPadEnter) {
                    if (it.type == KeyEventType.KeyUp) submit()
                    true
                } else false
            },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { submit() }, onDone = { submit() }, onGo = { submit() })
        )
        TextButton(onClick = submit, modifier = Modifier.testTag("${tag}Submit")) { Text("GO") }
        TextButton(onClick = voice, contentPadding = PaddingValues(0.dp), modifier = Modifier.width(48.dp)) { Text("🎤", fontSize = 22.sp) }
    }
}

@Composable
internal fun BoxScope.OverlayPanel(size: PopupSize, title: String, resize: () -> Unit, close: () -> Unit, visible: Boolean = true, content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().fillMaxHeight(size.fraction)
        .zIndex(if (visible) 10f else -1f).alpha(if (visible) 1f else 0f).background(Color.Black).testTag("${title}Panel")) {
        Box(Modifier.fillMaxWidth().height(3.dp).align(Alignment.TopCenter).background(Color.White).zIndex(20f))
        // A separate background hit target blocks the library without intercepting
        // button or WebView gestures. Interactive content is drawn above it.
        Box(Modifier.matchParentSize().pointerInput(Unit) {
            awaitPointerEventScope { while (true) {
                awaitPointerEvent().changes.forEach { it.consume() }
            } }
        })
        Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().height(48.dp).background(Color(0xff20242a)), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = resize) { Text(size.nextLabel()) }
            Text(title, modifier = Modifier.weight(1f))
            TextButton(onClick = close, modifier = Modifier.testTag("${title}Close")) { Text("×", fontSize = 28.sp) }
        }
        Box(Modifier.weight(1f).fillMaxWidth(), content = content)
        }
    }
}


@Composable
internal fun BoxScope.WebPanel(visible: Boolean, size: PopupSize = PopupSize.HALF, content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier.align(Alignment.BottomCenter).fillMaxWidth().fillMaxHeight(size.fraction)
            .zIndex(if (visible) 10f else -1f).alpha(if (visible) 1f else 0f)
            .background(Color.Black).testTag("WEBPanel")
    ) {
        Box(Modifier.fillMaxWidth().height(3.dp).align(Alignment.TopCenter).background(Color.White).zIndex(20f))
        Box(Modifier.fillMaxSize().padding(top = 3.dp), content = content)
    }
}

@Composable
private fun WebPlaybackBar(
    controller: WebAudioController,
    visible: Boolean,
    monitor: () -> Unit,
    toggleFullscreen: () -> Unit,
    isFullscreen: Boolean,
    externalScreen: () -> Unit,
    back: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xff18212b)).padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(onClick = { controller.togglePause() }, modifier = Modifier.testTag("webPause")) {
            Text(if (controller.isPlaying) "Ⅱ" else "▶", fontSize = 28.sp)
        }
        TextButton(onClick = { controller.stop() }, modifier = Modifier.testTag("webStop")) { Text("■", fontSize = 26.sp) }
        TextButton(onClick = monitor, modifier = Modifier.testTag("webMonitor")) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("▣", fontSize = 28.sp)
                Spacer(Modifier.width(4.dp))
                Text("MONITOR", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
        TextButton(onClick = toggleFullscreen, modifier = Modifier.testTag("webFullscreen")) {
            Text(if (isFullscreen) "↙" else "⛶", fontSize = 28.sp)
        }
        TextButton(onClick = externalScreen, modifier = Modifier.testTag("webExternalScreen")) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("▣", fontSize = 26.sp)
                Spacer(Modifier.width(4.dp))
                Text("EXT", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.weight(1f))
        if (!visible) Text("WEB", fontSize = 12.sp)
        TextButton(onClick = back, modifier = Modifier.testTag("karaokeBrowserBack")) {
            Text("◀", fontSize = 28.sp)
        }
    }
}

@Composable
private fun LyricsBrowserBar(back: () -> Unit, toggleFullscreen: () -> Unit, isFullscreen: Boolean, externalScreen: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xff18212b)).padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("LYRICS", fontSize = 12.sp)
        TextButton(onClick = toggleFullscreen, modifier = Modifier.testTag("lyricsFullscreen")) {
            Text(if (isFullscreen) "↙" else "⛶", fontSize = 28.sp)
        }
        TextButton(onClick = externalScreen, modifier = Modifier.testTag("lyricsExternalScreen")) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("▣", fontSize = 26.sp)
                Spacer(Modifier.width(4.dp))
                Text("EXT", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.weight(1f))
        TextButton(onClick = back, modifier = Modifier.testTag("lyricsBrowserBack")) {
            Text("◀", fontSize = 28.sp)
        }
    }
}

@Composable
private fun PlaybackBar(
    playback: PlaybackModel,
    resume: () -> Unit,
    show: () -> Unit,
    toggleFullscreen: () -> Unit,
    isFullscreen: Boolean,
    externalScreen: () -> Unit
) {
    Column(Modifier.fillMaxWidth().background(Color(0xff18212b)).padding(horizontal = 10.dp)) {
        Text(playback.song?.name.orEmpty(), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = resume, enabled = !playback.preparing && !playback.syncEditFinished, modifier = Modifier.testTag("pause")) { Text(if (playback.isPlaying) "Ⅱ" else "▶", fontSize = 28.sp) }
            TextButton(onClick = { playback.stop() }, modifier = Modifier.testTag("stop")) { Text("■", fontSize = 26.sp) }
            TextButton(onClick = show, modifier = Modifier.testTag("showCdg")) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("▣", fontSize = 28.sp)
                    Spacer(Modifier.width(4.dp))
                    Text("MONITOR", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            TextButton(onClick = toggleFullscreen, modifier = Modifier.testTag("localFullscreen")) {
                Text(if (isFullscreen) "↙" else "⛶", fontSize = 28.sp)
            }
            TextButton(onClick = externalScreen, modifier = Modifier.testTag("localExternalScreen")) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("▣", fontSize = 26.sp)
                    Spacer(Modifier.width(4.dp))
                    Text("EXT", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            if (playback.activeTextSidecar?.extension() == "txt" && playback.lyricsText != null && playback.lyricsText != "Učitavanje…" && !playback.syncEditActive && !playback.extractedPreview) {
                TextButton(onClick = { playback.startSyncEdit() }, modifier = Modifier.testTag("syncEdit")) {
                    Text("SYNC EDIT", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.weight(1f))
            Text(if (playback.preparing) "Učitavanje…" else "${time(playback.position)} / ${time(playback.duration)}", fontSize = 12.sp)
        }
    }
}

private fun time(ms: Int) = "%d:%02d".format(Locale.ROOT, ms / 60000, ms / 1000 % 60)

@Composable
private fun Browser(
    controller: WebAudioController,
    visible: Boolean,
    showExtract: Boolean,
    onExtract: () -> Unit
) {
    val context = LocalContext.current
    val web = remember(controller) { controller.webView(context) }
    DisposableEffect(context) {
        controller.webView(context)
        onDispose { controller.detachContext() }
    }
    Box(Modifier.fillMaxSize()) {
        AndroidView(factory = { (web.parent as? android.view.ViewGroup)?.removeView(web); web },
            update = { it.setOnTouchListener { _, _ -> !visible } }, modifier = Modifier.fillMaxSize())
        if (visible && showExtract) Button(
            onClick = onExtract,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 10.dp).zIndex(20f).testTag("extractLyrics")
        ) { Text("EXTRACT", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
    }
}
