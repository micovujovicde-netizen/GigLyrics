package com.teraphonia.cdglite

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

private data class Song(val name:String, val mp3:DocumentFile, val cdg:DocumentFile?)
private enum class PopupSize { HALF, FULL }

class MainActivity: ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { CdgLite() } }
}

@Composable private fun CdgLite() {
 val ctx=LocalContext.current
 val prefs=remember { ctx.getSharedPreferences("cdglite",0) }
 var root by remember { mutableStateOf(prefs.getString("root",null)?.let(Uri::parse)) }
 var currentDir by remember { mutableStateOf<DocumentFile?>(null) }
 var navStack by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
 var folders by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
 var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
 var query by remember { mutableStateOf("") }
 var webQuery by remember { mutableStateOf("") }
 var browserUrl by remember { mutableStateOf<String?>(null) }
 var browserSize by remember { mutableStateOf(PopupSize.HALF) }
 var playing by remember { mutableStateOf<Song?>(null) }
 var player by remember { mutableStateOf<MediaPlayer?>(null) }
 var decoder by remember { mutableStateOf<CdgDecoder?>(null) }
 var frame by remember { mutableStateOf<Bitmap?>(null) }
 var cdgSize by remember { mutableStateOf(PopupSize.HALF) }
 var volume by remember { mutableFloatStateOf(prefs.getFloat("volume",1f)) }
 var fontScale by remember { mutableFloatStateOf(prefs.getFloat("fontScale",1f).coerceIn(.75f,2.2f)) }
 val isHome=navStack.isEmpty()

 val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
  if(uri!=null){
   ctx.contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)
   root=uri; prefs.edit().putString("root",uri.toString()).apply()
   currentDir=DocumentFile.fromTreeUri(ctx,uri); navStack=emptyList(); query=""
  }
 }
 val localVoice=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){ r ->
  r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { query=it }
 }
 val webVoice=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){ r ->
  r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { webQuery=it }
 }
 fun voiceIntent()=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{
  putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
  putExtra(RecognizerIntent.EXTRA_PROMPT,"Search")
 }
 fun openWebSearch(){
  if(webQuery.isNotBlank()){
   val q=URLEncoder.encode("$webQuery karaoke",StandardCharsets.UTF_8.toString())
   browserUrl="https://www.google.com/search?q=$q"; browserSize=PopupSize.HALF
  }
 }
 LaunchedEffect(root){ if(currentDir==null) currentDir=root?.let { DocumentFile.fromTreeUri(ctx,it) } }
 LaunchedEffect(currentDir){
  currentDir?.let { val x=scanDirectory(it); folders=x.first;songs=x.second } ?: run { folders=emptyList();songs=emptyList() }
 }
 DisposableEffect(Unit){ onDispose { player?.release() } }
 LaunchedEffect(player,decoder){ while(player!=null&&decoder!=null){ val p=player?:break;val d=decoder?:break;if(p.isPlaying){d.seekTo(p.currentPosition);frame=d.bitmapCopy()};delay(40) } }
 fun closeCdg(){ player?.stop();player?.release();player=null;decoder=null;frame=null;playing=null;cdgSize=PopupSize.HALF }
 fun play(song:Song){
  closeCdg();val mp=MediaPlayer();mp.setDataSource(ctx,song.mp3.uri);mp.prepare();mp.setVolume(volume,volume);mp.start();player=mp;playing=song
  decoder=song.cdg?.let{CdgDecoder(ctx.contentResolver.openInputStream(it.uri)!!.readBytes())};frame=decoder?.bitmapCopy();mp.setOnCompletionListener{closeCdg()}
 }
 fun enterFolder(dir:DocumentFile){currentDir?.let{navStack=navStack+it};currentDir=dir;query=""}
 fun goBack(){if(navStack.isNotEmpty()){currentDir=navStack.last();navStack=navStack.dropLast(1);query=""}}
 fun goHome(){root?.let{currentDir=DocumentFile.fromTreeUri(ctx,it);navStack=emptyList();query=""}}

 MaterialTheme(colorScheme=darkColorScheme()){
  Box(Modifier.fillMaxSize().background(Color.Black)){
   Column(Modifier.fillMaxSize().padding(12.dp)){
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
     Button(onClick={if(root==null) picker.launch(null) else ::goHome},modifier=Modifier.height(58.dp)){Text(if(root==null)"FOLDER" else "HOME",fontSize=20.sp,fontWeight=FontWeight.Bold)}
     Spacer(Modifier.width(8.dp))
     Button(onClick={::goBack},enabled=navStack.isNotEmpty(),contentPadding=PaddingValues(0.dp),modifier=Modifier.size(58.dp)){Text("‹",fontSize=40.sp,fontWeight=FontWeight.Bold)}
     Spacer(Modifier.width(10.dp))
     Slider(value=volume,onValueChange={volume=it;player?.setVolume(it,it)},onValueChangeFinished={prefs.edit().putFloat("volume",volume).apply()},modifier=Modifier.weight(1f))
    }
    if(isHome&&root!=null){
     Spacer(Modifier.height(8.dp));Text("CdgLite",color=Color.White,fontSize=(34*fontScale).sp,fontWeight=FontWeight.Bold,modifier=Modifier.align(Alignment.CenterHorizontally));Spacer(Modifier.height(8.dp))
    } else Spacer(Modifier.height(10.dp))

    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
     OutlinedTextField(query,{query=it},singleLine=true,label={Text("LOCAL SEARCH — MP3")},modifier=Modifier.weight(1f).height(70.dp),textStyle=LocalTextStyle.current.copy(fontSize=(22*fontScale).sp))
     Spacer(Modifier.width(6.dp));Button(onClick={localVoice.launch(voiceIntent())},contentPadding=PaddingValues(0.dp),modifier=Modifier.size(64.dp)){Text("🎤",fontSize=28.sp)}
    }
    Spacer(Modifier.height(6.dp))
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
     Button(onClick={::openWebSearch},contentPadding=PaddingValues(0.dp),modifier=Modifier.size(64.dp)){Text("🌐",fontSize=28.sp)}
     Spacer(Modifier.width(6.dp));OutlinedTextField(webQuery,{webQuery=it},singleLine=true,label={Text("WEB KARAOKE SEARCH")},modifier=Modifier.weight(1f).height(70.dp),textStyle=LocalTextStyle.current.copy(fontSize=(22*fontScale).sp))
     Spacer(Modifier.width(6.dp));Button(onClick={webVoice.launch(voiceIntent())},contentPadding=PaddingValues(0.dp),modifier=Modifier.size(64.dp)){Text("🎤",fontSize=28.sp)}
    }
    Spacer(Modifier.height(8.dp))
    val shownFolders=remember(folders,query){if(query.isBlank())folders else folders.filter{(it.name?:"").contains(query,true)}}
    val shownSongs=remember(songs,query){if(query.isBlank())songs else songs.filter{it.name.contains(query,true)}}
    LazyColumn(
     Modifier.fillMaxSize().pointerInput(Unit){detectTransformGestures{_,_,zoom,_->if(zoom!=1f){fontScale=(fontScale*zoom).coerceIn(.75f,2.2f);prefs.edit().putFloat("fontScale",fontScale).apply()}}},
     horizontalAlignment=Alignment.CenterHorizontally
    ){
     items(shownFolders,key={it.uri.toString()}){f->
      Box(Modifier.fillMaxWidth().clickable{enterFolder(f)}.padding(vertical=15.dp,horizontal=16.dp),contentAlignment=Alignment.Center){Text("📁  ${f.name?:"Folder"}",color=Color.White,fontSize=(22*fontScale).sp,fontWeight=FontWeight.Bold)}
     }
     items(shownSongs,key={it.mp3.uri.toString()}){s->
      Row(Modifier.fillMaxWidth().clickable{play(s)}.padding(vertical=14.dp,horizontal=16.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.Center){
       Text("♪  ${s.name}",color=Color.White,fontSize=(22*fontScale).sp)
       if(s.cdg!=null){Spacer(Modifier.width(12.dp));Text("CDG",color=Color.Green,fontSize=(16*fontScale).sp,fontWeight=FontWeight.Bold)}
      }
     }
    }
   }

   if(playing!=null){
    val frac=if(cdgSize==PopupSize.HALF).5f else 1f
    Box(Modifier.fillMaxWidth().fillMaxHeight(frac).align(Alignment.BottomCenter).background(Color.Black,RoundedCornerShape(topStart=12.dp,topEnd=12.dp))){
     frame?.let{Image(it.asImageBitmap(),null,Modifier.fillMaxSize().padding(4.dp),contentScale=ContentScale.Fit)}
     if(playing?.cdg==null)Text("NEMA .CDG FAJLA",color=Color.White,fontSize=24.sp,modifier=Modifier.align(Alignment.Center))
     Button(onClick={cdgSize=if(cdgSize==PopupSize.HALF)PopupSize.FULL else PopupSize.HALF},modifier=Modifier.align(Alignment.TopStart).padding(8.dp)){Text(if(cdgSize==PopupSize.HALF)"FULL" else "1/2")}
     Button(onClick={::closeCdg},contentPadding=PaddingValues(0.dp),modifier=Modifier.align(Alignment.TopEnd).padding(8.dp).size(52.dp)){Text("×",fontSize=30.sp)}
    }
   }
   browserUrl?.let{url->
    val frac=if(browserSize==PopupSize.HALF).5f else 1f
    Box(Modifier.fillMaxWidth().fillMaxHeight(frac).align(Alignment.BottomCenter).background(Color.Black,RoundedCornerShape(topStart=12.dp,topEnd=12.dp))){
     AndroidView(factory={c->WebView(c).apply{webViewClient=WebViewClient();settings.javaScriptEnabled=true;settings.domStorageEnabled=true;loadUrl(url)}},update={if(it.url==null)it.loadUrl(url)},modifier=Modifier.fillMaxSize().padding(top=60.dp))
     Button(onClick={browserSize=if(browserSize==PopupSize.HALF)PopupSize.FULL else PopupSize.HALF},modifier=Modifier.align(Alignment.TopStart).padding(8.dp)){Text(if(browserSize==PopupSize.HALF)"FULL" else "1/2")}
     Button(onClick={browserUrl=null},contentPadding=PaddingValues(0.dp),modifier=Modifier.align(Alignment.TopEnd).padding(8.dp).size(52.dp)){Text("×",fontSize=30.sp)}
    }
   }
  }
 }
}

private suspend fun scanDirectory(dir:DocumentFile):Pair<List<DocumentFile>,List<Song>> = withContext(Dispatchers.IO){
 val kids=dir.listFiles().toList();val dirs=kids.filter{it.isDirectory}.sortedBy{(it.name?:"").lowercase()};val cdgs=kids.filter{it.isFile&&it.name?.endsWith(".cdg",true)==true}.associateBy{it.name!!.substringBeforeLast('.').lowercase()}
 val tracks=kids.filter{it.isFile&&it.name?.endsWith(".mp3",true)==true}.map{m->val base=m.name!!.substringBeforeLast('.');Song(base,m,cdgs[base.lowercase()])}.sortedBy{it.name.lowercase()};dirs to tracks
}

private class CdgDecoder(private val bytes:ByteArray){
 private val w=300;private val h=216;private val pix=ByteArray(w*h);private val clut=IntArray(16){AColor.BLACK};private var packet=0;private val bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888)
 fun seekTo(ms:Int){val target=(ms*300L/1000L).toInt().coerceAtMost(bytes.size/24);if(target<packet){pix.fill(0);clut.fill(AColor.BLACK);packet=0};while(packet<target){decode(packet);packet++}}
 fun bitmapCopy():Bitmap{val out=IntArray(w*h){clut[pix[it].toInt() and 15]};bmp.setPixels(out,0,w,0,0,w,h);return bmp.copy(Bitmap.Config.ARGB_8888,false)}
 private fun decode(n:Int){val o=n*24;if(o+24>bytes.size)return;if((bytes[o].toInt() and 0x3f)!=9)return;val ins=bytes[o+1].toInt() and 0x3f;val d=o+4;when(ins){
  1->{val c=bytes[d].toInt() and 15;pix.fill(c.toByte())}
  2->{val c=bytes[d].toInt() and 15;for(y in 0 until h)for(x in 0 until w)if(x<6||x>=294||y<12||y>=204)pix[y*w+x]=c.toByte()}
  6,38->{val c0=bytes[d].toInt() and 15;val c1=bytes[d+1].toInt() and 15;val row=bytes[d+2].toInt() and 31;val col=bytes[d+3].toInt() and 63;if(row<18&&col<50){for(yy in 0..11){val bits=bytes[d+4+yy].toInt() and 0x3f;for(xx in 0..5){val c=if((bits and (1 shl(5-xx)))!=0)c1 else c0;val p=(row*12+yy)*w+(col*6+xx);if(p in pix.indices)pix[p]=if(ins==38)((pix[p].toInt() xor c) and 15).toByte() else c.toByte()}}}}
  30,31->{val base=if(ins==30)0 else 8;for(i in 0..7){val a=bytes[d+i*2].toInt() and 0x3f;val b=bytes[d+i*2+1].toInt() and 0x3f;val r=((a and 0x30) shr 2) or ((a and 0x0c) shr 2);val g=((a and 0x03) shl 2) or ((b and 0x30) shr 4);val bl=b and 0x0f;clut[base+i]=AColor.rgb(r*17,g*17,bl*17)}}
 } }
}
