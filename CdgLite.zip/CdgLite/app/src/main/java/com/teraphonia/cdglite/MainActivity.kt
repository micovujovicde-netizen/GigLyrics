package com.teraphonia.cdglite

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.WindowManager
import android.media.AudioManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.key.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.zIndex
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.*
import java.net.URLEncoder
import java.util.Locale

internal enum class PopupSize(val fraction: Float) {
    QUARTER(.25f), HALF(.5f), FULL(1f);
    fun next() = entries[(ordinal + 1) % entries.size]
    fun nextLabel() = when (this) { QUARTER -> "1/2"; HALF -> "FULL"; FULL -> "1/4" }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        volumeControlStream = AudioManager.STREAM_MUSIC
        val playback = ViewModelProvider(this)[PlaybackModel::class.java]
        setContent { CdgLite(playback) }
    }
}

@Composable
internal fun CdgLite(playback: PlaybackModel, libraryRoot: DocumentFile? = null) {
    val context = LocalContext.current
    val focus = LocalFocusManager.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("cdglite", 0) }
    var root by rememberSaveable { mutableStateOf(libraryRoot?.uri?.toString() ?: prefs.getString("root", null)) }
    var path by rememberSaveable { mutableStateOf(arrayListOf<String>()) }
    var folders by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var texts by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var libraryError by remember { mutableStateOf<String?>(null) }
    var query by rememberSaveable { mutableStateOf("") }
    var submittedQuery by rememberSaveable { mutableStateOf("") }
    var webQuery by rememberSaveable { mutableStateOf("") }
    var browserVisible by rememberSaveable { mutableStateOf(false) }
    val web = playback.web
    var browserSize by rememberSaveable { mutableStateOf(PopupSize.HALF) }
    val audio = remember { context.getSystemService(android.content.Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var volume by remember { mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVolume) }
    val savedFontScale = prefs.getFloat("fontScale", 1f).let { if (it.isFinite()) it.coerceIn(.75f, 2.2f) else 1f }
    var fontScale by remember { mutableFloatStateOf(savedFontScale) }
    val listState = rememberLazyListState()

    fun showLibrary() { browserVisible = false; focus.clearFocus() }
    fun home() {
        showLibrary()
        path = arrayListOf()
        query = ""
        submittedQuery = ""
        scope.launch { listState.scrollToItem(0) }
    }
    fun back() {
        showLibrary()
        if (path.isNotEmpty()) path = ArrayList(path.dropLast(1))
        query = ""
        submittedQuery = ""
    }
    fun localSearch() {
        showLibrary()
        submittedQuery = query.trim()
        scope.launch { listState.scrollToItem(0) }
    }
    fun webSearch() {
        if (webQuery.isBlank()) return
        focus.clearFocus()
        playback.showCdg = false
        browserSize = PopupSize.HALF
        browserVisible = true
        web.open("https://www.google.com/search?q=" + URLEncoder.encode(webQuery.trim() + " karaoke", "UTF-8"))
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                root = uri.toString()
                prefs.edit().putString("root", root).apply()
                home()
            } catch (_: SecurityException) { libraryError = "Nije odobren pristup folderu." }
        }
    }
    val localVoice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let {
            query = it; localSearch()
        }
    }
    val webVoice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let {
            webQuery = it; webSearch()
        }
    }
    fun voiceIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_PROMPT, "Naziv pjesme")
    }
    fun voice(web: Boolean) {
        try { if (web) webVoice.launch(voiceIntent()) else localVoice.launch(voiceIntent()) }
        catch (_: android.content.ActivityNotFoundException) { libraryError = "Glasovna pretraga nije dostupna na ovom uređaju." }
    }

    LaunchedEffect(Unit) {
        playback.setVolume(1f)
        while (isActive) {
            volume = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVolume
            delay(300)
        }
    }
    LaunchedEffect(path, root, submittedQuery) {
        loading = true
        folders = emptyList()
        songs = emptyList()
        texts = emptyList()
        libraryError = null
        try {
            val target = root
            if (target != null) {
                val result = withContext(Dispatchers.IO) {
                    var dir = libraryRoot ?: DocumentFile.fromTreeUri(context, Uri.parse(target)) ?: error("Missing folder")
                    if (submittedQuery.isBlank()) for (name in path) { dir = dir.findFile(name) ?: error("Missing folder") }
                    scanFolder(dir, submittedQuery)
                }
                folders = result.folders
                songs = result.songs
                texts = result.texts
            }
        } catch (e: CancellationException) { throw e }
        catch (_: Exception) { libraryError = "Folder nije dostupan. Izaberi ga ponovo pomoću FOLDER." }
        finally { loading = false }
    }
    DisposableEffect(playback.isPlaying, web.isPlaying) {
        val window = (context as? ComponentActivity)?.window
        if (playback.isPlaying || web.isPlaying) window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }
    BackHandler(true) { back() }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Column(Modifier.fillMaxSize().background(Color.Black).safeDrawingPadding().imePadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { if (root == null) picker.launch(null) else home() }, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(72.dp, 52.dp).testTag("home")) { Text("HOME") }
                Button(onClick = { back() }, enabled = path.isNotEmpty(), contentPadding = PaddingValues(0.dp), modifier = Modifier.size(72.dp, 52.dp).testTag("back")) { Text("‹", fontSize = 36.sp) }
                Slider(value = volume, onValueChange = { volume = it; audio.setStreamVolume(AudioManager.STREAM_MUSIC, (it * maxVolume).toInt(), 0) }, modifier = Modifier.weight(1f).testTag("mainVolume"))
                TextButton(onClick = { picker.launch(null) }) { Text("FOLDER") }
            }
            // CDG is part of the layout, not an overlay: the song list ends at its top edge.
            Column(Modifier.weight(1f).fillMaxWidth()) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                Column(Modifier.fillMaxSize().padding(horizontal = 10.dp)) {
                    if (path.isEmpty() && submittedQuery.isEmpty()) Text("CdgLite", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
                    SearchRow(query, { query = it; if (it.isEmpty()) submittedQuery = "" }, "LOCAL SEARCH — MP3", "local", ::localSearch, { voice(false) })
                    SearchRow(webQuery, { webQuery = it }, "WEB KARAOKE SEARCH", "web", ::webSearch, { voice(true) })
                    val message = playback.error ?: libraryError
                    if (message != null) Text(message, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp))
                    if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text(if (submittedQuery.isNotEmpty()) "${songs.size} rezultata u svim podfolderima" else "${folders.size} foldera • ${songs.size} pjesama", fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize().testTag("library").pointerInput(Unit) {
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false)
                                var pinching = false
                                do {
                                    val event = awaitPointerEvent()
                                    if (event.changes.count { it.pressed } >= 2) {
                                        pinching = true
                                        val zoom = event.calculateZoom()
                                        if (zoom.isFinite() && zoom > 0f) {
                                            val nextScale = fontScale * zoom
                                            fontScale = if (nextScale.isFinite()) nextScale.coerceIn(.75f, 2.2f) else 1f
                                            prefs.edit().putFloat("fontScale", fontScale).apply()
                                        }
                                        event.changes.forEach { it.consume() }
                                    }
                                } while (event.changes.any { it.pressed })
                                if (pinching) prefs.edit().putFloat("fontScale", fontScale).commit()
                            }
                        }
                    ) {
                        if (!loading && folders.isEmpty() && songs.isEmpty() && texts.isEmpty()) item {
                            Text(if (root == null) "Izaberi FOLDER sa muzikom." else "Nema pjesama. Pretraži drugi naziv ili izaberi folder.", modifier = Modifier.padding(16.dp))
                        }
                        items(folders, key = { it.uri.toString() }) { dir ->
                            Text(
                                text = "📁  ${dir.name ?: "Folder"}",
                                color = Color.White,
                                fontSize = (22 * fontScale).sp,
                                modifier = Modifier.fillMaxWidth().zIndex(10f).clickable {
                                    path = ArrayList(path + (dir.name ?: return@clickable)); query = ""; submittedQuery = ""
                                    focus.clearFocus(); scope.launch { listState.scrollToItem(0) }
                                }.padding(16.dp)
                            )
                        }
                        items(songs, key = { it.mp3.uri.toString() }) { song ->
                            Row(Modifier.fillMaxWidth().clickable {
                                showLibrary()
                                if (playback.song?.mp3?.uri == song.mp3.uri && (playback.isPlaying || playback.preparing)) playback.stop()
                                else { playback.startLocal(song) }
                            }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(song.name, color = Color.White, fontSize = (22 * fontScale).sp, modifier = Modifier.weight(1f).zIndex(10f))
                                if (playback.song?.mp3?.uri == song.mp3.uri) Text(if (playback.isPlaying) "▶" else "■", modifier = Modifier.padding(start = 8.dp).testTag("activeTrackState"), fontSize = 14.sp)
                                if (song.cdg != null) Text("CDG", color = Color.Green, modifier = Modifier.padding(start = 8.dp))
                            }
                        }
                        items(texts, key = { it.uri.toString() }) { file ->
                            Text(
                                text = "≡  ${file.name}",
                                color = Color.White,
                                fontSize = (22 * fontScale).sp,
                                modifier = Modifier.fillMaxWidth().zIndex(10f).clickable { showLibrary(); playback.openText(file) }.padding(16.dp)
                            )
                        }
                    }
                }
                if (web.opened) {
                    OverlayPanel(browserSize, "WEB", { browserSize = browserSize.next() }, { browserVisible = false; web.close() }, visible = browserVisible) {
                        Browser(web, browserVisible)
                        if (browserVisible) {
                            Button(onClick = { web.toggle() }, modifier = Modifier.align(Alignment.Center).heightIn(min = 64.dp).testTag("webPlayStop"),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Black.copy(alpha = .32f), contentColor = Color.White)) {
                                Text(if (web.isPlaying) "■ STOP" else "▶ PLAY", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                            }
                            web.message?.let { Text(it, modifier = Modifier.align(Alignment.BottomCenter).background(Color.Black.copy(alpha = .8f)).padding(8.dp)) }
                        }
                    }
                }
                }
                if (playback.showCdg) {
                    CdgSurface {
                        val bitmap = playback.frame
                        if (playback.lyricsText != null) {
                            key(playback.popupTitle, playback.lyricsText) {
                                Text(playback.lyricsText.orEmpty(), fontSize = 22.sp,
                                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp).testTag("lyricsText"))
                            }
                        } else if (bitmap != null) Image(bitmap.asImageBitmap(), "Karaoke tekst", Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                        else Text(if (playback.song?.cdg == null) "NEMA .CDG FAJLA" else "Učitavanje CDG…", modifier = Modifier.align(Alignment.Center))
                    }
                }
            }
            if (playback.song != null) PlaybackBar(playback, resume = {
                if (!playback.isPlaying) web.stopForLocal()
                playback.togglePause()
            }) { showLibrary(); playback.showCdg = !playback.showCdg }
            if (web.opened && !browserVisible) TextButton(onClick = { playback.showCdg = false; browserVisible = true }, modifier = Modifier.align(Alignment.CenterHorizontally).testTag("showWeb")) { Text(if (web.isPlaying) "WEB ▶" else "WEB") }
        }
    }
}

@Composable
internal fun ColumnScope.CdgSurface(content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier.fillMaxWidth().weight(1f).background(Color.Black).testTag("CDGPanel"),
        content = content
    )
}

@Composable
internal fun SearchRow(value: String, change: (String) -> Unit, label: String, tag: String, submit: () -> Unit, voice: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value, change, singleLine = true, label = { Text(label, fontSize = 12.sp) },
            modifier = Modifier.weight(1f).testTag("${tag}Search").onPreviewKeyEvent {
                if (it.key == Key.Enter || it.key == Key.NumPadEnter) {
                    if (it.type == KeyEventType.KeyUp) submit()
                    true
                } else false
            },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { submit() }, onDone = { submit() }, onGo = { submit() })
        )
        TextButton(onClick = submit, modifier = Modifier.testTag("${tag}Submit")) { Text("GO") }
        TextButton(onClick = voice, contentPadding = PaddingValues(0.dp), modifier = Modifier.width(48.dp)) { Text("🎤", fontSize = 22.sp) }
    }
}

@Composable
internal fun BoxScope.OverlayPanel(size: PopupSize, title: String, resize: () -> Unit, close: () -> Unit, visible: Boolean = true, content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().fillMaxHeight(size.fraction)
        .zIndex(if (visible) 10f else -1f).alpha(if (visible) 1f else 0f).background(Color.Black).testTag("${title}Panel")) {
        // A separate background hit target blocks the library without intercepting
        // button or WebView gestures. Interactive content is drawn above it.
        Box(Modifier.matchParentSize().pointerInput(Unit) {
            awaitPointerEventScope { while (true) {
                awaitPointerEvent().changes.forEach { it.consume() }
            } }
        })
        Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().height(48.dp).background(Color(0xff20242a)), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = resize) { Text(size.nextLabel()) }
            Text(title, modifier = Modifier.weight(1f))
            TextButton(onClick = close, modifier = Modifier.testTag("${title}Close")) { Text("×", fontSize = 28.sp) }
        }
        Box(Modifier.weight(1f).fillMaxWidth(), content = content)
        }
    }
}

@Composable
private fun PlaybackBar(playback: PlaybackModel, resume: () -> Unit, show: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color(0xff18212b)).padding(horizontal = 10.dp)) {
        Text(playback.song?.name.orEmpty(), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = resume, enabled = !playback.preparing, modifier = Modifier.testTag("pause")) { Text(if (playback.isPlaying) "Ⅱ" else "▶", fontSize = 28.sp) }
            TextButton(onClick = { playback.stop() }, modifier = Modifier.testTag("stop")) { Text("■", fontSize = 26.sp) }
            if (playback.song?.cdg != null || playback.song?.text != null || playback.lyricsText != null) TextButton(onClick = show, modifier = Modifier.testTag("showCdg")) { Text("▣", fontSize = 28.sp) }
            Spacer(Modifier.weight(1f))
            Text(if (playback.preparing) "Učitavanje…" else "${time(playback.position)} / ${time(playback.duration)}", fontSize = 12.sp)
        }
    }
}

private fun time(ms: Int) = "%d:%02d".format(Locale.ROOT, ms / 60000, ms / 1000 % 60)

@Composable
private fun Browser(controller: WebAudioController, visible: Boolean) {
    val context = LocalContext.current
    val web = remember(controller) { controller.webView(context) }
    DisposableEffect(context) {
        controller.webView(context)
        onDispose { controller.detachContext() }
    }
    AndroidView(factory = { (web.parent as? android.view.ViewGroup)?.removeView(web); web },
        update = { it.setOnTouchListener { _, _ -> !visible } }, modifier = Modifier.fillMaxSize())
}
