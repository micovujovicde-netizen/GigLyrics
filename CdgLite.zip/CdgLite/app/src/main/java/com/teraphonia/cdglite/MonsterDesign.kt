package com.teraphonia.cdglite

import androidx.compose.foundation.Image
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

internal val MonsterGreen = Color(0xFF86F500)
internal val MonsterRed = Color(0xFFFF1818)
internal val MonsterPanel = Color(0xFF111512)
internal val monsterColors = darkColorScheme(
    primary = MonsterGreen, onPrimary = Color.Black,
    secondary = MonsterGreen, onSecondary = Color.Black,
    tertiary = MonsterRed, onTertiary = Color.White,
    background = Color.Black, onBackground = Color.White,
    surface = MonsterPanel, onSurface = Color.White,
    surfaceVariant = Color(0xFF181E19), onSurfaceVariant = Color(0xFFDFE7DC),
    outline = Color(0xFF56723A), error = Color(0xFFFF7272)
)

@Composable
internal fun MonsterButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    contentPadding: PaddingValues = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
    content: @Composable RowScope.() -> Unit
) {
    val shape = RoundedCornerShape(14.dp)
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.padding(horizontal = 2.dp, vertical = 3.dp).heightIn(min = 52.dp)
            .drawBehind {
                val inset = 12.dp.toPx()
                drawLine(if (enabled) MonsterRed else Color(0xFF572525),
                    Offset(inset, size.height - 1.dp.toPx()),
                    Offset(size.width - inset, size.height - 1.dp.toPx()), 3.dp.toPx())
            },
        enabled = enabled,
        shape = shape,
        border = BorderStroke(2.dp, if (enabled) MonsterGreen else Color(0xFF40532F)),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = MonsterPanel, contentColor = MonsterGreen,
            disabledContainerColor = MonsterPanel, disabledContentColor = Color(0xFF9EB487)
        ),
        contentPadding = contentPadding,
        content = content
    )
}

internal fun Modifier.monsterRow(): Modifier = drawBehind {
    drawLine(Color(0xFF202920), Offset(0f, size.height), Offset(size.width, size.height), 1.dp.toPx())
}

internal fun Modifier.monsterBar(): Modifier = drawBehind {
    drawLine(MonsterGreen, Offset.Zero, Offset(size.width, 0f), 2.dp.toPx())
    drawLine(MonsterRed, Offset(0f, size.height), Offset(size.width, size.height), 2.dp.toPx())
}

@Composable
internal fun MonsterFolderIcon() {
    Image(painterResource(R.drawable.karamonster_rex), null,
        Modifier.padding(start = 8.dp).size(48.dp))
}

@Composable
internal fun MonsterBrand() {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
    val brandSize = if (maxWidth < 400.dp) 24.sp else 30.sp
    Column(Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.karamonster_rex), null, Modifier.size(64.dp))
            Spacer(Modifier.width(8.dp))
            Text("KARA", color = Color.White, fontSize = brandSize, fontWeight = FontWeight.Black)
            Text("MONSTER", color = MonsterGreen, fontSize = brandSize, fontWeight = FontWeight.Black)
        }
        Box(Modifier.padding(top = 4.dp).fillMaxWidth(.7f).height(3.dp).background(MonsterRed))
    }
}

}
