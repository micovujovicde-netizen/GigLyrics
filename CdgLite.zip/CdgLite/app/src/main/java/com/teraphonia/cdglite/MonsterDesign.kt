package com.teraphonia.cdglite

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

internal val MonsterGreen = Color(0xFF86F500)
internal val MonsterRed = Color(0xFFFF1818)
internal val MonsterPurple = Color(0xFFD1B2FF)
internal val MonsterPurpleStrong = Color(0xFF9A5CFF)
internal val MonsterPanel = Color(0xFF0D120F)
internal val monsterColors = darkColorScheme(
    primary = MonsterGreen, onPrimary = Color.Black,
    secondary = MonsterPurple, onSecondary = Color.Black,
    tertiary = MonsterRed, onTertiary = Color.White,
    background = Color.Black, onBackground = Color.White,
    surface = MonsterPanel, onSurface = Color.White,
    surfaceVariant = Color(0xFF181E19), onSurfaceVariant = Color(0xFFDFE7DC),
    outline = Color(0xFF56723A), error = Color(0xFFFF7272)
)

internal enum class MonsterButtonTone { GREEN, PURPLE }

@Composable
internal fun MonsterButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    tone: MonsterButtonTone = MonsterButtonTone.GREEN,
    contentPadding: PaddingValues = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
    content: @Composable RowScope.() -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    val accent = if (tone == MonsterButtonTone.PURPLE) MonsterPurple else MonsterGreen
    val strong = if (tone == MonsterButtonTone.PURPLE) MonsterPurpleStrong else MonsterGreen
    val borderColor = if (enabled) accent else Color(0xFF4A5147)
    val brush = if (enabled) {
        if (tone == MonsterButtonTone.PURPLE) {
            Brush.verticalGradient(listOf(Color(0xFF3A2468), Color(0xFF171225), Color(0xFF0C0C11)))
        } else {
            Brush.verticalGradient(listOf(Color(0xFF172019), Color(0xFF0D130F), Color(0xFF080B09)))
        }
    } else Brush.verticalGradient(listOf(Color(0xFF151715), Color(0xFF0C0D0C)))

    OutlinedButton(
        onClick = onClick,
        modifier = modifier
            .padding(horizontal = 2.dp, vertical = 3.dp)
            .heightIn(min = 52.dp)
            .background(brush, shape)
            .border(BorderStroke(2.dp, borderColor), shape)
            .drawBehind {
                // Soft inner highlight gives the rendered buttons their glossy stage look.
                drawLine(
                    if (enabled) strong.copy(alpha = .55f) else Color.DarkGray.copy(alpha = .25f),
                    Offset(18.dp.toPx(), 1.5.dp.toPx()),
                    Offset(size.width - 18.dp.toPx(), 1.5.dp.toPx()),
                    1.dp.toPx()
                )
                // Green transport controls keep the KaraMonster red accent shown in the references.
                if (tone == MonsterButtonTone.GREEN) {
                    val inset = 12.dp.toPx()
                    drawLine(
                        if (enabled) MonsterRed else Color(0xFF572525),
                        Offset(inset, size.height - 1.dp.toPx()),
                        Offset(size.width - inset, size.height - 1.dp.toPx()),
                        3.dp.toPx()
                    )
                }
            },
        enabled = enabled,
        shape = shape,
        border = null,
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = Color.Transparent,
            contentColor = if (enabled) accent else Color(0xFF9BA39A),
            disabledContainerColor = Color.Transparent,
            disabledContentColor = Color(0xFF9BA39A)
        ),
        contentPadding = contentPadding,
        content = content
    )
}

internal fun Modifier.monsterRow(): Modifier = drawBehind {
    
    val vine = Color(0xFF91D6A1)
    val y = size.height - 1.dp.toPx()
    drawLine(vine.copy(alpha = .62f), Offset(0f, y), Offset(size.width, y), 1.5.dp.toPx())
    var x = 14.dp.toPx()
    while (x < size.width) {
        drawCircle(vine.copy(alpha = .36f), 1.8.dp.toPx(), Offset(x, y - 1.5.dp.toPx()))
        x += 34.dp.toPx()
    }
}

internal fun Modifier.monsterBar(): Modifier = drawBehind {
    drawLine(MonsterGreen, Offset.Zero, Offset(size.width, 0f), 2.dp.toPx())
    drawLine(MonsterRed, Offset(0f, size.height), Offset(size.width, size.height), 2.dp.toPx())
}

@Composable
internal fun MonsterFolderIcon() {
    Image(
        painterResource(R.drawable.karamonster_folder),
        null,
        Modifier.padding(start = 6.dp).size((64f * 2f / 3f).dp),
        contentScale = ContentScale.Fit
    )
}

@Composable
internal fun MonsterBrand() {
    Image(
        painter = painterResource(R.drawable.gigmonster_logo),
        contentDescription = "GigMonster",
        modifier = Modifier
            .fillMaxWidth(.67f)
            .heightIn(min = 76.dp, max = 118.dp)
            .padding(start = 8.dp, top = 8.dp, bottom = 6.dp),
        contentScale = ContentScale.Fit,
        alignment = Alignment.CenterStart
    )
}

@Composable
internal fun StoneButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    locked: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(topStart = 18.dp, topEnd = 10.dp, bottomEnd = 20.dp, bottomStart = 8.dp)
    val edge = if (active) Color(0xFF93E39D) else Color(0xFF777A72)
    val fill = if (active) Color(0xFF244A2D) else Color(0xFF353733)
    Box(
        modifier = modifier
            .padding(2.dp)
            .heightIn(min = 58.dp)
            .background(Brush.verticalGradient(listOf(fill.copy(alpha=.95f), Color(0xFF171A17))), shape)
            .border(3.dp, edge.copy(alpha=.85f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        content()
        if (locked) Text("🔒", fontSize = 28.sp, color = Color.White.copy(alpha = .32f), modifier = Modifier.align(Alignment.CenterEnd))
    }
}
