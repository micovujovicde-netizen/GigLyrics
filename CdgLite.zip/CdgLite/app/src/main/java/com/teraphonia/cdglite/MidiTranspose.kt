package com.teraphonia.cdglite

/**
 * Lossless-in-structure Standard MIDI File transposition.
 *
 * Only note numbers are changed. Timing, velocities, controllers, program changes,
 * karaoke/meta text and every other byte stay untouched. General MIDI channel 10
 * (zero-based channel 9) is percussion and is deliberately never transposed.
 */
internal object MidiTranspose {
    private const val HEADER = 0x4D546864 // MThd
    private const val TRACK = 0x4D54726B  // MTrk

    fun transpose(bytes: ByteArray, semitones: Int): ByteArray {
        if (semitones == 0) return bytes.copyOf()
        require(semitones in -12..12) { "Unsupported MIDI transpose: $semitones" }
        if (bytes.size < 14 || readInt(bytes, 0) != HEADER) {
            throw IllegalArgumentException("Not a Standard MIDI File")
        }

        val headerLength = readInt(bytes, 4)
        if (headerLength < 6 || headerLength > bytes.size - 8) {
            throw IllegalArgumentException("Invalid MIDI header")
        }

        val output = bytes.copyOf()
        var offset = 8 + headerLength
        while (offset + 8 <= output.size) {
            val chunkType = readInt(output, offset)
            val chunkLength = readInt(output, offset + 4)
            if (chunkLength < 0 || chunkLength > output.size - offset - 8) {
                throw IllegalArgumentException("Invalid MIDI chunk length")
            }
            val dataStart = offset + 8
            val dataEnd = dataStart + chunkLength
            if (chunkType == TRACK) transposeTrack(output, dataStart, dataEnd, semitones)
            offset = dataEnd
        }
        return output
    }

    private fun transposeTrack(data: ByteArray, start: Int, end: Int, semitones: Int) {
        var p = start
        var runningStatus = 0

        while (p < end) {
            p = skipVlq(data, p, end) // delta time
            if (p >= end) break

            val next = u8(data[p])
            val status: Int
            if (next >= 0x80) {
                status = next
                p++
                if (status in 0x80..0xEF) runningStatus = status
            } else {
                status = runningStatus
                if (status !in 0x80..0xEF) {
                    throw IllegalArgumentException("Invalid MIDI running status")
                }
            }

            when {
                status in 0x80..0xEF -> {
                    val kind = status and 0xF0
                    val channel = status and 0x0F
                    val dataLength = if (kind == 0xC0 || kind == 0xD0) 1 else 2
                    if (p + dataLength > end) throw IllegalArgumentException("Truncated MIDI event")

                    // NOTE OFF and NOTE ON: transpose the note number only.
                    if ((kind == 0x80 || kind == 0x90) && channel != 9) {
                        val note = u8(data[p])
                        data[p] = (note + semitones).coerceIn(0, 127).toByte()
                    }
                    p += dataLength
                }

                status == 0xFF -> { // Meta event, including all KAR lyric/text events.
                    if (p >= end) throw IllegalArgumentException("Truncated MIDI meta event")
                    p++ // meta type
                    val (length, afterLength) = readVlq(data, p, end)
                    p = afterLength
                    if (length > end - p) throw IllegalArgumentException("Truncated MIDI meta payload")
                    p += length
                }

                status == 0xF0 || status == 0xF7 -> { // SysEx in SMF has VLQ payload length.
                    val (length, afterLength) = readVlq(data, p, end)
                    p = afterLength
                    if (length > end - p) throw IllegalArgumentException("Truncated MIDI SysEx payload")
                    p += length
                }

                else -> {
                    // System-common events are unusual in SMF tracks, but accepting their
                    // fixed MIDI data sizes makes the parser tolerant without changing them.
                    val count = when (status) {
                        0xF1, 0xF3 -> 1
                        0xF2 -> 2
                        0xF6, in 0xF8..0xFE -> 0
                        else -> throw IllegalArgumentException("Unsupported MIDI status: $status")
                    }
                    if (p + count > end) throw IllegalArgumentException("Truncated MIDI system event")
                    p += count
                }
            }
        }
    }

    private fun skipVlq(data: ByteArray, offset: Int, end: Int): Int = readVlq(data, offset, end).second

    private fun readVlq(data: ByteArray, offset: Int, end: Int): Pair<Int, Int> {
        var p = offset
        var value = 0
        repeat(4) {
            if (p >= end) throw IllegalArgumentException("Truncated MIDI VLQ")
            val b = u8(data[p++])
            value = (value shl 7) or (b and 0x7F)
            if (b and 0x80 == 0) return value to p
        }
        throw IllegalArgumentException("Invalid MIDI VLQ")
    }

    private fun readInt(data: ByteArray, offset: Int): Int {
        if (offset < 0 || offset + 4 > data.size) throw IllegalArgumentException("Truncated MIDI chunk")
        return (u8(data[offset]) shl 24) or
            (u8(data[offset + 1]) shl 16) or
            (u8(data[offset + 2]) shl 8) or
            u8(data[offset + 3])
    }

    private fun u8(value: Byte): Int = value.toInt() and 0xFF
}
