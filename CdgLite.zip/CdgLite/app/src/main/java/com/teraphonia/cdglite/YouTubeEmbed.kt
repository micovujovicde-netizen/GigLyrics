package com.teraphonia.cdglite

import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/**
 * Converts a selected public YouTube video URL into the official embedded-player URL.
 * Search/results browsing stays on youtube.com; only the selected video page is replaced.
 */
internal fun youtubeEmbedUrl(rawUrl: String?): String? {
    if (rawUrl.isNullOrBlank()) return null
    val uri = try { URI(rawUrl) } catch (_: Throwable) { return null }
    val host = uri.host?.lowercase()?.removePrefix("www.")?.removePrefix("m.") ?: return null
    val path = uri.path.orEmpty()

    val videoId = when {
        host == "youtu.be" -> path.trim('/').substringBefore('/')
        host == "youtube.com" || host.endsWith(".youtube.com") -> when {
            path == "/watch" -> queryParameter(uri.rawQuery, "v")
            path.startsWith("/shorts/") -> path.removePrefix("/shorts/").substringBefore('/')
            path.startsWith("/live/") -> path.removePrefix("/live/").substringBefore('/')
            // Already embedded: never rewrite again.
            path.startsWith("/embed/") -> null
            else -> null
        }
        else -> null
    }?.takeIf { it.matches(Regex("[A-Za-z0-9_-]{6,20}")) } ?: return null

    return "https://www.youtube.com/embed/$videoId?autoplay=1&playsinline=1&controls=1"
}

internal fun isYouTubeEmbedUrl(rawUrl: String?): Boolean {
    if (rawUrl.isNullOrBlank()) return false
    val uri = try { URI(rawUrl) } catch (_: Throwable) { return false }
    val host = uri.host?.lowercase().orEmpty()
    return (host == "youtube.com" || host.endsWith(".youtube.com")) && uri.path.orEmpty().startsWith("/embed/")
}

private fun queryParameter(rawQuery: String?, wanted: String): String? {
    if (rawQuery.isNullOrBlank()) return null
    return rawQuery.split('&').firstNotNullOfOrNull { pair ->
        val key = pair.substringBefore('=', pair)
        if (key != wanted) return@firstNotNullOfOrNull null
        val value = pair.substringAfter('=', "")
        runCatching { URLDecoder.decode(value, StandardCharsets.UTF_8.name()) }.getOrNull()
    }
}
