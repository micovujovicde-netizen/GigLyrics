package com.teraphonia.cdglite

import android.app.Application
import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.view.SurfaceHolder
import androidx.compose.runtime.*
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import java.io.File

internal data class Song(
    val name: String,
    val mp3: DocumentFile,
    val cdg: DocumentFile?,
    val text: DocumentFile? = null,
    val folder: DocumentFile? = null
)
internal val Song.isVideo get() = mp3.extension() in videoExtensions
internal val Song.isMidi get() = mp3.extension() in setOf("mid", "midi", "kar")

/** Playback owns its resources independently of navigation and popup visibility. */
class PlaybackModel(app: Application) : AndroidViewModel(app) {
    // Physically separate browsers: GLUPAN = karaoke, TUPAN = lyrics.
    internal val karaokeWeb = WebAudioController(app, this, WebRole.KARAOKE)
    internal val lyricsWeb = WebAudioController(app, this, WebRole.LYRICS)
    /** Legacy test/compat alias: WEB always means the karaoke browser (GLUPAN). */
    internal val web get() = karaokeWeb
    internal var song by mutableStateOf<Song?>(null)
        private set
    var preparing by mutableStateOf(false)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var position by mutableIntStateOf(0)
        private set
    var duration by mutableIntStateOf(0)
        private set
    var frame by mutableStateOf<Bitmap?>(null)
        private set
    var showCdg by mutableStateOf(false)
    var showTextOnly by mutableStateOf(false)
    /** The selected Song carries this same-folder sidecar all the way to the CDG panel. */
    internal var activeTextSidecar by mutableStateOf<DocumentFile?>(null)
        private set
    internal var activeEmbeddedLyrics by mutableStateOf(false)
        private set
    var lyricsText by mutableStateOf<String?>(null)
        private set
    var extractedPreview by mutableStateOf(false)
        private set

    // TXT-only tap-to-sync editor. Nothing is written until SAVE is pressed.
    var syncEditActive by mutableStateOf(false)
        private set
    var syncEditFinished by mutableStateOf(false)
        private set
    var syncFingerVisible by mutableStateOf(false)
        private set
    var syncLines by mutableStateOf<List<String>>(emptyList())
        private set
    var syncTimes by mutableStateOf<List<Int?>>(emptyList())
        private set
    var syncNextIndex by mutableIntStateOf(-1)
        private set
    private var syncSource: DocumentFile? = null
    private var syncFromEmbedded = false

    internal var timedLyrics by mutableStateOf<List<LyricsReader.TimedLine>>(emptyList())
        private set
    var popupTitle by mutableStateOf("CDG")
        private set
    private var textJob: Job? = null
    var error by mutableStateOf<String?>(null)
    private var media: MediaPlayer? = null
    private var soundTouchMedia: SoundTouchAudioPlayer? = null
    private var midiMedia: FluidSynthMidiPlayer? = null
    private var activeMidiFile: File? = null
    private var midiRenderSerial = 0
    private var midiAutoStartDesired = true
    private var videoSurface: SurfaceHolder? = null
    private var decoder: CdgDecoder? = null
    private var loadJob: Job? = null
    private var generation = 0
    private var volume = 1f

    // Local transpose: immediate pitch shift, with an explicit per-song SAVE.
    // Pitch changes without changing playback speed.
    private val transposePrefs = app.getSharedPreferences("cdglite_transpose", 0)
    var transposeSemitones by mutableIntStateOf(0)
        private set
    var savedTransposeSemitones by mutableIntStateOf(0)
        private set
    val transposeDirty: Boolean get() = transposeSemitones != savedTransposeSemitones

    // BREAK player is intentionally independent from the karaoke player/UI.
    // HOME may leave this playing in the background; starting local/web karaoke stops it.
    var breakTrack by mutableStateOf<DocumentFile?>(null)
        private set
    var breakPreparing by mutableStateOf(false)
        private set
    var breakIsPlaying by mutableStateOf(false)
        private set
    var breakPosition by mutableIntStateOf(0)
        private set
    var breakDuration by mutableIntStateOf(0)
        private set
    var breakRandom by mutableStateOf(false)
        private set
    var breakRepeat by mutableStateOf(false)
        private set
    private var breakMedia: MediaPlayer? = null
    private var breakFiles: List<DocumentFile> = emptyList()
    private var breakOrder: List<Int> = emptyList()
    private var breakOrderPosition = -1

    init {
        viewModelScope.launch {
            while (isActive) {
                val st = soundTouchMedia
                val midi = midiMedia
                val p = media
                if (!preparing) {
                    position = when {
                        midi != null -> midi.currentPositionMs
                        st != null -> st.currentPositionMs
                        p != null -> runCatching { p.currentPosition }.getOrDefault(position)
                        else -> position
                    }
                    if ((midi != null || st != null || p != null) && showCdg) {
                        decoder?.let { d ->
                            val at = position
                            val nextFrame = withContext(Dispatchers.Default) {
                                d.seekTo(at)
                                d.bitmapCopy()
                            }
                            if (decoder === d && showCdg) frame = nextFrame
                        }
                    }
                    if (midi != null && isPlaying && !midi.isPlaying && duration > 0 && position >= (duration - 120).coerceAtLeast(0)) {
                        handleLocalCompletion {
                            midi.release()
                            if (midiMedia === midi) midiMedia = null
                        }
                    }
                }
                val bp = breakMedia
                if (bp != null && !breakPreparing) {
                    breakPosition = runCatching { bp.currentPosition }.getOrDefault(breakPosition)
                }
                delay(40)
            }
        }
    }

    internal fun startLocal(track: Song) {
        stopBreak()
        karaokeWeb.stopForLocal()
        lyricsWeb.close()
        play(track)
    }

    internal fun play(track: Song) {
        val sameTrack = song?.mp3?.uri == track.mp3.uri
        stop()
        if (!sameTrack) {
            val saved = transposePrefs.getInt(transposeKey(track), 0).coerceIn(-6, 6)
            savedTransposeSemitones = saved
            transposeSemitones = saved
        }
        textJob?.cancel()
        activeTextSidecar = null
        activeEmbeddedLyrics = false
        lyricsText = null
        extractedPreview = false
        timedLyrics = emptyList()
        showTextOnly = false
        frame = null
        decoder = null
        popupTitle = "CDG"
        error = null
        song = track
        preparing = true
        showCdg = true
        if (track.cdg == null) {
            if (track.text != null) openText(track.text)
            else if (track.mp3.extension() == "mp3") openEmbeddedLyrics3(track.mp3)
        }

        val token = generation
        when {
            track.isMidi -> startMidiPlayer(track, token, startAtMs = 0, autoStart = true)
            !track.isVideo && transposeSemitones != 0 -> startSoundTouch(track, 0, autoStart = true, token = token)
            else -> startPlatformPlayer(track, token)
        }
        loadCdg(track, token)
    }

    private fun startPlatformPlayer(
        track: Song,
        token: Int,
        startAtMs: Int = 0,
        autoStart: Boolean = true,
        dataSourcePath: String? = null
    ) {
        val p = MediaPlayer()
        media = p
        if (track.isVideo) p.setDisplay(videoSurface)
        p.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
        )
        p.setVolume(volume, volume)
        p.setOnPreparedListener {
            if (media !== p || token != generation) return@setOnPreparedListener
            duration = runCatching { p.duration }.getOrDefault(0)

            // Never use Android PlaybackParams for transpose. If the user changed KEY while
            // MediaPlayer was preparing, hand the audio track to the SoundTouch DSP instead.
            if (!track.isVideo && !track.isMidi && transposeSemitones != 0) {
                val wanted = startAtMs.coerceIn(0, duration.coerceAtLeast(0))
                runCatching { p.release() }
                if (media === p) media = null
                startSoundTouch(track, wanted, autoStart, token)
                return@setOnPreparedListener
            }

            if (startAtMs > 0) runCatching { p.seekTo(startAtMs.coerceIn(0, duration)) }
            preparing = false
            if (autoStart) {
                p.start()
                isPlaying = true
            } else {
                isPlaying = false
            }
        }
        p.setOnCompletionListener {
            if (media === p && token == generation) handleLocalCompletion {
                runCatching { p.release() }
                if (media === p) media = null
            }
        }
        p.setOnErrorListener { _, _, _ ->
            if (media === p && token == generation) {
                stop()
                error = "Ne mogu da reprodukujem ovu pjesmu."
            }
            true
        }
        try {
            if (dataSourcePath != null) p.setDataSource(dataSourcePath)
            else p.setDataSource(getApplication(), track.mp3.uri)
            p.prepareAsync()
        } catch (_: Exception) {
            if (media === p) media = null
            runCatching { p.release() }
            stop()
            error = "Fajl nije dostupan. Ponovo izaberi folder."
        }
    }

    /**
     * MIDI/KAR never runs through Android's device-dependent MIDI synthesizer.
     * We transpose note events first, then FluidSynth renders the file with the built-in
     * GeneralUser GS SoundFont. Timing/KAR meta events stay untouched and GM drums stay on
     * channel 10 without transposition.
     */
    private fun startMidiPlayer(track: Song, token: Int, startAtMs: Int, autoStart: Boolean) {
        if (!track.isMidi || token != generation) return
        preparing = true
        midiAutoStartDesired = autoStart
        val serial = ++midiRenderSerial
        val wantedPitch = transposeSemitones

        viewModelScope.launch {
            try {
                val prepared = withContext(Dispatchers.IO) {
                    val sourceBytes = getApplication<Application>().contentResolver.openInputStream(track.mp3.uri)?.use { it.readBytes() }
                        ?: error("MIDI file is not available")
                    val rendered = MidiTranspose.transpose(sourceBytes, wantedPitch)
                    val renderedFile = File.createTempFile("karamonster-midi-", ".mid", getApplication<Application>().cacheDir).apply {
                        writeBytes(rendered)
                    }
                    val synth = try {
                        FluidSynthMidiPlayer.create(getApplication(), renderedFile, rendered, volume)
                    } catch (t: Throwable) {
                        renderedFile.delete()
                        throw t
                    }
                    renderedFile to synth
                }

                val renderedFile = prepared.first
                val synth = prepared.second
                if (token != generation || serial != midiRenderSerial || song?.mp3?.uri != track.mp3.uri) {
                    withContext(Dispatchers.IO) {
                        synth.release()
                        renderedFile.delete()
                    }
                    return@launch
                }

                midiMedia?.release()
                midiMedia = synth
                activeMidiFile?.takeIf { it != renderedFile }?.let { old ->
                    withContext(Dispatchers.IO) { old.delete() }
                }
                activeMidiFile = renderedFile
                duration = synth.durationMs
                position = startAtMs.coerceIn(0, duration.coerceAtLeast(0))
                if (position > 0) synth.seekTo(position)
                preparing = false
                synth.setVolume(volume)
                if (autoStart) {
                    synth.start()
                    isPlaying = true
                } else {
                    isPlaying = false
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
                if (token == generation && serial == midiRenderSerial) {
                    preparing = false
                    isPlaying = false
                    error = "Ne mogu da reprodukujem ovaj MIDI/KAR fajl kroz FluidSynth."
                }
            }
        }
    }

    private fun startSoundTouch(track: Song, startAtMs: Int, autoStart: Boolean, token: Int) {
        if (track.isVideo || track.isMidi || token != generation) return
        preparing = true
        val player = SoundTouchAudioPlayer(
            context = getApplication(),
            uri = track.mp3.uri,
            initialPitchSemitones = transposeSemitones,
            initialPositionMs = startAtMs,
            onPrepared = { ready ->
                if (soundTouchMedia === ready && token == generation) {
                    duration = ready.durationMs
                    preparing = false
                    ready.setVolume(volume)
                    ready.setPitchSemitones(transposeSemitones)
                    if (autoStart) {
                        ready.start()
                        isPlaying = true
                    } else {
                        isPlaying = false
                    }
                }
            },
            onCompletion = { done ->
                if (soundTouchMedia === done && token == generation) handleLocalCompletion {
                    done.release()
                    if (soundTouchMedia === done) soundTouchMedia = null
                }
            },
            onError = { failed, _ ->
                if (soundTouchMedia === failed && token == generation) {
                    failed.release()
                    soundTouchMedia = null
                    stop()
                    error = "Ne mogu da reprodukujem ovu pjesmu kroz SoundTouch."
                }
            }
        )
        soundTouchMedia = player
        player.setVolume(volume)
    }

    private fun handleLocalCompletion(releasePlayer: () -> Unit) {
        if (syncEditActive) {
            position = duration
            isPlaying = false
            preparing = false
            syncEditFinished = true
            releasePlayer()
        } else {
            stop()
        }
    }

    private fun loadCdg(track: Song, token: Int) {
        loadJob = viewModelScope.launch {
            try {
                val bytes = withContext(Dispatchers.IO) {
                    track.cdg?.let { file ->
                        getApplication<Application>().contentResolver.openInputStream(file.uri)?.use { it.readBytes() }
                    }
                }
                if (token == generation) decoder = bytes?.let(::CdgDecoder)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                if (token == generation) error = "CDG nije dostupan; reprodukcija nastavlja."
            }
        }
    }

    private fun openEmbeddedLyrics3(file: DocumentFile) {
        textJob?.cancel()
        activeEmbeddedLyrics = false
        lyricsText = null
        timedLyrics = emptyList()
        textJob = viewModelScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val bytes = getApplication<Application>().contentResolver.openInputStream(file.uri)?.use { it.readBytes() }
                        ?: return@withContext null
                    val raw = bytes.toString(Charsets.ISO_8859_1)
                    if (!raw.contains("LYRICSBEGIN")) return@withContext null
                    LyricsReader.read(bytes, "lyr3") to LyricsReader.timed(bytes, "lyr3")
                }
                if (result != null) {
                    activeEmbeddedLyrics = true
                    popupTitle = "LYR3"
                    lyricsText = result.first.ifBlank { "Fajl je prazan." }
                    timedLyrics = result.second
                }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { /* No valid embedded Lyrics3: keep Find lyrics online panel. */ }
        }
    }

    /** Start a fresh TXT-only synchronization pass from the beginning. */
    fun startSyncEdit(): Boolean {
        val source = activeTextSidecar
        val embedded = activeEmbeddedLyrics
        if (!embedded && source?.extension() !in setOf("txt", "lrc", "lyr3")) return false
        val clean = lyricsText?.replace("\r\n", "\n")?.replace('\r', '\n')?.trimEnd() ?: return false
        if (clean == "Učitavanje…" || clean.startsWith("Ne mogu da pročitam")) return false
        val lines = clean.lines()
        if (lines.none { it.isNotBlank() }) return false

        // If playback already ended, rebuild the current media player first. play() does
        // not write the TXT; it only reopens the same selected track from the beginning.
        if (media == null && soundTouchMedia == null && midiMedia == null && !preparing) {
            val current = song ?: return false
            play(current)
        }

        textJob?.cancel()
        lyricsText = clean
        activeTextSidecar = source
        activeEmbeddedLyrics = embedded
        syncSource = source
        syncFromEmbedded = embedded
        syncLines = lines
        syncTimes = List(lines.size) { null }
        syncNextIndex = lines.indexOfFirst { it.isNotBlank() }
        syncEditActive = true
        syncEditFinished = false
        syncFingerVisible = true
        extractedPreview = false
        timedLyrics = emptyList()
        showTextOnly = true
        showCdg = true

        // A prepared track restarts immediately. If it is still preparing, its normal
        // onPrepared callback starts it at 0, which is exactly what Sync Edit needs.
        if (!preparing) {
            midiMedia?.let { p ->
                p.seekTo(0)
                p.start()
                position = 0
                isPlaying = true
            } ?: soundTouchMedia?.let { p ->
                p.seekTo(0)
                p.start()
                position = 0
                isPlaying = true
            } ?: media?.let { p ->
                runCatching { p.seekTo(0) }
                runCatching { p.start() }
                position = 0
                isPlaying = true
            }
        }
        return true
    }

    /** Capture the current playback time for the next highlighted non-empty TXT line. */
    fun tapSyncLine(index: Int) {
        if (!syncEditActive || syncEditFinished || index != syncNextIndex) return
        if (index !in syncLines.indices || syncLines[index].isBlank()) return
        val at = runCatching {
            midiMedia?.currentPositionMs ?: soundTouchMedia?.currentPositionMs ?: media?.currentPosition ?: position
        }.getOrDefault(position).coerceAtLeast(0)
        val updated = syncTimes.toMutableList()
        updated[index] = at
        syncTimes = updated
        syncFingerVisible = false
        syncNextIndex = ((index + 1) until syncLines.size).firstOrNull { syncLines[it].isNotBlank() && syncTimes[it] == null } ?: -1
    }

    /** Write LRC-style timestamps into the same TXT file only after the completed pass. */
    fun saveSyncEdit(): Boolean {
        if (!syncEditActive || !syncEditFinished) return false
        if (!syncFromEmbedded && syncSource?.extension() !in setOf("txt", "lrc", "lyr3")) return false
        val missing = syncLines.indices.any { syncLines[it].isNotBlank() && syncTimes.getOrNull(it) == null }
        if (missing) return false

        fun stamp(ms: Int): String {
            val safe = ms.coerceAtLeast(0)
            val minutes = safe / 60000
            val seconds = (safe / 1000) % 60
            val centis = (safe % 1000) / 10
            return "[%02d:%02d.%02d]".format(java.util.Locale.ROOT, minutes, seconds, centis)
        }

        val saved = syncLines.mapIndexed { index, line ->
            if (line.isBlank()) line else stamp(syncTimes[index] ?: 0) + line
        }.joinToString("\n")

        return try {
            val source = if (syncFromEmbedded) {
                val track = song ?: return false
                val parent = track.folder ?: return false
                val name = track.name + ".lrc"
                parent.listFiles().firstOrNull { it.isFile && it.name.equals(name, ignoreCase = true) }
                    ?: parent.createFile("text/plain", name) ?: return false
            } else syncSource ?: return false
            getApplication<Application>().contentResolver.openOutputStream(source.uri, "wt")?.use {
                it.write(saved.toByteArray(Charsets.UTF_8))
            } ?: return false

            val clean = syncLines.joinToString("\n").trimEnd()
            lyricsText = clean
            timedLyrics = syncLines.mapIndexedNotNull { index, line ->
                val at = syncTimes.getOrNull(index)
                if (line.isBlank() || at == null) null else LyricsReader.TimedLine(at, line)
            }.sortedBy { it.startMs }
            activeTextSidecar = source
            activeEmbeddedLyrics = false
            extractedPreview = false
            showTextOnly = false
            popupTitle = source.name ?: "TXT"
            showCdg = true
            clearSyncEditState()
            true
        } catch (_: Exception) { false }
    }

    private fun clearSyncEditState() {
        syncEditActive = false
        syncEditFinished = false
        syncFingerVisible = false
        syncLines = emptyList()
        syncTimes = emptyList()
        syncNextIndex = -1
        syncSource = null
        syncFromEmbedded = false
    }

    private fun transposeKey(track: Song): String = track.mp3.uri.toString()

    /** Local audio can transpose: MIDI/KAR changes note events; decoded audio uses SoundTouch. */
    val transposeSupported: Boolean get() = song?.isVideo != true

    /** Change transpose immediately while keeping the original tempo. */
    fun changeTranspose(delta: Int): Boolean {
        val track = song ?: return false
        if (track.isVideo) return false
        val next = (transposeSemitones + delta).coerceIn(-6, 6)
        if (next == transposeSemitones) return false
        transposeSemitones = next

        if (track.isMidi) {
            val midi = midiMedia
            val at = if (midi != null && !preparing) midi.currentPositionMs.coerceAtLeast(0)
            else position.coerceAtLeast(0)
            val resume = if (preparing) midiAutoStartDesired else isPlaying
            midiRenderSerial++ // invalidate an in-flight render/synth creation before rebuilding
            runCatching { midi?.release() }
            if (midiMedia === midi) midiMedia = null
            activeMidiFile?.let { old -> runCatching { old.delete() } }
            activeMidiFile = null
            position = at
            isPlaying = false
            startMidiPlayer(track, generation, startAtMs = at, autoStart = resume)
            return true
        }

        soundTouchMedia?.let { st ->
            if (next == 0) {
                val at = st.currentPositionMs.coerceAtLeast(0)
                val resume = isPlaying
                st.release()
                if (soundTouchMedia === st) soundTouchMedia = null
                position = at
                isPlaying = false
                preparing = true
                startPlatformPlayer(track, generation, startAtMs = at, autoStart = resume)
            } else {
                st.setPitchSemitones(next)
            }
            return true
        }

        // At 0 semitones the normal MediaPlayer path is bit-for-bit untouched. As soon as the
        // user requests a key change, continue from the same position through SoundTouch.
        val p = media
        if (p != null && !preparing && next != 0) {
            val at = runCatching { p.currentPosition }.getOrDefault(position).coerceAtLeast(0)
            val resume = isPlaying
            runCatching { p.release() }
            if (media === p) media = null
            position = at
            isPlaying = false
            startSoundTouch(track, at, autoStart = resume, token = generation)
        }
        return true
    }

    /** Persist the current transpose for this local media item. */
    fun saveTranspose(): Boolean {
        val track = song ?: return false
        if (track.isVideo) return false
        val key = transposeKey(track)
        val edit = transposePrefs.edit()
        if (transposeSemitones == 0) edit.remove(key) else edit.putInt(key, transposeSemitones)
        edit.apply()
        savedTransposeSemitones = transposeSemitones
        return true
    }

    fun togglePause() {
        if (preparing) return
        val midi = midiMedia
        val st = soundTouchMedia
        if (midi == null && st == null && media == null) {
            song?.let {
                stopBreak()
                play(it)
            }
            return
        }
        if (midi != null) {
            if (isPlaying) midi.pause() else midi.start()
            isPlaying = !isPlaying
            return
        }
        if (st != null) {
            if (isPlaying) st.pause() else st.start()
            isPlaying = !isPlaying
            return
        }
        media?.let { p ->
            if (isPlaying) p.pause() else p.start()
            isPlaying = !isPlaying
        }
    }

    internal fun openText(file: DocumentFile, standalone: Boolean = false) {
        textJob?.cancel()
        activeTextSidecar = file
        activeEmbeddedLyrics = false
        showCdg = true
        showTextOnly = standalone
        popupTitle = file.name ?: "TEKST"
        lyricsText = "Učitavanje…"
        timedLyrics = emptyList()
        textJob = viewModelScope.launch {
            try {
                val (text, timed) = withContext(Dispatchers.IO) {
                    val bytes = getApplication<Application>().contentResolver.openInputStream(file.uri)?.use { it.readBytes() }
                        ?: error("Fajl nije dostupan")
                    LyricsReader.read(bytes, file.extension()) to LyricsReader.timed(bytes, file.extension())
                }
                timedLyrics = timed
                lyricsText = text.ifBlank { "Fajl je prazan." }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { lyricsText = "Ne mogu da pročitam tekst iz ovog fajla." }
        }
    }

    /** Preview extracted web lyrics in the existing half-screen panel without writing a file. */
    fun previewExtractedLyrics(text: String): Boolean {
        val clean = text.replace("\r\n", "\n").replace('\r', '\n').trim()
        val lines = clean.lines().map { it.trim() }.filter { it.isNotBlank() }
        val useful = lines.count { it.length in 8..140 }
        if (clean.length < 120 || lines.size < 6 || useful < 5) return false
        textJob?.cancel()
        activeTextSidecar = null
        activeEmbeddedLyrics = false
        extractedPreview = true
        showTextOnly = true
        popupTitle = "Lyrics preview"
        timedLyrics = emptyList()
        lyricsText = clean
        showCdg = true
        return true
    }

    /** Save extracted web lyrics beside the active media file and show them immediately. */
    fun saveExtractedLyrics(text: String, allowEmpty: Boolean = false): Boolean {
        val track = song ?: return false
        val clean = text.replace("\r\n", "\n").replace('\r', '\n').trim()
        if (clean.isBlank() && !allowEmpty) return false
        return try {
            val parent = track.folder ?: return false
            val wantedName = track.name + ".txt"
            val existing = parent.listFiles().firstOrNull { it.isFile && it.name.equals(wantedName, ignoreCase = true) }
            val target = existing ?: parent.createFile("text/plain", wantedName) ?: return false
            getApplication<Application>().contentResolver.openOutputStream(target.uri, "wt")?.use {
                it.write(clean.toByteArray(Charsets.UTF_8))
            } ?: return false
            textJob?.cancel()
            activeTextSidecar = target
            activeEmbeddedLyrics = false
            extractedPreview = false
            showTextOnly = false
            popupTitle = target.name ?: wantedName
            timedLyrics = emptyList()
            lyricsText = clean
            showCdg = true
            true
        } catch (_: Exception) { false }
    }

    /** Start BREAK playback from the selected file, then continue through this folder. */
    fun startBreakPlaylist(files: List<DocumentFile>, selected: DocumentFile? = null): Boolean {
        val playable = files.filter { it.isFile && it.extension() in mediaExtensions }
            .distinctBy { it.uri.toString() }
        if (playable.isEmpty()) return false

        // BREAK takes audio ownership immediately, but remains independent from navigation.
        karaokeWeb.stopForLocal()
        lyricsWeb.close()
        stop()
        showCdg = false
        stopBreak(clearPlaylist = true)
        breakFiles = playable

        val selectedIndex = selected?.let { wanted ->
            playable.indexOfFirst { it.uri == wanted.uri }
        }?.takeIf { it >= 0 }
        rebuildBreakOrder(selectedIndex)
        if (breakOrder.isEmpty()) return false
        breakOrderPosition = 0
        playBreakIndex(breakOrder[0])
        return true
    }

    private fun rebuildBreakOrder(firstIndex: Int? = null) {
        val all = breakFiles.indices.toList()
        if (all.isEmpty()) {
            breakOrder = emptyList()
            breakOrderPosition = -1
            return
        }
        val first = firstIndex?.takeIf { it in all }
        val rest = if (first == null) all else all.filter { it != first }
        val orderedRest = if (breakRandom) rest.shuffled() else rest
        breakOrder = if (first == null) {
            if (breakRandom) all.shuffled() else all
        } else listOf(first) + orderedRest
        breakOrderPosition = if (breakOrder.isEmpty()) -1 else 0
    }

    private fun playBreakIndex(index: Int) {
        val file = breakFiles.getOrNull(index) ?: return
        breakMedia?.release()
        breakMedia = null
        breakTrack = file
        breakPreparing = true
        breakIsPlaying = false
        breakPosition = 0
        breakDuration = 0

        val p = MediaPlayer()
        breakMedia = p
        p.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
        )
        p.setVolume(volume, volume)
        p.setOnPreparedListener {
            if (breakMedia === p) {
                breakPreparing = false
                breakDuration = runCatching { p.duration }.getOrDefault(0)
                p.start()
                breakIsPlaying = true
            }
        }
        p.setOnCompletionListener {
            if (breakMedia === p) {
                runCatching { p.release() }
                breakMedia = null
                breakIsPlaying = false
                breakPreparing = false
                breakPosition = breakDuration
                advanceBreak()
            }
        }
        p.setOnErrorListener { _, _, _ ->
            if (breakMedia === p) {
                runCatching { p.release() }
                breakMedia = null
                breakIsPlaying = false
                breakPreparing = false
                advanceBreak()
            }
            true
        }
        try {
            p.setDataSource(getApplication(), file.uri)
            p.prepareAsync()
        } catch (_: Exception) {
            runCatching { p.release() }
            if (breakMedia === p) breakMedia = null
            breakPreparing = false
            breakIsPlaying = false
            advanceBreak()
        }
    }

    private fun advanceBreak() {
        if (breakFiles.isEmpty()) return
        val next = breakOrderPosition + 1
        if (next in breakOrder.indices) {
            breakOrderPosition = next
            playBreakIndex(breakOrder[next])
            return
        }
        if (breakRepeat) {
            rebuildBreakOrder()
            if (breakOrder.isNotEmpty()) {
                breakOrderPosition = 0
                playBreakIndex(breakOrder[0])
            }
        } else {
            // End of the folder with REPEAT OFF: BREAK session is finished.
            breakTrack = null
            breakPosition = 0
            breakDuration = 0
        }
    }

    fun seekBreakTo(value: Int) {
        if (breakPreparing || breakDuration <= 0) return
        val target = value.coerceIn(0, breakDuration)
        breakMedia?.let { p ->
            runCatching { p.seekTo(target) }
            breakPosition = target
        }
    }

    fun nextBreak() {
        if (breakFiles.isEmpty()) return
        if (breakOrder.isEmpty() || breakOrderPosition < 0) {
            rebuildBreakOrder()
            if (breakOrder.isNotEmpty()) {
                breakOrderPosition = 0
                playBreakIndex(breakOrder[0])
            }
            return
        }

        breakMedia?.release()
        breakMedia = null
        breakPreparing = false
        breakIsPlaying = false
        advanceBreak()
    }

    fun toggleBreakPause() {
        if (breakPreparing) return
        val p = breakMedia
        if (p == null) {
            if (breakFiles.isNotEmpty()) {
                rebuildBreakOrder()
                if (breakOrder.isNotEmpty()) {
                    breakOrderPosition = 0
                    playBreakIndex(breakOrder[0])
                }
            }
            return
        }
        if (breakIsPlaying) {
            runCatching { p.pause() }
            breakIsPlaying = false
        } else {
            runCatching { p.start() }
            breakIsPlaying = true
        }
    }

    fun updateBreakRandom(value: Boolean) {
        if (breakRandom == value) return
        breakRandom = value
        if (breakFiles.isNotEmpty()) {
            val current = breakTrack?.let { file -> breakFiles.indexOfFirst { it.uri == file.uri } }
                ?.takeIf { it >= 0 }
            rebuildBreakOrder(current)
        }
    }

    fun updateBreakRepeat(value: Boolean) {
        breakRepeat = value
    }

    fun stopBreak(clearPlaylist: Boolean = false) {
        breakMedia?.release()
        breakMedia = null
        breakPreparing = false
        breakIsPlaying = false
        breakPosition = 0
        breakDuration = 0
        breakTrack = null
        if (clearPlaylist) {
            breakFiles = emptyList()
            breakOrder = emptyList()
            breakOrderPosition = -1
        }
    }

    fun setVolume(value: Float) {
        volume = value.coerceIn(0f, 1f)
        media?.setVolume(volume, volume)
        soundTouchMedia?.setVolume(volume)
        midiMedia?.setVolume(volume)
        breakMedia?.setVolume(volume, volume)
    }

    fun setVideoSurface(holder: SurfaceHolder?) {
        videoSurface = holder
        if (song?.isVideo == true) media?.setDisplay(holder)
    }

    fun seekTo(value: Int) {
        if (preparing) return
        val target = value.coerceIn(0, duration)
        midiMedia?.seekTo(target) ?: soundTouchMedia?.seekTo(target) ?: media?.seekTo(target)
        position = target
    }

    fun stop() {
        generation++
        midiRenderSerial++
        loadJob?.cancel()
        loadJob = null
        media?.release()
        media = null
        soundTouchMedia?.release()
        soundTouchMedia = null
        midiMedia?.release()
        midiMedia = null
        activeMidiFile?.let { file -> runCatching { file.delete() } }
        activeMidiFile = null
        midiAutoStartDesired = true
        preparing = false
        isPlaying = false
        position = 0
        duration = 0
        clearSyncEditState()
    }

    override fun onCleared() { stop(); stopBreak(clearPlaylist = true); textJob?.cancel(); karaokeWeb.close(); lyricsWeb.close() }
}
