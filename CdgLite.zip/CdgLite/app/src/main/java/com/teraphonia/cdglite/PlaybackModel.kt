package com.teraphonia.cdglite

import android.app.Application
import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.view.SurfaceHolder
import androidx.compose.runtime.*
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*

internal data class Song(
    val name: String,
    val mp3: DocumentFile,
    val cdg: DocumentFile?,
    val text: DocumentFile? = null,
    val folder: DocumentFile? = null
)
internal val Song.isVideo get() = mp3.extension() in videoExtensions

/** Playback owns its resources independently of navigation and popup visibility. */
class PlaybackModel(app: Application) : AndroidViewModel(app) {
    // Physically separate browsers: GLUPAN = karaoke, TUPAN = lyrics.
    internal val karaokeWeb = WebAudioController(app, this, WebRole.KARAOKE)
    internal val lyricsWeb = WebAudioController(app, this, WebRole.LYRICS)
    /** Legacy test/compat alias: WEB always means the karaoke browser (GLUPAN). */
    internal val web get() = karaokeWeb
    internal var song by mutableStateOf<Song?>(null)
        private set
    var preparing by mutableStateOf(false)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var position by mutableIntStateOf(0)
        private set
    var duration by mutableIntStateOf(0)
        private set
    var frame by mutableStateOf<Bitmap?>(null)
        private set
    var showCdg by mutableStateOf(false)
    var showTextOnly by mutableStateOf(false)
    /** The selected Song carries this same-folder sidecar all the way to the CDG panel. */
    internal var activeTextSidecar by mutableStateOf<DocumentFile?>(null)
        private set
    internal var activeEmbeddedLyrics by mutableStateOf(false)
        private set
    var lyricsText by mutableStateOf<String?>(null)
        private set
    var extractedPreview by mutableStateOf(false)
        private set

    // TXT-only tap-to-sync editor. Nothing is written until SAVE is pressed.
    var syncEditActive by mutableStateOf(false)
        private set
    var syncEditFinished by mutableStateOf(false)
        private set
    var syncFingerVisible by mutableStateOf(false)
        private set
    var syncLines by mutableStateOf<List<String>>(emptyList())
        private set
    var syncTimes by mutableStateOf<List<Int?>>(emptyList())
        private set
    var syncNextIndex by mutableIntStateOf(-1)
        private set
    private var syncSource: DocumentFile? = null

    internal var timedLyrics by mutableStateOf<List<LyricsReader.TimedLine>>(emptyList())
        private set
    var popupTitle by mutableStateOf("CDG")
        private set
    private var textJob: Job? = null
    var error by mutableStateOf<String?>(null)
    private var media: MediaPlayer? = null
    private var videoSurface: SurfaceHolder? = null
    private var decoder: CdgDecoder? = null
    private var loadJob: Job? = null
    private var generation = 0
    private var volume = 1f

    init {
        viewModelScope.launch {
            while (isActive) {
                val p = media
                if (p != null && !preparing) {
                    position = p.currentPosition
                    if (showCdg) {
                        decoder?.let { d ->
                            val at = position
                            val nextFrame = withContext(Dispatchers.Default) {
                                d.seekTo(at)
                                d.bitmapCopy()
                            }
                            if (media === p && decoder === d && showCdg) frame = nextFrame
                        }
                    }
                }
                delay(40)
            }
        }
    }

    internal fun startLocal(track: Song) {
        karaokeWeb.stopForLocal()
        lyricsWeb.close()
        play(track)
    }

    internal fun play(track: Song) {
        stop()
        textJob?.cancel()
        activeTextSidecar = null
        activeEmbeddedLyrics = false
        lyricsText = null
        extractedPreview = false
        timedLyrics = emptyList()
        showTextOnly = false
        frame = null
        decoder = null
        popupTitle = "CDG"
        error = null
        song = track
        preparing = true
        // Every selected local media item uses the same half-screen display path.
        // Priority stays CDG first, then same-name text sidecar, then embedded MP3 Lyrics3.
        // If none exists, the panel remains open and offers online lyrics search.
        showCdg = true
        // Keep the discovered sidecar on the selected media item, exactly as for CDG.
        // The panel reads activeTextSidecar; it never searches the folder again.
        if (track.cdg == null) {
            if (track.text != null) openText(track.text)
            else if (track.mp3.extension() == "mp3") openEmbeddedLyrics3(track.mp3)
        }
        val token = generation
        val p = MediaPlayer()
        media = p
        if (track.isVideo) p.setDisplay(videoSurface)
        p.setAudioAttributes(AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
        p.setVolume(volume, volume)
        p.setOnPreparedListener {
            if (media === p) {
                preparing = false
                duration = p.duration
                p.start()
                isPlaying = true
            }
        }
        p.setOnCompletionListener {
            if (media === p) {
                if (syncEditActive) {
                    // End of the tap-through pass: keep the captured timestamps in memory
                    // and show SAVE. The original TXT is still untouched.
                    position = duration
                    isPlaying = false
                    preparing = false
                    syncEditFinished = true
                    runCatching { p.release() }
                    media = null
                } else stop()
            }
        }
        p.setOnErrorListener { _, _, _ ->
            if (media === p) { stop(); error = "Ne mogu da reprodukujem ovu pjesmu." }
            true
        }
        try {
            p.setDataSource(getApplication(), track.mp3.uri)
            p.prepareAsync()
        } catch (_: Exception) {
            stop()
            error = "Fajl nije dostupan. Ponovo izaberi folder."
            return
        }
        loadJob = viewModelScope.launch {
            try {
                val bytes = withContext(Dispatchers.IO) {
                    track.cdg?.let { file ->
                        getApplication<Application>().contentResolver.openInputStream(file.uri)?.use { it.readBytes() }
                    }
                }
                if (token == generation) decoder = bytes?.let(::CdgDecoder)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                if (token == generation) error = "CDG nije dostupan; reprodukcija nastavlja."
            }
        }
    }

    private fun openEmbeddedLyrics3(file: DocumentFile) {
        textJob?.cancel()
        activeEmbeddedLyrics = false
        lyricsText = null
        timedLyrics = emptyList()
        textJob = viewModelScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val bytes = getApplication<Application>().contentResolver.openInputStream(file.uri)?.use { it.readBytes() }
                        ?: return@withContext null
                    val raw = bytes.toString(Charsets.ISO_8859_1)
                    if (!raw.contains("LYRICSBEGIN")) return@withContext null
                    LyricsReader.read(bytes, "lyr3") to LyricsReader.timed(bytes, "lyr3")
                }
                if (result != null) {
                    activeEmbeddedLyrics = true
                    popupTitle = "LYR3"
                    lyricsText = result.first.ifBlank { "Fajl je prazan." }
                    timedLyrics = result.second
                }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { /* No valid embedded Lyrics3: keep Find lyrics online panel. */ }
        }
    }

    /** Start a fresh TXT-only synchronization pass from the beginning. */
    fun startSyncEdit(): Boolean {
        val source = activeTextSidecar ?: return false
        if (source.extension() != "txt") return false
        val clean = lyricsText?.replace("\r\n", "\n")?.replace('\r', '\n')?.trimEnd() ?: return false
        if (clean == "Učitavanje…" || clean.startsWith("Ne mogu da pročitam")) return false
        val lines = clean.lines()
        if (lines.none { it.isNotBlank() }) return false

        // If playback already ended, rebuild the current media player first. play() does
        // not write the TXT; it only reopens the same selected track from the beginning.
        if (media == null && !preparing) {
            val current = song ?: return false
            play(current)
        }

        syncSource = source
        syncLines = lines
        syncTimes = List(lines.size) { null }
        syncNextIndex = lines.indexOfFirst { it.isNotBlank() }
        syncEditActive = true
        syncEditFinished = false
        syncFingerVisible = true
        extractedPreview = false
        timedLyrics = emptyList()
        showTextOnly = true
        showCdg = true

        // A prepared track restarts immediately. If it is still preparing, its normal
        // onPrepared callback starts it at 0, which is exactly what Sync Edit needs.
        if (!preparing) {
            media?.let { p ->
                runCatching { p.seekTo(0) }
                runCatching { p.start() }
                position = 0
                isPlaying = true
            }
        }
        return true
    }

    /** Capture the current playback time for the next highlighted non-empty TXT line. */
    fun tapSyncLine(index: Int) {
        if (!syncEditActive || syncEditFinished || index != syncNextIndex) return
        if (index !in syncLines.indices || syncLines[index].isBlank()) return
        val at = runCatching { media?.currentPosition ?: position }.getOrDefault(position).coerceAtLeast(0)
        val updated = syncTimes.toMutableList()
        updated[index] = at
        syncTimes = updated
        syncFingerVisible = false
        syncNextIndex = ((index + 1) until syncLines.size).firstOrNull { syncLines[it].isNotBlank() && syncTimes[it] == null } ?: -1
    }

    /** Write LRC-style timestamps into the same TXT file only after the completed pass. */
    fun saveSyncEdit(): Boolean {
        val source = syncSource ?: return false
        if (!syncEditActive || !syncEditFinished || source.extension() != "txt") return false
        val missing = syncLines.indices.any { syncLines[it].isNotBlank() && syncTimes.getOrNull(it) == null }
        if (missing) return false

        fun stamp(ms: Int): String {
            val safe = ms.coerceAtLeast(0)
            val minutes = safe / 60000
            val seconds = (safe / 1000) % 60
            val centis = (safe % 1000) / 10
            return "[%02d:%02d.%02d]".format(java.util.Locale.ROOT, minutes, seconds, centis)
        }

        val saved = syncLines.mapIndexed { index, line ->
            if (line.isBlank()) line else stamp(syncTimes[index] ?: 0) + line
        }.joinToString("\n")

        return try {
            getApplication<Application>().contentResolver.openOutputStream(source.uri, "wt")?.use {
                it.write(saved.toByteArray(Charsets.UTF_8))
            } ?: return false

            val clean = syncLines.joinToString("\n").trimEnd()
            lyricsText = clean
            timedLyrics = syncLines.mapIndexedNotNull { index, line ->
                val at = syncTimes.getOrNull(index)
                if (line.isBlank() || at == null) null else LyricsReader.TimedLine(at, line)
            }.sortedBy { it.startMs }
            activeTextSidecar = source
            activeEmbeddedLyrics = false
            extractedPreview = false
            showTextOnly = false
            popupTitle = source.name ?: "TXT"
            showCdg = true
            clearSyncEditState()
            true
        } catch (_: Exception) { false }
    }

    private fun clearSyncEditState() {
        syncEditActive = false
        syncEditFinished = false
        syncFingerVisible = false
        syncLines = emptyList()
        syncTimes = emptyList()
        syncNextIndex = -1
        syncSource = null
    }

    fun togglePause() {
        if (preparing) return
        if (media == null) { song?.let { play(it) }; return }
        media?.let { p ->
            if (isPlaying) p.pause() else p.start()
            isPlaying = !isPlaying
        }
    }

    internal fun openText(file: DocumentFile, standalone: Boolean = false) {
        textJob?.cancel()
        activeTextSidecar = file
        activeEmbeddedLyrics = false
        showCdg = true
        showTextOnly = standalone
        popupTitle = file.name ?: "TEKST"
        lyricsText = "Učitavanje…"
        timedLyrics = emptyList()
        textJob = viewModelScope.launch {
            try {
                val (text, timed) = withContext(Dispatchers.IO) {
                    val bytes = getApplication<Application>().contentResolver.openInputStream(file.uri)?.use { it.readBytes() }
                        ?: error("Fajl nije dostupan")
                    LyricsReader.read(bytes, file.extension()) to LyricsReader.timed(bytes, file.extension())
                }
                timedLyrics = timed
                lyricsText = text.ifBlank { "Fajl je prazan." }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { lyricsText = "Ne mogu da pročitam tekst iz ovog fajla." }
        }
    }

    /** Preview extracted web lyrics in the existing half-screen panel without writing a file. */
    fun previewExtractedLyrics(text: String): Boolean {
        val clean = text.replace("\r\n", "\n").replace('\r', '\n').trim()
        val lines = clean.lines().map { it.trim() }.filter { it.isNotBlank() }
        val useful = lines.count { it.length in 8..140 }
        if (clean.length < 120 || lines.size < 6 || useful < 5) return false
        textJob?.cancel()
        activeTextSidecar = null
        activeEmbeddedLyrics = false
        extractedPreview = true
        showTextOnly = true
        popupTitle = "Lyrics preview"
        timedLyrics = emptyList()
        lyricsText = clean
        showCdg = true
        return true
    }

    /** Save extracted web lyrics beside the active media file and show them immediately. */
    fun saveExtractedLyrics(text: String): Boolean {
        val track = song ?: return false
        val clean = text.replace("\r\n", "\n").replace('\r', '\n').trim()
        if (clean.isBlank()) return false
        return try {
            val parent = track.folder ?: return false
            val wantedName = track.name + ".txt"
            val existing = parent.listFiles().firstOrNull { it.isFile && it.name.equals(wantedName, ignoreCase = true) }
            val target = existing ?: parent.createFile("text/plain", wantedName) ?: return false
            getApplication<Application>().contentResolver.openOutputStream(target.uri, "wt")?.use {
                it.write(clean.toByteArray(Charsets.UTF_8))
            } ?: return false
            textJob?.cancel()
            activeTextSidecar = target
            activeEmbeddedLyrics = false
            extractedPreview = false
            showTextOnly = false
            popupTitle = target.name ?: wantedName
            timedLyrics = emptyList()
            lyricsText = clean
            showCdg = true
            true
        } catch (_: Exception) { false }
    }

    fun setVolume(value: Float) {
        volume = value.coerceIn(0f, 1f)
        media?.setVolume(volume, volume)
    }

    fun setVideoSurface(holder: SurfaceHolder?) {
        videoSurface = holder
        if (song?.isVideo == true) media?.setDisplay(holder)
    }

    fun seekTo(value: Int) {
        if (!preparing) media?.seekTo(value.coerceIn(0, duration))
    }

    fun stop() {
        generation++
        loadJob?.cancel()
        loadJob = null
        media?.release()
        media = null
        preparing = false
        isPlaying = false
        position = 0
        duration = 0
        clearSyncEditState()
    }

    override fun onCleared() { stop(); textJob?.cancel(); karaokeWeb.close(); lyricsWeb.close() }
}
