package com.teraphonia.cdglite

import android.app.Application
import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.view.SurfaceHolder
import androidx.compose.runtime.*
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*

internal data class Song(
    val name: String,
    val mp3: DocumentFile,
    val cdg: DocumentFile?,
    val text: DocumentFile? = null
)
internal val Song.isVideo get() = mp3.extension() in videoExtensions

/** Playback owns its resources independently of navigation and popup visibility. */
class PlaybackModel(app: Application) : AndroidViewModel(app) {
    internal val web = WebAudioController(app, this)
    internal var song by mutableStateOf<Song?>(null)
        private set
    var preparing by mutableStateOf(false)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var position by mutableIntStateOf(0)
        private set
    var duration by mutableIntStateOf(0)
        private set
    var frame by mutableStateOf<Bitmap?>(null)
        private set
    var showCdg by mutableStateOf(false)
    var showTextOnly by mutableStateOf(false)
    var lyricsText by mutableStateOf<String?>(null)
        private set
    internal var timedLyrics by mutableStateOf<List<LyricsReader.TimedLine>>(emptyList())
        private set
    var popupTitle by mutableStateOf("CDG")
        private set
    private var textJob: Job? = null
    var error by mutableStateOf<String?>(null)
    private var media: MediaPlayer? = null
    private var videoSurface: SurfaceHolder? = null
    private var decoder: CdgDecoder? = null
    private var loadJob: Job? = null
    private var generation = 0
    private var volume = 1f

    init {
        viewModelScope.launch {
            while (isActive) {
                val p = media
                if (p != null && !preparing) {
                    position = p.currentPosition
                    if (showCdg) {
                        decoder?.let { d ->
                            val at = position
                            val nextFrame = withContext(Dispatchers.Default) {
                                d.seekTo(at)
                                d.bitmapCopy()
                            }
                            if (media === p && decoder === d && showCdg) frame = nextFrame
                        }
                    }
                }
                delay(40)
            }
        }
    }

    internal fun startLocal(track: Song) {
        web.stopForLocal()
        play(track)
    }

    internal fun play(track: Song) {
        stop()
        textJob?.cancel()
        lyricsText = null
        timedLyrics = emptyList()
        showTextOnly = false
        frame = null
        decoder = null
        popupTitle = "CDG"
        error = null
        song = track
        preparing = true
        showCdg = track.isVideo || track.cdg != null || track.text != null
        if (track.cdg == null) track.text?.let { openText(it) }
        val token = generation
        val p = MediaPlayer()
        media = p
        if (track.isVideo) p.setDisplay(videoSurface)
        p.setAudioAttributes(AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
        p.setVolume(volume, volume)
        p.setOnPreparedListener {
            if (media === p) {
                preparing = false
                duration = p.duration
                p.start()
                isPlaying = true
            }
        }
        p.setOnCompletionListener { if (media === p) stop() }
        p.setOnErrorListener { _, _, _ ->
            if (media === p) { stop(); error = "Ne mogu da reprodukujem ovu pjesmu." }
            true
        }
        try {
            p.setDataSource(getApplication(), track.mp3.uri)
            p.prepareAsync()
        } catch (_: Exception) {
            stop()
            error = "Fajl nije dostupan. Ponovo izaberi folder."
            return
        }
        loadJob = viewModelScope.launch {
            try {
                val bytes = withContext(Dispatchers.IO) {
                    track.cdg?.let { file ->
                        getApplication<Application>().contentResolver.openInputStream(file.uri)?.use { it.readBytes() }
                    }
                }
                if (token == generation) decoder = bytes?.let(::CdgDecoder)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                if (token == generation) error = "CDG nije dostupan; reprodukcija nastavlja."
            }
        }
    }

    fun togglePause() {
        if (preparing) return
        if (media == null) { song?.let { play(it) }; return }
        media?.let { p ->
            if (isPlaying) p.pause() else p.start()
            isPlaying = !isPlaying
        }
    }

    internal fun openText(file: DocumentFile, standalone: Boolean = false) {
        textJob?.cancel()
        showCdg = true
        showTextOnly = standalone
        popupTitle = file.name ?: "TEKST"
        lyricsText = "Učitavanje…"
        timedLyrics = emptyList()
        textJob = viewModelScope.launch {
            try {
                val (text, timed) = withContext(Dispatchers.IO) {
                    val bytes = getApplication<Application>().contentResolver.openInputStream(file.uri)?.use { it.readBytes() }
                        ?: error("Fajl nije dostupan")
                    LyricsReader.read(bytes, file.extension()) to LyricsReader.timed(bytes, file.extension())
                }
                timedLyrics = timed
                lyricsText = text.ifBlank { "Fajl je prazan." }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { lyricsText = "Ne mogu da pročitam tekst iz ovog fajla." }
        }
    }

    fun setVolume(value: Float) {
        volume = value.coerceIn(0f, 1f)
        media?.setVolume(volume, volume)
    }

    fun setVideoSurface(holder: SurfaceHolder?) {
        videoSurface = holder
        if (song?.isVideo == true) media?.setDisplay(holder)
    }

    fun seekTo(value: Int) {
        if (!preparing) media?.seekTo(value.coerceIn(0, duration))
    }

    fun stop() {
        generation++
        loadJob?.cancel()
        loadJob = null
        media?.release()
        media = null
        preparing = false
        isPlaying = false
        position = 0
        duration = 0
    }

    override fun onCleared() { stop(); textJob?.cancel(); web.close() }
}
