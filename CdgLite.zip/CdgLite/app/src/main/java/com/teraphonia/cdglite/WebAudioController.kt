package com.teraphonia.cdglite

import android.content.Context
import android.content.MutableContextWrapper
import android.graphics.Bitmap
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.*
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject

/** The native WebView mute is the handoff gate, including cross-origin frames. */
internal class WebAudioController(private val context: Context, private val local: PlaybackModel) {
    var isPlaying by mutableStateOf(false)
        private set
    var message by mutableStateOf<String?>(null)
        private set
    var opened by mutableStateOf(false)
        private set
    private var epoch = 0
    private var view: WebView? = null
    private var canControl = false
    private var canMute = false
    private var autoPlayOnReady = false
    private var suppressAutoPlayOnce = false
    private var lyricsOnly = false
    private data class Frame(val reply: JavaScriptReplyProxy, var score: Double = 0.0, var playing: Boolean = false)
    private val frames = mutableMapOf<String, Frame>()
    internal val hasPlayableMedia get() = frames.values.any { it.score > 0 }

    fun webView(uiContext: Context): WebView {
        val web = view ?: create().also { view = it }
        (web.context as MutableContextWrapper).baseContext = uiContext
        return web
    }

    /** Hard-silence only the Find Lyrics browsing document. Karaoke pages never receive this script. */
    private fun silenceLyricsDocument(web: WebView) {
        if (!lyricsOnly) return
        mute(true)
        val js = """(function(){try{
          if(window.__cdgLyricsSilent)return; window.__cdgLyricsSilent=true;
          function kill(e){try{e.muted=true;e.defaultMuted=true;e.volume=0;e.pause();e.setAttribute('muted','');}catch(_){} }
          function killAll(){try{document.querySelectorAll('audio,video').forEach(kill);}catch(_){} }
          try{
            var originalPlay=HTMLMediaElement.prototype.play;
            HTMLMediaElement.prototype.play=function(){kill(this);return Promise.resolve();};
          }catch(_){}
          document.addEventListener('play',function(e){if(e.target instanceof HTMLMediaElement)kill(e.target);},true);
          document.addEventListener('playing',function(e){if(e.target instanceof HTMLMediaElement)kill(e.target);},true);
          try{new MutationObserver(killAll).observe(document.documentElement||document,{childList:true,subtree:true});}catch(_){}
          killAll(); setInterval(killAll,250);
        }catch(_){}})()"""
        try { web.evaluateJavascript(js, null) } catch (_: Throwable) {}
    }

    private fun create(): WebView = WebView(MutableContextWrapper(context)).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false // only the controlled PLAY path is audible
        // Audio muting and karaoke bridge support are independent capabilities.
        // Lyrics browsing must still work on WebView versions that do not support
        // the document-start/message-listener karaoke bridge.
        canMute = WebViewFeature.isFeatureSupported(WebViewFeature.MUTE_AUDIO)
        canControl = listOf(WebViewFeature.DOCUMENT_START_SCRIPT, WebViewFeature.WEB_MESSAGE_LISTENER).all(WebViewFeature::isFeatureSupported)
        if (canMute) WebViewCompat.setAudioMuted(this, true)
        if (canControl && !lyricsOnly) {
            // Karaoke bridge only. The Find Lyrics browser deliberately stays identical
            // to LyrGig's plain WebView so site DOM/extraction is not disturbed.
            WebViewCompat.addWebMessageListener(this, "cdgHost", setOf("*")) { _, payload, _, _, reply ->
                receive(payload.data.orEmpty(), reply)
            }
            WebViewCompat.addDocumentStartJavaScript(this, context.assets.open("web-audio.js").bufferedReader().use { it.readText() }, setOf("*"))
        } else if (lyricsOnly && WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            // Silence media from the first script tick without changing/blocking network requests.
            WebViewCompat.addDocumentStartJavaScript(this, """(function(){try{var p=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){try{this.muted=true;this.volume=0;this.pause();}catch(e){}return Promise.resolve();};document.addEventListener('play',function(e){try{if(e.target instanceof HTMLMediaElement){e.target.muted=true;e.target.volume=0;e.target.pause();}}catch(x){}},true);}catch(e){}})();""", setOf("*"))
        }
        webViewClient = object : WebViewClient() {
            override fun onPageFinished(web: WebView, url: String) {
                // Force a high-contrast dark reading surface even on pages without their own dark theme.
                web.evaluateJavascript("""(function(){var s=document.getElementById('cdglite-dark');if(!s){s=document.createElement('style');s.id='cdglite-dark';s.textContent='html,body{background:#000!important;color:#fff!important} body *{border-color:#444!important} a{color:#8ab4f8!important} input,textarea,select,button{background:#171717!important;color:#fff!important}';document.documentElement.appendChild(s)}})()""", null)
                silenceLyricsDocument(web)
            }
            override fun onPageStarted(web: WebView, url: String, favicon: Bitmap?) {
                epoch++
                frames.clear()
                isPlaying = false
                mute(true)
                if (lyricsOnly) silenceLyricsDocument(web)
                // The initial Google results page stays silent. Any page opened from it
                // (the selected karaoke number) starts as soon as playable media appears.
                autoPlayOnReady = opened && !suppressAutoPlayOnce && !lyricsOnly
                suppressAutoPlayOnce = false
            }
        }
    }

    fun extractLyrics(result: (String?) -> Unit) {
        val web = view ?: return result(null)
        // This is intentionally the same extraction algorithm used by the proven
        // LyrGig/GigLyrics Web extractor. Do not replace it with a CdgLite-specific parser.
        val js = """
            (function() {
              function clean(t) {
                return (t || '')
                  .replace(/\\r/g, '')
                  .replace(/[ \\t]+\\n/g, '\\n')
                  .replace(/\\n[ \\t]+/g, '\\n')
                  .replace(/\\n{3,}/g, '\\n\\n')
                  .trim();
              }
              const specific = [
                '[data-lyrics-container="true"]',
                '.lyrics', '#lyrics', '.lyric', '#lyric',
                '[class*="lyrics"]', '[id*="lyrics"]'
              ];
              for (const sel of specific) {
                const nodes = Array.from(document.querySelectorAll(sel));
                if (nodes.length) {
                  const t = clean(nodes.map(n => n.innerText).join('\\n'));
                  if (t.length > 120) return t;
                }
              }

              const clone = document.body.cloneNode(true);
              clone.querySelectorAll('script,style,noscript,nav,header,footer,form,button,svg,canvas,iframe,aside').forEach(n => n.remove());
              const candidates = Array.from(clone.querySelectorAll('main,article,section,div,pre'));
              let best = '';
              let bestScore = -1e9;
              for (const el of candidates) {
                const t = clean(el.innerText);
                if (t.length < 120 || t.length > 18000) continue;
                const lines = t.split('\\n').map(x => x.trim()).filter(Boolean);
                if (lines.length < 4) continue;
                const shortLines = lines.filter(x => x.length >= 2 && x.length <= 90).length;
                const veryLong = lines.filter(x => x.length > 180).length;
                const noise = (t.match(/cookie|privacy|sign in|subscribe|advertis|menu|share|facebook|instagram/gi) || []).length;
                const score = shortLines * 5 + lines.length * 2 - veryLong * 8 - noise * 15 + Math.min(t.length, 4000) / 200;
                if (score > bestScore) { bestScore = score; best = t; }
              }
              return best || clean(clone.innerText);
            })();
        """.trimIndent()
        try {
            web.evaluateJavascript(js) { raw ->
                val value = try {
                    if (raw == null || raw == "null") "" else
                        org.json.JSONTokener(raw).nextValue() as? String ?: ""
                } catch (_: Exception) { "" }

                val cleanedLines = value.lines().map { it.trim() }.filter { it.isNotBlank() }
                val menuNoise = cleanedLines.count {
                    val l = it.lowercase()
                    l == "svi tekstovi" || l.startsWith("poslušaj na") ||
                        l.startsWith("listen on") || l == "home" || l == "menu" ||
                        l == "lyrics" || l == "tekst"
                }
                val usefulLines = cleanedLines.count { it.length in 8..140 }
                val looksLikeLyrics = value.length >= 180 && cleanedLines.size >= 6 &&
                    usefulLines >= 5 && menuNoise <= 1
                result(value.trim().takeIf { looksLikeLyrics })
            }
        } catch (_: Throwable) { result(null) }
    }

    fun open(url: String, lyricsMode: Boolean = false) {
        // Lyrics and karaoke intentionally use differently configured WebViews.
        // Recreate on mode changes so LyrGig extraction and karaoke bridge can never contaminate each other.
        if (view != null && lyricsOnly != lyricsMode) {
            try { view?.stopLoading(); view?.destroy() } catch (_: Throwable) {}
            view = null
            frames.clear()
        }
        lyricsOnly = lyricsMode
        val web = view ?: create().also { view = it }
        opened = true
        message = null
        autoPlayOnReady = false
        suppressAutoPlayOnce = true
        // Lyrics browsing must never be allowed to start media from a page tap/ad.
        // Karaoke deliberately keeps its existing autoplay/control behavior.
        web.settings.mediaPlaybackRequiresUserGesture = lyricsOnly
        if (lyricsOnly) {
            // Lyrics search does not depend on the karaoke JavaScript bridge.
            // This fixes devices where WebView can browse normally but lacks one
            // of the newer bridge features. Keep this WebView muted when supported.
            mute(true)
            silenceLyricsDocument(web)
            web.loadUrl(url)
        } else if (canControl) web.loadUrl(url)
        else {
            message = "Za Web plejer ažuriraj Android System WebView u Play prodavnici."
            web.loadData("<html><body style='background:black;color:white;font:20px sans-serif'>${message}</body></html>", "text/html", "UTF-8")
        }
    }

    private fun mute(value: Boolean) { if (canMute) view?.let { WebViewCompat.setAudioMuted(it, value) } }

    private fun receive(raw: String, reply: JavaScriptReplyProxy) {
        val data = try { JSONObject(raw) } catch (_: Exception) { return }
        val id = data.optString("frame")
        if (id.isBlank()) return
        if (data.optString("type") == "hello") {
            frames[id] = Frame(reply)
            reply.postMessage(JSONObject().put("command", "init").put("epoch", epoch).toString())
            return
        }
        if (data.optInt("epoch", -1) != epoch) return
        val frame = frames[id] ?: return
        when (data.optString("type")) {
            "ready" -> {
                frame.score = data.optDouble("score", 0.0)
                if (lyricsOnly) { mute(true); return }
                if (autoPlayOnReady && frame.score > 0) {
                    autoPlayOnReady = false
                    message = null
                    local.stop()
                    local.showCdg = false
                    mute(false)
                    frame.reply.postMessage(command("play"))
                }
            }
            "playing" -> {
                if (lyricsOnly) { mute(true); reply.postMessage(command("stop")); return }
                if (!data.optBoolean("user")) {
                    reply.postMessage(command("stop"))
                    return
                }
                // Web is already decoding but remains muted until local audio is stopped.
                frame.playing = true
                confirmPlaybackStarted()
            }
            "paused" -> { frame.playing = false; isPlaying = frames.values.any { it.playing } }
            "error" -> { message = "Video nije pokrenut. Otvori video ili koristi njegovo PLAY dugme." }
        }
    }

    /** Called only after a current, user-authorized media 'playing' event. */
    internal fun confirmPlaybackStarted() {
        local.stop()
        local.showCdg = false
        isPlaying = true
        message = null
        mute(false)
    }

    private fun command(name: String) = JSONObject().put("command", name).put("epoch", epoch).toString()

    fun play() {
        val target = frames.values.filter { it.score > 0 }.maxByOrNull { it.score }
        if (target == null) message = "Prvo otvori video na stranici."
        else {
            message = null
            local.stop()
            local.showCdg = false
            mute(false)
            target.reply.postMessage(command("play"))
        }
    }

    fun togglePause() {
        if (isPlaying) pause() else play()
    }

    fun pause() {
        frames.values.forEach { if (it.playing) it.reply.postMessage(command("pause")) }
    }

    fun stop() {
        stopForLocal()
    }

    fun toggle() = togglePause()

    fun stopForLocal() {
        // Mute synchronously before starting a local player, then pause all frames.
        mute(true)
        epoch++
        frames.values.forEach { it.playing = false; it.reply.postMessage(command("stop")) }
        isPlaying = false
    }

    fun detachContext() { (view?.context as? MutableContextWrapper)?.baseContext = context }
    fun close() { stopForLocal(); view?.stopLoading(); view?.destroy(); view = null; frames.clear(); opened = false }
}
