package com.teraphonia.cdglite

import android.content.Context
import android.content.MutableContextWrapper
import android.graphics.Bitmap
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.*
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject

/** The native WebView mute is the handoff gate, including cross-origin frames. */
internal class WebAudioController(private val context: Context, private val local: PlaybackModel) {
    var isPlaying by mutableStateOf(false)
        private set
    var message by mutableStateOf<String?>(null)
        private set
    var opened by mutableStateOf(false)
        private set
    private var epoch = 0
    private var view: WebView? = null
    private var canControl = false
    private var autoPlayOnReady = false
    private var suppressAutoPlayOnce = false
    private data class Frame(val reply: JavaScriptReplyProxy, var score: Double = 0.0, var playing: Boolean = false)
    private val frames = mutableMapOf<String, Frame>()
    internal val hasPlayableMedia get() = frames.values.any { it.score > 0 }

    fun webView(uiContext: Context): WebView {
        val web = view ?: create().also { view = it }
        (web.context as MutableContextWrapper).baseContext = uiContext
        return web
    }

    private fun create(): WebView = WebView(MutableContextWrapper(context)).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false // only the controlled PLAY path is audible
        canControl = listOf(WebViewFeature.MUTE_AUDIO, WebViewFeature.DOCUMENT_START_SCRIPT, WebViewFeature.WEB_MESSAGE_LISTENER).all(WebViewFeature::isFeatureSupported)
        if (canControl) {
            WebViewCompat.setAudioMuted(this, true)
            WebViewCompat.addWebMessageListener(this, "cdgHost", setOf("*")) { _, payload, _, _, reply ->
                receive(payload.data.orEmpty(), reply)
            }
            WebViewCompat.addDocumentStartJavaScript(this, context.assets.open("web-audio.js").bufferedReader().use { it.readText() }, setOf("*"))
        }
        webViewClient = object : WebViewClient() {
            override fun onPageFinished(web: WebView, url: String) {
                // Force a high-contrast dark reading surface even on pages without their own dark theme.
                web.evaluateJavascript("""(function(){var s=document.getElementById('cdglite-dark');if(!s){s=document.createElement('style');s.id='cdglite-dark';s.textContent='html,body{background:#000!important;color:#fff!important} body *{border-color:#444!important} a{color:#8ab4f8!important} input,textarea,select,button{background:#171717!important;color:#fff!important}';document.documentElement.appendChild(s)}})()""", null)
            }
            override fun onPageStarted(web: WebView, url: String, favicon: Bitmap?) {
                epoch++
                frames.clear()
                isPlaying = false
                mute(true)
                // The initial Google results page stays silent. Any page opened from it
                // (the selected karaoke number) starts as soon as playable media appears.
                autoPlayOnReady = opened && !suppressAutoPlayOnce
                suppressAutoPlayOnce = false
            }
        }
    }

    fun extractLyrics(result: (String?) -> Unit) {
        val web = view ?: return result(null)
        val js = """(function(){
          function clean(t){return (t||'').replace(/\\u00a0/g,' ').replace(/[ \\t]+\\n/g,'\\n').replace(/\\n[ \\t]+/g,'\\n').replace(/\\n{3,}/g,'\\n\\n').trim();}
          function score(el){
            var t=clean(el.innerText); if(t.length<80) return -1;
            var lines=t.split('\\n').map(x=>x.trim()).filter(Boolean); if(lines.length<4) return -1;
            var short=lines.filter(x=>x.length>0&&x.length<100).length;
            var veryLong=lines.filter(x=>x.length>180).length;
            var nav=lines.filter(x=>/^(home|menu|login|sign in|share|comments?|privacy|cookies?|advertisement|related|about)$/i.test(x)).length;
            return short*8 + Math.min(lines.length,80)*2 - veryLong*20 - nav*25 - Math.max(0,t.length-9000)/80;
          }
          var selectors=['[data-lyrics-container=true]','.lyrics','.lyric','.lyrics__content','.song-lyrics','#lyrics','article','main'];
          var nodes=[]; selectors.forEach(s=>{try{document.querySelectorAll(s).forEach(e=>nodes.push(e))}catch(e){}});
          if(!nodes.length) document.querySelectorAll('div,section').forEach(e=>{if((e.innerText||'').split('\\n').length>=6)nodes.push(e)});
          var best=null,bestScore=-1; nodes.forEach(e=>{var x=score(e);if(x>bestScore){bestScore=x;best=e}});
          if(!best) return '';
          var t=clean(best.innerText);
          var lines=t.split('\\n').map(x=>x.trim());
          lines=lines.filter(x=>x && !/^(share|copy|embed|advertisement|read more|sign in|log in|comments?|you might also like|related songs?)$/i.test(x));
          return clean(lines.join('\\n'));
        })()"""
        web.evaluateJavascript(js) { raw ->
            if (raw == null || raw == "null" || raw == "\"\"") result(null)
            else try { result(org.json.JSONArray("[$raw]").getString(0).trim().takeIf { it.isNotBlank() }) }
            catch (_: Exception) { result(null) }
        }
    }

    fun open(url: String) {
        val web = view ?: create().also { view = it }
        opened = true
        message = null
        autoPlayOnReady = false
        suppressAutoPlayOnce = true
        if (canControl) web.loadUrl(url)
        else {
            message = "Za Web plejer ažuriraj Android System WebView u Play prodavnici."
            web.loadData("<html><body style='background:black;color:white;font:20px sans-serif'>${message}</body></html>", "text/html", "UTF-8")
        }
    }

    private fun mute(value: Boolean) { if (canControl) view?.let { WebViewCompat.setAudioMuted(it, value) } }

    private fun receive(raw: String, reply: JavaScriptReplyProxy) {
        val data = try { JSONObject(raw) } catch (_: Exception) { return }
        val id = data.optString("frame")
        if (id.isBlank()) return
        if (data.optString("type") == "hello") {
            frames[id] = Frame(reply)
            reply.postMessage(JSONObject().put("command", "init").put("epoch", epoch).toString())
            return
        }
        if (data.optInt("epoch", -1) != epoch) return
        val frame = frames[id] ?: return
        when (data.optString("type")) {
            "ready" -> {
                frame.score = data.optDouble("score", 0.0)
                if (autoPlayOnReady && frame.score > 0) {
                    autoPlayOnReady = false
                    message = null
                    local.stop()
                    local.showCdg = false
                    mute(false)
                    frame.reply.postMessage(command("play"))
                }
            }
            "playing" -> {
                if (!data.optBoolean("user")) {
                    reply.postMessage(command("stop"))
                    return
                }
                // Web is already decoding but remains muted until local audio is stopped.
                frame.playing = true
                confirmPlaybackStarted()
            }
            "paused" -> { frame.playing = false; isPlaying = frames.values.any { it.playing } }
            "error" -> { message = "Video nije pokrenut. Otvori video ili koristi njegovo PLAY dugme." }
        }
    }

    /** Called only after a current, user-authorized media 'playing' event. */
    internal fun confirmPlaybackStarted() {
        local.stop()
        local.showCdg = false
        isPlaying = true
        message = null
        mute(false)
    }

    private fun command(name: String) = JSONObject().put("command", name).put("epoch", epoch).toString()

    fun play() {
        val target = frames.values.filter { it.score > 0 }.maxByOrNull { it.score }
        if (target == null) message = "Prvo otvori video na stranici."
        else {
            message = null
            local.stop()
            local.showCdg = false
            mute(false)
            target.reply.postMessage(command("play"))
        }
    }

    fun togglePause() {
        if (isPlaying) pause() else play()
    }

    fun pause() {
        frames.values.forEach { if (it.playing) it.reply.postMessage(command("pause")) }
    }

    fun stop() {
        stopForLocal()
    }

    fun toggle() = togglePause()

    fun stopForLocal() {
        // Mute synchronously before starting a local player, then pause all frames.
        mute(true)
        epoch++
        frames.values.forEach { it.playing = false; it.reply.postMessage(command("stop")) }
        isPlaying = false
    }

    fun detachContext() { (view?.context as? MutableContextWrapper)?.baseContext = context }
    fun close() { stopForLocal(); view?.stopLoading(); view?.destroy(); view = null; frames.clear(); opened = false }
}
