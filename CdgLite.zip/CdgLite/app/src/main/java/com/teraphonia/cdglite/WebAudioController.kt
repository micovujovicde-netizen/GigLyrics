package com.teraphonia.cdglite

import android.content.Context
import android.content.MutableContextWrapper
import android.graphics.Bitmap
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.*
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject

/** The native WebView mute is the handoff gate, including cross-origin frames. */
internal enum class WebRole { KARAOKE, LYRICS }

internal class WebAudioController(
    private val context: Context,
    private val local: PlaybackModel,
    private val role: WebRole
) {
    var isPlaying by mutableStateOf(false)
        private set
    var message by mutableStateOf<String?>(null)
        private set
    var opened by mutableStateOf(false)
        private set
    private var epoch = 0
    private var view: WebView? = null
    private var canControl = false
    private var canMute = false
    private var autoPlayOnReady = false
    private var suppressAutoPlayOnce = false
    private val lyricsOnly get() = role == WebRole.LYRICS
    private data class Frame(val reply: JavaScriptReplyProxy, var score: Double = 0.0, var playing: Boolean = false)
    private val frames = mutableMapOf<String, Frame>()
    internal val hasPlayableMedia get() = frames.values.any { it.score > 0 }

    /** TUPAN never leaves the text-web for obvious video platforms. */
    private fun isBlockedLyricsDestination(url: String?): Boolean {
        if (!lyricsOnly || url.isNullOrBlank()) return false
        val host = try { Uri.parse(url).host?.lowercase().orEmpty() } catch (_: Throwable) { "" }
        if (host.isBlank()) return false
        return host == "youtu.be" ||
            host == "youtube.com" || host.endsWith(".youtube.com") ||
            host == "vimeo.com" || host.endsWith(".vimeo.com") ||
            host == "dailymotion.com" || host.endsWith(".dailymotion.com") ||
            host == "tiktok.com" || host.endsWith(".tiktok.com")
    }

    fun webView(uiContext: Context): WebView {
        val web = view ?: create().also { view = it }
        (web.context as MutableContextWrapper).baseContext = uiContext
        return web
    }

    /** Hard-silence only the Find Lyrics browsing document. Karaoke pages never receive this script. */
    private fun silenceLyricsDocument(web: WebView) {
        if (!lyricsOnly) return
        mute(true)
        val js = """(function(){try{
          if(window.__cdgLyricsSilent)return; window.__cdgLyricsSilent=true;
          function kill(e){try{e.muted=true;e.defaultMuted=true;e.volume=0;e.pause();e.setAttribute('muted','');}catch(_){} }
          function killAll(){try{document.querySelectorAll('audio,video').forEach(kill);}catch(_){} }
          try{
            var originalPlay=HTMLMediaElement.prototype.play;
            HTMLMediaElement.prototype.play=function(){kill(this);return Promise.resolve();};
          }catch(_){}
          document.addEventListener('play',function(e){if(e.target instanceof HTMLMediaElement)kill(e.target);},true);
          document.addEventListener('playing',function(e){if(e.target instanceof HTMLMediaElement)kill(e.target);},true);
          try{new MutationObserver(killAll).observe(document.documentElement||document,{childList:true,subtree:true});}catch(_){}
          killAll(); setInterval(killAll,250);
        }catch(_){}})()"""
        try { web.evaluateJavascript(js, null) } catch (_: Throwable) {}
    }

    private fun create(): WebView = WebView(MutableContextWrapper(context)).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false // only the controlled PLAY path is audible
        if (lyricsOnly) {
            // TUPAN keeps the same browser identity/session between openings.
            // In particular, a solved Google CAPTCHA may keep its cookies instead of
            // making every Find Lyrics session look like a brand-new browser.
            val cookies = CookieManager.getInstance()
            cookies.setAcceptCookie(true)
            cookies.setAcceptThirdPartyCookies(this, true)
        }
        // Audio muting and karaoke bridge support are independent capabilities.
        // Lyrics browsing must still work on WebView versions that do not support
        // the document-start/message-listener karaoke bridge.
        canMute = WebViewFeature.isFeatureSupported(WebViewFeature.MUTE_AUDIO)
        canControl = listOf(WebViewFeature.DOCUMENT_START_SCRIPT, WebViewFeature.WEB_MESSAGE_LISTENER).all(WebViewFeature::isFeatureSupported)
        if (canMute) WebViewCompat.setAudioMuted(this, true)
        if (canControl && !lyricsOnly) {
            // Karaoke bridge only. The Find Lyrics browser deliberately stays identical
            // to LyrGig's plain WebView so site DOM/extraction is not disturbed.
            WebViewCompat.addWebMessageListener(this, "cdgHost", setOf("*")) { _, payload, _, _, reply ->
                receive(payload.data.orEmpty(), reply)
            }
            WebViewCompat.addDocumentStartJavaScript(this, context.assets.open("web-audio.js").bufferedReader().use { it.readText() }, setOf("*"))
        } else if (lyricsOnly && WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            // Silence media from the first script tick without changing/blocking network requests.
            WebViewCompat.addDocumentStartJavaScript(this, """(function(){try{var p=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){try{this.muted=true;this.volume=0;this.pause();}catch(e){}return Promise.resolve();};document.addEventListener('play',function(e){try{if(e.target instanceof HTMLMediaElement){e.target.muted=true;e.target.volume=0;e.target.pause();}}catch(x){}},true);}catch(e){}})();""", setOf("*"))
        }
        webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return isBlockedLyricsDestination(request?.url?.toString())
            }

            @Suppress("DEPRECATION")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                return isBlockedLyricsDestination(url)
            }

            override fun onPageFinished(web: WebView, url: String) {
                if (lyricsOnly) {
                    // Persist cookies to disk as soon as TUPAN finishes a page/CAPTCHA.
                    try { CookieManager.getInstance().flush() } catch (_: Throwable) {}
                }
                // Force a high-contrast dark reading surface even on pages without their own dark theme.
                web.evaluateJavascript("""(function(){var s=document.getElementById('cdglite-dark');if(!s){s=document.createElement('style');s.id='cdglite-dark';s.textContent='html,body{background:#000!important;color:#fff!important} body *{border-color:#444!important} a{color:#8ab4f8!important} input,textarea,select,button{background:#171717!important;color:#fff!important}';document.documentElement.appendChild(s)}})()""", null)
                silenceLyricsDocument(web)
            }
            override fun onPageStarted(web: WebView, url: String, favicon: Bitmap?) {
                epoch++
                frames.clear()
                isPlaying = false
                mute(true)
                if (lyricsOnly) silenceLyricsDocument(web)
                // The initial Google results page stays silent. Any page opened from it
                // (the selected karaoke number) starts as soon as playable media appears.
                autoPlayOnReady = opened && !suppressAutoPlayOnce && !lyricsOnly
                suppressAutoPlayOnce = false
            }
        }
    }

    fun extractLyrics(result: (String?) -> Unit) {
        if (!lyricsOnly) return result(null)
        val web = view ?: return result(null)
        // Keep the proven normal-page extractor, but also walk open Shadow DOM and
        // same-origin frames. Google AI Mode renders parts of its answer outside the
        // ordinary body clone, which made visible AI answers look empty to EXTRACT.
        val js = """
            (function() {
              function clean(t) {
                return (t || '')
                  .replace(/\r/g, '')
                  .replace(/[ \t]+\n/g, '\n')
                  .replace(/\n[ \t]+/g, '\n')
                  .replace(/\n{3,}/g, '\n\n')
                  .trim();
              }

              function collectRoots() {
                const roots = [];
                const seen = new Set();
                function walk(root) {
                  if (!root || seen.has(root)) return;
                  seen.add(root);
                  roots.push(root);
                  let nodes = [];
                  try { nodes = root.querySelectorAll ? Array.from(root.querySelectorAll('*')) : []; } catch (_) {}
                  for (const el of nodes) {
                    try { if (el.shadowRoot) walk(el.shadowRoot); } catch (_) {}
                    try {
                      if (el.tagName === 'IFRAME' && el.contentDocument) walk(el.contentDocument);
                    } catch (_) {}
                  }
                }
                walk(document);
                return roots;
              }

              function visible(el) {
                try {
                  const st = getComputedStyle(el);
                  if (st.display === 'none' || st.visibility === 'hidden' || Number(st.opacity || 1) === 0) return false;
                  const r = el.getBoundingClientRect();
                  return r.width > 1 && r.height > 1;
                } catch (_) { return true; }
              }

              const roots = collectRoots();
              const specific = [
                '[data-lyrics-container="true"]',
                '.lyrics', '#lyrics', '.lyric', '#lyric',
                '[class*="lyrics"]', '[id*="lyrics"]'
              ];

              for (const root of roots) {
                for (const sel of specific) {
                  let nodes = [];
                  try { nodes = Array.from(root.querySelectorAll(sel)).filter(visible); } catch (_) {}
                  if (nodes.length) {
                    const t = clean(nodes.map(n => n.innerText || n.textContent || '').join('\n'));
                    if (t.length > 120) return t;
                  }
                }
              }

              let best = '';
              let bestScore = -1e9;
              const selectors = 'main,article,[role="main"],[aria-live="polite"],[aria-live="assertive"],section,div,pre';
              const seenText = new Set();

              for (const root of roots) {
                let candidates = [];
                try { candidates = Array.from(root.querySelectorAll(selectors)); } catch (_) {}
                for (const el of candidates) {
                  if (!visible(el)) continue;
                  const t = clean(el.innerText || el.textContent || '');
                  if (t.length < 120 || t.length > 30000 || seenText.has(t)) continue;
                  seenText.add(t);

                  const lines = t.split('\n').map(x => x.trim()).filter(Boolean);
                  if (lines.length < 4) continue;
                  const shortLines = lines.filter(x => x.length >= 2 && x.length <= 90).length;
                  const usefulLines = lines.filter(x => x.length >= 8 && x.length <= 140).length;
                  const veryLong = lines.filter(x => x.length > 180).length;
                  const noise = (t.match(/cookie|privacy|sign in|subscribe|advertis|menu|share|facebook|instagram/gi) || []).length;
                  let bonus = 0;
                  try {
                    const tag = (el.tagName || '').toLowerCase();
                    const role = (el.getAttribute && el.getAttribute('role')) || '';
                    const live = (el.getAttribute && el.getAttribute('aria-live')) || '';
                    if (tag === 'main' || tag === 'article') bonus += 35;
                    if (role === 'main') bonus += 35;
                    if (live) bonus += 20;
                  } catch (_) {}
                  const score = shortLines * 5 + usefulLines * 3 + lines.length * 2 - veryLong * 8 - noise * 15 + Math.min(t.length, 5000) / 200 + bonus;
                  if (score > bestScore) { bestScore = score; best = t; }
                }
              }

              // AI Mode fallback: its answer may live entirely in Shadow DOM. Build a
              // rendered-text fallback from every discovered root instead of document.body only.
              if (!best) {
                const chunks = [];
                for (const root of roots) {
                  try {
                    const host = root.host;
                    const t = clean(host ? (root.textContent || '') : ((root.body && root.body.innerText) || root.innerText || root.textContent || ''));
                    if (t.length >= 80 && !chunks.includes(t)) chunks.push(t);
                  } catch (_) {}
                }
                best = clean(chunks.join('\n'));
              }

              const allVisible = clean(roots.map(root => {
                try {
                  if (root.host) return root.textContent || '';
                  return (root.body && root.body.innerText) || root.innerText || root.textContent || '';
                } catch (_) { return ''; }
              }).join('\n'));
              const googleHost = /(^|\.)google\./i.test(location.hostname || '');
              const aiMode = googleHost && /(^|\n)AI (režim|rezim|mode)(\n|$)/i.test(allVisible);
              return (aiMode ? '__CDGLITE_GOOGLE_AI__\n' : '') + clean(best);
            })();
        """.trimIndent()
        try {
            web.evaluateJavascript(js) { raw ->
                var value = try {
                    if (raw == null || raw == "null") "" else
                        org.json.JSONTokener(raw).nextValue() as? String ?: ""
                } catch (_: Exception) { "" }

                val googleAi = value.startsWith("__CDGLITE_GOOGLE_AI__\n")
                if (googleAi) value = value.removePrefix("__CDGLITE_GOOGLE_AI__\n")

                val cleanedLines = value.lines().map { it.trim() }.filter { it.isNotBlank() }
                val menuNoise = cleanedLines.count {
                    val l = it.lowercase()
                    l == "svi tekstovi" || l.startsWith("poslušaj na") ||
                        l.startsWith("listen on") || l == "home" || l == "menu" ||
                        l == "lyrics" || l == "tekst"
                }
                val usefulLines = cleanedLines.count { it.length in 8..140 }

                // Normal pages retain the old strict filter. Google AI Mode gets a slightly
                // looser acceptance gate because its visible answer mixes lyric lines with
                // explanatory prose, while previewExtractedLyrics still validates the result.
                val looksLikeLyrics = if (googleAi) {
                    value.length >= 120 && cleanedLines.size >= 5 && usefulLines >= 4
                } else {
                    value.length >= 180 && cleanedLines.size >= 6 && usefulLines >= 5 && menuNoise <= 1
                }
                result(value.trim().takeIf { looksLikeLyrics })
            }
        } catch (_: Throwable) { result(null) }
    }

    fun open(url: String) {
        val web = view ?: create().also { view = it }
        opened = true
        message = null
        autoPlayOnReady = false
        suppressAutoPlayOnce = true
        // GLUPAN (karaoke) and TUPAN (lyrics) are separate controller instances.
        // Their role is immutable, so EXTRACT/audio state can never leak across browsers.
        web.settings.mediaPlaybackRequiresUserGesture = lyricsOnly
        if (lyricsOnly) {
            mute(true)
            silenceLyricsDocument(web)
            web.loadUrl(url)
        } else if (canControl) {
            web.loadUrl(url)
        } else {
            message = "Za Web plejer ažuriraj Android System WebView u Play prodavnici."
            web.loadData("<html><body style='background:black;color:white;font:20px sans-serif'>${message}</body></html>", "text/html", "UTF-8")
        }
    }

    /** Browser-history BACK. Returns false when there is no page to return to. */
    fun goBack(): Boolean {
        val web = view ?: return false
        return if (web.canGoBack()) {
            web.goBack()
            true
        } else false
    }

    private fun mute(value: Boolean) { if (canMute) view?.let { WebViewCompat.setAudioMuted(it, value) } }

    private fun receive(raw: String, reply: JavaScriptReplyProxy) {
        val data = try { JSONObject(raw) } catch (_: Exception) { return }
        val id = data.optString("frame")
        if (id.isBlank()) return
        if (data.optString("type") == "hello") {
            frames[id] = Frame(reply)
            reply.postMessage(JSONObject().put("command", "init").put("epoch", epoch).toString())
            return
        }
        if (data.optInt("epoch", -1) != epoch) return
        val frame = frames[id] ?: return
        when (data.optString("type")) {
            "ready" -> {
                frame.score = data.optDouble("score", 0.0)
                if (lyricsOnly) { mute(true); return }
                if (autoPlayOnReady && frame.score > 0) {
                    autoPlayOnReady = false
                    message = null
                    local.stopBreak()
                    local.stop()
                    local.showCdg = false
                    mute(false)
                    frame.reply.postMessage(command("play"))
                }
            }
            "playing" -> {
                if (lyricsOnly) { mute(true); reply.postMessage(command("stop")); return }
                if (!data.optBoolean("user")) {
                    reply.postMessage(command("stop"))
                    return
                }
                // Web is already decoding but remains muted until local audio is stopped.
                frame.playing = true
                confirmPlaybackStarted()
            }
            "paused" -> { frame.playing = false; isPlaying = frames.values.any { it.playing } }
            "error" -> { message = "Video nije pokrenut. Otvori video ili koristi njegovo PLAY dugme." }
        }
    }

    /** Called only after a current, user-authorized media 'playing' event. */
    internal fun confirmPlaybackStarted() {
        local.stopBreak()
        local.stop()
        local.showCdg = false
        isPlaying = true
        message = null
        mute(false)
    }

    private fun command(name: String) = JSONObject().put("command", name).put("epoch", epoch).toString()

    fun play() {
        val target = frames.values.filter { it.score > 0 }.maxByOrNull { it.score }
        if (target == null) message = "Prvo otvori video na stranici."
        else {
            message = null
            local.stopBreak()
            local.stop()
            local.showCdg = false
            mute(false)
            target.reply.postMessage(command("play"))
        }
    }

    fun togglePause() {
        if (isPlaying) pause() else play()
    }

    fun pause() {
        frames.values.forEach { if (it.playing) it.reply.postMessage(command("pause")) }
    }

    fun stop() {
        stopForLocal()
    }

    fun toggle() = togglePause()

    fun stopForLocal() {
        // Mute synchronously before starting a local player, then pause all frames.
        mute(true)
        epoch++
        frames.values.forEach { it.playing = false; it.reply.postMessage(command("stop")) }
        isPlaying = false
    }

    fun detachContext() { (view?.context as? MutableContextWrapper)?.baseContext = context }
    fun close() {
        if (lyricsOnly) {
            try { CookieManager.getInstance().flush() } catch (_: Throwable) {}
        }
        stopForLocal(); view?.stopLoading(); view?.destroy(); view = null; frames.clear(); opened = false
    }
}
