package com.teraphonia.cdglite

import android.content.Context
import android.content.MutableContextWrapper
import android.graphics.Bitmap
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.*
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject

/** The native WebView mute is the handoff gate, including cross-origin frames. */
internal class WebAudioController(private val context: Context, private val local: PlaybackModel) {
    var isPlaying by mutableStateOf(false)
        private set
    var message by mutableStateOf<String?>(null)
        private set
    var opened by mutableStateOf(false)
        private set
    private var epoch = 0
    private var view: WebView? = null
    private var canControl = false
    private var autoPlayOnReady = false
    private var suppressAutoPlayOnce = false
    private data class Frame(val reply: JavaScriptReplyProxy, var score: Double = 0.0, var playing: Boolean = false)
    private val frames = mutableMapOf<String, Frame>()
    internal val hasPlayableMedia get() = frames.values.any { it.score > 0 }

    fun webView(uiContext: Context): WebView {
        val web = view ?: create().also { view = it }
        (web.context as MutableContextWrapper).baseContext = uiContext
        return web
    }

    private fun create(): WebView = WebView(MutableContextWrapper(context)).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false // only the controlled PLAY path is audible
        canControl = listOf(WebViewFeature.MUTE_AUDIO, WebViewFeature.DOCUMENT_START_SCRIPT, WebViewFeature.WEB_MESSAGE_LISTENER).all(WebViewFeature::isFeatureSupported)
        if (canControl) {
            WebViewCompat.setAudioMuted(this, true)
            WebViewCompat.addWebMessageListener(this, "cdgHost", setOf("*")) { _, payload, _, _, reply ->
                receive(payload.data.orEmpty(), reply)
            }
            WebViewCompat.addDocumentStartJavaScript(this, context.assets.open("web-audio.js").bufferedReader().use { it.readText() }, setOf("*"))
        }
        webViewClient = object : WebViewClient() {
            override fun onPageStarted(web: WebView, url: String, favicon: Bitmap?) {
                epoch++
                frames.clear()
                isPlaying = false
                mute(true)
                // The initial Google results page stays silent. Any page opened from it
                // (the selected karaoke number) starts as soon as playable media appears.
                autoPlayOnReady = opened && !suppressAutoPlayOnce
                suppressAutoPlayOnce = false
            }
        }
    }

    fun open(url: String) {
        val web = view ?: create().also { view = it }
        opened = true
        message = null
        autoPlayOnReady = false
        suppressAutoPlayOnce = true
        if (canControl) web.loadUrl(url)
        else {
            message = "Za Web plejer ažuriraj Android System WebView u Play prodavnici."
            web.loadData("<html><body style='background:black;color:white;font:20px sans-serif'>${message}</body></html>", "text/html", "UTF-8")
        }
    }

    private fun mute(value: Boolean) { if (canControl) view?.let { WebViewCompat.setAudioMuted(it, value) } }

    private fun receive(raw: String, reply: JavaScriptReplyProxy) {
        val data = try { JSONObject(raw) } catch (_: Exception) { return }
        val id = data.optString("frame")
        if (id.isBlank()) return
        if (data.optString("type") == "hello") {
            frames[id] = Frame(reply)
            reply.postMessage(JSONObject().put("command", "init").put("epoch", epoch).toString())
            return
        }
        if (data.optInt("epoch", -1) != epoch) return
        val frame = frames[id] ?: return
        when (data.optString("type")) {
            "ready" -> {
                frame.score = data.optDouble("score", 0.0)
                if (autoPlayOnReady && frame.score > 0) {
                    autoPlayOnReady = false
                    message = null
                    frame.reply.postMessage(command("play"))
                }
            }
            "playing" -> {
                if (!data.optBoolean("user")) {
                    reply.postMessage(command("stop"))
                    return
                }
                // Web is already decoding but remains muted until local audio is stopped.
                frame.playing = true
                confirmPlaybackStarted()
            }
            "paused" -> { frame.playing = false; isPlaying = frames.values.any { it.playing } }
            "error" -> { message = "Video nije pokrenut. Otvori video ili koristi njegovo PLAY dugme." }
        }
    }

    /** Called only after a current, user-authorized media 'playing' event. */
    internal fun confirmPlaybackStarted() {
        local.stop()
        local.showCdg = false
        isPlaying = true
        message = null
        mute(false)
    }

    private fun command(name: String) = JSONObject().put("command", name).put("epoch", epoch).toString()

    fun play() {
        val target = frames.values.filter { it.score > 0 }.maxByOrNull { it.score }
        if (target == null) message = "Prvo otvori video na stranici."
        else { message = null; target.reply.postMessage(command("play")) }
    }

    fun togglePause() {
        if (isPlaying) pause() else play()
    }

    fun pause() {
        frames.values.forEach { if (it.playing) it.reply.postMessage(command("pause")) }
    }

    fun stop() {
        stopForLocal()
    }

    fun toggle() = togglePause()

    fun stopForLocal() {
        // Mute synchronously before starting a local player, then pause all frames.
        mute(true)
        epoch++
        frames.values.forEach { it.playing = false; it.reply.postMessage(command("stop")) }
        isPlaying = false
    }

    fun detachContext() { (view?.context as? MutableContextWrapper)?.baseContext = context }
    fun close() { stopForLocal(); view?.stopLoading(); view?.destroy(); view = null; frames.clear(); opened = false }
}
