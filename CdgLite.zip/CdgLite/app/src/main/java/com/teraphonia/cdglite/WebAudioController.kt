package com.teraphonia.cdglite

import android.content.Context
import android.content.MutableContextWrapper
import android.graphics.Bitmap
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.*
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject

/** The native WebView mute is the handoff gate, including cross-origin frames. */
internal enum class WebRole { KARAOKE, LYRICS }

internal class WebAudioController(
    private val context: Context,
    private val local: PlaybackModel,
    private val role: WebRole
) {
    var isPlaying by mutableStateOf(false)
        private set
    var message by mutableStateOf<String?>(null)
        private set
    var opened by mutableStateOf(false)
        private set
    var isYouTubeEmbed by mutableStateOf(false)
        private set
    var positionMs by mutableIntStateOf(0)
        private set
    var durationMs by mutableIntStateOf(0)
        private set
    private var epoch = 0
    private var view: WebView? = null
    private var canControl = false
    private var canMute = false
    private var autoPlayOnReady = false
    private var suppressAutoPlayOnce = false
    private var currentVideoTitle: String? = null
    private var currentYoutubeVideoId: String? = null
    private val lyricsOnly get() = role == WebRole.LYRICS
    private data class Frame(val reply: JavaScriptReplyProxy, var score: Double = 0.0, var playing: Boolean = false)
    private val frames = mutableMapOf<String, Frame>()
    internal val hasPlayableMedia get() = frames.values.any { it.score > 0 }

    /** TUPAN never leaves the text-web for obvious video platforms. */
    private fun isBlockedLyricsDestination(url: String?): Boolean {
        if (!lyricsOnly || url.isNullOrBlank()) return false
        val host = try { Uri.parse(url).host?.lowercase().orEmpty() } catch (_: Throwable) { "" }
        if (host.isBlank()) return false
        return host == "youtu.be" ||
            host == "youtube.com" || host.endsWith(".youtube.com") ||
            host == "vimeo.com" || host.endsWith(".vimeo.com") ||
            host == "dailymotion.com" || host.endsWith(".dailymotion.com") ||
            host == "tiktok.com" || host.endsWith(".tiktok.com")
    }

    fun webView(uiContext: Context): WebView {
        val web = view ?: create().also { view = it }
        (web.context as MutableContextWrapper).baseContext = uiContext
        return web
    }

    /** Load the official YouTube embed as the TOP-LEVEL WebView page.
     * This is the path that already rendered real video/ads on the target tablet.
     * Do not wrap it in a second custom iframe host: on Samsung/Android WebView that
     * produced audio with a black video surface.
     */
    private fun isYoutubePlayerHostUrl(url: String?): Boolean = false

    private fun loadYoutubeEmbedPage(web: WebView, sourceUrl: String) {
        val id = youtubeVideoId(sourceUrl) ?: return
        currentYoutubeVideoId = id
        currentVideoTitle = null
        isYouTubeEmbed = true
        autoPlayOnReady = opened
        message = null
        positionMs = 0
        durationMs = 0
        mute(true)

        val embedUrl = "https://www.youtube.com/embed/$id?autoplay=1&playsinline=1&controls=1&rel=0&cc_load_policy=0"
        // Keep the rendering path identical to the earlier build that displayed
        // real YouTube video/ads correctly on the target tablet.
        web.loadUrl(embedUrl, mapOf("Referer" to "https://com.teraphonia.cdglite"))
    }

    /** Force YouTube SPA result taps into the official embedded player.
     * YouTube search uses client-side navigation, so WebViewClient URL overrides alone
     * can miss a selected result. This capture listener runs before YouTube's SPA handler.
     */
    private fun installYouTubeEmbedTapGuard(web: WebView, pageUrl: String) {
        if (lyricsOnly || isYouTubeEmbedUrl(pageUrl)) return
        val host = try { Uri.parse(pageUrl).host?.lowercase().orEmpty() } catch (_: Throwable) { "" }
        if (!(host == "youtube.com" || host.endsWith(".youtube.com"))) return
        val js = """(function(){try{
          if(window.__cdgEmbedTapGuard)return; window.__cdgEmbedTapGuard=true;
          function videoId(raw){
            try{
              var u=new URL(raw,location.href), h=u.hostname.replace(/^www\.|^m\./,'');
              if(!(h==='youtube.com'||h.endsWith('.youtube.com')||h==='youtu.be')) return null;
              var id=null;
              if(h==='youtu.be') id=u.pathname.split('/').filter(Boolean)[0]||null;
              else if(u.pathname==='/watch') id=u.searchParams.get('v');
              else if(u.pathname.indexOf('/shorts/')===0) id=u.pathname.split('/')[2]||null;
              else if(u.pathname.indexOf('/live/')===0) id=u.pathname.split('/')[2]||null;
              return (id && /^[A-Za-z0-9_-]{6,20}$/.test(id)) ? id : null;
            }catch(_){return null;}
          }
          function intercept(ev){
            try{
              var el=ev.target;
              while(el && el!==document){
                if(el.tagName==='A' && el.href){
                  var id=videoId(el.href);
                  if(id){
                    ev.preventDefault(); ev.stopPropagation();
                    if(ev.stopImmediatePropagation) ev.stopImmediatePropagation();
                    location.href='https://www.youtube.com/watch?v='+id+'&cdg_embed=1';
                    return false;
                  }
                }
                el=el.parentElement;
              }
            }catch(_){}
          }
          document.addEventListener('click',intercept,true);
          document.addEventListener('auxclick',intercept,true);
        }catch(_){}})()"""
        try { web.evaluateJavascript(js, null) } catch (_: Throwable) {}
    }

    /** Hard-silence only the Find Lyrics browsing document. Karaoke pages never receive this script. */
    private fun silenceLyricsDocument(web: WebView) {
        if (!lyricsOnly) return
        mute(true)
        val js = """(function(){try{
          if(window.__cdgLyricsSilent)return; window.__cdgLyricsSilent=true;
          function kill(e){try{e.muted=true;e.defaultMuted=true;e.volume=0;e.pause();e.setAttribute('muted','');}catch(_){} }
          function killAll(){try{document.querySelectorAll('audio,video').forEach(kill);}catch(_){} }
          try{
            var originalPlay=HTMLMediaElement.prototype.play;
            HTMLMediaElement.prototype.play=function(){kill(this);return Promise.resolve();};
          }catch(_){}
          document.addEventListener('play',function(e){if(e.target instanceof HTMLMediaElement)kill(e.target);},true);
          document.addEventListener('playing',function(e){if(e.target instanceof HTMLMediaElement)kill(e.target);},true);
          try{new MutationObserver(killAll).observe(document.documentElement||document,{childList:true,subtree:true});}catch(_){}
          killAll(); setInterval(killAll,250);
        }catch(_){}})()"""
        try { web.evaluateJavascript(js, null) } catch (_: Throwable) {}
    }

    private fun create(): WebView = WebView(MutableContextWrapper(context)).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false // only the controlled PLAY path is audible
        // Keep the browser session/cookies available in both roles. For karaoke this is
        // required because the official YouTube player is a third-party iframe inside our
        // neutral full-frame host page. Lyrics browsing also keeps solved CAPTCHA cookies.
        val cookies = CookieManager.getInstance()
        cookies.setAcceptCookie(true)
        cookies.setAcceptThirdPartyCookies(this, true)
        // Audio muting and karaoke bridge support are independent capabilities.
        // Lyrics browsing must still work on WebView versions that do not support
        // the document-start/message-listener karaoke bridge.
        canMute = WebViewFeature.isFeatureSupported(WebViewFeature.MUTE_AUDIO)
        canControl = listOf(WebViewFeature.DOCUMENT_START_SCRIPT, WebViewFeature.WEB_MESSAGE_LISTENER).all(WebViewFeature::isFeatureSupported)
        if (canMute) WebViewCompat.setAudioMuted(this, true)
        if (canControl && !lyricsOnly) {
            // Karaoke bridge only. The Find Lyrics browser deliberately stays identical
            // to LyrGig's plain WebView so site DOM/extraction is not disturbed.
            WebViewCompat.addWebMessageListener(this, "cdgHost", setOf("*")) { _, payload, _, _, reply ->
                receive(payload.data.orEmpty(), reply)
            }
            WebViewCompat.addDocumentStartJavaScript(this, context.assets.open("web-audio.js").bufferedReader().use { it.readText() }, setOf("*"))
        } else if (lyricsOnly && WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            // Silence media from the first script tick without changing/blocking network requests.
            WebViewCompat.addDocumentStartJavaScript(this, """(function(){try{var p=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){try{this.muted=true;this.volume=0;this.pause();}catch(e){}return Promise.resolve();};document.addEventListener('play',function(e){try{if(e.target instanceof HTMLMediaElement){e.target.muted=true;e.target.volume=0;e.target.pause();}}catch(x){}},true);}catch(e){}})();""", setOf("*"))
        }
        webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString()
                if (isBlockedLyricsDestination(url)) return true
                if (!lyricsOnly && request?.isForMainFrame == true) {
                    youtubeEmbedUrl(url)?.let { embed ->
                        view?.let { loadYoutubeEmbedPage(it, embed) }
                        return true
                    }
                }
                return false
            }

            @Suppress("DEPRECATION")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                if (isBlockedLyricsDestination(url)) return true
                if (!lyricsOnly) {
                    youtubeEmbedUrl(url)?.let { embed ->
                        view?.let { loadYoutubeEmbedPage(it, embed) }
                        return true
                    }
                }
                return false
            }

            override fun doUpdateVisitedHistory(web: WebView, url: String, isReload: Boolean) {
                super.doUpdateVisitedHistory(web, url, isReload)
                if (!lyricsOnly) {
                    youtubeEmbedUrl(url)?.let { embed ->
                        // YouTube frequently changes videos with history.pushState(), which
                        // bypasses shouldOverrideUrlLoading(). Catch that SPA navigation here.
                        web.stopLoading()
                        loadYoutubeEmbedPage(web, embed)
                        return
                    }
                }
            }

            override fun onPageFinished(web: WebView, url: String) {
                if (lyricsOnly) {
                    // Persist cookies to disk as soon as TUPAN finishes a page/CAPTCHA.
                    try { CookieManager.getInstance().flush() } catch (_: Throwable) {}
                }
                // Leave the official YouTube embed DOM completely untouched. This is
                // the rendering path that already showed real video/ads on the tablet.
                if (!isYouTubeEmbedUrl(url)) {
                    web.evaluateJavascript("""(function(){var s=document.getElementById('cdglite-dark');if(!s){s=document.createElement('style');s.id='cdglite-dark';s.textContent='html,body{background:#000!important;color:#fff!important} body *{border-color:#56723a!important} a{color:#86f500!important} input,textarea,select,button{background:#171717!important;color:#fff!important}';document.documentElement.appendChild(s)}})()""", null)
                    installYouTubeEmbedTapGuard(web, url)
                }
                silenceLyricsDocument(web)
            }
            override fun onPageStarted(web: WebView, url: String, favicon: Bitmap?) {
                val startingYoutubeEmbed = !lyricsOnly && (isYoutubePlayerHostUrl(url) || isYouTubeEmbedUrl(url))
                isYouTubeEmbed = startingYoutubeEmbed
                epoch++
                frames.clear()
                isPlaying = false
                positionMs = 0
                durationMs = 0
                if (startingYoutubeEmbed) currentVideoTitle = null
                else if (!lyricsOnly) currentYoutubeVideoId = null
                mute(true)
                if (lyricsOnly) silenceLyricsDocument(web)
                // Search/results pages stay silent. The selected official YouTube embed
                // auto-starts as soon as its player bridge reports ready, so the performer
                // does not have to tap PLAY again inside the embed popup.
                autoPlayOnReady = opened && startingYoutubeEmbed
                suppressAutoPlayOnce = false
            }

            override fun onRenderProcessGone(web: WebView, detail: RenderProcessGoneDetail): Boolean {
                // Never let a failed WebView renderer hold the global playback/UI state.
                mute(true)
                epoch++
                frames.clear()
                autoPlayOnReady = false
                isPlaying = false
                isYouTubeEmbed = false
                currentYoutubeVideoId = null
                positionMs = 0
                durationMs = 0
                message = "YouTube WebView je resetovan. Otvori video ponovo."
                runCatching { web.destroy() }
                if (view === web) view = null
                return true
            }
        }
    }

    fun extractLyrics(result: (String?) -> Unit) {
        if (!lyricsOnly) return result(null)
        val web = view ?: return result(null)
        // Keep the proven normal-page extractor, but also walk open Shadow DOM and
        // same-origin frames. Google AI Mode renders parts of its answer outside the
        // ordinary body clone, which made visible AI answers look empty to EXTRACT.
        val js = """
            (function() {
              function clean(t) {
                return (t || '')
                  .replace(/\r/g, '')
                  .replace(/[ \t]+\n/g, '\n')
                  .replace(/\n[ \t]+/g, '\n')
                  .replace(/\n{3,}/g, '\n\n')
                  .trim();
              }

              function collectRoots() {
                const roots = [];
                const seen = new Set();
                function walk(root) {
                  if (!root || seen.has(root)) return;
                  seen.add(root);
                  roots.push(root);
                  let nodes = [];
                  try { nodes = root.querySelectorAll ? Array.from(root.querySelectorAll('*')) : []; } catch (_) {}
                  for (const el of nodes) {
                    try { if (el.shadowRoot) walk(el.shadowRoot); } catch (_) {}
                    try {
                      if (el.tagName === 'IFRAME' && el.contentDocument) walk(el.contentDocument);
                    } catch (_) {}
                  }
                }
                walk(document);
                return roots;
              }

              function visible(el) {
                try {
                  const st = getComputedStyle(el);
                  if (st.display === 'none' || st.visibility === 'hidden' || Number(st.opacity || 1) === 0) return false;
                  const r = el.getBoundingClientRect();
                  return r.width > 1 && r.height > 1;
                } catch (_) { return true; }
              }

              const roots = collectRoots();
              const specific = [
                '[data-lyrics-container="true"]',
                '.lyrics', '#lyrics', '.lyric', '#lyric',
                '[class*="lyrics"]', '[id*="lyrics"]'
              ];

              for (const root of roots) {
                for (const sel of specific) {
                  let nodes = [];
                  try { nodes = Array.from(root.querySelectorAll(sel)).filter(visible); } catch (_) {}
                  if (nodes.length) {
                    const t = clean(nodes.map(n => n.innerText || n.textContent || '').join('\n'));
                    if (t.length > 120) return t;
                  }
                }
              }

              let best = '';
              let bestScore = -1e9;
              const selectors = 'main,article,[role="main"],[aria-live="polite"],[aria-live="assertive"],section,div,pre';
              const seenText = new Set();

              for (const root of roots) {
                let candidates = [];
                try { candidates = Array.from(root.querySelectorAll(selectors)); } catch (_) {}
                for (const el of candidates) {
                  if (!visible(el)) continue;
                  const t = clean(el.innerText || el.textContent || '');
                  if (t.length < 120 || t.length > 30000 || seenText.has(t)) continue;
                  seenText.add(t);

                  const lines = t.split('\n').map(x => x.trim()).filter(Boolean);
                  if (lines.length < 4) continue;
                  const shortLines = lines.filter(x => x.length >= 2 && x.length <= 90).length;
                  const usefulLines = lines.filter(x => x.length >= 8 && x.length <= 140).length;
                  const veryLong = lines.filter(x => x.length > 180).length;
                  const noise = (t.match(/cookie|privacy|sign in|subscribe|advertis|menu|share|facebook|instagram/gi) || []).length;
                  let bonus = 0;
                  try {
                    const tag = (el.tagName || '').toLowerCase();
                    const role = (el.getAttribute && el.getAttribute('role')) || '';
                    const live = (el.getAttribute && el.getAttribute('aria-live')) || '';
                    if (tag === 'main' || tag === 'article') bonus += 35;
                    if (role === 'main') bonus += 35;
                    if (live) bonus += 20;
                  } catch (_) {}
                  const score = shortLines * 5 + usefulLines * 3 + lines.length * 2 - veryLong * 8 - noise * 15 + Math.min(t.length, 5000) / 200 + bonus;
                  if (score > bestScore) { bestScore = score; best = t; }
                }
              }

              // AI Mode fallback: its answer may live entirely in Shadow DOM. Build a
              // rendered-text fallback from every discovered root instead of document.body only.
              if (!best) {
                const chunks = [];
                for (const root of roots) {
                  try {
                    const host = root.host;
                    const t = clean(host ? (root.textContent || '') : ((root.body && root.body.innerText) || root.innerText || root.textContent || ''));
                    if (t.length >= 80 && !chunks.includes(t)) chunks.push(t);
                  } catch (_) {}
                }
                best = clean(chunks.join('\n'));
              }

              const allVisible = clean(roots.map(root => {
                try {
                  if (root.host) return root.textContent || '';
                  return (root.body && root.body.innerText) || root.innerText || root.textContent || '';
                } catch (_) { return ''; }
              }).join('\n'));
              const googleHost = /(^|\.)google\./i.test(location.hostname || '');
              const aiMode = googleHost && /(^|\n)AI (režim|rezim|mode)(\n|$)/i.test(allVisible);
              return (aiMode ? '__CDGLITE_GOOGLE_AI__\n' : '') + clean(best);
            })();
        """.trimIndent()
        try {
            web.evaluateJavascript(js) { raw ->
                var value = try {
                    if (raw == null || raw == "null") "" else
                        org.json.JSONTokener(raw).nextValue() as? String ?: ""
                } catch (_: Exception) { "" }

                val googleAi = value.startsWith("__CDGLITE_GOOGLE_AI__\n")
                if (googleAi) value = value.removePrefix("__CDGLITE_GOOGLE_AI__\n")

                val cleanedLines = value.lines().map { it.trim() }.filter { it.isNotBlank() }
                val menuNoise = cleanedLines.count {
                    val l = it.lowercase()
                    l == "svi tekstovi" || l.startsWith("poslušaj na") ||
                        l.startsWith("listen on") || l == "home" || l == "menu" ||
                        l == "lyrics" || l == "tekst"
                }
                val usefulLines = cleanedLines.count { it.length in 8..140 }

                // Normal pages retain the old strict filter. Google AI Mode gets a slightly
                // looser acceptance gate because its visible answer mixes lyric lines with
                // explanatory prose, while previewExtractedLyrics still validates the result.
                val looksLikeLyrics = if (googleAi) {
                    value.length >= 120 && cleanedLines.size >= 5 && usefulLines >= 4
                } else {
                    value.length >= 180 && cleanedLines.size >= 6 && usefulLines >= 5 && menuNoise <= 1
                }
                result(value.trim().takeIf { looksLikeLyrics })
            }
        } catch (_: Throwable) { result(null) }
    }

    fun currentYoutubeUrl(): String? {
        val id = currentYoutubeVideoId ?: view?.url?.let(::youtubeVideoId) ?: return null
        return "https://www.youtube.com/watch?v=$id"
    }

    fun currentYoutubeTitle(): String? = currentVideoTitle
        ?.trim()
        ?.takeIf { it.isNotBlank() }
        ?: view?.title
            ?.removeSuffix(" - YouTube")
            ?.removeSuffix(" - YouTube Music")
            ?.trim()
            ?.takeIf { it.isNotBlank() && !it.equals("YouTube", true) }

    fun open(url: String) {
        val web = view ?: create().also { view = it }
        opened = true
        message = null
        autoPlayOnReady = false
        suppressAutoPlayOnce = true
        // GLUPAN (karaoke) and TUPAN (lyrics) are separate controller instances.
        // Their role is immutable, so EXTRACT/audio state can never leak across browsers.
        web.settings.mediaPlaybackRequiresUserGesture = lyricsOnly
        if (lyricsOnly) {
            mute(true)
            silenceLyricsDocument(web)
            web.loadUrl(url)
        } else if (canControl) {
            // A saved .yt file or any direct YouTube video URL must use the same
            // full-frame iframe host as a video chosen from search. Direct /embed
            // loading caused audio-with-black-video on some Android WebViews.
            if (youtubeVideoId(url) != null) loadYoutubeEmbedPage(web, url)
            else web.loadUrl(url)
        } else {
            message = "Za Web plejer ažuriraj Android System WebView u Play prodavnici."
            web.loadData("<html><body style='background:black;color:white;font:20px sans-serif'>${message}</body></html>", "text/html", "UTF-8")
        }
    }

    /** Browser-history BACK. Returns false when there is no page to return to. */
    fun goBack(): Boolean {
        val web = view ?: return false
        return if (web.canGoBack()) {
            web.goBack()
            true
        } else false
    }

    private fun mute(value: Boolean) { if (canMute) view?.let { WebViewCompat.setAudioMuted(it, value) } }

    private fun receive(raw: String, reply: JavaScriptReplyProxy) {
        val data = try { JSONObject(raw) } catch (_: Exception) { return }
        val id = data.optString("frame")
        if (id.isBlank()) return
        if (data.optString("type") == "hello") {
            frames[id] = Frame(reply)
            reply.postMessage(JSONObject().put("command", "init").put("epoch", epoch).toString())
            return
        }
        if (data.optInt("epoch", -1) != epoch) return
        val frame = frames[id] ?: return
        when (data.optString("type")) {
            "ready" -> {
                frame.score = data.optDouble("score", 0.0)
                if (lyricsOnly) { mute(true); return }
                if (autoPlayOnReady && frame.score > 0) {
                    autoPlayOnReady = false
                    message = null
                    local.stopBreak()
                    if (local.song?.isYoutubeLink != true) local.stop()
                    local.showCdg = false
                    mute(false)
                    frame.reply.postMessage(command("play"))
                }
            }
            "playing" -> {
                if (lyricsOnly) { mute(true); reply.postMessage(command("stop")); return }
                if (!data.optBoolean("user")) {
                    reply.postMessage(command("stop"))
                    return
                }
                // Web is already decoding but remains muted until local audio is stopped.
                frame.playing = true
                confirmPlaybackStarted()
            }
            "paused" -> { frame.playing = false; isPlaying = frames.values.any { it.playing } }
            "time" -> {
                positionMs = data.optInt("position", positionMs).coerceAtLeast(0)
                durationMs = data.optInt("duration", durationMs).coerceAtLeast(0)
            }
            "meta" -> {
                currentVideoTitle = data.optString("title").trim().takeIf { it.isNotBlank() }
            }
            "autoplayBlocked" -> {
                // Keep the official player visible and usable. Autoplay may be blocked by
                // a device/WebView policy even though the video itself is healthy.
                autoPlayOnReady = false
                mute(false)
                message = "Tapni ▶ ako uređaj blokira automatski start."
            }
            "error" -> {
                frame.playing = false
                autoPlayOnReady = false
                isPlaying = frames.values.any { it.playing }
                mute(true)
                val code = data.optInt("code", 0)
                message = if (code > 0) "YouTube player error $code. Pokušaj drugi rezultat." else "YouTube player nije pokrenut. Pokušaj drugi rezultat."
            }
        }
    }

    /** Called only after a current, user-authorized media 'playing' event. */
    internal fun confirmPlaybackStarted() {
        local.stopBreak()
        if (local.song?.isYoutubeLink != true) local.stop()
        local.showCdg = false
        isPlaying = true
        message = null
        mute(false)
    }

    private fun command(name: String) = JSONObject().put("command", name).put("epoch", epoch).toString()

    fun play() {
        val target = frames.values.filter { it.score > 0 }.maxByOrNull { it.score }
        if (target == null) message = "Prvo otvori video na stranici."
        else {
            message = null
            local.stopBreak()
            if (local.song?.isYoutubeLink != true) local.stop()
            local.showCdg = false
            mute(false)
            target.reply.postMessage(command("play"))
        }
    }

    fun togglePause() {
        if (isPlaying) pause() else play()
    }

    fun pause() {
        frames.values.forEach { if (it.playing) it.reply.postMessage(command("pause")) }
    }

    fun seekTo(ms: Int) {
        val target = frames.values.filter { it.score > 0 }.maxByOrNull { it.score } ?: return
        target.reply.postMessage(JSONObject().put("command", "seek").put("epoch", epoch).put("position", ms.coerceAtLeast(0)).toString())
        positionMs = ms.coerceAtLeast(0)
    }

    fun stop() {
        stopForLocal()
    }

    fun toggle() = togglePause()

    fun stopForLocal() {
        // Mute synchronously before starting a local player, then pause all frames.
        mute(true)
        epoch++
        frames.values.forEach { it.playing = false; it.reply.postMessage(command("stop")) }
        isPlaying = false
    }

    fun detachContext() { (view?.context as? MutableContextWrapper)?.baseContext = context }
    fun close() {
        if (lyricsOnly) {
            try { CookieManager.getInstance().flush() } catch (_: Throwable) {}
        }
        stopForLocal(); view?.stopLoading(); view?.destroy(); view = null; frames.clear(); opened = false; positionMs = 0; durationMs = 0
    }
}
