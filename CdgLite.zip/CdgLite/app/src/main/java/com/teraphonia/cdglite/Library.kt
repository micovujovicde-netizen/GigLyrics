package com.teraphonia.cdglite

import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.util.Locale

internal val textExtensions = setOf("lyr", "lyr3", "srt", "txt")
// Android MediaPlayer handles the actual container/codec; list common local media extensions.
internal val mediaExtensions = setOf("mp3", "wav", "wave", "mp4", "m4v", "mov", "3gp", "3g2", "mkv", "webm", "avi", "ts", "m2ts", "mpeg", "mpg", "m4a", "aac", "flac", "ogg", "opus", "amr", "mid", "midi")
internal val videoExtensions = setOf("mp4", "m4v", "mov", "3gp", "3g2", "mkv", "webm", "avi", "ts", "m2ts", "mpeg", "mpg")
internal data class Library(val folders: List<DocumentFile>, val songs: List<Song>, val texts: List<DocumentFile>)
internal fun DocumentFile.extension() = name.orEmpty().substringAfterLast('.', "").lowercase(Locale.ROOT)

/** Iterative traversal has no recursion-depth limit and never searches only the visible folder. */
internal suspend fun scanFolder(root: DocumentFile, query: String): Library = withContext(Dispatchers.IO) {
    check(root.exists() && root.canRead())
    val recursive = query.isNotBlank()
    val pending = ArrayDeque<DocumentFile>().apply { add(root) }
    val visited = mutableSetOf<String>()
    val directories = mutableListOf<DocumentFile>()
    val tracks = mutableListOf<Song>()
    val texts = mutableListOf<DocumentFile>()
    while (pending.isNotEmpty()) {
        ensureActive()
        val dir = pending.removeFirst()
        if (!visited.add(dir.uri.toString())) continue
        val kids = dir.listFiles()
        val dirs = kids.filter { it.isDirectory }
        if (recursive) pending.addAll(dirs) else directories.addAll(dirs)
        val companions = kids.filter { it.isFile }.groupBy { it.name.orEmpty().substringBeforeLast('.').lowercase(Locale.ROOT) }
        kids.filter { it.isFile && it.extension() in mediaExtensions }.forEach { mp3 ->
            val name = mp3.name!!.substringBeforeLast('.')
            val siblings = companions[name.lowercase(Locale.ROOT)].orEmpty()
            if (name.contains(query, true)) tracks.add(Song(name, mp3,
                siblings.firstOrNull { it.extension() == "cdg" },
                siblings.sortedBy { textExtensions.indexOf(it.extension()) }.firstOrNull { it.extension() in textExtensions }))
        }
        texts.addAll(kids.filter { it.isFile && it.extension() in textExtensions && it.name.orEmpty().contains(query, true) })
    }
    Library(directories.sortedBy { it.name?.lowercase(Locale.ROOT) }, tracks.sortedBy { it.name.lowercase(Locale.ROOT) }, texts.sortedBy { it.name?.lowercase(Locale.ROOT) })
}

internal object LyricsReader {
    fun read(bytes: ByteArray, extension: String): String {
        var data = bytes
        // Lyrics3 v1/v2 containers use byte counts; parse before Unicode decoding.
        val raw = bytes.toString(Charsets.ISO_8859_1)
        val begin = raw.indexOf("LYRICSBEGIN")
        if (begin >= 0) {
            val start = begin + "LYRICSBEGIN".length
            if (raw.indexOf("LYRICS200", start) >= 0) {
                var cursor = start
                var lyrics: ByteArray? = null
                while (cursor + 8 <= raw.length) {
                    val id = raw.substring(cursor, cursor + 3)
                    val length = raw.substring(cursor + 3, cursor + 8).toIntOrNull() ?: break
                    cursor += 8
                    if (length < 0 || cursor + length > bytes.size) break
                    if (id == "LYR") { lyrics = bytes.copyOfRange(cursor, cursor + length); break }
                    cursor += length
                }
                data = lyrics ?: error("Lyrics3 fajl nema čitljivo LYR polje.")
            } else {
                val end = raw.indexOf("LYRICSEND", start)
                data = bytes.copyOfRange(start, if (end >= 0) end else bytes.size)
            }
        }
        val text = decode(data).replace("\r\n", "\n").replace('\r', '\n').trim('\uFEFF', '\u0000', ' ', '\n')
        if (extension == "txt") return text
        val lines = text.lines()
        return lines.filterIndexed { index, line ->
            extension != "srt" || (!line.contains("-->") &&
                !(line.trim().matches(Regex("\\d+")) && lines.getOrNull(index + 1)?.contains("-->") == true))
        }.map { it.replace(Regex("\\[\\d{1,3}:\\d{2}(?:[.:]\\d+)?]"), "") }.joinToString("\n").trim()
    }

    private fun decode(bytes: ByteArray): String {
        if (bytes.size >= 2 && bytes[0] == 0xff.toByte() && bytes[1] == 0xfe.toByte()) return bytes.toString(Charsets.UTF_16LE)
        if (bytes.size >= 2 && bytes[0] == 0xfe.toByte() && bytes[1] == 0xff.toByte()) return bytes.toString(Charsets.UTF_16BE)
        return try { Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString() }
        catch (_: Exception) { bytes.toString(charset("windows-1250")) }
    }
}
