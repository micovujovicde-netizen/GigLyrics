package com.teraphonia.cdglite

import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.util.Locale

internal val textExtensions = listOf("lyr", "lyr3", "lrc", "txt", "srt")
// Android MediaPlayer handles the actual container/codec; list common local media extensions.
internal val mediaExtensions = setOf("mp3", "wav", "wave", "mp4", "m4v", "mov", "3gp", "3g2", "mkv", "webm", "avi", "ts", "m2ts", "mpeg", "mpg", "m4a", "aac", "flac", "ogg", "opus", "amr", "mid", "midi")
internal val videoExtensions = setOf("mp4", "m4v", "mov", "3gp", "3g2", "mkv", "webm", "avi", "ts", "m2ts", "mpeg", "mpg")
internal data class Library(val folders: List<DocumentFile>, val songs: List<Song>, val texts: List<DocumentFile>)
internal fun DocumentFile.extension() = name.orEmpty().substringAfterLast('.', "").lowercase(Locale.ROOT)

/** Iterative traversal has no recursion-depth limit and never searches only the visible folder. */
internal suspend fun scanFolder(root: DocumentFile, query: String): Library = withContext(Dispatchers.IO) {
    check(root.exists() && root.canRead())
    val recursive = query.isNotBlank()
    val pending = ArrayDeque<DocumentFile>().apply { add(root) }
    val visited = mutableSetOf<String>()
    val directories = mutableListOf<DocumentFile>()
    val tracks = mutableListOf<Song>()
    val texts = mutableListOf<DocumentFile>()
    while (pending.isNotEmpty()) {
        ensureActive()
        val dir = pending.removeFirst()
        if (!visited.add(dir.uri.toString())) continue
        val kids = dir.listFiles()
        val dirs = kids.filter { it.isDirectory }
        if (recursive) pending.addAll(dirs) else directories.addAll(dirs)
        val companions = kids.filter { it.isFile }.groupBy { it.name.orEmpty().substringBeforeLast('.').lowercase(Locale.ROOT) }
        kids.filter { it.isFile && it.extension() in mediaExtensions }.forEach { mp3 ->
            val name = mp3.name!!.substringBeforeLast('.')
            val siblings = companions[name.lowercase(Locale.ROOT)].orEmpty()
            if (name.contains(query, true)) tracks.add(Song(name, mp3,
                siblings.firstOrNull { it.extension() == "cdg" },
                textExtensions.firstNotNullOfOrNull { wanted -> siblings.firstOrNull { it.extension() == wanted } }))
        }
        // Sidecars and other non-media files are never separate browser entries.
    }
    Library(directories.sortedBy { it.name?.lowercase(Locale.ROOT) }, tracks.sortedBy { it.name.lowercase(Locale.ROOT) }, texts.sortedBy { it.name?.lowercase(Locale.ROOT) })
}

internal object LyricsReader {
    data class TimedLine(val startMs: Int, val text: String)

    /** LRC/LYR and SRT timestamps are kept separately from the readable text. */
    fun timed(bytes: ByteArray, extension: String): List<TimedLine> {
        // Parse the original text: read() deliberately removes timestamps for display.
        val source = rawText(bytes)
        val timestamp = Regex("""(?:(\d{1,2}):)?(\d{1,3}):(\d{2})(?:[.,](\d{1,3}))?""")
        fun millis(value: String): Int? {
            val match = timestamp.matchEntire(value.trim()) ?: return null
            val hours = match.groupValues[1].toIntOrNull() ?: 0
            val minutes = match.groupValues[2].toIntOrNull()?.takeIf { it < 60 || match.groupValues[1].isEmpty() } ?: return null
            val seconds = match.groupValues[3].toIntOrNull()?.takeIf { it < 60 } ?: return null
            val fraction = match.groupValues[4].padEnd(3, '0').take(3).toIntOrNull() ?: 0
            return ((hours * 60 + minutes) * 60 + seconds) * 1000 + fraction
        }
        if (extension == "srt" || source.contains("-->")) {
            val lines = source.lines()
            return buildList {
                lines.forEachIndexed { index, line ->
                    if ("-->" !in line) return@forEachIndexed
                    val at = millis(line.substringBefore("-->")) ?: return@forEachIndexed
                    val words = lines.drop(index + 1).takeWhile { it.isNotBlank() }.joinToString("\n").trim()
                    if (words.isNotBlank()) add(TimedLine(at, words))
                }
            }.sortedBy { it.startMs }
        }
        val marker = Regex("""\[((?:\d{1,2}:)?\d{1,3}:\d{2}(?:[.,]\d{1,3})?)\]""")
        return source.lines().flatMap { line ->
            val matches = marker.findAll(line).toList()
            val words = marker.replace(line, "").trim()
            if (words.isBlank()) emptyList() else matches.mapNotNull { match ->
                millis(match.groupValues[1])?.let { TimedLine(it, words) }
            }
        }.sortedBy { it.startMs }
    }
    fun read(bytes: ByteArray, extension: String): String {
        val text = rawText(bytes)
        if (extension == "srt") {
            val captions = text.split(Regex("""\n\s*\n"""))
                .mapNotNull { block ->
                    val lines = block.lines()
                    val timing = lines.indexOfFirst { "-->" in it }
                    if (timing < 0) null else lines.drop(timing + 1).joinToString("\n").trim().takeIf { it.isNotBlank() }
                }
                .joinToString("\n\n").trim()
            return captions.ifBlank { text }
        }
        return stripInlineTimestamps(text)
    }

    private fun rawText(bytes: ByteArray): String {
        var data = bytes
        // Lyrics3 v1/v2 containers use byte counts; parse before Unicode decoding.
        val raw = bytes.toString(Charsets.ISO_8859_1)
        val begin = raw.indexOf("LYRICSBEGIN")
        if (begin >= 0) {
            val start = begin + "LYRICSBEGIN".length
            if (raw.indexOf("LYRICS200", start) >= 0) {
                var cursor = start
                var lyrics: ByteArray? = null
                while (cursor + 8 <= raw.length) {
                    val id = raw.substring(cursor, cursor + 3)
                    val length = raw.substring(cursor + 3, cursor + 8).toIntOrNull() ?: break
                    cursor += 8
                    if (length < 0 || cursor + length > bytes.size) break
                    if (id == "LYR") { lyrics = bytes.copyOfRange(cursor, cursor + length); break }
                    cursor += length
                }
                data = lyrics ?: error("Lyrics3 fajl nema čitljivo LYR polje.")
            } else {
                val end = raw.indexOf("LYRICSEND", start)
                data = bytes.copyOfRange(start, if (end >= 0) end else bytes.size)
            }
        }
        return decode(data).replace("\r\n", "\n").replace('\r', '\n').trim('\uFEFF', '\u0000', ' ', '\n')
    }

    private fun stripInlineTimestamps(text: String): String = text.lines()
        .map { it.replace(Regex("\\[(?:\\d{1,2}:)?\\d{1,3}:\\d{2}(?:[.,:]\\d{1,3})?]"), "").trimEnd() }
        .joinToString("\n").trim()

    private fun decode(bytes: ByteArray): String {
        if (bytes.size >= 2 && bytes[0] == 0xff.toByte() && bytes[1] == 0xfe.toByte()) return bytes.toString(Charsets.UTF_16LE)
        if (bytes.size >= 2 && bytes[0] == 0xfe.toByte() && bytes[1] == 0xff.toByte()) return bytes.toString(Charsets.UTF_16BE)
        return try { Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString() }
        catch (_: Exception) { bytes.toString(charset("windows-1250")) }
    }
}
