(() => {
  if (window.__cdgAudio) return;
  const id = Math.random().toString(36).slice(2);
  let epoch = -1, enabled = false, userUntil = 0, commanded = false;
  let authorized = new WeakSet();
  const media = () => Array.from(document.querySelectorAll('video,audio'));
  const send = (type, extra = {}) => cdgHost.postMessage(JSON.stringify({frame:id, epoch, type, ...extra}));
  const score = e => { const r=e.getBoundingClientRect(); return Math.max(1,r.width*r.height); };
  const candidate = () => media().sort((a,b) => score(b)-score(a))[0];
  const report = () => { const e=candidate(); send('ready',{score:e?score(e):0}); };
  const pauseAll = () => { commanded=false; userUntil=0; authorized=new WeakSet(); media().forEach(e=>e.pause()); };
  const user = () => { userUntil=Date.now()+10000; };
  document.addEventListener('pointerdown',user,true);
  document.addEventListener('keydown',user,true);
  document.addEventListener('playing',e => {
    if (!(e.target instanceof HTMLMediaElement)) return;
    const allowed=enabled && (commanded || authorized.has(e.target) || Date.now()<userUntil);
    if (!allowed) { e.target.pause(); return; }
    authorized.add(e.target);
    send('playing',{user:true});
  },true);
  const paused = () => { if (!media().some(e=>!e.paused&&!e.ended)) { commanded=false; send('paused'); } };
  document.addEventListener('pause',paused,true);
  document.addEventListener('ended',paused,true);
  cdgHost.onmessage = event => {
    let data; try { data=JSON.parse(event.data); } catch (_) { return; }
    epoch=data.epoch;
    if (data.command==='init') { enabled=true; report(); }
    if (data.command==='stop') pauseAll();
    if (data.command==='play') {
      const e=candidate();
      if (!e) { send('error'); return; }
      commanded=true;
      e.play().catch(()=>{commanded=false;send('error');});
    }
  };
  window.__cdgAudio={report};
  new MutationObserver(report).observe(document,{childList:true,subtree:true});
  document.addEventListener('loadedmetadata',report,true);
  window.addEventListener('pagehide',()=>send('paused'));
  send('hello');
})();
