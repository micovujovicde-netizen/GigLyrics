(() => {
  if (window.__cdgAudio) return;
  const id = Math.random().toString(36).slice(2);
  let epoch = -1, enabled = false, userUntil = 0, commanded = false;
  let lastTimeSent = 0;
  let authorized = new WeakSet();
  const unmuteClicked = new WeakSet();
  const media = () => Array.from(document.querySelectorAll('video,audio'));
  const send = (type, extra = {}) => cdgHost.postMessage(JSON.stringify({frame:id, epoch, type, ...extra}));
  const score = e => { const r=e.getBoundingClientRect(); return Math.max(1,r.width*r.height); };
  const candidate = () => media().sort((a,b) => score(b)-score(a))[0];
  const unmute = e => {
    if (!e) return;
    e.muted=false;
    e.defaultMuted=false;
    e.removeAttribute('muted');
    if (e.volume===0) e.volume=1;
  };
  const report = () => { const e=candidate(); send('ready',{score:e?score(e):0}); };
  const pauseAll = () => { commanded=false; userUntil=0; authorized=new WeakSet(); media().forEach(e=>e.pause()); };
  const user = () => { userUntil=Date.now()+10000; };
  document.addEventListener('pointerdown',user,true);
  document.addEventListener('keydown',user,true);
  document.addEventListener('playing',e => {
    if (!(e.target instanceof HTMLMediaElement)) return;
    const allowed=enabled && (commanded || authorized.has(e.target) || Date.now()<userUntil);
    if (!allowed) { e.target.pause(); return; }
    unmute(e.target);
    authorized.add(e.target);
    send('playing',{user:true});
  },true);
  const paused = () => { if (!media().some(e=>!e.paused&&!e.ended)) { commanded=false; send('paused'); } };
  document.addEventListener('pause',paused,true);
  document.addEventListener('ended',paused,true);
  cdgHost.onmessage = event => {
    let data; try { data=JSON.parse(event.data); } catch (_) { return; }
    epoch=data.epoch;
    if (data.command==='init') { enabled=true; report(); }
    if (data.command==='stop') pauseAll();
    if (data.command==='pause') { commanded=false; media().forEach(e=>e.pause()); }
    if (data.command==='seek') {
      const e=candidate();
      if (e && Number.isFinite(data.position)) { try { e.currentTime=Math.max(0,data.position/1000); } catch(_){} }
    }
    if (data.command==='play') {
      const e=candidate();
      if (!e) { send('error'); return; }
      commanded=true;
      unmute(e);
      e.play().catch(()=>{commanded=false;send('error');});
    }
  };
  window.__cdgAudio={report};
  // YouTube mobile may reapply its muted-autoplay setting after play() resolves.
  setInterval(() => {
    if (!enabled) return;
    const now=Date.now(), active=candidate();
    if(active && now-lastTimeSent>=200){
      lastTimeSent=now;
      const pos=Number.isFinite(active.currentTime)?Math.round(active.currentTime*1000):0;
      const dur=Number.isFinite(active.duration)?Math.round(active.duration*1000):0;
      send('time',{position:pos,duration:dur});
    }
    media().forEach(e => {
      if (!authorized.has(e) || e.paused || e.ended) return;
      unmute(e);
      document.querySelectorAll('button,[role="button"]').forEach(button => {
        const label=(button.getAttribute('aria-label')||button.textContent||'').trim();
        if (!unmuteClicked.has(button) && /tap to unmute|tap for sound|unmute|dodirnite za zvuk|додирните за звук/i.test(label)) {
          unmuteClicked.add(button);
          button.click();
        }
      });
    });
  }, 250);
  // The official YouTube embed UI is intentionally left untouched.
  new MutationObserver(report).observe(document,{childList:true,subtree:true});
  document.addEventListener('loadedmetadata',report,true);
  window.addEventListener('pagehide',()=>send('paused'));
  send('hello');
})();
