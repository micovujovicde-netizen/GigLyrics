package com.teraphonia.cdglite

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class YouTubeEmbedTest {
    @Test fun convertsWatchUrlToOfficialEmbed() {
        assertEquals(
            "https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1&playsinline=1&controls=1",
            youtubeEmbedUrl("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
        )
    }

    @Test fun convertsShortAndYoutuBeUrls() {
        assertTrue(youtubeEmbedUrl("https://youtu.be/dQw4w9WgXcQ")!!.contains("/embed/dQw4w9WgXcQ"))
        assertTrue(youtubeEmbedUrl("https://m.youtube.com/shorts/dQw4w9WgXcQ")!!.contains("/embed/dQw4w9WgXcQ"))
    }

    @Test fun leavesSearchAndEmbedPagesAlone() {
        assertNull(youtubeEmbedUrl("https://www.youtube.com/results?search_query=karaoke"))
        assertNull(youtubeEmbedUrl("https://www.youtube.com/embed/dQw4w9WgXcQ"))
        assertNull(youtubeEmbedUrl("https://example.com/watch?v=dQw4w9WgXcQ"))
    }
}
