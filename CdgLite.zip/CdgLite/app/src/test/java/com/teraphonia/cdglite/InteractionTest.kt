package com.teraphonia.cdglite

import android.graphics.Color
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.RuntimeEnvironment
import org.robolectric.shadows.ShadowMediaPlayer
import org.robolectric.shadows.ShadowLooper
import org.robolectric.Shadows
import androidx.documentfile.provider.DocumentFile
import java.io.File
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.semantics.SemanticsProperties
import kotlinx.coroutines.runBlocking

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
@OptIn(ExperimentalTestApi::class)
class InteractionTest {
    @get:Rule val compose = createComposeRule()

    @Test fun bothSearchFieldsSubmitWithImeAndPhysicalEnter() {
        var calls = 0
        compose.setContent {
            MaterialTheme {
                Column {
                    SearchRow("song", {}, "Local", "local", { calls++ }, {})
                    SearchRow("song", {}, "Web", "web", { calls++ }, {})
                }
            }
        }
        for (tag in listOf("local", "web")) {
            compose.onNodeWithTag("${tag}Search").performImeAction()
            compose.onNodeWithTag("${tag}Search").performClick().performKeyInput { pressKey(Key.Enter) }
            compose.onNodeWithTag("${tag}Submit").performClick()
        }
        compose.runOnIdle { assertEquals(6, calls) }
    }

    @Test fun panelBlocksTouchesButCloseAndResizeStillWork() {
        var backgroundTaps = 0
        var closes = 0
        var resizes = 0
        compose.setContent {
            MaterialTheme {
                Box(Modifier.size(320.dp, 500.dp)) {
                    Box(Modifier.fillMaxSize().clickable { backgroundTaps++ })
                    OverlayPanel(PopupSize.HALF, "CDG", { resizes++ }, { closes++ }) {}
                }
            }
        }
        compose.onNodeWithTag("CDGPanel").performTouchInput { click(center) }
        compose.onNodeWithTag("CDGPanel").performTouchInput { swipeUp() }
        compose.onNodeWithText("FULL").performClick()
        compose.onNodeWithTag("CDGClose").performClick()
        compose.runOnIdle {
            assertEquals(0, backgroundTaps)
            assertEquals(1, closes)
            assertEquals(1, resizes)
        }
    }

    @Test fun decoderPreservesAllFourRedBits() {
        val packet = ByteArray(24)
        packet[0] = 9
        packet[1] = 30
        packet[4] = 0x20 // palette entry 0: red=8, green=0, blue=0
        val decoder = CdgDecoder(packet)
        decoder.seekTo(4)
        assertEquals(Color.rgb(136, 0, 0), decoder.bitmapCopy().getPixel(10, 10))
        decoder.seekTo(0)
        assertEquals(Color.BLACK, decoder.bitmapCopy().getPixel(10, 10))
    }

    @Test fun homeAndCloseKeepSongWhileStopEndsPlayback() {
        val app = RuntimeEnvironment.getApplication()
        app.getSharedPreferences("cdglite", 0).edit().putString("root", "content://test/tree/music").commit()
        ShadowMediaPlayer.setMediaInfoProvider { ShadowMediaPlayer.MediaInfo(600000, 0) }
        val model = PlaybackModel(app)
        val track = Song("Test song", DocumentFile.fromFile(File(app.cacheDir, "song.mp3")), null)
        compose.setContent { CdgLite(model) }
        compose.runOnIdle { model.play(track) }
        // prepareAsync posts its callback to Android's main looper. Advancing
        // only Compose's clock does not deliver that MediaPlayer callback.
        compose.runOnIdle { ShadowLooper.idleMainLooper(); assertTrue(model.error, model.isPlaying) }
        compose.runOnIdle { model.showCdg = true }
        compose.onNodeWithTag("CDGClose").performClick()
        compose.runOnIdle {
            assertFalse(model.showCdg)
            assertTrue(model.isPlaying)
            assertEquals(track, model.song)
            model.showCdg = true
        }
        compose.onNodeWithTag("home").performClick()
        compose.runOnIdle { assertTrue(model.showCdg); assertTrue(model.isPlaying) }
        compose.onNodeWithTag("pause").performClick()
        compose.runOnIdle { assertFalse(model.isPlaying) }
        compose.onNodeWithTag("pause").performClick()
        compose.runOnIdle { assertTrue(model.isPlaying) }
        compose.onNodeWithTag("stop").performClick()
        compose.runOnIdle { assertEquals(track, model.song); assertFalse(model.isPlaying) }
    }

    @Test fun foldersBackHomeTapToggleAndTextScrollingPreservePlayback() {
        val app = RuntimeEnvironment.getApplication()
        val root = File(app.cacheDir, "ui-${System.nanoTime()}").apply { mkdirs() }
        val child = File(root, "LevelOne").apply { mkdir() }
        val deep = File(child, "LevelTwo").apply { mkdir() }
        File(root, "Root song.mp3").writeText("")
        File(deep, "Deep song.mp3").writeText("")
        val text = File(root, "Words.txt").apply { writeText((1..150).joinToString("\n") { "Line $it" }) }
        Shadows.shadowOf(app.contentResolver).registerInputStream(android.net.Uri.fromFile(text), text.inputStream())
        ShadowMediaPlayer.setMediaInfoProvider { ShadowMediaPlayer.MediaInfo(600000,0) }
        val model = PlaybackModel(app)
        compose.setContent { CdgLite(model, DocumentFile.fromFile(root)) }
        fun awaitText(value: String) = compose.waitUntil(10000) { compose.onAllNodesWithText(value).fetchSemanticsNodes().isNotEmpty() }
        awaitText("Root song")
        compose.onNodeWithText("Root song").performClick()
        compose.runOnIdle { ShadowLooper.idleMainLooper(); assertTrue(model.isPlaying) }
        // Open text independently from MP3 playback, then scroll its real Compose surface.
        compose.runOnIdle { model.openText(DocumentFile.fromFile(text)) }
        compose.waitUntil(10000) {
            compose.runOnIdle { ShadowLooper.idleMainLooper() }
            model.lyricsText != "Učitavanje…"
        }
        compose.runOnIdle { assertTrue(model.lyricsText, model.lyricsText?.contains("Line 150") == true) }
        compose.onNodeWithTag("lyricsText").performTouchInput { swipeUp() }
        compose.runOnIdle { assertTrue(model.isPlaying) }
        assertTrue(compose.onNodeWithTag("lyricsText").fetchSemanticsNode().config[SemanticsProperties.VerticalScrollAxisRange].value() > 0f)
        compose.onNodeWithTag("home").performClick()
        compose.runOnIdle { assertTrue(model.showCdg); assertTrue(model.isPlaying) }
        compose.onNodeWithTag("CDGClose").performClick()
        compose.onNodeWithText("📁  LevelOne").performClick()
        awaitText("📁  LevelTwo")
        compose.onNodeWithText("📁  LevelTwo").performClick()
        awaitText("Deep song")
        compose.onNodeWithTag("back").performClick()
        awaitText("📁  LevelTwo")
        compose.onNodeWithTag("home").performClick()
        awaitText("📁  LevelOne")
        compose.onNodeWithTag("back").assertIsNotEnabled()
        compose.runOnIdle { assertTrue(model.isPlaying) }
        compose.onAllNodesWithText("Root song").onFirst().performClick()
        compose.runOnIdle { assertFalse(model.isPlaying); assertNotNull(model.song) }
        compose.onNodeWithTag("activeTrackState", useUnmergedTree = true).assertTextEquals("■")
        compose.onAllNodesWithText("Root song").onFirst().performClick()
        compose.runOnIdle { ShadowLooper.idleMainLooper(); assertTrue(model.isPlaying) }
        compose.onNodeWithTag("activeTrackState", useUnmergedTree = true).assertTextEquals("▶")
        compose.runOnIdle { model.stop() }
    }

    @Test fun pinchPersistsAndWorksAgainAfterRecreationWithoutResizingSearch() {
        val app = RuntimeEnvironment.getApplication()
        val prefs = app.getSharedPreferences("cdglite",0)
        prefs.edit().putFloat("fontScale",1f).commit()
        val model = PlaybackModel(app)
        var generation by mutableIntStateOf(0)
        compose.setContent { key(generation) { CdgLite(model) } }
        val originalHeight = compose.onNodeWithTag("localSearch").fetchSemanticsNode().boundsInRoot.height
        fun pinch() {
            compose.onNodeWithTag("library").performTouchInput {
                down(0,center+Offset(-30f,0f)); down(1,center+Offset(30f,0f))
                moveTo(0,center+Offset(-40f,0f)); moveTo(1,center+Offset(40f,0f))
                up(0);up(1)
            }
        }
        pinch()
        var first = 0f
        compose.runOnIdle { first=prefs.getFloat("fontScale",0f);assertTrue(first>1f);generation++ }
        compose.waitForIdle()
        pinch()
        compose.runOnIdle { assertTrue(prefs.getFloat("fontScale",0f)>first) }
        assertEquals(originalHeight, compose.onNodeWithTag("localSearch").fetchSemanticsNode().boundsInRoot.height)
    }

    @Test fun audioOwnershipTransfersOnPlaybackAndPreservesActiveTrack() {
        val app = RuntimeEnvironment.getApplication()
        ShadowMediaPlayer.setMediaInfoProvider { ShadowMediaPlayer.MediaInfo(600000,0) }
        val model = PlaybackModel(app)
        val track = Song("Handoff", DocumentFile.fromFile(File(app.cacheDir,"handoff.mp3")),null)
        compose.setContent { CdgLite(model) }
        compose.runOnIdle { model.startLocal(track); ShadowLooper.idleMainLooper(); assertTrue(model.isPlaying) }
        compose.runOnIdle {
            model.web.confirmPlaybackStarted()
            assertTrue(model.web.isPlaying)
            assertFalse(model.isPlaying)
            assertEquals(track,model.song)
            model.startLocal(track)
            assertFalse(model.web.isPlaying)
            ShadowLooper.idleMainLooper()
            assertTrue(model.isPlaying)
            model.stop()
        }
    }
}
