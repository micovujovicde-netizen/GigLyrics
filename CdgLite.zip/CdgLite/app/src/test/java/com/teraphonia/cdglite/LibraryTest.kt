package com.teraphonia.cdglite

import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class LibraryTest {
    @Test fun recursiveSearchFindsDeepTracksAndTheirCompanionText() = runBlocking {
        val root = File(RuntimeEnvironment.getApplication().cacheDir, "deep-${System.nanoTime()}").apply { mkdirs() }
        var dir = root
        repeat(35) { dir = File(dir,"d$it").apply { mkdir() } }
        File(dir,"Deep Song.mp3").writeBytes(byteArrayOf())
        File(dir,"Deep Song.lyr3").writeText("hello")
        val result = scanFolder(DocumentFile.fromFile(root), "deep song")
        assertEquals(1, result.songs.size)
        assertEquals("Deep Song.lyr3",result.songs.single().text?.name)
        assertTrue(result.texts.isEmpty())
        assertTrue(scanFolder(DocumentFile.fromFile(root), "").songs.isEmpty())
    }
    @Test fun readsPlainUtf8Utf16SubtitlesAndBothLyrics3Formats() {
        assertEquals("Čuvaj me", LyricsReader.read("Čuvaj me".toByteArray(), "txt"))
        assertEquals("Život", LyricsReader.read("Život".toByteArray(Charsets.UTF_16), "txt"))
        assertEquals("Hello", LyricsReader.read("1\n00:00:01,000 --> 00:00:02,000\nHello".toByteArray(), "srt"))
        assertEquals("Hello", LyricsReader.read("[00:12]Hello".toByteArray(), "lyr"))
        assertEquals("Hello", LyricsReader.read("LYRICSBEGINHelloLYRICSEND".toByteArray(), "lyr3"))
        assertEquals("Hello", LyricsReader.read("LYRICSBEGINLYR00005Hello000024LYRICS200".toByteArray(), "lyr3"))
    }
    @Test fun scansWavAndVideoWithMatchingLyrics() = runBlocking {
        val root = File(RuntimeEnvironment.getApplication().cacheDir, "media-${System.nanoTime()}").apply { mkdirs() }
        File(root, "Stage.wav").writeBytes(byteArrayOf())
        File(root, "Stage.srt").writeText("1\n00:00:01,000 --> 00:00:02,000\nHello")
        File(root, "Clip.mp4").writeBytes(byteArrayOf())
        File(root, "Clip.lyr").writeText("[00:01]Hello")
        File(root, "Lrc Song.mp3").writeBytes(byteArrayOf())
        File(root, "Lrc Song.LRC").writeText("[00:01.50]Hello")
        File(root, "Notes.txt").writeText("No matching media")
        File(root, "Poster.cdg").writeBytes(byteArrayOf())
        val songs = scanFolder(DocumentFile.fromFile(root), "").songs
        assertEquals(3, songs.size)
        assertEquals("Stage.srt", songs.first { it.name == "Stage" }.text?.name)
        assertEquals("Clip.lyr", songs.first { it.name == "Clip" }.text?.name)
        assertEquals("Lrc Song.LRC", songs.first { it.name == "Lrc Song" }.text?.name)
        assertTrue(songs.first { it.name == "Clip" }.isVideo)
        assertTrue(scanFolder(DocumentFile.fromFile(root), "").texts.isEmpty())
        assertTrue(scanFolder(DocumentFile.fromFile(root), "notes").songs.isEmpty())
    }
    @Test fun timestampsDriveTimedLyricsAndUntimedTextStillReads() {
        val lrc = "[00:01.50]Prva linija\n[00:03.00]Druga linija".toByteArray()
        assertEquals(listOf(1500, 3000), LyricsReader.timed(lrc, "lyr").map { it.startMs })
        val srt = "1\n00:00:01,000 --> 00:00:02,000\nPrva linija\n\n2\n00:00:03,000 --> 00:00:04,000\nDruga linija".toByteArray()
        assertEquals(listOf(1000, 3000), LyricsReader.timed(srt, "srt").map { it.startMs })
        val multiline = "1\n00:00:01,000 --> 00:00:02,000\nFirst line\nSecond line".toByteArray()
        assertEquals("First line\nSecond line", LyricsReader.timed(multiline, "srt").single().text)
        assertEquals(1500, LyricsReader.timed("LYRICSBEGIN[00:01.50]HelloLYRICSEND".toByteArray(), "lyr3").single().startMs)
        assertEquals(1500, LyricsReader.timed("[00:01.50]Hello".toByteArray(), "txt").single().startMs)
        assertTrue(LyricsReader.timed("Bez vremena".toByteArray(), "txt").isEmpty())
        assertEquals(listOf(83450), LyricsReader.timed("[01:23.45]Sejdefu".toByteArray(), "lrc").map { it.startMs })
        assertEquals(listOf(83450), LyricsReader.timed("1\n00:01:23,450 --> 00:01:27,000\nSejdefu".toByteArray(), "srt").map { it.startMs })
        assertEquals("Ordinary text", LyricsReader.read("Ordinary text".toByteArray(), "srt"))
    }
    @Test fun localSearchIgnoresDiacriticsPunctuationWordOrderAndSerbianCyrillic() {
        assertTrue(localNameMatches("Dajte vina-hocu lom Haris Dzinovic", "Dajte vina hoću lom Haris Džinović"))
        assertTrue(localNameMatches("Dajte vina-hocu lom Haris Dzinovic", "Харис Џиновић дајте вина хоћу лом"))
        assertTrue(localNameMatches("Djurdjevdan Bijelo Dugme", "Đurđevdan Dugme"))
        assertTrue(localNameMatches("dijabolik-belo Aca Lukas", "Aca Lukas belo"))
        assertFalse(localNameMatches("dijabolik-belo Aca Lukas", "Haris Dzinovic"))
    }

    @Test fun localSearchUsesAncestorFolderNamesAsPartOfTheTrackName() = runBlocking {
        val root = File(RuntimeEnvironment.getApplication().cacheDir, "path-search-${System.nanoTime()}").apply { mkdirs() }
        val artist = File(root, "Haris Dzinovic").apply { mkdir() }
        val album = File(artist, "Narodna").apply { mkdir() }
        File(album, "Dajte vina hocu lom.mp3").writeBytes(byteArrayOf())
        File(album, "I tebe sam sit kafano.mp3").writeBytes(byteArrayOf())

        assertEquals(1, scanFolder(DocumentFile.fromFile(root), "Haris Džinović Dajte vina").songs.size)
        assertEquals("Dajte vina hocu lom", scanFolder(DocumentFile.fromFile(root), "Харис Џиновић дајте вина").songs.single().name)
        assertEquals(2, scanFolder(DocumentFile.fromFile(root), "Haris Dzinovic").songs.size)
        assertEquals(2, scanFolder(DocumentFile.fromFile(root), "Narodna Haris").songs.size)
    }

    @Test fun cachedLocalIndexFindsDeepTracksWithoutRescanningForEachQuery() = runBlocking {
        val root = File(RuntimeEnvironment.getApplication().cacheDir, "cached-index-${System.nanoTime()}").apply { mkdirs() }
        val artist = File(root, "Haris Dzinovic").apply { mkdir() }
        val album = File(artist, "Narodna").apply { mkdir() }
        File(album, "Dajte vina hocu lom.mp3").writeBytes(byteArrayOf())
        File(album, "Dajte vina hocu lom.LRC").writeText("[00:01]Dajte vina")
        File(album, "I tebe sam sit kafano.mp3").writeBytes(byteArrayOf())

        val index = buildLocalSearchIndex(DocumentFile.fromFile(root))
        assertEquals(2, index.size)
        val result = searchLocalIndex(index, "Харис Џиновић дајте вина")
        assertEquals(1, result.size)
        assertEquals("Dajte vina hocu lom", result.single().name)
        assertEquals("Dajte vina hocu lom.LRC", result.single().text?.name)
        assertEquals(2, searchLocalIndex(index, "Haris Dzinovic").size)
    }

    @Test fun youtubeLinkFilesBehaveLikeVirtualSongsWithLyricsSidecars() = runBlocking {
        val root = File(RuntimeEnvironment.getApplication().cacheDir, "yt-${System.nanoTime()}").apply { mkdirs() }
        File(root, "Cesarica.yt").writeText("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
        File(root, "Cesarica.txt").writeText("[00:01.00]Cesarica")
        val song = scanFolder(DocumentFile.fromFile(root), "").songs.single()
        assertEquals("Cesarica", song.name)
        assertTrue(song.isYoutubeLink)
        assertEquals("Cesarica.txt", song.text?.name)
    }

}
