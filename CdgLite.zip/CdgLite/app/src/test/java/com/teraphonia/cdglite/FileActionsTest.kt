package com.teraphonia.cdglite

import androidx.documentfile.provider.DocumentFile
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.nio.file.Files

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class FileActionsTest {
    @Test fun renamePreservesMatchingLyricsAndCdg() {
        val dir = Files.createTempDirectory("rename-sidecars").toFile()
        try {
            val media = dir.resolve("Old.mp3").apply { writeText("audio") }
            dir.resolve("Old.lrc").writeText("lyrics")
            dir.resolve("Old.cdg").writeText("graphics")
            val parent = DocumentFile.fromFile(dir)
            val song = Song("Old", DocumentFile.fromFile(media), null, folder = parent)
            assertNull(renameMediaWithSidecars(song, "New.mp3"))
            assertEquals("audio", dir.resolve("New.mp3").readText())
            assertEquals("lyrics", dir.resolve("New.lrc").readText())
            assertEquals("graphics", dir.resolve("New.cdg").readText())
            assertFalse(dir.resolve("Old.mp3").exists())
        } finally { dir.deleteRecursively() }
    }

    @Test fun collisionDoesNotRenameOrOverwriteAnything() {
        val dir = Files.createTempDirectory("rename-collision").toFile()
        try {
            val media = dir.resolve("Old.mp3").apply { writeText("audio") }
            dir.resolve("Old.lrc").writeText("original lyrics")
            dir.resolve("New.lrc").writeText("existing lyrics")
            val song = Song("Old", DocumentFile.fromFile(media), null, folder = DocumentFile.fromFile(dir))
            assertNotNull(renameMediaWithSidecars(song, "New.mp3"))
            assertTrue(media.exists())
            assertFalse(dir.resolve("New.mp3").exists())
            assertEquals("original lyrics", dir.resolve("Old.lrc").readText())
            assertEquals("existing lyrics", dir.resolve("New.lrc").readText())
        } finally { dir.deleteRecursively() }
    }
}
