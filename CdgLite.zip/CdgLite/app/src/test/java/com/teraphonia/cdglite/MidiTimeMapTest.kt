package com.teraphonia.cdglite

import org.junit.Assert.assertEquals
import org.junit.Test

class MidiTimeMapTest {
    @Test
    fun mapsTicksAndMillisecondsAcrossTempoChanges() {
        val track = byteArrayOf(
            0, 0xFF.toByte(), 0x51, 0x03, 0x07, 0xA1.toByte(), 0x20, // 500,000 us/qn
            0, 0x90.toByte(), 60, 100,
            0x60, 0x80.toByte(), 60, 0, // tick 96 => 500 ms
            0, 0xFF.toByte(), 0x51, 0x03, 0x0F, 0x42, 0x40, // 1,000,000 us/qn
            0x60, 0x90.toByte(), 62, 100, // tick 192 => 1500 ms
            0, 0xFF.toByte(), 0x2F, 0
        )
        val bytes = byteArrayOf(
            0x4D, 0x54, 0x68, 0x64, 0, 0, 0, 6, 0, 0, 0, 1, 0, 96,
            0x4D, 0x54, 0x72, 0x6B, 0, 0, 0, track.size.toByte()
        ) + track

        val map = MidiTimeMap.parse(bytes)
        assertEquals(500, map.tickToMs(96))
        assertEquals(1500, map.tickToMs(192))
        assertEquals(96L, map.msToTick(500))
        assertEquals(192L, map.msToTick(1500))
    }
}
