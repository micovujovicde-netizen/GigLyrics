package com.teraphonia.cdglite

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class MidiTransposeTest {
    @Test
    fun transposesMelodyButLeavesDrumsAndKarTextUntouched() {
        // One SMF track: melody note, running-status melody note, GM drums, KAR-style text, EOT.
        val track = byteArrayOf(
            0, 0x90.toByte(), 0x3C, 0x64,
            0x10, 0x3E, 0x64,
            0, 0x99.toByte(), 0x24, 0x64,
            0, 0xFF.toByte(), 0x01, 0x04, 'T'.code.toByte(), 'E'.code.toByte(), 'X'.code.toByte(), 'T'.code.toByte(),
            0x60, 0x80.toByte(), 0x3C, 0,
            0, 0x89.toByte(), 0x24, 0,
            0, 0xFF.toByte(), 0x2F, 0
        )
        val bytes = byteArrayOf(
            0x4D, 0x54, 0x68, 0x64, 0, 0, 0, 6, 0, 0, 0, 1, 0, 96,
            0x4D, 0x54, 0x72, 0x6B,
            0, 0, 0, track.size.toByte()
        ) + track

        val out = MidiTranspose.transpose(bytes, 2)
        val base = 22
        assertEquals(0x3E, out[base + 2].toInt() and 0xFF)
        assertEquals(0x40, out[base + 5].toInt() and 0xFF) // running status
        assertEquals(0x24, out[base + 9].toInt() and 0xFF) // channel 10 percussion
        assertEquals(0x3E, out[base + 21].toInt() and 0xFF)
        assertEquals(0x24, out[base + 25].toInt() and 0xFF)
        assertArrayEquals("TEXT".toByteArray(), out.copyOfRange(base + 15, base + 19))
    }
}
