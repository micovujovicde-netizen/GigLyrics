package com.teraphonia.cdglite

import android.app.Application
import android.media.AudioManager
import android.util.Base64
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.documentfile.provider.DocumentFile
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

@RunWith(AndroidJUnit4::class)
class DevicePlaybackTest {
    @get:Rule val compose = createComposeRule()
    @Test fun realWebViewAndMediaPlayerHandOffOnlyOnActualPlay() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val root = File(app.cacheDir,"device-fixtures").apply { mkdirs() }
        val wav = wave()
        val file = File(root,"Local test.mp3").apply { writeBytes(wav) }
        val model = PlaybackModel(app)
        compose.setContent { CdgLite(model, DocumentFile.fromFile(root)) }
        compose.waitUntil(15000) { compose.onAllNodesWithText("Local test").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("Local test").performClick()
        compose.waitUntil(15000) { model.isPlaying }
        compose.runOnIdle {
            model.web.open("about:blank")
            assertNull("WebView must support controlled playback",model.web.message)
            val html = "<html><body style='margin:0;background:#ddd'><audio style='width:300px;height:90px' controls loop src='data:audio/wav;base64,${Base64.encodeToString(wav,Base64.NO_WRAP)}'></audio></body></html>"
            model.web.webView(app).loadDataWithBaseURL("https://cdglite.test/",html,"text/html","UTF-8",null)
        }
        compose.onNodeWithTag("showWeb").performClick()
        compose.waitUntil(20000) { model.web.hasPlayableMedia }
        compose.runOnIdle { assertTrue("Opening Web must preserve local audio",model.isPlaying) }
        compose.onNodeWithTag("webPlayStop").performClick()
        compose.waitUntil(15000) { model.web.isPlaying && !model.isPlaying }
        compose.onNodeWithTag("webPlayStop").assertTextEquals("■ STOP")
        compose.onNodeWithTag("home").performClick()
        compose.runOnIdle { assertTrue("HOME must preserve real Web audio", model.web.isPlaying) }
        val audio = app.getSystemService(AudioManager::class.java)
        val before=audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        compose.onNodeWithTag("mainVolume").performTouchInput { click(androidx.compose.ui.geometry.Offset(0f,center.y)) }
        compose.runOnIdle { assertEquals(0,audio.getStreamVolume(AudioManager.STREAM_MUSIC)) }
        compose.onAllNodesWithText("Local test").onFirst().performClick()
        compose.waitUntil(15000) { model.isPlaying && !model.web.isPlaying }
        compose.runOnIdle { model.stop();model.web.close();audio.setStreamVolume(AudioManager.STREAM_MUSIC,before,0) }
    }
    private fun wave(): ByteArray {
        val samples=8000*120
        val b=ByteBuffer.allocate(44+samples*2).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()).putInt(36+samples*2).put("WAVEfmt ".toByteArray()).putInt(16)
        b.putShort(1).putShort(1).putInt(8000).putInt(16000).putShort(2).putShort(16)
        b.put("data".toByteArray()).putInt(samples*2)
        repeat(samples) { b.putShort((kotlin.math.sin(it*2*Math.PI*440/8000)*1000).toInt().toShort()) }
        return b.array()
    }
}
