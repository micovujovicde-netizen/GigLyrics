# Finalna provjera — CANON build 3

Rezultat: BUILD SUCCESSFUL. APK: CdgLite 1.1, versionCode 3, minSdk 26, targetSdk 35.
Potpis provjeren pomoću apksigner; jednak prethodno isporučenom CdgLite 1.1 APK-u.

## Izvršeno i prošlo

- 9 automatskih testova, 0 grešaka i 0 neuspjeha.
- Stvarne Compose UI površine pod Robolectricom: Enter/IME/GO, blokiranje dodira i prevlačenja kroz popup, X i promjena veličine, HOME/Back, čuvanje reprodukcije, MP3 PLAY/STOP indikator, tekstualno skrolovanje uz muziku, pinch i njegova postojanost poslije rekreiranja ekrana.
- Integracija stanja lokalnog i Web kontrolera: Web preuzima aktivni izvor tek na potvrđeni playback događaj; lokalni početak ponovo preuzima izvor i zaustavlja Web stanje. Lokalni MediaPlayer u ovoj provjeri je simuliran.
- Pretraga kroz 35 nivoa podfoldera; povezivanje pratećeg teksta; TXT UTF-8/UTF-16, LYR, SRT, Lyrics3 v1/v2; CDG paleta.
- Stvarni Chromium i HTML audio, bez lažnih play događaja: sprečavanje neodobrenog autoplay-a, PLAY/STOP, cross-origin iframe i identifikacija aktuelnog ciklusa događaja. Skripta verification/test_web.py koristi isti web-audio.js kao APK.
- Sastavljeni su glavni APK i Android instrumentation test APK.

## Granice provjere

Android emulator se u ovom Windows okruženju gasi prije podizanja sistema, i sa 64-bitnom i sa 32-bitnom slikom bez hardverskog ubrzanja. Zbog toga DevicePlaybackTest nije izvršen na Android uređaju. Stvarna kombinacija MediaPlayer + Android WebView i reprodukcija na javnom YouTube sajtu još zahtijevaju probu na uređaju; Chromium fixture test nije zamjena za tu provjeru. Mic callback automatski poziva istu Search radnju, ali stvarni govorni servis nije testiran.

Nije predstavljeno kao završena provjera fizičkog telefona. Izvorni projekat sadrži DevicePlaybackTest za tu provjeru i CANON.md sa zahtjevima.
