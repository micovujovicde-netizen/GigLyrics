package com.teraphonia.cdglite

import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.util.Locale
import java.text.Normalizer

internal val textExtensions = listOf("lrc", "lyr3", "lyr", "srt", "txt")
// Android MediaPlayer handles the actual container/codec; list common local media extensions.
internal val mediaExtensions = setOf("mp3", "wav", "wave", "mp4", "m4v", "mov", "3gp", "3g2", "mkv", "webm", "avi", "ts", "m2ts", "mpeg", "mpg", "m4a", "aac", "flac", "ogg", "opus", "amr", "mid", "midi", "kar", "yt")
internal val videoExtensions = setOf("mp4", "m4v", "mov", "3gp", "3g2", "mkv", "webm", "avi", "ts", "m2ts", "mpeg", "mpg")
internal data class Library(val folders: List<DocumentFile>, val songs: List<Song>, val texts: List<DocumentFile>)

/** One cached deep-search entry. The UI keeps this index for the selected library root so
 * typing another query never walks the whole SAF tree again. */
internal data class LocalSearchEntry(val searchableName: String, val song: Song)
internal fun DocumentFile.extension() = name.orEmpty().substringAfterLast('.', "").lowercase(Locale.ROOT)

/** SAF getters each query the provider: sample them once per directory listing. */
private data class FolderEntry(val file: DocumentFile, val name: String, val directory: Boolean, val regularFile: Boolean) {
    val extension = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
    val base = name.substringBeforeLast('.')
}
private fun folderEntries(files: Array<DocumentFile>) = files.map { file ->
    val name = file.name.orEmpty()
    val directory = file.isDirectory
    FolderEntry(file, name, directory, !directory && file.isFile)
}


/**
 * Local search is intentionally folder/file-name-only, but tolerant of the way singers type
 * or dictate names on stage: punctuation/spacing, Serbian/Montenegrin diacritics,
 * Latin/Cyrillic script and word order must not make an existing track disappear.
 */
internal fun normalizeLocalSearch(value: String): String {
    val transliterated = buildString(value.length) {
        value.lowercase(Locale.ROOT).forEach { ch ->
            when (ch) {
                'đ', 'ђ' -> append("dj")
                'љ' -> append("lj")
                'њ' -> append("nj")
                'џ' -> append("dz")
                'а' -> append('a'); 'б' -> append('b'); 'в' -> append('v'); 'г' -> append('g')
                'д' -> append('d'); 'е' -> append('e'); 'ж' -> append('z'); 'з' -> append('z')
                'и' -> append('i'); 'ј' -> append('j'); 'к' -> append('k'); 'л' -> append('l')
                'м' -> append('m'); 'н' -> append('n'); 'о' -> append('o'); 'п' -> append('p')
                'р' -> append('r'); 'с' -> append('s'); 'т' -> append('t'); 'ћ' -> append('c')
                'у' -> append('u'); 'ф' -> append('f'); 'х' -> append('h'); 'ц' -> append('c')
                'ч' -> append('c'); 'ш' -> append('s')
                else -> append(ch)
            }
        }
    }
    return Normalizer.normalize(transliterated, Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()
        .replace(Regex("\\s+"), " ")
}

internal fun localNameMatches(name: String, query: String): Boolean {
    val wanted = normalizeLocalSearch(query)
    if (wanted.isBlank()) return true
    val candidate = normalizeLocalSearch(name)
    return wanted.split(' ').filter { it.isNotBlank() }.all { token -> candidate.contains(token) }
}

/** Iterative traversal has no recursion-depth limit and never searches only the visible folder. */
internal suspend fun scanFolder(root: DocumentFile, query: String): Library = withContext(Dispatchers.IO) {
    check(root.exists() && root.canRead())
    val recursive = query.isNotBlank()

    // Removable SD-card providers sometimes answer one SAF query with an empty list or
    // transient exception while the card is waking up. Retry the visible/root directory
    // briefly before accepting "empty" so the browser does not flicker to zero files.
    suspend fun rootChildrenWithRetry(dir: DocumentFile): Array<DocumentFile> {
        var last: Array<DocumentFile> = emptyArray()
        var lastFailure: Throwable? = null
        repeat(4) { attempt ->
            ensureActive()
            try {
                last = dir.listFiles()
                if (last.isNotEmpty()) return last
                lastFailure = null
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (t: Exception) {
                lastFailure = t
            }
            if (attempt < 3) delay(140L)
        }
        if (lastFailure != null || !dir.exists() || !dir.canRead()) {
            throw IllegalStateException("Folder temporarily unavailable", lastFailure)
        }
        return last // genuinely empty folder after four stable reads
    }
    data class PendingDir(val dir: DocumentFile, val relativePath: List<String>)
    val pending = ArrayDeque<PendingDir>().apply { add(PendingDir(root, emptyList())) }
    val visited = mutableSetOf<String>()
    val directories = mutableListOf<DocumentFile>()
    val tracks = mutableListOf<Song>()
    val texts = mutableListOf<DocumentFile>()
    while (pending.isNotEmpty()) {
        ensureActive()
        val current = pending.removeFirst()
        val dir = current.dir
        if (!visited.add(dir.uri.toString())) continue
        val kids = if (current.relativePath.isEmpty()) {
            rootChildrenWithRetry(dir)
        } else {
            try { dir.listFiles() } catch (_: Exception) { emptyArray() }
        }
        val entries = folderEntries(kids)
        val dirs = entries.filter { it.directory }
        if (recursive) {
            dirs.forEach { child ->
                pending.add(PendingDir(child.file, current.relativePath + child.name))
            }
        } else directories.addAll(dirs.map { it.file })
        val companions = entries.filter { it.regularFile }.groupBy { it.base.lowercase(Locale.ROOT) }
        entries.filter { it.regularFile && it.extension in mediaExtensions }.forEach { entry ->
            val mp3 = entry.file
            val name = entry.base
            val siblings = companions[name.lowercase(Locale.ROOT)].orEmpty()
            // Search the complete logical name, not only the bare media filename.
            // Many gig libraries are arranged as Artist/Album/Song.mp3, so a query
            // such as "Haris Dzinovic Dajte vina" must match even when "Haris
            // Dzinovic" exists only in an ancestor folder name.
            val searchableName = (current.relativePath + name).joinToString(" ")
            if (localNameMatches(searchableName, query)) tracks.add(Song(name, mp3,
                siblings.firstOrNull { it.extension == "cdg" }?.file,
                textExtensions.firstNotNullOfOrNull { wanted -> siblings.firstOrNull { it.extension == wanted }?.file },
                dir))
        }
        // Sidecars and other non-media files are never separate browser entries.
    }
    Library(directories.sortedBy { it.name?.lowercase(Locale.ROOT) }, tracks.sortedBy { it.name.lowercase(Locale.ROOT) }, texts.sortedBy { it.name?.lowercase(Locale.ROOT) })
}

/**
 * Build the deep local-search index once per selected library root. Normal folder browsing
 * still uses scanFolder(..., "") and remains unchanged. Search itself becomes an in-memory
 * filter, which avoids the endless-looking progress bar caused by a full SAF traversal for
 * every Enter/voice query.
 */
internal suspend fun buildLocalSearchIndex(root: DocumentFile): List<LocalSearchEntry> = withContext(Dispatchers.IO) {
    check(root.exists() && root.canRead())
    suspend fun indexRootChildrenWithRetry(dir: DocumentFile): Array<DocumentFile> {
        var last: Array<DocumentFile> = emptyArray()
        var failure: Throwable? = null
        repeat(3) { attempt ->
            ensureActive()
            try {
                last = dir.listFiles()
                if (last.isNotEmpty()) return last
                failure = null
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (t: Exception) { failure = t }
            if (attempt < 2) delay(160L)
        }
        if (failure != null || !dir.exists() || !dir.canRead()) throw IllegalStateException("Search root temporarily unavailable", failure)
        return last
    }
    data class PendingDir(val dir: DocumentFile, val relativePath: List<String>)
    val pending = ArrayDeque<PendingDir>().apply { add(PendingDir(root, emptyList())) }
    val visited = mutableSetOf<String>()
    val entries = mutableListOf<LocalSearchEntry>()

    while (pending.isNotEmpty()) {
        ensureActive()
        val current = pending.removeFirst()
        val dir = current.dir
        if (!visited.add(dir.uri.toString())) continue
        val kids = if (current.relativePath.isEmpty()) {
            indexRootChildrenWithRetry(dir)
        } else {
            try { dir.listFiles() } catch (_: Exception) { emptyArray() }
        }
        val children = folderEntries(kids)
        children.filter { it.directory }.forEach { child ->
            pending.add(PendingDir(child.file, current.relativePath + child.name))
        }
        val companions = children.filter { it.regularFile }
            .groupBy { it.base.lowercase(Locale.ROOT) }
        children.filter { it.regularFile && it.extension in mediaExtensions }.forEach { entry ->
            val media = entry.file
            val name = entry.base
            val siblings = companions[name.lowercase(Locale.ROOT)].orEmpty()
            entries.add(
                LocalSearchEntry(
                    searchableName = (current.relativePath + name).joinToString(" "),
                    song = Song(
                        name, media,
                        siblings.firstOrNull { it.extension == "cdg" }?.file,
                        textExtensions.firstNotNullOfOrNull { wanted -> siblings.firstOrNull { it.extension == wanted }?.file },
                        dir
                    )
                )
            )
        }
    }
    entries.sortedBy { it.song.name.lowercase(Locale.ROOT) }
}

internal fun searchLocalIndex(index: List<LocalSearchEntry>, query: String): List<Song> =
    index.asSequence()
        .filter { localNameMatches(it.searchableName, query) }
        .map { it.song }
        .toList()

internal object LyricsReader {
    data class TimedLine(val startMs: Int, val text: String)

    /** LRC/LYR and SRT timestamps are kept separately from the readable text. */
    fun timed(bytes: ByteArray, extension: String): List<TimedLine> {
        // Parse the original text: read() deliberately removes timestamps for display.
        val source = rawText(bytes)
        val timestamp = Regex("""(?:(\d{1,2}):)?(\d{1,3}):(\d{2})(?:[.,](\d{1,3}))?""")
        fun millis(value: String): Int? {
            val match = timestamp.matchEntire(value.trim()) ?: return null
            val hours = match.groupValues[1].toIntOrNull() ?: 0
            val minutes = match.groupValues[2].toIntOrNull()?.takeIf { it < 60 || match.groupValues[1].isEmpty() } ?: return null
            val seconds = match.groupValues[3].toIntOrNull()?.takeIf { it < 60 } ?: return null
            val fraction = match.groupValues[4].padEnd(3, '0').take(3).toIntOrNull() ?: 0
            return ((hours * 60 + minutes) * 60 + seconds) * 1000 + fraction
        }
        if (extension == "srt" || source.contains("-->")) {
            val lines = source.lines()
            return buildList {
                lines.forEachIndexed { index, line ->
                    if ("-->" !in line) return@forEachIndexed
                    val at = millis(line.substringBefore("-->")) ?: return@forEachIndexed
                    val words = lines.drop(index + 1).takeWhile { it.isNotBlank() }.joinToString("\n").trim()
                    if (words.isNotBlank()) add(TimedLine(at, words))
                }
            }.sortedBy { it.startMs }
        }
        val marker = Regex("""\[((?:\d{1,2}:)?\d{1,3}:\d{2}(?:[.,]\d{1,3})?)\]""")
        return source.lines().flatMap { line ->
            val matches = marker.findAll(line).toList()
            val words = marker.replace(line, "").trim()
            if (words.isBlank()) emptyList() else matches.mapNotNull { match ->
                millis(match.groupValues[1])?.let { TimedLine(it, words) }
            }
        }.sortedBy { it.startMs }
    }
    fun read(bytes: ByteArray, extension: String): String {
        val text = rawText(bytes)
        if (extension == "srt") {
            val captions = text.split(Regex("""\n\s*\n"""))
                .mapNotNull { block ->
                    val lines = block.lines()
                    val timing = lines.indexOfFirst { "-->" in it }
                    if (timing < 0) null else lines.drop(timing + 1).joinToString("\n").trim().takeIf { it.isNotBlank() }
                }
                .joinToString("\n\n").trim()
            return captions.ifBlank { text }
        }
        return stripInlineTimestamps(text)
    }

    /** Decode text for TEXT EDIT without stripping LRC/SRT markup. For Lyrics3 containers,
     * expose only the actual lyric payload rather than the container bookkeeping. */
    fun editableSource(bytes: ByteArray, extension: String): String {
        val decoded = if (extension == "lyr3") rawText(bytes) else decode(bytes)
        return decoded.replace("\r\n", "\n")
            .replace('\r', '\n')
            .removePrefix("\uFEFF")
            .trimEnd('\u0000')
    }

    /** Preserve the source encoding. Lyrics3 v1/v2 containers keep their wrapper and lengths;
     * only the lyric payload is replaced. */
    fun encodeEditedLike(original: ByteArray, text: String, extension: String): ByteArray {
        val normalized = text.replace("\r\n", "\n").replace('\r', '\n')

        fun encodeLike(sample: ByteArray, value: String): ByteArray = when {
            sample.size >= 2 && sample[0] == 0xff.toByte() && sample[1] == 0xfe.toByte() ->
                byteArrayOf(0xff.toByte(), 0xfe.toByte()) + value.toByteArray(Charsets.UTF_16LE)
            sample.size >= 2 && sample[0] == 0xfe.toByte() && sample[1] == 0xff.toByte() ->
                byteArrayOf(0xfe.toByte(), 0xff.toByte()) + value.toByteArray(Charsets.UTF_16BE)
            runCatching { Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(sample)); true }.getOrDefault(false) ->
                value.toByteArray(Charsets.UTF_8)
            else -> value.toByteArray(charset("windows-1250"))
        }

        if (extension != "lyr3") return encodeLike(original, normalized)
        val iso = original.toString(Charsets.ISO_8859_1)
        val begin = iso.indexOf("LYRICSBEGIN")
        if (begin < 0) return encodeLike(original, normalized)
        val payloadStart = begin + "LYRICSBEGIN".length

        val v2End = iso.lastIndexOf("LYRICS200")
        if (v2End > payloadStart && v2End >= 6) {
            val footerSizePos = v2End - 6
            val oldFooterSize = iso.substring(footerSizePos, v2End).toIntOrNull()
            var cursor = payloadStart
            while (cursor + 8 <= footerSizePos) {
                val id = iso.substring(cursor, cursor + 3)
                val length = iso.substring(cursor + 3, cursor + 8).toIntOrNull() ?: break
                val dataStart = cursor + 8
                val dataEnd = dataStart + length
                if (length < 0 || dataEnd > footerSizePos) break
                if (id == "LYR") {
                    val oldPayload = original.copyOfRange(dataStart, dataEnd)
                    val replacement = encodeLike(oldPayload, normalized)
                    if (replacement.size > 99999) return original
                    val fieldHeader = "LYR%05d".format(java.util.Locale.ROOT, replacement.size).toByteArray(Charsets.US_ASCII)
                    var rebuilt = original.copyOfRange(0, cursor) + fieldHeader + replacement + original.copyOfRange(dataEnd, original.size)
                    if (oldFooterSize != null) {
                        val delta = replacement.size - oldPayload.size
                        val rebuiltIso = rebuilt.toString(Charsets.ISO_8859_1)
                        val rebuiltEnd = rebuiltIso.lastIndexOf("LYRICS200")
                        val rebuiltSizePos = rebuiltEnd - 6
                        val newFooter = (oldFooterSize + delta).coerceAtLeast(0).toString().padStart(6, '0').takeLast(6).toByteArray(Charsets.US_ASCII)
                        rebuilt = rebuilt.copyOfRange(0, rebuiltSizePos) + newFooter + rebuilt.copyOfRange(rebuiltEnd, rebuilt.size)
                    }
                    return rebuilt
                }
                cursor = dataEnd
            }
            return original
        }

        val v1End = iso.indexOf("LYRICSEND", payloadStart)
        if (v1End >= payloadStart) {
            val oldPayload = original.copyOfRange(payloadStart, v1End)
            val replacement = encodeLike(oldPayload, normalized)
            return original.copyOfRange(0, payloadStart) + replacement + original.copyOfRange(v1End, original.size)
        }
        return encodeLike(original, normalized)
    }

    private fun rawText(bytes: ByteArray): String {
        var data = bytes
        // Lyrics3 v1/v2 containers use byte counts; parse before Unicode decoding.
        val raw = bytes.toString(Charsets.ISO_8859_1)
        val begin = raw.indexOf("LYRICSBEGIN")
        if (begin >= 0) {
            val start = begin + "LYRICSBEGIN".length
            if (raw.indexOf("LYRICS200", start) >= 0) {
                var cursor = start
                var lyrics: ByteArray? = null
                while (cursor + 8 <= raw.length) {
                    val id = raw.substring(cursor, cursor + 3)
                    val length = raw.substring(cursor + 3, cursor + 8).toIntOrNull() ?: break
                    cursor += 8
                    if (length < 0 || cursor + length > bytes.size) break
                    if (id == "LYR") { lyrics = bytes.copyOfRange(cursor, cursor + length); break }
                    cursor += length
                }
                data = lyrics ?: error("Lyrics3 fajl nema čitljivo LYR polje.")
            } else {
                val end = raw.indexOf("LYRICSEND", start)
                data = bytes.copyOfRange(start, if (end >= 0) end else bytes.size)
            }
        }
        return decode(data).replace("\r\n", "\n").replace('\r', '\n').trim('\uFEFF', '\u0000', ' ', '\n')
    }

    private fun stripInlineTimestamps(text: String): String = text.lines()
        .map { it.replace(Regex("\\[(?:\\d{1,2}:)?\\d{1,3}:\\d{2}(?:[.,:]\\d{1,3})?]"), "").trimEnd() }
        .joinToString("\n").trim()

    private fun decode(bytes: ByteArray): String {
        if (bytes.size >= 2 && bytes[0] == 0xff.toByte() && bytes[1] == 0xfe.toByte()) return bytes.toString(Charsets.UTF_16LE)
        if (bytes.size >= 2 && bytes[0] == 0xfe.toByte() && bytes[1] == 0xff.toByte()) return bytes.toString(Charsets.UTF_16BE)
        return try { Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString() }
        catch (_: Exception) { bytes.toString(charset("windows-1250")) }
    }
}

/** Inspect just the MP3 tail when seekable; do not load a whole song into memory. */
internal fun hasEmbeddedLyrics3(context: android.content.Context, file: DocumentFile): Boolean {
    if (file.extension() != "mp3") return false
    return try {
        context.contentResolver.openFileDescriptor(file.uri, "r")?.let { descriptor ->
            android.os.ParcelFileDescriptor.AutoCloseInputStream(descriptor).use { stream ->
                val channel = stream.channel
                val size = channel.size()
                channel.position((size - 128 * 1024).coerceAtLeast(0))
                val raw = stream.readBytes().toString(Charsets.ISO_8859_1)
                (raw.contains("LYRICSBEGIN") && (raw.contains("LYRICS200") || raw.contains("LYRICSEND"))) || Regex("[0-9]{6}LYRICS200").containsMatchIn(raw)
            }
        } ?: false
    } catch (_: Exception) { false }
}

/** Keep existing same-base sidecars matched when a media filename changes. */
internal fun renameMediaWithSidecars(track: Song, newName: String): String? {
    val parent = track.folder ?: return "Folder is unavailable."
    return try {
        val oldName = track.mp3.name ?: return "File is unavailable."
        val oldBase = oldName.substringBeforeLast('.')
        val newBase = newName.substringBeforeLast('.')
        val siblings = parent.listFiles()
        val changes = listOf(track.mp3 to newName) + siblings.filter {
            it.isFile && it.uri != track.mp3.uri &&
                it.name.orEmpty().substringBeforeLast('.').equals(oldBase, ignoreCase = true) &&
                (it.extension() in textExtensions || it.extension() == "cdg")
        }.map { it to (newBase + "." + it.extension()) }
        for ((file, name) in changes) {
            if (siblings.any { it.uri != file.uri && it.name.equals(name, ignoreCase = true) }) {
                return "A file with that name already exists."
            }
        }
        val renamed = mutableListOf<Pair<DocumentFile, String>>()
        for ((file, name) in changes) {
            val previous = file.name ?: return "File is unavailable."
            if (!file.renameTo(name)) {
                val rolledBack = renamed.asReversed().map { (item, old) -> item.renameTo(old) }.all { it }
                return if (rolledBack) "Could not rename. Check folder write access." else "Rename partly failed. Check filenames in this folder."
            }
            renamed.add(file to previous)
        }
        null
    } catch (_: Exception) { "Could not rename. Check filenames and folder write access." }
}
