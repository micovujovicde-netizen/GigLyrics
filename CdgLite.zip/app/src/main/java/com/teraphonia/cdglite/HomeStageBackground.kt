package com.teraphonia.cdglite

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.res.painterResource

/** Masks fitted HOME artwork only; no pointer handler, CDG or PIP changes. */
@Composable
internal fun HomeStageBackground(modifier: Modifier, popupAdjacent: Boolean) {
    val painter = painterResource(R.drawable.gigmonster_stage_background)
    Canvas(modifier) {
        val source = painter.intrinsicSize
        if (source.width <= 0f || source.height <= 0f || size.width <= 0f || size.height <= 0f) return@Canvas
        val scale = minOf(size.width / source.width, size.height / source.height)
        val fitted = Size(source.width * scale, source.height * scale)
        translate(size.width - fitted.width, size.height - fitted.height) {
            val canvas = drawContext.canvas
            canvas.saveLayer(Rect(Offset.Zero, fitted), Paint())
            try {
                with(painter) { draw(fitted, alpha = .5146f) }
                drawRect(Brush.horizontalGradient(
                    0f to Color.Transparent, .13f to Color.Black, .87f to Color.Black, 1f to Color.Transparent,
                    startX = 0f, endX = fitted.width), size = fitted, blendMode = BlendMode.DstIn)
                drawRect(Brush.verticalGradient(
                    0f to Color.Transparent, .08f to Color.Black,
                    (if (popupAdjacent) .85f else .89f) to Color.Black, 1f to Color.Transparent,
                    startY = 0f, endY = fitted.height), size = fitted, blendMode = BlendMode.DstIn)
            } finally { canvas.restore() }
        }
    }
}
