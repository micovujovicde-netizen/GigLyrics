package com.teraphonia.cdglite

import java.util.Locale

internal fun remainingPlaybackLabel(playback: PlaybackModel): String {
    val web = playback.karaokeWeb
    val (duration, position) = when {
        playback.breakTrack != null -> playback.breakDuration to playback.breakPosition
        web.isYouTubeEmbed && web.opened -> web.durationMs to web.positionMs
        else -> playback.duration to playback.position
    }
    if (duration <= 0) return "--:--"
    val seconds = ((duration.toLong() - position.toLong()).coerceAtLeast(0) + 999) / 1000
    return String.format(Locale.ROOT, "%d:%02d", seconds / 60, seconds % 60)
}
