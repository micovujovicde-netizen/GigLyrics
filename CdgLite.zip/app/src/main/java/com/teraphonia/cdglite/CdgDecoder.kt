package com.teraphonia.cdglite

import android.graphics.Bitmap
import android.graphics.Color as AColor

internal class CdgDecoder(private val bytes:ByteArray){
 private val w=300;private val h=216;private val pix=ByteArray(w*h);private val clut=IntArray(16){AColor.BLACK};private var packet=0;private var xOffset=0;private var yOffset=0;private val bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888)
 fun seekTo(ms:Int){val target=(ms.coerceAtLeast(0)*300L/1000L).toInt().coerceAtMost(bytes.size/24);if(target<packet){pix.fill(0);clut.fill(AColor.BLACK);xOffset=0;yOffset=0;packet=0};while(packet<target){decode(packet);packet++}}
 fun bitmapCopy():Bitmap{val out=IntArray(w*h){clut[pix[((it/w+yOffset).coerceAtMost(h-1))*w+(it%w+xOffset).coerceAtMost(w-1)].toInt() and 15]};bmp.setPixels(out,0,w,0,0,w,h);return bmp.copy(Bitmap.Config.ARGB_8888,false)}
 private fun decode(n:Int){val o=n*24;if(o+24>bytes.size)return;if((bytes[o].toInt() and 0x3f)!=9)return;val ins=bytes[o+1].toInt() and 0x3f;val d=o+4;when(ins){
  1->{if((bytes[d+1].toInt() and 15)==0){val c=bytes[d].toInt() and 15;pix.fill(c.toByte())}}
  2->{val c=bytes[d].toInt() and 15;for(y in 0 until h)for(x in 0 until w)if(x<6||x>=294||y<12||y>=204)pix[y*w+x]=c.toByte()}
  6,38->{val c0=bytes[d].toInt() and 15;val c1=bytes[d+1].toInt() and 15;val row=bytes[d+2].toInt() and 31;val col=bytes[d+3].toInt() and 63;if(row<18&&col<50){for(yy in 0..11){val bits=bytes[d+4+yy].toInt() and 0x3f;for(xx in 0..5){val c=if((bits and (1 shl(5-xx)))!=0)c1 else c0;val p=(row*12+yy)*w+(col*6+xx);if(p in pix.indices)pix[p]=if(ins==38)((pix[p].toInt() xor c) and 15).toByte() else c.toByte()}}}}
  20,24->{scroll(d,ins==24)}
  30,31->{val base=if(ins==30)0 else 8;for(i in 0..7){val a=bytes[d+i*2].toInt() and 0x3f;val b=bytes[d+i*2+1].toInt() and 0x3f;val r=(a shr 2) and 15;val g=((a and 0x03) shl 2) or ((b and 0x30) shr 4);val bl=b and 0x0f;clut[base+i]=AColor.rgb(r*17,g*17,bl*17)}}
 } }
 private fun scroll(d:Int,copy:Boolean){
  val color=(bytes[d].toInt() and 15).toByte()
  val horizontal=bytes[d+1].toInt() and 0x3f
  val vertical=bytes[d+2].toInt() and 0x3f
  xOffset=(horizontal and 7).coerceAtMost(5)
  yOffset=(vertical and 15).coerceAtMost(11)
  val dx=when(horizontal shr 4){1->6;2->-6;else->0}
  val dy=when(vertical shr 4){1->12;2->-12;else->0}
  if(dx==0&&dy==0)return
  val old=pix.copyOf()
  for(y in 0 until h)for(x in 0 until w){
   val sx=x-dx;val sy=y-dy
   pix[y*w+x]=if(copy)old[((sy+h)%h)*w+(sx+w)%w]
    else if(sx in 0 until w&&sy in 0 until h)old[sy*w+sx] else color
  }
 }
}
