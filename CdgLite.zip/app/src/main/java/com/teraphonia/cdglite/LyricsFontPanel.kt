package com.teraphonia.cdglite

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

internal val LocalLyricsFontSize = compositionLocalOf { 32f }

/** Controls occupy their own top row, so lyric taps and scrolling remain unobstructed. */
@Composable
internal fun LyricsFontPanel(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val prefs = LocalContext.current.getSharedPreferences("cdglite", 0)
    var fontSize by rememberSaveable { mutableFloatStateOf(prefs.getFloat("lyricsFontSize", 32f).let {
        if (it.isFinite()) it.coerceIn(20f, 72f) else 32f
    }) }
    fun change(delta: Float) {
        fontSize = (fontSize + delta).coerceIn(20f, 72f)
        prefs.edit().putFloat("lyricsFontSize", fontSize).apply()
    }
    Box(modifier) {
        CompositionLocalProvider(LocalLyricsFontSize provides fontSize) {
            Box(Modifier.fillMaxSize().padding(top = 48.dp), content = content)
        }
        Row(Modifier.align(Alignment.TopEnd).padding(end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            for ((symbol, delta) in listOf("−" to -2f, "+" to 2f)) {
                val enabled = if (delta < 0) fontSize > 20f else fontSize < 72f
                Box(Modifier.size(48.dp)
                    .semantics { contentDescription = if (delta < 0) "Decrease lyrics font" else "Increase lyrics font" }
                    .testTag(if (delta < 0) "lyricsFontDown" else "lyricsFontUp")
                    .clickable(enabled = enabled) { change(delta) }, contentAlignment = Alignment.Center) {
                    Box(Modifier.size(36.dp, 28.dp).border(1.dp,
                        if (enabled) MonsterGreen else androidx.compose.ui.graphics.Color.DarkGray,
                        RoundedCornerShape(6.dp)), contentAlignment = Alignment.Center) {
                        Text(symbol, color = if (enabled) MonsterGreen else androidx.compose.ui.graphics.Color.Gray,
                            fontSize = 24.sp, fontWeight = FontWeight.Normal)
                    }
                }
            }
        }
    }
}
