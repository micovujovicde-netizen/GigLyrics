package com.teraphonia.cdglite

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

internal val LocalLyricsFontSize = compositionLocalOf { 32f }

/** Controls occupy their own top row, so lyric taps and scrolling remain unobstructed. */
@Composable
internal fun LyricsFontPanel(
    modifier: Modifier = Modifier,
    viewMode: LyricsViewMode? = null,
    onView: (() -> Unit)? = null,
    controlsOverlay: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    val prefs = LocalContext.current.getSharedPreferences("cdglite", 0)
    var fontSize by rememberSaveable { mutableFloatStateOf(prefs.getFloat("lyricsFontSize", 32f).let {
        if (it.isFinite()) it.coerceIn(20f, 72f) else 32f
    }) }
    fun change(delta: Float) {
        fontSize = (fontSize + delta).coerceIn(20f, 72f)
        prefs.edit().putFloat("lyricsFontSize", fontSize).apply()
    }
    Box(modifier) {
        CompositionLocalProvider(LocalLyricsFontSize provides fontSize) {
            Box(Modifier.fillMaxSize().then(if (controlsOverlay) Modifier else Modifier.padding(top = 48.dp)), content = content)
        }
        Column(
            modifier = Modifier.align(Alignment.TopEnd).padding(end = 8.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Row(Modifier.height(48.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                for ((symbol, delta) in listOf("−" to -2f, "+" to 2f)) {
                    val enabled = if (delta < 0) fontSize > 20f else fontSize < 72f
                    Box(Modifier.size(48.dp)
                        .semantics { contentDescription = if (delta < 0) "Decrease lyrics font" else "Increase lyrics font" }
                        .testTag(if (delta < 0) "lyricsFontDown" else "lyricsFontUp")
                        .clickable(enabled = enabled) { change(delta) }, contentAlignment = Alignment.Center) {
                        Box(Modifier.size(36.dp, 28.dp).border(1.dp,
                            if (enabled) MonsterGreen else androidx.compose.ui.graphics.Color.DarkGray,
                            RoundedCornerShape(6.dp)), contentAlignment = Alignment.Center) {
                            Text(symbol, color = if (enabled) MonsterGreen else androidx.compose.ui.graphics.Color.Gray,
                                fontSize = 24.sp, fontWeight = FontWeight.Normal)
                        }
                    }
                }
            }
            if (viewMode != null && onView != null) {
                MonsterButton(
                    onClick = onView,
                    compact = true,
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                    modifier = Modifier.width(78.dp).height(36.dp).testTag("lyricsView")
                ) {
                    Text("VIEW", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
        }
    }
}
