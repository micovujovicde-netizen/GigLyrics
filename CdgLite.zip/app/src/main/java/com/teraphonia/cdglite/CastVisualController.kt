package com.teraphonia.cdglite

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.framework.CastContext
import java.io.ByteArrayOutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.max

/**
 * Visual-only EXT output for Google Cast.
 *
 * Audio is never loaded on the Cast receiver. The receiver only gets PNG stage frames hosted by
 * this tablet on the LAN. Timed lyrics are advanced slightly early to compensate for Cast display
 * latency; the local audio engine remains authoritative and untouched.
 */
internal class CastVisualController(private val appContext: Context) {
    companion object {
        private const val WIDTH = 1280
        private const val HEIGHT = 720
        private const val DEFAULT_CAST_LEAD_MS = 300
        private const val CDG_REFRESH_MS = 700
    }

    private val prefs = appContext.getSharedPreferences("cdglite", 0)
    private val castContext by lazy { CastContext.getSharedInstance(appContext) }
    private val server = CastFrameServer(appContext)
    private var lastSessionId: String? = null
    private var lastSignature: String? = null
    private var loadInFlight = false

    fun update(playback: PlaybackModel) {
        val session = runCatching { castContext.sessionManager.currentCastSession }.getOrNull()
        if (session == null || !session.isConnected) {
            lastSessionId = null
            lastSignature = null
            loadInFlight = false
            return
        }
        if (lastSessionId != session.sessionId) {
            lastSessionId = session.sessionId
            lastSignature = null
            loadInFlight = false
        }
        val client = session.remoteMediaClient ?: return
        if (loadInFlight) return

        val leadMs = prefs.getInt("extCastLeadMs", DEFAULT_CAST_LEAD_MS).coerceIn(-1000, 1000)
        val rendered = CastStageRenderer.render(appContext, playback, leadMs)
        if (rendered.signature == lastSignature) return

        val url = server.publish(rendered.bitmap) ?: return
        lastSignature = rendered.signature
        val metadata = MediaMetadata(MediaMetadata.MEDIA_TYPE_PHOTO).apply {
            putString(MediaMetadata.KEY_TITLE, "GigMonster EXT")
            putInt(MediaMetadata.KEY_WIDTH, WIDTH)
            putInt(MediaMetadata.KEY_HEIGHT, HEIGHT)
        }
        val mediaInfo = MediaInfo.Builder(url)
            .setStreamType(MediaInfo.STREAM_TYPE_NONE)
            .setContentType("image/png")
            .setMetadata(metadata)
            .setStreamDuration(0)
            .build()

        loadInFlight = true
        client.load(
            MediaLoadRequestData.Builder()
                .setMediaInfo(mediaInfo)
                .setAutoplay(true)
                .build()
        ).setResultCallback {
            loadInFlight = false
            if (!it.status.isSuccess) lastSignature = null
        }
    }

    fun close() {
        server.close()
    }

    private object CastStageRenderer {
        data class Rendered(val signature: String, val bitmap: Bitmap)

        fun render(context: Context, playback: PlaybackModel, leadMs: Int): Rendered {
            val cdg = playback.frame
            if (playback.song?.cdg != null && cdg != null) {
                val bucket = max(0, playback.position + leadMs) / CDG_REFRESH_MS
                return Rendered("cdg:$bucket", renderCdg(cdg))
            }

            val timed = playback.timedLyrics
            if (timed.isNotEmpty()) {
                val effective = max(0, playback.position + leadMs)
                val activeCue = timed.indexOfLast { it.startMs <= effective }
                val rows = lyricDisplayRows(timed, playback.lyricsText, playback.showTextOnly)
                val activeRow = rows.indexOfFirst { activeCue in it.cues }.let { if (it >= 0) it else 0 }
                val signature = buildString {
                    append("lyrics:")
                    append(playback.lyricsViewMode.name).append(':')
                    append(activeCue).append(':').append(activeRow).append(':')
                    append(playback.lyricsText?.hashCode() ?: 0)
                }
                return Rendered(signature, renderTimed(rows, activeCue, activeRow, playback.lyricsViewMode))
            }

            val plain = playback.lyricsText?.takeIf {
                it.isNotBlank() && it != "Učitavanje…" && !it.startsWith("Ne mogu da pročitam")
            }
            if (plain != null) {
                return Rendered("plain:${plain.hashCode()}", renderPlain(plain))
            }

            return Rendered("logo", renderLogo(context))
        }

        private fun base(): Pair<Bitmap, Canvas> {
            val bitmap = Bitmap.createBitmap(WIDTH, HEIGHT, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.BLACK)
            return bitmap to canvas
        }

        private fun renderLogo(context: Context): Bitmap {
            val (bitmap, canvas) = base()
            val logo = BitmapFactory.decodeResource(context.resources, R.drawable.gigmonster_app_icon_no_text)
            if (logo != null) {
                val maxSide = 360
                val scale = minOf(maxSide.toFloat() / logo.width, maxSide.toFloat() / logo.height)
                val w = (logo.width * scale).toInt().coerceAtLeast(1)
                val h = (logo.height * scale).toInt().coerceAtLeast(1)
                val left = (WIDTH - w) / 2
                val top = (HEIGHT - h) / 2
                canvas.drawBitmap(logo, null, Rect(left, top, left + w, top + h), Paint(Paint.ANTI_ALIAS_FLAG))
            }
            return bitmap
        }

        private fun renderCdg(frame: Bitmap): Bitmap {
            val (bitmap, canvas) = base()
            val scale = minOf(WIDTH.toFloat() / frame.width, HEIGHT.toFloat() / frame.height)
            val w = (frame.width * scale).toInt()
            val h = (frame.height * scale).toInt()
            val left = (WIDTH - w) / 2
            val top = (HEIGHT - h) / 2
            canvas.drawBitmap(frame, null, Rect(left, top, left + w, top + h), Paint(Paint.ANTI_ALIAS_FLAG))
            return bitmap
        }

        private fun renderPlain(text: String): Bitmap {
            val (bitmap, canvas) = base()
            val clean = text.trim().lines().take(16).joinToString("\n")
            drawTextBlock(canvas, clean, 96f, 1120, Color.WHITE, false, HEIGHT / 2, centerVertically = true)
            return bitmap
        }

        private fun renderTimed(
            rows: List<LyricDisplayRow>,
            activeCue: Int,
            activeRow: Int,
            mode: LyricsViewMode
        ): Bitmap {
            val (bitmap, canvas) = base()
            if (rows.isEmpty()) return bitmap
            val center = activeRow.coerceIn(0, rows.lastIndex)
            val green = Color.rgb(134, 245, 0)

            fun isActive(row: LyricDisplayRow) = activeCue >= 0 && activeCue in row.cues
            fun nonBlankAfter(from: Int): Int? = ((from + 1)..rows.lastIndex).firstOrNull { rows[it].text.isNotBlank() }
            fun drawRows(indices: List<Int>, yStart: Int, gap: Int, activeSize: Float, otherSize: Float) {
                var y = yStart
                indices.forEach { idx ->
                    val row = rows[idx]
                    if (row.text.isBlank()) { y += gap; return@forEach }
                    val active = isActive(row)
                    val h = drawTextBlock(
                        canvas, row.text, if (active) activeSize else otherSize, 1120,
                        if (active) green else Color.WHITE, active, y, centerVertically = false
                    )
                    y += h + gap
                }
            }

            when (mode) {
                LyricsViewMode.TWO_LINE -> {
                    val next = nonBlankAfter(center)
                    val list = listOfNotNull(center, next)
                    drawRows(list, 235, 34, 72f, 54f)
                }
                LyricsViewMode.THREE_LINE -> {
                    val prev = (center - 1 downTo 0).firstOrNull { rows[it].text.isNotBlank() }
                    val next = nonBlankAfter(center)
                    drawRows(listOfNotNull(prev, center, next), 160, 26, 68f, 46f)
                }
                LyricsViewMode.BIG_NEXT -> {
                    drawTextBlock(canvas, rows[center].text, 96f, 1120, green, true, 220, false)
                    nonBlankAfter(center)?.let { drawTextBlock(canvas, rows[it].text, 52f, 1060, Color.WHITE, false, 460, false) }
                }
                LyricsViewMode.OVERLAY -> {
                    canvas.drawRect(70f, 435f, 1210f, 690f, Paint().apply { color = Color.argb(185, 0, 0, 0) })
                    drawTextBlock(canvas, rows[center].text, 72f, 1080, green, true, 480, false)
                    nonBlankAfter(center)?.let { drawTextBlock(canvas, rows[it].text, 44f, 1040, Color.WHITE, false, 600, false) }
                }
                LyricsViewMode.VERSE -> {
                    var start = center
                    var end = center
                    while (start > 0 && rows[start - 1].text.isNotBlank()) start--
                    while (end < rows.lastIndex && rows[end + 1].text.isNotBlank()) end++
                    if (end - start > 6) {
                        start = (center - 2).coerceAtLeast(0)
                        end = (center + 3).coerceAtMost(rows.lastIndex)
                    }
                    drawRows((start..end).toList(), 100, 18, 58f, 42f)
                }
                LyricsViewMode.CENTER -> {
                    val start = (center - 2).coerceAtLeast(0)
                    val end = (center + 2).coerceAtMost(rows.lastIndex)
                    drawRows((start..end).toList(), 95, 14, 60f, 38f)
                }
                LyricsViewMode.ROLL -> {
                    val start = (center - 1).coerceAtLeast(0)
                    val end = (center + 3).coerceAtMost(rows.lastIndex)
                    drawRows((start..end).toList(), 90, 16, 60f, 42f)
                }
            }
            return bitmap
        }

        private fun drawTextBlock(
            canvas: Canvas,
            text: String,
            sizePx: Float,
            widthPx: Int,
            color: Int,
            bold: Boolean,
            y: Int,
            centerVertically: Boolean
        ): Int {
            val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                this.color = color
                textSize = sizePx
                typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            }
            val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, widthPx)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setIncludePad(false)
                .setLineSpacing(0f, 1.08f)
                .build()
            val x = (WIDTH - widthPx) / 2f
            val top = if (centerVertically) (HEIGHT - layout.height) / 2f else y.toFloat()
            canvas.save()
            canvas.translate(x, top)
            layout.draw(canvas)
            canvas.restore()
            return layout.height
        }
    }
}

/** Minimal LAN HTTP server used only to expose the current silent PNG frame to the Cast receiver. */
private class CastFrameServer(private val context: Context) {
    @Volatile private var bytes: ByteArray = ByteArray(0)
    private val version = AtomicLong(0)
    private var socket: ServerSocket? = null
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "GigMonsterCastFrameServer").apply { isDaemon = true } }

    @Synchronized
    private fun ensureStarted(): Boolean {
        if (socket != null) return true
        return runCatching {
            val s = ServerSocket(0)
            socket = s
            executor.execute {
                while (!s.isClosed) {
                    val client = runCatching { s.accept() }.getOrNull() ?: break
                    runCatching {
                        client.use { connection ->
                            connection.soTimeout = 3000
                            val reader = connection.getInputStream().bufferedReader(Charsets.US_ASCII)
                            val first = reader.readLine().orEmpty()
                            while (true) {
                                val line = reader.readLine() ?: break
                                if (line.isEmpty()) break
                            }
                            val body = bytes
                            val headOnly = first.startsWith("HEAD ")
                            val out = connection.getOutputStream().buffered()
                            val header = buildString {
                                append("HTTP/1.1 200 OK\r\n")
                                append("Content-Type: image/png\r\n")
                                append("Content-Length: ${body.size}\r\n")
                                append("Cache-Control: no-store, no-cache, must-revalidate, max-age=0\r\n")
                                append("Pragma: no-cache\r\n")
                                append("Access-Control-Allow-Origin: *\r\n")
                                append("Connection: close\r\n\r\n")
                            }.toByteArray(Charsets.US_ASCII)
                            out.write(header)
                            if (!headOnly) out.write(body)
                            out.flush()
                        }
                    }
                }
            }
            true
        }.getOrDefault(false)
    }

    fun publish(bitmap: Bitmap): String? {
        if (!ensureStarted()) return null
        val out = ByteArrayOutputStream()
        if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) return null
        bytes = out.toByteArray()
        val host = localIpv4() ?: return null
        val port = socket?.localPort ?: return null
        val v = version.incrementAndGet()
        return "http://$host:$port/frame.png?v=$v"
    }

    private fun localIpv4(): String? {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val active = cm?.activeNetwork
        val fromActive = active?.let { cm.getLinkProperties(it) }
            ?.linkAddresses
            ?.map { it.address }
            ?.filterIsInstance<Inet4Address>()
            ?.firstOrNull { !it.isLoopbackAddress }
            ?.hostAddress
        if (!fromActive.isNullOrBlank()) return fromActive

        return runCatching {
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return@runCatching null
            while (interfaces.hasMoreElements()) {
                val addresses = interfaces.nextElement().inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (address is Inet4Address && !address.isLoopbackAddress && address.isSiteLocalAddress) {
                        return@runCatching address.hostAddress
                    }
                }
            }
            null
        }.getOrNull()
    }

    fun close() {
        runCatching { socket?.close() }
        socket = null
        executor.shutdownNow()
    }
}
