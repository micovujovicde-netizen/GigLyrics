package com.teraphonia.cdglite

import android.content.Context
import com.google.android.gms.cast.CastMediaControlIntent
import com.google.android.gms.cast.framework.CastOptions
import com.google.android.gms.cast.framework.OptionsProvider
import com.google.android.gms.cast.framework.SessionProvider

/**
 * EXT intentionally uses Google's Default Media Receiver.
 * We cast silent image frames only, so the TV never takes over GigMonster audio.
 * This also avoids requiring a custom Cast receiver registration for the basic stage display.
 */
class GigMonsterCastOptionsProvider : OptionsProvider {
    override fun getCastOptions(appContext: Context): CastOptions =
        CastOptions.Builder()
            .setReceiverApplicationId(CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID)
            .build()

    override fun getAdditionalSessionProviders(context: Context): List<SessionProvider>? = null
}
