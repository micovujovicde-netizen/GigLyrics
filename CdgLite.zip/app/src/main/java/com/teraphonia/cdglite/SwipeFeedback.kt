package com.teraphonia.cdglite

internal fun swipeFeedbackResource(added: Boolean, playlist: Int): Int {
    val resources = if (added) listOf(
        R.drawable.swipe_added_p1, R.drawable.swipe_added_p2,
        R.drawable.swipe_added_p3, R.drawable.swipe_added_p4
    ) else listOf(
        R.drawable.swipe_removed_p1, R.drawable.swipe_removed_p2,
        R.drawable.swipe_removed_p3, R.drawable.swipe_removed_p4
    )
    return resources[(playlist - 1).coerceIn(0, 3)]
}
