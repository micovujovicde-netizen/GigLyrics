package com.teraphonia.cdglite

internal data class LyricDisplayRow(val text: String, val cues: Set<Int>)

/** Keep unsynchronized lines without disabling valid cues in a partially timed file. */
internal fun lyricDisplayRows(timed: List<LyricsReader.TimedLine>, plain: String?, preservePlain: Boolean): List<LyricDisplayRow> {
    if (!preservePlain || plain.isNullOrBlank()) return timed.mapIndexed { i, line -> LyricDisplayRow(line.text, setOf(i)) }
    val rows = plain.lines().map { LyricDisplayRow(it, emptySet()) }.toMutableList()
    var cursor = 0
    timed.forEachIndexed { cue, line ->
        val words = line.text.lines().map(String::trim)
        fun matches(at: Int) = at + words.size <= rows.size && words.indices.all { rows[at + it].text.trim() == words[it] }
        val at = (cursor until rows.size).firstOrNull(::matches)
            ?: (0 until rows.size).firstOrNull(::matches)
        if (at == null) rows.add(LyricDisplayRow(line.text, setOf(cue)))
        else {
            words.indices.forEach { offset ->
                val row = rows[at + offset]
                rows[at + offset] = row.copy(cues = row.cues + cue)
            }
            cursor = at + words.size
        }
    }
    return rows
}
