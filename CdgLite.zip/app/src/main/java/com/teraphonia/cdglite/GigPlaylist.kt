package com.teraphonia.cdglite

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.*
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject

internal data class GhostTrack(
    val name: String,
    val mediaUri: String,
    val cdgUri: String? = null,
    val textUri: String? = null
) {
    fun toSong(context: Context): Song? {
        val media = DocumentFile.fromSingleUri(context, Uri.parse(mediaUri)) ?: return null
        val cdg = cdgUri?.let { DocumentFile.fromSingleUri(context, Uri.parse(it)) }
        val text = textUri?.let { DocumentFile.fromSingleUri(context, Uri.parse(it)) }
        return Song(name, media, cdg, text, null)
    }
    companion object {
        fun from(song: Song) = GhostTrack(song.name, song.mp3.uri.toString(), song.cdg?.uri?.toString(), song.text?.uri?.toString())
    }
}

internal class GigPlaylistStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("gigmonster_playlists", 0)
    val lists = List(4) { mutableStateListOf<GhostTrack>() }
    var activeIndex by mutableIntStateOf(prefs.getInt("active", 0).coerceIn(0, 3))
        private set
    private val locked = BooleanArray(4) { prefs.getBoolean("locked_$it", it != activeIndex) }

    init { repeat(4) { load(it) } }

    fun isLocked(index: Int) = locked[index]
    fun activate(index: Int) {
        if (index !in 0..3) return
        repeat(4) { locked[it] = it != index }
        activeIndex = index
        saveMeta()
    }
    fun lock(index: Int) { if (index in 0..3) { locked[index] = true; saveMeta() } }
    fun add(song: Song): Boolean {
        val list = lists[activeIndex]
        val ghost = GhostTrack.from(song)
        if (list.any { it.mediaUri == ghost.mediaUri }) return false
        list.add(ghost); save(activeIndex); return true
    }
    fun remove(index: Int, item: Int) { lists[index].removeAt(item); save(index) }
    fun removeUris(index: Int, uris: Set<String>) {
        if (index !in lists.indices || uris.isEmpty()) return
        lists[index].removeAll { it.mediaUri in uris }
        save(index)
    }
    fun move(index: Int, from: Int, to: Int) {
        val list = lists[index]
        if (from !in list.indices || to !in list.indices || from == to) return
        val item = list.removeAt(from); list.add(to, item); save(index)
    }
    private fun load(index: Int) {
        runCatching {
            val array = JSONArray(prefs.getString("p$index", "[]"))
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                lists[index].add(GhostTrack(o.getString("name"), o.getString("media"), o.optString("cdg").takeIf(String::isNotBlank), o.optString("text").takeIf(String::isNotBlank)))
            }
        }
    }
    private fun save(index: Int) {
        val a = JSONArray()
        lists[index].forEach { g -> a.put(JSONObject().put("name", g.name).put("media", g.mediaUri).put("cdg", g.cdgUri ?: "").put("text", g.textUri ?: "")) }
        prefs.edit().putString("p$index", a.toString()).apply()
    }
    private fun saveMeta() {
        val e = prefs.edit().putInt("active", activeIndex)
        repeat(4) { e.putBoolean("locked_$it", locked[it]) }
        e.apply()
    }
}
