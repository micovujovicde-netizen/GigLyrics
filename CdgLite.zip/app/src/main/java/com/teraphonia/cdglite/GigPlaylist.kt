package com.teraphonia.cdglite

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.*
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject

internal data class GhostTrack(
    val name: String,
    val mediaUri: String,
    val cdgUri: String? = null,
    val textUri: String? = null,
    val folderUri: String? = null,
    val chordsUri: String? = null
) {
    fun toSong(context: Context): Song? {
        val media = DocumentFile.fromSingleUri(context, Uri.parse(mediaUri)) ?: return null
        val cdg = cdgUri?.let { DocumentFile.fromSingleUri(context, Uri.parse(it)) }
        val text = textUri?.let { DocumentFile.fromSingleUri(context, Uri.parse(it)) }
        val chords = chordsUri?.let { DocumentFile.fromSingleUri(context, Uri.parse(it)) }
        val folder = folderUri?.let { documentFolderFromUri(context, Uri.parse(it)) }
            ?: documentParentFromMediaUri(context, media.uri)
        return Song(name, media, cdg, text, folder, chords ?: folder?.listFiles()?.firstOrNull {
            it.isFile && it.name.equals("$name.gmx", ignoreCase = true)
        })
    }
    companion object {
        fun from(song: Song) = GhostTrack(song.name, song.mp3.uri.toString(), song.cdg?.uri?.toString(), song.text?.uri?.toString(), song.folder?.uri?.toString(), song.chords?.uri?.toString())
    }
}

internal fun documentFolderFromUri(context: Context, uri: Uri): DocumentFile? = runCatching {
    if (android.provider.DocumentsContract.isTreeUri(uri)) {
        val authority = uri.authority ?: return null
        val tree = android.provider.DocumentsContract.buildTreeDocumentUri(
            authority,
            android.provider.DocumentsContract.getTreeDocumentId(uri)
        )
        val document = if (android.provider.DocumentsContract.isDocumentUri(context, uri)) {
            android.provider.DocumentsContract.getDocumentId(uri)
        } else android.provider.DocumentsContract.getTreeDocumentId(uri)
        val root = DocumentFile.fromTreeUri(context, tree)
        val treeId = android.provider.DocumentsContract.getTreeDocumentId(uri)
        val relative = document.removePrefix(treeId).trimStart('/')
        val nested = if (relative.isEmpty()) root else relative.split('/').fold(root) { current, name -> current?.findFile(name) }
        nested ?: DocumentFile.fromSingleUri(context, android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, document))
    } else DocumentFile.fromSingleUri(context, uri)
}.getOrNull()

internal fun documentParentFromMediaUri(context: Context, uri: Uri): DocumentFile? = runCatching {
    val authority = uri.authority ?: return null
    val documentId = android.provider.DocumentsContract.getDocumentId(uri)
    val parentId = documentId.substringBeforeLast('/', missingDelimiterValue = "")
        .ifBlank { documentId.substringBefore(':') + ":" }
    if (android.provider.DocumentsContract.isTreeUri(uri)) {
        val tree = android.provider.DocumentsContract.buildTreeDocumentUri(
            authority,
            android.provider.DocumentsContract.getTreeDocumentId(uri)
        )
        documentFolderFromUri(context, android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, parentId))
    } else DocumentFile.fromSingleUri(context, android.provider.DocumentsContract.buildDocumentUri(authority, parentId))
}.getOrNull()

internal class GigPlaylistStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("gigmonster_playlists", 0)
    val lists = List(4) { mutableStateListOf<GhostTrack>() }
    private val names = mutableStateListOf<String>().apply {
        repeat(4) { index -> add(prefs.getString("name_$index", null)?.trim().takeUnless { it.isNullOrBlank() } ?: "P${index + 1}") }
    }
    var activeIndex by mutableIntStateOf(prefs.getInt("active", 0).coerceIn(0, 3))
        private set
    private val locked = BooleanArray(4) { prefs.getBoolean("locked_$it", it != activeIndex) }

    init { repeat(4) { load(it) } }

    fun isLocked(index: Int) = locked[index]
    fun name(index: Int): String = names.getOrElse(index) { "P${index + 1}" }
    fun rename(index: Int, rawName: String) {
        if (index !in 0..3) return
        val value = rawName.trim().ifBlank { "P${index + 1}" }
        names[index] = value
        prefs.edit().putString("name_$index", value).apply()
    }
    fun activate(index: Int) {
        if (index !in 0..3) return
        repeat(4) { locked[it] = it != index }
        activeIndex = index
        saveMeta()
    }
    fun lock(index: Int) { if (index in 0..3) { locked[index] = true; saveMeta() } }
    fun add(song: Song): Boolean {
        val list = lists[activeIndex]
        val ghost = GhostTrack.from(song)
        if (list.any { it.mediaUri == ghost.mediaUri }) return false
        list.add(ghost); save(activeIndex); return true
    }
    fun remove(index: Int, item: Int) { lists[index].removeAt(item); save(index) }
    fun removeUris(index: Int, uris: Set<String>) {
        if (index !in lists.indices || uris.isEmpty()) return
        lists[index].removeAll { it.mediaUri in uris }
        save(index)
    }
    fun move(index: Int, from: Int, to: Int) {
        val list = lists[index]
        if (from !in list.indices || to !in list.indices || from == to) return
        val item = list.removeAt(from); list.add(to, item); save(index)
    }

    /** Move all selected playlist entries one slot while preserving their relative order. */
    fun moveUrisByStep(index: Int, uris: Set<String>, direction: Int): Boolean {
        if (index !in lists.indices || uris.isEmpty() || direction == 0) return false
        val list = lists[index]
        var moved = false
        if (direction < 0) {
            for (i in 1 until list.size) {
                if (list[i].mediaUri in uris && list[i - 1].mediaUri !in uris) {
                    val previous = list[i - 1]
                    list[i - 1] = list[i]
                    list[i] = previous
                    moved = true
                }
            }
        } else {
            for (i in list.size - 2 downTo 0) {
                if (list[i].mediaUri in uris && list[i + 1].mediaUri !in uris) {
                    val next = list[i + 1]
                    list[i + 1] = list[i]
                    list[i] = next
                    moved = true
                }
            }
        }
        if (moved) save(index)
        return moved
    }
    private fun load(index: Int) {
        runCatching {
            val array = JSONArray(prefs.getString("p$index", "[]"))
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                lists[index].add(GhostTrack(o.getString("name"), o.getString("media"), o.optString("cdg").takeIf(String::isNotBlank), o.optString("text").takeIf(String::isNotBlank), o.optString("folder").takeIf(String::isNotBlank), o.optString("chords").takeIf(String::isNotBlank)))
            }
        }
    }
    private fun save(index: Int) {
        val a = JSONArray()
        lists[index].forEach { g -> a.put(JSONObject().put("name", g.name).put("media", g.mediaUri).put("cdg", g.cdgUri ?: "").put("text", g.textUri ?: "").put("folder", g.folderUri ?: "").put("chords", g.chordsUri ?: "")) }
        prefs.edit().putString("p$index", a.toString()).apply()
    }
    private fun saveMeta() {
        val e = prefs.edit().putInt("active", activeIndex)
        repeat(4) { e.putBoolean("locked_$it", locked[it]) }
        e.apply()
    }
}
