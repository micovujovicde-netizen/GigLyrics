package com.teraphonia.cdglite

/**
 * Turns rendered web chord sheets into a clean, language-agnostic two-line layout.
 * Lyrics are never translated or interpreted: only chord notation is recognized.
 */
internal object ChordSheetFormatter {
    private val root = "(?:[A-GH](?:#|b|♯|♭)?|Do|Re|Ré|Mi|Fa|Sol|La|Si|Ti)"
    private val quality = "(?:(?:maj|min|dim|aug|sus|add|omit|no|m|M)?(?:2|4|5|6|7|9|11|13)?(?:[#b](?:5|9|11|13))?(?:\\([^)]*\\))?)*"
    private val chordRegex = Regex("(?i)^$root$quality(?:/$root)?$")
    private val bracketRegex = Regex("\\[([^]\\n]{1,32})]")
    private val uiNoise = Regex(
        "(?i)^(download(?:\\s+(?:pdf|txt|file))?|sign\\s*in|log\\s*in|subscribe|share|print|open in app|read more|cookie(?:s)?|privacy|terms|advertisement|menu|home|search|" +
            "preuzmi|prijavi se|podijeli|štampaj|stampa|descargar|iniciar sesión|télécharger|connexion|herunterladen|anmelden|scarica|accedi|baixar|entrar|скачать|войти|pobierz|zaloguj|indir|giriş)$"
    )

    private fun normalizeToken(raw: String): String = raw.trim()
        .trim('|', ',', ';', ':', '.', '(', ')', '{', '}')
        .replace("♯", "#")
        .replace("♭", "b")

    internal fun isChordToken(raw: String): Boolean {
        val token = normalizeToken(raw)
        if (token.equals("N.C", true) || token.equals("N.C.", true) || token.equals("NC", true)) return true
        return chordRegex.matches(token)
    }

    private fun chordTokens(line: String): List<String> = line
        .replace("||", " | ")
        .replace('|', ' ')
        .split(Regex("\\s+"))
        .map(::normalizeToken)
        .filter { it.isNotBlank() }
        .filter(::isChordToken)

    internal fun looksLikeChordLine(line: String): Boolean {
        val trimmed = line.trim()
        if (trimmed.isBlank() || trimmed.length > 180) return false
        val rawTokens = trimmed
            .replace("||", " | ")
            .replace('|', ' ')
            .split(Regex("\\s+"))
            .map(::normalizeToken)
            .filter { it.isNotBlank() && it != "-" && it != "–" && it != "—" }
        if (rawTokens.isEmpty()) return false
        val chords = rawTokens.count(::isChordToken)
        if (chords == 0) return false
        if (rawTokens.size == 1) return chords == 1 && trimmed.length <= 18
        return chords >= 2 && chords.toDouble() / rawTokens.size >= 0.60
    }

    private data class InlineResult(val chordLine: String, val lyricLine: String, val chords: Int)

    /** Convert [Am]word [F]word notation to a chord line aligned above the lyric line. */
    private fun expandInlineChords(line: String): InlineResult? {
        val matches = bracketRegex.findAll(line).toList()
        if (matches.none { isChordToken(it.groupValues[1]) }) return null

        val lyric = StringBuilder()
        val placements = mutableListOf<Pair<Int, String>>()
        var cursor = 0
        for (match in matches) {
            lyric.append(line.substring(cursor, match.range.first))
            val token = normalizeToken(match.groupValues[1])
            if (isChordToken(token)) {
                placements += lyric.length to token
            } else {
                lyric.append(match.value)
            }
            cursor = match.range.last + 1
        }
        lyric.append(line.substring(cursor))

        if (placements.isEmpty()) return null
        val width = maxOf(lyric.length, placements.maxOf { it.first + it.second.length })
        val chars = CharArray(width.coerceAtLeast(1)) { ' ' }
        var occupiedUntil = -1
        for ((requested, chord) in placements) {
            var start = requested.coerceAtLeast(0)
            if (start <= occupiedUntil) start = occupiedUntil + 2
            if (start + chord.length > chars.size) {
                // Very tightly packed inline chords are safer left inline than silently misplaced.
                return InlineResult(placements.joinToString("  ") { it.second }, lyric.toString().trimEnd(), placements.size)
            }
            chord.forEachIndexed { index, c -> chars[start + index] = c }
            occupiedUntil = start + chord.length - 1
        }
        return InlineResult(String(chars).trimEnd(), lyric.toString().trimEnd(), placements.size)
    }

    private fun isNoise(line: String): Boolean {
        val t = line.trim()
        if (t.isBlank()) return false
        if (t.length <= 80 && uiNoise.matches(t)) return true
        if (t.startsWith("http://", true) || t.startsWith("https://", true) || t.startsWith("www.", true)) return true
        if (t.length <= 70 && Regex("(?i)^(facebook|instagram|youtube|scribd|pinterest|tiktok)$").matches(t)) return true
        return false
    }

    /**
     * Returns a clean chord sheet or null when the rendered page contains no credible chords.
     * All lyric text is kept in its original language/script.
     */
    fun format(raw: String): String? {
        val source = raw.replace("\r\n", "\n").replace('\r', '\n').replace('\u00A0', ' ')
        val out = mutableListOf<String>()
        var chordCount = 0
        var lyricLikeCount = 0

        for (original in source.lines()) {
            val line = original.replace("\t", "    ").trimEnd()
            if (isNoise(line)) continue
            if (line.isBlank()) {
                if (out.isNotEmpty() && out.last().isNotBlank()) out += ""
                continue
            }

            val inline = expandInlineChords(line)
            if (inline != null) {
                out += inline.chordLine
                if (inline.lyricLine.isNotBlank()) {
                    out += inline.lyricLine
                    lyricLikeCount++
                }
                chordCount += inline.chords
                continue
            }

            if (looksLikeChordLine(line)) {
                out += line.trimEnd()
                chordCount += chordTokens(line).size.coerceAtLeast(1)
            } else {
                out += line.trim()
                if (line.trim().length >= 3) lyricLikeCount++
            }
        }

        while (out.firstOrNull()?.isBlank() == true) out.removeAt(0)
        while (out.lastOrNull()?.isBlank() == true) out.removeAt(out.lastIndex)
        if (out.isEmpty()) return null

        // Remove duplicate consecutive lines caused by nested DOM containers.
        val deduped = mutableListOf<String>()
        for (line in out) {
            if (line.isNotBlank() && deduped.lastOrNull() == line) continue
            if (line.isBlank() && deduped.lastOrNull()?.isBlank() == true) continue
            deduped += line
        }

        val result = deduped.joinToString("\n").trim()
        val credible = chordCount >= 2 && (lyricLikeCount >= 1 || chordCount >= 6)
        return result.takeIf { credible && it.length >= 20 }
    }
}

/** Search broadly across chord terminology while leaving the lyric language unrestricted. */
internal fun chordSearchQuery(title: String): String {
    val terms = listOf(
        "chords", "akordi", "akord", "acordes", "accords", "accordi", "Akkorde",
        "akordy", "akkoorden", "acorduri", "akordlar", "аккорды", "акорди",
        "акорды", "和弦", "コード", "코드"
    ).joinToString(" OR ")
    return "$title ($terms) -site:youtube.com -site:youtu.be -site:music.youtube.com -site:vimeo.com -site:dailymotion.com -site:tiktok.com"
}
