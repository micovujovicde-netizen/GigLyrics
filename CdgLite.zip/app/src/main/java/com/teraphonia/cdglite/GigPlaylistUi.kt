package com.teraphonia.cdglite

import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Text
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.zIndex
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

@Composable
internal fun GestureManual(resource: Int, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { context -> GestureGifView(context, resource) }
    )
}

@Suppress("DEPRECATION")
private class GestureGifView(context: android.content.Context, resource: Int) : android.view.View(context) {
    private val movie = context.resources.openRawResource(resource).use { android.graphics.Movie.decodeStream(it) }
    private val started = android.os.SystemClock.uptimeMillis()
    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }
    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val animation = movie ?: return
        animation.setTime(((android.os.SystemClock.uptimeMillis() - started) % animation.duration().coerceAtLeast(1)).toInt())
        val scale = minOf(width.toFloat() / animation.width(), height.toFloat() / animation.height())
        canvas.save()
        canvas.translate((width - animation.width() * scale) / 2, (height - animation.height() * scale) / 2)
        canvas.scale(scale, scale)
        animation.draw(canvas, 0f, 0f)
        canvas.restore()
        if (isAttachedToWindow) postInvalidateDelayed(40)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun GigPlaylistPopup(
    store: GigPlaylistStore,
    selected: Int,
    onSelected: (Int) -> Unit,
    showHint: Boolean,
    onGestureLearned: () -> Unit,
    nextEnabled: Boolean,
    onToggleNext: () -> Unit,
    onRemoved: (Set<String>) -> Unit,
    activeMediaUri: String?,
    activePlaying: Boolean,
    onPlay: (Int, GhostTrack) -> Unit,
    modifier: Modifier = Modifier,
    onSwipeRemoved: (Int) -> Unit = {},
    refreshKey: Int = 0
) {
    val context = LocalContext.current
    val bedrockFamily = FontFamily.SansSerif
    val formatCache = remember(refreshKey) { mutableMapOf<GhostTrack, List<FormatMark>>() }
    val marked = remember(selected) { mutableStateListOf<String>() }
    val flashing = remember(selected) { mutableStateListOf<String>() }
    val swipeHandler = remember { android.os.Handler(android.os.Looper.getMainLooper()) }
    var renameIndex by remember { mutableIntStateOf(-1) }
    var renameValue by remember { mutableStateOf("") }
    fun removeMarked(uris: Set<String>) {
        store.removeUris(selected, uris)
        marked.removeAll(uris)
        onRemoved(uris)
    }
    Column(modifier.testTag("gigPlaylistPanel").background(Color(0xFF061008)).padding(6.dp)) {
        Row(Modifier.fillMaxWidth()) {
            repeat(4) { index ->
                StoneButton(
                    onClick = { store.activate(index); onSelected(index) },
                    modifier = Modifier.weight(1f).height(52.dp).alpha(if (store.activeIndex == index) 1f else .92f),
                    active = store.activeIndex == index,
                    locked = false,
                    onLongClick = { renameIndex = index; renameValue = store.names[index].value }
                ) {
                    Text(
                        store.displayName(index),
                        color = if (store.activeIndex == index) MonsterGreen else Color(0xFF9BA39A),
                        fontSize = 23.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = bedrockFamily,
                        letterSpacing = .5.sp,
                        maxLines = 1
                    )
                }
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Spacer(Modifier.weight(1f))
            StoneButton(
                onClick = onToggleNext,
                modifier = Modifier.width(118.dp).height(52.dp).testTag("gigNextToggle"),
                active = nextEnabled
            ) {
                Text(
                    if (nextEnabled) "NEXT ON" else "NEXT OFF",
                    color = if (nextEnabled) MonsterGreen else Color(0xFF9BA39A),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
            }
            StoneButton(
                onClick = { if (marked.isNotEmpty()) removeMarked(marked.toSet()) },
                modifier = Modifier.width(118.dp).height(52.dp).testTag("gigRemove"),
                active = marked.isNotEmpty()
            ) {
                Text(
                    "REMOVE",
                    color = if (marked.isNotEmpty()) MonsterGreen else Color.Gray,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
            }

        }
        if (showHint) {
            GestureManual(R.drawable.playlist_gesture_hint, Modifier.fillMaxWidth().height(150.dp).padding(vertical = 4.dp))
        }
        LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(store.lists[selected], key = { _, g -> g.mediaUri }) { index, ghost ->
                val marks by produceState<List<FormatMark>>(formatCache[ghost].orEmpty(), ghost, refreshKey) {
                    val cached = formatCache[ghost]
                    value = cached ?: withContext(Dispatchers.IO) {
                        runCatching {
                            ghost.toSong(context)?.let { song ->
                                song.formatMarks(hasEmbeddedLyrics3(context, song.mp3))
                            }.orEmpty()
                        }.getOrDefault(emptyList())
                    }
                    formatCache[ghost] = value
                }
                var dragX by remember(ghost.mediaUri) { mutableFloatStateOf(0f) }
                var dragY by remember(ghost.mediaUri) { mutableFloatStateOf(0f) }
                var reordering by remember(ghost.mediaUri) { mutableStateOf(false) }

                val active = activePlaying && activeMediaUri == ghost.mediaUri
                val selectedForMove = ghost.mediaUri in marked
                Row(
                    Modifier.fillMaxWidth().testTag("playlistRow:$index")
                        .zIndex(if (reordering) 4f else 0f)
                        .graphicsLayer {
                            translationY = if (reordering) dragY else 0f
                            scaleX = if (reordering) 1.012f else 1f
                            scaleY = if (reordering) 1.012f else 1f
                            alpha = if (reordering) .94f else 1f
                            shadowElevation = if (reordering) 12.dp.toPx() else 0f
                        }
                        .monsterRow()
                        .background(if (ghost.mediaUri in flashing) MonsterGreen.copy(alpha = .55f) else if (ghost.mediaUri in marked || active) Color(0xFF383838) else Color.Transparent)
                        .pointerInput(ghost.mediaUri, selected) {
                            detectHorizontalDragGestures(
                                onDragStart = { dragX = 0f },
                                onHorizontalDrag = { change, amount -> change.consume(); dragX += amount },
                                onDragEnd = {
                                    if (dragX > 80.dp.toPx() && ghost.mediaUri !in flashing) {
                                        flashing.add(ghost.mediaUri)
                                        onSwipeRemoved(selected + 1)
                                        onGestureLearned()
                                        swipeHandler.postDelayed({
                                            removeMarked(setOf(ghost.mediaUri))
                                            flashing.remove(ghost.mediaUri)
                                        }, 240)
                                    }
                                    dragX = 0f
                                },
                                onDragCancel = { dragX = 0f }
                            )
                        }
                        .pointerInput(ghost.mediaUri, selected, selectedForMove, marked.size) {
                            if (!selectedForMove) return@pointerInput
                            val stepPx = 54.dp.toPx()
                            detectVerticalDragGestures(
                                onDragStart = {
                                    reordering = true
                                    dragY = 0f
                                    onGestureLearned()
                                },
                                onVerticalDrag = { change, amount ->
                                    change.consume()
                                    dragY += amount
                                    while (dragY <= -stepPx) {
                                        if (store.moveUrisByStep(selected, marked.toSet(), -1)) dragY += stepPx
                                        else { dragY = 0f; break }
                                    }
                                    while (dragY >= stepPx) {
                                        if (store.moveUrisByStep(selected, marked.toSet(), 1)) dragY -= stepPx
                                        else { dragY = 0f; break }
                                    }
                                },
                                onDragEnd = {
                                    reordering = false
                                    dragY = 0f
                                },
                                onDragCancel = {
                                    reordering = false
                                    dragY = 0f
                                }
                            )
                        }
                        .combinedClickable(
                            onLongClick = {
                                if (ghost.mediaUri in marked) marked.remove(ghost.mediaUri) else marked.add(ghost.mediaUri)
                            },
                            onClick = {
                                if (marked.isNotEmpty()) {
                                    if (ghost.mediaUri in marked) marked.remove(ghost.mediaUri) else marked.add(ghost.mediaUri)
                                } else onPlay(index, ghost)
                            }
                        )
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${index + 1}.",
                        color = MonsterGreen,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = bedrockFamily,
                        modifier = Modifier.width(44.dp)
                    )
                    Text(
                        ghost.name,
                        color = Color.White,
                        fontSize = 23.sp,
                        lineHeight = 29.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = bedrockFamily,
                        letterSpacing = .25.sp,
                        modifier = Modifier.weight(1f)
                    )
                    SongFormatLabels(marks)
                }
            }
        }
    }
    if (renameIndex in 0..3) {
        AlertDialog(
            onDismissRequest = { renameIndex = -1 },
            title = { Text("Rename playlist", color = Color.White) },
            text = {
                OutlinedTextField(
                    value = renameValue,
                    onValueChange = { renameValue = it.take(24) },
                    singleLine = true,
                    label = { Text("Playlist name") }
                )
            },
            confirmButton = {
                TextButton(onClick = { store.rename(renameIndex, renameValue); renameIndex = -1 }) {
                    Text("SAVE", color = MonsterGreen)
                }
            },
            dismissButton = {
                TextButton(onClick = { renameIndex = -1 }) { Text("CANCEL", color = Color.White) }
            },
            containerColor = Color(0xFF162017)
        )
    }
}
