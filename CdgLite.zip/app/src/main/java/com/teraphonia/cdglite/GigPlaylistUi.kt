package com.teraphonia.cdglite

import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.os.Build
import android.widget.ImageView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlin.math.abs

@Composable
private fun PlaylistGestureHint(modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier
            .fillMaxWidth()
            .height(78.dp)
            .background(Color(0xE6101610)),
        factory = { context ->
            ImageView(context).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                if (Build.VERSION.SDK_INT >= 28) {
                    runCatching {
                        val source = ImageDecoder.createSource(resources, R.drawable.playlist_gesture_hint)
                        val drawable = ImageDecoder.decodeDrawable(source)
                        setImageDrawable(drawable)
                        (drawable as? AnimatedImageDrawable)?.start()
                    }.onFailure { setImageResource(R.drawable.playlist_gesture_hint) }
                } else setImageResource(R.drawable.playlist_gesture_hint)
            }
        }
    )
}

@Composable
internal fun GigPlaylistPopup(
    store: GigPlaylistStore,
    selected: Int,
    onSelected: (Int) -> Unit,
    showHint: Boolean,
    onGestureLearned: () -> Unit,
    activeMediaUri: String?,
    activePlaying: Boolean,
    onPlay: (Int, GhostTrack) -> Unit,
    modifier: Modifier = Modifier
) {
    val bedrockFamily = FontFamily.SansSerif
    Column(modifier.background(Color(0xF20A0D0A)).padding(6.dp)) {
        Row(Modifier.fillMaxWidth()) {
            repeat(4) { index ->
                StoneButton(
                    onClick = { store.activate(index); onSelected(index) },
                    modifier = Modifier.weight(1f).height(68.dp),
                    active = store.activeIndex == index,
                    locked = store.activeIndex != index
                ) {
                    Text(
                        "P${index + 1}",
                        color = if (store.activeIndex == index) MonsterGreen else Color(0xFFD2D5CF),
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = bedrockFamily,
                        letterSpacing = 1.2.sp
                    )
                }
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "P${selected + 1}  •  ${store.lists[selected].size} pjesama",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                fontFamily = bedrockFamily,
                letterSpacing = .5.sp,
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
            )
            StoneButton(
                onClick = {
                    store.lock(selected)
                    val next = (selected + 1) % 4
                    store.activate(next)
                    onSelected(next)
                },
                modifier = Modifier.width(132.dp).height(58.dp),
                active = false
            ) {
                Text("LOCK", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black, fontFamily = bedrockFamily, letterSpacing = 1.sp)
            }
        }
        if (showHint && store.lists[selected].isNotEmpty()) {
            PlaylistGestureHint(Modifier.padding(vertical = 4.dp))
        }
        LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(store.lists[selected], key = { _, g -> g.mediaUri }) { index, ghost ->
                var dragX by remember(ghost.mediaUri) { mutableFloatStateOf(0f) }
                var dragY by remember(ghost.mediaUri) { mutableFloatStateOf(0f) }
                val active = activePlaying && activeMediaUri == ghost.mediaUri
                Row(
                    Modifier.fillMaxWidth()
                        .monsterRow()
                        .background(if (active) Color(0xFF383838) else Color.Transparent)
                        .pointerInput(ghost.mediaUri, index, selected) {
                            detectDragGesturesAfterLongPress(
                                onDragStart = { dragX = 0f; dragY = 0f },
                                onDrag = { change, amount -> change.consume(); dragX += amount.x; dragY += amount.y },
                                onDragEnd = {
                                    val learned = when {
                                        dragX < -80.dp.toPx() && abs(dragX) > abs(dragY) -> { store.remove(selected, index); true }
                                        dragY < -45.dp.toPx() && index > 0 -> { store.move(selected, index, index - 1); true }
                                        dragY > 45.dp.toPx() && index < store.lists[selected].lastIndex -> { store.move(selected, index, index + 1); true }
                                        else -> false
                                    }
                                    if (learned) onGestureLearned()
                                }
                            )
                        }
                        .clickable { onPlay(index, ghost) }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${index + 1}.",
                        color = MonsterGreen,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = bedrockFamily,
                        modifier = Modifier.width(44.dp)
                    )
                    Text(
                        ghost.name,
                        color = Color.White,
                        fontSize = 23.sp,
                        lineHeight = 29.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = bedrockFamily,
                        letterSpacing = .25.sp,
                        modifier = Modifier.weight(1f)
                    )
                    if (ghost.mediaUri.lowercase().contains(".yt")) Text("YT", color = Color.Red, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}
