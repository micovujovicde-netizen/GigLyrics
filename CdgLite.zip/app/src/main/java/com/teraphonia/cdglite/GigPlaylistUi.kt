package com.teraphonia.cdglite

import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

@Composable
internal fun GestureManual(resource: Int, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { context -> GestureGifView(context, resource) }
    )
}

@Suppress("DEPRECATION")
private class GestureGifView(context: android.content.Context, resource: Int) : android.view.View(context) {
    private val movie = context.resources.openRawResource(resource).use { android.graphics.Movie.decodeStream(it) }
    private val started = android.os.SystemClock.uptimeMillis()
    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }
    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val animation = movie ?: return
        animation.setTime(((android.os.SystemClock.uptimeMillis() - started) % animation.duration().coerceAtLeast(1)).toInt())
        val scale = minOf(width.toFloat() / animation.width(), height.toFloat() / animation.height())
        canvas.save()
        canvas.translate((width - animation.width() * scale) / 2, (height - animation.height() * scale) / 2)
        canvas.scale(scale, scale)
        animation.draw(canvas, 0f, 0f)
        canvas.restore()
        if (isAttachedToWindow) postInvalidateDelayed(40)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun GigPlaylistPopup(
    store: GigPlaylistStore,
    selected: Int,
    onSelected: (Int) -> Unit,
    showHint: Boolean,
    onGestureLearned: () -> Unit,
    nextEnabled: Boolean,
    onToggleNext: () -> Unit,
    onRemoved: (Set<String>) -> Unit,
    activeMediaUri: String?,
    activePlaying: Boolean,
    onPlay: (Int, GhostTrack) -> Unit,
    modifier: Modifier = Modifier,
    onSwipeRemoved: (Int) -> Unit = {}
) {
    val bedrockFamily = FontFamily.SansSerif
    val marked = remember(selected) { mutableStateListOf<String>() }
    val flashing = remember(selected) { mutableStateListOf<String>() }
    val swipeHandler = remember { android.os.Handler(android.os.Looper.getMainLooper()) }
    fun removeMarked(uris: Set<String>) {
        store.removeUris(selected, uris)
        marked.removeAll(uris)
        onRemoved(uris)
    }
    Column(modifier.background(Color(0xF20A0D0A)).padding(6.dp)) {
        Row(Modifier.fillMaxWidth()) {
            repeat(4) { index ->
                StoneButton(
                    onClick = { store.activate(index); onSelected(index) },
                    modifier = Modifier.weight(1f).height(68.dp),
                    active = store.activeIndex == index,
                    locked = store.activeIndex != index
                ) {
                    Text(
                        "P${index + 1}",
                        color = if (store.activeIndex == index) MonsterGreen else Color(0xFFD2D5CF),
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = bedrockFamily,
                        letterSpacing = 1.2.sp
                    )
                }
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "P${selected + 1}  •  ${store.lists[selected].size} pjesama",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                fontFamily = bedrockFamily,
                letterSpacing = .5.sp,
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
            )
            StoneButton(
                onClick = onToggleNext,
                modifier = Modifier.width(118.dp).height(58.dp).testTag("gigNextToggle"),
                active = nextEnabled
            ) { Text("NEXT ${if (nextEnabled) "ON" else "OFF"}", color = if (nextEnabled) MonsterGreen else Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            StoneButton(
                onClick = { if (marked.isNotEmpty()) removeMarked(marked.toSet()) },
                modifier = Modifier.width(118.dp).height(58.dp).testTag("gigRemove"),
                active = marked.isNotEmpty()
            ) { Text("REMOVE", color = if (marked.isNotEmpty()) MonsterGreen else Color.Gray, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            StoneButton(
                onClick = {
                    store.lock(selected)
                    val next = (selected + 1) % 4
                    store.activate(next)
                    onSelected(next)
                },
                modifier = Modifier.width(132.dp).height(58.dp),
                active = false
            ) {
                Text("LOCK", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black, fontFamily = bedrockFamily, letterSpacing = 1.sp)
            }
        }
        if (showHint) {
            GestureManual(R.drawable.playlist_gesture_hint, Modifier.fillMaxWidth().height(150.dp).padding(vertical = 4.dp))
        }
        LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(store.lists[selected], key = { _, g -> g.mediaUri }) { index, ghost ->
                var dragX by remember(ghost.mediaUri) { mutableFloatStateOf(0f) }

                val active = activePlaying && activeMediaUri == ghost.mediaUri
                Row(
                    Modifier.fillMaxWidth().testTag("playlistRow:$index")
                        .monsterRow()
                        .background(if (ghost.mediaUri in flashing) MonsterGreen.copy(alpha = .55f) else if (ghost.mediaUri in marked || active) Color(0xFF383838) else Color.Transparent)
                        .pointerInput(ghost.mediaUri, selected) {
                            detectHorizontalDragGestures(
                                onDragStart = { dragX = 0f },
                                onHorizontalDrag = { change, amount -> change.consume(); dragX += amount },
                                onDragEnd = {
                                    if (dragX > 80.dp.toPx() && ghost.mediaUri !in flashing) {
                                        flashing.add(ghost.mediaUri)
                                        onSwipeRemoved(selected + 1)
                                        onGestureLearned()
                                        swipeHandler.postDelayed({
                                            removeMarked(setOf(ghost.mediaUri))
                                            flashing.remove(ghost.mediaUri)
                                        }, 240)
                                    }
                                },
                                onDragCancel = { dragX = 0f }
                            )
                        }
                        .combinedClickable(
                            onLongClick = {
                                if (ghost.mediaUri in marked) marked.remove(ghost.mediaUri) else marked.add(ghost.mediaUri)
                            },
                            onClick = {
                                if (marked.isNotEmpty()) {
                                    if (ghost.mediaUri in marked) marked.remove(ghost.mediaUri) else marked.add(ghost.mediaUri)
                                } else onPlay(index, ghost)
                            }
                        )
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${index + 1}.",
                        color = MonsterGreen,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = bedrockFamily,
                        modifier = Modifier.width(44.dp)
                    )
                    Text(
                        ghost.name,
                        color = Color.White,
                        fontSize = 23.sp,
                        lineHeight = 29.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = bedrockFamily,
                        letterSpacing = .25.sp,
                        modifier = Modifier.weight(1f)
                    )
                    if (ghost.mediaUri.lowercase().contains(".yt")) Text("YT", color = Color.Red, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}
