package com.teraphonia.cdglite

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.nio.charset.Charset

/**
 * Embedded karaoke lyrics for Standard MIDI / KAR files.
 *
 * Read priority is FF 05 (Lyric). A parallel FF 01 karaoke text track is used only
 * for its '/' and '\\' line-boundary markers, never as a second timing stream.
 * If FF 05 is absent, a karaoke-style FF 01 stream is used as the lyric source.
 *
 * Writing deliberately creates one timing stream only: FF 05 Lyric events. Existing
 * FF 05 events and karaoke-style FF 01 lyric fragments are removed first, while
 * @K/@T/@I/@V/@L metadata is preserved. This prevents duplicate lyric timing.
 */
internal object MidiLyrics {
    data class Embedded(val text: String, val timed: List<LyricsReader.TimedLine>)

    private data class TextEvent(
        val track: Int,
        val tick: Long,
        val order: Int,
        val type: Int,
        val text: String
    )

    private data class MidiEvent(
        val tick: Long,
        val order: Int,
        val bytes: ByteArray,
        val metaType: Int? = null,
        val metaPayload: ByteArray? = null
    )

    private data class TrackData(
        val events: List<MidiEvent>,
        val endTick: Long,
        val lyricTextEventCount: Int
    )

    fun read(data: ByteArray): Embedded? {
        val timeMap = runCatching { MidiTimeMap.parse(data) }.getOrNull() ?: return null
        val events = collectTextEvents(data)
        val lyrics = events.filter { it.type == 0x05 && meaningful(it.text) }
            .sortedWith(compareBy<TextEvent> { it.tick }.thenBy { it.track }.thenBy { it.order })
        val karaokeText = events.filter { it.type == 0x01 && !isKaraokeHeader(it.text) && meaningful(it.text) }
            .sortedWith(compareBy<TextEvent> { it.tick }.thenBy { it.track }.thenBy { it.order })

        val source = if (lyrics.isNotEmpty()) lyrics else karaokeText
        if (source.isEmpty()) return null

        // Classic KAR often carries the exact same syllables twice: FF01 has the line
        // separators and FF05 has the preferred lyric timing. Borrow only those separators.
        val textMarkerAtTick = karaokeText.groupBy { it.tick }.mapValues { (_, list) -> list.first().text }
        val lines = mutableListOf<LyricsReader.TimedLine>()
        val plain = mutableListOf<String>()
        var current = StringBuilder()
        var currentStart: Int? = null

        fun flush() {
            val line = current.toString().trim()
            val start = currentStart
            if (line.isNotEmpty() && start != null) {
                plain += line
                lines += LyricsReader.TimedLine(start, line)
            }
            current = StringBuilder()
            currentStart = null
        }

        source.forEach { event ->
            var fragment = event.text.replace("\r", "").replace("\n", "")
            val marker = if (lyrics.isNotEmpty()) textMarkerAtTick[event.tick] else event.text
            val startsNewLine = marker?.let(::hasLineBoundary) == true || hasLineBoundary(fragment)
            fragment = fragment.trimStart('/', '\\')
            if (startsNewLine && current.isNotEmpty()) flush()
            if (currentStart == null) currentStart = timeMap.tickToMs(event.tick)
            current.append(fragment)
        }
        flush()

        // Some MIDI files store one complete line per FF05 event with no slash markers.
        // If concatenation produced one implausibly huge line, fall back to one cue/event.
        if (lines.size == 1 && source.size > 4 && lines.first().text.length > 180) {
            val perEvent = source.mapNotNull { event ->
                val text = event.text.trimStart('/', '\\').trim()
                text.takeIf { it.isNotEmpty() }?.let { LyricsReader.TimedLine(timeMap.tickToMs(event.tick), it) }
            }
            if (perEvent.isNotEmpty()) return Embedded(perEvent.joinToString("\n") { it.text }, perEvent)
        }

        return if (lines.isEmpty()) null else Embedded(plain.joinToString("\n"), lines)
    }

    /** Replace embedded karaoke lyric timing with exactly one FF05 stream. */
    fun embed(data: ByteArray, timedLines: List<LyricsReader.TimedLine>): ByteArray {
        require(timedLines.any { it.text.isNotBlank() }) { "No timed lyrics" }
        require(data.size >= 14 && ascii(data, 0, 4) == "MThd") { "Not a Standard MIDI File" }
        val headerLength = readInt32(data, 4)
        require(headerLength >= 6 && 8 + headerLength <= data.size) { "Invalid MIDI header" }
        val format = readU16(data, 8)
        val declaredTracks = readU16(data, 10)
        val timeMap = MidiTimeMap.parse(data)

        data class Chunk(val type: String, val raw: ByteArray, val track: TrackData? = null)
        val chunks = mutableListOf<Chunk>()
        var p = 8 + headerLength
        var trackIndex = 0
        while (trackIndex < declaredTracks && p + 8 <= data.size) {
            val type = ascii(data, p, 4)
            val length = readInt32(data, p + 4)
            val start = p + 8
            val end = start + length
            require(length >= 0 && end <= data.size) { "Invalid MIDI chunk" }
            val raw = data.copyOfRange(p, end)
            chunks += if (type == "MTrk") {
                val parsed = parseTrack(data, start, end)
                trackIndex++
                Chunk(type, raw, parsed)
            } else Chunk(type, raw, null)
            p = end
        }
        require(trackIndex == declaredTracks) { "Missing MIDI tracks" }

        val trackChunks = chunks.filter { it.type == "MTrk" }
        val existingLyricTrack = trackChunks.indexOfFirst { chunk ->
            chunk.track?.events?.any { it.metaType == 0x05 } == true
        }
        val existingKaraokeTrack = trackChunks.indexOfFirst { chunk ->
            (chunk.track?.lyricTextEventCount ?: 0) >= 2
        }
        val targetTrackIndex = when {
            existingLyricTrack >= 0 -> existingLyricTrack
            existingKaraokeTrack >= 0 -> existingKaraokeTrack
            format == 0 -> 0
            else -> -1 // append a dedicated lyric track for format 1/2
        }

        val lyricEvents = timedLines
            .filter { it.text.isNotBlank() }
            .mapIndexed { index, line ->
                val payload = line.text.trim().toByteArray(Charsets.UTF_8)
                MidiEvent(
                    tick = timeMap.msToTick(line.startMs),
                    order = Int.MAX_VALUE / 2 + index,
                    bytes = metaEventBytes(0x05, payload),
                    metaType = 0x05,
                    metaPayload = payload
                )
            }
            .sortedWith(compareBy<MidiEvent> { it.tick }.thenBy { it.order })

        val output = ByteArrayOutputStream(data.size + lyricEvents.sumOf { it.bytes.size + 4 })
        val header = data.copyOfRange(0, 8 + headerLength)
        if (targetTrackIndex < 0) {
            val newCount = declaredTracks + 1
            header[10] = ((newCount ushr 8) and 0xff).toByte()
            header[11] = (newCount and 0xff).toByte()
        }
        output.write(header)

        var seenTrack = 0
        chunks.forEach { chunk ->
            if (chunk.type != "MTrk") {
                output.write(chunk.raw)
                return@forEach
            }
            val track = chunk.track ?: error("Missing track")
            val isTarget = seenTrack == targetTrackIndex
            val filtered = track.events.filterNot { event ->
                when (event.metaType) {
                    0x05 -> true
                    0x01 -> track.lyricTextEventCount >= 2 && event.metaPayload?.let { payload ->
                        val text = decodeText(payload)
                        !isKaraokeHeader(text) && meaningful(text)
                    } == true
                    0x2f -> true // rebuilt once at the end of the track
                    else -> false
                }
            }.toMutableList()
            if (isTarget) filtered += lyricEvents
            val endTick = maxOf(track.endTick, if (isTarget) lyricEvents.maxOfOrNull { it.tick } ?: 0L else 0L)
            output.write(trackChunkBytes(filtered, endTick))
            seenTrack++
        }

        if (targetTrackIndex < 0) {
            val endTick = lyricEvents.maxOfOrNull { it.tick } ?: 0L
            output.write(trackChunkBytes(lyricEvents, endTick))
        }

        val result = output.toByteArray()
        // Refuse to return a malformed rewrite or a rewrite that lost the lyrics.
        MidiTimeMap.parse(result)
        require(read(result)?.timed?.isNotEmpty() == true) { "Embedded lyrics verification failed" }
        return result
    }

    private fun trackChunkBytes(events: List<MidiEvent>, endTick: Long): ByteArray {
        val body = ByteArrayOutputStream()
        var lastTick = 0L
        events.sortedWith(compareBy<MidiEvent> { it.tick }.thenBy { it.order }).forEach { event ->
            val tick = event.tick.coerceAtLeast(lastTick)
            body.write(vlqBytes(tick - lastTick))
            body.write(event.bytes)
            lastTick = tick
        }
        val finalTick = endTick.coerceAtLeast(lastTick)
        body.write(vlqBytes(finalTick - lastTick))
        body.write(byteArrayOf(0xff.toByte(), 0x2f, 0x00))
        val bytes = body.toByteArray()
        val out = ByteArrayOutputStream(bytes.size + 8)
        out.write("MTrk".toByteArray(Charsets.US_ASCII))
        writeInt32(out, bytes.size)
        out.write(bytes)
        return out.toByteArray()
    }

    private fun collectTextEvents(data: ByteArray): List<TextEvent> {
        require(data.size >= 14 && ascii(data, 0, 4) == "MThd") { "Not a Standard MIDI File" }
        val headerLength = readInt32(data, 4)
        val declaredTracks = readU16(data, 10)
        var p = 8 + headerLength
        var trackIndex = 0
        val out = mutableListOf<TextEvent>()
        while (trackIndex < declaredTracks && p + 8 <= data.size) {
            val type = ascii(data, p, 4)
            val length = readInt32(data, p + 4)
            val start = p + 8
            val end = start + length
            require(length >= 0 && end <= data.size) { "Invalid MIDI chunk" }
            if (type == "MTrk") {
                val track = parseTrack(data, start, end)
                track.events.forEach { event ->
                    if (event.metaType == 0x01 || event.metaType == 0x05) {
                        val payload = event.metaPayload ?: return@forEach
                        out += TextEvent(trackIndex, event.tick, event.order, event.metaType, decodeText(payload))
                    }
                }
                trackIndex++
            }
            p = end
        }
        require(trackIndex == declaredTracks) { "Missing MIDI tracks" }
        return out
    }

    private fun parseTrack(data: ByteArray, start: Int, end: Int): TrackData {
        var p = start
        var tick = 0L
        var runningStatus = -1
        var order = 0
        var endTick = 0L
        val events = mutableListOf<MidiEvent>()
        var nonHeaderText = 0
        while (p < end) {
            val delta = readVlq(data, p, end)
            tick += delta.first
            p = delta.second
            if (p >= end) break

            var status = data[p].toInt() and 0xff
            if (status < 0x80) {
                require(runningStatus >= 0) { "Invalid MIDI running status" }
                status = runningStatus
            } else {
                p++
                if (status in 0x80..0xef) runningStatus = status
            }

            when {
                status in 0x80..0xef -> {
                    val type = status and 0xf0
                    val count = if (type == 0xc0 || type == 0xd0) 1 else 2
                    require(p + count <= end) { "Truncated MIDI channel event" }
                    val raw = ByteArray(count + 1)
                    raw[0] = status.toByte()
                    data.copyInto(raw, 1, p, p + count)
                    p += count
                    events += MidiEvent(tick, order++, raw)
                }
                status == 0xff -> {
                    require(p < end) { "Truncated MIDI meta event" }
                    val metaType = data[p++].toInt() and 0xff
                    val len = readVlq(data, p, end)
                    val length = len.first.toInt()
                    p = len.second
                    require(length >= 0 && p + length <= end) { "Truncated MIDI meta payload" }
                    val payload = data.copyOfRange(p, p + length)
                    p += length
                    if (metaType == 0x01) {
                        val text = decodeText(payload)
                        if (!isKaraokeHeader(text) && meaningful(text)) nonHeaderText++
                    }
                    if (metaType == 0x2f) endTick = maxOf(endTick, tick)
                    events += MidiEvent(tick, order++, metaEventBytes(metaType, payload), metaType, payload)
                }
                status == 0xf0 || status == 0xf7 -> {
                    val len = readVlq(data, p, end)
                    val length = len.first.toInt()
                    p = len.second
                    require(length >= 0 && p + length <= end) { "Truncated MIDI SysEx" }
                    val payload = data.copyOfRange(p, p + length)
                    p += length
                    val raw = ByteArrayOutputStream().apply {
                        write(status)
                        write(vlqBytes(length.toLong()))
                        write(payload)
                    }.toByteArray()
                    events += MidiEvent(tick, order++, raw)
                }
                else -> {
                    val count = when (status) {
                        0xf1, 0xf3 -> 1
                        0xf2 -> 2
                        0xf6, in 0xf8..0xfe -> 0
                        else -> throw IllegalArgumentException("Unsupported MIDI status: $status")
                    }
                    require(p + count <= end) { "Truncated MIDI system event" }
                    val raw = ByteArray(count + 1)
                    raw[0] = status.toByte()
                    data.copyInto(raw, 1, p, p + count)
                    p += count
                    events += MidiEvent(tick, order++, raw)
                }
            }
        }
        if (endTick == 0L) endTick = tick
        return TrackData(events, maxOf(endTick, tick), nonHeaderText)
    }

    private fun meaningful(value: String): Boolean = value.any { !it.isWhitespace() && it != '/' && it != '\\' }

    private fun hasLineBoundary(value: String): Boolean {
        val t = value.trimStart()
        return t.startsWith("/") || t.startsWith("\\") || value.contains('\n') || value.contains('\r')
    }

    private fun isKaraokeHeader(value: String): Boolean {
        val t = value.trimStart()
        return t.startsWith("@K", true) || t.startsWith("@T", true) || t.startsWith("@I", true) ||
            t.startsWith("@V", true) || t.startsWith("@L", true) || t.startsWith("@W", true)
    }

    private fun decodeText(bytes: ByteArray): String {
        if (bytes.isEmpty()) return ""
        val utf8 = runCatching {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes)).toString()
        }.getOrNull()
        if (utf8 != null) return utf8
        return runCatching { Charset.forName("windows-1250").decode(ByteBuffer.wrap(bytes)).toString() }
            .getOrElse { bytes.toString(Charsets.ISO_8859_1) }
    }

    private fun metaEventBytes(type: Int, payload: ByteArray): ByteArray = ByteArrayOutputStream().apply {
        write(0xff)
        write(type)
        write(vlqBytes(payload.size.toLong()))
        write(payload)
    }.toByteArray()

    private fun vlqBytes(value: Long): ByteArray {
        require(value >= 0) { "Negative MIDI delta" }
        var v = value
        val tmp = IntArray(10)
        var count = 0
        tmp[count++] = (v and 0x7f).toInt()
        v = v ushr 7
        while (v > 0) {
            tmp[count++] = ((v and 0x7f).toInt() or 0x80)
            v = v ushr 7
        }
        return ByteArray(count) { i -> tmp[count - 1 - i].toByte() }
    }

    private fun readVlq(data: ByteArray, offset: Int, end: Int): Pair<Long, Int> {
        var p = offset
        var value = 0L
        repeat(4) {
            require(p < end) { "Truncated MIDI VLQ" }
            val b = data[p++].toInt() and 0xff
            value = (value shl 7) or (b and 0x7f).toLong()
            if ((b and 0x80) == 0) return value to p
        }
        throw IllegalArgumentException("Invalid MIDI VLQ")
    }

    private fun ascii(data: ByteArray, offset: Int, length: Int): String =
        data.copyOfRange(offset, offset + length).toString(Charsets.US_ASCII)

    private fun readU16(data: ByteArray, offset: Int): Int =
        ((data[offset].toInt() and 0xff) shl 8) or (data[offset + 1].toInt() and 0xff)

    private fun readInt32(data: ByteArray, offset: Int): Int =
        ((data[offset].toInt() and 0xff) shl 24) or
            ((data[offset + 1].toInt() and 0xff) shl 16) or
            ((data[offset + 2].toInt() and 0xff) shl 8) or
            (data[offset + 3].toInt() and 0xff)

    private fun writeInt32(out: ByteArrayOutputStream, value: Int) {
        out.write((value ushr 24) and 0xff)
        out.write((value ushr 16) and 0xff)
        out.write((value ushr 8) and 0xff)
        out.write(value and 0xff)
    }
}
