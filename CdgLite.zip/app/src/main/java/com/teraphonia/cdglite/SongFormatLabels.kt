package com.teraphonia.cdglite

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

internal data class FormatMark(val text: String, val color: Color, val tag: String)

/** Uses existing resolved sidecars, never a parallel matching system. */
internal fun Song.formatMarks(embeddedLyrics: Boolean = false): List<FormatMark> = buildList {
    if (cdg != null) add(FormatMark("CDG", Color.Green, "cdgFileType"))
    if (isMidi) add(FormatMark(mp3.extension().uppercase(Locale.ROOT), MonsterPurple, "midiFileType"))
    if (isYoutubeLink) add(FormatMark("YT", Color.Red, "youtubeFileType"))
    if (chords != null) add(FormatMark("CHORDS", MonsterGreen, "chordsFileType"))
    if (embeddedLyrics) add(FormatMark("LYR3", Color.Red, "embeddedLyricsType"))
    text?.let { sidecar ->
        val type = sidecar.extension().uppercase(Locale.ROOT)
        val color = when (type) {
            "LRC" -> Color.Yellow
            "TXT" -> Color(0xFF4D9DFF)
            "SRT" -> Color(0xFFB97836)
            "LYR3" -> Color.Red
            else -> Color.Cyan
        }
        add(FormatMark(type, color, "lyricsSidecarType"))
    }
}

@Composable
internal fun SongFormatLabels(marks: List<FormatMark>) {
    if (marks.isEmpty()) return
    Column(
        Modifier.width(68.dp).padding(start = 8.dp, end = 4.dp),
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        marks.forEach { mark ->
            Box(Modifier.fillMaxWidth().heightIn(min = 28.dp), contentAlignment = Alignment.CenterEnd) {
                if (mark.text == "YT") YouTubeBadge(Modifier.testTag(mark.tag))
                else Text(mark.text, color = mark.color, fontSize = if (mark.text == "CHORDS") 11.sp else 16.sp, lineHeight = 20.sp,
                    fontWeight = FontWeight.Bold, modifier = Modifier.testTag(mark.tag))
            }
        }
    }
}
