package com.teraphonia.cdglite

import android.content.Intent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.app.PictureInPictureParams
import android.app.PendingIntent
import android.app.RemoteAction
import android.content.res.Configuration
import android.graphics.drawable.Icon
import android.util.Rational
import android.speech.RecognizerIntent
import android.view.WindowManager
import android.widget.Toast
import android.media.AudioManager
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.key.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.zIndex
import androidx.documentfile.provider.DocumentFile
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.PlayerConstants
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.options.IFramePlayerOptions
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.*
import java.net.URLEncoder
import java.util.Locale

internal enum class PopupSize(val fraction: Float) {
    QUARTER(.25f), HALF(.5f), FULL(1f);
    fun next() = entries[(ordinal + 1) % entries.size]
    fun nextLabel() = when (this) { QUARTER -> "1/2"; HALF -> "FULL"; FULL -> "1/4" }
}

class MainActivity : ComponentActivity() {
    private lateinit var playback: PlaybackModel
    private var pipMode by mutableStateOf(false)
    private var compactPip by mutableStateOf(false)
    internal var playbackPopupVisible = false
    private var floatingPlayer: FloatingPlayer? = null
    private var requestingFloatingPermission = false

    fun requestFloatingPermission() {
        requestingFloatingPermission = true
        if (Build.VERSION.SDK_INT >= 31 && ::playback.isInitialized) {
            runCatching { setPictureInPictureParams(buildPipParams(autoEnterOverride = false)) }
        }
        startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    override fun onResume() {
        super.onResume()
        requestingFloatingPermission = false
        floatingPlayer?.hide()
    }

    private val pipReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            handlePipIntent(intent)
            if (isInPictureInPictureMode) setPictureInPictureParams(buildPipParams())
        }
    }

    companion object {
        private const val ACTION_PIP_PREVIOUS = "com.teraphonia.cdglite.PIP_PREVIOUS"
        private const val ACTION_PIP_PLAY_PAUSE = "com.teraphonia.cdglite.PIP_PLAY_PAUSE"
        private const val ACTION_PIP_NEXT = "com.teraphonia.cdglite.PIP_NEXT"
        private const val ACTION_PIP_STOP = "com.teraphonia.cdglite.PIP_STOP"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        volumeControlStream = AudioManager.STREAM_MUSIC
        playback = ViewModelProvider(this)[PlaybackModel::class.java]
        floatingPlayer = FloatingPlayer(this, playback)
        val pipFilter = IntentFilter().apply {
            addAction(ACTION_PIP_PREVIOUS)
            addAction(ACTION_PIP_PLAY_PAUSE)
            addAction(ACTION_PIP_NEXT)
            addAction(ACTION_PIP_STOP)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(pipReceiver, pipFilter, Context.RECEIVER_NOT_EXPORTED)
        else {
            @Suppress("DEPRECATION")
            registerReceiver(pipReceiver, pipFilter)
        }
        setContent { CdgLite(playback, pipMode = pipMode, compactPip = compactPip) }
    }

    override fun onDestroy() {
        floatingPlayer?.hide()
        runCatching { unregisterReceiver(pipReceiver) }
        super.onDestroy()
    }

    private fun pipPendingIntent(action: String, requestCode: Int): PendingIntent =
        PendingIntent.getBroadcast(
            this,
            requestCode,
            Intent(action).setPackage(packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun pipAction(action: String, requestCode: Int, iconRes: Int, title: String): RemoteAction =
        RemoteAction(Icon.createWithResource(this, iconRes), title, title, pipPendingIntent(action, requestCode))

    private fun buildPipParams(autoEnterOverride: Boolean? = null): PictureInPictureParams {
        val playing = playback.karaokeWeb.isPlaying || playback.isPlaying
        val actions = if (compactPip) listOf(RemoteAction(
            Icon.createWithResource(this, R.drawable.karamonster_rex_clean),
            "BACK TO GIGMONSTER", "BACK TO GIGMONSTER",
            PendingIntent.getActivity(this, 105,
                Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        )) else listOf(
            pipAction(ACTION_PIP_PREVIOUS, 101, android.R.drawable.ic_media_previous, "Previous"),
            pipAction(
                ACTION_PIP_PLAY_PAUSE,
                102,
                if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (playing) "Pause" else "Play"
            ),
            pipAction(ACTION_PIP_NEXT, 103, android.R.drawable.ic_media_next, "Next"),
            pipAction(ACTION_PIP_STOP, 104, R.drawable.ic_pip_stop, "Stop")
        )
        val cdgPip = playback.song?.cdg != null && playback.song?.isYoutubeLink != true
        return PictureInPictureParams.Builder()
            // CD+G graphics are 300x216 (25:18). Give them a PiP window close to
            // their native shape instead of forcing the YouTube 16:9 aspect ratio.
            .setAspectRatio(if (compactPip) Rational(239, 100) else if (cdgPip) Rational(25, 18) else Rational(16, 9))
            .setActions(actions)
            .apply {
                if (Build.VERSION.SDK_INT >= 31) {
                    setSeamlessResizeEnabled(true)
                    setAutoEnterEnabled(autoEnterOverride ?: isAutoPipEligible())
                }
            }
            .build()
    }

    private fun hasVisualPipContent(): Boolean {
        val current = playback.song ?: return false
        return current.isYoutubeLink ||
            current.isVideo ||
            current.cdg != null ||
            playback.activeTextSidecar != null ||
            playback.activeEmbeddedLyrics ||
            playback.extractedPreview
    }

    private fun isAutoPipEligible(): Boolean {
        if (!::playback.isInitialized || requestingFloatingPermission) return false
        val web = playback.karaokeWeb
        if (web.isYoutubeWatchFallback) return false
        val hasPlayback = playback.isPlaying || playback.preparing ||
            playback.breakIsPlaying || playback.breakPreparing || web.isPlaying
        return hasPlayback || (playbackPopupVisible && playback.song != null)
    }

    internal fun refreshAutoPipState() {
        if (Build.VERSION.SDK_INT < 31 || !::playback.isInitialized || isInPictureInPictureMode) return
        val eligible = isAutoPipEligible()
        if (eligible) compactPip = !hasVisualPipContent()
        // Prefer GigMonster's own floating PiP whenever overlay permission is available.
        // It preserves the stage tap cycle (small -> half -> full -> app) and lets the
        // compact end-of-song bar use its own fixed small size. System PiP remains the
        // universal fallback when overlay permission is not available.
        val useSystemAutoPip = eligible && !android.provider.Settings.canDrawOverlays(this)
        runCatching { setPictureInPictureParams(buildPipParams(autoEnterOverride = useSystemAutoPip)) }
    }

    private fun handlePipIntent(intent: Intent?) {
        if (!::playback.isInitialized) return
        when (intent?.action) {
            ACTION_PIP_PREVIOUS -> playback.previousGigTrack()
            ACTION_PIP_NEXT -> playback.nextGigTrack()
            ACTION_PIP_PLAY_PAUSE -> {
                if (playback.song?.isYoutubeLink == true) playback.karaokeWeb.togglePause()
                else playback.togglePause()
            }
            ACTION_PIP_STOP -> {
                if (playback.song?.isYoutubeLink == true) playback.karaokeWeb.stop()
                else playback.stop()
            }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (requestingFloatingPermission) return
        val web = playback.karaokeWeb
        // The blocked-embed fallback must remain in GigMonster's existing WebView.
        // Do not turn that handoff into a PiP transition.
        if (web.isYoutubeWatchFallback) return

        val hasPlayback = playback.isPlaying || playback.preparing || playback.breakIsPlaying || playback.breakPreparing || web.isPlaying
        val hasFloatingContent = hasPlayback || (playbackPopupVisible && playback.song != null)
        if (!hasFloatingContent || isInPictureInPictureMode) return

        compactPip = !hasVisualPipContent()

        // On every Android version, prefer our touchable floating PiP when the user has
        // granted overlay permission. This keeps the original one-tap -> half,
        // second-tap -> full, third-tap -> app behaviour. It also gives the compact
        // end-of-song return bar its own fixed dimensions instead of inheriting a
        // system-PiP window size.
        if (android.provider.Settings.canDrawOverlays(this) && floatingPlayer?.show(compactBar = compactPip) == true) return

        // Without overlay permission, Android 12+ uses the platform auto-enter path;
        // Android 8-11 explicitly enters platform PiP here.
        if (Build.VERSION.SDK_INT >= 31) {
            refreshAutoPipState()
            return
        }

        // PiP is presentation only. The same native YouTubePlayerView stays alive;
        // never pause, seek, release or create a new YT session here.
        web.beginYoutubeSurfaceTransfer()
        runCatching { enterPictureInPictureMode(buildPipParams()) }
    }

    internal fun collapsePipAfterPlaybackEnd() {
        if (!isInPictureInPictureMode || compactPip) return
        compactPip = true
        runCatching { setPictureInPictureParams(buildPipParams()) }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        // Entering/leaving PiP only reparents the same native YT view. Playback state
        // is untouched, so there is no audible break and no restart from 0:00.
        playback.karaokeWeb.beginYoutubeSurfaceTransfer()
        pipMode = isInPictureInPictureMode
        if (!isInPictureInPictureMode) {
            compactPip = false
            window.decorView.post { window.decorView.requestLayout() }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun CdgLite(playback: PlaybackModel, libraryRoot: DocumentFile? = null, pipMode: Boolean = false, compactPip: Boolean = false) {
    val context = LocalContext.current
    val focus = LocalFocusManager.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("cdglite", 0) }
    var root by rememberSaveable { mutableStateOf(libraryRoot?.uri?.toString() ?: prefs.getString("root", null)) }
    var path by rememberSaveable { mutableStateOf(arrayListOf<String>()) }
    var breakRoot by rememberSaveable { mutableStateOf(prefs.getString("breakRoot", null)) }
    var breakPath by rememberSaveable { mutableStateOf(arrayListOf<String>()) }
    var breakVisible by rememberSaveable { mutableStateOf(false) }
    var breakFolders by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var breakSongs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var breakLoading by remember { mutableStateOf(false) }
    var breakError by remember { mutableStateOf<String?>(null) }
    var folders by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var texts by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var libraryError by remember { mutableStateOf<String?>(null) }
    var localSearchIndex by remember { mutableStateOf<List<LocalSearchEntry>?>(null) }
    var localSearchIndexRoot by remember { mutableStateOf<String?>(null) }
    var localSearchIndexError by remember { mutableStateOf<String?>(null) }
    var query by rememberSaveable { mutableStateOf("") }
    var submittedQuery by rememberSaveable { mutableStateOf("") }
    var webQuery by rememberSaveable { mutableStateOf("") }
    var karaokeVisible by rememberSaveable { mutableStateOf(false) }
    var lyricsVisible by rememberSaveable { mutableStateOf(false) }
    var chordsVisible by rememberSaveable { mutableStateOf(false) }
    val glupan = playback.karaokeWeb
    val tupan = playback.lyricsWeb
    val chordWeb = playback.chordsWeb
    // Keep the AndroidView composition itself alive when moving between PiP and browser.
    val youtubeSurface = remember(glupan) { movableContentOf { NativeYouTubePlayer(glupan) } }
    LaunchedEffect(pipMode) { glupan.finishPendingYoutubeSurfaceTransfer() }
    LaunchedEffect(pipMode, playback.playbackEndedNaturally) {
        if (pipMode && playback.playbackEndedNaturally) {
            (context as? MainActivity)?.collapsePipAfterPlaybackEnd()
        }
    }
    SideEffect {
        (context as? MainActivity)?.let { activity ->
            activity.playbackPopupVisible = playback.showCdg || karaokeVisible || lyricsVisible || chordsVisible
            activity.refreshAutoPipState()
        }
    }
    if (pipMode) {
        MaterialTheme(colorScheme = monsterColors) {
            Box(Modifier.fillMaxSize().background(Color.Black)) {
                val cdgFrame = playback.frame
                if (compactPip || playback.playbackEndedNaturally) {
                    MiniPlaybackPip(playback)
                } else if (cdgFrame != null && playback.song?.isYoutubeLink != true && !playback.showTextOnly) {
                    // The active decoded output is authoritative, exactly as in the monitor.
                    // Do not rediscover/reclassify the song when the activity enters PiP.
                    CdgFrame(cdgFrame)
                } else if (playback.song?.cdg != null && playback.song?.isYoutubeLink != true) {
                    Text(
                        playback.error ?: "CDG kadar nije spreman • PiP v30",
                        color = Color.White, fontSize = 24.sp,
                        modifier = Modifier.align(Alignment.Center).padding(12.dp)
                    )
                } else if (playback.song?.isVideo == true) {
                    LocalVideo(playback)
                } else if (glupan.isYoutubeWatchFallback) {
                    // If Android was already displaying the app in PiP when the embed
                    // error arrived, keep using the same WebView instance there too.
                    Browser(glupan, visible = true, showExtract = false, onExtract = {})
                } else if (playback.song?.isYoutubeLink == true && glupan.youtubeVideoIdForPlayer() != null) {
                    youtubeSurface()
                } else if (playback.timedLyrics.isNotEmpty()) {
                    TimedLyrics(playback)
                } else {
                    Text(
                        playback.lyricsText ?: "PiP v30 • nema CDG kadra\n${playback.song?.name.orEmpty()}",
                        color = Color.White, fontSize = 28.sp, lineHeight = 36.sp,
                        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)
                    )
                }
            }
        }
        return
    }
    var browserSize by rememberSaveable { mutableStateOf(PopupSize.HALF) }
    var localFullscreen by rememberSaveable { mutableStateOf(false) }
    val audio = remember { context.getSystemService(android.content.Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var volume by remember { mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVolume) }
    val savedFontScale = prefs.getFloat("fontScale", 1f).let { if (it.isFinite()) it.coerceIn(.75f, 2.2f) else 1f }
    var fontScale by remember { mutableFloatStateOf(savedFontScale) }
    var showPinchHint by remember { mutableStateOf(prefs.getBoolean("pinchHintPending", false) && !prefs.getBoolean("pinchHintDone", false)) }
    val listState = rememberLazyListState()
    var refreshFiles by remember { mutableIntStateOf(0) }
    val folderSnapshots = remember(root, refreshFiles) { linkedMapOf<List<String>, Library>() }
    var fileMenu by remember { mutableStateOf<Song?>(null) }
    var fileMenuAllowsMove by remember { mutableStateOf(false) }
    var renameMode by remember { mutableStateOf(false) }
    var renameText by remember { mutableStateOf("") }
    var fileActionError by remember { mutableStateOf<String?>(null) }
    var moveChooserVisible by remember { mutableStateOf(false) }
    var moveFolderPath by remember { mutableStateOf(arrayListOf<String>()) }
    var editingExtract by remember { mutableStateOf(false) }
    var editedLyrics by remember { mutableStateOf("") }
    var editingChordExtract by remember { mutableStateOf(false) }
    var editedChords by remember { mutableStateOf("") }
    var editingTextSidecar by remember { mutableStateOf(false) }
    var editedTextSidecar by remember { mutableStateOf("") }
    var lyricsSearchPromptSong by remember { mutableStateOf<Song?>(null) }
    var embeddedLyricsFiles by remember(root) { mutableStateOf<Map<String, Boolean>>(emptyMap()) }
    var saveYtVisible by rememberSaveable { mutableStateOf(false) }
    var saveYtPath by rememberSaveable { mutableStateOf(arrayListOf<String>()) }
    var saveYtFolders by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var saveYtLoading by remember { mutableStateOf(false) }
    var saveYtError by remember { mutableStateOf<String?>(null) }
    val gigPlaylists = remember { GigPlaylistStore(context) }
    var swipeFeedback by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var swipeFeedbackSequence by remember { mutableIntStateOf(0) }
    var swipeBlinkUri by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(swipeFeedback) {
        if (swipeFeedback != null) { delay(2000); swipeFeedback = null }
    }
    LaunchedEffect(swipeFeedbackSequence) {
        if (swipeBlinkUri != null) { delay(240); swipeBlinkUri = null }
    }
    fun showSwipeFeedback(added: Boolean, playlist: Int) {
        swipeFeedbackSequence++
        swipeFeedback = swipeFeedbackResource(added, playlist) to swipeFeedbackSequence
    }
    var playlistVisible by rememberSaveable { mutableStateOf(false) }
    var playlistTab by rememberSaveable { mutableIntStateOf(gigPlaylists.activeIndex) }
    var showFloatingPermission by remember { mutableStateOf(false) }

    fun openLyricsSearchFor(track: Song) {
        val title = track.name
        if (title.isBlank()) return
        webQuery = title
        focus.clearFocus()
        browserSize = PopupSize.HALF
        karaokeVisible = false
        glupan.close()
        lyricsVisible = true
        playback.showCdg = false
        tupan.open("https://www.google.com/search?q=" + URLEncoder.encode("lyrics $title -site:youtube.com -site:youtu.be -site:music.youtube.com -site:vimeo.com -site:dailymotion.com -site:tiktok.com", "UTF-8"))
    }

    fun openChordSearch() {
        val title = playback.song?.name?.takeIf { it.isNotBlank() }
            ?: glupan.currentYoutubeTitle()?.takeIf { it.isNotBlank() }
            ?: webQuery.takeIf { it.isNotBlank() }
        if (title == null) {
            Toast.makeText(context, "Prvo izaberi numeru.", Toast.LENGTH_SHORT).show()
            return
        }
        focus.clearFocus()
        browserSize = PopupSize.HALF
        karaokeVisible = false
        lyricsVisible = false
        tupan.close()
        playback.showCdg = false
        chordsVisible = true
        chordWeb.open("https://www.google.com/search?q=" + URLEncoder.encode("$title chords akordi -site:youtube.com -site:youtu.be", "UTF-8"))
    }

    fun chordAction() {
        if (playback.showSavedChords()) {
            playback.showCdg = true
            karaokeVisible = false
            lyricsVisible = false
            chordsVisible = false
            chordWeb.close()
        } else if (playback.hasChords) {
            playback.toggleChordsLyrics()
            playback.showCdg = true
            karaokeVisible = false
            lyricsVisible = false
            chordsVisible = false
            chordWeb.close()
        } else openChordSearch()
    }

    fun suppressLyricsPromptFor(track: Song) {
        val key = "lyricsPromptDontAskUris"
        val updated = prefs.getStringSet(key, emptySet()).orEmpty().toMutableSet().apply { add(track.mp3.uri.toString()) }
        prefs.edit().putStringSet(key, updated).apply()
    }

    LaunchedEffect(playback.localPlaySerial) {
        val track = playback.song ?: return@LaunchedEffect
        // The automatic question is only for plain local audio with no CDG/text/LYR3 mark.
        // Video, MIDI/KAR, YT and any known sidecar keep their existing visual path.
        if (track.isYoutubeLink || track.isVideo || track.isMidi || track.cdg != null || track.text != null) return@LaunchedEffect

        val uri = track.mp3.uri.toString()
        val hasEmbedded = if (track.mp3.extension() == "mp3") {
            embeddedLyricsFiles[uri] ?: withContext(Dispatchers.IO) { hasEmbeddedLyrics3(context, track.mp3) }.also { found ->
                embeddedLyricsFiles = embeddedLyricsFiles + (uri to found)
            }
        } else false
        if (hasEmbedded) return@LaunchedEffect

        // Do not leave the old empty "Find lyrics online" half-screen behind the question.
        playback.showCdg = false
        val suppressed = prefs.getStringSet("lyricsPromptDontAskUris", emptySet()).orEmpty().contains(uri)
        if (!suppressed) lyricsSearchPromptSong = track
    }

    LaunchedEffect(playback.isPlaying, glupan.isPlaying) {
        if ((playback.isPlaying || glupan.isPlaying) && !android.provider.Settings.canDrawOverlays(context) && !prefs.getBoolean("floatingPermissionExplained", false)) {
            prefs.edit().putBoolean("floatingPermissionExplained", true).apply()
            showFloatingPermission = true
        }
    }
    if (showFloatingPermission) {
        AlertDialog(
            onDismissRequest = { showFloatingPermission = false },
            title = { Text("PiP: tap → ½ screen → FULL → app", fontSize = 26.sp) },
            text = { Text("Allow display over other apps for the floating player.", fontSize = 24.sp) },
            confirmButton = { MonsterButton(onClick = { showFloatingPermission = false; (context as? MainActivity)?.requestFloatingPermission() }) { Text("ALLOW", fontSize = 24.sp) } },
            dismissButton = { MonsterButton(onClick = { showFloatingPermission = false }) { Text("LATER", fontSize = 24.sp) } }
        )
    }
    var playlistHint by remember { mutableStateOf(false) }
    var folderSwipeHint by remember { mutableStateOf(false) }
    LaunchedEffect(root, loading, songs.isNotEmpty()) {
        if (root != null && !loading && songs.isNotEmpty() && !prefs.getBoolean("folderSwipeHintDone", false)) {
            prefs.edit().putBoolean("folderSwipeHintDone", true).apply()
            folderSwipeHint = true
        }
    }
    LaunchedEffect(playlistVisible) {
        if (playlistVisible && !prefs.getBoolean("playlistManualV30Done", false)) {
            prefs.edit().putBoolean("playlistManualV30Done", true).apply()
            playlistHint = true
        }
    }

    fun resolveWorkFolder(relative: List<String>): DocumentFile? {
        var dir = libraryRoot ?: root?.let { DocumentFile.fromTreeUri(context, Uri.parse(it)) } ?: return null
        for (part in relative) dir = dir.findFile(part)?.takeIf { it.isDirectory } ?: return null
        return dir
    }

    LaunchedEffect(folderSwipeHint) {
        if (folderSwipeHint) { delay(8000); folderSwipeHint = false }
    }
    LaunchedEffect(playlistHint) {
        if (playlistHint) { delay(14000); playlistHint = false }
    }
    fun showLibrary() { focus.clearFocus() }
    fun home() {
        showLibrary()
        playlistVisible = false
        breakVisible = false
        breakPath = arrayListOf()
        path = arrayListOf()
        query = ""
        submittedQuery = ""
        localFullscreen = false
        browserSize = PopupSize.HALF
        scope.launch { listState.scrollToItem(0) }
    }
    fun back() {
        showLibrary()
        if (localFullscreen) { localFullscreen = false; return }
        if ((karaokeVisible || lyricsVisible) && browserSize == PopupSize.FULL) { browserSize = PopupSize.HALF; return }
        if (breakVisible) {
            if (breakPath.isNotEmpty()) breakPath = ArrayList(breakPath.dropLast(1))
            else breakVisible = false
            return
        }
        if (path.isNotEmpty()) path = ArrayList(path.dropLast(1))
        query = ""
        submittedQuery = ""
    }
    fun runLocalSearch(raw: String) {
        showLibrary()
        val term = raw.trim()
        query = term
        submittedQuery = term
        scope.launch { listState.scrollToItem(0) }
    }
    fun localSearch() = runLocalSearch(query)
    fun runWebSearch(raw: String) {
        val term = raw.trim()
        if (term.isBlank()) return
        webQuery = term
        focus.clearFocus()
        playback.showCdg = false
        localFullscreen = false
        browserSize = PopupSize.HALF
        lyricsVisible = false
        tupan.close()
        karaokeVisible = true
        // GLUPAN: YouTube karaoke search; selected videos are redirected to the official embed player.
        val karaokeQuery = "karaoke $term"
        glupan.open("https://www.youtube.com/results?search_query=" + URLEncoder.encode(karaokeQuery, "UTF-8"))
    }
    fun webSearch() = runWebSearch(webQuery)
    fun externalScreen() {
        val manager = context.getSystemService(android.content.Context.DISPLAY_SERVICE) as android.hardware.display.DisplayManager
        val display = manager.getDisplays(android.hardware.display.DisplayManager.DISPLAY_CATEGORY_PRESENTATION).firstOrNull()
        if (display == null) {
            Toast.makeText(context, "Connect an external monitor or TV to use EXT.", Toast.LENGTH_LONG).show()
        } else {
            // UI hook is ready. The dedicated external karaoke Presentation will attach here.
            Toast.makeText(context, "EXT screen ready: ${display.name}", Toast.LENGTH_SHORT).show()
        }
    }
    fun openBreak() {
        showLibrary()
        breakPath = arrayListOf()
        breakVisible = true
        karaokeVisible = false
        lyricsVisible = false
        playback.showCdg = false
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
                    .getOrElse { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                root = uri.toString()
                val firstPinchPending = !prefs.getBoolean("pinchHintDone", false)
                prefs.edit()
                    .putString("root", root)
                    .putBoolean("pinchHintPending", firstPinchPending)
                    .apply()
                showPinchHint = firstPinchPending
                home()
            } catch (_: SecurityException) { libraryError = "Nije odobren pristup folderu." }
        }
    }
    val breakPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
                    .getOrElse { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                breakRoot = uri.toString()
                prefs.edit().putString("breakRoot", breakRoot).apply()
                openBreak()
            } catch (_: SecurityException) { breakError = "Nije odobren pristup BREAK folderu." }
        }
    }
    val localVoice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let(::runLocalSearch)
    }
    val webVoice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let(::runWebSearch)
    }
    fun voiceIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_PROMPT, "Naziv pjesme")
    }
    fun voice(web: Boolean) {
        try { if (web) webVoice.launch(voiceIntent()) else localVoice.launch(voiceIntent()) }
        catch (_: android.content.ActivityNotFoundException) { libraryError = "Glasovna pretraga nije dostupna na ovom uređaju." }
    }

    LaunchedEffect(saveYtVisible, saveYtPath, root) {
        if (!saveYtVisible) return@LaunchedEffect
        saveYtLoading = true
        saveYtError = null
        try {
            saveYtFolders = withContext(Dispatchers.IO) {
                resolveWorkFolder(saveYtPath)?.listFiles()?.filter { it.isDirectory }?.sortedBy { it.name?.lowercase(Locale.ROOT) } ?: emptyList()
            }
        } catch (_: Exception) {
            saveYtFolders = emptyList()
            saveYtError = "Folder nije dostupan."
        } finally { saveYtLoading = false }
    }

    LaunchedEffect(Unit) {
        playback.setVolume(1f)
        while (isActive) {
            volume = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVolume
            delay(300)
        }
    }
    // Build one deep index in the background for the selected root. Subsequent local
    // searches are instant in-memory filters instead of another full SAF traversal.
    LaunchedEffect(root, refreshFiles) {
        // Let surface handoff/first visible frame finish before restarting deep SD work.
        delay(500)
        val target = root
        localSearchIndex = null
        localSearchIndexRoot = target
        localSearchIndexError = null
        if (target != null) {
            try {
                val rootDir = libraryRoot ?: DocumentFile.fromTreeUri(context, Uri.parse(target)) ?: error("Missing folder")
                localSearchIndex = buildLocalSearchIndex(rootDir)
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) {
                localSearchIndex = emptyList()
                localSearchIndexError = "Local search indeks nije mogao da se učita. Izaberi FOLDER ponovo."
            }
        }
    }

    // Do not make ordinary folder browsing depend on the background deep-search index.
    // On slow/removable SD storage the old dependency caused a second visible rescan when
    // the index completed; because the lists were cleared first, folders/files disappeared
    // for a few seconds. Only a submitted search should observe index changes.
    val visibleSearchIndexKey: Any? = if (submittedQuery.isNotBlank()) localSearchIndex else null
    val visibleSearchRootKey: Any? = if (submittedQuery.isNotBlank()) localSearchIndexRoot else null
    LaunchedEffect(path, root, submittedQuery, visibleSearchIndexKey, visibleSearchRootKey, refreshFiles) {
        libraryError = null
        val target = root
        if (target == null) {
            folders = emptyList()
            songs = emptyList()
            texts = emptyList()
            loading = false
            return@LaunchedEffect
        }

        // If the user searches immediately after opening the app, keep the current browser
        // visible and show progress until the one-time background index is ready.
        if (submittedQuery.isNotBlank() && (localSearchIndexRoot != target || localSearchIndex == null)) {
            loading = true
            return@LaunchedEffect
        }

        val folderKey = path.toList()
        if (submittedQuery.isBlank()) folderSnapshots[folderKey]?.let { cached ->
            folders = cached.folders
            songs = cached.songs
            texts = cached.texts
        }
        loading = true
        try {
            if (submittedQuery.isNotBlank()) {
                val newSongs = searchLocalIndex(localSearchIndex.orEmpty(), submittedQuery)
                folders = emptyList()
                songs = newSongs
                texts = emptyList()
            } else {
                val result = withContext(Dispatchers.IO) {
                    var dir = libraryRoot ?: DocumentFile.fromTreeUri(context, Uri.parse(target)) ?: error("Missing folder")
                    for (name in path) { dir = dir.findFile(name) ?: error("Missing folder") }
                    scanFolder(dir, "")
                }
                folderSnapshots[folderKey] = result
                if (folderSnapshots.size > 24) folderSnapshots.remove(folderSnapshots.keys.first())
                // Atomic-looking swap: keep the previous SD-card contents on screen until
                // the replacement scan has completed successfully.
                folders = result.folders
                songs = result.songs
                texts = result.texts
            }
        } catch (e: CancellationException) { throw e }
        catch (_: Exception) {
            // A removable SD card can have short provider hiccups. Keep the last successful
            // browser snapshot instead of flashing an empty library.
            libraryError = "SD/folder refresh kasni — prikazujem zadnje uspješno učitavanje."
        }
        finally { loading = false }
    }
    LaunchedEffect(songs, refreshFiles) {
        for (track in songs) {
            val uri = track.mp3.uri.toString()
            if (track.mp3.extension() == "mp3" && uri !in embeddedLyricsFiles) {
                val found = withContext(Dispatchers.IO) { hasEmbeddedLyrics3(context, track.mp3) }
                embeddedLyricsFiles = embeddedLyricsFiles + (uri to found)
            }
        }
    }
    LaunchedEffect(breakVisible, breakRoot, breakPath, refreshFiles) {
        if (!breakVisible) return@LaunchedEffect
        // Keep the last successful BREAK listing visible while removable storage refreshes.
        breakError = null
        val target = breakRoot
        if (target == null) {
            breakLoading = false
            return@LaunchedEffect
        }
        breakLoading = true
        try {
            val result = withContext(Dispatchers.IO) {
                var dir = DocumentFile.fromTreeUri(context, Uri.parse(target)) ?: error("Missing BREAK folder")
                for (name in breakPath) dir = dir.findFile(name) ?: error("Missing BREAK subfolder")
                scanFolder(dir, "")
            }
            breakFolders = result.folders
            breakSongs = result.songs.filterNot { it.isYoutubeLink }
        } catch (e: CancellationException) { throw e }
        catch (_: Exception) { breakError = "BREAK folder nije dostupan. Drži BREAK da izabereš ponovo." }
        finally { breakLoading = false }
    }

    DisposableEffect(playback.isPlaying, glupan.isPlaying, playback.breakIsPlaying) {
        val window = (context as? ComponentActivity)?.window
        if (playback.isPlaying || glupan.isPlaying || playback.breakIsPlaying) window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }
    BackHandler(true) { back() }

    MaterialTheme(colorScheme = monsterColors) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize().background(Color.Black).safeDrawingPadding().imePadding()) {
            BoxWithConstraints(Modifier.fillMaxWidth()) {
            val navWidth = (maxWidth * .24f).coerceAtMost(144.dp)
            val navTone = MonsterButtonTone.GREEN
            val navAccent = if (navTone == MonsterButtonTone.PURPLE) MonsterPurple else MonsterGreen
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                MonsterButton(
                    onClick = { if (playlistVisible || breakVisible) home() else if (root == null) picker.launch(null) else home() },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    modifier = Modifier.width(navWidth).height(56.dp).testTag("home"),
                    tone = navTone
                ) {
                    if (root != null || breakVisible) {
                        Text("⌂", fontSize = 25.sp, fontWeight = FontWeight.Black, color = if (navTone == MonsterButtonTone.PURPLE) Color(0xFFFFD84A) else navAccent)
                        Spacer(Modifier.width(6.dp))
                    }
                    Text(if (root == null && !breakVisible) "SELECT FOLDER" else "HOME", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                MonsterButton(
                    onClick = { back() },
                    enabled = if (breakVisible) true else path.isNotEmpty() || localFullscreen || ((karaokeVisible || lyricsVisible) && browserSize == PopupSize.FULL),
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier.width(navWidth).height(56.dp).testTag("back"),
                    tone = navTone
                ) { Text("‹", fontSize = 40.sp, fontWeight = FontWeight.Bold) }
                Slider(
                    value = volume,
                    onValueChange = { volume = it; audio.setStreamVolume(AudioManager.STREAM_MUSIC, (it * maxVolume).toInt(), 0) },
                    modifier = Modifier.weight(1f).testTag("mainVolume"),
                    colors = SliderDefaults.colors(
                        thumbColor = navAccent,
                        activeTrackColor = navAccent,
                        inactiveTrackColor = if (navTone == MonsterButtonTone.PURPLE) Color(0xFF514663) else Color(0xFF32412D)
                    )
                )
                MonsterButton(
                    onClick = { if (breakVisible) breakPicker.launch(null) else picker.launch(null) },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    modifier = Modifier.width(navWidth).height(56.dp).testTag("folder"),
                    tone = navTone
                ) {
                    if (!breakVisible) { Text("📁", fontSize = 18.sp); Spacer(Modifier.width(5.dp)) }
                    Text(if (breakVisible) "CHANGE" else "FOLDER", fontWeight = FontWeight.Bold)
                }
            }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp)) {
                StoneButton(
                    onClick = { playlistVisible = !playlistVisible; playlistTab = gigPlaylists.activeIndex },
                    modifier = Modifier.fillMaxWidth().height(62.dp).testTag("playlistToggle"),
                    active = playlistVisible
                ) {
                    Text(if (playlistVisible) "EXIT PLAYLIST" else "PLAYLIST  •  P${gigPlaylists.activeIndex + 1}", color = if (playlistVisible) MonsterGreen else Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                }
            }
            // CDG is part of the layout, not an overlay: the song list ends at its top edge.
            Column(Modifier.weight(1f).fillMaxWidth()) {
                BoxWithConstraints((if (localFullscreen && playback.showCdg) Modifier.height(0.dp) else Modifier.weight(1f)).fillMaxWidth()) {
                // WEB and online-LYRICS panels overlay this browser area. Give the library
                // matching scroll room so the final folder/song can be moved fully above
                // the open popup instead of remaining hidden underneath it.
                val browserPopupOpen = (karaokeVisible && glupan.opened) || (lyricsVisible && tupan.opened)
                val libraryPopupBottomPadding = if (browserPopupOpen && browserSize != PopupSize.FULL) {
                    maxHeight * browserSize.fraction
                } else 0.dp
                if (breakVisible) {
                    BreakBrowser(
                        folders = breakFolders,
                        songs = breakSongs,
                        loading = breakLoading,
                        error = breakError,
                        path = breakPath,
                        playback = playback,
                        fileActions = { track -> fileMenu = track; fileMenuAllowsMove = false; renameMode = false; fileActionError = null },
                        openFolder = { dir ->
                            dir.name?.let { name -> breakPath = ArrayList(breakPath + name) }
                        },
                        playSong = { song ->
                            playback.showCdg = false
                            playback.startBreakPlaylist(breakSongs.map { it.mp3 }, song.mp3)
                        },
                        modifier = Modifier.matchParentSize().zIndex(50f)
                    )
                }
                if (!breakVisible) {
                val artworkReduced = playback.showCdg || browserPopupOpen
                if (path.isEmpty() && submittedQuery.isEmpty()) HomeStageBackground(
                    modifier = Modifier.align(Alignment.BottomEnd).fillMaxHeight(.92f)
                        .fillMaxWidth(if (artworkReduced) 1f else .74f)
                        .padding(end = if (artworkReduced) 148.dp else 0.dp),
                    popupAdjacent = artworkReduced
                )
                Column(Modifier.fillMaxSize().padding(horizontal = 10.dp)) {
                    if (path.isEmpty() && submittedQuery.isEmpty()) MonsterBrand()
                    if (path.isEmpty()) {
                        SearchRow(query, { query = it; if (it.isEmpty()) submittedQuery = "" }, "LOCAL SEARCH — FILES", "local", ::localSearch, { voice(false) }, MonsterButtonTone.GREEN)
                        SearchRow(webQuery, { webQuery = it }, "WEB KARAOKE SEARCH", "web", ::webSearch, { voice(true) }, MonsterButtonTone.GREEN)
                    }
                    val message = playback.error ?: libraryError ?: localSearchIndexError
                    if (message != null) Text(message, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp))
                    if (folderSwipeHint && !playlistVisible) {
                        GestureManual(R.drawable.folder_swipe_hint, Modifier.fillMaxWidth().height(120.dp))
                    }
                    if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                    if (submittedQuery.isNotEmpty() || path.isNotEmpty()) {
                        Text(if (submittedQuery.isNotEmpty()) "${songs.size} rezultata u svim podfolderima" else "${folders.size} foldera • ${songs.size} pjesama", fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
                    }
                    LazyColumn(
                        state = listState,
                        contentPadding = PaddingValues(bottom = libraryPopupBottomPadding),
                        modifier = Modifier.fillMaxSize().testTag("library").pointerInput(Unit) {
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false)
                                var pinching = false
                                do {
                                    val event = awaitPointerEvent()
                                    if (event.changes.count { it.pressed } >= 2) {
                                        pinching = true
                                        val zoom = event.calculateZoom()
                                        if (zoom.isFinite() && zoom > 0f) {
                                            val nextScale = fontScale * zoom
                                            fontScale = if (nextScale.isFinite()) nextScale.coerceIn(.75f, 2.2f) else 1f
                                            prefs.edit().putFloat("fontScale", fontScale).apply()
                                        }
                                        event.changes.forEach { it.consume() }
                                    }
                                } while (event.changes.any { it.pressed })
                                if (pinching) {
                                    val finishPinchHint = showPinchHint || prefs.getBoolean("pinchHintPending", false)
                                    if (finishPinchHint) showPinchHint = false
                                    val edit = prefs.edit().putFloat("fontScale", fontScale)
                                    if (finishPinchHint) {
                                        edit.putBoolean("pinchHintDone", true)
                                            .putBoolean("pinchHintPending", false)
                                    }
                                    edit.commit()
                                }
                            }
                        }
                    ) {
                        if (!loading && folders.isEmpty() && songs.isEmpty() && texts.isEmpty()) item {
                            Text(if (root == null) "Izaberi FOLDER sa muzikom." else "Nema pjesama. Pretraži drugi naziv ili izaberi folder.", modifier = Modifier.padding(16.dp))
                        }
                        itemsIndexed(folders, key = { _, item -> item.uri.toString() }) { index, dir ->
                            Row(Modifier.fillMaxWidth().monsterRow(), verticalAlignment = Alignment.CenterVertically) {
                                MonsterFolderIcon()
                                Text(
                                    text = dir.name ?: "Folder",
                                    color = Color.White,
                                    fontSize = (26 * fontScale).sp,
                                    lineHeight = (36 * fontScale).sp,
                                    softWrap = true,
                                    modifier = Modifier.weight(1f).clickable {
                                        path = ArrayList(path + (dir.name ?: return@clickable)); query = ""; submittedQuery = ""
                                        focus.clearFocus(); scope.launch { listState.scrollToItem(0) }
                                    }.padding(16.dp)
                                )
                                if (index == 0 && path.isEmpty() && submittedQuery.isEmpty()) {
                                    BreakButton(
                                        onClick = { if (breakRoot == null) breakPicker.launch(null) else openBreak() },
                                        onLongClick = { breakPicker.launch(null) }
                                    )
                                }
                            }
                        }
                        items(songs, key = { it.mp3.uri.toString() }) { song ->
                            val isActiveSong = playback.song?.mp3?.uri == song.mp3.uri
                            val isActivePlaying = if (song.isYoutubeLink) {
                                isActiveSong && glupan.isPlaying
                            } else {
                                isActiveSong && (playback.isPlaying || playback.preparing)
                            }
                            Row(Modifier.fillMaxWidth().monsterRow()
                                .background(if (swipeBlinkUri == song.mp3.uri.toString()) MonsterGreen.copy(alpha = .55f) else if (isActivePlaying) Color(0xFF383838) else Color.Transparent)
                                .pointerInput(song.mp3.uri.toString(), gigPlaylists.activeIndex) {
                                    var dx = 0f
                                    detectHorizontalDragGestures(
                                        onDragStart = { dx = 0f },
                                        onHorizontalDrag = { change, amount -> dx += amount; if (kotlin.math.abs(dx) > 12f) change.consume() },
                                        onDragEnd = {
                                            if (dx > 90.dp.toPx()) {
                                                val added = gigPlaylists.add(song)
                                                if (added) {
                                                    swipeBlinkUri = song.mp3.uri.toString()
                                                    showSwipeFeedback(true, gigPlaylists.activeIndex + 1)
                                                } else Toast.makeText(context, "Već je u P${gigPlaylists.activeIndex + 1}", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    )
                                }
                                .combinedClickable(onLongClick = { fileMenu = song; fileMenuAllowsMove = true; renameMode = false; fileActionError = null }, onClick = {
                                showLibrary()
                                karaokeVisible = false
                                lyricsVisible = false
                                localFullscreen = false
                                if (song.isYoutubeLink) {
                                    playback.clearGigQueue()
                                    lyricsVisible = false
                                    tupan.close()
                                    karaokeVisible = true
                                    browserSize = PopupSize.HALF
                                    if (!playback.startYoutubeLink(song)) libraryError = "Sačuvani YT link nije dostupan."
                                } else if (playback.song?.mp3?.uri == song.mp3.uri && (playback.isPlaying || playback.preparing)) playback.stop()
                                else { playback.startLocal(song) }
                            }).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    song.name,
                                    color = Color.White,
                                    fontSize = (26 * fontScale).sp,
                                    lineHeight = (36 * fontScale).sp,
                                    softWrap = true,
                                    modifier = Modifier.weight(1f)
                                )
                                if (isActiveSong) Box(
                                    modifier = Modifier.padding(start = 8.dp).size(26.dp).testTag("activeTrackState"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(if (isActivePlaying) "▶" else "■", fontSize = 14.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                }
                                SongFormatLabels(song.formatMarks(embeddedLyricsFiles[song.mp3.uri.toString()] == true))
                            }
                        }
                    }
                }
                }
                if (playlistVisible && !breakVisible) {
                    val shownPlaylist = playlistTab
                    GigPlaylistPopup(
                        store = gigPlaylists,
                        refreshKey = refreshFiles,
                        selected = playlistTab,
                        onSelected = { playlistTab = it },
                        showHint = playlistHint,
                        onGestureLearned = { playlistHint = false; prefs.edit().putBoolean("playlistMoveHintDone", true).apply() },
                        onSwipeRemoved = { playlist -> showSwipeFeedback(false, playlist) },
                        nextEnabled = playback.gigNextEnabled,
                        onToggleNext = { playback.toggleGigNext() },
                        onRemoved = { uris -> if (playback.gigPlaylistId == shownPlaylist) playback.removeFromGigQueue(uris) },
                        activeMediaUri = playback.song?.mp3?.uri?.toString(),
                        activePlaying = if (playback.song?.isYoutubeLink == true) glupan.isPlaying else (playback.isPlaying || playback.preparing),
                        onPlay = { index, ghost ->
                            val resolved = gigPlaylists.lists[playlistTab].mapNotNull { it.toSong(context) }
                            val targetIndex = resolved.indexOfFirst { it.mp3.uri.toString() == ghost.mediaUri }
                            if (targetIndex >= 0) {
                                val song = resolved[targetIndex]
                                if (song.isYoutubeLink) {
                                    lyricsVisible = false
                                    tupan.close()
                                    karaokeVisible = true
                                    browserSize = PopupSize.HALF
                                }
                                playback.startGigPlaylist(resolved, targetIndex, playlistTab)
                            }
                        },
                        modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().fillMaxHeight().zIndex(85f)
                    )                }
                swipeFeedback?.let { (resource, sequence) ->
                    key(sequence) {
                        GestureManual(resource, Modifier.align(Alignment.TopCenter).fillMaxWidth().height(128.dp).zIndex(110f))
                    }
                }
                if (showPinchHint && !breakVisible && path.isEmpty() && submittedQuery.isEmpty() && !glupan.opened && !tupan.opened && !chordWeb.opened) {
                    PinchZoomHint(Modifier.align(Alignment.Center).zIndex(70f))
                }
                // GLUPAN: karaoke browser. No EXTRACT button exists on this path.
                if (glupan.opened && !breakVisible) {
                    WebPanel(visible = karaokeVisible, size = browserSize) {
                        Browser(glupan, karaokeVisible, showExtract = false, onExtract = {}, youtubeSurface = youtubeSurface)
                        if (karaokeVisible) {
                            glupan.message?.let { Text(it, modifier = Modifier.align(Alignment.BottomCenter).background(Color.Black.copy(alpha = .8f)).padding(8.dp)) }
                        }
                    }
                }
                // TUPAN: lyrics-only browser. The proven extract filter lives only here.
                if (tupan.opened && !breakVisible) {
                    WebPanel(visible = lyricsVisible, size = browserSize) {
                        Browser(tupan, lyricsVisible, showExtract = true, onExtract = {
                            tupan.extractLyrics { extracted ->
                                if (extracted != null && playback.previewExtractedLyrics(extracted)) {
                                    lyricsVisible = false
                                    tupan.close()
                                    playback.showCdg = true
                                } else Toast.makeText(context, "Lyrics nisu pronađeni na ovoj stranici", Toast.LENGTH_LONG).show()
                            }
                        }, onBack = { tupan.goBack() })
                        if (lyricsVisible) {
                            tupan.message?.let { Text(it, modifier = Modifier.align(Alignment.BottomCenter).background(Color.Black.copy(alpha = .8f)).padding(8.dp)) }
                        }
                    }
                }
                if (chordWeb.opened && !breakVisible) {
                    WebPanel(visible = chordsVisible, size = browserSize) {
                        Browser(chordWeb, chordsVisible, showExtract = true, onExtract = {
                            chordWeb.extractChords { extracted ->
                                if (extracted != null && playback.previewExtractedChords(extracted)) {
                                    chordsVisible = false
                                    chordWeb.close()
                                    playback.showCdg = true
                                } else Toast.makeText(context, "Chords nisu pronađeni na ovoj stranici", Toast.LENGTH_LONG).show()
                            }
                        }, onBack = { chordWeb.goBack() })
                        if (chordsVisible) {
                            chordWeb.message?.let { Text(it, modifier = Modifier.align(Alignment.BottomCenter).background(Color.Black.copy(alpha = .8f)).padding(8.dp)) }
                        }
                    }
                }
                }
                // Local monitor button is authoritative: when showCdg is false, the
                // CDG/TXT/LRC/SRT/LYR3 half-screen panel must really leave the layout.
                if (playback.showCdg && !breakVisible) {
                    CdgSurface(
                        showRexBackground = playback.song?.cdg != null || playback.activeTextSidecar != null || playback.activeEmbeddedLyrics || playback.extractedPreview
                    ) {
                        val bitmap = playback.frame
                        if (playback.showChords && playback.hasChords) {
                            LyricsFontPanel(
                                modifier = Modifier.fillMaxSize(),
                                railControls = {
                                    ChordsSyncEditControls(
                                        playback = playback,
                                        onView = if (!playback.syncEditActive) playback::cycleLyricsViewMode else null,
                                        onTextEdit = { editedChords = playback.chordsText.orEmpty(); editingChordExtract = true }
                                    )
                                }
                            ) {
                                if (playback.syncEditActive && playback.syncEditingChords) SyncEditLyrics(playback)
                                else if (playback.timedChords.isNotEmpty()) TimedChords(playback)
                                else Column(Modifier.fillMaxSize()) {
                                    Text(
                                        playback.chordsText.orEmpty(),
                                        color = Color.White,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = LocalLyricsFontSize.current.sp,
                                        lineHeight = (LocalLyricsFontSize.current * 1.3125f).sp,
                                        modifier = Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState()).padding(14.dp).testTag("chordsText")
                                    )
                                    if (playback.chordsPreview) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        MonsterButton(onClick = { editedChords = playback.chordsText.orEmpty(); editingChordExtract = true }, modifier = Modifier.weight(1f).testTag("editExtractedChords")) { Text("EDIT", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
                                        MonsterButton(
                                            onClick = {
                                                val text = playback.chordsText.orEmpty()
                                                if (playback.saveExtractedChords(text)) { refreshFiles++; Toast.makeText(context, "Chords saved", Toast.LENGTH_SHORT).show() }
                                                else Toast.makeText(context, "Chords nisu sačuvani", Toast.LENGTH_LONG).show()
                                            },
                                            modifier = Modifier.weight(1f).padding(vertical = 8.dp).testTag("saveExtractedChords")
                                        ) { Text("SAVE", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
                                    }
                                }
                            }
                        } else if (playback.song?.cdg != null) {
                            if (bitmap != null) CdgFrame(bitmap)
                            else Text(playback.error ?: "Učitavanje CDG…", color = Color.White, modifier = Modifier.align(Alignment.Center))
                        } else if (playback.song?.isVideo == true && !playback.showTextOnly) {
                            LocalVideo(
                                playback,
                                onTextEdit = {
                                    val raw = playback.loadActiveTextForEdit()
                                    if (raw != null) {
                                        editedTextSidecar = raw
                                        editingTextSidecar = true
                                    } else {
                                        Toast.makeText(context, "Text file is not available for editing.", Toast.LENGTH_LONG).show()
                                    }
                                }
                            )
                        } else if (playback.activeTextSidecar != null || playback.activeEmbeddedLyrics || playback.extractedPreview) {
                            LyricsFontPanel(
                                modifier = Modifier.fillMaxSize(),
                                railControls = {
                                    if (playback.syncEditSupported) {
                                        SyncEditControls(
                                            playback = playback,
                                            onView = if (!playback.syncEditActive) playback::cycleLyricsViewMode else null,
                                            onTextEdit = {
                                                val raw = playback.loadActiveTextForEdit()
                                                if (raw != null) {
                                                    editedTextSidecar = raw
                                                    editingTextSidecar = true
                                                } else {
                                                    Toast.makeText(context, "Text file is not available for editing.", Toast.LENGTH_LONG).show()
                                                }
                                            }
                                        )
                                    }
                                }
                            ) {
                                if (playback.syncEditActive) SyncEditLyrics(playback)
                                else if (playback.timedLyrics.isNotEmpty()) TimedLyrics(playback)
                                else Column(Modifier.fillMaxSize()) {
                                    key(playback.activeTextSidecar?.uri, playback.activeEmbeddedLyrics, playback.lyricsText) {
                                        Text(playback.lyricsText ?: "Učitavanje…", color = Color.White, fontSize = LocalLyricsFontSize.current.sp, lineHeight = (LocalLyricsFontSize.current * 1.3125f).sp,
                                            modifier = Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState()).padding(14.dp).testTag("lyricsText"))
                                    }
                                    if (playback.extractedPreview) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        MonsterButton(onClick = { editedLyrics = playback.lyricsText.orEmpty(); editingExtract = true }, modifier = Modifier.weight(1f).testTag("editExtractedLyrics")) { Text("EDIT", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
                                        MonsterButton(
                                            onClick = {
                                                val text = playback.lyricsText.orEmpty()
                                                if (playback.saveExtractedLyrics(text)) Toast.makeText(context, "Lyrics saved", Toast.LENGTH_SHORT).show()
                                                else Toast.makeText(context, "Lyrics nisu sačuvani", Toast.LENGTH_LONG).show()
                                            },
                                            modifier = Modifier.weight(1f).padding(vertical = 8.dp).testTag("saveExtractedLyrics")
                                        ) { Text("SAVE", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
                                    }
                                }
                            }
                        } else if (bitmap != null) CdgFrame(bitmap)
                        else if (playback.song?.cdg != null) Text("Učitavanje CDG…", modifier = Modifier.align(Alignment.Center))
                        else if (playback.song?.isMidi == true) Text(
                            "No embedded lyrics",
                            color = Color.White.copy(alpha = .7f),
                            fontSize = 18.sp,
                            modifier = Modifier.align(Alignment.Center).testTag("noEmbeddedMidiLyrics")
                        )
                        else MonsterButton(
                            onClick = { playback.song?.let(::openLyricsSearchFor) },
                            modifier = Modifier.align(Alignment.Center).testTag("findLyricsOnline")
                        ) { Text("Find lyrics online", fontSize = 22.sp) }
                    }
                }
            }
            if (breakVisible) BreakPlaybackBar(playback)
            else if (playback.breakTrack != null) { /* BREAK continues silently in the background UI. */ }
            else if (chordWeb.opened) LyricsBrowserBar(
                label = "CHORDS",
                monitor = {
                    chordsVisible = !chordsVisible
                    if (!chordsVisible) browserSize = PopupSize.HALF
                },
                visible = chordsVisible,
                back = {
                    if (!chordWeb.goBack()) {
                        chordsVisible = false
                        chordWeb.close()
                        browserSize = PopupSize.HALF
                        playback.showCdg = playback.song != null
                    }
                },
                toggleFullscreen = {
                    chordsVisible = true
                    browserSize = if (browserSize == PopupSize.FULL) PopupSize.HALF else PopupSize.FULL
                },
                isFullscreen = browserSize == PopupSize.FULL,
                externalScreen = ::externalScreen,
                chordLabel = if (playback.showChords && playback.hasChords) "LYRICS" else "CHORDS",
                chordAction = ::chordAction
            )
            else if (tupan.opened) LyricsBrowserBar(
                label = "LYRICS",
                monitor = {
                    lyricsVisible = !lyricsVisible
                    if (!lyricsVisible) browserSize = PopupSize.HALF
                },
                visible = lyricsVisible,
                back = {
                    if (!tupan.goBack()) {
                        lyricsVisible = false
                        tupan.close()
                        browserSize = PopupSize.HALF
                        playback.showCdg = playback.song != null
                    }
                },
                toggleFullscreen = {
                    lyricsVisible = true
                    browserSize = if (browserSize == PopupSize.FULL) PopupSize.HALF else PopupSize.FULL
                },
                isFullscreen = browserSize == PopupSize.FULL,
                externalScreen = ::externalScreen,
                chordLabel = if (playback.showChords && playback.hasChords) "LYRICS" else "CHORDS",
                chordAction = ::chordAction
            )
            else if (glupan.opened && (karaokeVisible || glupan.isPlaying || playback.song == null || playback.song?.isYoutubeLink == true)) WebPlaybackBar(
                controller = glupan,
                playback = playback,
                visible = karaokeVisible,
                monitor = {
                    playback.showCdg = false
                    localFullscreen = false
                    karaokeVisible = !karaokeVisible
                    if (!karaokeVisible) browserSize = PopupSize.HALF
                },
                toggleFullscreen = {
                    karaokeVisible = true
                    browserSize = if (browserSize == PopupSize.FULL) PopupSize.HALF else PopupSize.FULL
                },
                isFullscreen = browserSize == PopupSize.FULL,
                externalScreen = ::externalScreen,
                chordLabel = if (playback.showChords && playback.hasChords) "LYRICS" else "CHORDS",
                chordAction = ::chordAction,
                save = {
                    if (root == null) Toast.makeText(context, "Prvo izaberi radni FOLDER.", Toast.LENGTH_LONG).show()
                    else if (glupan.currentYoutubeUrl() == null) Toast.makeText(context, "Prvo otvori karaoke video.", Toast.LENGTH_SHORT).show()
                    else {
                        saveYtPath = ArrayList(path)
                        saveYtVisible = true
                    }
                },
                back = {
                    if (!glupan.goBack()) { karaokeVisible = false; browserSize = PopupSize.HALF }
                }
            )
            else if (playback.song != null && playback.breakTrack == null) PlaybackBar(
                playback = playback,
                resume = {
                    if (!playback.isPlaying) glupan.stopForLocal()
                    playback.togglePause()
                },
                show = {
                    showLibrary()
                    playback.showCdg = !playback.showCdg
                    if (!playback.showCdg) localFullscreen = false
                },
                toggleFullscreen = {
                    playback.showCdg = true
                    localFullscreen = !localFullscreen
                },
                isFullscreen = localFullscreen,
                externalScreen = ::externalScreen,
                chordLabel = if (playback.showChords && playback.hasChords) "LYRICS" else "CHORDS",
                chordAction = ::chordAction,
                popupVisible = playback.showCdg
            )
        }
        lyricsSearchPromptSong?.let { track ->
            AlertDialog(
                onDismissRequest = { lyricsSearchPromptSong = null },
                title = { Text("SEARCH LYRICS?", fontSize = 26.sp, fontWeight = FontWeight.Bold) },
                text = {
                    Text(
                        "No CDG or lyrics tag was found for:\n${track.name}",
                        fontSize = 22.sp,
                        lineHeight = 29.sp
                    )
                },
                confirmButton = {
                    MonsterButton(onClick = {
                        lyricsSearchPromptSong = null
                        openLyricsSearchFor(track)
                    }) { Text("YES", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
                },
                dismissButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MonsterButton(onClick = {
                            lyricsSearchPromptSong = null
                            playback.showCdg = false
                        }) { Text("NO", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
                        MonsterButton(onClick = {
                            suppressLyricsPromptFor(track)
                            lyricsSearchPromptSong = null
                            playback.showCdg = false
                        }) {
                            Text("DON'T ASK AGAIN", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            )
        }
        if (editingTextSidecar) AlertDialog(
            onDismissRequest = { editingTextSidecar = false },
            title = { Text("TEXT EDIT", fontSize = 24.sp) },
            text = {
                OutlinedTextField(
                    editedTextSidecar,
                    { editedTextSidecar = it },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 240.dp, max = 420.dp).testTag("textSidecarEditor"),
                    textStyle = TextStyle(color = Color.White, fontSize = 24.sp)
                )
            },
            confirmButton = {
                MonsterButton(onClick = {
                    if (playback.saveActiveTextEdit(editedTextSidecar)) {
                        editingTextSidecar = false
                        refreshFiles++
                        Toast.makeText(context, "Text saved", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Could not save text. Check folder write access.", Toast.LENGTH_LONG).show()
                    }
                }) { Text("SAVE") }
            },
            dismissButton = { MonsterButton(onClick = { editingTextSidecar = false }) { Text("CANCEL") } }
        )
        if (editingExtract) AlertDialog(
            onDismissRequest = { editingExtract = false },
            title = { Text("EDIT LYRICS", fontSize = 24.sp) },
            text = { OutlinedTextField(editedLyrics, { editedLyrics = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 240.dp, max = 420.dp).testTag("lyricsEditor"), textStyle = TextStyle(color = Color.White, fontSize = 24.sp)) },
            confirmButton = { MonsterButton(onClick = {
                if (playback.saveExtractedLyrics(editedLyrics, allowEmpty = true)) { editingExtract = false; refreshFiles++ }
                else Toast.makeText(context, "Could not save lyrics. Check folder write access.", Toast.LENGTH_LONG).show()
            }) { Text("SAVE") } },
            dismissButton = { MonsterButton(onClick = { editingExtract = false }) { Text("CANCEL") } }
        )
        if (editingChordExtract) AlertDialog(
            onDismissRequest = { editingChordExtract = false },
            title = { Text("EDIT CHORDS", fontSize = 24.sp) },
            text = { OutlinedTextField(editedChords, { editedChords = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 240.dp, max = 420.dp).testTag("chordsEditor"), textStyle = TextStyle(color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 22.sp)) },
            confirmButton = { MonsterButton(onClick = {
                if (playback.saveExtractedChords(editedChords)) { editingChordExtract = false; refreshFiles++ }
                else Toast.makeText(context, "Could not save chords. Check folder write access.", Toast.LENGTH_LONG).show()
            }) { Text("SAVE") } },
            dismissButton = { MonsterButton(onClick = { editingChordExtract = false }) { Text("CANCEL") } }
        )
        if (saveYtVisible) {
            AlertDialog(
                onDismissRequest = { saveYtVisible = false },
                title = { Text("SAVE YT LINK", fontSize = 24.sp, fontWeight = FontWeight.Bold) },
                text = {
                    Column(Modifier.fillMaxWidth()) {
                        Text(if (saveYtPath.isEmpty()) "HOME" else saveYtPath.joinToString(" / "), fontSize = 18.sp, color = MonsterGreen)
                        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                            MonsterButton(onClick = { if (saveYtPath.isNotEmpty()) saveYtPath = ArrayList(saveYtPath.dropLast(1)) }, enabled = saveYtPath.isNotEmpty()) { Text("‹ UP") }
                            Spacer(Modifier.width(8.dp))
                            Text("Izaberi folder pa SAVE HERE", modifier = Modifier.align(Alignment.CenterVertically))
                        }
                        if (saveYtLoading) LinearProgressIndicator(Modifier.fillMaxWidth())
                        saveYtError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 360.dp)) {
                            items(saveYtFolders, key = { it.uri.toString() }) { dir ->
                                Row(Modifier.fillMaxWidth().monsterRow().clickable { dir.name?.let { saveYtPath = ArrayList(saveYtPath + it) } }, verticalAlignment = Alignment.CenterVertically) {
                                    MonsterFolderIcon()
                                    Text(dir.name ?: "Folder", color = Color.White, fontSize = 22.sp, modifier = Modifier.weight(1f).padding(12.dp))
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    MonsterButton(onClick = {
                        val link = glupan.currentYoutubeUrl()
                        val folder = resolveWorkFolder(saveYtPath)
                        if (link == null || folder == null) {
                            saveYtError = "YT link ili folder nije dostupan."
                        } else scope.launch {
                            val title = glupan.currentYoutubeTitle().takeUnless { it.isNullOrBlank() || it.equals("YouTube", true) } ?: webQuery.ifBlank { "YouTube karaoke" }
                            val baseName = title
                                .replace(Regex("[\\/:*?\"<>|]"), "-")
                                .replace(Regex("\\s+"), " ")
                                .trim().trim('.')
                                .take(120).ifBlank { "YouTube karaoke" }
                            val saved = withContext(Dispatchers.IO) {
                                val wanted = "$baseName.yt"
                                val target = folder.listFiles().firstOrNull { it.isFile && it.name.equals(wanted, true) }
                                    ?: folder.createFile("application/octet-stream", wanted)
                                    ?: return@withContext null
                                context.contentResolver.openOutputStream(target.uri, "wt")?.use { it.write(link.toByteArray(Charsets.UTF_8)) } ?: return@withContext null
                                Song(baseName, target, null, null, folder)
                            }
                            if (saved == null) {
                                saveYtError = "Ne mogu da sačuvam link u ovom folderu."
                            } else {
                                // SAVE means SAVE LINK ONLY. Do not launch lyrics search, change
                                // the active playback item, or interrupt the current YouTube embed.
                                saveYtVisible = false
                                refreshFiles++
                                Toast.makeText(context, "YT LINK SAVED", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }) { Text("SAVE HERE") }
                },
                dismissButton = { MonsterButton(onClick = { saveYtVisible = false }) { Text("CANCEL") } }
            )
        }
        fileMenu?.let { selected ->
            AlertDialog(
                onDismissRequest = { fileMenu = null },
                title = { Text(if (renameMode) "RENAME" else selected.mp3.name.orEmpty(), fontSize = 24.sp) },
                text = {
                    Column {
                        if (renameMode) OutlinedTextField(renameText, { renameText = it }, label = { Text("File name") }, textStyle = TextStyle(fontSize = 22.sp), modifier = Modifier.fillMaxWidth())
                        fileActionError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    }
                },
                confirmButton = { MonsterButton(onClick = {
                    if (!renameMode) { renameMode = true; renameText = selected.mp3.name.orEmpty().substringBeforeLast('.') }
                    else {
                        val name = renameText.trim()
                        if (name.isBlank() || '/' in name || '\\' in name) {
                            fileActionError = "Enter a valid file name."
                        } else scope.launch {
                            if (playback.song?.mp3?.uri == selected.mp3.uri) playback.stop()
                            if (playback.breakTrack?.uri == selected.mp3.uri) playback.stopBreak()
                            val result = withContext(Dispatchers.IO) { renameMediaWithSidecars(selected, name) }
                            if (result == null) { fileMenu = null; refreshFiles++ }
                            else fileActionError = result
                        }
                    }
                }) { Text(if (renameMode) "SAVE" else "RENAME") } },
                dismissButton = {
                    Row {
                        if (!renameMode && fileMenuAllowsMove) MonsterButton(onClick = {
                            moveFolderPath = arrayListOf()
                            moveChooserVisible = true
                            fileActionError = null
                        }) { Text("MOVE TO...") }
                        if (!renameMode) MonsterButton(onClick = {
                            scope.launch {
                                if (playback.song?.mp3?.uri == selected.mp3.uri) playback.stop()
                                if (playback.breakTrack?.uri == selected.mp3.uri) playback.stopBreak()
                                val deleted = withContext(Dispatchers.IO) { runCatching { selected.mp3.delete() }.getOrDefault(false) }
                                if (deleted) { fileMenu = null; refreshFiles++ }
                                else fileActionError = "Could not delete file. Check folder write access."
                            }
                        }) { Text("DELETE") }
                        MonsterButton(onClick = { fileMenu = null }) { Text("CANCEL") }
                    }
                }
            )
        }
        if (moveChooserVisible) {
            val destination = resolveWorkFolder(moveFolderPath)
            val destinationFolders = remember(root, moveFolderPath, refreshFiles) {
                destination?.listFiles()?.filter { it.isDirectory }?.sortedBy { it.name?.lowercase(Locale.ROOT) } ?: emptyList()
            }
            AlertDialog(
                onDismissRequest = { moveChooserVisible = false },
                title = { Text("MOVE TO", fontSize = 24.sp, fontWeight = FontWeight.Bold) },
                text = {
                    Column(Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                        Text("Destination: /" + moveFolderPath.joinToString("/"), color = MonsterGreen, fontSize = 18.sp)
                        Spacer(Modifier.height(8.dp))
                        if (moveFolderPath.isNotEmpty()) {
                            MonsterButton(onClick = { moveFolderPath = ArrayList(moveFolderPath.dropLast(1)) }, modifier = Modifier.fillMaxWidth().height(48.dp)) { Text("⬆  ..") }
                        }
                        Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())) {
                            destinationFolders.forEach { folder ->
                                Text("📁  ${folder.name.orEmpty()}", color = Color.White, fontSize = 21.sp,
                                    modifier = Modifier.fillMaxWidth().clickable { folder.name?.let { moveFolderPath = ArrayList(moveFolderPath + it) } }.padding(12.dp))
                            }
                        }
                        fileActionError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    }
                },
                confirmButton = {
                    MonsterButton(onClick = {
                        val selected = fileMenu
                        val target = destination
                        if (selected == null || target == null) fileActionError = "Destination folder is unavailable."
                        else scope.launch {
                            if (playback.song?.mp3?.uri == selected.mp3.uri) playback.stop()
                            if (playback.breakTrack?.uri == selected.mp3.uri) playback.stopBreak()
                            val result = withContext(Dispatchers.IO) { moveMediaWithSidecars(context, selected, target) }
                            if (result == null) {
                                moveChooserVisible = false
                                fileMenu = null
                                fileActionError = null
                                refreshFiles++
                            } else fileActionError = result
                        }
                    }) { Text("MOVE HERE") }
                },
                dismissButton = { MonsterButton(onClick = { moveChooserVisible = false }) { Text("CANCEL") } }
            )
        }
        if (root == null && !breakVisible) {
            Box(
                Modifier
                    .matchParentSize()
                    .background(Color.Black)
                    .zIndex(1000f)
                    .pointerInput(Unit) {
                        // This full-screen first-run layer prevents the old top-left controls
                        // underneath from receiving taps. The centered button is the only action.
                        awaitPointerEventScope { while (true) awaitPointerEvent() }
                    },
                contentAlignment = Alignment.Center
            ) {
                StoneButton(
                    onClick = { picker.launch(null) },
                    modifier = Modifier.width(300.dp).height(112.dp).testTag("addFolderFirstRun"),
                    active = true
                ) {
                    Text("ADD FOLDER", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black)
                }
            }
        }
        }
    }
}

@Composable
internal fun YouTubeBadge(modifier: Modifier = Modifier) {
    // YouTube play mark: draw the triangle ourselves instead of using a font glyph,
    // so the badge keeps the correct proportions on every Android font/device.
    Canvas(modifier.size(38.dp, 27.dp)) {
        val radius = size.height * 0.22f
        drawRoundRect(
            color = Color(0xFFFF0000),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius)
        )
        val cx = size.width * 0.51f
        val cy = size.height * 0.50f
        val halfH = size.height * 0.23f
        val halfW = size.width * 0.13f
        val play = Path().apply {
            moveTo(cx - halfW, cy - halfH)
            lineTo(cx - halfW, cy + halfH)
            lineTo(cx + halfW, cy)
            close()
        }
        drawPath(play, Color.White)
    }
}

@Composable
private fun BreakButton(onClick: () -> Unit, onLongClick: () -> Unit) {
    Box(
        Modifier
            .padding(start = 8.dp, end = 8.dp)
            .offset(y = 4.dp)
            .size(126.dp, 58.dp)
            .background(Color(0xFF0A100B), RoundedCornerShape(16.dp))
            .border(2.dp, MonsterGreen, RoundedCornerShape(16.dp))
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onClick() },
                    onLongPress = { onLongClick() }
                )
            }
            .testTag("breakButton"),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Text("▶", color = MonsterGreen, fontSize = 27.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.width(8.dp))
            Text("BREAK\nPLAYER", color = Color.White, fontSize = 16.sp, lineHeight = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun BreakModeGlyph(
    glyph: String,
    selected: Boolean,
    description: String,
    tag: String,
    onClick: () -> Unit
) {
    MonsterButton(
        onClick = onClick,
        enabled = true,
        tone = MonsterButtonTone.GREEN,
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
        modifier = Modifier.padding(3.dp).width(112.dp).height(76.dp).testTag(tag)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(glyph, color = if (selected) MonsterGreen else Color.LightGray, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text(description, color = if (selected) MonsterGreen else Color.LightGray, fontSize = 12.sp, maxLines = 1, fontWeight = FontWeight.Bold)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BreakBrowser(
    folders: List<DocumentFile>,
    songs: List<Song>,
    loading: Boolean,
    error: String?,
    path: List<String>,
    playback: PlaybackModel,
    fileActions: (Song) -> Unit,
    openFolder: (DocumentFile) -> Unit,
    playSong: (Song) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.background(Color.Black).padding(horizontal = 10.dp)) {
        Text(
            "BREAK",
            color = MonsterGreen,
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
        )

        Text(
            if (path.isEmpty()) "BREAK folder" else "BREAK / ${path.joinToString(" / ")}",
            fontSize = 14.sp,
            color = Color.LightGray,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        Row(
            Modifier.fillMaxWidth().padding(vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.End
        ) {
            BreakModeGlyph(
                glyph = if (playback.breakRandom) "🔀" else "⇉",
                selected = true,
                description = if (playback.breakRandom) "RANDOM" else "ORDER",
                tag = "breakOrderRandom"
            ) { playback.updateBreakRandom(!playback.breakRandom) }
            BreakModeGlyph(
                glyph = "↻",
                selected = playback.breakRepeat,
                description = if (playback.breakRepeat) "REPEAT ON" else "REPEAT OFF",
                tag = "breakRepeat"
            ) { playback.updateBreakRepeat(!playback.breakRepeat) }
        }

        if (error != null) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp))
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        Text("${folders.size} foldera • ${songs.size} pjesama", fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))

        LazyColumn(Modifier.fillMaxSize().testTag("breakLibrary")) {
            items(folders, key = { it.uri.toString() }) { dir ->
                Row(Modifier.fillMaxWidth().monsterRow().clickable { openFolder(dir) }, verticalAlignment = Alignment.CenterVertically) {
                    MonsterFolderIcon()
                    Text(dir.name ?: "Folder", color = Color.White, fontSize = 26.sp, lineHeight = 36.sp, modifier = Modifier.weight(1f).padding(16.dp))
                }
            }
            items(songs, key = { it.mp3.uri.toString() }) { song ->
                val active = playback.breakTrack?.uri == song.mp3.uri
                Row(
                    Modifier.fillMaxWidth().monsterRow().background(if (active && playback.breakIsPlaying) Color(0xFF383838) else Color.Transparent).combinedClickable(onClick = { playSong(song) }, onLongClick = { fileActions(song) }).padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        song.name,
                        color = Color.White,
                        fontSize = 24.sp,
                        lineHeight = 36.sp,
                        softWrap = true,
                        modifier = Modifier.weight(1f)
                    )
                    if (song.isMidi) Text(song.mp3.extension().uppercase(Locale.ROOT), color = MonsterPurple, modifier = Modifier.padding(start = 8.dp))
                    if (active) Text(if (playback.breakIsPlaying) "▶" else "Ⅱ", fontSize = 18.sp)
                }
            }
            if (!loading && folders.isEmpty() && songs.isEmpty()) item {
                Text("Nema audio fajlova u ovom folderu.", modifier = Modifier.padding(16.dp))
            }
        }
    }
}

@Composable
private fun BreakPlaybackBar(playback: PlaybackModel) {
    Column(Modifier.fillMaxWidth().background(MonsterPanel).monsterBar().padding(horizontal = 10.dp, vertical = 6.dp)) {
        Text(
            playback.breakTrack?.name ?: "BREAK",
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp)
        )
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
            MonsterButton(
                onClick = { playback.toggleBreakPause() },
                enabled = !playback.breakPreparing,
                modifier = Modifier.testTag("breakPause")
            ) { Text(if (playback.breakIsPlaying) "Ⅱ" else "▶", fontSize = 28.sp) }
            MonsterButton(onClick = { playback.stopBreak() }, modifier = Modifier.testTag("breakStop")) {
                Text("■", fontSize = 26.sp)
            }
            MonsterButton(onClick = { playback.nextBreak() }, modifier = Modifier.testTag("breakNext")) {
                Text("⏭", fontSize = 28.sp)
            }
            Spacer(Modifier.width(12.dp))
            Text(
                if (playback.breakPreparing) "Učitavanje…" else "${time(playback.breakPosition)} / ${time(playback.breakDuration)}",
                fontSize = 12.sp
            )
        }
        Slider(
            value = if (playback.breakDuration > 0) playback.breakPosition.coerceIn(0, playback.breakDuration).toFloat() else 0f,
            onValueChange = { playback.seekBreakTo(it.toInt()) },
            valueRange = 0f..playback.breakDuration.coerceAtLeast(1).toFloat(),
            enabled = !playback.breakPreparing && playback.breakDuration > 0,
            modifier = Modifier.fillMaxWidth().testTag("breakSeek")
        )
    }
}

@Composable
internal fun CdgFrame(bitmap: android.graphics.Bitmap) {
    Image(
        bitmap = bitmap.asImageBitmap(),
        contentDescription = "CDG",
        modifier = Modifier.fillMaxSize().background(Color.Black).testTag("cdgFrame"),
        contentScale = ContentScale.Fit
    )
}

@Composable
internal fun ColumnScope.CdgSurface(
    showRexBackground: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    Box(Modifier.fillMaxWidth().weight(1f).background(Color.Black).testTag("CDGPanel")) {
        Box(Modifier.fillMaxSize().padding(top = 3.dp), content = content)
        if (showRexBackground) {
            Image(
                painter = painterResource(R.drawable.gigmonster_stage_background),
                contentDescription = null,
                modifier = Modifier.align(Alignment.CenterEnd).fillMaxHeight(.98f).fillMaxWidth(.62f).alpha(.0996f),
                contentScale = ContentScale.Fit
            )
        }
        Box(Modifier.fillMaxWidth().height(2.5.dp).align(Alignment.TopCenter).background(MonsterGreen.copy(alpha = .90f)).zIndex(5f))
    }
}

@Composable
private fun LocalVideoSurface(playback: PlaybackModel, modifier: Modifier) {
    AndroidView(
        factory = { context -> SurfaceView(context).apply {
            holder.addCallback(object : SurfaceHolder.Callback {
                override fun surfaceCreated(holder: SurfaceHolder) { playback.setVideoSurface(holder) }
                override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) = Unit
                override fun surfaceDestroyed(holder: SurfaceHolder) { playback.clearVideoSurface(holder) }
            })
        } },
        modifier = modifier
    )
}

@Composable
private fun BoxScope.LocalVideo(playback: PlaybackModel, onTextEdit: (() -> Unit)? = null) {
    val hasTimedLyrics = playback.timedLyrics.isNotEmpty()
    val overlayMode = hasTimedLyrics && playback.lyricsViewMode == LyricsViewMode.OVERLAY

    if (overlayMode) {
        LyricsFontPanel(
            modifier = Modifier.fillMaxSize(),
            controlsOverlay = true,
            railControls = {
                if (playback.syncEditSupported) {
                    SyncEditControls(
                        playback = playback,
                        onView = if (!playback.syncEditActive) playback::cycleLyricsViewMode else null,
                        onTextEdit = onTextEdit
                    )
                }
            }
        ) {
            LocalVideoSurface(playback, Modifier.fillMaxSize())
            TimedLyrics(playback)
        }
    } else {
        Column(Modifier.fillMaxSize()) {
            LocalVideoSurface(
                playback,
                Modifier.fillMaxWidth().weight(if (playback.lyricsText == null) 1f else .68f)
            )
            playback.lyricsText?.let { lyrics ->
                LyricsFontPanel(
                    modifier = Modifier.fillMaxWidth().weight(.32f),
                    railControls = {
                        if (playback.syncEditSupported) {
                            SyncEditControls(
                                playback = playback,
                                onView = if (hasTimedLyrics && !playback.syncEditActive) playback::cycleLyricsViewMode else null,
                                onTextEdit = onTextEdit
                            )
                        }
                    }
                ) {
                    if (hasTimedLyrics) TimedLyrics(playback)
                    else key(playback.popupTitle, lyrics) {
                        Text(
                            lyrics,
                            color = Color.White,
                            fontSize = LocalLyricsFontSize.current.sp,
                            lineHeight = (LocalLyricsFontSize.current * 1.3125f).sp,
                            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SyncEditLyrics(playback: PlaybackModel) {
    val lines = playback.syncLines
    val next = playback.syncNextIndex
    val state = rememberLazyListState()
    LaunchedEffect(next, lines) {
        if (next in lines.indices) state.animateScrollToItem(next)
    }

    val finger = rememberInfiniteTransition(label = "syncFinger")
    val fingerAlpha by finger.animateFloat(
        initialValue = .35f,
        targetValue = .82f,
        animationSpec = infiniteRepeatable(tween(450), RepeatMode.Reverse),
        label = "syncFingerAlpha"
    )
    val fingerMove by finger.animateFloat(
        initialValue = 0f,
        targetValue = 10f,
        animationSpec = infiniteRepeatable(tween(450), RepeatMode.Reverse),
        label = "syncFingerMove"
    )

    LazyColumn(
        state = state,
        modifier = Modifier.fillMaxSize().testTag("syncEditLyrics"),
        contentPadding = PaddingValues(start = 14.dp, top = 12.dp, end = 104.dp, bottom = 86.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        items(lines.size) { index ->
            val line = lines[index]
            if (line.isBlank()) Spacer(Modifier.height(14.dp))
            else Box(
                Modifier.fillMaxWidth().heightIn(min = 54.dp)
                    .background(if (index == next && !playback.syncEditFinished) Color(0xff242424) else Color.Transparent)
                    .clickable(enabled = !playback.syncEditFinished && index == next) { playback.tapSyncLine(index) }
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Text(
                    line,
                    color = if (playback.syncTimes.getOrNull(index) != null) Color.LightGray else Color.White,
                    fontSize = LocalLyricsFontSize.current.sp,
                    lineHeight = (LocalLyricsFontSize.current * 1.3125f).sp,
                    fontWeight = if (index == next && !playback.syncEditFinished) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier.fillMaxWidth().padding(end = 66.dp)
                )
                if (playback.syncFingerVisible && index == next && !playback.syncEditFinished) {
                    Text(
                        "👆",
                        fontSize = 46.sp,
                        modifier = Modifier.align(Alignment.CenterEnd).alpha(fingerAlpha)
                            .graphicsLayer { translationY = fingerMove }
                            .testTag("syncFinger")
                    )
                }
            }
        }
    }
}

@Composable
private fun LyricsPopupActionButton(
    label: String,
    onClick: () -> Unit,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    fontSize: Int = 10
) {
    val borderColor = if (enabled) MonsterGreen else Color(0xFF4A5147)
    val textColor = if (enabled) MonsterGreen else Color(0xFF777D75)
    Box(
        modifier = modifier
            .width(78.dp)
            .height(36.dp)
            .background(Color(0xFF101410), RoundedCornerShape(7.dp))
            .border(1.5.dp, borderColor, RoundedCornerShape(7.dp))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = textColor, fontSize = fontSize.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun MonitorArrow(popupVisible: Boolean) {
    // A single huge, filled, low triangle is much easier to see on stage than a thin arrow.
    // Its low height makes the pointing angle deliberately blunt; rotation keeps the same
    // MONITOR control for popup down/up without changing the button footprint.
    Canvas(Modifier.size(width = 42.dp, height = 34.dp).graphicsLayer { rotationZ = if (popupVisible) 0f else 180f }) {
        val triangle = Path().apply {
            moveTo(size.width * .04f, size.height * .20f)
            lineTo(size.width * .96f, size.height * .20f)
            lineTo(size.width * .50f, size.height * .82f)
            close()
        }
        drawPath(triangle, color = Color.White)
    }
}

@Composable
private fun ColumnScope.ChordsSyncEditControls(
    playback: PlaybackModel,
    onView: (() -> Unit)? = null,
    onTextEdit: (() -> Unit)? = null
) {
    val context = LocalContext.current

    // CHORDS has its own rail on purpose. It must never inherit TXT/LRC/LYR3/SRT
    // availability or accidentally invoke the lyrics synchronization path.
    if (playback.syncEditActive && playback.syncEditingChords) {
        LyricsControlRailItem {
            LyricsPopupActionButton(
                label = "◀",
                onClick = { playback.rewindSyncLine() },
                enabled = playback.canRewindSync,
                modifier = Modifier.testTag("chordsSyncRewind"),
                fontSize = 20
            )
        }
        LyricsControlRailItem {
            LyricsPopupActionButton(
                label = "SAVE",
                onClick = {
                    if (playback.saveSyncEdit()) Toast.makeText(context, "CHORDS SYNC saved", Toast.LENGTH_SHORT).show()
                    else Toast.makeText(context, "Tap at least one chord line before SAVE.", Toast.LENGTH_LONG).show()
                },
                modifier = Modifier.testTag("chordsSaveSyncEdit")
            )
        }
    } else {
        if (onView != null) {
            LyricsControlRailItem {
                LyricsPopupActionButton(
                    label = "VIEW",
                    onClick = onView,
                    modifier = Modifier.testTag("chordsView")
                )
            }
        }
        if (onTextEdit != null) {
            LyricsControlRailItem {
                LyricsPopupActionButton(
                    label = "TEXT EDIT",
                    onClick = onTextEdit,
                    modifier = Modifier.testTag("chordsTextEdit")
                )
            }
        }
        LyricsControlRailItem {
            LyricsPopupActionButton(
                label = "SYNC EDIT",
                onClick = {
                    if (!playback.startChordsSyncEdit()) {
                        Toast.makeText(context, "CHORDS SYNC nije dostupan za trenutno otvorene akorde.", Toast.LENGTH_LONG).show()
                    }
                },
                // This control is rendered only inside an open CHORDS panel. Its enabled
                // state depends solely on the current chords, never on a lyrics sidecar.
                enabled = true,
                modifier = Modifier.testTag("chordsSyncEdit")
            )
        }
    }
}

@Composable
private fun ColumnScope.SyncEditControls(
    playback: PlaybackModel,
    onView: (() -> Unit)? = null,
    onTextEdit: (() -> Unit)? = null,
    onSyncEdit: (() -> Boolean)? = null,
    syncEditEnabled: Boolean? = null
) {
    val context = LocalContext.current
    if (playback.syncEditActive) {
        LyricsControlRailItem {
            LyricsPopupActionButton(
                label = "◀",
                onClick = { playback.rewindSyncLine() },
                enabled = playback.canRewindSync,
                modifier = Modifier.testTag("syncRewind"),
                fontSize = 20
            )
        }
        LyricsControlRailItem {
            LyricsPopupActionButton(
                label = "SAVE",
                onClick = {
                    if (playback.saveSyncEdit()) Toast.makeText(context, "SYNC saved", Toast.LENGTH_SHORT).show()
                    else Toast.makeText(context, "Tap at least one line before SAVE.", Toast.LENGTH_LONG).show()
                },
                modifier = Modifier.testTag("saveSyncEdit")
            )
        }
    } else {
        if (onView != null) {
            LyricsControlRailItem {
                LyricsPopupActionButton(
                    label = "VIEW",
                    onClick = onView,
                    modifier = Modifier.testTag("lyricsView")
                )
            }
        }
        if (onTextEdit != null && (playback.textEditSupported || onSyncEdit != null)) {
            LyricsControlRailItem {
                LyricsPopupActionButton(
                    label = "TEXT EDIT",
                    onClick = onTextEdit,
                    modifier = Modifier.testTag("textEdit")
                )
            }
        }
        LyricsControlRailItem {
            LyricsPopupActionButton(
                label = "SYNC EDIT",
                onClick = {
                    val started = onSyncEdit?.invoke() ?: playback.startSyncEdit()
                    if (!started) Toast.makeText(context, "SYNC nije dostupan za trenutno otvoreni sadržaj.", Toast.LENGTH_LONG).show()
                },
                enabled = syncEditEnabled ?: if (onSyncEdit != null) playback.lyricsSyncCanBeOpened else playback.syncEditSupported,
                modifier = Modifier.testTag("syncEdit")
            )
        }
    }
}

@Composable
private fun PinchZoomHint(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "pinchHint")
    val spread by transition.animateFloat(
        initialValue = 10f,
        targetValue = 42f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pinchSpread"
    )
    val glow by transition.animateFloat(
        initialValue = .55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pinchGlow"
    )
    Column(
        modifier = modifier
            .background(Color.Black.copy(alpha = .86f), RoundedCornerShape(20.dp))
            .border(2.dp, MonsterGreen.copy(alpha = glow), RoundedCornerShape(20.dp))
            .padding(horizontal = 24.dp, vertical = 16.dp)
            .testTag("pinchZoomHint"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("PINCH TO ZOOM", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Box(Modifier.width(170.dp).height(70.dp)) {
            Text(
                "☝",
                fontSize = 48.sp,
                modifier = Modifier.align(Alignment.Center).offset(x = (-spread).dp).graphicsLayer { rotationZ = -14f }
            )
            Text(
                "☝",
                fontSize = 48.sp,
                modifier = Modifier.align(Alignment.Center).offset(x = spread.dp).graphicsLayer { scaleX = -1f; rotationZ = -14f }
            )
        }
    }
}

@Composable
private fun TimedChords(playback: PlaybackModel) {
    TimedContent(
        playback = playback,
        lines = playback.timedChords,
        plainText = playback.chordsText,
        preservePlain = true
    )
}

@Composable
private fun TimedLyrics(playback: PlaybackModel) {
    TimedContent(
        playback = playback,
        lines = playback.timedLyrics,
        plainText = playback.lyricsText,
        preservePlain = playback.showTextOnly
    )
}

@Composable
private fun TimedContent(
    playback: PlaybackModel,
    lines: List<LyricsReader.TimedLine>,
    plainText: String?,
    preservePlain: Boolean
) {
    val active = lines.indexOfLast { it.startMs <= playback.position }
    val fontSize = LocalLyricsFontSize.current
    val rows = remember(lines, plainText, preservePlain) {
        lyricDisplayRows(lines, plainText, preservePlain)
    }
    val activeRow = rows.indexOfFirst { active in it.cues }.let { if (it >= 0) it else 0 }

    when (playback.lyricsViewMode) {
        LyricsViewMode.ROLL -> TimedLyricsRoll(rows, active, activeRow, fontSize)
        LyricsViewMode.TWO_LINE -> TimedLyricsFixedWindow(rows, active, activeRow, before = 0, after = 1, fontSize = fontSize)
        LyricsViewMode.THREE_LINE -> TimedLyricsFixedWindow(rows, active, activeRow, before = 1, after = 1, fontSize = fontSize)
        LyricsViewMode.CENTER -> TimedLyricsFixedWindow(rows, active, activeRow, before = 2, after = 2, fontSize = fontSize, centerLock = true)
        LyricsViewMode.BIG_NEXT -> TimedLyricsBigNext(rows, active, activeRow, fontSize)
        LyricsViewMode.VERSE -> TimedLyricsVerse(rows, active, activeRow, fontSize)
        LyricsViewMode.OVERLAY -> TimedLyricsOverlay(rows, active, activeRow, fontSize)
    }
}

@Composable
private fun TimedLyricsRoll(
    rows: List<LyricDisplayRow>,
    activeCue: Int,
    activeRow: Int,
    fontSize: Float
) {
    val state = rememberLazyListState()
    LaunchedEffect(activeRow, rows, fontSize) {
        if (activeRow in rows.indices) state.animateScrollToItem(activeRow)
    }
    LazyColumn(
        state = state,
        modifier = Modifier.fillMaxSize().testTag("timedLyrics"),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        items(rows.size) { index ->
            TimedLyricsRow(rows[index], activeCue, fontSize)
        }
    }
}

@Composable
private fun TimedLyricsRow(row: LyricDisplayRow, activeCue: Int, fontSize: Float, centered: Boolean = false) {
    val isActive = activeCue in row.cues
    Box(
        Modifier
            .fillMaxWidth()
            .background(if (isActive) MonsterGreen.copy(alpha = .12f) else Color.Transparent, RoundedCornerShape(10.dp))
            .border(
                width = if (isActive) 2.dp else 0.dp,
                color = if (isActive) MonsterGreen.copy(alpha = .72f) else Color.Transparent,
                shape = RoundedCornerShape(10.dp)
            )
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            row.text,
            color = if (isActive) MonsterGreen else Color.White,
            fontSize = fontSize.sp,
            lineHeight = (fontSize * 1.3125f).sp,
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
            textAlign = if (centered) TextAlign.Center else TextAlign.Start,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

private fun neighboringLyricRows(rows: List<LyricDisplayRow>, activeRow: Int, before: Int, after: Int): List<Pair<Int, LyricDisplayRow>> {
    if (rows.isEmpty()) return emptyList()
    val center = activeRow.coerceIn(0, rows.lastIndex)
    return ((center - before).coerceAtLeast(0)..(center + after).coerceAtMost(rows.lastIndex))
        .map { it to rows[it] }
}

@Composable
private fun TimedLyricsFixedWindow(
    rows: List<LyricDisplayRow>,
    activeCue: Int,
    activeRow: Int,
    before: Int,
    after: Int,
    fontSize: Float,
    centerLock: Boolean = false
) {
    val visible = neighboringLyricRows(rows, activeRow, before, after)
    Box(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 12.dp).testTag("timedLyrics")) {
        Column(
            modifier = Modifier.align(Alignment.Center).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(if (centerLock) 6.dp else 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            visible.forEach { (_, row) ->
                TimedLyricsRow(
                    row = row,
                    activeCue = activeCue,
                    fontSize = if (centerLock && activeCue !in row.cues) fontSize * .82f else fontSize,
                    centered = true
                )
            }
        }
    }
}

@Composable
private fun TimedLyricsBigNext(rows: List<LyricDisplayRow>, activeCue: Int, activeRow: Int, fontSize: Float) {
    if (rows.isEmpty()) return
    val currentIndex = activeRow.coerceIn(0, rows.lastIndex)
    val nextIndex = ((currentIndex + 1)..rows.lastIndex).firstOrNull { rows[it].text.isNotBlank() }
    Box(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 12.dp).testTag("timedLyrics")) {
        Column(
            modifier = Modifier.align(Alignment.Center).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Text(
                rows[currentIndex].text,
                color = MonsterGreen,
                fontSize = (fontSize * 1.35f).coerceAtMost(82f).sp,
                lineHeight = (fontSize * 1.55f).coerceAtMost(92f).sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            nextIndex?.let {
                Text(
                    rows[it].text,
                    color = Color.White.copy(alpha = .82f),
                    fontSize = (fontSize * .72f).coerceAtLeast(18f).sp,
                    lineHeight = (fontSize * .94f).coerceAtLeast(24f).sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun TimedLyricsVerse(rows: List<LyricDisplayRow>, activeCue: Int, activeRow: Int, fontSize: Float) {
    if (rows.isEmpty()) return
    val center = activeRow.coerceIn(0, rows.lastIndex)
    var start = center
    var end = center
    while (start > 0 && rows[start - 1].text.isNotBlank()) start--
    while (end < rows.lastIndex && rows[end + 1].text.isNotBlank()) end++
    if (start == 0 && end == rows.lastIndex && rows.size > 6) {
        start = (center - 2).coerceAtLeast(0)
        end = (start + 4).coerceAtMost(rows.lastIndex)
        start = (end - 4).coerceAtLeast(0)
    }
    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 12.dp).verticalScroll(rememberScrollState()).testTag("timedLyrics"),
        verticalArrangement = Arrangement.Center
    ) {
        for (index in start..end) {
            if (rows[index].text.isBlank()) Spacer(Modifier.height(8.dp))
            else TimedLyricsRow(rows[index], activeCue, fontSize, centered = true)
        }
    }
}

@Composable
private fun TimedLyricsOverlay(rows: List<LyricDisplayRow>, activeCue: Int, activeRow: Int, fontSize: Float) {
    if (rows.isEmpty()) return
    val currentIndex = activeRow.coerceIn(0, rows.lastIndex)
    val nextIndex = ((currentIndex + 1)..rows.lastIndex).firstOrNull { rows[it].text.isNotBlank() }
    Box(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 16.dp).testTag("timedLyrics")) {
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = .68f), RoundedCornerShape(12.dp))
                .padding(horizontal = 18.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text(
                rows[currentIndex].text,
                color = MonsterGreen,
                fontSize = (fontSize * 1.12f).coerceAtMost(76f).sp,
                lineHeight = (fontSize * 1.38f).coerceAtMost(86f).sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            nextIndex?.let {
                Text(
                    rows[it].text,
                    color = Color.White,
                    fontSize = (fontSize * .72f).coerceAtLeast(18f).sp,
                    lineHeight = (fontSize * .92f).coerceAtLeast(24f).sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
internal fun SearchRow(
    value: String,
    change: (String) -> Unit,
    label: String,
    tag: String,
    submit: () -> Unit,
    voice: () -> Unit,
    tone: MonsterButtonTone = MonsterButtonTone.GREEN
) {
    val accent = if (tone == MonsterButtonTone.PURPLE) MonsterPurple else MonsterGreen
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = value,
            onValueChange = change,
            singleLine = true,
            placeholder = { Text(label, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = Color(0xFFD9D6DE)) },
            textStyle = TextStyle(fontSize = 22.sp, color = Color.White),
            shape = RoundedCornerShape(9.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = accent,
                unfocusedBorderColor = if (tone == MonsterButtonTone.PURPLE) Color(0xFFBFA3DD) else Color(0xFF5F7A4D),
                cursorColor = accent,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            modifier = Modifier.weight(1f).height(62.dp).testTag("${tag}Search").onPreviewKeyEvent {
                if (it.key == Key.Enter || it.key == Key.NumPadEnter) {
                    if (it.type == KeyEventType.KeyUp) submit()
                    true
                } else false
            },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { submit() }, onDone = { submit() }, onGo = { submit() })
        )
        MonsterButton(onClick = submit, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp), modifier = Modifier.width(72.dp).height(62.dp).testTag("${tag}Submit"), tone = tone) {
            Text("⌕", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(3.dp))
            Text("GO", maxLines = 1, fontWeight = FontWeight.Black)
        }
        MonsterButton(onClick = voice, contentPadding = PaddingValues(0.dp), modifier = Modifier.width(54.dp).height(62.dp), tone = tone) {
            Text("🎤", fontSize = 23.sp)
        }
    }
}

@Composable
internal fun BoxScope.OverlayPanel(size: PopupSize, title: String, resize: () -> Unit, close: () -> Unit, visible: Boolean = true, content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().fillMaxHeight(size.fraction)
        .zIndex(if (visible) 10f else -1f).alpha(if (visible) 1f else 0f).background(Color.Black).testTag("${title}Panel")) {
        Box(Modifier.fillMaxWidth().height(3.dp).align(Alignment.TopCenter).background(MonsterGreen).zIndex(20f))
        // A separate background hit target blocks the library without intercepting
        // button or WebView gestures. Interactive content is drawn above it.
        Box(Modifier.matchParentSize().pointerInput(Unit) {
            awaitPointerEventScope { while (true) {
                awaitPointerEvent().changes.forEach { it.consume() }
            } }
        })
        Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().heightIn(min = 64.dp).background(MonsterPanel), verticalAlignment = Alignment.CenterVertically) {
            MonsterButton(onClick = resize) { Text(size.nextLabel()) }
            Text(title, modifier = Modifier.weight(1f))
            MonsterButton(onClick = close, modifier = Modifier.testTag("${title}Close")) { Text("×", fontSize = 28.sp) }
        }
        Box(Modifier.weight(1f).fillMaxWidth(), content = content)
        }
    }
}


@Composable
internal fun BoxScope.WebPanel(
    visible: Boolean,
    size: PopupSize = PopupSize.HALF,
    cleanFrame: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    val panelModifier = Modifier
        .align(Alignment.BottomCenter)
        .fillMaxWidth()
        .fillMaxHeight(size.fraction)
        .zIndex(if (visible) 10f else -1f)
        .then(if (visible) Modifier else Modifier.alpha(0f))
        .background(Color.Black)
        .testTag("WEBPanel")
    Box(panelModifier) {
        if (!cleanFrame) {
            Box(Modifier.fillMaxWidth().height(3.dp).align(Alignment.TopCenter).background(MonsterGreen).zIndex(20f))
        }
        Box(Modifier.fillMaxSize().then(if (cleanFrame) Modifier else Modifier.padding(top = 3.dp)), content = content)
    }
}

@Composable
private fun WebPlaybackBar(
    controller: WebAudioController,
    playback: PlaybackModel,
    visible: Boolean,
    monitor: () -> Unit,
    toggleFullscreen: () -> Unit,
    isFullscreen: Boolean,
    externalScreen: () -> Unit,
    chordLabel: String,
    chordAction: () -> Unit,
    save: () -> Unit,
    back: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().background(MonsterPanel).monsterBar().padding(horizontal = 10.dp, vertical = 6.dp).horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), onClick = { playback.previousGigTrack() }, enabled = playback.hasGigPrevious, modifier = Modifier.testTag("webPrevious")) { Text("⏮", fontSize = 25.sp) }
        MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), onClick = { controller.togglePause() }, modifier = Modifier.testTag("webPause")) {
            Text(if (controller.isPlaying) "Ⅱ" else "▶", fontSize = 28.sp)
        }
        MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), onClick = { controller.stop() }, modifier = Modifier.testTag("webStop")) { Text("■", fontSize = 26.sp) }
        MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), onClick = { playback.nextGigTrack() }, enabled = playback.hasGigNext, modifier = Modifier.testTag("webNext")) { Text("⏭", fontSize = 25.sp) }
        MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp), onClick = monitor, modifier = Modifier.width(88.dp).height(52.dp).semantics { contentDescription = if (visible) "Minimize popup" else "Restore popup" }.testTag("webMonitor")) {
            MonitorArrow(visible)
        }
        MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), onClick = toggleFullscreen, modifier = Modifier.testTag("webFullscreen")) {
            Text(if (isFullscreen) "↙" else "⛶", fontSize = 28.sp)
        }
        MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp), onClick = externalScreen, modifier = Modifier.width(88.dp).height(52.dp).testTag("webExternalScreen")) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("▣", fontSize = 26.sp)
                Spacer(Modifier.width(4.dp))
                Text("EXT", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
        MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp), onClick = chordAction, modifier = Modifier.width(88.dp).height(52.dp).testTag("webChords")) {
            Text(chordLabel, fontSize = 12.sp, fontWeight = FontWeight.Black, maxLines = 1)
        }
        MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), onClick = save, enabled = controller.isYouTubeEmbed, modifier = Modifier.testTag("saveYoutubeLink")) {
            Text("SAVE", fontSize = 15.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width(12.dp))
        if (!visible) Text("WEB", fontSize = 12.sp)
        MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), onClick = back, modifier = Modifier.testTag("karaokeBrowserBack")) {
            Text("◀", fontSize = 28.sp)
        }
    }
}

@Composable
private fun LyricsBrowserBar(
    label: String,
    monitor: () -> Unit,
    visible: Boolean,
    back: () -> Unit,
    toggleFullscreen: () -> Unit,
    isFullscreen: Boolean,
    externalScreen: () -> Unit,
    chordLabel: String,
    chordAction: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().background(MonsterPanel).monsterBar().padding(horizontal = 10.dp, vertical = 6.dp).horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 12.sp)
        MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp), onClick = monitor, modifier = Modifier.width(88.dp).height(52.dp).semantics { contentDescription = if (visible) "Minimize popup" else "Restore popup" }.testTag("lyricsMonitor")) {
            MonitorArrow(visible)
        }
        MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), onClick = toggleFullscreen, modifier = Modifier.testTag("lyricsFullscreen")) {
            Text(if (isFullscreen) "↙" else "⛶", fontSize = 28.sp)
        }
        MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp), onClick = externalScreen, modifier = Modifier.width(88.dp).height(52.dp).testTag("lyricsExternalScreen")) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("▣", fontSize = 26.sp)
                Spacer(Modifier.width(4.dp))
                Text("EXT", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
        MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp), onClick = chordAction, modifier = Modifier.width(88.dp).height(52.dp).testTag("lyricsChords")) {
            Text(chordLabel, fontSize = 12.sp, fontWeight = FontWeight.Black, maxLines = 1)
        }
        Spacer(Modifier.width(12.dp))
        MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), onClick = back, modifier = Modifier.testTag("lyricsBrowserBack")) {
            Text("◀", fontSize = 28.sp)
        }
    }
}

@Composable
private fun PlaybackBar(
    playback: PlaybackModel,
    resume: () -> Unit,
    show: () -> Unit,
    toggleFullscreen: () -> Unit,
    isFullscreen: Boolean,
    externalScreen: () -> Unit,
    chordLabel: String,
    chordAction: () -> Unit,
    popupVisible: Boolean
) {
    val progress = if (playback.duration > 0) {
        playback.position.coerceIn(0, playback.duration).toFloat() / playback.duration.toFloat()
    } else 0f
    Column(
        Modifier
            .fillMaxWidth()
            .background(MonsterPanel)
            .drawBehind {
                val greenWidth = 2.dp.toPx()
                val redWidth = 2.dp.toPx()
                val railY = 6.dp.toPx()
                drawLine(MonsterGreen, Offset(0f, railY), Offset(size.width, railY), greenWidth)
                drawLine(MonsterRed, Offset(0f, size.height), Offset(size.width, size.height), redWidth)
                val dotRadius = 5.dp.toPx()
                val x = (size.width * progress.coerceIn(0f, 1f)).coerceIn(dotRadius, (size.width - dotRadius).coerceAtLeast(dotRadius))
                drawCircle(MonsterGreen, radius = dotRadius, center = Offset(x, railY))
            }
            .pointerInput(playback.duration) {
                // Keep the rail visually thin, but give it a comfortable invisible touch target.
                // Tap anywhere along the rail or drag the finger to scrub through the song.
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val railTouchHeight = 28.dp.toPx()
                    if (down.position.y <= railTouchHeight && playback.duration > 0 && size.width > 0) {
                        fun seekFromX(x: Float) {
                            val ratio = (x / size.width.toFloat()).coerceIn(0f, 1f)
                            playback.seekTo((playback.duration * ratio).toInt())
                        }
                        seekFromX(down.position.x)
                        down.consume()
                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == down.id } ?: break
                            if (!change.pressed) break
                            seekFromX(change.position.x)
                            change.consume()
                        }
                    }
                }
            }
            .padding(start = 10.dp, top = 6.dp, end = 10.dp, bottom = 0.dp)
            .testTag("playbackProgressRail")
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), onClick = { playback.previousGigTrack() }, enabled = playback.hasGigPrevious, modifier = Modifier.testTag("playlistPrevious")) { Text("⏮", fontSize = 25.sp) }
                MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), onClick = resume, enabled = !playback.preparing && !playback.syncEditFinished, modifier = Modifier.testTag("pause")) { Text(if (playback.isPlaying) "Ⅱ" else "▶", fontSize = 28.sp) }
                MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), onClick = { playback.stop() }, modifier = Modifier.testTag("stop")) { Text("■", fontSize = 26.sp) }
                MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), onClick = { playback.nextGigTrack() }, enabled = playback.hasGigNext, modifier = Modifier.testTag("playlistNext")) { Text("⏭", fontSize = 25.sp) }
                MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp), onClick = show, modifier = Modifier.width(88.dp).height(52.dp).semantics { contentDescription = if (popupVisible) "Minimize popup" else "Restore popup" }.testTag("showCdg")) {
                    MonitorArrow(popupVisible)
                }
                MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), onClick = toggleFullscreen, modifier = Modifier.height(52.dp).testTag("localFullscreen")) {
                    Text(if (isFullscreen) "↙" else "⛶", fontSize = 28.sp)
                }
                MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp), onClick = externalScreen, modifier = Modifier.width(88.dp).height(52.dp).testTag("localExternalScreen")) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("▣", fontSize = 26.sp)
                        Spacer(Modifier.width(4.dp))
                        Text("EXT", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
                MonsterButton(compact = true, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp), onClick = chordAction, modifier = Modifier.width(88.dp).height(52.dp).testTag("localChords")) {
                    Text(chordLabel, fontSize = 12.sp, fontWeight = FontWeight.Black, maxLines = 1)
                }
                Spacer(Modifier.width(10.dp))
            }
            TransposeControl(playback)
        }
    }
}

@Composable
private fun TransposeControl(playback: PlaybackModel) {
    val dirty = playback.transposeDirty && playback.transposeSupported
    Column(
        modifier = Modifier.width(174.dp).padding(start = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(28.dp)
                .clickable(enabled = dirty) { playback.saveTranspose() }
                .testTag("transposeSave"),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (dirty) "SAVE" else "TRANSPOSE",
                    color = if (dirty) MonsterGreen else Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.width(6.dp))
                Box(
                    modifier = Modifier.size(22.dp).offset(y = (-4).dp)
                        .border(1.dp, Color.White, androidx.compose.foundation.shape.CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "HQ",
                        color = Color.White,
                        fontSize = 8.sp,
                        lineHeight = 9.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().height(48.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .border(2.dp, MonsterGreen, RoundedCornerShape(9.dp))
                    .clickable(enabled = playback.transposeSupported && playback.transposeSemitones > -6) { playback.changeTranspose(-1) }
                    .testTag("transposeDown"),
                contentAlignment = Alignment.Center
            ) { Text("−", color = MonsterGreen, fontSize = 28.sp, fontWeight = FontWeight.Bold) }

            Text(
                if (playback.transposeSemitones > 0) "+${playback.transposeSemitones}" else playback.transposeSemitones.toString(),
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.width(54.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            Box(
                modifier = Modifier
                    .size(48.dp)
                    .border(2.dp, MonsterGreen, RoundedCornerShape(9.dp))
                    .clickable(enabled = playback.transposeSupported && playback.transposeSemitones < 6) { playback.changeTranspose(1) }
                    .testTag("transposeUp"),
                contentAlignment = Alignment.Center
            ) { Text("+", color = MonsterGreen, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

private fun time(ms: Int) = "%d:%02d".format(Locale.ROOT, ms / 60000, ms / 1000 % 60)

@Composable
private fun NativeYouTubePlayer(controller: WebAudioController) {
    if (controller.youtubeVideoIdForPlayer() == null) return
    val context = LocalContext.current

    // The controller owns ONE native YouTubePlayerView for the current YT session.
    // Normal mode and PiP only move that exact view between parents.  Do not release
    // it from Compose disposal: releasing/recreating causes an audible break/restart.
    AndroidView(
        modifier = Modifier.fillMaxSize().background(Color.Black).testTag("nativeYouTubePlayer"),
        factory = { controller.youtubePlayerView(context) },
        update = { controller.prepareYoutubePlayerViewFor(context, it) }
    )
}

@Composable
private fun Browser(
    controller: WebAudioController,
    visible: Boolean,
    showExtract: Boolean,
    onExtract: () -> Unit,
    onBack: (() -> Unit)? = null,
    youtubeSurface: (@Composable () -> Unit)? = null
) {
    val context = LocalContext.current
    val web = remember(controller) { controller.webView(context) }
    DisposableEffect(context) {
        controller.webView(context)
        onDispose { controller.detachContext() }
    }
    Box(Modifier.fillMaxSize()) {
        if (controller.isYouTubeEmbed && !showExtract) {
            if (youtubeSurface != null) youtubeSurface() else NativeYouTubePlayer(controller)
        } else {
            AndroidView(factory = { (web.parent as? android.view.ViewGroup)?.removeView(web); web },
                update = { it.setOnTouchListener { _, _ -> !visible } }, modifier = Modifier.fillMaxSize())
        }
        if (visible && showExtract && controller.canExtractCurrentPage) {
            Row(
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 10.dp).zIndex(20f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MonsterButton(
                    onClick = { onBack?.invoke() ?: controller.goBack() },
                    modifier = Modifier.testTag("extractBrowserBack")
                ) { Text("BACK", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                MonsterButton(
                    onClick = onExtract,
                    modifier = Modifier.testTag("extractLyrics")
                ) { Text("EXTRACT", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}


@Composable
private fun MiniPlaybackPip(playback: PlaybackModel) {
    var remaining by remember { mutableStateOf(remainingPlaybackLabel(playback)) }
    LaunchedEffect(playback) {
        while (isActive) { remaining = remainingPlaybackLabel(playback); delay(500) }
    }
    Row(Modifier.fillMaxSize().background(Color(0xFF061008)).border(1.dp, MonsterGreen, RoundedCornerShape(9.dp)).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Image(
            painterResource(R.drawable.karamonster_rex_clean),
            null,
            Modifier.size(36.dp),
            contentScale = ContentScale.Fit
        )
        Text(remaining, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp))
        Text("BACK TO GIGMONSTER", color = MonsterGreen, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
    }
}
