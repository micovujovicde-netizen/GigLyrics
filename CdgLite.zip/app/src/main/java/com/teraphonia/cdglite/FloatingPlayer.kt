package com.teraphonia.cdglite

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.*
import android.widget.*
import kotlin.math.abs

/** One playback session; only its visible surface changes parents. */
internal class FloatingPlayer(private val activity: Activity, private val playback: PlaybackModel) {
    private val manager = activity.getSystemService(WindowManager::class.java)
    private val handler = Handler(Looper.getMainLooper())
    private var root: FrameLayout? = null
    private var content: FrameLayout? = null
    private var image: ImageView? = null
    private var text: TextView? = null
    private var video: SurfaceView? = null
    private var originalVideoSurface: SurfaceHolder? = null
    private var youtube: View? = null
    private var originalYoutubeParent: ViewGroup? = null
    private var originalYoutubeParams: ViewGroup.LayoutParams? = null
    private var lastFrame: android.graphics.Bitmap? = null
    private var mode = ""
    private var compact = false
    private var halfScreen = false
    private var params: WindowManager.LayoutParams? = null
    val visible get() = root != null

    private fun screenSize(): Pair<Int, Int> {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            val bounds = manager.currentWindowMetrics.bounds
            return bounds.width() to bounds.height()
        }
        @Suppress("DEPRECATION")
        val metrics = android.util.DisplayMetrics().also { manager.defaultDisplay.getRealMetrics(it) }
        return metrics.widthPixels to metrics.heightPixels
    }

    fun show(compactBar: Boolean = false): Boolean {
        if (!Settings.canDrawOverlays(activity)) return false
        if (visible) return true
        val (width, height) = screenSize()
        compact = compactBar
        halfScreen = false
        originalVideoSurface = if (compact) null else playback.currentVideoSurface
        val density = activity.resources.displayMetrics.density
        val smallWidth = if (compact) minOf((width * .85f).toInt(), (400 * density).toInt()) else (width * .42f).toInt()
        val layout = WindowManager.LayoutParams(
            smallWidth, if (compact) (76 * density).toInt() else (smallWidth * 216f / 300f).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.LEFT; x = width - smallWidth; y = height - this.height - 48 }
        val window = FrameLayout(activity).apply { setBackgroundColor(Color.BLACK) }
        val body = FrameLayout(activity)
        window.addView(body, FrameLayout.LayoutParams(-1, -1))
        val touch = View(activity)
        window.addView(touch, FrameLayout.LayoutParams(-1, -1))
        var downX = 0f; var downY = 0f; var originX = 0; var originY = 0; var dragged = false
        val slop = ViewConfiguration.get(activity).scaledTouchSlop
        var tracker: VelocityTracker? = null
        touch.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    tracker?.recycle()
                    tracker = VelocityTracker.obtain().also { it.addMovement(event) }
                    downX = event.rawX; downY = event.rawY; originX = layout.x; originY = layout.y; dragged = false
                }
                MotionEvent.ACTION_MOVE -> {
                    tracker?.addMovement(event)
                    val dx = event.rawX - downX; val dy = event.rawY - downY
                    if (abs(dx) > slop || abs(dy) > slop) dragged = true
                    if (dragged && !halfScreen) {
                        layout.x = (originX + dx.toInt()).coerceIn(0, (width - layout.width).coerceAtLeast(0))
                        layout.y = (originY + dy.toInt()).coerceIn(0, (height - layout.height).coerceAtLeast(0))
                        runCatching { manager.updateViewLayout(window, layout) }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    tracker?.addMovement(event)
                    tracker?.computeCurrentVelocity(1000)
                    val distance = maxOf(abs(event.rawX - downX), abs(event.rawY - downY))
                    val speed = maxOf(abs(tracker?.xVelocity ?: 0f), abs(tracker?.yVelocity ?: 0f))
                    val fastSwipe = distance >= 48 * density && speed >= 900 * density && event.eventTime - event.downTime <= 450
                    tracker?.recycle(); tracker = null
                    if (fastSwipe) {
                        hide()
                        playback.stop()
                        playback.stopBreak()
                        playback.karaokeWeb.close()
                        playback.lyricsWeb.close()
                        activity.finishAndRemoveTask()
                    } else if (!dragged && compact) {
                        hide()
                        activity.startActivity(Intent(activity, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
                    } else if (!dragged && !halfScreen) {
                        halfScreen = true
                        layout.width = width; layout.height = height / 2; layout.x = 0; layout.y = height / 2
                        runCatching { manager.updateViewLayout(window, layout) }
                    } else if (!dragged) {
                        hide()
                        activity.startActivity(Intent(activity, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
                    }
                }
                MotionEvent.ACTION_CANCEL -> { tracker?.recycle(); tracker = null }
            }
            true
        }
        return try {
            manager.addView(window, layout)
            root = window; content = body; params = layout
            handler.post(tick)
            true
        } catch (_: Exception) { false }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!visible) return
            render()
            handler.postDelayed(this, if (compact) 500 else 40)
        }
    }

    private fun restoreYoutube() {
        val player = youtube ?: return
        playback.karaokeWeb.beginYoutubeSurfaceTransfer()
        (player.parent as? ViewGroup)?.removeView(player)
        originalYoutubeParent?.let { parent ->
            if (player.parent == null) parent.addView(player, originalYoutubeParams ?: ViewGroup.LayoutParams(-1, -1))
        }
        playback.karaokeWeb.finishYoutubeSurfaceTransfer(player)
        youtube = null; originalYoutubeParent = null; originalYoutubeParams = null
    }

    private fun setMode(next: String) {
        if (next == mode) return
        restoreYoutube()
        video?.let { playback.clearVideoSurface(it.holder) }
        content?.removeAllViews()
        image = null; text = null; video = null; lastFrame = null
        mode = next
        when (next) {
            "compact" -> {
                val density = activity.resources.displayMetrics.density
                val row = LinearLayout(activity).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding((8 * density).toInt(), (6 * density).toInt(), (8 * density).toInt(), (6 * density).toInt())
                    background = android.graphics.drawable.GradientDrawable().apply {
                        setColor(Color.rgb(6, 16, 8)); cornerRadius = 9 * density
                        setStroke(density.toInt().coerceAtLeast(1), Color.rgb(134, 245, 0))
                    }
                }
                row.addView(ImageView(activity).apply {
                    setImageResource(R.drawable.gigmonster_app_icon_no_text)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                }, LinearLayout.LayoutParams((40 * density).toInt(), (40 * density).toInt()))
                text = TextView(activity).apply {
                    setTextColor(Color.WHITE); textSize = 22f; gravity = Gravity.CENTER
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    maxLines = 1
                }
                row.addView(text, LinearLayout.LayoutParams((94 * density).toInt(), -1))
                row.addView(TextView(activity).apply {
                    text = "BACK TO
GIGMONSTER"; textSize = 16f; gravity = Gravity.CENTER
                    setTextColor(Color.rgb(134, 245, 0)); setTypeface(null, android.graphics.Typeface.BOLD)
                }, LinearLayout.LayoutParams(0, -1, 1f))
                content?.addView(row, FrameLayout.LayoutParams(-1, -1))
            }
            "cdg" -> image = ImageView(activity).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                content?.addView(this, FrameLayout.LayoutParams(-1, -1))
            }
            "video" -> video = SurfaceView(activity).apply {
                holder.addCallback(object : SurfaceHolder.Callback {
                    override fun surfaceCreated(holder: SurfaceHolder) { playback.setVideoSurface(holder) }
                    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) = Unit
                    override fun surfaceDestroyed(holder: SurfaceHolder) { playback.clearVideoSurface(holder) }
                })
                content?.addView(this, FrameLayout.LayoutParams(-1, -1))
            }
            "text" -> text = TextView(activity).apply {
                setTextColor(Color.WHITE); textSize = 26f; gravity = Gravity.CENTER
                setPadding(12, 12, 12, 12)
                content?.addView(this, FrameLayout.LayoutParams(-1, -1))
            }
        }
    }

    private fun render() {
        if (compact) {
            setMode("compact")
            text?.text = remainingPlaybackLabel(playback)
            root?.contentDescription = "${text?.text} remaining. BACK TO GIGMONSTER"
            return
        }
        val song = playback.song
        val bitmap = playback.frame
        val next = when {
            song?.isYoutubeLink == true && playback.karaokeWeb.youtubeVideoIdForPlayer() != null -> "youtube"
            bitmap != null && !playback.showTextOnly -> "cdg"
            song?.cdg != null -> "text"
            song?.isVideo == true -> "video"
            else -> "text"
        }
        setMode(next)
        when (next) {
            "cdg" -> if (bitmap !== lastFrame) { image?.setImageBitmap(bitmap); lastFrame = bitmap }
            "youtube" -> {
                val player = playback.karaokeWeb.youtubePlayerView(activity, detachFromParent = false)
                if (youtube !== player) {
                    restoreYoutube()
                    originalYoutubeParent = player.parent as? ViewGroup
                    originalYoutubeParams = player.layoutParams
                    playback.karaokeWeb.beginYoutubeSurfaceTransfer()
                    originalYoutubeParent?.removeView(player)
                    youtube = player
                    content?.addView(player, FrameLayout.LayoutParams(-1, -1))
                    playback.karaokeWeb.finishYoutubeSurfaceTransfer(player)
                }
            }
            "text" -> {
                val lines = playback.timedLyrics
                val active = lines.indexOfLast { it.startMs <= playback.position }.coerceAtLeast(0)
                text?.text = when {
                    song?.cdg != null -> playback.error ?: "Učitavanje CDG…"
                    lines.isNotEmpty() -> lines.drop(active).take(3).joinToString("\n") { it.text }
                    else -> playback.lyricsText ?: song?.name.orEmpty()
                }
            }
        }
    }

    fun hide() {
        handler.removeCallbacks(tick)
        restoreYoutube()
        video?.let { playback.clearVideoSurface(it.holder) }
        root?.let { runCatching { manager.removeViewImmediate(it) } }
        originalVideoSurface?.takeIf { it.surface.isValid }?.let { playback.setVideoSurface(it) }
        originalVideoSurface = null
        root = null; content = null; image = null; text = null; video = null; params = null
        lastFrame = null; mode = ""
    }
}
