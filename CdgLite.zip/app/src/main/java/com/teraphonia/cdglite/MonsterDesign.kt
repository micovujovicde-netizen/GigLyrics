package com.teraphonia.cdglite

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

internal val MonsterGreen = Color(0xFF86F500)
internal val MonsterRed = Color(0xFFFF1818)
internal val MonsterPurple = Color(0xFFD1B2FF)
internal val MonsterPurpleStrong = Color(0xFF9A5CFF)
internal val MonsterPanel = Color(0xFF0D120F)
internal val monsterColors = darkColorScheme(
    primary = MonsterGreen, onPrimary = Color.Black,
    secondary = MonsterPurple, onSecondary = Color.Black,
    tertiary = MonsterRed, onTertiary = Color.White,
    background = Color.Black, onBackground = Color.White,
    surface = MonsterPanel, onSurface = Color.White,
    surfaceVariant = Color(0xFF181E19), onSurfaceVariant = Color(0xFFDFE7DC),
    outline = Color(0xFF56723A), error = Color(0xFFFF7272)
)

internal enum class MonsterButtonTone { GREEN, PURPLE }

@Composable
internal fun MonsterButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    tone: MonsterButtonTone = MonsterButtonTone.GREEN,
    compact: Boolean = false,
    contentPadding: PaddingValues = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
    content: @Composable RowScope.() -> Unit
) {
    val shape = RoundedCornerShape(9.dp)
    val accent = if (tone == MonsterButtonTone.PURPLE) MonsterPurple else MonsterGreen
    val strong = if (tone == MonsterButtonTone.PURPLE) MonsterPurpleStrong else MonsterGreen
    val borderColor = if (enabled) accent else Color(0xFF4A5147)
    val brush = if (enabled) {
        if (tone == MonsterButtonTone.PURPLE) {
            Brush.verticalGradient(listOf(Color(0xFF3B3A3A), Color(0xFF252326), Color(0xFF111112)))
        } else {
            Brush.verticalGradient(listOf(Color(0xFF343A34), Color(0xFF202520), Color(0xFF0D100D)))
        }
    } else Brush.verticalGradient(listOf(Color(0xFF2C2D2A), Color(0xFF151614)))

    OutlinedButton(
        onClick = onClick,
        modifier = modifier
            .padding(horizontal = 2.dp, vertical = 3.dp)
            .heightIn(min = if (compact) 48.dp else 52.dp)
            .background(brush, shape)
            .border(BorderStroke(2.dp, borderColor), shape)
            .drawBehind {
                // Small controls stay simpler than the P1–P4 slabs, but still read as dark carved stone.
                drawLine(
                    if (enabled) strong.copy(alpha = .55f) else Color.DarkGray.copy(alpha = .25f),
                    Offset(18.dp.toPx(), 1.5.dp.toPx()),
                    Offset(size.width - 18.dp.toPx(), 1.5.dp.toPx()),
                    1.dp.toPx()
                )
                // Green transport controls keep the KaraMonster red accent shown in the references.
                if (tone == MonsterButtonTone.GREEN) {
                    val inset = 12.dp.toPx()
                    drawLine(
                        if (enabled) MonsterRed else Color(0xFF572525),
                        Offset(inset, size.height - 1.dp.toPx()),
                        Offset(size.width - inset, size.height - 1.dp.toPx()),
                        3.dp.toPx()
                    )
                }
            },
        enabled = enabled,
        shape = shape,
        border = null,
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = Color.Transparent,
            contentColor = if (enabled) accent else Color(0xFF9BA39A),
            disabledContainerColor = Color.Transparent,
            disabledContentColor = Color(0xFF9BA39A)
        ),
        contentPadding = contentPadding,
        content = content
    )
}

internal fun Modifier.monsterRow(): Modifier = drawBehind {
    // CANON: the old white rails become a pale fluorescent jungle vine. Keep it thin so
    // long song/folder names remain the visual priority on stage.
    val vine = Color(0xFF91D6A1)
    val y = size.height - 3.dp.toPx()
    val path = Path().apply {
        moveTo(0f, y)
        cubicTo(size.width * .16f, y - 4.dp.toPx(), size.width * .30f, y + 3.dp.toPx(), size.width * .45f, y)
        cubicTo(size.width * .60f, y - 4.dp.toPx(), size.width * .78f, y + 3.dp.toPx(), size.width, y - 1.dp.toPx())
    }
    drawPath(path, vine.copy(alpha = .58f), style = Stroke(width = 1.4.dp.toPx()))
    var x = 24.dp.toPx()
    var up = true
    while (x < size.width - 12.dp.toPx()) {
        val leafY = y + if (up) -4.dp.toPx() else 3.dp.toPx()
        drawCircle(vine.copy(alpha = .36f), 2.2.dp.toPx(), Offset(x, leafY))
        drawLine(vine.copy(alpha = .29f), Offset(x, y), Offset(x + 5.dp.toPx(), leafY), .9.dp.toPx())
        up = !up
        x += 44.dp.toPx()
    }
}

internal fun Modifier.monsterBar(): Modifier = drawBehind {
    drawLine(MonsterGreen, Offset.Zero, Offset(size.width, 0f), 2.dp.toPx())
    drawLine(MonsterRed, Offset(0f, size.height), Offset(size.width, size.height), 2.dp.toPx())
}

@Composable
internal fun MonsterFolderIcon() {
    Image(
        painterResource(R.drawable.karamonster_folder),
        null,
        Modifier.padding(start = 6.dp).size((64f * 2f / 3f).dp),
        contentScale = ContentScale.Fit
    )
}

@Composable
internal fun MonsterBrand() {
    Image(
        painter = painterResource(R.drawable.gigmonster_logo),
        contentDescription = "GigMonster",
        modifier = Modifier
            .fillMaxWidth(.67f)
            .heightIn(min = 76.dp, max = 118.dp)
            .padding(start = 8.dp, top = 8.dp, bottom = 6.dp)
            .alpha(.88f),
        contentScale = ContentScale.Fit,
        alignment = Alignment.CenterStart
    )
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
internal fun StoneButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    locked: Boolean = false,
    onLongClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    // Irregular Bedrock silhouette rather than a normal rounded Android button.
    val stoneShape = GenericShape { size, _ ->
        moveTo(size.width * .06f, 0f)
        lineTo(size.width * .91f, size.height * .03f)
        lineTo(size.width, size.height * .18f)
        lineTo(size.width * .96f, size.height * .88f)
        lineTo(size.width * .84f, size.height)
        lineTo(size.width * .08f, size.height * .96f)
        lineTo(0f, size.height * .80f)
        lineTo(size.width * .02f, size.height * .12f)
        close()
    }
    val edge = if (active) MonsterGreen else Color(0xFF4A5147)
    val top = if (active) Color(0xFF345E3A) else Color(0xFF30332E)
    val bottom = if (active) Color(0xFF172B1B) else Color(0xFF20221F)
    Box(
        modifier = modifier
            .padding(2.dp)
            .heightIn(min = 48.dp)
            .background(Brush.verticalGradient(listOf(top, bottom)), stoneShape)
            .border(2.dp, edge, stoneShape)
            .drawBehind {
                val crack = Color.Black.copy(alpha = .28f)
                drawLine(crack, Offset(size.width * .17f, size.height * .18f), Offset(size.width * .28f, size.height * .31f), 1.3.dp.toPx())
                drawLine(crack, Offset(size.width * .74f, size.height * .70f), Offset(size.width * .84f, size.height * .61f), 1.2.dp.toPx())
                drawLine(edge.copy(alpha = .24f), Offset(size.width * .08f, size.height * .10f), Offset(size.width * .86f, size.height * .08f), 1.dp.toPx())
            }
            .then(if (onLongClick == null) Modifier.clickable(onClick = onClick) else Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        content()
        if (locked) {
            Canvas(
                Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 4.dp)
                    .size(34.dp)
                    .alpha(.32f)
            ) {
                val white = Color.White
                val stroke = 3.dp.toPx()
                drawRoundRect(
                    color = white,
                    topLeft = Offset(size.width * .18f, size.height * .44f),
                    size = androidx.compose.ui.geometry.Size(size.width * .64f, size.height * .46f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx(), 4.dp.toPx()),
                    style = Stroke(stroke)
                )
                drawArc(
                    color = white,
                    startAngle = 195f,
                    sweepAngle = 150f,
                    useCenter = false,
                    topLeft = Offset(size.width * .28f, size.height * .06f),
                    size = androidx.compose.ui.geometry.Size(size.width * .44f, size.height * .55f),
                    style = Stroke(stroke)
                )
            }
        }
    }
}
