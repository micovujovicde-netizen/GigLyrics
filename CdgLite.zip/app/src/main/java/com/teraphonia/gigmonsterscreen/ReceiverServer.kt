package com.teraphonia.gigmonsterscreen

import android.graphics.BitmapFactory
import android.os.Build
import android.util.Base64
import org.json.JSONObject
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class ReceiverServer(
    private val onCommand: (StageCommand) -> Unit,
    private val onDisconnected: () -> Unit
) {
    companion object {
        const val DISCOVERY_PORT = 49510
        const val CONTROL_PORT = 49511
        const val DISCOVERY_REQUEST = "GIGMONSTER_DISCOVER_V1"
        const val DISCOVERY_RESPONSE = "GIGMONSTER_SCREEN_V1"
    }

    private val running = AtomicBoolean(false)
    private val executor = Executors.newCachedThreadPool()
    private val clientSockets = CopyOnWriteArrayList<Socket>()
    @Volatile private var discoverySocket: DatagramSocket? = null
    @Volatile private var serverSocket: ServerSocket? = null

    fun start() {
        if (!running.compareAndSet(false, true)) return
        executor.execute(::runDiscovery)
        executor.execute(::runControlServer)
    }

    fun stop() {
        running.set(false)
        runCatching { discoverySocket?.close() }
        runCatching { serverSocket?.close() }
        clientSockets.forEach { runCatching { it.close() } }
        clientSockets.clear()
        executor.shutdownNow()
    }

    private fun runDiscovery() {
        try {
            val socket = DatagramSocket(null).apply {
                reuseAddress = true
                broadcast = true
                bind(InetSocketAddress(DISCOVERY_PORT))
            }
            discoverySocket = socket
            val buffer = ByteArray(512)
            while (running.get()) {
                val packet = DatagramPacket(buffer, buffer.size)
                socket.receive(packet)
                val request = String(packet.data, 0, packet.length, Charsets.UTF_8).trim()
                if (request == DISCOVERY_REQUEST) {
                    val deviceName = Build.MODEL.replace('|', ' ').trim().ifEmpty { "Android TV" }
                    val response = "$DISCOVERY_RESPONSE|$deviceName|$CONTROL_PORT"
                    val bytes = response.toByteArray(Charsets.UTF_8)
                    socket.send(DatagramPacket(bytes, bytes.size, packet.address, packet.port))
                }
            }
        } catch (_: SocketException) {
            // Normal during shutdown.
        } catch (_: Throwable) {
            // Keep the TV app alive even if discovery is unavailable.
        }
    }

    private fun runControlServer() {
        try {
            val server = ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress(CONTROL_PORT))
            }
            serverSocket = server
            while (running.get()) {
                val client = server.accept()
                client.keepAlive = true
                client.tcpNoDelay = true
                clientSockets += client
                executor.execute { handleClient(client) }
            }
        } catch (_: SocketException) {
            // Normal during shutdown.
        } catch (_: Throwable) {
            // App stays on the logo if the server cannot bind.
        }
    }

    private fun handleClient(socket: Socket) {
        try {
            val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
            val writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream(), Charsets.UTF_8))
            writer.write("{\"type\":\"hello\",\"receiver\":\"GigMonster Screen\",\"version\":1}\n")
            writer.flush()

            while (running.get() && !socket.isClosed) {
                val line = reader.readLine() ?: break
                if (line.isBlank()) continue
                val json = runCatching { JSONObject(line) }.getOrNull() ?: continue
                when (json.optString("type")) {
                    "ping" -> {
                        writer.write("{\"type\":\"pong\"}\n")
                        writer.flush()
                    }
                    "logo", "clear" -> onCommand(StageCommand.Logo)
                    "text", "lyrics" -> onCommand(
                        StageCommand.Lyrics(
                            current = json.optString("current", json.optString("text", "")),
                            next = json.optString("next", "")
                        )
                    )
                    "frame" -> decodeFrame(json.optString("data", ""))?.let {
                        onCommand(StageCommand.Frame(it))
                    }
                }
            }
        } catch (_: Throwable) {
            // Connection loss simply returns TV to the logo.
        } finally {
            clientSockets -= socket
            runCatching { socket.close() }
            if (clientSockets.isEmpty()) onDisconnected()
        }
    }

    private fun decodeFrame(data: String): android.graphics.Bitmap? {
        if (data.isBlank()) return null
        val clean = data.substringAfter("base64,", data)
        val bytes = runCatching { Base64.decode(clean, Base64.DEFAULT) }.getOrNull() ?: return null
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }
}
