package com.teraphonia.gigmonsterscreen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.min

class StageView(context: Context) : View(context) {
    private val logo: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.gigmonster_logo)
    private val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = android.graphics.Typeface.create("sans", android.graphics.Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }

    private var mode: StageCommand = StageCommand.Logo

    fun applyCommand(command: StageCommand) {
        mode = command
        invalidate()
    }

    fun showLogo() {
        applyCommand(StageCommand.Logo)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.BLACK)
        when (val currentMode = mode) {
            StageCommand.Logo -> drawLogo(canvas)
            is StageCommand.Lyrics -> drawLyrics(canvas, currentMode)
            is StageCommand.Frame -> drawFrame(canvas, currentMode.bitmap)
        }
    }

    private fun drawLogo(canvas: Canvas) {
        if (width <= 0 || height <= 0 || logo.width <= 0 || logo.height <= 0) return
        val maxW = width * 0.64f
        val maxH = height * 0.68f
        val scale = min(maxW / logo.width.toFloat(), maxH / logo.height.toFloat())
        val w = logo.width * scale
        val h = logo.height * scale
        val left = (width - w) / 2f
        val top = (height - h) / 2f
        canvas.drawBitmap(logo, null, RectF(left, top, left + w, top + h), imagePaint)
    }

    private fun drawLyrics(canvas: Canvas, lyrics: StageCommand.Lyrics) {
        val current = lyrics.current.trim()
        if (current.isEmpty()) {
            drawLogo(canvas)
            return
        }

        val currentSize = (height * 0.105f).coerceIn(42f, 120f)
        textPaint.textSize = currentSize
        textPaint.color = Color.rgb(134, 245, 0)
        val currentLines = wrap(current, textPaint, width * 0.86f)
        val currentLineHeight = currentSize * 1.18f

        val next = lyrics.next.trim()
        val nextSize = currentSize * 0.58f
        val nextLines = if (next.isNotEmpty()) {
            textPaint.textSize = nextSize
            wrap(next, textPaint, width * 0.82f)
        } else emptyList()

        val blockHeight = currentLines.size * currentLineHeight +
            if (nextLines.isNotEmpty()) height * 0.07f + nextLines.size * nextSize * 1.22f else 0f
        var y = (height - blockHeight) / 2f + currentSize

        textPaint.textSize = currentSize
        textPaint.color = Color.rgb(134, 245, 0)
        currentLines.forEach { line ->
            canvas.drawText(line, width / 2f, y, textPaint)
            y += currentLineHeight
        }

        if (nextLines.isNotEmpty()) {
            y += height * 0.06f
            textPaint.textSize = nextSize
            textPaint.color = Color.WHITE
            textPaint.alpha = 220
            nextLines.forEach { line ->
                canvas.drawText(line, width / 2f, y, textPaint)
                y += nextSize * 1.22f
            }
            textPaint.alpha = 255
        }
    }

    private fun drawFrame(canvas: Canvas, bitmap: Bitmap) {
        if (bitmap.width <= 0 || bitmap.height <= 0) return
        val scale = min(width / bitmap.width.toFloat(), height / bitmap.height.toFloat())
        val w = bitmap.width * scale
        val h = bitmap.height * scale
        val left = (width - w) / 2f
        val top = (height - h) / 2f
        canvas.drawBitmap(bitmap, null, RectF(left, top, left + w, top + h), imagePaint)
    }

    private fun wrap(text: String, paint: Paint, maxWidth: Float): List<String> {
        val words = text.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.isEmpty()) return emptyList()
        val out = mutableListOf<String>()
        var line = words.first()
        for (word in words.drop(1)) {
            val candidate = "$line $word"
            if (paint.measureText(candidate) <= maxWidth) line = candidate
            else {
                out += line
                line = word
            }
        }
        out += line
        return out
    }
}
