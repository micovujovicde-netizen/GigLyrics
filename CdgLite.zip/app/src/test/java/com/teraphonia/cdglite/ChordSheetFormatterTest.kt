package com.teraphonia.cdglite

import org.junit.Assert.*
import org.junit.Test

class ChordSheetFormatterTest {
    @Test fun inlineChordsBecomeAlignedChordAndLyricRows() {
        val formatted = ChordSheetFormatter.format("[Am]Ružica si bila [F]jedna u mom srcu")!!
        val lines = formatted.lines()
        assertTrue(lines[0].startsWith("Am"))
        assertTrue(lines[0].contains("F"))
        assertEquals("Ružica si bila jedna u mom srcu", lines[1])
    }

    @Test fun keepsLyricsInAnyScriptAndRecognizesGermanHChord() {
        val formatted = ChordSheetFormatter.format("Am      H7\nТы была моей весной\nF       E\nNoćas te sanjam")!!
        assertTrue(formatted.contains("Ты была моей весной"))
        assertTrue(formatted.contains("Noćas te sanjam"))
        assertTrue(formatted.contains("H7"))
    }

    @Test fun preservesExistingChordOverLyricLayout() {
        val raw = "Am              F\nProšla je kroz moje snove\nC               G\ni bila je tren"
        assertEquals(raw, ChordSheetFormatter.format(raw))
    }

    @Test fun rejectsOrdinaryWebTextWithoutChords() {
        assertNull(ChordSheetFormatter.format("This is an ordinary article.\nIt contains text but no musical harmony.\nNothing to extract here."))
    }

    @Test fun chordSearchIsMultilingualAndDoesNotExcludeScribd() {
        val query = chordSearchQuery("Bijelo dugme Ruzica si bila")
        assertTrue(query.contains("chords"))
        assertTrue(query.contains("akordi"))
        assertTrue(query.contains("аккорды"))
        assertTrue(query.contains("和弦"))
        assertFalse(query.contains("-site:scribd.com"))
        assertTrue(query.contains("-site:youtube.com"))
    }
}
