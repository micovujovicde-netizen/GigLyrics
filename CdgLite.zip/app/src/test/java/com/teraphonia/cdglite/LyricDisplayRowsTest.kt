package com.teraphonia.cdglite

import org.junit.Assert.*
import org.junit.Test

class LyricDisplayRowsTest {
    @Test fun partialTimingKeepsUntimedLinesAndCues() {
        val rows = lyricDisplayRows(listOf(LyricsReader.TimedLine(1000, "First"), LyricsReader.TimedLine(3000, "Last")),
            "Intro\nFirst\n\nInstrumental\nLast\nOutro", true)
        assertEquals(listOf("Intro", "First", "", "Instrumental", "Last", "Outro"), rows.map { it.text })
        assertEquals(1, rows.indexOfFirst { 0 in it.cues })
        assertEquals(4, rows.indexOfFirst { 1 in it.cues })
    }
    @Test fun multilineCaptionsAndRepeatedCueShareTheirVisibleText() {
        val cues = listOf(LyricsReader.TimedLine(1000, "One\nTwo"), LyricsReader.TimedLine(5000, "One\nTwo"))
        val rows = lyricDisplayRows(cues, "Title\nOne\nTwo\nEnd", true)
        assertEquals(4, rows.size)
        assertEquals(setOf(0, 1), rows[1].cues)
        assertEquals(setOf(0, 1), rows[2].cues)
    }
    @Test fun unmatchedCueRemainsAvailableInsteadOfDisappearing() {
        val rows = lyricDisplayRows(listOf(LyricsReader.TimedLine(1000, "Cue")), "Other text", true)
        assertEquals(listOf("Other text", "Cue"), rows.map { it.text })
        assertEquals(setOf(0), rows.last().cues)
    }
}
