package com.teraphonia.cdglite

import androidx.documentfile.provider.DocumentFile
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class SongFormatLabelsTest {
    @Test fun existingSidecarsAndMidiKeepTheirActualFormatLabels() {
        val root = File(RuntimeEnvironment.getApplication().cacheDir, "marks-${System.nanoTime()}").apply { mkdirs() }
        val media = DocumentFile.fromFile(File(root, "Song.mp3").apply { writeBytes(byteArrayOf()) })
        for (extension in listOf("lrc", "txt", "srt", "lyr", "lyr3")) {
            val sidecar = DocumentFile.fromFile(File(root, "Song.$extension").apply { writeText("line") })
            assertEquals(listOf(extension.uppercase()), Song("Song", media, null, sidecar).formatMarks().map { it.text })
        }
        val cdg = DocumentFile.fromFile(File(root, "Song.cdg").apply { writeBytes(byteArrayOf()) })
        assertEquals(listOf("CDG", "LYR3"), Song("Song", media, cdg).formatMarks(true).map { it.text })
        for (extension in listOf("mid", "midi", "kar", "yt")) {
            val file = DocumentFile.fromFile(File(root, "Song.$extension").apply { writeBytes(byteArrayOf()) })
            assertEquals(listOf(extension.uppercase()), Song("Song", file, null).formatMarks().map { it.text })
        }
    }

    @Test fun ytInParentPathDoesNotTurnLocalAudioIntoYouTube() {
        val root = File(RuntimeEnvironment.getApplication().cacheDir, "archive.yt-${System.nanoTime()}").apply { mkdirs() }
        val media = DocumentFile.fromFile(File(root, "Song.mp3").apply { writeBytes(byteArrayOf()) })
        assertTrue(Song("Song", media, null).formatMarks().isEmpty())
    }
}
