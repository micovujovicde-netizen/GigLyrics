package com.teraphonia.cdglite

import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.documentfile.provider.DocumentFile
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class GigPlaylistSelectionTest {
    @get:Rule val compose = createComposeRule()

    @Test fun holdSelectsMultipleAndRemoveOnlyRemovesPlaylistReferences() {
        val app = RuntimeEnvironment.getApplication()
        app.getSharedPreferences("gigmonster_playlists", 0).edit().clear().commit()
        val files = (1..3).map { File(app.cacheDir, "Select $it.wav").apply { writeBytes(byteArrayOf(1)) } }
        val store = GigPlaylistStore(app)
        files.forEach { store.add(Song(it.name, DocumentFile.fromFile(it), null)) }
        var played = 0
        var removed: Set<String> = emptySet()
        compose.setContent {
            MaterialTheme {
                GigPlaylistPopup(store, 0, {}, false, {}, false, {}, { removed = it }, null, false, { _, _ -> played++ })
            }
        }
        compose.onNodeWithTag("playlistRow:0").performTouchInput { longClick() }
        compose.onNodeWithTag("playlistRow:1").performTouchInput { longClick() }
        compose.onNodeWithTag("gigRemove").performClick()
        compose.runOnIdle {
            assertEquals(0, played)
            assertEquals(2, removed.size)
            assertEquals(1, store.lists[0].size)
            assertTrue(files.all { it.exists() })
            assertEquals(1, GigPlaylistStore(app).lists[0].size)
        }
    }

    @Test fun quickRightSwipeRemovesWithoutPlayingTheSong() {
        val app = RuntimeEnvironment.getApplication()
        app.getSharedPreferences("gigmonster_playlists", 0).edit().clear().commit()
        val file = File(app.cacheDir, "Swipe.wav").apply { writeBytes(byteArrayOf(1)) }
        val store = GigPlaylistStore(app)
        store.add(Song("Swipe", DocumentFile.fromFile(file), null))
        var played = false
        compose.setContent {
            MaterialTheme { GigPlaylistPopup(store, 0, {}, false, {}, false, {}, {}, null, false, { _, _ -> played = true }) }
        }
        compose.onNodeWithTag("playlistRow:0").performTouchInput { swipeRight(durationMillis = 150) }
        compose.waitUntil(2000) { store.lists[0].isEmpty() }
        compose.runOnIdle { assertFalse(played); assertTrue(file.exists()) }
    }
}
