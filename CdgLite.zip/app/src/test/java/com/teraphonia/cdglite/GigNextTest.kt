package com.teraphonia.cdglite

import androidx.documentfile.provider.DocumentFile
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowMediaPlayer
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class GigNextTest {
    @Test fun nextOffStopsAdvancingAndNextOnAdvancesUntilTheEnd() {
        val app = RuntimeEnvironment.getApplication()
        app.getSharedPreferences("gigmonster_playlists", 0).edit().clear().commit()
        ShadowMediaPlayer.setMediaInfoProvider { ShadowMediaPlayer.MediaInfo(600000, 0) }
        val tracks = (1..3).map {
            Song("Next $it", DocumentFile.fromFile(File(app.cacheDir, "Next $it.wav").apply { writeBytes(byteArrayOf(1)) }), null)
        }
        val model = PlaybackModel(app)
        try {
            assertTrue(model.startGigPlaylist(tracks, 0, 0))
            assertFalse(model.onGigTrackEnded())
            assertEquals(tracks[0].name, model.song?.name)
            model.toggleGigNext()
            assertTrue(model.onGigTrackEnded())
            assertEquals(tracks[1].name, model.song?.name)
            model.removeFromGigQueue(setOf(tracks[1].mp3.uri.toString()))
            assertTrue(model.onGigTrackEnded())
            assertEquals(tracks[2].name, model.song?.name)
            assertFalse(model.onGigTrackEnded())
            assertTrue(app.getSharedPreferences("gigmonster_playlists", 0).getBoolean("nextEnabled", false))
        } finally { model.stop() }
    }
}
