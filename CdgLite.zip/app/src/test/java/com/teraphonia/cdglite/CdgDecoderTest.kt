package com.teraphonia.cdglite

import android.graphics.Color
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class CdgDecoderTest {
    private fun packet(instruction: Int, vararg data: Int): ByteArray =
        ByteArray(24).apply {
            this[0] = 9
            this[1] = instruction.toByte()
            data.forEachIndexed { i, value -> this[4 + i] = value.toByte() }
        }

    private fun palette() = packet(30, 0, 0, 63, 63)
    private fun tile() = packet(6, 0, 1, 1, 1, *IntArray(12) { 63 })

    @Test fun tileAndXorFollowThePlaybackClockAndRewind() {
        val decoder = CdgDecoder(palette() + tile() + packet(38, 0, 1, 1, 1, *IntArray(12) { 63 }))
        decoder.seekTo(7) // two packets at 300 packets/second
        val first = decoder.bitmapCopy()
        assertEquals(Color.WHITE, first.getPixel(6, 12))
        decoder.seekTo(10)
        assertEquals(Color.BLACK, decoder.bitmapCopy().getPixel(6, 12))
        assertEquals(Color.WHITE, first.getPixel(6, 12)) // displayed frame stays immutable
        decoder.seekTo(7)
        assertEquals(Color.WHITE, decoder.bitmapCopy().getPixel(6, 12))
    }

    @Test fun repeatedMemoryPresetDoesNotEraseLyrics() {
        val decoder = CdgDecoder(palette() + tile() + packet(1, 0, 1))
        decoder.seekTo(10)
        assertEquals(Color.WHITE, decoder.bitmapCopy().getPixel(6, 12))
    }

    @Test fun scrollMovesTheLyricsAndFillsTheExposedEdge() {
        val decoder = CdgDecoder(palette() + tile() + packet(20, 1, 16, 0))
        decoder.seekTo(10)
        val frame = decoder.bitmapCopy()
        assertEquals(Color.WHITE, frame.getPixel(12, 12))
        assertEquals(Color.BLACK, frame.getPixel(6, 12))
        assertEquals(Color.WHITE, frame.getPixel(0, 12))
    }
}
