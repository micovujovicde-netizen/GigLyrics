# GigMonster Screen — Android TV test receiver

Small Android TV/Google TV receiver for GigMonster stage output.

## What it does now
- Full-screen black stage output.
- Idle/disconnected state: centered GigMonster logo only.
- Receives local-Wi-Fi GigMonster commands over raw TCP.
- Supports current + next lyric line.
- Supports full image frames (for later CDG/video-frame testing).
- No audio playback. Audio remains on the tablet/PA by design.
- Keeps the TV awake while running.

## Network protocol v1
- UDP discovery port: `49510`
- Discovery request: `GIGMONSTER_DISCOVER_V1`
- Reply: `GIGMONSTER_SCREEN_V1|<TV model>|49511`
- TCP control port: `49511`
- One JSON command per line.

Examples:
```json
{"type":"logo"}
{"type":"lyrics","current":"Current lyric line","next":"Next lyric line"}
{"type":"frame","data":"<base64 PNG/JPEG>"}
{"type":"ping"}
```

## Build
Same base toolchain as the main GigMonster project:
- Gradle wrapper 8.9
- Android Gradle Plugin 8.7.3
- Kotlin 2.3.0
- Java 17
- compile/target SDK 35

Build command:
```bash
./gradlew assembleDebug
```
APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Existing GitHub workflow
The project layout is deliberately the same simple root + `app/` layout used by CdgLite/GigMonster. If the existing GitHub workflow is hard-coded to the archive name `CdgLite.zip`, upload this TV project under that filename for the test build, or change only the workflow input filename to `GigMonsterScreen.zip`.
