# CdgLite 1.1 — CANON build 3

Android 8+ (package `com.teraphonia.cdglite`). Ova verzija primjenjuje priloženi CANON.md.

## Korišćenje

- FOLDER bira biblioteku. LOCAL SEARCH + Enter/GO pretražuje cijeli izabrani korijen, kroz sve podfoldere. MIC automatski izvršava lokalnu ili web pretragu čim prepozna govor.
- HOME vraća glavni folder. ‹ ide tačno jedan nivo gore, a na korijenu je onemogućen. Navigacija čuva reprodukciju i otvoreni lokalni CDG/tekst popup.
- Prvi tap na MP3 pokreće pjesmu, sljedeći tap na isti aktivni MP3 zaustavlja je; naredni je ponovo pokreće. Samo aktivni fajl ima mali ▶/■ indikator.
- × odmah sklanja lokalni popup bez prekida pjesme. Popup zaustavlja dodire prema listi ispod. Kontrole veličine i PAUZA/STOP ostaju dostupne.
- .lyr, .lyr3 (uključujući Lyrics3 v1/v2), .srt i .txt otvaraju se kao tekst. Istoimeni tekst se automatski otvara uz MP3 ako nema CDG fajla. Tekst se ručno skroluje bez prekida muzike.
- Pinch sa dva prsta u listi mijenja samo nazive foldera/fajlova. Jedan prst normalno skroluje listu. Veličina se pamti i pinch radi i poslije novog pokretanja.
- Glavni Volume upravlja Androidovim medijskim zvukom, pa važi za MP3 i Web/YouTube. Hardverske promjene jačine se odražavaju na klizaču.
- Otvaranje Weba sklanja lokalni popup, ali ne prekida MP3. Centralni transparentni ▶ PLAY / ■ STOP prati događaje stvarne HTML audio/video reprodukcije. MP3 se zaustavlja tek kada Web zaista krene.
- HOME/‹ sklanjaju Web prozor iz prikaza, ali Web audio nastavlja. WEB dugme ga ponovo prikazuje. Tek pokretanje lokalnog MP3 trenutno utišava i pauzira Web. × na Web prozoru zatvara Web i njegov zvuk.

## Web kompatibilnost

Kontrolisana reprodukcija koristi ažuriran Android System WebView sa podrškom za dokument-start skripte, poruke iz iframeova i nativno utišavanje. Ako WebView nema te mogućnosti, aplikacija prikazuje poruku za ažuriranje, umjesto da dozvoli nekontrolisano preklapanje dva izvora. YouTube pretraga ostaje obična pretraga, ali izabrani video se otvara kroz standardni YouTube embed player. Podržani su i ostali HTML audio/video plejeri; prijava, oglasi i ograničenja sadržaja ostaju pod kontrolom izvornog sajta.

## Build i testovi

JDK 17, Android SDK 35. Postavi ANDROID_HOME, zatim:

```
./gradlew :app:assembleDebug :app:testDebugUnitTest
```

Za test na uređaju/emulatoru:

```
./gradlew :app:connectedDebugAndroidTest
```

Test DevicePlaybackTest koristi stvarni MediaPlayer i WebView, lokalno generisan WAV i HTML audio fixture, bez tuđeg sadržaja. Local UI testovi pokreću stvarne Compose površine i dodirne gestove pod Robolectricom. Web bridge test je u `verification/test_web.py` i koristi Playwright sa Chromiumom.

Opciona promjenljiva CDGLITE_DEBUG_KEYSTORE bira razvojni ključ (alias androiddebugkey, lozinka android). Dostavljeni build 3 ima isti potpis kao prethodni dostavljeni APK 1.1, pa se instalira kao nadogradnja. Ako još koristiš originalni APK 1.0, različit potpis zahtijeva uklanjanje stare aplikacije; MP3/CDG fajlovi u izabranom folderu ostaju sačuvani.

CDG dekoder i dalje podržava memory/border preset, tile normal/XOR i CLUT; scroll komande nisu dio ovog zahvata. Aplikacija nije pozadinski foreground audio servis.
