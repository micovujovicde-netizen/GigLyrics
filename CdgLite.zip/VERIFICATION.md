# Finalna provjera — CANON build 3

Rezultat: BUILD SUCCESSFUL. APK: CdgLite 1.1, versionCode 3, minSdk 26, targetSdk 35.
Potpis provjeren pomoću apksigner; jednak prethodno isporučenom CdgLite 1.1 APK-u.

## Izvršeno i prošlo

- 9 automatskih testova, 0 grešaka i 0 neuspjeha.
- Stvarne Compose UI površine pod Robolectricom: Enter/IME/GO, blokiranje dodira i prevlačenja kroz popup, X i promjena veličine, HOME/Back, čuvanje reprodukcije, MP3 PLAY/STOP indikator, tekstualno skrolovanje uz muziku, pinch i njegova postojanost poslije rekreiranja ekrana.
- Integracija stanja lokalnog i Web kontrolera: Web preuzima aktivni izvor tek na potvrđeni playback događaj; lokalni početak ponovo preuzima izvor i zaustavlja Web stanje. Lokalni MediaPlayer u ovoj provjeri je simuliran.
- Pretraga kroz 35 nivoa podfoldera; povezivanje pratećeg teksta; TXT UTF-8/UTF-16, LYR, SRT, Lyrics3 v1/v2; CDG paleta.
- Stvarni Chromium i HTML audio, bez lažnih play događaja: sprečavanje neodobrenog autoplay-a, PLAY/STOP, cross-origin iframe i identifikacija aktuelnog ciklusa događaja. Skripta verification/test_web.py koristi isti web-audio.js kao APK.
- Sastavljeni su glavni APK i Android instrumentation test APK.

## Granice provjere

Android emulator se u ovom Windows okruženju gasi prije podizanja sistema, i sa 64-bitnom i sa 32-bitnom slikom bez hardverskog ubrzanja. Zbog toga DevicePlaybackTest nije izvršen na Android uređaju. Stvarna kombinacija MediaPlayer + Android WebView i reprodukcija na javnom YouTube sajtu još zahtijevaju probu na uređaju; Chromium fixture test nije zamjena za tu provjeru. Mic callback automatski poziva istu Search radnju, ali stvarni govorni servis nije testiran.

Nije predstavljeno kao završena provjera fizičkog telefona. Izvorni projekat sadrži DevicePlaybackTest za tu provjeru i CANON.md sa zahtjevima.

## Lyrics popup runtime fix (v1.2-lyrics-fix)
Local selected media now keeps the half-screen surface in the layout even if the showCdg state flag is lost. Content priority remains CDG -> discovered same-stem text sidecar -> embedded MP3 Lyrics3 -> Find lyrics online.

## v30 — floating player and playlist controls

- A floating window uses the existing playback session and decoded CDG frame.
  First tap expands to half the display; the next tap returns to MainActivity.
  Android display-over-other-apps permission is required; native PiP remains
  the fallback when permission is unavailable.
- Animated first-use folder and playlist instructions are bundled GIF assets.
- Playlist: quick right swipe removes a reference; long press selects multiple
  rows; REMOVE changes to green when selection is nonempty.
- NEXT OFF preserves stop-at-end behavior. NEXT ON advances the active queue
  on local completion and official YouTube ENDED events; it stops at the last
  entry. This is automatic progression, not a guarantee of sample-gapless audio.
- Added selection/removal and NEXT regression tests. These tests and APK build
  have not been executed here because the Gradle distribution is unavailable.
- GIF animation bytes, manifest XML, and ZIP integrity checked locally. Device
  overlay permission, taps, surface handoff, and audio continuity need APK QA.
