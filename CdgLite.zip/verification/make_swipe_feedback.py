from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

OUT = Path(__file__).resolve().parents[1] / 'app/src/main/res/drawable-nodpi'
FONT = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 58)
for action in ('added', 'removed'):
    for playlist in range(1, 5):
        text = f'{action.capitalize()} '+ ('to' if action == 'added' else 'from') + f' P{playlist}'
        frames = []
        for i in range(20):
            frame = Image.new('RGB', (800, 180), '#101610')
            d = ImageDraw.Draw(frame)
            d.rounded_rectangle((5, 5, 795, 175), radius=18, outline='#92ee00', width=5)
            width = d.textbbox((0, 0), text, font=FONT)[2]
            d.text(((800-width)/2, 48), text, fill='white', font=FONT)
            # Moving green underline makes the confirmation visibly animated.
            x = 30 + i * 31
            d.rounded_rectangle((x, 142, min(x+140,770), 152), radius=4, fill='#92ee00')
            frames.append(frame)
        frames[0].save(OUT/f'swipe_{action}_p{playlist}.gif', save_all=True, append_images=frames[1:], duration=100, loop=0, optimize=True)
