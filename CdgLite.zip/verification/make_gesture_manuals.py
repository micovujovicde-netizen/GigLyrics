from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'app/src/main/res/drawable-nodpi'
OUT.mkdir(parents=True, exist_ok=True)
FONT = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
GREEN = '#92ee00'

def finger(draw, x, y, hold=False):
    if hold:
        draw.ellipse((x-32,y-32,x+32,y+32), outline=GREEN, width=4)
    draw.rounded_rectangle((x-12,y,x+12,y+60), radius=12, fill='white')
    draw.rounded_rectangle((x-27,y+40,x+34,y+86), radius=16, fill='white')
    draw.line((x+32,y+60,x+49,y+50), fill='white', width=17)

def frames(pages):
    result=[]
    for title, subtitle, gesture in pages:
        for i in range(45):
            im=Image.new('RGB',(800,250),'#101610');d=ImageDraw.Draw(im)
            for text,y,size,color in [(title,10,36,'white'),(subtitle,55,30,GREEN)]:
                f=ImageFont.truetype(FONT,size)
                while d.textbbox((0,0),text,font=f)[2] > 775:
                    size-=1;f=ImageFont.truetype(FONT,size)
                d.text(((800-d.textbbox((0,0),text,font=f)[2])/2,y),text,font=f,fill=color)
            d.rounded_rectangle((50,112,750,215),radius=14,fill='#303830',outline=GREEN,width=2)
            d.text((70,132),'Song',font=ImageFont.truetype(FONT,30),fill='white')
            progress=min(i/26,1)
            if gesture=='swipe':
                d.line((250,153,670,153),fill=GREEN,width=8)
                d.polygon([(670,153),(642,136),(642,170)],fill=GREEN)
                finger(d, int(260+progress*370),140)
            elif gesture=='select':
                if i>14:d.rounded_rectangle((50,112,750,215),radius=14,fill='#686868',outline=GREEN,width=3)
                finger(d,390,135,hold=True)
            elif gesture=='remove':
                d.rounded_rectangle((445,125,722,194),radius=9,fill=GREEN)
                d.text((465,143),'REMOVE',font=ImageFont.truetype(FONT,31),fill='black')
                finger(d,585,155)
            elif gesture=='next':
                on=i>20
                d.text((275,141),'NEXT '+('ON' if on else 'OFF'),font=ImageFont.truetype(FONT,32),fill=GREEN if on else 'white')
                finger(d,530,157)
            result.append(im)
    return result

def save(name,pages):
    all_frames=frames(pages)
    all_frames[0].save(OUT/name,save_all=True,append_images=all_frames[1:],duration=65,loop=0,optimize=True)

save('folder_swipe_hint.gif', [('Swipe right to add song','to playlist','swipe')])
save('playlist_gesture_hint.gif', [
    ('Swipe right to remove song','from playlist','swipe'),
    ('Hold to select songs','Select one or more','select'),
    ('Tap REMOVE','Remove selected songs','remove'),
    ('NEXT ON / OFF','Auto-play the next song','next'),
])
