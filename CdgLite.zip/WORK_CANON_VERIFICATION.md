# Work canon — 1.7.0 / versionCode 34

Implemented:
- Main HOME closes playlist visibility through the existing home flow without stopping music or changing P1–P4. Also handles PL open without a local root.
- Source trace: PL is bounded to the browser area below navigation. Confirmed HOME defect: playlist visibility remained set. Touch interception was not demonstrated; top-bar taps still need device verification.
- Shared format-label renderer for browser/PL, using existing Song media/CDG/text references. PL metadata and MP3-tail checks run off the UI thread and are cached while the panel is open. YT uses resolved media extension, not URI substring detection. Matching and playback are unchanged.
- Consistent compact transport styling across local/web/lyrics bars, 48dp minimum touch height. NEXT already had ON/OFF; refined OFF styling. Playlist touch height retained at 48dp inside margins.
- HQ increased from 18dp/8sp to 22dp/10sp. Green active P tabs, darker inactive tabs, no restored lock control or lock decoration.
- Green HOME/search accents; consistent 9dp search/transpose corners; search action/mic controls aligned at 62dp and GO kept on one line.
- HOME artwork retains original opacity and aspect ratio. Alpha masks: horizontal 13%, top 8%, bottom 11%, rising to 15% adjacent to popup. No random noise, raster edits, additional global dimming or new decorations.
- Existing lyrics display, folder icons, current-song grey bar, CDG/PiP, playback engines, sync/save and long-press retained.

Checks passed:
- All original archive entries retained.
- Playback engines, matching/scanning, CDG decoder, floating player, playlist store and web controllers byte-identical to input.
- PiP branch and CDG surface byte-identical to input.
- Kotlin lexical delimiter check (not compilation).
- Source diff reviewed against canon and original screenshots.
- Final ZIP integrity check.

Build/testing limitation:
Gradle wrapper could not download Gradle 8.9: Network is unreachable. No cached build runtime was found in inspected locations. APK compilation and all runtime/unit tests were NOT executed; no new runtime screenshots were produced.
Added regression tests for actual HOME taps dismissing PL without losing playback/P3 references, format labels and false YT substring identification.

Tablet checks required:
HOME and other top-bar taps in PL with popup open/minimized; P1–P4 and continued playback; format labels/long titles/sidecar opening; NEXT/auto-next; monitor/EXT/fullscreen/transpose; CDG/PiP; sync edit/save; web extract/edit/save; full and reduced HOME bitmap edges.


## Additional requested changes — 1.7.1 / versionCode 35
- Thin minus/plus controls at top right of the text popup; 48dp touch targets around 36x28dp outlines. Range 20–72sp, step 2sp, persisted between songs/app restarts.
- Plain text, timestamp-follow, Sync Edit and video-associated text use the selected size and proportional line height. Existing MIDI/KAR embedded lyrics and resolved text sidecars follow the same text display path. CDG bitmap and PiP untouched.
- Dedicated 48dp control row prevents font buttons overlapping lyric tap/scroll targets.
- Playlist uses opaque nearly-black green #061008 and fills the available browser area above any local text/CDG panel. Current-song grey highlight and format colors unchanged.
- Source preservation/lexical checks and final ZIP integrity passed. Gradle download again failed with Network is unreachable; compile/runtime tests NOT executed. Verify font resizing, remembered size, sync line taps/auto-follow and PL background on tablet.


## Sync follow / SD refresh — 1.7.2 / versionCode 36
- Popup now follows nonempty parsed timestamps even when showTextOnly was set by partial synchronization. Previously the popup fell back to plain text while the floating window continued following cues.
- Partially timed text preserves untimed source lines; each cue maps to its original visible rows (including multiline captions and repeated timestamps). Unmatched cue text is retained. Current cue highlights/auto-scroll work in the timed display. Sync Edit still uses its separate tap workflow.
- Font-size changes re-anchor the currently active line after resizing. No synthetic timing is added to files without timestamps.
- Folder scans/deep indexing sample file name/type once per entry rather than repeatedly querying the SD provider during grouping/matching. Matching priority, sorting, extension support and retry schedule unchanged.
- Up to 24 visited-folder snapshots display immediately on return while the normal refresh runs. Cache is invalidated by root change and app-triggered file edits. No additional polling or forced retries; this improves perceived return speed but does not remove SD hardware/provider latency.
- Kotlin lexical/source-preservation and ZIP integrity checks passed. Added partial-cue regression tests; compilation/tests/device playback still unverified because Gradle is unavailable offline.


## Artwork/playlist label — 1.7.3 / versionCode 37
- Main playlist toggle reads EXIT PLAYLIST while PL is open, otherwise PLAYLIST • Pn. Existing toggle action unchanged.
- HOME artwork opacity multiplied by 0.9 (0.5146 → 0.46314).
- Rounded feather mask built from 24 smooth alpha contours, combined with existing edge fades. No raster edit, distortion or randomization.
- In reduced HOME space, reserve 148dp at the right for search GO/microphone controls; fit artwork to the remaining area so it moves left with aspect ratio preserved. Normal HOME positioning retained.
- Playback, PiP, sync/font controls, matching and SD scan code untouched in this change.
- Lexical/source-diff/ZIP integrity checks passed; build and actual screen appearance remain unverified on device (Gradle unavailable offline).


## YouTube surface handoff — 1.7.4 / versionCode 38
- Native YouTube AndroidView uses remembered movable content across Android PiP/browser destinations, preserving its composition/player instead of recreating its host composition.
- Both floating-window restoration and Android PiP transitions capture playback intent and complete a single guarded continuation only after the same live surface is attached. Playing sessions issue play without seek/reload. Explicit pause/stop, ended tracks, released player and session changes invalidate pending continuation.
- Attachment listeners are one-shot; stale callbacks are guarded by transfer generation/session/player identity. No forced-play loop or native thread-priority change.
- Deep SD index startup yields 500ms for surface/UI restoration; normal visible folder refresh remains unchanged.
- Lexical/source-preservation and ZIP integrity checks passed. Gradle 8.9 download again failed with Network is unreachable, so APK compilation and playback/device tests were NOT run.
- Verify repeated floating/Android PiP return while playing and paused, playlist auto-next, stop during transition, and return with an SD folder open. This is a source-level fix pending device confirmation.


## Compact return bar — 1.7.5 / versionCode 39
- While playback/preparation is active and no playback popup is visibly open, minimizing selects a compact overlay rather than the content popup. Includes local audio/MIDI, YouTube and BREAK timer sources; regular popup behavior retained when visible.
- Compact overlay: nearly black green, thin green rounded border, decorative logo, remaining minutes/seconds and BACK TO GIGMONSTER. Unknown duration shows --:--. Negative remaining time clamps to zero.
- A single tap returns the existing task without stopping/restarting playback. Slow drag can reposition; existing fast-swipe app-close behavior retained. Timer ticks every 500ms.
- Android PiP fallback uses wide 2.39:1 presentation and one BACK TO GIGMONSTER RemoteAction; OS manages taps on the PiP window itself. Floating overlay still requires the existing overlay permission.
- Compact overlay does not move local video or native YouTube surfaces. Playback engines and existing handoff code unchanged.
- Source preservation, lexical checks and ZIP integrity passed. Build/runtime/device tests remain unexecuted due unavailable offline Gradle. Verify minimize from hidden/no popup in local, MIDI, YT and BREAK, remaining timer, one-tap return, and standard popup when visible.


## Build log correction
GitHub log logs_100332986609.zip reported FloatingPlayer.kt:171–172: unterminated string. The BACK TO / GIGMONSTER label accidentally contained a raw newline in an ordinary string. Corrected it to the escaped newline sequence. No feature changes.
Checked all Kotlin ordinary strings for raw newlines, and final ZIP integrity passed. The earlier delimiter check did not detect this error. Compilation still requires another CI run; a successful build is not claimed.
