# Work canon — 1.7.0 / versionCode 34

Implemented:
- Main HOME closes playlist visibility through the existing home flow without stopping music or changing P1–P4. Also handles PL open without a local root.
- Source trace: PL is bounded to the browser area below navigation. Confirmed HOME defect: playlist visibility remained set. Touch interception was not demonstrated; top-bar taps still need device verification.
- Shared format-label renderer for browser/PL, using existing Song media/CDG/text references. PL metadata and MP3-tail checks run off the UI thread and are cached while the panel is open. YT uses resolved media extension, not URI substring detection. Matching and playback are unchanged.
- Consistent compact transport styling across local/web/lyrics bars, 48dp minimum touch height. NEXT already had ON/OFF; refined OFF styling. Playlist touch height retained at 48dp inside margins.
- HQ increased from 18dp/8sp to 22dp/10sp. Green active P tabs, darker inactive tabs, no restored lock control or lock decoration.
- Green HOME/search accents; consistent 9dp search/transpose corners; search action/mic controls aligned at 62dp and GO kept on one line.
- HOME artwork retains original opacity and aspect ratio. Alpha masks: horizontal 13%, top 8%, bottom 11%, rising to 15% adjacent to popup. No random noise, raster edits, additional global dimming or new decorations.
- Existing lyrics display, folder icons, current-song grey bar, CDG/PiP, playback engines, sync/save and long-press retained.

Checks passed:
- All original archive entries retained.
- Playback engines, matching/scanning, CDG decoder, floating player, playlist store and web controllers byte-identical to input.
- PiP branch and CDG surface byte-identical to input.
- Kotlin lexical delimiter check (not compilation).
- Source diff reviewed against canon and original screenshots.
- Final ZIP integrity check.

Build/testing limitation:
Gradle wrapper could not download Gradle 8.9: Network is unreachable. No cached build runtime was found in inspected locations. APK compilation and all runtime/unit tests were NOT executed; no new runtime screenshots were produced.
Added regression tests for actual HOME taps dismissing PL without losing playback/P3 references, format labels and false YT substring identification.

Tablet checks required:
HOME and other top-bar taps in PL with popup open/minimized; P1–P4 and continued playback; format labels/long titles/sidecar opening; NEXT/auto-next; monitor/EXT/fullscreen/transpose; CDG/PiP; sync edit/save; web extract/edit/save; full and reduced HOME bitmap edges.


## Additional requested changes — 1.7.1 / versionCode 35
- Thin minus/plus controls at top right of the text popup; 48dp touch targets around 36x28dp outlines. Range 20–72sp, step 2sp, persisted between songs/app restarts.
- Plain text, timestamp-follow, Sync Edit and video-associated text use the selected size and proportional line height. Existing MIDI/KAR embedded lyrics and resolved text sidecars follow the same text display path. CDG bitmap and PiP untouched.
- Dedicated 48dp control row prevents font buttons overlapping lyric tap/scroll targets.
- Playlist uses opaque nearly-black green #061008 and fills the available browser area above any local text/CDG panel. Current-song grey highlight and format colors unchanged.
- Source preservation/lexical checks and final ZIP integrity passed. Gradle download again failed with Network is unreachable; compile/runtime tests NOT executed. Verify font resizing, remembered size, sync line taps/auto-follow and PL background on tablet.
