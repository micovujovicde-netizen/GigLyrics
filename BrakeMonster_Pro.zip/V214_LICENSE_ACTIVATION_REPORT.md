# BrakeMonster PRO — v214 license activation / REBUY fix

**Source of truth:** user-supplied `BrakeMonster_Pro.zip` (2026-11-01).
**Input SHA-256:** `3985ce1d2deb1ce5981fd00f51ff51d3916e97f02f12fb25c7354c6e1200965e`
**Input:** `versionCode=213`, `versionName=1.0.178-pro.97[-TEST]`
**Output:** `versionCode=214`, `versionName=1.0.179-pro.98[-TEST]`
**Application ID (unchanged):** `com.teraphonia.breakmonster.pro`

## What was changed

- Added `LicenseValidity.kt` to interpret both `validUntil` response representations:
  - TEST v4.1: epoch milliseconds (`number`).
  - PRODUCTION v4.2 R2: ISO-8601 UTC (`string`), or `null` for Lifetime.
- An active Lifetime purchase can now be reflected in the app; the original offline limit of at most **72 hours since last server confirmation** is retained.
- The app refuses to activate expired, malformed or inactive licenses.
- Following a checkout browser return, the app refreshes the license immediately and, for recent checkouts only, retries after 5/10/15/20 seconds to allow for a delayed Creem webhook. Checks are async and never issue player commands.
- The existing TEST/PRODUCTION split, signing configuration, application ID, Media3, RollMonster, playlists, UI controls, backup and WebView remain unchanged.
- Bumped Android version code/name for in-place upgrade to 214.

Files changed from source ZIP:
- `app/build.gradle.kts`
- `app/src/main/java/com/teraphonia/breakmonster/CommercialRelease.kt`

Files added:
- `app/src/main/java/com/teraphonia/breakmonster/LicenseValidity.kt`
- `tools/LicenseValidityTest.kt`
- `V214_LICENSE_ACTIVATION_REPORT.md`

## Checks actually performed

`kotlinc ... LicenseValidityTest.kt` / `java -jar ...`: **11/11 PASS** including production ISO expiration, TEST integer expiration, Lifetime null, revoked/inactive, missing or malformed expiry.

**Not built here:** Android SDK 35 and original signing keystore are not available in this environment. No v214 APK was produced or tested on a device. Actual Creem CHECKOUT/REBUY still requires an end-to-end test on a device.

## Build using the already configured GitHub workflow

1. Upload THIS ZIP as `BrakeMonster_Pro.zip` to the existing BrakeMonster app repository. Do not upload it to `brakemonster-license` (that's the Cloudflare backend repository).
2. Wait for the source build checks to complete, then manually run **Build BrakeMonster PRO candidate** with **`license_test_mode=true`** for the isolated TEST APK.
3. Verify version code 214 and name `1.0.179-pro.98-TEST`; the same original signing certificate must be used if installing over an existing 213 app. Do not uninstall/clear data; otherwise the local installation token and playlists may be lost.
4. Test license check on A9+, existing TEST purchase and renewal; verify BM PRO icon/status and that playlist/player functions still work. Avoid purchasing again before checking existing test entitlement.
5. Only after TEST device QA, build with `license_test_mode=false` for PRODUCTION. `BILLING_ENABLED=false` on live Worker must remain until the real checkout flow has been authorized and verified.

Important: tests of only the license-time parser are not complete Android build tests. Do not treat 11/11 as a guarantee the APK works.
