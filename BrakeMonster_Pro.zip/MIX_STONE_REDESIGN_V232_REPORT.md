# BrakeMonster PRO — MIX popup stone redesign v232

Source archive (most recent Library BrakeMonster_Pro ZIP when work began): BrakeMonster_Pro(20261103-073456).zip
Original SHA-256: 5fca1ca99dc5174d94627491e93873c7456a7c38276ae7d48d8cf8e2871767d7
Original versionCode / versionName: 231 / 1.0.187-pro.115
Final versionCode / versionName: 232 / 1.0.188-pro.116 (TEST suffix when configured)

Modified **only**:
- app/src/main/java/com/teraphonia/breakmonster/MainActivity.kt
  - Existing ProMixerDialog still receives original callbacks, -1..1 Slider range and existing enabled/WAIT guard.
  - Custom Material3 Slider thumb: tiny non-interactive Baba traveling with the slider; custom carved-stone track.
  - Existing StoneBufferColumn draws 8 broad spaced slabs, filled only, using unchanged bufferedPercent and percentage text.
- app/build.gradle.kts: version bump only.

Added:
- app/src/main/assets/mixer_baba/Baba_Pterodaktil_Blink.webp: intact source animation.
- app/src/main/assets/mixer_baba/frame_00.webp .. frame_03.webp: lossless frames from source animation for Compose playback on Android 26+.

No edits to Media3/ExoPlayer, A/B, auto mix, buffering, preloading, WAIT audio, queue, FX, license, Cloudflare, payment, website or other UI.

Validation:
- Static checks passed: original dialog retained, callbacks, toggle/seconds/done labels, value range, enabled guard, percentages, filled-only slabs, two visual helpers.
- Source/4 extracted frames tested pixel-for-pixel lossless.
- Archive integrity tested and all original non-targeted files content-unchanged.
- Android APK **not built**: Android SDK and cached Gradle 8.9 distribution unavailable; wrapper fails with UnknownHostException (no network access).
- Manual functional checks (phone/tablet screenshot, finger drag/touch, end positions, actual A/B buffer and AUTO MIX) require an Android device. They are NOT claimed as tested.

Upload `BrakeMonster_Pro.zip` to your existing GitHub Actions flow to compile and test the APK.
