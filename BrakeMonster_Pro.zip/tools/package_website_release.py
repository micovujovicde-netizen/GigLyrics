#!/usr/bin/env python3
"""Verify an original-key release; package private distribution, never publish."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
APP_ID = 'com.teraphonia.breakmonster.pro'
CODE = 211
NAME = '1.0.176-pro.95'


def run(*args):
    return subprocess.check_output([str(a) for a in args], text=True, stderr=subprocess.STDOUT)


def package(apk, output):
    apk = apk.resolve(strict=True)
    # A source ZIP, unsigned APK or debug-signed replacement is never accepted.
    with zipfile.ZipFile(apk) as z:
        if not {'AndroidManifest.xml', 'classes.dex'}.issubset(z.namelist()):
            raise ValueError('Not an Android installation APK')
    sdk_value = os.environ.get('ANDROID_HOME') or os.environ.get('ANDROID_SDK_ROOT')
    if not sdk_value:
        raise ValueError('Android SDK is required to verify APK metadata and signature')
    sdk = Path(sdk_value)
    versions = sorted((sdk / 'build-tools').glob('*'), key=lambda p: tuple(int(x) for x in re.findall(r'\d+', p.name)))
    if not versions:
        raise ValueError('Android SDK build tools missing')
    build_tools = versions[-1]
    cert = run(build_tools / 'apksigner', 'verify', '--verbose', '--print-certs', apk)
    digests = re.findall(r'^Signer #\d+ certificate SHA-256 digest: ([a-fA-F0-9]+)$', cert, re.M)
    expected = os.environ.get('BM_EXPECTED_CERT_SHA256', '').replace(':', '').lower().strip()
    if not re.fullmatch('[a-f0-9]{64}', expected):
        raise ValueError('Original installed-app certificate SHA-256 must be provided')
    if len(digests) != 1 or digests[0].lower() != expected or 'Android Debug' in cert:
        raise ValueError('APK is not signed by the expected original release certificate')
    badging = run(build_tools / 'aapt', 'dump', 'badging', apk)
    if 'application-debuggable' in badging:
        raise ValueError('Debuggable APK rejected')
    line = next(x for x in badging.splitlines() if x.startswith('package:'))
    for field, value in [('name', APP_ID), ('versionCode', str(CODE)), ('versionName', NAME)]:
        if re.search(r"\b" + field + r"='([^']*)'", line).group(1) != value:
            raise ValueError('Unexpected APK ' + field)
    if "sdkVersion:'26'" not in badging:
        raise ValueError('Unexpected minimum Android SDK')
    digest = hashlib.sha256(apk.read_bytes()).hexdigest()
    output.mkdir(parents=True, exist_ok=True)
    target = output / 'BrakeMonster-PRO.apk'
    shutil.copyfile(apk, target)
    public = ROOT / 'distribution/public-site'
    # Fail closed: public content must not contain paid binary downloads.
    if any(public.rglob('*.apk')) or any(public.rglob('*.aab')):
        raise ValueError('Paid binary found in public website folder')
    meta = dict(applicationId=APP_ID, versionCode=CODE, versionName=NAME, minSdk=26,
                sha256=digest, sizeBytes=apk.stat().st_size,
                signingCertificateSha256=expected, debuggable=False,
                buildVerified=True, deviceVerified=False, publicDownloadEnabled=False)
    with zipfile.ZipFile(output / 'BrakeMonster-PRO-WEBSITE.zip', 'w', zipfile.ZIP_DEFLATED) as z:
        z.write(target, 'private/BrakeMonster-PRO.apk')
        z.writestr('VERSION.json', json.dumps(meta, indent=2) + '\n')
        z.writestr('SHA256SUMS.txt', digest + '  private/BrakeMonster-PRO.apk\n')
        z.writestr('SIGNATURE.txt', cert)
        z.write(ROOT / 'distribution/INSTALL.txt', 'INSTALL.txt')
        z.write(ROOT / 'distribution/INTEGRATION.md', 'INTEGRATION.md')
        for p in sorted(public.rglob('*')):
            if p.is_file():
                if p.name == 'latest.json' and p.parent.name == 'releases':
                    release = json.loads(p.read_text())
                    release['buildVerified'] = True
                    release['status'] = 'Signed build verified. Device QA and protected delivery pending.'
                    z.writestr('public-site/' + p.relative_to(public).as_posix(), json.dumps(release, indent=2) + '\n')
                else:
                    z.write(p, 'public-site/' + p.relative_to(public).as_posix())
    (output / 'APK-VERIFICATION.json').write_text(json.dumps(meta, indent=2) + '\n')
    print(json.dumps(meta, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('apk', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    package(args.apk, args.output)
