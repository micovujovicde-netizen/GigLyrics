import com.teraphonia.breakmonster.LicenseValidity

fun main() {
    val now = java.time.Instant.parse("2026-11-01T05:00:00Z").toEpochMilli()
    val future = java.time.Instant.parse("2026-12-01T05:00:00Z").toEpochMilli()
    val past = java.time.Instant.parse("2026-10-01T05:00:00Z").toEpochMilli()
    var passed = 0
    fun case(label: String, actual: Long, expected: Long) {
        check(actual == expected) { "$label: got $actual expected $expected" }
        println("PASS: $label")
        passed++
    }
    case("TEST epoch millis", LicenseValidity.confirmedPaidUntil(true,"subscription",future,now),future)
    case("PRODUCTION ISO Z", LicenseValidity.confirmedPaidUntil(true,"subscription","2026-12-01T05:00:00.000Z",now),future)
    case("numeric string", LicenseValidity.confirmedPaidUntil(true,"subscription",future.toString(),now),future)
    case("active lifetime NULL", LicenseValidity.confirmedPaidUntil(true,"lifetime",null,now),Long.MAX_VALUE)
    case("inactive lifetime NULL", LicenseValidity.confirmedPaidUntil(false,"lifetime",null,now),0)
    case("inactive subscription", LicenseValidity.confirmedPaidUntil(false,"subscription",future,now),0)
    case("expired subscription", LicenseValidity.confirmedPaidUntil(true,"subscription",past,now),0)
    case("missing expiry monthly", LicenseValidity.confirmedPaidUntil(true,"subscription",null,now),0)
    case("malformed expiry", LicenseValidity.confirmedPaidUntil(true,"subscription","junk",now),0)
    case("JSON null surrogate", LicenseValidity.confirmedPaidUntil(true,"subscription",Any(),now),0)
    // Confirmed offline lifetime access is separately bounded to 72 h:
    val lifetime = LicenseValidity.confirmedPaidUntil(true,"lifetime",null,now)
    check(now + 72*3_600_000L < lifetime)
    println("PASS: lifetime still requires 72h offline age limit in CommercialRelease")
    passed++
    println("TOTAL: $passed PASS")
}
