# BrakeMonster PRO v219 — TEST checkout and crash diagnostics

Base: user-confirmed v218 ZIP, checksum `06d58d398ec9de78351b5dfdb8e4392ea7ca99f342bc172d52cc9b7643922f7f`.

Changes in Android source:
- TEST plan selector stays open while checkout request is pending; closes only after successful browser launch.
- Failed checkout immediately shows Worker's HTTP code, provider HTTP code, safe Creem message and trace identifier, including during audio playback.
- Checkout failures and browser-opening attempts are logged without credentials or user tokens.
- Return-from-browser recheck runs while a paid upgrade is pending even if an old monthly entitlement is already active; successful upgrade is recognized by a later paid-until value.
- BLACK BOX export now includes the persisted fatal crash report, when available.
- versionCode=219; versionName=1.0.184-pro.103 (-TEST in TEST builds).

TEST Worker (separate deliverable): log sanitized provider error message and automatically probe the YEARLY product using the same TEST API key only after a failed YEARLY checkout HTTP 404. This produces no charge and exposes no API key. Tests include four mocked provider scenarios and disabled billing.

Unchanged: audio engine, D1 schema, webhook entitlement policy and production Worker.

Limitations: Android source has NOT been compiled or tested on a real device here. TEST Worker passes Node syntax validation and five local unit simulations; no live Creem API test was performed. Deploy TEST Worker and compile TEST APK, then try one YEARLY checkout. Do not treat a local simulation as real purchase verification.
