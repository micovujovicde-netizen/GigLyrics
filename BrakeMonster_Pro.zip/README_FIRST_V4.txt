🦖 BRAKEMONSTER PRO — V4 integracioni kandidat

ORIGINAL ZIP: 047de803d35b20e4b4e67afc49ef47bd2198a5b475db803008185e68460db6b3
NOVI IZVOR: versionCode 212, versionName 1.0.177-pro.96

VAŽNO: OVAJ ZIP JE IZVORNI ANDROID PROJEKAT + CLOUDFLARE WORKERI, NIJE APK.
Nije mijenjan tvoj javni sajt niti Cloudflare nalog, nije objavljena naplata.

Pročitati COMMERCIAL_V4_RELEASE_CANDIDATE.md.
Prvo server/MIGRATION_V4.sql u TEST D1, pa TEST Worker i signed QA APK sa
BM_LICENSE_TEST_MODE=true. Tek poslije cijelog testiranja prelazak na produkciju.

Izrađeni testovi: 26 produkcioni backend + 24 testni backend, lokalno PASS.
Android build ovdje nije izveden: Gradle distro/Android SDK nisu dostupni.
Zato nijesmo provjerili originalni certifikat, instalaciju ni playback.

Promotivni spot (tekst) je u PROMO_SPOT_20s.txt. NE OBJAVLJIVATI prije QA.
