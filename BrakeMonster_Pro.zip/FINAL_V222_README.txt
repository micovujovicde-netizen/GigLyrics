BRAKEMONSTER PRO — FINAL v222 SOURCE PACKAGE
versionCode: 222
versionName: 1.0.185-pro.106 (1.0.185-pro.106-TEST with BM_LICENSE_TEST_MODE=true)
Original ZIP SHA-256: 3dc66a8583a75c2b14dce005d1a49b7884752c2fd3f275096e6102f4de5ece3e

This document replaces all intermediate v222 step reports.

NORMAL VIEW
One centered PLAYLISTS stone, width multiplier 2.0, height multiplier 1.0.
Original height (58dp), relief, borders, thickness and vertical spacing preserved.
Width capped at available space; baba pterodactyl remains centered above the stone.
QUEUE is a visible independent control below the volume rope on the right.
Normal LOCAL FILES remains available; no ADD TO QUEUE long-press workaround.

XL CHOOSER
Fixed top row: SEARCH PLAYLISTS | EXIT.
While ADD TO QUEUE is active: fixed WEB SEARCH then LOCAL SEARCH inputs below it.
Scrollable order: QUEUE -> LOCAL FILES -> WELCOME -> saved user/imported playlists.
Navigation rows never enter saved playlist order and have no edit/delete menus.
Original playlist storage, identities, menus and protections are preserved.

CONNECTED BEHAVIOR
QUEUE toggles the existing selection mode. Turning it off opens QUEUE without
autoplay. The same blink State drives queue labels, PLAYLISTS, LOCAL FILES and
search placeholders; no separate blink clocks are added.
WEB uses the existing guarded search panel and selection/save handler inside XL.
LOCAL uses the existing local/playlist search and its result dialog.
Search controls share their query state with the normal view.
Search results never introduce a separate audio/playback implementation.
The cloud SEARCH PLAYLISTS browser is the existing browser with its PRO guard;
closing it restores the XL chooser and retained scroll position.

LOCAL FILES shares exactly the normal header's navigation callback and preserves
selection mode/playback. Browser-owned XL state survives leaving the playlist
panel. PLAYLISTS or Android Back at the local root returns to the same XL chooser;
inside a folder, Back retains normal folder-up navigation.
EXIT clears XL mode and cancels unfinished MOVE; it does not save a partial order.
MOVE resolves destinations by stable playlist key so QUEUE/LOCAL FILES rows cannot
shift the target. Existing drag commit, edge scroll, popup menus and saved order
are retained. XL-owned result WebViews are released after disposal.

VALIDATION
Compared all original ZIP entries: only MainActivity.kt and app/build.gradle.kts
were changed, plus this final report. Audio/FX, persistence, imports/backups,
licensing, backend and workflows remain unchanged.
Reviewed callback wiring, shared state, Back/navigation paths, pinned MOVE targets,
shared blink references, width/height formulas and unchanged stone rendering.
All ZIP entries passed CRC verification; no intermediate step reports remain.

BUILD / DEVICE STATUS
This is the final consolidated SOURCE ZIP for the steps implemented in this
conversation, not a compiled or device-tested APK. Android compilation/lint was
blocked because the Gradle distribution download is unavailable in this environment.
Build and run device QA before treating this as a tested release.
Check A9+, A7 and phone: normal/XL/local/cloud/Back navigation; selection without
playback interruption; local-result dialog layering; MOVE around pinned rows and
edges; order after restart; PRO expiry; font scaling; keyboard; both orientations.
Very short keyboard viewports or extreme fonts still require real-device checks.

SOURCE FILE HASHES
1fbb6a565507a154ea5a2690c2f95a7920eaf2dd845e50d5c1d5e90802dfc542  app/src/main/java/com/teraphonia/breakmonster/MainActivity.kt
d93f36cc72b7146fb329ee4bdeb07c8cd2b908ff214e258126594053a0cd2f80  app/build.gradle.kts
