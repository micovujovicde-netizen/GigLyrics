# BrakeMonster PRO v223 — UI repair source package

Source: latest user-supplied `BrakeMonster_Pro.zip` (v222)
Source SHA-256: `33caebe371cafc513c135198215e3b9dd5ca346bceee9a662c4033e003df984c`
New versionCode: **223**
New versionName: **1.0.185-pro.107** (`-TEST` only when `BM_LICENSE_TEST_MODE=true`)
Application ID remains `com.teraphonia.breakmonster.pro`.

## Corrections

1. Main wide PLAYLISTS stone now opens the XL chooser DIRECTLY. Width multiplier 2.0, height multiplier 1.0, stone thickness unchanged. It does not toggle a selected playlist.
2. Removed obsolete XL stone from the normal horizontal playlist strip. QUEUE is now the first stone in that strip and is precisely 4/3 the ordinary 160dp tab width. When LOCAL FILES is open (and the playlist strip is absent), a QUEUE fallback stays reachable in its former place.
3. Updated normal drag-and-drop slot offsets for the larger QUEUE stone. User playlist order/ids/storage and pinned-WELCOME protections are unchanged.
4. XL fixed search controls form exactly one second ROW when ADD TO QUEUE is active. Tablets display two side-by-side search inputs. Narrow phones display WEB SEARCH | LOCAL SEARCH stone buttons that open accessible query dialogs, preserving shared queries and handlers.
5. XL scrollable QUEUE row now has separate OPEN QUEUE and TOGGLE ADD TO QUEUE zones (128dp toggle, >= 48dp height), avoiding accidental navigation when toggling.
6. Queue charcoal, Local Files blue-slate, Welcome warm sandstone: distinct carved stone shades; same original stone shape/relief.
7. Phones use native device density for the main browser, controls, playback/footer, and top left/right actions, rather than scaling every touch target to 45% of its designed size. Stage art retains the virtual original 800dp layout. Main PLAYLISTS retains original 58dp height. On short phones (<680dp display height), full-width search/voice input is available via compact search dialogs to preserve track space. The phone pterodactyl is proportionately sized to avoid covering those inputs.

## Validation run

- Source static acceptance checks: `python verification/test_v223_ui_source.py` => 17/17 PASS.
- `kotlinc MainActivity.kt` syntax pass: no `expecting`/unexpected-token diagnostics. Full semantic compile is impossible without the Android and Compose dependencies (thousands of expected unresolved Android imports).
- Attempted `./gradlew --offline :app:compileDebugKotlin`: BLOCKED before compilation because Gradle 8.9 distribution is missing and `services.gradle.org` could not be reached. **No compiled APK is included; do not call this a device-tested build.**
- The output ZIP must pass `unzip -t`, and hashes are provided separately.

## Must complete before production

- Build and lint via existing GitHub Actions, with `BM_LICENSE_TEST_MODE=false`.
- Verify release signing fingerprint matches previous installed PRO release; debug build is not an installable production update.
- On **320, 360, 390dp** width and portrait/landscape tablets, inspect clipping and 48dp tap areas, status/navigation insets, pterodactyl overlap, and native/virtual density interactions.
- Verify NORMAL->XL->LOCAL->Back->XL, OPEN QUEUE vs TOGGLE ADD TO QUEUE, EXIT, SEARCH PLAYLISTS and returning from cloud browser, Web/Local search results overlays, multiple consecutive entries, ADD TO QUEUE blink/saved state, user playlist MOVE/drop/edge scroll/storage after restart, continuous audio, FREE/PRO locks.
- No Cloudflare/D1/Creem/website files altered.

## Important

This ZIP is a **candidate source repair**, not a confirmed Android release. The original app's scene graph is complex; final touch geometry requires device QA. Report any build error from Actions rather than treating static tests as compilation.
