data class Entry(val uri: String, val name: String)
class Policy(var files: List<Entry>, var order: List<Int>, var repeat: Boolean, var orderPosition: Int, val unplayableStandbyUris: MutableSet<String>) {
    private fun nextPlayableOrderPosition(after: Int): Int {
        if (order.isEmpty()) return -1
        for (offset in 1..order.size) {
            val candidate = after + offset
            if (!repeat && candidate >= order.size) return -1
            val position = ((candidate % order.size) + order.size) % order.size
            val entry = order.getOrNull(position)?.let { files.getOrNull(it) } ?: continue
            if (entry.uri !in unplayableStandbyUris) return position
        }
        return -1
    }
    fun next() = nextPlayableOrderPosition(orderPosition)
}
fun main() {
    val a = listOf(Entry("a", "A"), Entry("b", "B"), Entry("c", "C"))
    fun checkCase(condition: Boolean, desc: String) { check(condition) { desc }; println("PASS: $desc") }
    val seq = Policy(a, listOf(0,1,2), false, 0, mutableSetOf())
    checkCase(seq.next() == 1, "normal NEXT")
    seq.unplayableStandbyUris.add("b")
    checkCase(seq.next() == 2, "skip failed B")
    seq.unplayableStandbyUris.add("c")
    checkCase(seq.next() == -1, "no playable next")
    val loop = Policy(a, listOf(0,1,2), true, 2, mutableSetOf())
    checkCase(loop.next() == 0, "repeat wraps")
    loop.unplayableStandbyUris.add("a")
    checkCase(loop.next() == 1, "repeat wraps past failed track")
    loop.unplayableStandbyUris.add("b")
    loop.unplayableStandbyUris.add("c")
    checkCase(loop.next() == -1, "all failed terminates")
    val empty = Policy(emptyList(), emptyList(), true, -1, mutableSetOf())
    checkCase(empty.next() == -1, "empty queue")
}
