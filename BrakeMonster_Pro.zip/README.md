# BrakeMonster PRO — audio development build

Package ID: `com.teraphonia.breakmonster.pro` (independent of FREE)
Version: `1.0.141-pro.40` / 156 (latest source; see TURBO_BUFFER_REPORT.txt)

## Audio playback

- Local audio plays through a foreground Android `BreakPlaybackService`.
- `.bmq` records use NewPipeExtractor to resolve *audio-only* streaming URLs
  on a background worker thread. An Android `MediaPlayer` in the foreground
  service plays the stream without any embedded YouTube video or PiP window.
- Android audio focus pauses for phone calls; partial wake lock and media
  notification permit playback with the display off, while using another app,
  or during file imports. Removing the app from Recent Apps stops the service.
- Stream access is best-effort and depends on the provider; audio-only links
  may be blocked, removed, expired or temporarily unavailable. Streaming and
  locked-screen behavior MUST be tested on an Android device.

## BMQ personal playlist data

- When importing a ZIP of `.yt` links, or saving a WEB SEARCH result with
  SAVE TO QUEUE, PRO writes `.bmq` files to the persistent QUEUE. Selecting a
  result only stages its URL and metadata; it does not change playback.
- Existing private `.yt` links get `.bmq` companion files during background
  migration. Old `.yt` files are *retained* if legacy playlist references
  still rely on them. The original files in external folders are not modified.
- BMQ contains only an encrypted video identifier, not audio data. This is
  not absolute DRM; see `THIRD_PARTY_NOTICES.md`.

The former MONSTER/factory playlists and bundled archive have been removed.
QUEUE, the WELCOME SONG and personal playlists remain available.

## Interface

- `BUY A BIG MONSTER` uses the new cigar T-Rex graphic. Payment link is not
  configured yet.
- The Android launcher icon uses the same T-Rex head.
- WEB SEARCH keeps its existing YouTube results page. Selecting a result leaves
  the active deck and service running. SAVE TO QUEUE writes the selected link
  and metadata to the permanent queue.
- MIXER uses two reusable MediaPlayer decks with automatic crossfade (default
  2 seconds, adjustable 1–12 seconds) and manual fader control. The GIF overlay
  appears only while an outgoing playlist track waits for a playlist-change
  target; it hides when the incoming deck begins playback. Stone columns report
  buffering progress; they do not show sample-derived amplitude waveforms.
- The bottom playback progress display is non-interactive. Silence detection
  and exact two-second playable-buffer detection are not implemented.

## Distribution & build

- PRO workflow is included at `.github/workflows/brakemonster_pro.yml`.
  Copy it into the repository `.github/workflows/` separately: a workflow inside ZIP alone does not trigger GitHub Actions.
- The NewPipeExtractor library is GPL-3.0-or-later. If distributing a
  commercial binary, comply with GPLv3 including providing corresponding
  covered source. See `THIRD_PARTY_NOTICES.md`.
- Work outside Google Play does not waive third-party platform terms.

## PRO audio diagnostic fix (build 124)

- Delays creation of Android MediaPlayer until the BMQ audio URL is resolved.
- Queries position/duration only after onPrepared, preventing an IDLE MediaPlayer state error (-38).
- BLACK BOX records BMQ resolve, datasource setup, prepareAsync, buffering, prepared, and playback states.
- Failed songs stop without skipping the entire playlist; NEXT remains available.
- This is a source-code fix, not a verified APK or a dual-deck audio mixing implementation.

## PRO compile repair (build 125)

- Corrected `MediaPlayer.setDataSource` call for BMQ network URLs: uses
  Android's `(Context, Uri, Map<String, String>)` overload rather than
  the invalid `(String, Map<String, String>)` overload.
- No changes to audio navigation, MIXER controls, playlists or images.
- ZIP validation is not an APK build or streaming test.

## Build 126: workflow separation

- Removed FREE workflow from PRO source ZIP.
- Added PRO-only workflow, requiring the PRO ZIP and PRO application ID.
- Audio service from build 125 retained; no untested audio rewrite.
- Not compiled or playback-tested here.

## Build 132: search, manual mix, and transition feedback

- Search selection stages the link for saving and does not start/restart audio.
- Manual fader polling no longer overwrites the user's gesture. The service
  verifies standby player identity and prepared state, resumes a pending manual
  start when B becomes ready, and logs failure reasons.
- Added the supplied transparent 20-frame MIXING GIF for playlist transitions.
- See `IMPLEMENTATION_REPORT.txt` for limitations and validation. No Android
  compile or device playback test was completed in this environment.
