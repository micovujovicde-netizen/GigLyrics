# BrakeMonster PRO — audio development build

Package ID: `com.teraphonia.breakmonster.pro` (independent of FREE)
Version: `1.0.115-pro.3` / 119

## Audio playback

- Local audio plays through a foreground Android `BreakPlaybackService`.
- `.bmq` records use NewPipeExtractor to resolve *audio-only* streaming URLs
  on a background worker thread. An Android `MediaPlayer` in the foreground
  service plays the stream without any embedded YouTube video or PiP window.
- Android audio focus pauses for phone calls; partial wake lock and media
  notification permit playback with the display off, while using another app,
  or during file imports. Removing the app from Recent Apps stops the service.
- Stream access is best-effort and depends on the provider; audio-only links
  may be blocked, removed, expired or temporarily unavailable. Streaming and
  locked-screen behavior MUST be tested on an Android device.

## BMQ playlist data

- `app/src/main/assets/factory_collection.zip` contains 1,536 encrypted
  `.bmq` reference files in 51 existing genre folders (no `.yt` entries).
- Bundled `BMQF:` references are rewrapped as Android Keystore-encrypted
  `BMQ1:` files when the MONSTER library first loads.
- When importing a ZIP of `.yt` links, or saving a YouTube search result,
  PRO writes `.bmq` files. Imported `.bmq` files are also supported.
- Existing private `.yt` links get `.bmq` companion files during background
  migration. Old `.yt` files are *retained* if legacy playlist references
  still rely on them. The original files in external folders are not modified.
- BMQ contains only an encrypted video identifier, not audio data. This is
  not absolute DRM; see `THIRD_PARTY_NOTICES.md`.

## Interface

- `BUY A BIG MONSTER` uses the new cigar T-Rex graphic. Payment link is not
  configured yet.
- The Android launcher icon uses the same T-Rex head.
- MIXER popup, playlist UI, searches and local playback are preserved.
  Crossfade, true AUTO MIX and audio normalization are **not implemented** yet;
  the mixer popup still stores settings only.

## Distribution & build

- Separate PRO `.yml` GitHub Actions workflow is needed to build
  `BrakeMonster_Pro.zip`, not the FREE zip.
- The NewPipeExtractor library is GPL-3.0-or-later. If distributing a
  commercial binary, comply with GPLv3 including providing corresponding
  covered source. See `THIRD_PARTY_NOTICES.md`.
- Work outside Google Play does not waive third-party platform terms.
