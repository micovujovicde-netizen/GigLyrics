const fs=require('fs'),vm=require('vm'),assert=require('assert');
const script=fs.readFileSync(require('path').join(__dirname,'../distribution/public-site/release.js'),'utf8');
(async()=>{
 const cases=[
  {name:'unavailable release',body:{applicationId:'com.teraphonia.breakmonster.pro',candidateVersionCode:211,candidateVersionName:'1.0.176-pro.95',available:false}},
  {name:'public flag and malicious URL cannot unlock',body:{applicationId:'com.teraphonia.breakmonster.pro',candidateVersionCode:211,candidateVersionName:'1.0.176-pro.95',available:true,buildVerified:true,apkUrl:'https://example.com/paid.apk'}},
  {name:'invalid metadata',body:{applicationId:'wrong',candidateVersionCode:211,candidateVersionName:'<script>alert(1)</script>'}},
  {name:'network failure',fail:true}
 ];
 for(const c of cases){
  const els={};for(const id of ['release-status','release-details','download'])els[id]={textContent:'',disabled:false,href:'old-public-url',removeAttribute(k){delete this[k]}};
  await vm.runInNewContext(script,{document:{getElementById:id=>els[id]},fetch:async()=>{if(c.fail)throw Error('offline');return{ok:true,json:async()=>c.body}},AbortSignal:{timeout:()=>({})},Number});
  assert.strictEqual(els.download.disabled,true);assert.ok(!els.download.href);assert.ok(!Object.values(els).some(e=>e.textContent.includes('example.com')));
  console.log('PASS: '+c.name);
 }
})().catch(e=>{console.error(e);process.exitCode=1});
