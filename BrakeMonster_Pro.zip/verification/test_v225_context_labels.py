#!/usr/bin/env python3
"""Static checks for XL context labels; NOT proof of runtime Compose behavior."""
from pathlib import Path
import re, sys
root=Path(sys.argv[1])
s=(root/'app/src/main/java/com/teraphonia/breakmonster/MainActivity.kt').read_text()
g=(root/'app/build.gradle.kts').read_text()
def has(pattern): return bool(re.search(pattern,s,re.S))
checks={
 'version225 + applicationId': 'versionCode = 225' in g and '1.0.185-pro.109' in g and 'com.teraphonia.breakmonster.pro' in g,
 'width-only PLAYLISTS': 'MAIN_PLAYLISTS_WIDTH_MULTIPLIER = 2f' in s and 'MAIN_PLAYLISTS_HEIGHT_MULTIPLIER = 1f' in s,
 'XL entry still main PLAYLISTS': has(r'PlaylistStoneButton\(onClick = \{\s*xlMode\.value = true\s*xlChooserVisible\.value = true'),
 'second XL row only in add-mode': 'if (xlSearchControls.queueSelectionMode) {' in s,
 'XL web locked labelled PRO': '!xlSearchControls.webEnabled -> "WEB SEARCH · PRO"' in s,
 'XL web result => new search': 'xlWebSearchUrl != null -> "NEW WEB SEARCH"' in s,
 'XL local busy => searching': 'xlSearchControls.localSearchBusy -> "SEARCHING LOCAL…"' in s,
 'XL local result => new search': 'xlSearchControls.localResultsOpen -> "NEW LOCAL SEARCH"' in s,
 'XL toggling ON => DONE ADDING': 'Text(if (xlSearchControls.queueSelectionMode) "DONE ADDING"' in s,
 'same toggle handler': 'PlaylistStoneButton(onClick = { onQueueTap() }' in s,
 'locked WEB invokes existing PRO gate': has(r'if \(!xlSearchControls.webEnabled\) xlSearchControls.onAllowWebSearch\(\)'),
 'unchanged first fixed row': 'contentDescription = "SEARCH PLAYLISTS"' in s and 'contentDescription = "EXIT XL"' in s,
 'normal LOCAL FILES header': 'HeaderStoneText("LOCAL FILES", 14.sp, 1)' in s,
 'XL source-state propagation': has(r'localSearchBusy = globalSearchBusy,\s*localResultsOpen = showGlobalSearchResults') and has(r'localSearchBusy = localSearchBusy,\s*localResultsOpen = localResultsOpen'),
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL'),name)
assert all(checks.values()),'static label test failed'
print('STATIC PASS',sum(checks.values()),'/',len(checks),'(NOT Android build/device test)')
