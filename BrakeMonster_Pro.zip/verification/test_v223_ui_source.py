#!/usr/bin/env python3
"""Static acceptance checks for v223 UI repair. Not an Android device test."""
from pathlib import Path
import re

root=Path(__file__).resolve().parents[1]
s=(root/'app/src/main/java/com/teraphonia/breakmonster/MainActivity.kt').read_text()
g=(root/'app/build.gradle.kts').read_text()
checks={
    'v223 build number preserved app ID': 'versionCode = 223' in g and '1.0.185-pro.107' in g and 'com.teraphonia.breakmonster.pro' in g,
    'width 2x but height unchanged': 'MAIN_PLAYLISTS_WIDTH_MULTIPLIER = 2f' in s and 'MAIN_PLAYLISTS_HEIGHT_MULTIPLIER = 1f' in s,
    'main PLAYLISTS opens XL directly': bool(re.search(r'PlaylistStoneButton\(onClick = \{\s*xlMode\.value = true\s*xlChooserVisible\.value = true',s)),
    'no legacy XL stone in normal row': 'Text("XL", color = Color.White' not in s,
    'QUEUE first in normal stone row': 'First NORMAL stone is QUEUE' in s and s.index('First NORMAL stone is QUEUE') < s.index('baseOrder.forEachIndexed'),
    'normal QUEUE 4/3 width': 'queueNavigationWidthDp = 160f * 4f / 3f' in s,
    'normal MOVE accounts for QUEUE width': 'dragCenterContentX - playlistStartPx - stoneWidthPx / 2f' in s and 'playlistStartPx + baseIndex * slotPitchPx' in s,
    'XL header fixed two buttons': '"SEARCH PLAYLISTS"' in s and '"EXIT XL"' in s,
    'XL second row conditional': bool(re.search(r'if \(xlSearchControls\.queueSelectionMode\) \{\s*Spacer\(Modifier\.height\(8\.dp\)\)',s)),
    'XL second row side by side': 'Row(Modifier.fillMaxWidth().height(60.dp)' in s and 'xlPhoneSearchDialog = "web"' in s and 'xlPhoneSearchDialog = "local"' in s,
    'XL separate QUEUE navigation/toggle': 'contentDescription = "OPEN QUEUE"' in s and 'contentDescription = "TOGGLE ADD TO QUEUE"' in s,
    'XL navigation order': s.index('item(key = store.playbackContext(store.queueIndex))') < s.index('item(key = "xl-navigation:local-files")') < s.index('items(xlOrder, key'),
    'unique QUEUE/local/welcome stone tones': 'queueTone = true' in s and 'localTone = true' in s and 'welcomeTone = index == store.welcomePlaylistIndex()' in s,
    'single blink alpha shared': 'xlSearchControls.blinkAlpha.value' in s and 'queueBlinkAlpha.value' in s,
    'phone native-density browsing and playback': s.count('if (phonePortraitLayout) nativePhoneDensity else LocalDensity.current') >= 4,
    'phone main button 58dp': '.height((58f * rowHeightFactor * MAIN_PLAYLISTS_HEIGHT_MULTIPLIER).dp)' in s,
    'no backend code change in validation': (root/'server/brakemonster-license-v4.js').exists(),
}
for name,pass_ in checks.items():
 print(('PASS' if pass_ else 'FAIL'), name)
assert all(checks.values()),'Static UI source test failed'
print(f'STATIC PASS {len(checks)}/{len(checks)} (not a build or screenshot validation)')
