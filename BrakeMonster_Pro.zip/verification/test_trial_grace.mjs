import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {join} from 'node:path';
const src=join(import.meta.dirname, '..', 'server', 'worker-test-v220.js');
const simulated=readFileSync(src,'utf8').replaceAll('const now = Date.now();','const now = globalThis.__bmTestNow ?? Date.now();');
const worker=(await import('data:text/javascript;base64,' + Buffer.from(simulated).toString('base64'))).default;
class Db {
  constructor() {this.trials=new Map(); this.rows=[];}
  prepare(sql) {
    const db=this;
    return {bind(...args){
      return {
        all:async()=> {if(sql.includes('FROM licenses l'))return {results:db.rows}; throw Error(sql)},
        first:async()=> {if(sql.includes('SELECT first_seen_ms'))return {first_seen_ms:db.trials.get(args[0])};throw Error(sql)},
        run:async()=> {if(sql.includes('INSERT OR IGNORE INTO bm_trial_devices')){if(!db.trials.has(args[0]))db.trials.set(args[0],args[1]);return {success:true};}throw Error(sql)}
      };
    }};
  }
}
const env={DB:new Db()};
const start=Date.parse('2026-11-02T11:00:00Z');
const day=86400000;
const f='b'.repeat(64),token='a'.repeat(64);
async function license(t,hash=f,auth=token) {
 globalThis.__bmTestNow=t;
 const headers={Authorization:'Bearer '+auth};
 if(hash!==null) headers['X-BM-Trial-Device']=hash;
 const response=await worker.fetch(new Request('https://example.workers.dev/v1/license',{headers}),env);
 const json=await response.json();
 assert.equal(response.status,200,JSON.stringify(json));
 return json;
}
let r=await license(start); assert.equal(r.entitlementType,'trial');assert.equal(r.validUntil,start+7*day);console.log('PASS trial starts on first server contact');
r=await license(start+day,f,'c'.repeat(64));assert.equal(r.validUntil,start+7*day);console.log('PASS reinstall with different install token does not reset trial');
r=await license(start+7*day);assert.equal(r.active,false);console.log('PASS trial expires at 7d');
env.DB.rows=[{status:'active',expires_at:new Date(start+10*day).toISOString(),product_id:'prod_38aihCnx3ramvwkUxxJC5v'}];
r=await license(start+9*day);assert.equal(r.entitlementType,'paid');console.log('PASS valid paid entitlement priority');
r=await license(start+11*day);assert.equal(r.entitlementType,'grace');assert.equal(r.validUntil,start+13*day);console.log('PASS grace for unpaid renewal');
r=await license(start+13*day);assert.equal(r.entitlementType,'free');console.log('PASS grace ends after 3d');
env.DB.rows[0].status='canceled';r=await license(start+11*day);assert.equal(r.active,false);console.log('PASS canceled subscription does not create payment-failure grace');
env.DB.rows=[{status:'lifetime',expires_at:null,product_id:'prod_1RKZxe64ISMSTIEJ5umurL'}];r=await license(start+900*day);assert.equal(r.entitlementType,'lifetime');console.log('PASS lifetime has no expiry');
// A paying user must register their first contact immediately, not after renewal fails.
const paidFirstFingerprint='e'.repeat(64);
env.DB.rows=[{status:'active',expires_at:new Date(start+100*day).toISOString(),product_id:'prod_38aihCnx3ramvwkUxxJC5v'}];
r=await license(start,paidFirstFingerprint);assert.equal(r.entitlementType,'paid');
assert.equal(env.DB.trials.get(paidFirstFingerprint),start);
env.DB.rows=[];
r=await license(start+101*day,paidFirstFingerprint);assert.equal(r.active,false);
console.log('PASS paid accounts do not receive late free trials');
r=await license(start+9*day,null);assert.equal(r.active,false);console.log('PASS no fingerprint never grants untracked trial');
console.log('TOTAL: 10 PASS');
