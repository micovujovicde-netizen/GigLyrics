# 🦖 BrakeMonster PRO — V4 integracioni kandidat

**Status: IZVORNI KANDIDAT — NIJE IZGRAĐEN APK, NIJE JAVNO OBJAVLJENO.**

Izvor: isključivo korisnički `BrakeMonster_Pro.zip`, identičan `BrakeMonster_Pro-1.zip`.

- Originalni SHA-256 oba ZIP-a: `047de803d35b20e4b4e67afc49ef47bd2198a5b475db803008185e68460db6b3`
- Original: versionCode 211, versionName `1.0.176-pro.95`.
- Novi izvor: versionCode **212**, versionName **`1.0.177-pro.96`** (produkcija) ili **`1.0.177-pro.96-TEST`** (odvojeni QA build).
- Package: `com.teraphonia.breakmonster.pro`, bez zamjene originalnog potpisa.
- Izmijenjeni Android fajlovi: `app/build.gradle.kts`, `CommercialRelease.kt`, `MainActivity.kt`.
- Audio, A/B, QUEUE, FX, playlists, CF, backup i postojeće UI kontrole nijesu mijenjani.

## Šta je stvarno urađeno

1. Android aplikacija sada koristi licencni Worker (`/v1/license`) umjesto još nepostojećeg `api.teraphonia.com/v1`. Poslije povratka iz kupovine provjerava licencu odmah. Postojeći offline cache ≤72 h ostaje.
2. V4 server ima POST `/v1/checkout`, GET `/v1/license`, GET `/v1/health`, POST `/v1/portal`, POST `/webhook`. Creem checkout se kreira samo na serveru; API ključ nikad ne ulazi u aplikaciju ili sajt. Plaćene licence se povezuju s instalacijom preko SHA-256 nasumičnog lokalnog tokena u Creem metadata.
3. V4 test Worker je odvojen: testni proizvod, testni Creem API, testni webhook i testna baza. Testni build Androida koristi samo test Worker i plaća se samo testnim metodom.
4. Na web kopiji pripremljen je izbor Monthly / Yearly / Lifetime, ali `distribution/public-site/commercial-config.json` i dalje ima **`billingEnabled: false`**. Javni sajt nije mijenjan.
5. Cloudflare produkcioni Worker, produkciona D1 i javni teraphonia.com nijesu mijenjani u ovom isporučenom paketu.

## Lokalni testovi

- `node --disable-warning=ExperimentalWarning server/test-v4.mjs`: **26 prolaznih provjera**.
- `node --disable-warning=ExperimentalWarning server/test-v4-staging.mjs`: **24 prolazne provjere**.
- `node --check` oba Workera i `purchase.js`: prolazi.
- SQL migracija `server/MIGRATION_V4.sql` uspješno izvršena u odvojenoj lokalnoj SQLite bazi.
- Pokušaj `./gradlew --offline :app:assembleRelease` NIJE prošao: `UnknownHostException: services.gradle.org` (nedostaje distribucija Gradle i Android SDK). **Nijedan APK nije izgrađen niti potpisan; nema fizičkog Android testa.**

## Bezbijedan redosljed (obavezno prije prodaje)

1. Napravi rollback tačku i kopiju sadašnjeg TEST Workera. U TEST D1 bazi `brakemonster-licenses-test` izvrši `server/MIGRATION_V4.sql`.
2. U *isključivo* `brakemonster-license-test` Worker postavi `server/brakemonster-license-v4-test.js`. Sačuvaj `DB` binding na TEST bazu; `CREEM_WEBHOOK_SECRET` testni ključ (kao **Secret**, po potrebi rotirati jer je bio prikazan), dodaj `CREEM_API_KEY` **TEST** kao Secret, `BILLING_ENABLED` kao običnu varijablu `true`. Nemoj nijedan ključ stavljati u ZIP.
3. Na mašini sa Android SDK 35, JDK 17, Gradle i originalnim ključem, napravi QA build s `BM_LICENSE_TEST_MODE=true ./gradlew :app:assembleRelease`. Sačuvaj cert fingerprint i potvrdi da se može instalirati preko stare aplikacije bez deinstalacije.
4. Na A9+ i telefonu uradi stvarnu probnu kupovinu iz **BUY PRO** dugmeta. Provjeri `GET /v1/license` u appu i `BM PRO` status, pa test obnove/otkazivanja, dvostruke isporuke i ponovnog pokretanja; playback nikad ne zaustavljati tokom provjere. Ovo nije ranije izvršeno.
5. Tek poslije uspješnog QA: u **produkcioni** `brakemonster-licenses` izvrši istu migraciju; napravi rollback tačku; postavi **produkcioni** `server/brakemonster-license-v4.js` samo na `brakemonster-license`; sačuvaj produkcione `DB` i `CREEM_WEBHOOK_SECRET` bindings. Produkcioni `CREEM_API_KEY` dodaj kao Secret. `BILLING_ENABLED=false` dok aktivacija i checkout ne prođu QA.
6. Produkcioni APK izgradi bez `BM_LICENSE_TEST_MODE` (ili `false`) koristeći ORIGINALNI signing key i provjeri APK certifikat. Provjeri BUY PRO, ažuriranja i lokalni audio na uređajima.
7. Po konačnom odobrenju postavi izdvojeno `distribution/public-site/`, promijeni public config `billingEnabled=true` i produkcioni Worker `BILLING_ENABLED=true`; javni APK dostavljaj *samo kroz autorizovani download*, ne kao nezaštićeni fajl na javnom sajtu. **Nijedna od ovih objava nije izvršena.**

## Važne preostale granice

- Nema povratka licence na drugi telefon/tablet nakon gubitka lokalnog tokena; prije prodaje obavezno isplanirati oporavak kupovine. Za sada se pravo veže samo za instalaciju s koje je kupovina pokrenuta.
- PRO oznaka/validacija su povezane, ali nije dodat novi univerzalni paywall oko svake postojeće DJ funkcije. Besplatna i PRO distribucija i zaštita premium funkcija zahtijevaju dodatno odobrenje.
- `BILLING_ENABLED=false` je namjerna zaštita: nema slučajne javne kupovine dok nije gotova Android QA.
- Nikad ne upisivati `CREEM_API_KEY`, `whsec_...`, privatne potpise ili originalni keystore u kod, ZIP ili chat.
- Testni i produkcioni `product_id` su odvojeni. Produkcioni proizvodi: Monthly / Yearly / Lifetime. Test ima samo Monthly.
- Otkazivanje čuva pristup do plaćenog datuma; Lifetime ne ističe. Nevalidan potpis ili dupli događaj ne daju novu licencu.

## Marketinški status

Promotivni tekst je u `PROMO_SPOT_20s.txt`. **Ne objavljuj** dok Android i produkcioni proces kupovine i isporuke APK-a ne prođu QA.
