package com.teraphonia.breakmonster;
public class PlaylistTabFollowTest {
    static int checks;
    static void check(int expected, float start, float width, float viewport, int max) {
        int actual = PlaylistTabFollow.offset(start, width, viewport, max);
        checks++;
        if (actual != expected) throw new AssertionError("Center/bounds check #" + checks + ": " + actual);
    }
    public static void main(String[] args) {
        check(0, 0, 251.09334f, 720, 1600); // active QUEUE stays left on tablet
        check(0, 0, 251.09334f, 340, 1600); // active QUEUE stays left on phone
        check(0, 50, 100, 500, 1000); // early button cannot reach center
        check(480, 600, 160, 400, 1200); // exact interior centering
        check(700, 1000, 160, 400, 700); // last item, no trailing blank padding
        check(0, 600, 160, 400, 0); // short, non-scrollable row
        check(0, 600, 160, 0, 1200); // not laid out yet
        check(0, 600, 160, 400, -1); // no valid scroll range
        check(600, 1000, 200, 1000, 2000); // wide viewport
        check(116, 200, 160, 328, 1600); // phone viewport
        check(0, 100, 160, 360, 1600); // left boundary exactly
        check(1, 101, 160, 360, 1600); // one pixel inside boundary
        if (PlaylistTabFollow.offsetFromRoot(200, 410, 160, 10, 400, 1200) != 480) throw new AssertionError("Root center");
        if (PlaylistTabFollow.offsetFromRoot(200, -190, 194, 10, 400, 1200) != 0) throw new AssertionError("QUEUE root clamp");
        if (PlaylistTabFollow.offsetFromRoot(650, 360, 160, 10, 400, 700) != 700) throw new AssertionError("Last root clamp");
        if (PlaylistTabFollow.offsetFromRoot(480, 130, 160, 10, 400, 1200) != 480) throw new AssertionError("Already centered");
        checks += 4;
        System.out.println("PASS: " + checks + " playback-tab center/bounds checks");
    }
}
