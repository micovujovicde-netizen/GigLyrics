package com.teraphonia.breakmonster;
public class UpdateRetryGateTest {
    static int checks;
    static void check(boolean expected, int retries, boolean terminal, boolean installed,
                      boolean idle, boolean active, long waited) {
        boolean actual = UpdateRetryGate.mayRetry(retries, terminal, installed, idle, active, waited);
        checks++;
        if (actual != expected) throw new AssertionError("Unexpected retry decision #" + checks);
    }
    public static void main(String[] args) {
        check(true, 0, false, false, true, false, 3000); // the reported silent close
        check(true, 0, false, false, true, false, 12000);
        check(false, 0, false, false, true, false, 2999); // callback grace
        check(false, 1, false, false, true, false, 3000); // no third attempt
        check(false, 2, false, false, true, false, 3000);
        check(false, 0, true, false, true, false, 3000); // cancel/error result
        check(false, 0, true, true, true, false, 3000); // successful result
        check(false, 0, false, true, true, false, 3000); // actual version already advanced
        check(false, 0, false, false, false, false, 3000); // background or playback
        check(false, 0, false, false, true, true, 3000); // Android still installing
        check(false, 0, false, false, true, false, -1); // staging grace
        if (!UpdateRetryGate.retryableStatus(1, 0)) throw new AssertionError("Generic first failure must retry");
        if (UpdateRetryGate.retryableStatus(1, 1)) throw new AssertionError("No third attempt after failure");
        for (int status : new int[]{0, 2, 3, 4, 5, 6, 7, 8}) {
            if (UpdateRetryGate.retryableStatus(status, 0)) throw new AssertionError("Terminal status retried: " + status);
        }
        checks += 10;
        System.out.println("PASS: " + checks + " installer retry decisions");
    }
}
