package com.teraphonia.breakmonster

import android.app.Application
import android.content.ContentUris
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

internal data class BreakItem(
    val file: DocumentFile,
    val name: String,
    val isYoutube: Boolean,
    val fileName: String = file.uri.lastPathSegment.orEmpty().substringAfterLast('/')
) {
    val extension: String get() = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
    val playbackName: String get() = fileName.takeIf { extension in localPlayableExtensions || extension in referenceExtensions } ?: name
}

internal data class LocalFolder(val uri: Uri, val name: String)
private val referenceExtensions = setOf("yt", "bmq")

internal val localPlayableExtensions = setOf(
    "mp3", "wav", "wave", "m4a", "aac", "flac", "ogg", "opus", "amr",
    "mp4", "m4v", "mov", "3gp", "3g2", "mkv", "webm", "avi", "ts", "m2ts", "mpeg", "mpg"
)
internal val importSidecarExtensions = setOf("txt", "lrc", "srt", "cdg", "lyr", "lyr3", "mid", "midi", "kar")

private val localAudioServiceExtensions = setOf("mp3", "wav", "wave", "m4a", "aac", "flac", "ogg", "opus", "amr")
internal fun BreakItem.isAudioServiceTrack(): Boolean =
    if (isYoutube) extension in referenceExtensions
    else extension in localAudioServiceExtensions ||
        (extension !in localPlayableExtensions && file.uri.scheme == "content")

internal class BreakMonsterModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("breakmonster", 0)

    var rootUri by mutableStateOf(prefs.getString("root", null))
        private set

    private var manualRootUris:List<String> = runCatching {
        val raw=prefs.getString("manual_roots",null)
        val saved=if(raw==null) emptyList() else { val a=JSONArray(raw);(0 until a.length()).map{a.getString(it)} }
        (saved + listOfNotNull(rootUri)).distinct()
    }.getOrDefault(listOfNotNull(rootUri))

    var path by mutableStateOf(loadPath())
        private set

    var folders by mutableStateOf<List<LocalFolder>>(emptyList())
        private set
    var tracks by mutableStateOf<List<BreakItem>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    var mediaScanComplete by mutableStateOf(prefs.getBoolean("first_user_scan_complete_v25",false))
        private set
    var mediaScanInProgress by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    var random by mutableStateOf(prefs.getBoolean("random", false))
        private set
    var repeat by mutableStateOf(prefs.getBoolean("repeat", false))
        private set

    var localTrackUri by mutableStateOf<String?>(null)
        private set
    /** Source file owning the active row, including saved YouTube playlist entries. */
    var activePlaybackItemUri by mutableStateOf<String?>(null)
        private set
    /** Playlist owner for the current playback queue; prevents duplicate songs in other lists highlighting. */
    var activePlaybackPlaylistContext by mutableStateOf<String?>(null)
        private set
    private var playlistTransitionTargetUri by mutableStateOf<String?>(null)
    private var observedIdleTrackLoad = false
    var localTrackName by mutableStateOf<String?>(null)
        private set
    var localPreparing by mutableStateOf(false)
        private set
    var localPlaying by mutableStateOf(false)
        private set
    var localPosition by mutableIntStateOf(0)
        private set
    var localDuration by mutableIntStateOf(0)
        private set

    var youtubeVideoId by mutableStateOf<String?>(null)
        private set
    var youtubeUrl by mutableStateOf<String?>(null)
        private set
    var youtubeTitle by mutableStateOf<String?>(null)
        private set
    var youtubeSession by mutableIntStateOf(0)
        private set
    var youtubePlaying by mutableStateOf(false)
        private set
    var youtubeCurrentSecond by mutableStateOf(0f)
        private set
    var youtubeDurationSecond by mutableStateOf(0f)
        private set
    var youtubeSaved by mutableStateOf(false)
        private set
    var youtubeCanSave by mutableStateOf(false)
        private set

    private var playbackQueue: List<BreakItem> = emptyList()
    private var playbackQueueIndex = -1
    private val autoFailedYoutubeUris = mutableSetOf<String>()

    var refreshSerial by mutableIntStateOf(0)
        private set

    var message by mutableStateOf<String?>(null)
        private set

    private val installedMediaDir = File(app.filesDir, "installed_media")
    private val brakeMonsterDir = File(app.filesDir, "brakemonster_media")
    private val ytDownloadsDir = File(brakeMonsterDir, "YT DOWNLOADS")
    private var ownedMediaItems by mutableStateOf<List<BreakItem>>(emptyList())
    val brakeMonsterItems: List<BreakItem> get() = ownedMediaItems.filterNot { it.isYoutube }
    val ytDownloadItems: List<BreakItem> get() = ownedMediaItems.filter { it.isYoutube }
    // Compose-facing library must be memory-only. Never rebuild DocumentFiles / parse JSON here.
    private var manualLibraryItems by mutableStateOf<List<BreakItem>>(emptyList())
    // Declared before init because init restores this cache explicitly.
    private var mediaStoreItems: List<BreakItem> = emptyList()
    private var allMusicCache by mutableStateOf<List<BreakItem>>(emptyList())
    val allMusicItems: List<BreakItem> get() = allMusicCache
    /** Every indexed local item, including app-owned imports and their .yt files. */
    val searchableLocalItems: List<BreakItem>
        get() = dedupeMedia(allMusicCache + ownedMediaItems)

    var activeLocalSaveKey: String = "order:all_music"
        private set
    private var activeLocalItems: List<BreakItem> = emptyList()

    private fun localSearchSaves(key: String): List<BreakItem> =
        runCatching {
            val rows = JSONArray(prefs.getString("search_saves:$key", "[]"))
            (0 until rows.length()).mapNotNull { i ->
                val row = rows.getJSONObject(i)
                val file = File(Uri.parse(row.getString("uri")).path.orEmpty())
                if (file.isFile) BreakItem(DocumentFile.fromFile(file), row.getString("name"), true) else null
            }
        }.getOrDefault(emptyList())

    fun saveSearchToLocal(name: String, uri: String, playingUri: String?, key: String?): Boolean {
        key ?: return false
        val item = BreakItem(DocumentFile.fromFile(File(Uri.parse(uri).path.orEmpty())), name, true)
        val saves = dedupeMedia(localSearchSaves(key) + item)
        val source = if (key == activeLocalSaveKey) activeLocalItems else emptyList()
        val updated = source.filterNot { it.file.uri.toString() == uri }.toMutableList()
        val at = updated.indexOfFirst { it.file.uri.toString() == playingUri }
        updated.add(if (at >= 0) at + 1 else updated.size, item)
        val rows = JSONArray()
        saves.forEach { rows.put(JSONObject().put("uri", it.file.uri.toString()).put("name", it.name)) }
        if (!prefs.edit().putString("search_saves:$key", rows.toString())
                .putString(key, JSONArray(updated.map { it.file.uri.toString() }).toString()).commit()) return false
        if (key == activeLocalSaveKey) {
            activeLocalItems = updated
            if (activePlaybackPlaylistContext == null) {
                val queued = playbackQueue.filterNot { it.file.uri.toString() == uri }.toMutableList()
                val currentIndex = queued.indexOfFirst { it.file.uri.toString() == playingUri }
                queued.add(if (currentIndex >= 0) currentIndex + 1 else queued.size, item)
                playbackQueue = queued
            }
        }
        rebuildAllMusicCache()
        val visibleKey = visibleOrderKey
        if (visibleKey == key) tracks = applySavedOrder(dedupeMedia(tracks + item), key)
        return true
    }

    private var pendingYoutubeError: Job? = null
    private var errorSequence = 0
    private fun buildAllMusicCache(manual: List<BreakItem>, media: List<BreakItem>): List<BreakItem> =
        applySavedOrder(
            dedupeMedia(manual + media + localSearchSaves("order:all_music")).filterNot(::isBundledSeed),
            "order:all_music"
        )

    private fun rebuildAllMusicCache() {
        allMusicCache = buildAllMusicCache(manualLibraryItems, mediaStoreItems)
    }
    val installedItems: List<BreakItem> get() = installedMediaDir.listFiles().orEmpty()
        .filter { it.isFile && (it.extension.lowercase(Locale.ROOT) in localPlayableExtensions || it.extension.lowercase(Locale.ROOT) in setOf("yt", "bmq")) }
        .map { f -> BreakItem(DocumentFile.fromFile(f), f.nameWithoutExtension, f.extension.lowercase(Locale.ROOT) in setOf("yt", "bmq")) }

    init {
        installBundledMedia()
        brakeMonsterDir.mkdirs(); ytDownloadsDir.mkdirs()
        refreshOwnedItems()
        manualLibraryItems = cachedItems("manual_library_cache")
        mediaStoreItems = cachedItems("media_store_cache")
        rebuildAllMusicCache()
        tracks = allMusicCache
        viewModelScope.launch(Dispatchers.IO) {
            BmqCodec.migrateOwnedYt(getApplication(), brakeMonsterDir)
            BmqCodec.migrateOwnedYt(getApplication(), File(getApplication<Application>().filesDir, "user_playlists"))
            withContext(Dispatchers.Main) { refreshOwnedItems(); refreshSerial++ }
        }
        BreakPlaybackService.onSingleTrackCompleted = {
            if (playbackQueue.isEmpty()) clearYoutube()
            else if (playbackQueue.all { it.isAudioServiceTrack() }) {
                BlackBox.log("QUEUE AUDIO FINISHED count=${playbackQueue.size}")
                playbackQueue = emptyList()
                playbackQueueIndex = -1
                activePlaybackItemUri = null
            } else advanceQueue()
        }
        BreakPlaybackService.onTrackChanged = { uri ->
            val index = playbackQueue.indexOfFirst { it.file.uri.toString() == uri }
            if (index >= 0) {
                playbackQueueIndex = index
                activePlaybackItemUri = uri
            } else {
                // A WEB SAVE / QUEUE ghost can be inserted immediately NEXT
                // from outside the current playlist. Do not keep highlighting
                // the song that was playing before this external handover.
                activePlaybackItemUri = uri
                activePlaybackPlaylistContext = null
            }
        }
        viewModelScope.launch {
            while (isActive) {
                syncServiceSnapshot()
                delay(150)
            }
        }
        // Do not auto-scan on startup. The first library scan must only start after
        // the user explicitly presses FIND YOUR MUSIC.
    }

    /** Skip failed YouTube video references without deleting user playlist entries.
     * IFrame error codes do not reliably distinguish age restriction from temporary failures.
     */
    fun onYoutubePlaybackError(errorCode:String) {
        if(playbackQueue.isEmpty() || playbackQueueIndex !in playbackQueue.indices) return
        val failedUri=activePlaybackItemUri ?: return
        val failedContext=activePlaybackPlaylistContext
        // A network outage must not sweep through the entire playlist.
        val cm=getApplication<Application>().getSystemService(android.content.Context.CONNECTIVITY_SERVICE)
                as? android.net.ConnectivityManager
        val connected=runCatching { cm?.activeNetworkInfo?.isConnected == true }.getOrDefault(false)
        if(!connected) {
            BlackBox.log("YT ERROR network unavailable; keeping playlist and position: $errorCode")
            return
        }
        // UNKNOWN may be an age-gate or another iframe failure: skip, never auto-hide.
        BlackBox.log("YT ERROR skip in 2 seconds: $errorCode")
        autoFailedYoutubeUris.add(failedUri)
        val sequence=++errorSequence
        pendingYoutubeError?.cancel()
        pendingYoutubeError=viewModelScope.launch {
            delay(2_000)
            if(sequence==errorSequence && activePlaybackItemUri==failedUri && activePlaybackPlaylistContext==failedContext) advanceQueue()
        }
    }

    /** Remove only the three obsolete app-bundled starter files once; never touch user media. */
    private fun installBundledMedia() {
        brakeMonsterDir.mkdirs()
        val welcome = File(brakeMonsterDir, "BRAKE MONSTER WELCOME SONG.mp3")
        // Install the bundled welcome track once. Never overwrite or recreate a file
        // after first install, since it may have been changed or removed by the user.
        if (!prefs.getBoolean("welcome_song_asset_installed_v1", false)) {
            runCatching {
                if (!welcome.exists()) getApplication<Application>().assets.open("BRAKE MONSTER.mp3").use { input ->
                    welcome.outputStream().use { output -> input.copyTo(output) }
                }
                prefs.edit().putBoolean("welcome_song_asset_installed_v1", true).commit()
            }
        }
    }

    private fun loadPath(): List<String> = runCatching {
        val raw = prefs.getString("path", null) ?: return@runCatching emptyList<String>()
        val json = JSONArray(raw)
        (0 until json.length()).map { json.getString(it) }
    }.getOrDefault(emptyList<String>())

    private fun persistPath() {
        prefs.edit().putString("path", JSONArray(path).toString()).apply()
    }

    fun consumeMessage() { message = null }

    fun setRoot(uri: Uri) {
        indexedRoots = null
        rootUri = uri.toString()
        manualRootUris=(manualRootUris+uri.toString()).distinct()
        path = emptyList<String>()
        prefs.edit().putString("root", rootUri).putString("manual_roots",JSONArray(manualRootUris).toString()).putString("path", "[]").apply()
        refreshSerial++
    }

    fun home() {
        BlackBox.log("MODEL home pathDepth=${path.size}")
        if (path.isNotEmpty()) {
            path = emptyList<String>()
            persistPath()
        }
    }

    /** @return true when a folder level was consumed. */
    fun back(): Boolean {
        BlackBox.log("MODEL back pathDepth=${path.size}")
        if (path.isEmpty()) return false
        path = path.dropLast(1)
        persistPath()
        return true
    }

    fun openFolder(dir: LocalFolder) {
        BlackBox.log("MODEL openFolder ${dir.name}")
        val name = dir.name
        path = path + name
        persistPath()
    }

    /** Find an indexed SAF item in its granted tree and restore that exact folder. */
    fun navigateToLocalItem(item: BreakItem) {
        folderNavigationJob?.cancel()
        if (item.file.uri.scheme == "file" || item.file.uri.authority == "media") {
            home()
            refresh()
            return
        }
        val targetUri = item.file.uri
        val roots = manualRootUris
        folderNavigationJob = viewModelScope.launch {
            val destination = withContext(Dispatchers.IO) {
                folderScanMutex.withLock {
                    for (root in roots) {
                        val tree = Uri.parse(root)
                        val rootDocument = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
                        val visited = HashSet<Uri>()
                        fun find(uri: Uri, names: List<String>): List<String>? {
                            if (names.size > 12 || !visited.add(uri)) return null
                            val listing = runCatching { listFolder(uri) }.getOrNull() ?: return null
                            if (listing.tracks.any { it.file.uri == targetUri }) return names
                            for (folder in listing.folders) {
                                find(folder.uri, names + folder.name)?.let { return it }
                            }
                            return null
                        }
                        find(rootDocument, emptyList())?.let { return@withLock root to it }
                    }
                    null
                }
            }
            if (destination != null) {
                rootUri = destination.first
                path = destination.second
                prefs.edit().putString("root", rootUri).putString("path", JSONArray(path).toString()).apply()
            } else home()
            refresh()
        }
    }

    private data class FolderRequest(val root: String?, val path: List<String>, val serial: Int)
    private data class FolderListing(
        val folders: List<LocalFolder>,
        val tracks: List<BreakItem>
    )
    private data class FolderResult(
        val path: List<String>,
        val orderKey: String,
        val folders: List<LocalFolder>,
        val tracks: List<BreakItem>,
        val manualIndex: List<BreakItem>?,
        val allMusic: List<BreakItem>?
    )

    private val folderScanMutex = Mutex()
    private var folderNavigationJob: Job? = null
    private var visibleOrderKey = "order:all_music"
    private var pendingFolderRequest: FolderRequest? = null
    private var runningFolderRequest: FolderRequest? = null
    private var completedFolderRequest: FolderRequest? = null
    private var folderRefreshJob: Job? = null
    private var indexedRoots: List<String>? = null

    fun refresh() {
        val request = FolderRequest(rootUri, path, refreshSerial)
        if (request == pendingFolderRequest) return
        if (request == runningFolderRequest) {
            pendingFolderRequest = null
            return
        }
        if (runningFolderRequest == null && request == completedFolderRequest) return
        pendingFolderRequest = request
        if (folderRefreshJob?.isActive == true) return
        folderRefreshJob = viewModelScope.launch {
            loading = true
            try {
                while (true) {
                    val next = pendingFolderRequest ?: break
                    pendingFolderRequest = null
                    runningFolderRequest = next
                    error = null
                    val root = next.root
                    if (root == null) {
                        visibleOrderKey = "order:all_music"
                        folders = emptyList()
                        tracks = allMusicItems
                        completedFolderRequest = next
                        continue
                    }
                    try {
                        val roots = manualRootUris
                        val rebuildIndex = roots != indexedRoots
                        val savedIndex = manualLibraryItems
                        val mediaItems = mediaStoreItems
                        val result = withContext(Dispatchers.IO) {
                            folderScanMutex.withLock {
                                val rootUri = Uri.parse(root)
                                val rootDocument = DocumentsContract.buildDocumentUriUsingTree(
                                    rootUri, DocumentsContract.getTreeDocumentId(rootUri)
                                )
                                var uri = rootDocument
                                var listing = listFolder(uri)
                                val resolved = mutableListOf<String>()
                                for (segment in next.path) {
                                    uri = listing.folders.firstOrNull { it.name == segment }?.uri ?: break
                                    listing = listFolder(uri)
                                    resolved += segment
                                }
                                val index = if (resolved.isEmpty() && rebuildIndex) roots.flatMap { grantedRoot ->
                                    if (grantedRoot == root) scanManualTree(rootDocument, listing)
                                    else runCatching {
                                        val tree = Uri.parse(grantedRoot)
                                        scanManualTree(DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree)))
                                    }.getOrDefault(emptyList())
                                } else null
                                val orderKey = if (resolved.isEmpty()) "order:all_music" else "order:$uri"
                                val source = if (resolved.isEmpty()) mediaItems + (index ?: savedIndex) + listing.tracks else listing.tracks
                                val combined = applySavedOrder(dedupeMedia(source + localSearchSaves(orderKey)), orderKey)
                                if (index != null) saveItemCache("manual_library_cache", index)
                                FolderResult(resolved, orderKey, listing.folders, combined, index,
                                    index?.let { buildAllMusicCache(it, mediaItems) })
                            }
                        }
                        // An in-flight provider query is allowed to finish before the next
                        // request starts. Publish its rows only if it still owns the screen.
                        if (next.serial == refreshSerial && result.manualIndex != null && result.allMusic != null) {
                            manualLibraryItems = result.manualIndex
                            allMusicCache = result.allMusic
                            indexedRoots = roots
                        }
                        if (next != FolderRequest(rootUri, path, refreshSerial) || pendingFolderRequest != null) continue
                        visibleOrderKey = result.orderKey
                        if (path != result.path) {
                            path = result.path
                            persistPath()
                        }
                        folders = result.folders
                        tracks = result.tracks
                        completedFolderRequest = next.copy(path = result.path)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (_: Exception) {
                        if (next == FolderRequest(rootUri, path, refreshSerial)) {
                            folders = emptyList()
                            tracks = emptyList()
                            error = "Folder is unavailable. Select it again to restore access."
                        }
                    }
                }
            } finally {
                runningFolderRequest = null
                loading = false
            }
        }
    }

    private fun listFolder(uri: Uri): FolderListing {
        val context = getApplication<Application>()
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(uri, DocumentsContract.getDocumentId(uri))
        val columns = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        val folders = mutableListOf<LocalFolder>()
        val tracks = mutableListOf<BreakItem>()
        val cursor = checkNotNull(context.contentResolver.query(children, columns, null, null, null))
        cursor.use {
            while (it.moveToNext()) {
                val child = DocumentsContract.buildDocumentUriUsingTree(uri, it.getString(0))
                val name = it.getString(1) ?: continue
                if (it.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR) {
                    if (!name.equals(".thumbnails", true)) folders += LocalFolder(child, name)
                } else {
                    val extension = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
                    if (extension !in localPlayableExtensions && extension !in referenceExtensions) continue
                    val file = DocumentFile.fromSingleUri(context, child) ?: continue
                    tracks += BreakItem(file, name.substringBeforeLast('.'), extension in referenceExtensions, name)
                }
            }
        }
        return FolderListing(
            folders.sortedBy { it.name.lowercase(Locale.ROOT) },
            tracks.sortedBy { it.fileName.lowercase(Locale.ROOT) }
        )
    }

    private fun scanManualTree(root: Uri, rootListing: FolderListing = listFolder(root)): List<BreakItem> {
        val result = mutableListOf<BreakItem>()
        val visited = hashSetOf(root)
        fun visit(listing: FolderListing, depth: Int) {
            result.addAll(listing.tracks)
            if (depth >= 12) return
            for (folder in listing.folders) {
                if (!visited.add(folder.uri)) continue
                val children = runCatching { listFolder(folder.uri) }.getOrNull() ?: continue
                visit(children, depth + 1)
            }
        }
        visit(rootListing, 0)
        return result
    }

    private fun scanOwnedDir(dir: File, includeYt: Boolean): List<BreakItem> = runCatching {
        if (!dir.exists()) return@runCatching emptyList()
        dir.walkTopDown().filter { f ->
            f.isFile && (f.extension.lowercase(Locale.ROOT) in localPlayableExtensions ||
                (includeYt && f.extension.lowercase(Locale.ROOT) in setOf("yt", "bmq"))) &&
                !(f.extension.equals("yt", true) && File(f.parentFile, f.nameWithoutExtension + ".bmq").exists())
        }
            .map { f -> BreakItem(DocumentFile.fromFile(f), f.nameWithoutExtension, f.extension.lowercase(Locale.ROOT) in setOf("yt", "bmq")) }.toList()
    }.getOrDefault(emptyList())

    private fun refreshOwnedItems() { ownedMediaItems=scanOwnedDir(brakeMonsterDir, true) }

    fun importName(uri: Uri): String = runCatching {
        getApplication<Application>().contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Imported media"

    fun importedNameExists(name: String): Boolean {
        val ext=name.substringAfterLast('.',"").lowercase(Locale.ROOT)
        val dir=if(ext in setOf("yt", "bmq")) ytDownloadsDir else brakeMonsterDir
        val output = if(ext == "yt") name.substringBeforeLast('.') + ".bmq" else name
        return dir.listFiles().orEmpty().any { it.name.equals(output,true) }
    }

    /** Copy a picker-selected document into app-owned storage; the original URI is read only. */
    fun copyImport(uri: Uri, choice: String) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val context = getApplication<Application>()
                    brakeMonsterDir.mkdirs(); ytDownloadsDir.mkdirs()
                    val sourceName = sanitizeFileName(importName(uri)).ifBlank { "Imported media" }
                    val ext = sourceName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                    if (ext !in localPlayableExtensions && ext !in importSidecarExtensions && ext !in setOf("yt", "bmq")) return@runCatching false
                    val dir = if (ext in setOf("yt", "bmq")) ytDownloadsDir else brakeMonsterDir
                    val safeName = if (ext == "yt") sourceName.substringBeforeLast('.') + ".bmq" else sourceName
                    val existing=dir.listFiles().orEmpty().firstOrNull { it.name.equals(safeName,true) }
                    var target = File(dir, safeName)
                    if (existing!=null) {
                        when (choice) {
                            "replace" -> target=existing
                            "keep" -> { val base = safeName.substringBeforeLast('.', safeName); val suffix = safeName.substringAfterLast('.', "").let { if (it.isBlank()) "" else ".$it" }; var n=2; while (dir.listFiles().orEmpty().any { it.name.equals("$base ($n)$suffix",true) }) n++; target=File(dir,"$base ($n)$suffix") }
                            else -> return@runCatching false
                        }
                    }
                    if (ext in setOf("yt", "bmq")) {
                        val body = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                            ?: return@runCatching false
                        if (body.length > 8192) return@runCatching false
                        BmqCodec.atomicWrite(target, BmqCodec.convertToDevice(body))
                    } else {
                        context.contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use { output -> input.copyTo(output) } } ?: return@runCatching false
                    }
                    true
                }.getOrDefault(false)
            }
            if (result) { refreshOwnedItems(); message = "IMPORTED"; refreshSerial++ } else message = "Import was cancelled or could not be copied."
        }
    }

    private fun cachedItems(key:String):List<BreakItem> = runCatching {
        val a=JSONArray(prefs.getString(key,"[]"));(0 until a.length()).mapNotNull { i ->
            val o=a.getJSONObject(i);val uri=Uri.parse(o.getString("uri"));
            val doc=if(uri.scheme=="file") DocumentFile.fromFile(File(uri.path.orEmpty())) else DocumentFile.fromSingleUri(getApplication(),uri)
            doc?.let {
                // Do NOT use it.name as optString's default: Kotlin evaluates that default
                // eagerly, causing a ContentResolver query for every cached MediaStore row.
                val cachedName = o.optString("name").takeIf { n -> n.isNotBlank() }
                    ?: uri.lastPathSegment.orEmpty()
                BreakItem(it, cachedName, o.optBoolean("yt", false), o.optString("fileName", uri.lastPathSegment.orEmpty().substringAfterLast('/')))
            }
        }
    }.getOrDefault(emptyList())

    private fun saveItemCache(key:String,items:List<BreakItem>) {
        val a=JSONArray();items.forEach { a.put(org.json.JSONObject().put("uri",it.file.uri.toString()).put("name",it.name).put("yt",it.isYoutube).put("fileName",it.fileName)) }
        prefs.edit().putString(key,a.toString()).apply()
    }

    private fun isBundledSeed(item: BreakItem): Boolean {
        // item.name is cached metadata. DocumentFile.name can hit ContentResolver and must
        // never be used from this Compose-facing filter.
        val n = item.name.trim()
        return n.equals("BRAKE MONSTER WELCOME SONG.mp3", true) ||
            n.equals("BRAKE MONSTER WELCOME SONG", true) ||
            n.equals("BRAKE MONSTER.mp3", true) ||
            n.equals("TERAPHONIA - TERAPHONIA DAD.bmq", true) ||
            n.equals("TERAPHONIA - TERAPHONIA DAD", true) ||
            n.equals("EDEN - TERAPHONIA DAD.bmq", true) ||
            n.equals("EDEN - TERAPHONIA DAD", true)
    }

    private fun dedupeMedia(items:List<BreakItem>):List<BreakItem> {
        // IMPORTANT: never call DocumentFile.length()/name here. For MediaStore URIs those
        // methods perform ContentResolver I/O; this function is also used by Compose-facing
        // getters and previously caused seconds of main-thread blocking for ~1000 songs.
        val seenUris=HashSet<String>()
        return items.filter { item -> seenUris.add(item.file.uri.toString()) }
    }

    private fun applySavedOrder(items:List<BreakItem>, key:String):List<BreakItem> {
        val saved=runCatching { JSONArray(prefs.getString(key,"[]")) }.getOrNull()?.let { a -> (0 until a.length()).map { a.getString(it) } }.orEmpty()
        if(saved.isEmpty()) return items
        val rank=saved.withIndex().associate { it.value to it.index }
        return items.sortedWith(compareBy<BreakItem> { rank[it.file.uri.toString()] ?: Int.MAX_VALUE }.thenBy { it.name.lowercase(Locale.ROOT) })
    }

    fun moveTrack(from: Int, to: Int) {
        if (from !in tracks.indices || to !in tracks.indices || from == to) return
        val m = tracks.toMutableList()
        val item = m.removeAt(from)
        m.add(to, item)
        tracks = m
        val orderKey = visibleOrderKey
        prefs.edit().putString(orderKey, JSONArray(m.map { it.file.uri.toString() }).toString()).apply()
    }



    /** Save a concrete .yt file inside the selected user's physical playlist directory. */
    fun saveYoutubeToPlaylist(playlistIndex: Int, exactFieldName: String, onSaved: (String, String, Boolean) -> Boolean) {
        val rawUrl = youtubeUrl ?: run { message = "Prvo pusti YouTube video."; return }
        val title = exactFieldName.ifBlank { youtubeTitle ?: "YouTube" }
        val app = getApplication<Application>()
        val versionInfo = runCatching {
            val info = app.packageManager.getPackageInfo(app.packageName, 0)
            @Suppress("DEPRECATION")
            val code = if (android.os.Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
            "versionName=${info.versionName ?: "unknown"} versionCode=$code"
        }.getOrDefault("versionName=unknown versionCode=unknown")
        var stage = "URL_VALIDATION"
        BlackBox.log("SAVE YT BEGIN $versionInfo playlist=$playlistIndex")
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    stage = "FILE_CREATION"
                    persistYoutubePlaylistFile(playlistIndex, title, rawUrl)
                }
            }
            result.fold(onSuccess = { (name, uri) ->
                try {
                    stage = "PLAYLIST_PERSISTENCE"
                    BlackBox.log("SAVE YT STAGE=$stage name=$name playlist=$playlistIndex")
                    check(onSaved(title.ifBlank { name }, uri, true)) { "Playlist entry could not be persisted" }
                    stage = "BROWSER_REFRESH"
                    refreshSerial++
                    if (youtubeUrl == rawUrl) {
                        youtubeSaved = true
                        youtubeCanSave = false
                        clearYoutube()
                    }
                    message = "BMQ SAVED: $name"
                    BlackBox.log("SAVE YT SUCCESS $versionInfo stage=$stage playlist=$playlistIndex name=$name")
                } catch (e: Throwable) {
                    logSaveYoutubeFailure(versionInfo, stage, playlistIndex, e)
                    message = "SAVE FAILED: ${e.message ?: e.javaClass.simpleName}"
                }
            }, onFailure = { e ->
                logSaveYoutubeFailure(versionInfo, stage, playlistIndex, e)
                message = "SAVE FAILED: ${e.message ?: e.javaClass.simpleName}"
            })
        }
    }

    /** ZIP payloads are written on IO, then committed to playlist storage as one ordered batch. */
    fun importYoutubeLinksToPlaylist(
        playlistIndex: Int,
        links: List<Pair<String, String>>,
        onSaved: suspend (saved: List<Triple<String, String, String>>, failed: Int) -> Pair<Int, Int>,
        onComplete: (added: Int, skipped: Int) -> Unit
    ) {
        viewModelScope.launch {
            val saved = withContext(Dispatchers.IO) {
                links.map { (title, url) -> runCatching {
                    val (name, uri) = persistYoutubePlaylistFile(playlistIndex, title, url)
                    Triple(name, uri, extractYoutubeVideoId(url).orEmpty())
                } }
            }
            val valid = saved.mapNotNull { result -> result.getOrNull() }
            val failed = saved.size - valid.size
            val result = try { onSaved(valid, failed) } catch (_: Throwable) { 0 to saved.size }
            refreshSerial++
            onComplete(result.first, result.second)
        }
    }

    /** The single writer for both YouTube Search saves and imported .yt links. */
    private fun persistYoutubePlaylistFile(playlistIndex: Int, title: String, rawUrl: String): Pair<String, String> {
        require(title.isNotBlank()) { "Enter a song name in IME NUMERE" }
        val videoId = extractYoutubeVideoId(rawUrl) ?: error("Invalid YouTube video URL")
        val canonicalUrl = "https://www.youtube.com/watch?v=$videoId"
        // The filename comes from the user's current IME NUMERE value, preserving
        // all text except characters forbidden by the filesystem.
        val base = sanitizeYoutubeFileName(title)
        val dir = File(getApplication<Application>().filesDir, "user_playlists/$playlistIndex")
        check(dir.isDirectory || dir.mkdirs()) { "Cannot create playlist folder" }
        var finalName = base
        var file = File(dir, "$finalName.bmq")
        var duplicate = 1
        while (file.exists() && runCatching { BmqCodec.decode(file.readText(Charsets.UTF_8)) != videoId }.getOrDefault(true)) {
            duplicate++
            check(duplicate < 10000) { "Too many duplicate YouTube filenames" }
            // Keep the complete user title and add a collision marker only when needed.
            val suffix = " ($duplicate)"
            finalName = base + suffix
            file = File(dir, "$finalName.bmq")
        }
        if (!file.exists()) {
            val temp = File.createTempFile("saveyt_", ".tmp", dir)
            try {
                temp.writeText(BmqCodec.encode(canonicalUrl), Charsets.UTF_8)
                check(temp.renameTo(file)) { "Could not finalize YouTube link file" }
            } finally {
                if (temp.exists()) temp.delete()
            }
        }
        check(file.isFile && BmqCodec.decode(file.readText(Charsets.UTF_8)) == videoId) { "Saved .bmq file verification failed" }
        return finalName to Uri.fromFile(file).toString()
    }

    private fun logSaveYoutubeFailure(version: String, stage: String, playlistIndex: Int, error: Throwable) {
        BlackBox.log("SAVE YT FAILED $version stage=$stage playlist=$playlistIndex exception=${error.javaClass.name}: ${error.message}\n${android.util.Log.getStackTraceString(error)}")
    }

    fun cancelPlaylistTransitionOverlay(reason: String) {
        if (playlistTransitionTargetUri != null) {
            BlackBox.log("PLAYLIST TRANSITION OVERLAY CANCEL reason=$reason target=$playlistTransitionTargetUri")
        }
        playlistTransitionTargetUri = null
        observedIdleTrackLoad = false
    }

    private fun trackIdleStart(uri: String, selectedByUser: Boolean = true) {
        val live = BreakPlaybackService.snapshot
        playlistTransitionTargetUri = uri.takeIf { selectedByUser && !live.playing && !youtubePlaying }
        observedIdleTrackLoad = false
    }

    fun isIdleTrackLoading(s: BreakPlaybackService.Snapshot): Boolean {
        val target = playlistTransitionTargetUri ?: return false
        return s.sessionActive && !s.playing && !s.crossfading &&
            ((s.trackUri == target && s.preparing) ||
                (s.transitionRequested && s.standbyTrackUri == target &&
                    (s.deckBPreparing || s.deckBReady || s.deckBRecovering)))
    }

    fun startPlaylist(
        items: List<BreakItem>,
        startIndex: Int,
        playlistContext: String? = null,
        selectedByUser: Boolean = true
    ) {
        if (items.isEmpty() || startIndex !in items.indices) return
        val incoming = items[startIndex]
        trackIdleStart(incoming.file.uri.toString(), selectedByUser)
        autoFailedYoutubeUris.clear()
        activePlaybackPlaylistContext = playlistContext
        val ordered=items.drop(startIndex) + items.take(startIndex)
        val first=ordered.first()
        val rest=ordered.drop(1)
        playbackQueue = listOf(first) + if(random) rest.shuffled() else rest
        playbackQueueIndex = 0
        startQueueItem()
    }

    /** Called only after a song has actually been persisted to the active playlist. */
    fun onActivePlaylistSongAdded(context: String, newItems: List<BreakItem>) {
        if (activePlaybackPlaylistContext != context || playbackQueue.size != 1) return
        val current = playbackQueue.firstOrNull() ?: return
        val added = newItems.firstOrNull { it.file.uri != current.file.uri } ?: return
        if (!current.isAudioServiceTrack() || !added.isAudioServiceTrack()) return
        val appended = BreakPlaybackService.appendToActivePlaylist(
            current.file.uri.toString(),
            BreakPlaybackService.Entry(added.file.uri.toString(), added.playbackName)
        )
        if (appended) {
            playbackQueue = playbackQueue + added
            BlackBox.log("QUEUE MODEL DYNAMIC APPEND next=${added.name} context=$context")
        }
    }

    /** Push the latest active user playlist order into the live service without replacing its playing deck. */
    private var deletedPlaybackContext: String? = null
    fun finishDeletedPlaylist(context: String) {
        if (activePlaybackPlaylistContext != context) return
        deletedPlaybackContext = context
        val uri = BreakPlaybackService.snapshot.trackUri ?: localTrackUri ?: return
        val current = playbackQueue.firstOrNull { it.file.uri.toString() == uri } ?: return
        playbackQueue = listOf(current)
        playbackQueueIndex = 0
        BreakPlaybackService.updateActiveQueue(uri,
            listOf(BreakPlaybackService.Entry(uri, current.name)), shuffle = false, looping = false)
    }

    fun refreshActivePlaylist(context: String, latestItems: List<BreakItem>) {
        if (activePlaybackPlaylistContext != context || playbackQueue.isEmpty() ||
            playbackQueue.any { !it.isAudioServiceTrack() } || latestItems.any { !it.isAudioServiceTrack() }) return
        val playingUri = BreakPlaybackService.snapshot.trackUri ?: localTrackUri ?: return
        val current = playbackQueue.firstOrNull { it.file.uri.toString() == playingUri }
            ?: playbackQueue.getOrNull(playbackQueueIndex) ?: return
        val latest = latestItems.filter { it.isAudioServiceTrack() }
            .distinctBy { it.file.uri.toString() }
        val currentIndex = latest.indexOfFirst { it.file.uri.toString() == playingUri }
        val upcoming = when {
            random || repeat -> latest.filterNot { it.file.uri.toString() == playingUri }
            currentIndex >= 0 -> latest.drop(currentIndex + 1)
            else -> latest
        }
        // Keep the active item at position zero for the live service snapshot.
        // Sequential playback includes only rows after the current row; otherwise a
        // refresh while song 2 played would incorrectly make song 1 NEXT again.
        val ordered = listOf(current) + upcoming
        playbackQueue = ordered
        playbackQueueIndex = 0
        val changed = BreakPlaybackService.updateActiveQueue(
            expectedCurrentUri = playingUri,
            updated = ordered.map { BreakPlaybackService.Entry(it.file.uri.toString(), it.playbackName) },
            shuffle = random, looping = repeat
        )
        BlackBox.log("ACTIVE PLAYLIST REFRESH context=$context count=${ordered.size} upcoming=${upcoming.size} playing=${current.name} serviceUpdated=$changed")
    }

    fun startLocal(selected: BreakItem) {
        // Global search may select a file outside the currently open folder.
        // Always include the selected file in the playback queue; otherwise
        // the old implementation silently returned or played a different item.
        val current = tracks.filter { it.isYoutube || it.extension in localPlayableExtensions || it.isAudioServiceTrack() }
        val playable = if (current.any { it.file.uri == selected.file.uri }) current else {
            val global = allMusicItems.filter { it.isYoutube || it.extension in localPlayableExtensions || it.isAudioServiceTrack() }
            if (global.any { it.file.uri == selected.file.uri }) global else listOf(selected)
        }
        activePlaybackPlaylistContext = null
        activeLocalSaveKey = if (playable === current) visibleOrderKey else "order:all_music"
        activeLocalItems = playable
        autoFailedYoutubeUris.clear()
        val selectedIndex = playable.indexOfFirst { it.file.uri == selected.file.uri }
        if (selectedIndex < 0) return
        trackIdleStart(selected.file.uri.toString())
        BlackBox.log("QUEUE MODEL START size=${playable.size} selectedIndex=$selectedIndex selected=${selected.name} source=local")
        val rest = playable.filterIndexed { index, _ -> index != selectedIndex }
        playbackQueue = listOf(playable[selectedIndex]) + if (random) rest.shuffled() else rest
        playbackQueueIndex = 0
        startQueueItem()
    }

    private fun startQueueItem() {
        pendingYoutubeError?.cancel()
        pendingYoutubeError=null
        errorSequence++
        val item = playbackQueue.getOrNull(playbackQueueIndex) ?: return
        activePlaybackItemUri = item.file.uri.toString()
        val itemExtension = item.extension
        val savedAudioReference = itemExtension in setOf("bmq", "yt")
        if (item.isYoutube && !savedAudioReference) {
            if(item.file.uri.toString() in autoFailedYoutubeUris) { advanceQueue(); return }
            stopLocal()
            clearYoutube()
            openSavedYoutubeForQueue(item)
            return
        }
        clearYoutube()
        // Keep the entire audio-only queue inside the foreground service.
        // Mixed YouTube-video queues retain the legacy model-owned handoff.
        val serviceQueue = if (playbackQueue.all { it.isAudioServiceTrack() }) playbackQueue else listOf(item)
        val request = BreakPlaybackService.StartRequest(
            files = serviceQueue.map { BreakPlaybackService.Entry(it.file.uri.toString(), it.playbackName) },
            selectedUri = item.file.uri.toString(),
            random = random,
            repeat = if (serviceQueue.size > 1) repeat else false,
            volume = 1f,
            playlistContext = activePlaybackPlaylistContext
        )
        BlackBox.log("QUEUE HANDOFF model=${playbackQueue.size} service=${serviceQueue.size} selected=${playbackQueueIndex} mixed=${serviceQueue.size == 1 && playbackQueue.size > 1}")
        BreakPlaybackService.start(getApplication(), request)
    }

    fun toggleLocalPause() = BreakPlaybackService.togglePause()
    fun nextLocal() {
        if (playbackQueue.isNotEmpty() && playbackQueue.all { it.isAudioServiceTrack() }) {
            BreakPlaybackService.next()
        } else if (playbackQueue.isNotEmpty()) {
            stopLocal()
            advanceQueue()
        } else BreakPlaybackService.next()
    }
    fun previousLocal() {
        if (playbackQueue.isNotEmpty() && playbackQueue.all { it.isAudioServiceTrack() }) {
            BreakPlaybackService.previous()
        } else if (playbackQueueIndex > 0) {
            stopLocal()
            clearYoutube()
            playbackQueueIndex--
            startQueueItem()
        } else if (localTrackUri != null) {
            BreakPlaybackService.previous()
        } else if (playbackQueueIndex == 0 && playbackQueue.isNotEmpty()) {
            stopLocal()
            clearYoutube()
            startQueueItem()
        }
    }
    fun seekLocal(value: Int) = BreakPlaybackService.seekTo(value)
    fun stopLocal() = BreakPlaybackService.stop(getApplication())

    fun updateRandom(value: Boolean) {
        random = value
        prefs.edit().putBoolean("random", value).apply()
        BreakPlaybackService.setRandom(value)
    }

    fun updateRepeat(value: Boolean) {
        repeat = value
        prefs.edit().putBoolean("repeat", value).apply()
        BreakPlaybackService.setRepeat(value)
    }

    fun selectYoutube(videoId: String, title: String?, sourceUrl: String? = null) {
        // Web search selection is a pending QUEUE save only. Never touch the live
        // service, playback queue, or the currently playing deck here.
        youtubeVideoId = videoId
        youtubeUrl = sourceUrl?.takeIf { it.isNotBlank() } ?: "https://www.youtube.com/watch?v=$videoId"
        youtubeTitle = title?.trim()?.takeIf { it.isNotBlank() } ?: "YouTube"
        youtubeSaved = false
        youtubeCanSave = true
        BlackBox.log("WEB SEARCH SELECTED title=$youtubeTitle uri=$youtubeUrl playbackUntouched=true")
    }

    fun openSavedYoutube(item: BreakItem) {
        if (!item.isYoutube) return
        autoFailedYoutubeUris.clear()
        activePlaybackPlaylistContext = null
        val current = tracks.filter { it.isYoutube || it.extension in localPlayableExtensions || it.isAudioServiceTrack() }
        val playable = if(current.any { it.file.uri==item.file.uri }) current else allMusicItems.filter { it.isYoutube || it.extension in localPlayableExtensions || it.isAudioServiceTrack() }
        val selectedIndex = playable.indexOfFirst { it.file.uri == item.file.uri }
        if (selectedIndex >= 0) {
            val rest = playable.filterIndexed { index, _ -> index != selectedIndex }
            playbackQueue = listOf(playable[selectedIndex]) + if (random) rest.shuffled() else rest
            playbackQueueIndex = 0
        }
        stopLocal()
        clearYoutube()
        if (item.extension in setOf("bmq", "yt") && playbackQueue.isNotEmpty()) startQueueItem()
        else openSavedYoutubeForQueue(item)
    }

    private fun openSavedYoutubeForQueue(item: BreakItem) {
        viewModelScope.launch {
            val link = withContext(Dispatchers.IO) {
                runCatching {
                    if(item.file.uri.scheme=="file") File(item.file.uri.path.orEmpty()).takeIf { it.isFile }?.readText()?.trim()
                    else getApplication<Application>().contentResolver.openInputStream(item.file.uri)?.bufferedReader()?.use { it.readText().trim() }
                }.getOrNull()
            }
            val id = runCatching { BmqCodec.decode(link.orEmpty()) }.getOrNull()
            if (id == null) {
                if (playlistTransitionTargetUri == item.file.uri.toString()) {
                    cancelPlaylistTransitionOverlay("saved_link_unavailable")
                }
                message = "Sačuvani YT link nije dostupan."
            } else {
                youtubeVideoId = id
                youtubeUrl = "https://www.youtube.com/watch?v=$id"
                youtubeTitle = item.name
                youtubeCurrentSecond = 0f
                youtubeDurationSecond = 0f
                youtubePlaying = false
                youtubeSaved = true
                youtubeCanSave = false
                youtubeSession++
                BreakPlaybackService.start(getApplication(), BreakPlaybackService.StartRequest(
                    files = listOf(BreakPlaybackService.Entry(item.file.uri.toString(), item.name)),
                    selectedUri = item.file.uri.toString(), random = false, repeat = false, volume = 1f
                ))
            }
        }
    }

    fun clearYoutube() {
        youtubeVideoId = null
        youtubeUrl = null
        youtubeTitle = null
        youtubePlaying = false
        youtubeCurrentSecond = 0f
        youtubeDurationSecond = 0f
        youtubeSaved = false
        youtubeCanSave = false
    }

    fun onYoutubePlaying(value: Boolean) { youtubePlaying = value }
    fun onYoutubeCurrentSecond(value: Float) { youtubeCurrentSecond = value.coerceAtLeast(0f) }
    fun onYoutubeDuration(value: Float) { youtubeDurationSecond = value.coerceAtLeast(0f) }

    fun onYoutubeEnded() {
        if (youtubeCanSave && playbackQueue.isEmpty()) return
        clearYoutube()
        advanceQueue()
    }

    fun stopPlayback() {
        cancelPlaylistTransitionOverlay("stop_playback")
        pendingYoutubeError?.cancel()
        pendingYoutubeError=null
        errorSequence++
        autoFailedYoutubeUris.clear()
        playbackQueue = emptyList()
        playbackQueueIndex = -1
        activePlaybackItemUri = null
        activePlaybackPlaylistContext = null
        stopLocal()
        clearYoutube()
    }

    override fun onCleared() {
        BreakPlaybackService.onSingleTrackCompleted = null
        BreakPlaybackService.onTrackChanged = null
        super.onCleared()
    }

    private fun advanceQueue() {
        if (deletedPlaybackContext != null && deletedPlaybackContext == activePlaybackPlaylistContext) {
            deletedPlaybackContext = null
            stopPlayback()
            return
        }
        if (playbackQueue.isEmpty()) return
        val size=playbackQueue.size
        var next=playbackQueueIndex+1
        if(next>=size) {
            if(repeat) next=0 else { stopPlayback(); return }
        }
        var checked=0
        while(checked<size) {
            val candidate=playbackQueue[next]
            if(!candidate.isYoutube || candidate.file.uri.toString() !in autoFailedYoutubeUris) break
            checked++
            next++
            if(next>=size) {
                if(repeat) next=0 else { stopPlayback(); return }
            }
        }
        if(checked>=size) { stopPlayback(); return }
        playbackQueueIndex=next
        startQueueItem()
    }

    fun rename(item: BreakItem, newBaseName: String) {
        val clean = sanitizeFileName(newBaseName).trim()
        if (clean.isBlank()) { message = "Ime ne može biti prazno."; return }
        viewModelScope.launch {
            val uri = item.file.uri
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val ext = item.file.name.orEmpty().substringAfterLast('.', "")
                    val wanted = if (ext.isBlank()) clean else "$clean.$ext"
                    if (DocumentsContract.isTreeUri(uri)) {
                        DocumentsContract.renameDocument(getApplication<Application>().contentResolver, uri, wanted) != null
                    } else item.file.renameTo(wanted)
                }.getOrDefault(false)
            }
            if (!ok) message = "Rename nije uspio."
            else if (DocumentsContract.isTreeUri(uri)) indexedRoots = null
            refreshOwnedItems(); refreshSerial++
        }
    }

    fun delete(item: BreakItem, onSuccess: (() -> Unit)? = null) {
        if (localTrackUri == item.file.uri.toString()) stopLocal()
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching {
                if(item.file.uri.authority=="media") getApplication<Application>().contentResolver.delete(item.file.uri,null,null)>0
                else item.file.delete()
            }.getOrDefault(false) }
            if (!ok) message = "Delete nije uspio."
            else {
                if (DocumentsContract.isTreeUri(item.file.uri)) indexedRoots = null
                onSuccess?.invoke()
            }
            refreshOwnedItems()
            refreshSerial++
        }
    }

    fun onMediaStoreDeleteApproved(item:BreakItem){
        val uri=item.file.uri.toString()
        if(localTrackUri==uri) stopLocal()
        mediaStoreItems=mediaStoreItems.filterNot { it.file.uri.toString()==uri }
        manualLibraryItems=manualLibraryItems.filterNot { it.file.uri.toString()==uri }
        rebuildAllMusicCache()
        tracks=tracks.filterNot { it.file.uri.toString()==uri }
        saveItemCache("media_store_cache",mediaStoreItems)
        saveItemCache("manual_library_cache",manualLibraryItems)
        refreshSerial++
    }

    fun findInstalledWelcome():BreakItem? = scanOwnedDir(brakeMonsterDir, true).firstOrNull { it.file.name.equals("BRAKE MONSTER WELCOME SONG.mp3",true) }

    fun bundledP1Items(): List<BreakItem> = scanOwnedDir(brakeMonsterDir, true).filter { item ->
        item.file.name.equals("BRAKE MONSTER WELCOME SONG.mp3",true) ||
        item.file.name.equals("TERAPHONIA - TERAPHONIA DAD.bmq",true) ||
        item.file.name.equals("EDEN - TERAPHONIA DAD.bmq",true)
    }.sortedBy { if(it.file.name.equals("BRAKE MONSTER WELCOME SONG.mp3",true)) 0 else 1 }

    fun scanMediaStore(showResult:Boolean=true) {
        if(mediaScanInProgress) { BlackBox.log("MEDIA SCAN ignored already running"); return }
        val bbScanStart=android.os.SystemClock.elapsedRealtime()
        mediaScanInProgress=true
        viewModelScope.launch {
            BlackBox.log("MEDIA SCAN DISPATCH -> IO")
            val scanResult=withContext(Dispatchers.IO) {
                val ioStart=android.os.SystemClock.elapsedRealtime()
                BlackBox.log("MEDIA SCAN IO START")
                val resolver=getApplication<Application>().contentResolver
                val collection=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                val columns=arrayOf(MediaStore.Audio.Media._ID,MediaStore.Audio.Media.DISPLAY_NAME,MediaStore.Audio.Media.TITLE)
                val out=mutableListOf<BreakItem>()
                runCatching {
                    resolver.query(collection,columns,"${MediaStore.Audio.Media.IS_MUSIC} != 0",null,"${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
                        val idCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                        val nameCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                        val titleCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                        while(c.moveToNext()) {
                            val uri=ContentUris.withAppendedId(collection,c.getLong(idCol))
                            val rawName=c.getString(nameCol).orEmpty()
                            val display=c.getString(titleCol)?.takeIf{it.isNotBlank()} ?: rawName.substringBeforeLast('.')
                            // Filter seed files from cursor metadata while still on IO. Do not
                            // ask DocumentFile for name/length later on the main thread.
                            val n=rawName.ifBlank { display }
                            val seed=n.equals("BRAKE MONSTER WELCOME SONG.mp3",true) ||
                                n.equals("BRAKE MONSTER WELCOME SONG",true) || n.equals("BRAKE MONSTER.mp3",true) ||
                                n.equals("TERAPHONIA - TERAPHONIA DAD.bmq",true) || n.equals("TERAPHONIA - TERAPHONIA DAD",true) ||
                                n.equals("EDEN - TERAPHONIA DAD.bmq",true) || n.equals("EDEN - TERAPHONIA DAD",true)
                            if(!seed) {
                                val file=DocumentFile.fromSingleUri(getApplication(),uri) ?: continue
                                out.add(BreakItem(file, display, false, n))
                            }
                        }
                    }
                }
                val cached=JSONArray()
                out.forEach { cached.put(org.json.JSONObject().put("uri",it.file.uri.toString()).put("name",it.name).put("fileName",it.fileName)) }
                BlackBox.log("MEDIA SCAN IO END ${android.os.SystemClock.elapsedRealtime()-ioStart}ms items=${out.size}")
                Pair(out,cached.toString())
            }
            // Main thread now only swaps already-built in-memory state; no provider calls.
            val (found,cacheJson)=scanResult
            mediaStoreItems=found
            rebuildAllMusicCache()
            tracks=allMusicCache
            mediaScanComplete=true
            prefs.edit().putBoolean("media_scan_complete",true).putBoolean("first_user_scan_complete_v25",true).putString("media_store_cache",cacheJson).apply()
            if(showResult) message="${found.size} SONGS FOUND"
            refreshSerial++
            mediaScanInProgress=false
            BlackBox.log("MEDIA SCAN COMPLETE ${android.os.SystemClock.elapsedRealtime()-bbScanStart}ms items=${found.size}")
        }
    }

    private fun syncServiceSnapshot() {
        val s = BreakPlaybackService.snapshot
        val target = playlistTransitionTargetUri
        if (target != null) {
            val loading = isIdleTrackLoading(s)
            if (loading) observedIdleTrackLoad = true
            if (!loading && (observedIdleTrackLoad || (s.trackUri == target && s.playing))) {
                cancelPlaylistTransitionOverlay("idle_track_load_finished")
            }
        }
        localTrackUri = s.trackUri
        localTrackName = s.trackName
        localPreparing = s.preparing
        localPlaying = s.playing
        localPosition = s.position
        localDuration = s.duration
        if (youtubeVideoId != null) {
            youtubePlaying = s.playing
            youtubeCurrentSecond = s.position / 1000f
            youtubeDurationSecond = s.duration / 1000f
        }
        if (random != s.random && s.sessionActive) random = s.random
        if (repeat != s.repeat && s.sessionActive) repeat = s.repeat
    }

    /** Safe filename normalization for imported files and Rename; no regex involved. */
    private fun sanitizeFileName(value: String): String {
        val cleaned = StringBuilder(value.length.coerceAtMost(180))
        for (char in value) {
            when {
                char.code < 32 || char.code == 127 || char in "\\/:*?\"<>|" -> cleaned.append('-')
                else -> cleaned.append(char)
            }
        }
        return cleaned.toString().trim().trim('.').take(180).trimEnd(' ', '.')
    }

    companion object {
        private fun isCanonicalYoutubeUrl(value: String): Boolean {
            val prefix = "https://www.youtube.com/watch?v="
            if (!value.startsWith(prefix)) return false
            val id = value.substring(prefix.length)
            return id.length == 11 && id.all { it in 'A'..'Z' || it in 'a'..'z' || it in '0'..'9' || it == '_' || it == '-' }
        }

        /** CdgLite SAVE HERE filename rules, adapted to BrakeMonster internal playlists.
         * No Regex/Pattern compilation on the SAVE YT path.
         */
        /** Strip trailing YouTube time badges, not numbers within real song titles. */
        fun cleanYoutubeTitle(value:String):String {
            var title=value.trim()
            // Entire title is a duration: do not turn the duration into a song name.
            fun isDuration(v:String):Boolean {
                val pieces=v.trim().split(':')
                return pieces.size in 2..3 && pieces.all{it.length in 1..2 && it.all(Char::isDigit)}
            }
            if(isDuration(title))return "YouTube karaoke"
            val parts=title.split(' ')
            if(parts.isNotEmpty() && isDuration(parts.last())) title=parts.dropLast(1).joinToString(" ").trimEnd(' ','-','|','•')
            if(title.isBlank())return "YouTube karaoke"
            return title
        }

        fun sanitizeYoutubeFileName(value: String): String {
            val normalized = StringBuilder(value.length)
            for (char in value) {
                normalized.append(if (char in "\\/:*?\"<>|" || char.code < 32 || char.code == 127) '-' else char)
            }
            return normalized.toString()
        }

        private fun takeFilenameChars(value: String, limit: Int): String {
            val result = StringBuilder(minOf(value.length, limit))
            var offset = 0
            var used = 0
            while (offset < value.length) {
                val codePoint = value.codePointAt(offset)
                val units = Character.charCount(codePoint)
                if (used + units > limit) break
                result.appendCodePoint(codePoint)
                offset += units
                used += units
            }
            return result.toString()
        }

        fun extractYoutubeVideoId(raw: String?): String? {
            if (raw.isNullOrBlank()) return null
            return runCatching {
                val uri = Uri.parse(raw.trim())
                val host = uri.host?.lowercase(Locale.ROOT).orEmpty().removePrefix("www.").removePrefix("m.")
                val id = when {
                    host == "youtu.be" -> uri.pathSegments.firstOrNull()
                    host == "youtube.com" || host.endsWith(".youtube.com") -> when {
                        uri.path == "/watch" -> uri.getQueryParameter("v")
                        uri.pathSegments.firstOrNull() == "shorts" -> uri.pathSegments.getOrNull(1)
                        uri.pathSegments.firstOrNull() == "live" -> uri.pathSegments.getOrNull(1)
                        uri.pathSegments.firstOrNull() == "embed" -> uri.pathSegments.getOrNull(1)
                        else -> null
                    }
                    else -> null
                }
                id?.takeIf { it.length in 6..20 && it.all { char -> char in 'A'..'Z' || char in 'a'..'z' || char in '0'..'9' || char == '_' || char == '-' } }
            }.getOrNull()
        }
    }
}
