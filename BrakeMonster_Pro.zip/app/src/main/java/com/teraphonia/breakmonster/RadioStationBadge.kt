package com.teraphonia.breakmonster

import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource

/** Badge shared by BMR favorites, QUEUE entries, and future COUNTRY station results. */
@Composable
internal fun RadioStationBadge(modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.radio_1950s),
        contentDescription = "Radio station",
        modifier = modifier,
        contentScale = ContentScale.Fit
    )
}

/** Explicit source identity only: never classify normal tracks by their title. */
internal fun BreakPlaylistEntry.isRadioStation(): Boolean {
    val type = sourceKind.uppercase(java.util.Locale.ROOT)
    return type == "BMR" || type == "RADIO" || type.startsWith("BMR_") ||
        type.startsWith("RADIO_") || uri.startsWith("bmr:", ignoreCase = true)
}
