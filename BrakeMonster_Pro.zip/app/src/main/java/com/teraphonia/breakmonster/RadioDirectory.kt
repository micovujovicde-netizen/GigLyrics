package com.teraphonia.breakmonster

import android.content.Context
import android.net.Uri
import android.os.SystemClock
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.zIndex
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.abs

internal data class RadioStation(
    val stationUuid: String,
    val name: String,
    val url: String,
    val countryCode: String = ""
)

internal fun isRadioHttpUrl(url: String): Boolean =
    (Uri.parse(url).scheme.equals("http", true) || Uri.parse(url).scheme.equals("https", true)) &&
        !url.startsWith("https://www.youtube.com/watch?v=", ignoreCase = true)

/** Radio Browser is a directory, not an audio proxy. Read it off the UI thread. */
internal object RadioDirectory {
    private val mirrors = listOf(
        "https://de1.api.radio-browser.info",
        "https://at1.api.radio-browser.info",
        "https://nl1.api.radio-browser.info"
    )
    data class Country(val name: String, val code: String)
    val countries: List<Country> by lazy {
        Locale.getISOCountries().map { code ->
            Country(Locale("", code).getDisplayCountry(Locale.ENGLISH), code)
        }.filter { it.name.isNotBlank() }.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })
    }
    suspend fun stations(code: String, offset: Int, limit: Int = 80): List<RadioStation> = withContext(Dispatchers.IO) {
        require(code.matches(Regex("[A-Z]{2}")))
        var failure: Throwable? = null
        for (server in mirrors) {
            try {
                val uri = "$server/json/stations/bycountrycodeexact/$code?hidebroken=true&order=votes&reverse=true&limit=$limit&offset=$offset"
                val connection = URL(uri).openConnection() as HttpURLConnection
                connection.connectTimeout = 8_000
                connection.readTimeout = 12_000
                connection.setRequestProperty("User-Agent", "BrakeMonsterPRO/266 (Radio Browser client)")
                connection.setRequestProperty("Accept", "application/json")
                try {
                    if (connection.responseCode !in 200..299) error("Radio directory HTTP ${connection.responseCode}")
                    val data = connection.inputStream.bufferedReader().use { it.readText() }
                    val rows = JSONArray(data)
                    return@withContext (0 until rows.length()).mapNotNull { i ->
                        val row = rows.optJSONObject(i) ?: return@mapNotNull null
                        val name = row.optString("name").trim().take(120)
                        val url = row.optString("url_resolved").takeIf { isRadioHttpUrl(it) }
                            ?: row.optString("url").takeIf { isRadioHttpUrl(it) }
                        val playlistOnly = url?.substringBefore('?')?.lowercase(Locale.ROOT)?.let {
                            it.endsWith(".pls") || it.endsWith(".m3u") || it.endsWith(".asx") || it.endsWith(".xspf")
                        } ?: false
                        if (name.isBlank() || url == null || playlistOnly || row.optInt("lastcheckok", 1) == 0) null
                        else RadioStation(row.optString("stationuuid"), name, url, code)
                    }.distinctBy { it.url }
                } finally { connection.disconnect() }
            } catch (cancelled: CancellationException) { throw cancelled }
            catch (e: Exception) { failure = e }
        }
        throw IllegalStateException(failure?.message ?: "Radio directory unavailable")
    }
}

/** Persistence only for starred stations. Queue radio entries remain RAM-only. */
internal class RadioFavoritesStore private constructor(context: Context) {
    companion object {
        @Volatile private var instance: RadioFavoritesStore? = null
        fun shared(context: Context): RadioFavoritesStore = instance ?: synchronized(this) {
            instance ?: RadioFavoritesStore(context.applicationContext).also { instance = it }
        }
    }
    private val prefs = context.getSharedPreferences("brakemonster_bmr_favorites", Context.MODE_PRIVATE)
    val entries = mutableStateListOf<RadioStation>()
    init {
        runCatching { decode(JSONArray(prefs.getString("favorites_v1", "[]"))) }
            .getOrDefault(emptyList()).let { entries.addAll(it) }
    }
    private fun decode(array: JSONArray): List<RadioStation> =
        (0 until array.length()).mapNotNull { i ->
            val x = array.optJSONObject(i) ?: return@mapNotNull null
            val uri = x.optString("url")
            if (!isRadioHttpUrl(uri)) null else RadioStation(
                x.optString("stationuuid"), x.optString("name").take(120),
                uri, x.optString("countrycode"))
        }.distinctBy { it.url }
    fun contains(url: String): Boolean = entries.any { it.url == url }
    fun add(station: RadioStation) {
        if (!isRadioHttpUrl(station.url) || contains(station.url)) return
        entries.add(station)
        persist()
    }
    fun remove(url: String) {
        entries.removeAll { it.url == url }
        persist()
    }
    /** Move one saved station before/after another; their stable URLs identify the rows.
     * Use apply() during dragging so persistence never blocks the main/UI thread.
     */
    fun moveRelative(url: String, anchorUrl: String, after: Boolean): Boolean {
        val originalIndex = entries.indexOfFirst { it.url == url }
        val anchorIndex = entries.indexOfFirst { it.url == anchorUrl }
        if (originalIndex < 0 || anchorIndex < 0 || url == anchorUrl) return false
        val newIndex = if (after) {
            if (anchorIndex < originalIndex) anchorIndex + 1 else anchorIndex
        } else {
            if (anchorIndex < originalIndex) anchorIndex else anchorIndex - 1
        }
        if (newIndex == originalIndex) return false
        val station = entries.removeAt(originalIndex)
        entries.add(newIndex, station)
        prefs.edit().putString("favorites_v1", toJson().toString()).apply()
        return true
    }
    fun toJson(): JSONArray = JSONArray().apply { entries.forEach { station ->
        put(JSONObject().put("stationuuid", station.stationUuid).put("name", station.name)
            .put("url", station.url).put("countrycode", station.countryCode))
    } }
    fun restore(array: JSONArray) { val restored = decode(array); entries.clear(); entries.addAll(restored); persist() }
    private fun persist() { check(prefs.edit().putString("favorites_v1", toJson().toString()).commit()) }
}

/** Country pins are ordered by selection time, independently of station favorites. */
internal class RadioCountryPinsStore private constructor(context: Context) {
    companion object {
        @Volatile private var instance: RadioCountryPinsStore? = null
        fun shared(context: Context): RadioCountryPinsStore = instance ?: synchronized(this) {
            instance ?: RadioCountryPinsStore(context.applicationContext).also { instance = it }
        }
    }
    private val prefs = context.getSharedPreferences("brakemonster_radio_countries", Context.MODE_PRIVATE)
    val codes = mutableStateListOf<String>()
    private fun decode(array: JSONArray): List<String> {
        val valid = RadioDirectory.countries.map { it.code }.toSet()
        return (0 until array.length()).map { array.optString(it) }
            .filter { it in valid }.distinct()
    }
    init {
        codes.addAll(runCatching { decode(JSONArray(prefs.getString("pins_v1", "[]"))) }
            .getOrDefault(emptyList()))
    }
    fun contains(code: String): Boolean = code in codes
    fun toggle(code: String) {
        if (RadioDirectory.countries.none { it.code == code }) return
        if (!codes.remove(code)) codes.add(code)
        // apply updates preferences immediately and writes to disk off the UI thread.
        prefs.edit().putString("pins_v1", toJson().toString()).apply()
    }
    fun orderedCountries(): List<RadioDirectory.Country> {
        val byCode = RadioDirectory.countries.associateBy { it.code }
        return codes.mapNotNull { byCode[it] } + RadioDirectory.countries.filterNot { it.code in codes }
    }
    fun toJson(): JSONArray = JSONArray(codes.toList())
    fun restore(array: JSONArray) {
        val restored = decode(array)
        codes.clear(); codes.addAll(restored)
        prefs.edit().putString("pins_v1", toJson().toString()).apply()
    }
}

/** One screen: COUNTRY -> popup station list, plus durable Favorites only. */
@Composable
internal fun RadioHub(onClose: () -> Unit, onPlay: (RadioStation) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val favorites = remember(context) { RadioFavoritesStore.shared(context) }
    val countryPins = remember(context) { RadioCountryPinsStore.shared(context) }
    val countryListState = rememberLazyListState()
    val favoritesListState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var draggingFavoriteUrl by remember { mutableStateOf<String?>(null) }
    var draggingFavoriteOffsetY by remember { mutableFloatStateOf(0f) }
    var lastFavoritesAutoScrollAt by remember { mutableLongStateOf(0L) }
    var view by remember { mutableStateOf("favorites") } // favorites / countries / stations
    var selected by remember { mutableStateOf<RadioDirectory.Country?>(null) }
    var page by remember { mutableIntStateOf(0) }
    var stationList by remember { mutableStateOf<List<RadioStation>>(emptyList()) }
    var hasMore by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var failure by remember { mutableStateOf<String?>(null) }
    var pendingRemoval by remember { mutableStateOf<RadioStation?>(null) }
    val gold = Color(0xFFFFBE46)
    val bg = Color(0xFF151915)
    LaunchedEffect(selected, page) {
        val country = selected ?: return@LaunchedEffect
        loading = true; failure = null
        try {
            val chunk = RadioDirectory.stations(country.code, page * 80)
            stationList = if (page == 0) chunk else (stationList + chunk).distinctBy { it.url }
            hasMore = chunk.size >= 80
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { failure = "Could not load stations. ${e.message.orEmpty()}" }
        finally { loading = false }
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxWidth(.96f).fillMaxHeight(.9f)
            .background(bg, RoundedCornerShape(16.dp)).border(2.dp, gold, RoundedCornerShape(16.dp))
            .padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioStationBadge(Modifier.size(42.dp))
                    Text(" RADIO", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                }
                TextButton(onClick = onClose) { Text("CLOSE", color = gold, fontSize = 19.sp) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { view = "countries" }, modifier = Modifier.weight(1f).height(54.dp)) {
                    Text("COUNTRY", fontSize = 18.sp, fontWeight = FontWeight.Black)
                }
                OutlinedButton(onClick = { view = "favorites" }, modifier = Modifier.weight(1f).height(54.dp)) {
                    Text("★ FAVORITES", color = gold, fontSize = 18.sp, fontWeight = FontWeight.Black)
                }
            }
            when (view) {
                "countries" -> {
                    Text("CHOOSE COUNTRY · WORLD RADIO", color = gold, fontSize = 18.sp)
                    LazyColumn(Modifier.weight(1f), state = countryListState) {
                        items(countryPins.orderedCountries(), key = { it.code }) { country ->
                            val pinned = countryPins.contains(country.code)
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(country.name.uppercase(Locale.ENGLISH), color = Color.White, fontSize = 20.sp,
                                    modifier = Modifier.weight(1f).clickable {
                                        selected = country; page = 0; stationList = emptyList(); hasMore = false; view = "stations"
                                    }.padding(vertical = 14.dp, horizontal = 8.dp))
                                IconToggleButton(checked = pinned, onCheckedChange = {
                                    countryPins.toggle(country.code)
                                    // Show the ordered pins immediately; a star never opens stations.
                                    scope.launch { countryListState.scrollToItem(0) }
                                }, modifier = Modifier.size(56.dp).semantics {
                                    contentDescription = if (pinned) "Unpin ${country.name}" else "Pin ${country.name} to top"
                                }) {
                                    Text(if (pinned) "★" else "☆", color = if (pinned) gold else Color.White,
                                        fontSize = 32.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            HorizontalDivider(color = Color.White.copy(alpha = .16f))
                        }
                    }
                }
                "stations" -> {
                    Text("${selected?.name?.uppercase(Locale.ENGLISH).orEmpty()} · RADIO STATIONS", color = gold, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    if (failure != null) Text(failure.orEmpty(), color = Color(0xFFFF9191), fontSize = 17.sp)
                    if (loading && stationList.isEmpty()) LinearProgressIndicator(Modifier.fillMaxWidth())
                    if (!loading && failure == null && stationList.isEmpty()) Text("NO STATIONS FOUND", color = Color.White, fontSize = 18.sp)
                    LazyColumn(Modifier.weight(1f)) {
                        items(stationList, key = { it.url }) { station ->
                            Row(Modifier.fillMaxWidth().clickable { onPlay(station); onClose() }
                                .padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                RadioStationBadge(Modifier.size(36.dp))
                                Spacer(Modifier.width(9.dp))
                                Text(station.name, color = Color.White, fontSize = 19.sp,
                                    modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                                if (favorites.contains(station.url)) Text("★", color = gold, fontSize = 23.sp)
                            }
                            HorizontalDivider(color = Color.White.copy(alpha = .16f))
                        }
                        item {
                            if (hasMore && stationList.isNotEmpty() && !loading && failure == null) {
                                TextButton(onClick = { page++ }, modifier = Modifier.fillMaxWidth()) {
                                    Text("MORE STATIONS", color = gold, fontSize = 20.sp)
                                }
                            }
                        }
                    }
                }
                else -> {
                    Text("★ SAVED RADIO STATIONS", color = gold, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    if (favorites.entries.isEmpty()) Text("No favorites yet. COUNTRY → choose a station, then tap ★ in QUEUE.",
                        color = Color.White, fontSize = 18.sp)
                    LazyColumn(Modifier.weight(1f), state = favoritesListState) {
                        items(favorites.entries, key = { it.url }) { station ->
                            val isDragging = draggingFavoriteUrl == station.url
                            Row(
                                Modifier.fillMaxWidth()
                                    .graphicsLayer { translationY = if (isDragging) draggingFavoriteOffsetY else 0f }
                                    .zIndex(if (isDragging) 1f else 0f)
                                    .background(if (isDragging) gold.copy(alpha = .23f) else Color.Transparent)
                                    .pointerInput(station.url) {
                                        var lastTarget: String? = null
                                        detectDragGesturesAfterLongPress(
                                            onDragStart = {
                                                draggingFavoriteUrl = station.url
                                                draggingFavoriteOffsetY = 0f
                                                lastTarget = null
                                            },
                                            onDrag = { change, amount ->
                                                change.consume()
                                                draggingFavoriteOffsetY += amount.y
                                                val layout = favoritesListState.layoutInfo
                                                val active = layout.visibleItemsInfo.firstOrNull { it.key == station.url }
                                                if (active != null) {
                                                    val center = active.offset + draggingFavoriteOffsetY + active.size / 2f
                                                    val target = layout.visibleItemsInfo
                                                        .filter { it.key is String && it.key != station.url }
                                                        .minByOrNull { abs(center - (it.offset + it.size / 2f)) }
                                                    val targetUrl = target?.key as? String
                                                    if (target != null && targetUrl != null) {
                                                        val movingUp = target.index < active.index
                                                        val crossed = if (movingUp) center < target.offset + target.size / 2f
                                                            else center > target.offset + target.size / 2f
                                                        if (crossed && targetUrl != lastTarget &&
                                                            favorites.moveRelative(station.url, targetUrl, after = !movingUp)
                                                        ) {
                                                            draggingFavoriteOffsetY += if (movingUp) target.size.toFloat() else -target.size.toFloat()
                                                            lastTarget = targetUrl
                                                        }
                                                    }
                                                    val edge = 56.dp.toPx()
                                                    val now = SystemClock.elapsedRealtime()
                                                    if (now - lastFavoritesAutoScrollAt > 70L &&
                                                        center < layout.viewportStartOffset + edge
                                                    ) {
                                                        lastFavoritesAutoScrollAt = now
                                                        scope.launch { favoritesListState.scrollBy(-24f) }
                                                    } else if (now - lastFavoritesAutoScrollAt > 70L &&
                                                        center > layout.viewportEndOffset - edge
                                                    ) {
                                                        lastFavoritesAutoScrollAt = now
                                                        scope.launch { favoritesListState.scrollBy(24f) }
                                                    }
                                                }
                                            },
                                            onDragEnd = {
                                                draggingFavoriteUrl = null
                                                draggingFavoriteOffsetY = 0f
                                            },
                                            onDragCancel = {
                                                draggingFavoriteUrl = null
                                                draggingFavoriteOffsetY = 0f
                                            }
                                        )
                                    }
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioStationBadge(Modifier.size(34.dp))
                                Text(station.name, color = Color.White, fontSize = 19.sp,
                                    modifier = Modifier.weight(1f).clickable { onPlay(station); onClose() }.padding(8.dp),
                                    maxLines = 2, overflow = TextOverflow.Ellipsis)
                                TextButton(onClick = { pendingRemoval = station }) { Text("★", color = gold, fontSize = 27.sp) }
                            }
                            HorizontalDivider(color = Color.White.copy(alpha = .16f))
                        }
                    }
                }
            }
            if (loading && stationList.isNotEmpty()) LinearProgressIndicator(Modifier.fillMaxWidth())
        }
    }
    pendingRemoval?.let { station ->
        AlertDialog(onDismissRequest = { pendingRemoval = null },
            title = { Text("ARE YOU SURE?") },
            text = { Text("Remove ${station.name} from RADIO favorites? Playing radio will continue.") },
            confirmButton = { TextButton(onClick = { favorites.remove(station.url); pendingRemoval = null }) { Text("REMOVE", color = Color.Red) } },
            dismissButton = { TextButton(onClick = { pendingRemoval = null }) { Text("CANCEL") } })
    }
}
