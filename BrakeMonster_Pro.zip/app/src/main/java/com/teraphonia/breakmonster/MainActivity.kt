package com.teraphonia.breakmonster

import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import android.graphics.Movie
import android.os.SystemClock
import android.app.Activity
import android.content.ContentValues
import android.os.Environment
import android.util.Base64
import android.os.Build
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.MutableContextWrapper
import android.graphics.Color as AndroidColor
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.AudioAttributes
import android.net.Uri
import android.provider.MediaStore
import android.os.Bundle
import android.speech.RecognizerIntent
import android.content.pm.PackageManager
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import org.json.JSONArray
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.IntentSenderRequest
import androidx.activity.viewModels
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.LinearEasing
import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.zIndex
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.TextUnit
import androidx.core.content.ContextCompat
import androidx.compose.ui.viewinterop.AndroidView
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.suspendCoroutine
import kotlin.coroutines.resume
import java.net.URLEncoder
import java.util.Locale
import kotlin.math.roundToInt

private val DeepGreen = Color(0xFF001B10)
private val PanelGreen = Color(0xE5142E21)
private val Amber = Color(0xFFFFB52E)
private val MonsterGreen = Color(0xFF86F500)
private val MutedGreen = Color(0xFF294535)
private val BrowserEndInset = 12.dp
private val SongControlWidth = 36.dp
private const val MIN_SONG_TEXT_SIZE = 10f
private const val MAIN_PLAYLISTS_WIDTH_MULTIPLIER = 2f
private const val MAIN_PLAYLISTS_HEIGHT_MULTIPLIER = 1f
private const val BUY_MONSTER_URL = "https://teraphonia.com/buy.html"
private const val PLAYLIST_WEB_URL = "https://playlist-cloud.micovujovic-de.workers.dev"

private data class GlobalSearchHit(
    val title: String,
    val location: String,
    val uri: String,
    val kind: String,
    val item: BreakItem? = null,
    val playlistIndex: Int = -1,
    val playlistItems: List<BreakItem> = emptyList(),
    val selectedIndex: Int = -1
)

/** Lives with the browser, so local/queue navigation cannot dispose XL state. */
private class XlPlaylistUiState(
    val mode: MutableState<Boolean>,
    val chooserVisible: MutableState<Boolean>,
    val returningFromSearch: MutableState<Boolean>,
    val webSearchUrl: MutableState<String?>,
    val listState: LazyListState
)

/** XL inputs share the normal view's queries, handlers and single blink clock. */
private data class XlSearchControls(
    val webTextSize: MutableFloatState,
    val queueSelectionMode: Boolean,
    val blinkAlpha: State<Float>,
    val webEnabled: Boolean,
    val webQuery: String,
    val onWebQuery: (String) -> Unit,
    val onAllowWebSearch: () -> Boolean,
    val onWebSelected: (String, String?, String) -> Unit,
    val localQuery: String,
    val onLocalQuery: (String) -> Unit,
    val onLocalSearch: () -> Unit
)

class MainActivity : ComponentActivity() {
    private val model by viewModels<BreakMonsterModel>()
    internal lateinit var commerce: CommercialRelease
        private set
    private var showReturnLogo by mutableStateOf(false)
    private var returnLogoPending = false
    private var cloudLinkSerial = 0L
    var pendingCloudLink by mutableStateOf<Pair<Long, Uri>?>(null)
        private set

    private fun readCloudLink(intent: Intent?) {
        if (intent?.action == Intent.ACTION_VIEW) intent.data?.let(::receiveCloudPlaylistLink)
    }
    // The dedicated, in-app playlist browser uses the SAME validated cloud
    // transfer pipeline as ACTION_VIEW; no external Chrome round-trip needed.
    fun receiveCloudPlaylistLink(uri: Uri) {
        if (uri.scheme.equals("brakemonster", true) && uri.host.equals("save-playlist", true)) {
            cloudLinkSerial++
            pendingCloudLink = cloudLinkSerial to uri
        }
    }
    fun dismissCloudLink(serial: Long) {
        if (pendingCloudLink?.first == serial) pendingCloudLink = null
    }
    private var introPlayer: MediaPlayer? = null
    var introFinished by mutableStateOf(true); private set
    var introStartupChecked by mutableStateOf(false); private set
    // Keep document import state independent from playback and Activity lifecycle.
    private var playlistPickerOpen = false
    fun setPlaylistPickerOpen(open: Boolean) { playlistPickerOpen = open }
    private fun startFirstRunIntro() {
        if (introStartupChecked) return
        introStartupChecked = true
        val prefs = getSharedPreferences("teraphonia_startup", MODE_PRIVATE)
        if (prefs.getBoolean("welcome_started_v1", false) || prefs.getBoolean("first_jingle_completed_v1", false)) {
            introFinished = true
            return
        }
        runCatching {
            introFinished = false
            val player = MediaPlayer.create(this, R.raw.monster_intro) ?: return
            introPlayer = player
            player.setOnCompletionListener {
                runCatching { it.release() }; introPlayer = null
                getSharedPreferences("teraphonia_startup", MODE_PRIVATE).edit()
                    .putBoolean("first_jingle_completed_v1", true).commit()
                introFinished = true
            }
            // An error is not completion: keep the onboarding gate closed.
            player.setOnErrorListener { _, _, _ -> true }
            player.start()
        }.onFailure { introFinished = false }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        BlackBox.initialize(applicationContext)
        val priorHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            BlackBox.recordCrash(thread, throwable)
            priorHandler?.uncaughtException(thread, throwable)
        }
        super.onCreate(savedInstanceState)
        AppLanguage.initialize(this)
        readCloudLink(intent)
        startFirstRunIntro()
        commerce = CommercialRelease(this) {
            val state = BreakPlaybackService.snapshot
            state.playing || state.preparing || state.crossfading || state.transitionRequested || model.localPlaying || !introFinished
        }
        commerce.start()
        // PRO allows screen timeout/lock while its foreground media service plays.
        window.statusBarColor = AndroidColor.rgb(0, 27, 16)
        window.navigationBarColor = AndroidColor.rgb(0, 27, 16)
        // Wait for the user to select a HOME folder before startup audio.
        setContent {
            // Preserve the tablet composition 1:1 on portrait phones.  The old
            // phone-only 4/3 sizing and fixed DP controls overflowed narrow
            // screens; changing density here lets Compose *measure* against a
            // tablet-width viewport, so clipping, scrolling and taps all agree.
            // Tablets and landscape layouts keep their original device density.
            val config = LocalConfiguration.current
            val naturalDensity = LocalDensity.current
            val tabletCanvasWidthDp = 800f
            val phonePortrait = config.screenWidthDp < 600 &&
                config.orientation == android.content.res.Configuration.ORIENTATION_PORTRAIT
            val tabletScale = if (phonePortrait) {
                (config.screenWidthDp.toFloat() / tabletCanvasWidthDp).coerceIn(0.35f, 1f)
            } else 1f
            val canvasDensity = remember(naturalDensity.density, naturalDensity.fontScale, tabletScale) {
                Density(naturalDensity.density * tabletScale, naturalDensity.fontScale)
            }
            // v175: the top clearance is measured with the REAL device density,
            // before the phone-specific 800dp virtual tablet density is applied.
            // Clip the app canvas so its stage art (which is offset -54dp)
            // cannot paint back into the required empty 20dp black strip.
            Box(Modifier.fillMaxSize().background(Color.Black)) {
                Box(Modifier.fillMaxSize().padding(top = 20.dp).clipToBounds()) {
                    CompositionLocalProvider(LocalDensity provides canvasDensity) {
                        BreakMonsterTheme {
                            BreakMonsterApp(model = model, pipMode = false, showReturnLogo = showReturnLogo, moveTaskToBack = { moveTaskToBack(true) })
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readCloudLink(intent)
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) returnLogoPending = true
    }

    override fun onResume() {
        super.onResume()
        if (::commerce.isInitialized) commerce.onReturnToApp()
        if (returnLogoPending) {
            returnLogoPending = false
            showReturnLogo = true
            android.os.Handler(mainLooper).postDelayed({ showReturnLogo = false }, 650L)
        }
    }

    override fun onDestroy() { if(::commerce.isInitialized) commerce.close(); super.onDestroy() }


}

@Composable
private fun BreakMonsterTheme(content: @Composable () -> Unit) {
    val colors = darkColorScheme(
        primary = Amber,
        secondary = MonsterGreen,
        background = DeepGreen,
        surface = DeepGreen,
        onPrimary = Color.Black,
        onSecondary = Color.Black,
        onBackground = Color.White,
        onSurface = Color.White
    )
    MaterialTheme(colorScheme = colors, content = content)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BreakMonsterApp(
    model: BreakMonsterModel,
    pipMode: Boolean,
    showReturnLogo: Boolean,
    moveTaskToBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? MainActivity
    val proEnabled = activity?.commerce?.active == true
    fun proOrBuy(feature: String, action: () -> Unit) {
        if (activity?.commerce?.active == true) action()
        else activity?.commerce?.requirePro(feature)
    }
    // Preserve the exact v176 tablet-header geometry, but without the edit controls.
    val isTablet = LocalConfiguration.current.smallestScreenWidthDp >= 600
    val configuration = LocalConfiguration.current
    val phonePortraitLayout = !isTablet && configuration.screenWidthDp < 600 &&
        configuration.orientation == android.content.res.Configuration.ORIENTATION_PORTRAIT
    val phoneControlDensity = Density(context.resources.displayMetrics.density * 0.85f,
        context.resources.configuration.fontScale)
    var showYoutubeSearchInput by remember { mutableStateOf(false) }
    var youtubeQuery by remember { mutableStateOf("") }
    var localQuery by remember { mutableStateOf("") }
    var globalSearchHits by remember { mutableStateOf<List<GlobalSearchHit>>(emptyList()) }
    var showGlobalSearchResults by remember { mutableStateOf(false) }
    var globalSearchJob by remember { mutableStateOf<Job?>(null) }
    var globalSearchBusy by remember { mutableStateOf(false) }
    val globalSearchScope = rememberCoroutineScope()
    LaunchedEffect(localQuery) {
        globalSearchJob?.cancel()
        globalSearchJob = null
        globalSearchBusy = false
    }
    var speechTarget by remember { mutableStateOf("local") }
    var youtubeSearchUrl by remember { mutableStateOf<String?>(null) }
    // Independent internal browser: only the SEARCH PLAYLISTS stone opens it.
    // Existing WEB SEARCH / YouTube panel remains unchanged.
    var playlistCloudBrowserOpen by remember { mutableStateOf(false) }
    var playlistCloudWebView by remember { mutableStateOf<WebView?>(null) }
    var imeNumere by remember { mutableStateOf("") }
    // PRO mixer controls are applied to the foreground audio service.
    val mixerPrefs = remember(context) { context.getSharedPreferences("brakemonster_pro_mixer", Context.MODE_PRIVATE) }
    var mixerOpen by remember { mutableStateOf(false) }
    val blackBoxExporter = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null) {
            val saved = runCatching {
                val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
                val version = "${packageInfo.versionName} (${if (Build.VERSION.SDK_INT >= 28) packageInfo.longVersionCode else packageInfo.versionCode.toLong()})"
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { writer ->
                    writer.write(BlackBox.exportAudioReport(version))
                } ?: error("Could not open log destination")
            }
            uiToast(context,
                if (saved.isSuccess) "BLACK BOX LOG SAVED" else "BLACK BOX SAVE FAILED: ${saved.exceptionOrNull()?.message}",
                Toast.LENGTH_LONG).show()
        }
    }
    var crossfaderPosition by remember { mutableFloatStateOf(mixerPrefs.getFloat("crossfader", -1f).coerceIn(-1f, 1f)) }
    var manualFaderDragging by remember { mutableStateOf(false) }
    // Prevent a held finger at B from restarting the NEXT mix after a completed A->B swap.
    var manualFaderAwaitingRelease by remember { mutableStateOf(false) }
    var lastManualMixCompletion by remember { mutableLongStateOf(BreakPlaybackService.snapshot.manualMixCompletions) }
    var autoMixEnabled by remember { mutableStateOf(true) }
    var crossfadeSeconds by remember { mutableIntStateOf(mixerPrefs.getInt("duration_seconds", 2).coerceIn(1, 12)) }
    var mixerSnapshot by remember { mutableStateOf(BreakPlaybackService.snapshot) }
    LaunchedEffect(Unit) {
        BreakPlaybackService.setMixer(crossfaderPosition, proEnabled && autoMixEnabled, crossfadeSeconds)
        while (true) {
            mixerSnapshot = BreakPlaybackService.snapshot
            delay(200)
        }
    }
    LaunchedEffect(proEnabled) {
        if (!proEnabled) {
            mixerOpen = false
            playlistCloudBrowserOpen = false
            youtubeSearchUrl = null
            showYoutubeSearchInput = false
            BreakPlaybackService.releaseRollEffect()
            BreakPlaybackService.releaseLiveFx()
        }
        BreakPlaybackService.setMixer(-1f, proEnabled && autoMixEnabled, crossfadeSeconds)
    }
    LaunchedEffect(mixerSnapshot.crossfader, mixerSnapshot.sessionActive) {
        if (!manualFaderDragging && mixerSnapshot.sessionActive && mixerSnapshot.crossfader != crossfaderPosition) {
            crossfaderPosition = mixerSnapshot.crossfader
            mixerPrefs.edit().putFloat("crossfader", crossfaderPosition).apply()
        }
    }
    // The audio service confirms the handover BEFORE the UI snaps B straight back
    // to A. This must work even while the old slider gesture is still held.
    LaunchedEffect(mixerSnapshot.manualMixCompletions) {
        val completed = mixerSnapshot.manualMixCompletions
        if (completed != lastManualMixCompletion) {
            lastManualMixCompletion = completed
            if (completed > 0L) {
                manualFaderAwaitingRelease = manualFaderDragging
                crossfaderPosition = -1f
                mixerPrefs.edit().putFloat("crossfader", -1f).apply()
            }
        }
    }
    var videoExpanded by remember { mutableStateOf(false) }
    LaunchedEffect(model.youtubeSession) { videoExpanded = false }
    // The 11-second intro must finish naturally; playback is sequenced below.
    var selectedForMenu by remember { mutableStateOf<BreakItem?>(null) }
    var renameMode by remember { mutableStateOf(false) }
    var renameText by remember { mutableStateOf("") }
    var deleteFileConfirm by remember { mutableStateOf(false) }
    val transitionClick = remember { TransitionMetronome(context) }
    // Seeking is a separate, explicitly requested exception to the last-five-seconds rule.
    var seekTargetSecond by remember { mutableStateOf<Float?>(null) }
    var seekInProgress by remember { mutableStateOf(false) }
    LaunchedEffect(seekTargetSecond) {
        if (seekTargetSecond != null) {
            kotlinx.coroutines.delay(6000L) // fail-safe for unavailable YouTube progress callbacks
            seekTargetSecond = null
            seekInProgress = false
            transitionClick.stop()
        }
    }
    DisposableEffect(Unit) { onDispose { transitionClick.stop() } }
    LaunchedEffect(model.localTrackUri, model.youtubeSession) { transitionClick.stop() }
    val playlists = remember { BreakPlaylistStore.shared(context) }
    // Import the packaged decade playlists once, asynchronously. No audio,
    // QUEUE, or existing playlist is replaced by this first-install import.
    LaunchedEffect(playlists) { playlists.seedBundledDecadePlaylists() }
    SideEffect {
        playlists.onPlaylistDeleted = { deletedContext -> model.finishDeletedPlaylist(deletedContext) }
        playlists.onPlaylistChanged = { changedIndex ->
            if (changedIndex == playlists.queueIndex) {
                // Ignore the factory WELCOME SONG: the first actual user choice
                // is prepared immediately, even while another playlist is playing.
                val firstSelected = playlists.lists[playlists.queueIndex].firstOrNull {
                    !it.missing && it.sourceKind != "BUNDLED_WELCOME" &&
                        !it.name.equals("BRAKE MONSTER WELCOME SONG", ignoreCase = true)
                }
                BreakPlaybackService.prebufferFirstQueued(context,
                    firstSelected?.let { BreakPlaybackService.Entry(it.uri, it.name) })
            }
            model.refreshActivePlaylist(playlists.playbackContext(changedIndex), playlists.resolve(changedIndex))
        }
    }
    // A QUEUE addition changes NEXT only when QUEUE owns playback.
    SideEffect {
        playlists.onPlaylistEntryAdded = { index ->
            val activeQueue = index == playlists.queueIndex &&
                model.activePlaybackPlaylistContext == playlists.playbackContext(index)
            if (activeQueue || index == playlists.webSavesIndex) {
                playlists.lists.getOrNull(index)?.lastOrNull()?.let { entry ->
                    if (!entry.missing) BreakPlaybackService.insertAfterPlaying(
                        BreakPlaybackService.Entry(entry.uri, entry.name))
                }
            }
        }
    }

    var pendingMediaDelete by remember { mutableStateOf<BreakItem?>(null) }
    val mediaDeleteLauncher=rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        val item=pendingMediaDelete
        if(result.resultCode==Activity.RESULT_OK && item!=null) { model.onMediaStoreDeleteApproved(item);playlists.removeMedia(item.file.uri.toString()) }
        pendingMediaDelete=null
    }
    var pendingMediaRename by remember { mutableStateOf<Pair<BreakItem,String>?>(null) }
    val mediaWriteLauncher=rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        val pending=pendingMediaRename
        if(result.resultCode==Activity.RESULT_OK && pending!=null) {
            model.rename(pending.first,pending.second);playlists.renameMedia(pending.first.file.uri.toString(),pending.second)
        }
        pendingMediaRename=null
    }
    fun renameConfirmed(item:BreakItem,name:String) {
        if(android.os.Build.VERSION.SDK_INT>=30 && item.file.uri.authority=="media") {
            runCatching {
                pendingMediaRename=item to name
                val request=MediaStore.createWriteRequest(context.contentResolver,listOf(item.file.uri))
                mediaWriteLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
            }.onFailure { pendingMediaRename=null;uiToast(context,"Android could not authorize this rename.",Toast.LENGTH_LONG).show() }
        } else { model.rename(item,name);playlists.renameMedia(item.file.uri.toString(),name) }
    }
    fun deleteConfirmed(item:BreakItem) {
        if(android.os.Build.VERSION.SDK_INT>=30 && item.file.uri.authority=="media") {
            runCatching {
                pendingMediaDelete=item
                val request=MediaStore.createDeleteRequest(context.contentResolver,listOf(item.file.uri))
                mediaDeleteLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
            }.onFailure { pendingMediaDelete=null;uiToast(context,"Android could not authorize this deletion.",Toast.LENGTH_LONG).show() }
        } else model.delete(item){playlists.removeMedia(item.file.uri.toString())}
    }
    var playlistVisible by remember { mutableStateOf(true) }
    var playlistTab by remember { mutableIntStateOf(playlists.queueIndex) }
    var lastUserPlaylistTab by remember { mutableIntStateOf(playlists.activeIndex.takeUnless { it==playlists.queueIndex } ?: 0) }
    var welcomeLaunchRequested by remember { mutableStateOf(false) }
    var queueSelectionMode by remember {
        mutableStateOf(!context.getSharedPreferences("teraphonia_startup", Context.MODE_PRIVATE)
            .getBoolean("first_run_complete_v1", false))
    }
    // One synchronized blink clock for ADD TO QUEUE and all browsing affordances.
    // Share the same State across all surfaces so no separate animation drifts.
    val queueBlinkAlpha: State<Float> = if (queueSelectionMode) {
        rememberInfiniteTransition(label = "queue_browsing_shared_blink").animateFloat(
            initialValue = .18f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(500), RepeatMode.Reverse),
            label = "queue_browsing_shared_alpha"
        )
    } else {
        // Removing the transition stops its clock; every consumer gets full opacity.
        remember { mutableFloatStateOf(1f) }
    }
    // Hoist these once: LOCAL SEARCH and the browser must read the same live state.
    // The existing preference keys preserve all previously saved sizes.
    val queueSongTextSize = rememberSongTextSize("queue", 23f)
    val playlistSongTextSize = rememberSongTextSize("playlists", 23f)
    val localSongTextSize = rememberSongTextSize("local", 26f)
    val webTextSize = rememberSongTextSize("web", 20f)
    var playbackBarHeightPx by remember { mutableIntStateOf(0) }
    val playbackCanvasDensity = LocalDensity.current
    val startupGuidePrefs = remember { context.getSharedPreferences("teraphonia_startup", Context.MODE_PRIVATE) }
    val welcomeGuidePending = remember { startupGuidePrefs.getBoolean("welcome_guide_pending", false) }
    var showQueueExplanation by remember { mutableStateOf(welcomeGuidePending) }
    var queueExplanationForWelcome by remember { mutableStateOf(welcomeGuidePending) }
    var showBackupMenu by rememberSaveable { mutableStateOf(false) }
    val backupBusy = remember { mutableStateOf(false) }
    var loadingPlaylists by remember { mutableStateOf(emptySet<String>()) }
    var zipImportBusy by remember { mutableStateOf(false) }
    var welcomeQueueExplanationShown by remember { mutableStateOf(false) }
    val prefs = remember { context.getSharedPreferences("breakmonster_ui", 0) }
    var firstWelcomeTouchLock by remember {
        mutableStateOf(!context.getSharedPreferences("teraphonia_startup", Context.MODE_PRIVATE).getBoolean("first_run_complete_v1", false))
    }
    // QUEUE is the startup and HOME destination. First-install playback uses only
    // its single seeded welcome entry; the local library scan is independent.
    LaunchedEffect(Unit) {
        playlistVisible = true
        playlistTab = playlists.queueIndex
        playlists.activate(playlists.queueIndex)
    }
    LaunchedEffect(activity?.introFinished) {
        if (activity?.introFinished != true || welcomeLaunchRequested) return@LaunchedEffect
        val startupPrefs = context.getSharedPreferences("teraphonia_startup", Context.MODE_PRIVATE)
        if (startupPrefs.getBoolean("first_run_complete_v1", false)) return@LaunchedEffect
        val welcome = playlists.resolve(playlists.queueIndex).firstOrNull {
            it.file.name.equals("BRAKE MONSTER WELCOME SONG.mp3", true)
        } ?: return@LaunchedEffect
        welcomeLaunchRequested = true
        firstWelcomeTouchLock = true
        playlistVisible = true
        playlistTab = playlists.queueIndex
        playlists.activate(playlists.queueIndex)
        // Already in ADD TO QUEUE mode when the initial welcome audio starts.
        queueSelectionMode = true
        val current = BreakPlaybackService.snapshot
        if (!current.sessionActive) {
            model.startPlaylist(
                listOf(welcome), 0,
                playlistContext = playlists.playbackContext(playlists.queueIndex),
                selectedByUser = false
            )
        } else if (current.trackUri != welcome.file.uri.toString()) {
            queueSelectionMode = false
        }
        firstWelcomeTouchLock = false
    }
    // Use the audio SERVICE's confirmed PLAYING snapshot, not the ViewModel's
    // later mirroring of it. A fast first-install start must never miss its
    // one-time ADD TO QUEUE tutorial because of a Compose/ViewModel race.
    LaunchedEffect(welcomeLaunchRequested, mixerSnapshot.trackUri, mixerSnapshot.playing) {
        if (!welcomeLaunchRequested || !mixerSnapshot.playing) return@LaunchedEffect
        val welcome = playlists.lists.getOrNull(playlists.queueIndex)?.firstOrNull {
            it.name.equals("BRAKE MONSTER WELCOME SONG", ignoreCase = true)
        } ?: return@LaunchedEffect
        if (mixerSnapshot.trackUri != welcome.uri) return@LaunchedEffect
        val startupPrefs = context.getSharedPreferences("teraphonia_startup", Context.MODE_PRIVATE)
        playlistVisible = true
        playlistTab = playlists.queueIndex
        queueSelectionMode = true
        if (!welcomeQueueExplanationShown) {
            welcomeQueueExplanationShown = true
            if (!startupPrefs.getBoolean("queue_intro_shown_v1", false)) {
                queueExplanationForWelcome = true
                showQueueExplanation = true
                startupPrefs.edit().putBoolean("welcome_guide_pending", true).apply()
                BlackBox.log("QUEUE FIRST INSTALL INTRO shown while WELCOME SONG playing")
            }
        }
        // A GIF's first frame is NOT evidence of successful playback. Mark
        // first-run complete only after the welcome MediaPlayer has started.
        startupPrefs.edit().putBoolean("welcome_started_v1", true)
            .putBoolean("first_run_complete_v1", true).commit()
    }
    var playlistFocusUri by remember { mutableStateOf<String?>(null) }
    val cloudMutex = remember { Mutex() }
    val cloudImportsInFlight = remember { HashSet<String>() }
    val cloudRequest = activity?.pendingCloudLink
    LaunchedEffect(cloudRequest?.first) {
        val incoming = cloudRequest ?: return@LaunchedEffect
        activity?.dismissCloudLink(incoming.first)
        // Direct ACTION_VIEW/Cloud links must not bypass SEARCH PLAYLISTS in FREE.
        if (activity?.commerce?.active != true) {
            activity?.commerce?.requirePro("ONLINE PLAYLISTS")
            return@LaunchedEffect
        }
        globalSearchScope.launch {
            cloudMutex.withLock {
                // Recheck at execution time: access may expire while waiting for the mutex.
                if (activity?.commerce?.active != true) return@withLock
                var inFlightReceipt: String? = null
                var createdIndex: Int? = null
                var loadingContext: String? = null
                try {
                    val endpoint = CloudPlaylistTransfer.verifiedTransferUri(incoming.second)
                    val receipt = CloudPlaylistTransfer.transferKey(endpoint)
                    if (CloudPlaylistTransfer.previouslySaved(context, receipt)) {
                        uiToast(context, "Playlist already saved", Toast.LENGTH_LONG).show()
                        return@withLock
                    }
                    if (!cloudImportsInFlight.add(receipt)) {
                        uiToast(context, "Playlist import already running", Toast.LENGTH_SHORT).show()
                        return@withLock
                    }
                    inFlightReceipt = receipt
                    uiToast(context, "Importing playlist...", Toast.LENGTH_LONG).show()
                    val transfer = CloudPlaylistTransfer.fetch(endpoint)
                    val index = playlists.createUnique(transfer.title) ?: error("Cannot create playlist")
                    createdIndex = index
                    val playlistContext = playlists.playbackContext(index)
                    loadingContext = playlistContext
                    loadingPlaylists = loadingPlaylists + playlistContext
                    // Reuse the identical BMQ writer as the existing ZIP import.
                    // Downloading or importing does not interrupt the active player.
                    model.importYoutubeLinksToPlaylist(index, transfer.tracks,
                        { saved, failed ->
                            val entries = saved.map { (name, uri, videoId) ->
                                BreakPlaylistEntry(name, uri, true, sourceKind = "CLOUD_IMPORT", videoId = videoId)
                            }
                            if (playlists.addEntries(index, entries)) entries.size to failed
                            else 0 to (entries.size + failed)
                        }
                    ) { imported, failed ->
                        globalSearchScope.launch {
                            loadingPlaylists = loadingPlaylists - playlistContext
                            cloudImportsInFlight.remove(receipt)
                            if (imported > 0) {
                                CloudPlaylistTransfer.markSaved(context, receipt)
                                playlistTab = index
                                playlists.activate(index)
                                playlistFocusUri = null
                                youtubeSearchUrl = null
                                playlistVisible = true
                                uiToast(context, "SAVED ${playlists.displayName(index)}: $imported songs${if(failed>0) ", $failed skipped" else ""}", Toast.LENGTH_LONG).show()
                            } else {
                                playlists.delete(index)
                                uiToast(context, "Playlist import failed: $failed skipped", Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                } catch (error: Exception) {
                    loadingContext?.let { loadingPlaylists = loadingPlaylists - it }
                    inFlightReceipt?.let { cloudImportsInFlight.remove(it) }
                    createdIndex?.let { if (playlists.lists.getOrNull(it)?.isEmpty() == true) playlists.delete(it) }
                    BlackBox.log("CLOUD SAVE ${error.javaClass.simpleName}: ${error.message}")
                    uiToast(context, "SAVE PLAYLIST: ${error.message ?: "Import failed"}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
    var browserSection by remember { mutableStateOf("ALL MUSIC") }
    var importUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var importCursor by remember { mutableIntStateOf(0) }
    var importConflict by remember { mutableStateOf<Uri?>(null) }
    var playlistImportSource by remember { mutableStateOf(false) }
    var zipImportTarget by remember { mutableIntStateOf(-1) }
    fun prepareImportDisplay() { (context as? MainActivity)?.setPlaylistPickerOpen(true) }
    fun restoreImportDisplay() { (context as? MainActivity)?.setPlaylistPickerOpen(false) }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken=result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
        if(spoken.isNotBlank()) {
            if(speechTarget=="youtube") {
                // Voice recognition may return after the PRO entitlement expired.
                proOrBuy("WEB SEARCH") {
                    youtubeQuery=spoken
                    youtubeSearchUrl="https://www.youtube.com/results?search_query="+URLEncoder.encode(spoken,"UTF-8")
                }
            } else localQuery=spoken
        }
    }
    fun startVoiceSearch(target:String) {
        speechTarget=target
        val intent=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak your search")
        runCatching { speechLauncher.launch(intent) }.onFailure { uiToast(context,"Voice search is not available.",Toast.LENGTH_SHORT).show() }
    }
    fun playGlobalSearchHit(hit: GlobalSearchHit) {
        showGlobalSearchResults = false
        localQuery = ""
        if(queueSelectionMode && hit.kind=="PLAYLIST") {
            val entry=playlists.lists.getOrNull(hit.playlistIndex)?.firstOrNull { it.uri==hit.uri }
            if(entry!=null) playlists.toggleQueueEntry(entry.copy(sourceKind="USER_PLAYLIST",sourcePlaylistIndex=hit.playlistIndex,sourceContext=playlists.playbackContext(hit.playlistIndex)))
            return
        }
        when (hit.kind) {
            "PLAYLIST" -> {
                val current = playlists.resolve(hit.playlistIndex)
                val exact = current.indexOfFirst { it.file.uri.toString() == hit.uri }
                if (exact < 0) {
                    uiToast(context, "Song unavailable", Toast.LENGTH_SHORT).show()
                    return
                }
                playlistTab = hit.playlistIndex
                playlists.activate(hit.playlistIndex)
                playlistVisible = true
                        youtubeSearchUrl = null
                model.startPlaylist(current, exact, playlistContext = playlists.playbackContext(hit.playlistIndex))
            }
            else -> {
                val item = hit.item ?: model.searchableLocalItems.firstOrNull { it.file.uri.toString() == hit.uri }
                if (item == null) {
                    uiToast(context, "Song unavailable", Toast.LENGTH_SHORT).show()
                    return
                }
                if(queueSelectionMode) {
                    playlists.toggleQueueEntry(BreakPlaylistEntry(item.name,item.file.uri.toString(),item.isYoutube,sourceKind="LOCAL_SEARCH",sourceContext="local-search"))
                    showGlobalSearchResults=false
                    return
                }
                playlistVisible = false
                        youtubeSearchUrl = null
                val itemUri = Uri.parse(item.file.uri.toString())
                browserSection = when {
                    itemUri.scheme == "file" && itemUri.path.orEmpty().contains("/YT DOWNLOADS/") -> "YT DOWNLOADS"
                    itemUri.scheme == "file" && itemUri.path.orEmpty().contains("/brakemonster_media/") -> "BRAKEMONSTER"
                    else -> "ALL MUSIC"
                }
                model.navigateToLocalItem(item)
                model.startLocal(item)
            }
        }
    }
    val audioPermission = if(Build.VERSION.SDK_INT>=33) android.Manifest.permission.READ_MEDIA_AUDIO else android.Manifest.permission.READ_EXTERNAL_STORAGE
    val musicPermissionLauncher=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if(granted) model.scanMediaStore() else uiToast(context,"Music access was not granted.",Toast.LENGTH_LONG).show()
    }
    fun findMyMusic() {
        BlackBox.log("UI FIND YOUR MUSIC")
        model.home()

        if(ContextCompat.checkSelfPermission(context,audioPermission)==PackageManager.PERMISSION_GRANTED) model.scanMediaStore()
        else musicPermissionLauncher.launch(audioPermission)
    }
    fun saveYoutubeFromSearch(exactName: String) {
        val liveAtSelection = BreakPlaybackService.snapshot
        val playingContext = model.activePlaybackPlaylistContext
        val playingPlaylist = (0 until playlists.size).firstOrNull {
            playlists.isAvailable(it) && playlists.playbackContext(it) == playingContext
        }
        val targetIndex = if (!queueSelectionMode && liveAtSelection.sessionActive &&
            playingPlaylist != null && playingPlaylist != playlists.welcomePlaylistIndex())
            playingPlaylist else playlists.queueIndex
        val targetContext = playlists.playbackContext(targetIndex)
        val playingUri = liveAtSelection.trackUri.takeIf {
            liveAtSelection.sessionActive && playingContext == targetContext
        }
        model.saveYoutubeToPlaylist(targetIndex, exactName) { name, uri, videoId ->
            if (!playlists.isAvailable(targetIndex) ||
                playlists.playbackContext(targetIndex) != targetContext) {
                BreakPlaylistStore.SearchSaveResult.FAILED
            } else {
                val result = playlists.saveSearchToPlaylist(targetIndex, name, uri, videoId, playingUri)
                if (result == BreakPlaylistStore.SearchSaveResult.ADDED && playingUri != null &&
                    model.activePlaybackPlaylistContext == targetContext) {
                    BreakPlaybackService.playSavedWebAfterEnd(
                        expectedCurrentUri = playingUri,
                        entry = BreakPlaybackService.Entry(uri, name)
                    )
                }
                result
            }
        }
    }
    // ADD TO QUEUE is a browsing mode, not a navigation destination. It stays
    // enabled across USER PLAYLISTS, LOCAL FILES and WEB until this button is
    // pressed again; returning to QUEUE then restores ordinary row playback.
    fun toggleQueueSelection() {
        if (!queueSelectionMode) {
            model.cancelPlaylistTransitionOverlay("queue_selection_started")
            queueSelectionMode = true
            if (!prefs.getBoolean("queueExplanationDone", false)) {
                queueExplanationForWelcome = false
                showQueueExplanation = true
            }
        } else {
            model.cancelPlaylistTransitionOverlay("queue_selection_finished")
            queueSelectionMode = false
            playlistTab = playlists.queueIndex
            playlists.activate(playlists.queueIndex)
            playlistVisible = true
            youtubeSearchUrl = null
            playlistFocusUri = null
        }
    }
    // Same navigation action in the normal header and the XL list.
    // Preserve ADD TO QUEUE and the playing deck when browsing local files.
    fun openLocalFiles() {
        mixerOpen = false
        playlistVisible = false
        youtubeSearchUrl = null
        browserSection = "ALL MUSIC"
        playlistTab = playlists.queueIndex
        playlists.activate(playlists.queueIndex)
        model.home()
    }
    var swipeFeedback by remember { mutableStateOf<Pair<Int,Int>?>(null) }
    var swipeFeedbackSequence by remember { mutableIntStateOf(0) }
    var swipeBlinkUri by remember { mutableStateOf<String?>(null) }
    var folderSwipeHint by remember { mutableStateOf(false) }
    var playlistHint by remember { mutableStateOf(false) }
    var reorderHint by remember { mutableStateOf(false) }
    var playlistReorderHint by remember { mutableStateOf(false) }
    LaunchedEffect(model.allMusicItems.size, browserSection) {
        if(browserSection=="ALL MUSIC" && model.allMusicItems.isNotEmpty() && !prefs.getBoolean("folderSwipeHintDone", false)) {
            folderSwipeHint = true
        }
    }
    LaunchedEffect(model.tracks.size, model.rootUri, model.path, browserSection) {
        if(browserSection=="ALL MUSIC" && model.rootUri!=null && model.path.isEmpty() && model.tracks.size>1 && prefs.getBoolean("folderSwipeHintDone",false) && !prefs.getBoolean("reorderGestureHintDone",false)) reorderHint=true
    }
    LaunchedEffect(playlistVisible, playlistTab, playlists.lists.getOrNull(playlistTab)?.size) {
        if(playlistVisible && playlistTab!=playlists.queueIndex && (playlists.lists.getOrNull(playlistTab)?.size ?: 0) > 1 && prefs.getBoolean("playlistHintDone",false) && !prefs.getBoolean("playlistReorderGestureHintDone",false)) playlistReorderHint=true
    }
    LaunchedEffect(folderSwipeHint, playlistVisible, browserSection, youtubeSearchUrl, model.tracks.size) {
        if (folderSwipeHint && !playlistVisible && browserSection == "ALL MUSIC" &&
            youtubeSearchUrl == null && model.tracks.isNotEmpty()) {
            delay(8000)
            prefs.edit().putBoolean("folderSwipeHintDone", true).apply()
            folderSwipeHint = false
            if (model.rootUri != null && model.path.isEmpty() && model.tracks.size > 1 &&
                !prefs.getBoolean("reorderGestureHintDone", false)) reorderHint = true
        }
    }
    LaunchedEffect(playlistVisible, playlistTab, playlists.lists.getOrNull(playlistTab)?.size){
        if (playlistVisible && playlistTab!=playlists.queueIndex && !prefs.getBoolean("playlistHintShownOnEntryV2", false) && !prefs.getBoolean("playlistHintDone", false)) {
            playlistHint = true
        }
    }
    LaunchedEffect(playlistHint, playlistVisible, playlistTab, youtubeSearchUrl) {
        if (playlistHint && playlistVisible && playlistTab != playlists.queueIndex && youtubeSearchUrl == null) {
            delay(14000)
            prefs.edit().putBoolean("playlistHintShownOnEntryV2", true).putBoolean("playlistHintDone", true).apply()
            playlistHint = false
            if ((playlists.lists.getOrNull(playlistTab)?.size ?: 0) > 1 &&
                !prefs.getBoolean("playlistReorderGestureHintDone", false)) playlistReorderHint = true
        }
    }
    LaunchedEffect(swipeFeedback){ if(swipeFeedback!=null){ delay(2000); swipeFeedback=null } }
    LaunchedEffect(swipeFeedbackSequence){ if(swipeBlinkUri!=null){ delay(240); swipeBlinkUri=null } }
    fun showSwipeFeedback(added:Boolean, playlist:Int){
        swipeFeedbackSequence++; swipeFeedback = swipeFeedbackResource(added, playlist) to swipeFeedbackSequence
    }


    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                runCatching { context.contentResolver.takePersistableUriPermission(uri, flags) }
                    .getOrElse { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                model.setRoot(uri)
            } catch (_: SecurityException) {
                uiToast(context, "Folder permission nije sačuvan.", Toast.LENGTH_LONG).show()
            }
        }
    }
    val mediaImportPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        importUris = uris; importCursor = 0; importConflict = null
        if (uris.isNotEmpty()) {
            uris.forEach { uri -> runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
            browserSection = "BRAKEMONSTER"
        }
    }
    val playlistFilePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            playlistTab = importM3uPlaylist(context, uri, model.allMusicItems, playlists)
        }
        restoreImportDisplay()
    }

    val ytMonsterZipPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && zipImportTarget == -2) {
            zipImportBusy = true
            globalSearchScope.launch {
                val pending = mutableSetOf<String>()
                val result = try {
                    importYtMonsterZip(context, uri, playlists, model, onLoading = { index, loading ->
                        val key = playlists.playbackContext(index)
                        if (loading) {
                            pending.add(key)
                            loadingPlaylists = loadingPlaylists + key
                        } else {
                            pending.remove(key)
                            loadingPlaylists = loadingPlaylists - key
                        }
                    })
                } finally {
                    loadingPlaylists = loadingPlaylists - pending
                    zipImportBusy = false
                }
                uiToast(context, result.message, Toast.LENGTH_LONG).show()
                restoreImportDisplay()
                if (result.openIndex != null) {
                    playlistTab = result.openIndex
                    playlists.activate(result.openIndex)
                    playlistFocusUri = null
                                youtubeSearchUrl = null
                    playlistVisible = true
                    BlackBox.log("ZIP IMPORT OPEN playlistIndex=${result.openIndex}")
                }
            }
        } else restoreImportDisplay()
        zipImportTarget = -1
    }

    LaunchedEffect(model.rootUri, model.path, model.refreshSerial) { model.refresh() }

    LaunchedEffect(importUris, importCursor, importConflict) {
        if (importCursor < importUris.size && importConflict == null) {
            val uri = importUris[importCursor]
            val name = model.importName(uri)
            if (model.importedNameExists(name)) importConflict = uri
            else { model.copyImport(uri, "cancel"); importCursor++ }
        } else if (importCursor >= importUris.size) importUris = emptyList()
    }

    fun resolveImportConflict(choice: String) {
        val uri = importConflict ?: return
        if (choice != "cancel") model.copyImport(uri, choice)
        importConflict = null; importCursor++
    }

    LaunchedEffect(model.message) {
        model.message?.let {
            uiToast(context, it, Toast.LENGTH_SHORT).show()
            model.consumeMessage()
        }
    }

    var fullBrowser by rememberSaveable { mutableStateOf(false) }
    val phoneHeaderTop = 62.dp
    val phoneHeaderHeight = 50.dp
    val phoneHeaderFont = 12.sp
    BackHandler(enabled = !pipMode) {
        when {
            playlistCloudBrowserOpen -> {
                val web = playlistCloudWebView
                if (web?.canGoBack() == true) web.goBack()
                else playlistCloudBrowserOpen = false
            }
            youtubeSearchUrl != null -> youtubeSearchUrl = null
            showYoutubeSearchInput -> showYoutubeSearchInput = false
            selectedForMenu != null -> selectedForMenu = null
            fullBrowser -> fullBrowser = false
            model.path.isNotEmpty() -> model.back()
            !playlistVisible || playlistTab != playlists.queueIndex -> {
                playlistVisible = true; playlistTab = playlists.queueIndex; playlists.activate(playlists.queueIndex)
                queueSelectionMode = false; model.home()
            }
            else -> moveTaskToBack()
        }
    }

    // v175: root setContent owns the REAL 20dp top margin and clips the stage
    // beneath it. Do not add padding a second time inside virtual canvas density.
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (!pipMode) {
            Image(
                painter = painterResource(R.drawable.breakmonster_stage),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().offset(y = (-54).dp)
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .15f)))

            if (!fullBrowser && phonePortraitLayout) {
                CompositionLocalProvider(LocalDensity provides phoneControlDensity) {
                    BoxWithConstraints(
                        Modifier.align(Alignment.TopCenter)
                            .fillMaxWidth()
                            .height(phoneHeaderTop + phoneHeaderHeight)
                            // Match the visible stone edge inside the button's 2dp
                            // outer padding and the shape's 99% bottom point.
                            .padding(bottom = 2.5.dp),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        Image(
                            painter = painterResource(R.drawable.breakmonster_logo_phone),
                            contentDescription = AppLanguage.text("BreakMonster"),
                            contentScale = ContentScale.Fit,
                            alignment = Alignment.BottomCenter,
                            modifier = Modifier.width(maxWidth * (.43f * 4f / 3f) * 0.8f).fillMaxHeight()
                        )
                    }
                }
            }

            // Keep the original stage-art header visible: HOME / BACK / logo / folder ventilation.
            if (!fullBrowser) BoxWithConstraints(Modifier.align(Alignment.TopCenter).fillMaxWidth().height(136.dp)) {
                val w = maxWidth
                if (!isTablet && !phonePortraitLayout) {
                    Image(
                        painter = painterResource(R.drawable.breakmonster_logo),
                        contentDescription = AppLanguage.text("BreakMonster"),
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.align(Alignment.TopCenter).padding(top = 2.dp)
                            .width(w * (.43f * 4f / 3f)).heightIn(max = 136.dp)
                    )
                } else if (isTablet) {
                    // Keep the v176 tablet logo size and alignment exactly as approved.
                    Box(
                        Modifier.align(Alignment.TopCenter)
                            .padding(top = 2.dp)
                            .size(
                                width = (w * (.43f * 4f / 3f)).coerceAtLeast(150.dp),
                                height = 136.dp
                            )
                            .zIndex(1f)
                    ) {
                        Image(
                            painter = painterResource(R.drawable.breakmonster_logo),
                            contentDescription = AppLanguage.text("BreakMonster"),
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
                Box(Modifier.offset(x = w * .012f).width(w * .12f).fillMaxHeight().combinedClickable(onClick = { BlackBox.log("UI HOME"); model.cancelPlaylistTransitionOverlay("home_navigation"); browserSection="ALL MUSIC"; playlistVisible=true; playlistTab=playlists.queueIndex; playlists.activate(playlists.queueIndex); queueSelectionMode=false; youtubeSearchUrl=null; model.home() }, onLongClick = {}))
                Box(Modifier.offset(x = w * .125f).width(w * .14f).fillMaxHeight().combinedClickable(onClick = { BlackBox.log("UI BACK"); model.back() }, onLongClick = {}))

                // The folder is already painted into the stage artwork. Keep the art untouched
                // and make that painted ventilation/folder area itself the folder picker target.
                Box(
                    Modifier.offset(x = w * .655f, y = 30.dp).width(w * .19f).height(96.dp)
                        .semantics { contentDescription = AppLanguage.text("Folder decoration") }
                        .clickable { folderPicker.launch(null) }
                )
            }

            // Decorative top edge of the app window. Draw exactly the same muted,
            // diagonally twisted rope as the volume control, but without its stone
            // thumb or any touch/volume handling. It sits at the absolute top of
            // the stage so it does not consume the browser's usable vertical space.
            if (!fullBrowser) WindowTopRope(
                Modifier.align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .height(14.dp)
                    .zIndex(220f)
            )

            // Phone touch regions use native dp, never the 800dp virtual stage density.
            if (!fullBrowser) CompositionLocalProvider(LocalDensity provides
                if (phonePortraitLayout) phoneControlDensity else LocalDensity.current) {
            Box(
                Modifier.align(Alignment.TopStart)
                    .padding(start = 6.dp, top = if (phonePortraitLayout) phoneHeaderTop else 50.dp)
                    .size(
                        width = if (phonePortraitLayout) 118.dp else 154.dp,
                        height = if (phonePortraitLayout) phoneHeaderHeight else 64.dp
                    )
                    .zIndex(210f)
            ) {
                PlaylistStoneButton(
                    onClick = ::openLocalFiles,
                    active = !playlistVisible,
                    modifier = Modifier.fillMaxSize()
                        .semantics { contentDescription = AppLanguage.text("LOCAL FILES") }
                ) {
                    HeaderStoneText("LOCAL FILES", if (isTablet) 14.sp else phoneHeaderFont, 1)
                }
            }

            }

            // The artwork still uses the proven virtual stage canvas, but browser
            // lists/buttons must measure in native dp to remain usable on phones.
            CompositionLocalProvider(LocalDensity provides
                if (phonePortraitLayout) phoneControlDensity else LocalDensity.current) {
            BreakBrowserArea(
                    model = model,
                    loadingPlaylists = loadingPlaylists,
                    zipImportBusy = zipImportBusy,
                    fullBrowser = fullBrowser,
                    playbackBarInset = if (playbackBarHeightPx > 0) {
                        with(LocalDensity.current) { playbackBarHeightPx.toDp() }
                    } else 132.dp,
                    onYoutubeSearch = { proOrBuy("WEB SEARCH") { val q=youtubeQuery.trim(); if(q.isNotBlank()) youtubeSearchUrl="https://www.youtube.com/results?search_query="+URLEncoder.encode(q,"UTF-8") else showYoutubeSearchInput=true } },
                    onFindMusic = ::findMyMusic,
                    showFindMusic = !model.mediaScanComplete && activity?.introFinished == true,
                    firstScanBusy = model.mediaScanInProgress,
                    localQuery = localQuery,
                    onLocalQuery = { localQuery = it },
                    youtubeQuery = youtubeQuery,
                    onYoutubeQuery = { youtubeQuery = it },
                    onLocalMic = { startVoiceSearch("local") },
                    onGlobalLocalSearch = {
                        val query = localQuery.trim()
                        if (query.isNotEmpty() && !globalSearchBusy) {
                            globalSearchJob?.cancel()
                            globalSearchBusy = true
                            val localSnapshot = model.searchableLocalItems.toList()
                            val playlistSnapshot = playlists.availableIndices().map { i ->
                                Triple(i, playlists.displayName(i), playlists.lists[i].toList())
                            }
                            globalSearchJob = globalSearchScope.launch {
                                val hits = try { withContext(Dispatchers.IO) {
                                    val found = mutableListOf<GlobalSearchHit>()
                                    localSnapshot.filter { it.name.contains(query, true) }.forEach { item ->
                                        found += GlobalSearchHit(item.name, "LOCAL MUSIC", item.file.uri.toString(), "LOCAL", item=item)
                                    }
                                    playlistSnapshot.forEach { (index, name, entries) ->
                                        val resolved = entries.filterNot { it.missing }.mapNotNull { entry ->
                                            runCatching {
                                                val entryUri = Uri.parse(entry.uri)
                                                val document = if (entryUri.scheme == "file") DocumentFile.fromFile(java.io.File(entryUri.path.orEmpty())) else DocumentFile.fromSingleUri(context, entryUri)
                                                document?.let { BreakItem(it, entry.name, entry.youtube) }
                                            }.getOrNull()
                                        }
                                        entries.filter { !it.missing && it.name.contains(query, true) }.forEach { entry ->
                                            val selected = resolved.indexOfFirst { it.file.uri.toString() == entry.uri }
                                            if (selected >= 0) found += GlobalSearchHit(entry.name, name, entry.uri, "PLAYLIST", playlistIndex=index, playlistItems=resolved, selectedIndex=selected)
                                        }
                                    }
                                    found.distinctBy { "${it.kind}:${it.location}:${it.uri}" }.take(200)
                                } } catch (cancelled: CancellationException) { throw cancelled } catch (error: Throwable) {
                                    globalSearchBusy = false
                                    uiToast(context, "Search failed: ${error.message ?: "unavailable"}", Toast.LENGTH_SHORT).show()
                                    return@launch
                                }
                                globalSearchBusy = false
                                if (hits.isEmpty()) uiToast(context, "No matching song", Toast.LENGTH_SHORT).show()
                                else if (hits.size == 1) playGlobalSearchHit(hits.single())
                                else {
                                    globalSearchHits = hits
                                    showGlobalSearchResults = true
                                }
                            }
                        }
                    },
                    onYoutubeMic = { proOrBuy("WEB SEARCH") { startVoiceSearch("youtube") } },
                    onOpenFolder = { model.openFolder(it) },
                    onTrack = { item -> model.startLocal(item) },
                    selectedItem = selectedForMenu,
                    onSelect = { item -> selectedForMenu = item },
                    onDeselect = { selectedForMenu = null },
                    playlistVisible = playlistVisible,
                    playlistStore = playlists,
                    activePlaylistContext = model.activePlaybackPlaylistContext,
                    queueSelectionMode = queueSelectionMode,
                    queueBlinkAlpha = queueBlinkAlpha,
                    queueSongTextSize = queueSongTextSize,
                    playlistSongTextSize = playlistSongTextSize,
                    localSongTextSize = localSongTextSize,
                    webTextSize = webTextSize,
                    onQueueTap = ::toggleQueueSelection,
                    onMixerOpen = { proOrBuy("MIXER") { mixerOpen = true } },
                    random = model.random,
                    repeat = model.repeat,
                    onRandom = { model.updateRandom(!model.random) },
                    onRepeat = { model.updateRepeat(!model.repeat) },
                    onCreatePlaylist = { name -> val index=playlists.create(name); playlistTab=index; lastUserPlaylistTab=index },
                    playlistTab = playlistTab,
                    playlistFocusUri = playlistFocusUri,
                    onPlaylistTab = { model.cancelPlaylistTransitionOverlay("playlist_screen_navigation"); playlistTab = it; if(it!=playlists.queueIndex) lastUserPlaylistTab=it; playlistFocusUri=null; playlists.activate(it) },
                    onTogglePlaylist = { model.cancelPlaylistTransitionOverlay("playlist_screen_toggled"); playlistVisible = !playlistVisible },
                    folderSwipeHint = folderSwipeHint,
                    playlistHint = playlistHint,
                    swipeBlinkUri = swipeBlinkUri,
                    onSwipeAdded = { item ->
                        if (!prefs.getBoolean("folderSwipeHintDone", false)) {
                            prefs.edit().putBoolean("folderSwipeHintDone", true).apply()
                            if(model.rootUri!=null && model.path.isEmpty() && model.tracks.size>1 && !prefs.getBoolean("reorderGestureHintDone",false)) reorderHint=true
                        }
                        folderSwipeHint = false
                        val added = playlists.add(item)
                        if (added) {
                            swipeBlinkUri=item.file.uri.toString(); showSwipeFeedback(true, playlists.activeIndex+1)
                            uiToast(context,"ADDED TO ${playlists.displayName(playlists.activeIndex)}",Toast.LENGTH_SHORT).show()
                        }
                        else uiToast(context, "Već je u ${playlists.displayName(playlists.activeIndex)}", Toast.LENGTH_SHORT).show()
                    },
                    onSwipeRemoved = { pl -> showSwipeFeedback(false, pl) },
                    onPlaylistGestureLearned = {
                        prefs.edit().putBoolean("playlistHintDone", true).apply(); playlistHint=false
                        if((playlists.lists.getOrNull(playlistTab)?.size ?: 0)>1 && !prefs.getBoolean("playlistReorderGestureHintDone",false)) playlistReorderHint=true
                    },
                    // FREE cannot retain an online WebView across entitlement changes.
                    youtubeSearchUrl = youtubeSearchUrl.takeIf { proEnabled },
                    onYoutubeSelected = { id, title, url ->
                        // Block stale result taps if PRO access expired mid-search.
                        proOrBuy("WEB SEARCH") {
                            model.selectYoutube(id, title, url)
                            imeNumere = title.orEmpty()
                            saveYoutubeFromSearch(title.orEmpty())
                            youtubeSearchUrl = null
                        }
                    },
                    onYoutubeClose = { youtubeSearchUrl = null },
                    browserSection = browserSection,
                    onBrowserSection = { model.cancelPlaylistTransitionOverlay("browser_navigation"); browserSection = it; playlistVisible=false; playlistTab=playlists.queueIndex; playlists.activate(playlists.queueIndex); model.home() },
                    onImportMedia = { mediaImportPicker.launch(arrayOf("*/*")) },
                    onImportPlaylist = { playlistImportSource = true },
                    onImportZipAt = { index ->
                        if (!zipImportBusy) {
                            prepareImportDisplay()
                            zipImportTarget = index
                            ytMonsterZipPicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*"))
                        }
                    },
                    reorderHint = reorderHint,
                    onReorderGestureLearned = { prefs.edit().putBoolean("reorderGestureHintDone",true).apply(); reorderHint=false },
                    playlistReorderHint = playlistReorderHint,
                    onPlaylistReorderLearned = { prefs.edit().putBoolean("playlistReorderGestureHintDone",true).apply(); playlistReorderHint=false },
                    onOpenLocalFiles = ::openLocalFiles,
                    xlWebSearchEnabled = proEnabled,
                    onAllowXlWebSearch = {
                        var allowed = false
                        proOrBuy("WEB SEARCH") { allowed = true }
                        allowed
                    },
                    playlistSearchOpen = playlistCloudBrowserOpen,
                    onSearchPlaylists = {
                        var opened = false
                        proOrBuy("ONLINE PLAYLISTS") {
                            playlistCloudBrowserOpen = true
                            opened = true
                        }
                        opened
                    },
                    onOpenUserPlaylists = {
                        model.cancelPlaylistTransitionOverlay("user_playlists_navigation")
                        youtubeSearchUrl=null // Preserve ADD TO QUEUE across playlist browsing.
                        if (!playlistVisible || playlistTab==playlists.queueIndex) {
                            playlistVisible=true
                            playlistTab=lastUserPlaylistTab.takeIf { playlists.isAvailable(it) && it!=playlists.queueIndex } ?: playlists.playlistTabIndices().firstOrNull() ?: playlists.queueIndex
                            playlists.activate(playlistTab)
                        } else {
                            lastUserPlaylistTab=playlistTab
                            playlistTab=playlists.queueIndex
                            playlists.activate(playlists.queueIndex)
                        }
                    },
                )
            }

            swipeFeedback?.let { (resource, sequence) ->
                key(sequence) { GestureManual(resource, Modifier.align(Alignment.TopCenter).padding(top=188.dp).fillMaxWidth().height(128.dp).zIndex(110f)) }
            }

            val showMixingAnimation = mixerSnapshot.automaticCrossfadePlaying ||
                model.isIdleTrackLoading(mixerSnapshot)
            if (showMixingAnimation && !pipMode) {
                BoxWithConstraints(
                    Modifier.fillMaxSize().padding(top = 136.dp, bottom = 158.dp).zIndex(150f),
                    contentAlignment = Alignment.Center
                ) {
                    val displayWidth = minOf(maxWidth * 0.82f, (maxHeight - 16.dp).coerceAtLeast(80.dp) * 1.5f, 520.dp) * (2f / 3f)
                    GestureManual(
                        R.raw.baba_pterodaktil_dj_mixing,
                        Modifier.width(displayWidth).height(displayWidth / 1.5f)
                    )
                }
            }

            if (!fullBrowser) CompositionLocalProvider(LocalDensity provides
                if (phonePortraitLayout) phoneControlDensity else LocalDensity.current) {
            PlaybackBar(
                model = model,
                backupBusy = backupBusy.value,
                nameValue = imeNumere,
                onNameChange = { imeNumere = it },
                onSaveYoutube = {
                    saveYoutubeFromSearch(imeNumere)
                },
                saveToQueue = queueSelectionMode || !BreakPlaybackService.snapshot.sessionActive ||
                    model.activePlaybackPlaylistContext == null ||
                    model.activePlaybackPlaylistContext == playlists.playbackContext(playlists.queueIndex) ||
                    model.activePlaybackPlaylistContext == playlists.playbackContext(playlists.welcomePlaylistIndex()),
                onTransitionNext = { transitionClick.stop() },
                onTransitionStop = { transitionClick.stop() },
                onMixerOpen = { proOrBuy("MIXER") { mixerOpen = true } },
                onFeedMonster = {
                    activity?.commerce?.status(onBackup = { showBackupMenu = true })
                },
                modifier = Modifier.align(Alignment.BottomCenter)
                    .onSizeChanged { playbackBarHeightPx = it.height }
                    .navigationBarsPadding()
            )
            }

            // Keep the controls above the measured player, including navigation padding.
            if (fullBrowser || playbackBarHeightPx > 0) {
                val sizingSection = when {
                    youtubeSearchUrl != null && proEnabled -> "web"
                    !playlistVisible -> "local"
                    playlistTab == playlists.queueIndex -> "queue"
                    else -> "playlists"
                }
                val sizingState = when (sizingSection) {
                    "web" -> webTextSize
                    "local" -> localSongTextSize
                    "queue" -> queueSongTextSize
                    else -> playlistSongTextSize
                }
                CompositionLocalProvider(LocalDensity provides
                    if (phonePortraitLayout) phoneControlDensity else LocalDensity.current) {
                    val bottomInset = if (fullBrowser) 0.dp else
                        with(if (phonePortraitLayout) phoneControlDensity else playbackCanvasDensity) {
                            playbackBarHeightPx.toDp()
                        }
                    Column(
                        modifier = Modifier.align(Alignment.BottomEnd)
                            .windowInsetsPadding(WindowInsets.navigationBars.only(WindowInsetsSides.End))
                            .then(if (fullBrowser) Modifier.navigationBarsPadding() else Modifier)
                            .padding(bottom = bottomInset + 6.dp)
                            .zIndex(120f),
                        horizontalAlignment = Alignment.End,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val controlHeight = if (phonePortraitLayout) 120.dp else 208.dp
                        BrowserFullToggle(fullBrowser, controlHeight) { fullBrowser = !fullBrowser }
                        SongTextSizeControls(sizingSection, sizingState, controlHeight)
                    }
                }
            }


        }

        // PRO AUDIO ONLY: no YouTube video surface or hidden iframe is created.

        // Replace the old top-right EXIT X with the only cloud navigation button.
        // Preserve its v176 tablet placement and two-line label without editing overlays.
        if (!pipMode && !showReturnLogo && !fullBrowser) {
            CompositionLocalProvider(LocalDensity provides
                if (phonePortraitLayout) phoneControlDensity else LocalDensity.current) {
            Box(
                Modifier.align(Alignment.TopEnd)
                    .padding(end = 6.dp, top = if (phonePortraitLayout) phoneHeaderTop else 50.dp)
                    .size(
                        width = if (phonePortraitLayout) 118.dp else 170.dp,
                        height = if (phonePortraitLayout) phoneHeaderHeight else 64.dp
                    )
                    .zIndex(210f)
            ) {
                PlaylistStoneButton(
                    onClick = {
                        // Stay in BrakeMonster. This browser has NO address bar.
                        // Do not touch existing WEB SEARCH or audio playback.
                        proOrBuy("ONLINE PLAYLISTS") { playlistCloudBrowserOpen = true }
                    },
                    modifier = Modifier.fillMaxSize().semantics { contentDescription = AppLanguage.text("SEARCH PLAYLISTS") }
                ) {
                    HeaderStoneText("SEARCH\nPLAYLISTS", if (isTablet) 15.sp else phoneHeaderFont, 2)
                }
            }
            }
        }

        // Full-screen dedicated cloud browser sits over the stage, while the
        // playing deck, QUEUE and other state continue undisturbed underneath.
        if (playlistCloudBrowserOpen && proEnabled && !pipMode) {
            PlaylistCloudBrowser(
                onClose = { playlistCloudBrowserOpen = false },
                onWebView = { playlistCloudWebView = it },
                onPlaylistLink = { uri ->
                    proOrBuy("ONLINE PLAYLISTS") {
                        activity?.receiveCloudPlaylistLink(uri)
                        playlistCloudBrowserOpen = false
                    }
                },
                modifier = Modifier.fillMaxSize().zIndex(500f)
            )
        }

        if (firstWelcomeTouchLock) {
            val waitBlink by rememberInfiniteTransition(label = "first-welcome-wait")
                .animateFloat(initialValue = .3f, targetValue = 1f,
                    animationSpec = infiniteRepeatable(tween(480), RepeatMode.Reverse), label = "wait-opacity")
            Box(
                Modifier.fillMaxSize().zIndex(1000f).background(Color.Black.copy(alpha = .78f))
                    .pointerInput(Unit) {
                        awaitPointerEventScope {
                            while (true) awaitPointerEvent().changes.forEach { it.consume() }
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                FittedControlText(AppLanguage.text("WAIT..."), color = Color.White.copy(alpha = waitBlink), fontSize = 42.sp,
                    fontWeight = FontWeight.Black, modifier = Modifier.background(Color.Black.copy(alpha = .68f), RoundedCornerShape(14.dp))
                        .border(3.dp, Amber, RoundedCornerShape(14.dp)).padding(horizontal = 28.dp, vertical = 16.dp))
            }
        }

    }

    if (mixerOpen) {
        ProMixerDialog(
            crossfader = crossfaderPosition,
            mixerState = mixerSnapshot,
            onCrossfader = { value ->
                if (!manualFaderAwaitingRelease) {
                    manualFaderDragging = true
                    // A -> B only. Never allow a reverse manual swipe.
                    crossfaderPosition = value.coerceIn(crossfaderPosition, 1f)
                    mixerPrefs.edit().putFloat("crossfader", crossfaderPosition).apply()
                    BreakPlaybackService.setMixer(crossfaderPosition, false, crossfadeSeconds)
                }
            },
            onManualEnd = {
                if (manualFaderAwaitingRelease || crossfaderPosition >= 0.999f) {
                    // Release the service-side one-shot guard after the pointer
                    // lifts, so the next deliberate A->B gesture can start.
                    BreakPlaybackService.setMixer(-1f, false, crossfadeSeconds)
                }
                manualFaderDragging = false
                manualFaderAwaitingRelease = false
            },
            autoMix = autoMixEnabled,
            onAutoMix = { _ -> },
            seconds = crossfadeSeconds,
            onSeconds = { seconds ->
                crossfadeSeconds = seconds.coerceIn(1, 12)
                mixerPrefs.edit().putInt("duration_seconds", crossfadeSeconds).apply()
                BreakPlaybackService.setMixer(crossfaderPosition, autoMixEnabled, crossfadeSeconds)
            },
            onExportBlackBox = { blackBoxExporter.launch("BrakeMonster_PRO_BlackBox.txt") },
            onResetBlackBox = {
                BlackBox.clearAudioReport()
                uiToast(context, "BLACK BOX RESET · PLAY ONE SONG", Toast.LENGTH_LONG).show()
            },
            onDismiss = {
                manualFaderDragging = false
                manualFaderAwaitingRelease = false
                mixerOpen = false
            }
        )
    }

    PlaylistBackupDialogs(
        store = playlists,
        visible = showBackupMenu,
        busy = backupBusy,
        onDismiss = { showBackupMenu = false },
        onRestored = {
            model.cancelPlaylistTransitionOverlay("playlist_backup_restored")
            playlistFocusUri = null
            playlistTab = playlists.queueIndex
            playlists.activate(playlists.queueIndex)
            playlistVisible = true
            youtubeSearchUrl = null
            queueSelectionMode = false
        }
    )

    if (showQueueExplanation) {
        val phone = LocalConfiguration.current.smallestScreenWidthDp < 600
        val bodySize = if (phone) 16.sp else 19.sp
        val finishGuide = {
            prefs.edit().putBoolean("queueExplanationDone", true).apply()
            if (queueExplanationForWelcome) {
                startupGuidePrefs.edit().putBoolean("queue_intro_shown_v1", true)
                    .remove("welcome_guide_pending").apply()
            }
            showQueueExplanation = false
        }
        CompositionLocalProvider(LocalDensity provides if (phonePortraitLayout) phoneControlDensity else LocalDensity.current) {
            AlertDialog(
                onDismissRequest = finishGuide,
                title = {
                    Text(AppLanguage.text(if (queueExplanationForWelcome) "WELCOME TO BRAKE MONSTER 🦖" else "BUILD YOUR QUEUE"),
                        fontSize = if (phone) 20.sp else 24.sp, fontWeight = FontWeight.Black)
                },
                text = {
                    Column(Modifier.heightIn(max = if (phone) 320.dp else 480.dp)
                        .verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(AppLanguage.text("ADD TO QUEUE: tap songs in PLAYLISTS or LOCAL FILES to add or remove them. WEB SEARCH always saves to QUEUE."), fontSize = bodySize)
                        Text(AppLanguage.text("XL: tap the blue XL stone to open your playlists in a vertical list. Tap a playlist to open it. Hold a playlist for its options. Tap NORMAL to return."), fontSize = bodySize)
                        Text(AppLanguage.text("Tap ADD TO QUEUE again (DONE in XL) to finish and return to QUEUE."), fontSize = bodySize)
                    }
                },
                confirmButton = { Button(onClick = finishGuide) { FittedControlText(AppLanguage.text("GOT IT"), fontWeight = FontWeight.Black) } }
            )
        }
    }

    if (showYoutubeSearchInput && proEnabled) {
        AlertDialog(
            onDismissRequest = { showYoutubeSearchInput = false },
            title = { FittedControlText(AppLanguage.text("WEB SEARCH"), fontSize = 24.sp, fontWeight = FontWeight.Black) },
            text = {
                OutlinedTextField(
                    value = youtubeQuery,
                    onValueChange = { youtubeQuery = it },
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 22.sp),
                    label = { FittedControlText(AppLanguage.text("Search")) },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        proOrBuy("WEB SEARCH") {
                            val q = youtubeQuery.trim()
                            if (q.isNotBlank()) {
                                youtubeSearchUrl = "https://www.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8")
                                showYoutubeSearchInput = false
                            }
                        }
                    },
                    enabled = youtubeQuery.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color.Black)
                ) { FittedControlText(AppLanguage.text("SEARCH"), fontWeight = FontWeight.Black) }
            },
            dismissButton = { TextButton(onClick = { showYoutubeSearchInput = false }) { FittedControlText(AppLanguage.text("CANCEL")) } }
        )
    }

    // Search results share LOCAL's live setting, including changes made this session.
    val globalSongTextSize = localSongTextSize
    val globalResultsRowHeight = songRowHeight(globalSongTextSize.floatValue, local = true)
    val globalRowScale = songRowControlScale(globalSongTextSize.floatValue, defaultSize = 26f)
    if (showGlobalSearchResults) AlertDialog(
        onDismissRequest = { showGlobalSearchResults = false },
        title = { FittedControlText(AppLanguage.text("LOCAL SEARCH RESULTS"), fontSize = 22.sp, fontWeight = FontWeight.Black) },
        text = {
            Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState())) {
                globalSearchHits.forEach { hit ->
                    TextButton(
                        onClick = { playGlobalSearchHit(hit) },
                        modifier = Modifier.fillMaxWidth().height(globalResultsRowHeight)
                    ) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                MarqueeFilenameText(hit.title, Modifier.fillMaxWidth(), Color.White, globalSongTextSize.floatValue.sp, FontWeight.Bold)
                                Text(hit.location, color = Color(0xFFB4D38E), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            val hitItem = hit.item ?: hit.playlistItems.getOrNull(hit.selectedIndex)
                            if (hitItem?.isYoutube == true) YouTubeBadge(Modifier.size(34.dp * globalRowScale))
                            else MediaTypeBadge(Uri.parse(hit.uri).lastPathSegment.orEmpty().substringAfterLast('.', ""), globalRowScale)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { showGlobalSearchResults = false }) { FittedControlText(AppLanguage.text("CLOSE")) } }
    )

    if (showReturnLogo && !pipMode) {
        Box(Modifier.fillMaxSize().background(DeepGreen).zIndex(100f), contentAlignment = Alignment.Center) {
            Image(
                painter = painterResource(R.drawable.breakmonster_logo),
                contentDescription = AppLanguage.text("BreakMonster"),
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxWidth(.72f).heightIn(max = 220.dp)
            )
        }
    }


    selectedForMenu?.let { item ->
        if(!renameMode && !deleteFileConfirm) AlertDialog(
            onDismissRequest={selectedForMenu=null},
            title={Text(item.name,fontSize=22.sp,fontWeight=FontWeight.Bold)},
            confirmButton={TextButton(onClick={renameMode=true;renameText=item.name}){FittedControlText(AppLanguage.text("RENAME"),fontSize=18.sp)}},
            dismissButton={Row { TextButton(onClick={deleteFileConfirm=true}){FittedControlText(AppLanguage.text("DELETE"),fontSize=18.sp,color=Color(0xFFFF7B72))}; TextButton(onClick={selectedForMenu=null}){FittedControlText(AppLanguage.text("CANCEL"),fontSize=18.sp)} }}
        )
        if (renameMode) AlertDialog(
            onDismissRequest = { renameMode = false },
            title = { FittedControlText(AppLanguage.text("RENAME"), fontSize = 22.sp, fontWeight = FontWeight.Bold) },
            text = { OutlinedTextField(value = renameText, onValueChange = { renameText = it }, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(fontSize = 22.sp), modifier = Modifier.fillMaxWidth()) },
            confirmButton = { Button(onClick = { renameConfirmed(item,renameText); renameMode = false; selectedForMenu = null }) { FittedControlText(AppLanguage.text("SAVE")) } },
            dismissButton = { TextButton(onClick = { renameMode = false }) { FittedControlText(AppLanguage.text("CANCEL")) } }
        )
        if(deleteFileConfirm) AlertDialog(
            onDismissRequest={deleteFileConfirm=false;selectedForMenu=null},
            title={FittedControlText(AppLanguage.text("ARE YOU SURE?"),fontSize=23.sp,fontWeight=FontWeight.Black)},
            text={Text(AppLanguage.text("Delete ${item.name}? This removes the real media file."),fontSize=18.sp)},
            confirmButton={Button(onClick={deleteConfirmed(item);deleteFileConfirm=false;selectedForMenu=null}){FittedControlText(AppLanguage.text("DELETE"),fontWeight=FontWeight.Black)}},
            dismissButton={TextButton(onClick={deleteFileConfirm=false;selectedForMenu=null}){FittedControlText(AppLanguage.text("CANCEL"),fontSize=18.sp)}}
        )
    }

    importConflict?.let { uri ->
        val name = model.importName(uri)
        AlertDialog(onDismissRequest={resolveImportConflict("cancel")}, title={FittedControlText(AppLanguage.text("FILE ALREADY EXISTS"),fontWeight=FontWeight.Black)},
            text={Text(AppLanguage.text("$name is already in BRAKEMONSTER. Choose how to copy this file."),fontSize=18.sp)},
            confirmButton={TextButton(onClick={resolveImportConflict("replace")}){FittedControlText(AppLanguage.text("REPLACE"),fontWeight=FontWeight.Bold)}},
            dismissButton={Row { TextButton(onClick={resolveImportConflict("keep")}){FittedControlText(AppLanguage.text("KEEP BOTH"))}; TextButton(onClick={resolveImportConflict("cancel")}){FittedControlText(AppLanguage.text("CANCEL"))} }})
    }

    if (playlistImportSource) AlertDialog(onDismissRequest={playlistImportSource=false}, title={FittedControlText(AppLanguage.text("IMPORT PLAYLIST"),fontWeight=FontWeight.Black)},
        text={Column { Text(AppLanguage.text("Import a local M3U or M3U8 playlist. Online playlist sources need official API access, which is not configured in this project."),fontSize=17.sp); Spacer(Modifier.height(10.dp)); Text(AppLanguage.text("YouTube · Spotify · Apple Music: unavailable until official API access is configured."),fontSize=15.sp,color=Color.LightGray) }},
        confirmButton={TextButton(onClick={playlistImportSource=false;prepareImportDisplay();playlistFilePicker.launch(arrayOf("*/*"))}){FittedControlText(AppLanguage.text("CHOOSE M3U / M3U8"))}},
        dismissButton={TextButton(onClick={playlistImportSource=false}){FittedControlText(AppLanguage.text("CANCEL"))} })

    if (importUris.isNotEmpty() && importConflict == null) {
        // Copy requests are handled one at a time; the source document is only read.
    }

}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BreakBrowserArea(
    model: BreakMonsterModel,
    loadingPlaylists: Set<String>,
    zipImportBusy: Boolean,
    fullBrowser: Boolean,
    playbackBarInset: Dp,
    onYoutubeSearch: () -> Unit,
    onFindMusic: () -> Unit,
    showFindMusic: Boolean,
    firstScanBusy: Boolean,
    localQuery: String,
    onLocalQuery: (String) -> Unit,
    youtubeQuery: String,
    onYoutubeQuery: (String) -> Unit,
    onLocalMic: () -> Unit,
    onGlobalLocalSearch: () -> Unit,
    onYoutubeMic: () -> Unit,
    onOpenFolder: (LocalFolder) -> Unit,
    onTrack: (BreakItem) -> Unit,
    selectedItem: BreakItem?,
    onSelect: (BreakItem) -> Unit,
    onDeselect: () -> Unit,
    playlistVisible: Boolean,
    playlistStore: BreakPlaylistStore,
    activePlaylistContext: String?,
    queueSelectionMode: Boolean,
    queueBlinkAlpha: State<Float>,
    queueSongTextSize: MutableFloatState,
    playlistSongTextSize: MutableFloatState,
    localSongTextSize: MutableFloatState,
    webTextSize: MutableFloatState,
    onQueueTap: () -> Unit,
    onMixerOpen: () -> Unit,
    random: Boolean,
    repeat: Boolean,
    onRandom: () -> Unit,
    onRepeat: () -> Unit,
    onCreatePlaylist: (String) -> Unit,
    playlistTab: Int,
    playlistFocusUri: String?,
    onPlaylistTab: (Int) -> Unit,
    onTogglePlaylist: () -> Unit,
    folderSwipeHint: Boolean,
    playlistHint: Boolean,
    swipeBlinkUri: String?,
    onSwipeAdded: (BreakItem) -> Unit,
    onSwipeRemoved: (Int) -> Unit,
    onPlaylistGestureLearned: () -> Unit,
    youtubeSearchUrl: String?,
    onYoutubeSelected: (String, String?, String) -> Unit,
    onYoutubeClose: () -> Unit,
    browserSection: String,
    onBrowserSection: (String) -> Unit,
    onImportMedia: () -> Unit,
    onImportPlaylist: () -> Unit,
    onImportZipAt: (Int) -> Unit,
    reorderHint: Boolean,
    onReorderGestureLearned: () -> Unit,
    playlistReorderHint: Boolean,
    onPlaylistReorderLearned: () -> Unit,
    onOpenUserPlaylists: () -> Unit,
    onOpenLocalFiles: () -> Unit,
    xlWebSearchEnabled: Boolean,
    onAllowXlWebSearch: () -> Boolean,
    playlistSearchOpen: Boolean,
    onSearchPlaylists: () -> Boolean,
) {
    // Keep XL navigation and scroll alive even when the playlist panel is
    // replaced by LOCAL FILES, QUEUE or the normal web search panel.
    val xlMode = rememberSaveable { mutableStateOf(false) }
    val xlChooserVisible = rememberSaveable { mutableStateOf(false) }
    val xlReturningFromSearch = rememberSaveable { mutableStateOf(false) }
    val xlWebSearchUrl = rememberSaveable { mutableStateOf<String?>(null) }
    val xlListState = rememberLazyListState()
    val xlUiState = remember(xlMode, xlChooserVisible, xlReturningFromSearch,
        xlWebSearchUrl, xlListState) {
        XlPlaylistUiState(xlMode, xlChooserVisible, xlReturningFromSearch,
            xlWebSearchUrl, xlListState)
    }
    // Inside a local folder, the normal Back action still goes up one level.
    // At the local root it returns to the retained XL chooser.
    BackHandler(enabled = !fullBrowser && xlMode.value && !playlistVisible &&
        !xlChooserVisible.value && !playlistSearchOpen && youtubeSearchUrl == null &&
        selectedItem == null && model.path.isEmpty()) {
        xlChooserVisible.value = true
        onOpenUserPlaylists()
    }
    // Exactly one + / − control per visible song list; never one on each song.
    // QUEUE, PLAYLISTS and LOCAL each keep one independent saved size.
    val songTextSection = when {
        playlistVisible && playlistTab == playlistStore.queueIndex -> "queue"
        playlistVisible -> "playlists"
        else -> "local"
    }
    val songTextSize = when (songTextSection) {
        "queue" -> queueSongTextSize
        "playlists" -> playlistSongTextSize
        else -> localSongTextSize
    }
    val localSongRowHeight = songRowHeight(songTextSize.floatValue, local = true)
    val localRowScale = songRowControlScale(songTextSize.floatValue, defaultSize = 26f)
    val baseTracks = when (browserSection) {
        "YT DOWNLOADS" -> model.ytDownloadItems
        "BRAKEMONSTER" -> model.brakeMonsterItems
        else -> model.tracks
    }
    val visibleTracks = remember(baseTracks, model.allMusicItems, localQuery) {
        if(localQuery.isBlank()) baseTracks else model.allMusicItems.filter { it.name.contains(localQuery.trim(),true) }
    }
    val localListState = rememberLazyListState()
    val activeLocalUri = model.activePlaybackItemUri ?: model.localTrackUri
    LaunchedEffect(activeLocalUri, visibleTracks) {
        val activeIndex = visibleTracks.indexOfFirst { it.file.uri.toString() == activeLocalUri }
        if (activeIndex >= 0) {
            val info = localListState.layoutInfo
            val row = info.visibleItemsInfo.firstOrNull { it.index == activeIndex }
            val threshold = info.viewportStartOffset + (info.viewportEndOffset - info.viewportStartOffset) * 2 / 3
            if (row == null && activeIndex > (info.visibleItemsInfo.lastOrNull()?.index ?: -1)) localListState.animateScrollToItem((activeIndex - 2).coerceAtLeast(0))
            else if (row != null && row.offset + row.size > threshold) localListState.animateScrollToItem((activeIndex - 2).coerceAtLeast(0))
        }
    }
    val visibleFolders = remember(model.folders,localQuery,browserSection) { if(browserSection!="ALL MUSIC") emptyList() else model.folders.filter { localQuery.isBlank() || it.name.contains(localQuery.trim(), true) } }
    val rowHeightFactor = 1f
    val nativePhoneBrowser = LocalConfiguration.current.screenWidthDp < 600 &&
        LocalConfiguration.current.orientation == android.content.res.Configuration.ORIENTATION_PORTRAIT
    val shortPhoneBrowser = nativePhoneBrowser && LocalConfiguration.current.screenHeightDp < 680
    var shortPhoneSearch by remember { mutableStateOf<String?>(null) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            // Browser intentionally has no panel/window of its own. The stage bitmap
            // must remain fully visible behind folders and tracks.
            .background(Color.Transparent)
            .then(if (fullBrowser) Modifier.navigationBarsPadding() else Modifier)
            .padding(top = if (fullBrowser) 4.dp else if (nativePhoneBrowser) 112.dp else 120.dp,
                bottom = if (fullBrowser) 0.dp else playbackBarInset,
                start = 12.dp, end = BrowserEndInset)
    ) {
        if (!fullBrowser) {
            if (shortPhoneBrowser) {
                // On short phones two 66dp search rows would leave almost no room
                // for tracks. Both searches and voice input remain available here.
                Row(Modifier.fillMaxWidth().height(52.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PlaylistStoneButton(onClick = { shortPhoneSearch = "web" },
                        modifier = Modifier.weight(1f).fillMaxHeight()
                            .semantics { contentDescription = AppLanguage.text("WEB SEARCH") }) {
                        FittedControlText(AppLanguage.text("WEB SEARCH"), color = Color.White,
                            fontSize = 16.sp, fontWeight = FontWeight.Black, maxLines = 1)
                    }
                    PlaylistStoneButton(onClick = { shortPhoneSearch = "local" },
                        modifier = Modifier.weight(1f).fillMaxHeight()
                            .semantics { contentDescription = AppLanguage.text("LOCAL SEARCH") }) {
                        FittedControlText(AppLanguage.text("LOCAL SEARCH"), color = Color.White,
                            fontSize = 16.sp, fontWeight = FontWeight.Black, maxLines = 1)
                    }
                }
                if (shortPhoneSearch != null) {
                    val web = shortPhoneSearch == "web"
                    AlertDialog(onDismissRequest = { shortPhoneSearch = null },
                        title = { Text(AppLanguage.text(if (web) "WEB SEARCH" else "LOCAL SEARCH")) },
                        text = {
                            Column {
                                OutlinedTextField(value = if (web) youtubeQuery else localQuery,
                                    onValueChange = if (web) onYoutubeQuery else onLocalQuery,
                                    label = { FittedControlText(AppLanguage.text("Search music")) }, singleLine = true,
                                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                        imeAction = androidx.compose.ui.text.input.ImeAction.Search),
                                    keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                                        onSearch = {
                                            shortPhoneSearch = null
                                            if (web) onYoutubeSearch() else onGlobalLocalSearch()
                                        }), modifier = Modifier.fillMaxWidth())
                                TextButton(onClick = {
                                    shortPhoneSearch = null
                                    if (web) onYoutubeMic() else onLocalMic()
                                }) { FittedControlText(AppLanguage.text("🎙 VOICE SEARCH"), fontWeight = FontWeight.Black) }
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = {
                                shortPhoneSearch = null
                                if (web) onYoutubeSearch() else onGlobalLocalSearch()
                            }) { FittedControlText(AppLanguage.text("SEARCH"), fontWeight = FontWeight.Black) }
                        },
                        dismissButton = {
                            TextButton(onClick = { shortPhoneSearch = null }) { FittedControlText(AppLanguage.text("CANCEL")) }
                        })
                }
            } else {
                Row(Modifier.fillMaxWidth().height(66.dp),verticalAlignment=Alignment.CenterVertically) {
                    SearchInputField(
                        value = youtubeQuery,
                        onValueChange = onYoutubeQuery,
                        placeholder = "WEB SEARCH",
                        blinkAlpha = remember { mutableFloatStateOf(1f) },
                        onSearch = onYoutubeSearch,
                        modifier = Modifier.weight(1f).height(62.dp)
                    )
                    StoneButton(onClick=onYoutubeMic,active=false,modifier=Modifier.size(54.dp)) {
                        FittedControlText(AppLanguage.text("🎙"),fontSize=25.sp,color=MonsterGreen)
                    }
                }
                Spacer(Modifier.height(3.dp))
                Row(Modifier.fillMaxWidth().height(66.dp),verticalAlignment=Alignment.CenterVertically) {
                    SearchInputField(
                        value = localQuery,
                        onValueChange = onLocalQuery,
                        placeholder = "LOCAL SEARCH",
                        blinkAlpha = remember { mutableFloatStateOf(1f) },
                        onSearch = onGlobalLocalSearch,
                        modifier = Modifier.weight(1f).height(62.dp)
                    )
                    StoneButton(onClick=onLocalMic,active=false,modifier=Modifier.size(54.dp)) {
                        FittedControlText(AppLanguage.text("🎙"),fontSize=25.sp,color=MonsterGreen)
                    }
                }
            }
            Spacer(Modifier.height(if (shortPhoneBrowser) 0.dp else if (nativePhoneBrowser) 6.dp else 22.dp))
            // NORMAL: fixed XL entry and compact ADD TO QUEUE / DONE side by side.
            // Changing view never changes playback or the queue selection mode.
            Row(Modifier.fillMaxWidth().height((58f * rowHeightFactor).dp + 22.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(2f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                    PlaylistStoneButton(onClick = {
                        xlMode.value = true
                        xlChooserVisible.value = true
                        if (!playlistVisible) onOpenUserPlaylists()
                    }, blueTone = true, modifier = Modifier.fillMaxSize().padding(top = 22.dp)) {
                        FittedControlText(AppLanguage.text("XL"), color = Color.White, fontSize = 20.sp,
                            fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                    }
                    PterodactylBlink(Modifier.align(Alignment.TopCenter).offset(y = (-24).dp).size(width = 90.dp, height = 59.dp).zIndex(3f))
                }
                PlaylistStoneButton(onClick = onQueueTap,
                    redTone = true, redActive = queueSelectionMode,
                    modifier = Modifier.weight(1f).fillMaxHeight().padding(top = 22.dp)
                        .semantics { contentDescription = if (queueSelectionMode) "DONE" else "ADD TO QUEUE" }) {
                    Text(AppLanguage.text(if (queueSelectionMode) "DONE" else "ADD TO QUEUE"),
                        color = Color.White.copy(alpha = if (queueSelectionMode) queueBlinkAlpha.value else 1f),
                        fontSize = if (queueSelectionMode) 16.sp else 12.sp,
                        fontWeight = FontWeight.Black, textAlign = TextAlign.Center,
                        maxLines = 2, lineHeight = 14.sp)
                }
            }
            RopeVolumeSlider(Modifier.fillMaxWidth().height(30.dp).padding(horizontal = 2.dp))
            Spacer(Modifier.height(4.dp))
        }

        Box(modifier = Modifier.fillMaxSize()) {
            Column {
                // No breadcrumb/title strip between the volume rope and playlist stones.
                // The recovered vertical space belongs to the active song list.
                if (youtubeSearchUrl != null) {
                    YoutubeSearchPanel(
                        url = youtubeSearchUrl,
                        textSize = webTextSize.floatValue,
                        onSelected = onYoutubeSelected,
                        onClose = onYoutubeClose,
                        modifier = Modifier.fillMaxSize()
                    )
                } else if (playlistVisible) {
                    BreakPlaylistPanel(
                        loadingPlaylists = loadingPlaylists,
                        zipImportBusy = zipImportBusy,
                        store = playlistStore, selected = playlistTab, onSelected = onPlaylistTab, onImportPlaylist=onImportPlaylist, onImportZipAt=onImportZipAt,
                        playlistSearchOpen=playlistSearchOpen, onSearchPlaylists=onSearchPlaylists,
                        onOpenLocalFiles=onOpenLocalFiles,
                        xlUiState=xlUiState,
                        fullBrowser=fullBrowser,
                        xlSearchControls = XlSearchControls(
                            webTextSize = webTextSize,
                            queueSelectionMode = queueSelectionMode, blinkAlpha = queueBlinkAlpha,
                            webEnabled = xlWebSearchEnabled,
                            webQuery = youtubeQuery, onWebQuery = onYoutubeQuery,
                            onAllowWebSearch = onAllowXlWebSearch, onWebSelected = onYoutubeSelected,
                            localQuery = localQuery, onLocalQuery = onLocalQuery,
                            onLocalSearch = onGlobalLocalSearch),
                        playingPlaylistContext = activePlaylistContext,
                        queueSelectionMode=queueSelectionMode,
                        onQueueTap=onQueueTap,
                        onExportQueue={ name -> playlistStore.exportQueue(name) },
                        random=random, repeat=repeat, onRandom=onRandom, onRepeat=onRepeat,
                        localQuery=localQuery, onCreatePlaylist=onCreatePlaylist,
                        showHint = playlistHint, onGestureLearned = onPlaylistGestureLearned,
                        showReorderHint=playlistReorderHint, onReorderGestureLearned=onPlaylistReorderLearned,
                        onSwipeRemoved = onSwipeRemoved,
                        playingUri = model.activePlaybackItemUri ?: model.localTrackUri,
                        focusUri = playlistFocusUri,
                        songTextSize = songTextSize,
                        onPlayRadio = { station ->
                            proOrBuy("RADIO") {
                                val saved = playlistStore.addTemporaryRadio(station)
                                playlistTab = playlistStore.queueIndex
                                playlistStore.activate(playlistStore.queueIndex)
                                playlistVisible = true
                                queueSelectionMode = false
                                val ordered = playlistStore.resolve(playlistStore.queueIndex)
                                val position = ordered.indexOfFirst { it.file.uri.toString() == saved.uri }
                                if (position >= 0) model.startPlaylist(ordered, position,
                                    playlistContext = playlistStore.playbackContext(playlistStore.queueIndex))
                                else uiToast(context, "RADIO station could not be loaded", Toast.LENGTH_LONG).show()
                            }
                        },
                        onPlay = { uri ->
                            if(queueSelectionMode) return@BreakPlaylistPanel
                            val resolved=playlistStore.resolve(playlistTab)
                            val index=resolved.indexOfFirst { it.file.uri.toString()==uri }
                            if(index>=0) model.startPlaylist(resolved,index,playlistContext=playlistStore.playbackContext(playlistTab))
                        }
                    )
                } else if (showFindMusic) {
                    Spacer(Modifier.weight(1f))
                    StoneButton(onClick=onFindMusic,active=!firstScanBusy,modifier=Modifier.fillMaxWidth().height(72.dp)){
                        Text(AppLanguage.text(if(firstScanBusy) "WAIT..." else "FIND YOUR MUSIC"),color=Color.White,fontSize=22.sp,fontWeight=FontWeight.Black)
                    }
                    Spacer(Modifier.weight(1f))
                } else {
                if (browserSection == "BRAKEMONSTER") {
                    Row(Modifier.fillMaxWidth().padding(horizontal=8.dp, vertical=2.dp), horizontalArrangement=Arrangement.End) {
                        PlaylistStoneButton(onClick=onImportMedia,active=true,modifier=Modifier.width(156.dp).height(38.dp)) { StoneLabel("IMPORT",Color.White,12.sp) }
                    }
                }
                if (model.loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = MonsterGreen)
                model.error?.let { Text(it, color = Color(0xFFFF8A80), fontSize = 18.sp, modifier = Modifier.padding(12.dp)) }
                SongListArea {
                    LazyColumn(Modifier.fillMaxSize(), state=localListState) {
                    if(folderSwipeHint && visibleTracks.isNotEmpty() && browserSection=="ALL MUSIC") item { GestureManual(R.drawable.folder_swipe_hint, Modifier.fillMaxWidth().height(86.dp)) }
                    if(reorderHint && browserSection=="ALL MUSIC" && model.rootUri!=null && model.path.isEmpty() && visibleTracks.size>1) item { ReorderGestureHelp(Modifier.fillMaxWidth().height(44.dp)) }
                    // Defence-in-depth: never render Android/media thumbnail cache folders,
                    // even if a provider returns one between model refreshes.
                    items(visibleFolders, key = { it.uri.toString() }) { dir ->
                        Row(
                            Modifier.fillMaxWidth().heightIn(min = (64f * rowHeightFactor).dp)
                                .combinedClickable(onClick = { onOpenFolder(dir) }, onLongClick = {})
                                .padding(horizontal = 10.dp, vertical = 1.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(R.drawable.karamonster_folder),
                                contentDescription = null,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.padding(start = 6.dp).size((64f * 2f / 3f).dp)
                            )
                            Text(
                                dir.name,
                                color = Color.White,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.weight(1f).padding(start = 8.dp)
                            )
                        }
                        HorizontalDivider(color = Color.White.copy(alpha = .08f))
                    }
                    itemsIndexed(visibleTracks, key = { _, it -> it.file.uri.toString() }) { index, item ->
                        val active = (model.activePlaybackItemUri ?: model.localTrackUri) == item.file.uri.toString()
                        val selected = selectedItem?.file?.uri == item.file.uri
                        Row(
                            Modifier.fillMaxWidth().height(localSongRowHeight)
                                .background(if(swipeBlinkUri == item.file.uri.toString()) MonsterGreen.copy(alpha=.55f) else if(queueSelectionMode && playlistStore.isInQueue(item.file.uri.toString())) Amber.copy(alpha=.40f) else if(queueSelectionMode) Color(0xB30A2417) else if(active) Amber.copy(alpha=.5f) else if (selected) Amber.copy(alpha=.20f) else Color.Transparent)
                                .pointerInput(item.file.uri, playlistStore.activeIndex) {
                                    var dx = 0f
                                    detectHorizontalDragGestures(onDragStart={dx=0f}, onHorizontalDrag={c,a->dx+=a;if(kotlin.math.abs(dx)>12f)c.consume()}, onDragEnd={ if(dx>90.dp.toPx()) onSwipeAdded(item); dx=0f }, onDragCancel={dx=0f})
                                }
                                .pointerInput(item.file.uri) {
                                    var dragTotal = 0f
                                    detectDragGesturesAfterLongPress(
                                        onDragStart = { onSelect(item); dragTotal = 0f },
                                        onDragEnd = { dragTotal = 0f }, onDragCancel = { dragTotal = 0f },
                                        onDrag = { change, amount ->
                                            change.consume(); dragTotal += amount.y
                                            val currentIndex = model.tracks.indexOfFirst { it.file.uri == item.file.uri }
                                            if (kotlin.math.abs(dragTotal) > 55f) {
                                                onReorderGestureLearned()
                                                if (dragTotal > 0f && currentIndex in 0 until model.tracks.lastIndex) model.moveTrack(currentIndex, currentIndex + 1)
                                                else if (dragTotal < 0f && currentIndex > 0) model.moveTrack(currentIndex, currentIndex - 1)
                                                dragTotal = 0f
                                            }
                                        }
                                    )
                                }
                                .combinedClickable(onClick = {
                                    if(queueSelectionMode) playlistStore.toggleQueueEntry(BreakPlaylistEntry(item.name,item.file.uri.toString(),item.isYoutube,sourceKind="LOCAL_BROWSER",sourceContext="browser:$browserSection"))
                                    else if (selected) onDeselect() else onTrack(item)
                                }, onLongClick = { onSelect(item) })
                                .padding(start = 12.dp, end = SongControlWidth + 4.dp, top = 3.dp, bottom = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            MarqueeFilenameText(item.name, Modifier.weight(1f), Color.White, songTextSize.floatValue.sp, if (active) FontWeight.Bold else FontWeight.Medium)
                            if (active) { Spacer(Modifier.width(8.dp)); Text(AppLanguage.text(if (model.localPlaying) "▶" else "Ⅱ"), color = MonsterGreen, fontSize = 20.sp) }
                            if (item.isYoutube) { Spacer(Modifier.width(8.dp)); YouTubeBadge(Modifier.size(34.dp * localRowScale)) }
                            else { Spacer(Modifier.width(8.dp)); MediaTypeBadge(item.extension, localRowScale) }
                        }
                        HorizontalDivider(color = Color.White.copy(alpha = .08f))
                    }
                    if (!model.loading && model.folders.isEmpty() && visibleTracks.isEmpty()) {
                        item {
                            FittedControlText(AppLanguage.text("Folder je prazan."), color = Color.White.copy(alpha = .7f), fontSize = 20.sp, modifier = Modifier.padding(18.dp))
                        }
                    }
                    }
                }
                }
            }
        }
    }
}

@Composable
private fun SearchInputField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    onSearch: () -> Unit,
    modifier: Modifier = Modifier,
    blinkAlpha: State<Float>? = null
) {
    // Golf 4 / CdgLite search field: Material3 OutlinedTextField owns the
    // text layout, baseline and cursor; no nested full-height BasicTextField.
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        placeholder = {
            Text(placeholder, fontSize = 17.sp, fontWeight = FontWeight.Medium,
                color = Color(0xFFD9D6DE).copy(alpha = blinkAlpha?.value ?: 1f), maxLines = 1)
        },
        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 22.sp, color = Color.White),
        shape = RoundedCornerShape(9.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Amber,
            unfocusedBorderColor = Color(0xFF5F7A4D),
            cursorColor = Amber,
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White
        ),
        modifier = modifier,
        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
            imeAction = androidx.compose.ui.text.input.ImeAction.Search
        ),
        keyboardActions = androidx.compose.foundation.text.KeyboardActions(
            onSearch = { onSearch() }
        )
    )
}


@Composable
private fun PterodactylBlink(modifier: Modifier = Modifier) {
    val transition = androidx.compose.animation.core.rememberInfiniteTransition(label="pterodactyl-blink")
    val phase by transition.animateFloat(0f, 2000f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(2000, easing=androidx.compose.animation.core.LinearEasing)), label="blink-clock")
    val closed = phase in 140f..260f
    Image(painterResource(if(closed) R.drawable.pterodactyl_closed else R.drawable.pterodactyl_open),
        contentDescription="Playlist pterodactyl", contentScale=ContentScale.Fit, modifier=modifier)
}

/** Preserve the original blinking monster character in the PRO purchase button. */
@Composable
private fun MonsterBlinkGif(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val frames = remember(context) {
        (0..8).mapNotNull { frame ->
            runCatching {
                context.assets.open("monster_blink/frame_%02d.png".format(frame)).use { stream ->
                    android.graphics.BitmapFactory.decodeStream(stream)?.asImageBitmap()
                }
            }.getOrNull()
        }
    }
    var frameIndex by remember { mutableIntStateOf(0) }
    LaunchedEffect(frames.size) {
        while (frames.isNotEmpty()) {
            delay(170)
            frameIndex = (frameIndex + 1) % frames.size
        }
    }
    frames.getOrNull(frameIndex)?.let { frame ->
        Image(bitmap = frame, contentDescription = AppLanguage.text("Blinking little monster"), contentScale = ContentScale.Fit, modifier = modifier)
    }
}

/**
 * PRO mixer for the foreground service's independent audio decks.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProMixerDialog(
    crossfader: Float,
    mixerState: BreakPlaybackService.Snapshot,
    onCrossfader: (Float) -> Unit,
    onManualEnd: () -> Unit,
    autoMix: Boolean,
    onAutoMix: (Boolean) -> Unit,
    seconds: Int,
    onSeconds: (Int) -> Unit,
    onExportBlackBox: () -> Unit,
    onResetBlackBox: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            FittedControlText(AppLanguage.text("MIXER"), fontSize = 28.sp, fontWeight = FontWeight.Black, color = MonsterGreen)
        },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
                    StoneBufferColumn(mixerState.bufferedPercentA)
                    StoneBufferColumn(mixerState.bufferedPercentB)
                }

                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    FittedControlText(AppLanguage.text("A"), color = Amber, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Slider(
                        value = crossfader,
                        onValueChange = onCrossfader,
                        onValueChangeFinished = onManualEnd,
                        valueRange = -1f..1f,
                        enabled = mixerState.deckAReady && mixerState.deckBReady &&
                            (mixerState.bufferedPercentA >= MANUAL_MIX_BUFFER_PERCENT ||
                                (mixerState.playing && !mixerState.bufferingA)) &&
                            mixerState.standbyMixReady,
                        modifier = Modifier.weight(1f).padding(horizontal = 10.dp),
                        thumb = { MixerBabaThumb() },
                        track = { MixerCrossfadeTrack() }
                    )
                    FittedControlText(AppLanguage.text("B"), color = Amber, fontSize = 22.sp, fontWeight = FontWeight.Black)
                }
                val hasQueuedNextDeck = mixerState.standbyTrackUri != null || mixerState.deckBPreparing || mixerState.deckBRecovering
                if (mixerState.sessionActive && hasQueuedNextDeck &&
                    !(mixerState.deckAReady && mixerState.deckBReady &&
                        (mixerState.bufferedPercentA >= MANUAL_MIX_BUFFER_PERCENT ||
                            (mixerState.playing && !mixerState.bufferingA)) &&
                        mixerState.standbyMixReady)) {
                    val blink by androidx.compose.animation.core.rememberInfiniteTransition(label = "buffer-wait")
                        .animateFloat(initialValue = 0.25f, targetValue = 1f,
                            animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                                androidx.compose.animation.core.tween(420), androidx.compose.animation.core.RepeatMode.Reverse),
                            label = "wait-opacity")
                    FittedControlText(AppLanguage.text("WAIT..."), color = Amber.copy(alpha = blink), fontSize = 22.sp, fontWeight = FontWeight.Black)
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Button(onClick = { onSeconds((seconds - 1).coerceAtLeast(1)) }, enabled = seconds > 1,
                        colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color.Black),
                        modifier = Modifier.size(62.dp), contentPadding = PaddingValues(0.dp)) {
                        FittedControlText(AppLanguage.text("−"), fontSize = 29.sp, fontWeight = FontWeight.Black)
                    }
                    Text(AppLanguage.text("$seconds sec"), fontSize = 25.sp, color = MonsterGreen, fontWeight = FontWeight.Black)
                    Button(onClick = { onSeconds((seconds + 1).coerceAtMost(12)) }, enabled = seconds < 12,
                        colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color.Black),
                        modifier = Modifier.size(62.dp), contentPadding = PaddingValues(0.dp)) {
                        FittedControlText(AppLanguage.text("+"), fontSize = 29.sp, fontWeight = FontWeight.Black)
                    }
                }
                FittedControlText(AppLanguage.text("AUTO CROSSFADE"), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            }
        },
        confirmButton = { Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = MonsterGreen, contentColor = Color.Black)) {
            FittedControlText(AppLanguage.text("DONE"), fontSize = 18.sp, fontWeight = FontWeight.Black)
        } },
        containerColor = DeepGreen,
        titleContentColor = Color.White,
        textContentColor = Color.White
    )
}

private val MixerStoneShape = GenericShape { size, _ ->
    moveTo(size.width * .06f, size.height * .12f)
    lineTo(size.width * .43f, 0f)
    lineTo(size.width * .91f, size.height * .06f)
    lineTo(size.width, size.height * .28f)
    lineTo(size.width * .96f, size.height * .76f)
    lineTo(size.width * .86f, size.height)
    lineTo(size.width * .10f, size.height * .92f)
    lineTo(0f, size.height * .68f)
    close()
}

@Composable
private fun MixerStoneSlab(modifier: Modifier) {
    Box(
        modifier
            .background(
                Brush.verticalGradient(listOf(Color(0xFF929184), Color(0xFF57584E), Color(0xFF30332E))),
                MixerStoneShape
            )
            .border(1.dp, Color(0xFF77796D), MixerStoneShape)
    )
}

@Composable
private fun MixerCrossfadeTrack() {
    Box(
        Modifier.fillMaxWidth().height(16.dp).clip(MixerStoneShape)
            .background(Brush.verticalGradient(
                0f to Color(0xFFD1CBBB),
                .16f to Color(0xFF989787),
                .29f to Color(0xFF65675B),
                .64f to Color(0xFF54574D),
                .72f to Color(0xFF3C4038),
                1f to Color(0xFF20241E)
            ))
            .border(1.dp, Color(0xFF73766A), MixerStoneShape)
            .drawBehind {
                drawLine(Color(0xFFE3DDC8).copy(alpha = .55f),
                    center.copy(x = size.width * .07f, y = size.height * .19f),
                    center.copy(x = size.width * .90f, y = size.height * .15f), 1.dp.toPx())
                drawLine(Color.Black.copy(alpha = .45f),
                    center.copy(x = size.width * .10f, y = size.height * .82f),
                    center.copy(x = size.width * .89f, y = size.height * .88f), 1.dp.toPx())
            }
    )
}

@Composable
private fun MixerBabaThumb() {
    val frames = remember {
        intArrayOf(R.drawable.mixer_baba_0, R.drawable.mixer_baba_1, R.drawable.mixer_baba_2, R.drawable.mixer_baba_3)
    }
    var frameIndex by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        val frameDurations = longArrayOf(1850, 60, 60, 30)
        while (true) {
            delay(frameDurations[frameIndex])
            frameIndex = (frameIndex + 1) % frames.size
        }
    }
    Box(Modifier.size(width = 55.dp, height = 42.dp), contentAlignment = Alignment.Center) {
        MixerStoneSlab(Modifier.size(width = 16.dp, height = 12.dp).align(Alignment.BottomCenter))
        Image(
            painter = painterResource(frames[frameIndex]),
            contentDescription = null,
            modifier = Modifier.size(width = 55.dp, height = 33.dp).align(Alignment.TopCenter),
            contentScale = ContentScale.Fit
        )
    }
}

@Composable
private fun StoneBufferColumn(bufferedPercent: Int) {
    val percent = bufferedPercent.coerceIn(0, 100)
    val filled = percent * 8 / 100
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Column(
            Modifier.width(62.dp).height(122.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp, Alignment.Bottom)
        ) {
            repeat(filled) {
                MixerStoneSlab(Modifier.width(48.dp).height(11.dp))
            }
        }
        Text(AppLanguage.text("$percent%"), color = MonsterGreen, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MixerFxProButtons(onMixerOpen: () -> Unit, onClick: () -> Unit, backupBusy: Boolean, modifier: Modifier = Modifier, compact: Boolean = false, narrow: Boolean = false) {
    val phone = LocalConfiguration.current.smallestScreenWidthDp < 600
    val commercial = (LocalContext.current as? MainActivity)?.commerce
    val proActive = commercial?.active == true
    var showRollMonster by remember { mutableStateOf(false) }
    LaunchedEffect(proActive) { if (!proActive) showRollMonster = false }
    if (showRollMonster && proActive) RollMonsterDialog(onDismiss = {
        BreakPlaybackService.releaseRollEffect()
        BreakPlaybackService.releaseLiveFx()
        showRollMonster = false
    })
    Row(modifier = modifier.height(54.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        PlaylistStoneButton(onClick = onMixerOpen, modifier = Modifier.weight(1f).fillMaxHeight()) {
            FittedControlText(AppLanguage.text("MIX"), color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp, maxLines = 1)
        }
        StoneButton(onClick = {
            if (proActive) showRollMonster = true else commercial?.requirePro("FX")
        }, modifier = Modifier.weight(1f).fillMaxHeight()) {
            FittedControlText(AppLanguage.text("FX"), color = Color.White, fontWeight = FontWeight.Black, fontSize = 19.sp)
        }
        // Keep the original purchase action on the right-hand stone.
        StoneButton(onClick = onClick, onLongClick = onClick, enabled = !backupBusy,
            modifier = Modifier.weight(1f).fillMaxHeight().semantics {
                contentDescription = if (backupBusy) "Backup in progress" else "PRO purchase or license status. Includes BACKUP, HELP and CHECK FOR UPDATES"
            }) {
            if (backupBusy) {
                WaitStoneLabel(fontSize = if (phone) 10.sp else 13.sp)
            } else {
                Column(
                    modifier = Modifier.fillMaxSize().padding(horizontal = if (compact) 2.dp else 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(AppLanguage.text(if(proActive && commercial?.entitlementType == "trial") "TRIAL" else if(proActive) "BM PRO" else "BUY PRO"), color = Color.White, fontSize = if (phone) 8.sp else if (compact || narrow) 12.sp else 15.sp,
                            fontWeight = FontWeight.Black, maxLines = 1, softWrap = false)
                        if (proActive) {
                            Spacer(Modifier.width(4.dp))
                            Image(painterResource(R.drawable.bm_pro_rex_transparent), contentDescription = AppLanguage.text("BrakeMonster original T-Rex icon"), modifier = Modifier.size(if (phone) 9.dp else if (compact) 24.dp else 32.dp))
                        } else if (!compact) {
                            Spacer(Modifier.width(4.dp))
                            FittedControlText(AppLanguage.text("🛒"), fontSize = 21.sp, maxLines = 1)
                        }
                    }
                    FittedControlText(AppLanguage.text("HELP / ABOUT"), modifier = Modifier.clickable(onClick = onClick).padding(vertical = if (phone) 1.dp else 3.dp), color = Color.White, fontSize = if (phone) 6.sp else 10.sp,
                        lineHeight = 9.sp, maxLines = 1, softWrap = false,
                        style = TextStyle(platformStyle = PlatformTextStyle(includeFontPadding = false)))
                }
            }
        }
    }
}

/** Original two-bar LOOP retained; the 12 legacy tricks are replaced by real-time PCM DSP. */
@Composable
private fun LiveRollMonsterLogo(compact: Boolean = false) {
    val motion = rememberInfiniteTransition(label = "rmLogo")
    val scale by motion.animateFloat(
        initialValue = 0.985f,
        targetValue = 1.015f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1700, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "rmLogoScale"
    )
    val lift by motion.animateFloat(
        initialValue = 0f,
        targetValue = -6f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2100, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "rmLogoLift"
    )
    val frameAlpha by motion.animateFloat(
        initialValue = 0.55f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "rmLogoGlow"
    )
    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(if (compact) 100.dp else 176.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF202522), Color(0xFF101311))
                    ),
                    RoundedCornerShape(18.dp)
                )
                .border(2.dp, MonsterGreen.copy(alpha = frameAlpha), RoundedCornerShape(18.dp))
                .padding(horizontal = 8.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                factory = { context ->
                    android.widget.ImageView(context).apply {
                        contentDescription = AppLanguage.text("Roll Monster live logo")
                        scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
                        if (Build.VERSION.SDK_INT >= 28) {
                            val source = android.graphics.ImageDecoder.createSource(
                                resources, R.drawable.roll_monster_header_logo
                            )
                            val logo = android.graphics.ImageDecoder.decodeDrawable(source)
                            setImageDrawable(logo)
                            (logo as? android.graphics.drawable.AnimatedImageDrawable)?.apply {
                                repeatCount = android.graphics.drawable.AnimatedImageDrawable.REPEAT_INFINITE
                                start()
                            }
                        } else {
                            setImageResource(R.drawable.roll_monster_header_logo)
                        }
                    }
                },
                onRelease = { view ->
                    (view.drawable as? android.graphics.drawable.Animatable)?.stop()
                    view.setImageDrawable(null)
                },
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .height(if (compact) 84.dp else 158.dp)
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationY = lift
                    )
            )
        }
    }
}

@Composable
private fun RollMonsterDialog(onDismiss: () -> Unit) {
    val filters = listOf("LPF", "HPF", "BAND PASS", "NOTCH", "3-BAND KILL", "TILT EQ")
    val rhythmic = listOf("BPM DELAY", "BPM FLANGER", "BPM PAN")
    val modern = listOf("PUMP", "BEAT GATE", "FREQUENCY\nSHIFTER")
    val modernColors = listOf(Color(0xFFBF79FF), Color(0xFF45DAED), Color(0xFFFFAD52))
    var bpm by remember { mutableIntStateOf(BreakPlaybackService.currentRollBpm()) }
    var selectedLoop by remember { mutableIntStateOf(-1) }
    var selectedFx by remember { mutableIntStateOf(-1) }
    var strength by remember { mutableFloatStateOf(.55f) }
    var subdivision by remember { mutableIntStateOf(1) }
    var status by remember { mutableStateOf("SELECT FILTER / LOOP") }
    var mixing by remember { mutableStateOf(BreakPlaybackService.snapshot.crossfading) }
    var autoMixing by remember { mutableStateOf(BreakPlaybackService.snapshot.autoMix) }
    var radioIsLive by remember { mutableStateOf(BreakPlaybackService.snapshot.trackUri?.let(::isRadioHttpUrl) == true) }
    var wasMixing by remember { mutableStateOf(mixing) }
    var strobeLit by remember { mutableStateOf(true) }
    LaunchedEffect(selectedLoop) {
        strobeLit = true
        while (selectedLoop >= 0) {
            kotlinx.coroutines.delay(140)
            strobeLit = !strobeLit
        }
        strobeLit = true
    }
    LaunchedEffect(Unit) {
        while (true) {
            val snapshot = BreakPlaybackService.snapshot
            mixing = snapshot.crossfading
            autoMixing = snapshot.autoMix
            radioIsLive = snapshot.trackUri?.let(::isRadioHttpUrl) == true
            if (radioIsLive && selectedLoop >= 0) { BreakPlaybackService.releaseRollEffect(); selectedLoop = -1 }
            bpm = BreakPlaybackService.currentRollBpm()
            if (mixing && selectedLoop >= 0) {
                selectedLoop = -1
                status = if (autoMixing) "WAIT · AUTO MIX" else "WAIT · MIX"
            }
            if (wasMixing && !mixing && selectedFx < 0) status = "SELECT FILTER / LOOP"
            wasMixing = mixing
            kotlinx.coroutines.delay(120)
        }
    }
    fun tapFx(index: Int) {
        if (selectedFx == index) {
            BreakPlaybackService.releaseLiveFx()
            selectedFx = -1
            status = "FILTER OFF · SONG CONTINUES"
        } else if (BreakPlaybackService.setLiveFx(index, strength, subdivision)) {
            selectedFx = index
            status = "${(filters + rhythmic + modern)[index].replace("\n", " ")} · LIVE PCM"
        } else {
            status = if (!BreakPlaybackService.snapshot.playing) "PLAY A SONG FIRST"
                else if (LiveFxAudioProcessor.needsTempo(index) && bpm !in 40..220) "WAIT · REAL BPM ANALYSIS"
                else "WAIT · PCM AUDIO"
        }
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        // Measure the usable dialog window first, then fit the entire 700x600
        // console. This measures controls at the fitted density, not just their
        // painted size; touch coordinates and the animated logo fit together.
        BoxWithConstraints(
            Modifier.fillMaxSize().safeDrawingPadding().padding(10.dp),
            contentAlignment = Alignment.Center
        ) {
            val natural = LocalDensity.current
            val fit = minOf(maxWidth.value / 700f, maxHeight.value / 600f, 1f)
            CompositionLocalProvider(LocalDensity provides Density(natural.density * fit, 1f)) {
                Column(
                    Modifier.size(width = 700.dp, height = 600.dp).background(Color(0xFF171A18), RoundedCornerShape(18.dp))
                        .border(2.dp, MonsterGreen, RoundedCornerShape(18.dp)).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(Modifier.fillMaxWidth().height(100.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.weight(1f)) { LiveRollMonsterLogo(compact = true) }
                        Column(Modifier.width(170.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            StoneButton(onClick = {
                                if (selectedLoop == 0) {
                                    BreakPlaybackService.releaseRollEffect()
                                    selectedLoop = -1
                                    status = "LOOP · EXIT AFTER 2 BARS"
                                } else if (mixing) {
                                    status = "WAIT · AUTO MIX"
                                } else if (BreakPlaybackService.setRollPreset(-1, 2.0)) {
                                    selectedLoop = 0
                                    status = "2 BAR LOOP · ARMED"
                                } else status = "WAIT · BPM / PCM"
                            }, modifier = Modifier.fillMaxWidth().height(66.dp),
                                active = selectedLoop == 0 && strobeLit, brightActive = true, enabled = !mixing && !radioIsLive) {
                                FittedControlText(AppLanguage.text("LOOP"), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
                            }
                            Text(AppLanguage.text(if (bpm in 40..220) "$bpm BPM" else "BPM: WAIT"), color = Amber,
                                fontSize = 20.sp, fontWeight = FontWeight.Black, maxLines = 1)
                        }
                    }
                    filters.chunked(3).forEachIndexed { row, group ->
                        Row(Modifier.fillMaxWidth().height(52.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            group.forEachIndexed { col, label ->
                                val index = row * 3 + col
                                StoneButton(onClick = { tapFx(index) }, modifier = Modifier.weight(1f).fillMaxHeight(),
                                    active = selectedFx == index, brightActive = true) {
                                    Text(AppLanguage.text(label), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black,
                                        maxLines = 1, softWrap = false)
                                }
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().height(52.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        rhythmic.forEachIndexed { i, label ->
                            StoneButton(onClick = { tapFx(i + 6) }, modifier = Modifier.weight(1f).fillMaxHeight(),
                                active = selectedFx == i + 6, brightActive = true) {
                                Text(AppLanguage.text(label), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Black,
                                    maxLines = 1, softWrap = false)
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().height(60.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        modern.forEachIndexed { i, label ->
                            val tint = modernColors[i]
                            val active = selectedFx == i + 9
                            Box(Modifier.weight(1f).fillMaxHeight()
                                .background(if (active) tint else tint.copy(alpha = .18f), RoundedCornerShape(10.dp))
                                .border(if (active) 3.dp else 2.dp, tint, RoundedCornerShape(10.dp))
                                .clickable { tapFx(i + 9) }
                                .semantics { contentDescription = label.replace("\n", " ") },
                                contentAlignment = Alignment.Center) {
                                Text(AppLanguage.text(label), color = if (active) Color.Black else tint, fontSize = 19.sp,
                                    lineHeight = 21.sp, fontWeight = FontWeight.Black, maxLines = 2,
                                    textAlign = TextAlign.Center)
                            }
                        }
                    }
                    val controlLabel = when (selectedFx) {
                        in 0..3 -> "FREQUENCY"
                        4 -> when { strength < .25f -> "BASS KILL"; strength < .75f -> "MID KILL"; else -> "HIGH KILL" }
                        5 -> when { strength < .475f -> "WARM / BASS"; strength > .525f -> "BRIGHT / TREBLE"; else -> "NEUTRAL" }
                        11 -> "SHIFT ${((strength - .5f) * 1600f).toInt()} Hz"
                        else -> "EFFECT DEPTH"
                    }
                    Text(controlLabel, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.height(24.dp), maxLines = 1)
                    Slider(value = strength, onValueChange = { value ->
                        strength = value
                        if (selectedFx >= 0) BreakPlaybackService.setLiveFx(selectedFx, value, subdivision)
                    }, modifier = Modifier.fillMaxWidth().height(48.dp))
                    Row(Modifier.fillMaxWidth().height(48.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("¼", "⅛", "¹⁄₁₆").forEachIndexed { index, label ->
                            StoneButton(onClick = {
                                subdivision = index
                                if (selectedFx >= 0) BreakPlaybackService.setLiveFx(selectedFx, strength, subdivision)
                            }, modifier = Modifier.weight(1f).fillMaxHeight(), active = subdivision == index, brightActive = true) {
                                Text(AppLanguage.text(label), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                    Text(AppLanguage.text(if (mixing) (if (autoMixing) "LOOP WAIT · AUTO MIX" else "LOOP WAIT · MIX") else status),
                        color = Amber, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, modifier = Modifier.height(24.dp))
                    StoneButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth().height(44.dp)) {
                        FittedControlText(AppLanguage.text("EXIT"), color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }
    }
}

@Composable
private fun PlaylistBackupDialogs(
    store: BreakPlaylistStore,
    visible: Boolean,
    busy: MutableState<Boolean>,
    onDismiss: () -> Unit,
    onRestored: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var restoreBackupConfirm by remember { mutableStateOf(false) }
    var backupBusy by busy
    var backupSnapshot by remember { mutableStateOf<org.json.JSONObject?>(null) }
    val backupFolderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        val snapshot = backupSnapshot
        backupSnapshot = null
        if (uri != null && snapshot != null) scope.launch {
            backupBusy = true
            var created: androidx.documentfile.provider.DocumentFile? = null
            try {
                val output = withContext(Dispatchers.IO) {
                    val folder = checkNotNull(androidx.documentfile.provider.DocumentFile.fromTreeUri(context, uri))
                    val stamp = java.text.SimpleDateFormat("yyyyMMdd-HHmmss", java.util.Locale.US).format(java.util.Date())
                    checkNotNull(folder.createFile("application/zip", "BrakeMonster_Backup_All_$stamp.zip")) { "Cannot create ZIP in this folder" }
                }
                created = output
                PlaylistBackup.write(context, output.uri, snapshot)
                uiToast(context, "BACKUP ALL SAVED", Toast.LENGTH_LONG).show()
            } catch (error: Exception) {
                withContext(Dispatchers.IO) { runCatching { created?.delete() } }
                uiToast(context, "BACKUP FAILED: ${error.message}", Toast.LENGTH_LONG).show()
            } finally { backupBusy = false }
        }
    }
    val backupRestorePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            backupBusy = true
            var prepared: PlaylistBackup.Prepared? = null
            var committed = false
            try {
                val ready = PlaylistBackup.read(context, uri)
                prepared = ready
                BreakPlaybackService.stop(context)
                store.restoreBackup(ready.snapshot)
                committed = true
                onRestored()
                uiToast(context, "ALL PLAYLISTS RESTORED", Toast.LENGTH_LONG).show()
            } catch (error: Exception) {
                if (!committed) withContext(Dispatchers.IO) { prepared?.directory?.deleteRecursively() }
                uiToast(context, "RESTORE FAILED: ${error.message}", Toast.LENGTH_LONG).show()
            } finally { backupBusy = false }
        }
    }
    if (visible && !backupBusy) AlertDialog(onDismissRequest=onDismiss,
        title={FittedControlText(AppLanguage.text("BACKUP ALL"), fontWeight=FontWeight.Black)},
        text={Text(AppLanguage.text("Save all playlists, QUEUE, song order and BMQ files in one ZIP. Local audio used by playlists is included. Choose a folder to keep the backup."), fontSize=18.sp)},
        confirmButton={TextButton(onClick={
            onDismiss(); backupSnapshot=store.backupSnapshot(); backupFolderPicker.launch(null)
        }) { FittedControlText(AppLanguage.text("SAVE ZIP"), fontWeight=FontWeight.Bold) }},
        dismissButton={Row {
            TextButton(onClick={onDismiss();restoreBackupConfirm=true}) { FittedControlText(AppLanguage.text("LOAD BACKUP")) }
            TextButton(onClick=onDismiss) { FittedControlText(AppLanguage.text("CANCEL")) }
        }})
    if (restoreBackupConfirm) AlertDialog(onDismissRequest={restoreBackupConfirm=false},
        title={FittedControlText(AppLanguage.text("RESTORE ALL PLAYLISTS"), fontWeight=FontWeight.Black)},
        text={Text(AppLanguage.text("Loading this backup replaces the current playlists and QUEUE with the saved lists and order. Playback stops after the ZIP is checked."), fontSize=18.sp)},
        confirmButton={TextButton(onClick={restoreBackupConfirm=false;backupRestorePicker.launch(arrayOf("application/zip", "application/octet-stream"))}) { FittedControlText(AppLanguage.text("CHOOSE BACKUP ZIP")) }},
        dismissButton={TextButton(onClick={restoreBackupConfirm=false}) { FittedControlText(AppLanguage.text("CANCEL")) }})
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BreakPlaylistPanel(
    loadingPlaylists: Set<String>,
    zipImportBusy: Boolean,
    fullBrowser: Boolean,
    store: BreakPlaylistStore, selected: Int, onSelected:(Int)->Unit,
    queueSelectionMode:Boolean, onQueueTap:()->Unit, onExportQueue:(String)->Int?,
    random:Boolean, repeat:Boolean, onRandom:()->Unit, onRepeat:()->Unit,
    localQuery:String, onCreatePlaylist:(String)->Unit,
    showHint:Boolean, onGestureLearned:()->Unit, showReorderHint:Boolean, onReorderGestureLearned:()->Unit, onSwipeRemoved:(Int)->Unit,
    onPlay:(String)->Unit, onImportPlaylist:()->Unit, onImportZipAt:(Int)->Unit, playingUri:String?, playingPlaylistContext:String?, focusUri:String?,
    songTextSize: MutableFloatState,
    playlistSearchOpen: Boolean, onSearchPlaylists: () -> Boolean,
    xlSearchControls: XlSearchControls, onOpenLocalFiles: () -> Unit,
    xlUiState: XlPlaylistUiState,
    onPlayRadio: (RadioStation) -> Unit
) {
    var radioHubOpen by remember { mutableStateOf(false) }
    val playlistSongRowHeight = songRowHeight(songTextSize.floatValue, local = false)
    val rowScale = songRowControlScale(songTextSize.floatValue, defaultSize = 23f)
    val marked = remember(selected){ mutableStateListOf<String>() }
    val flashing = remember(selected){ mutableStateListOf<String>() }
    val scope = rememberCoroutineScope()
    val context= LocalContext.current
    val favorites = remember(context) { RadioFavoritesStore.shared(context) }
    val listState = rememberLazyListState()
    val visibleEntries = store.lists[selected]
    // Keep the currently playing entry centered after every track change, including shuffle.
    LaunchedEffect(playingUri, playingPlaylistContext, selected, visibleEntries.size) {
        if (playingPlaylistContext == store.playbackContext(selected)) {
            val activeIndex = visibleEntries.indexOfFirst { it.uri == playingUri }
            if (activeIndex >= 0) {
                listState.scrollToItem(activeIndex)
                val layout = listState.layoutInfo
                val row = layout.visibleItemsInfo.firstOrNull { it.index == activeIndex }
                if (row != null) {
                    val center = (layout.viewportStartOffset + layout.viewportEndOffset) / 2
                    listState.scrollBy(-(center - row.size / 2).coerceAtLeast(0).toFloat())
                }
            }
        }
    }
    var draggingUri by remember(selected) { mutableStateOf<String?>(null) }
    var dragOffsetY by remember(selected) { mutableFloatStateOf(0f) }
    var lastAutoScrollAt by remember { mutableLongStateOf(0L) }
    var createPlaylist by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var entryMenu by remember { mutableStateOf<BreakPlaylistEntry?>(null) }
    var entryRename by remember { mutableStateOf<BreakPlaylistEntry?>(null) }
    var entryRenameText by remember { mutableStateOf("") }
    var entryMove by remember { mutableStateOf<BreakPlaylistEntry?>(null) }
    var entryDelete by remember { mutableStateOf<BreakPlaylistEntry?>(null) }
    var deletePlaylistConfirm by remember { mutableStateOf(false) }
    var exportDialog by remember { mutableStateOf(false) }
    var exportName by remember { mutableStateOf("") }
    var exportError by remember { mutableStateOf("") }
    var saveQueueDialog by remember { mutableStateOf(false) }
    var saveQueueName by remember { mutableStateOf("") }
    var saveQueueError by remember { mutableStateOf("") }
    var queueOptions by remember { mutableStateOf(false) }
    var clearQueueConfirm by remember { mutableStateOf(false) }
    var moveFromQueue by remember { mutableStateOf<BreakPlaylistEntry?>(null) }
    var moveError by remember { mutableStateOf("") }
    var mergeMode by remember { mutableStateOf(false) }
    var mergeNaming by remember { mutableStateOf(false) }
    val mergeSelection = remember { mutableStateListOf<Int>() }
    var mergeName by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().background(Color.Transparent)) {
        // Keep the XL chooser in composition on QUEUE (the default HOME tab).
        // Keep the ordinary horizontal stone row visible on QUEUE too, so
        // the other playlists are always one tap away during QUEUE playback.
        BreakPlaylistTabs(store, selected, onSelected, onImportPlaylist, onImportZipAt,
            onOpenRadio = { radioHubOpen = true }, loadingPlaylists = loadingPlaylists,
            playlistSearchOpen = playlistSearchOpen, onSearchPlaylists = onSearchPlaylists,
            xlSearchControls = xlSearchControls,
            onQueueTap = onQueueTap, onOpenLocalFiles = onOpenLocalFiles,
            xlUiState = xlUiState,
            fullBrowser = fullBrowser,
            showNormalTabs = true,
            mergeMode = mergeMode, mergeSelection = mergeSelection,
            onMergePick = { index -> if(index in mergeSelection) mergeSelection.remove(index) else mergeSelection.add(index) })
        if (mergeMode) {
            FittedControlText(AppLanguage.text("SELECT PLAYLISTS TO MERGE"), color=Color.White, fontWeight=FontWeight.Black, modifier=Modifier.padding(8.dp))
            Text(mergeSelection.joinToString(" + ") { playlistUiName(store, it) }.ifBlank { "Choose at least two stone playlists" }, color=MonsterGreen, modifier=Modifier.padding(horizontal=8.dp))
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly) {
                Button(onClick={ mergeName=""; mergeNaming=true }, enabled=mergeSelection.size>=2){ FittedControlText(AppLanguage.text("MERGE")) }
                TextButton(onClick={mergeMode=false;mergeSelection.clear()}){FittedControlText(AppLanguage.text("CANCEL"))}
            }
        }
        val inQueue = selected == store.queueIndex
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val compactToolbar = maxWidth < 560.dp
            val controlHeight = if (inQueue) 42.dp else 46.dp
            val gap = if (compactToolbar) 1.dp else 5.dp
            val labelSize = if (maxWidth < 350.dp) 9.sp else if (compactToolbar) 11.sp else 14.sp
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(gap)
            ) {
                val control = Modifier.weight(1f).height(controlHeight)
                PlaylistStoneButton(onClick = onRandom, active = random, modifier = control,
                    contentPadding = 2.dp) {
                    ShuffleGlyph(crossed = random, Modifier.size(if (compactToolbar) 18.dp else 27.dp),
                        if (random) MonsterGreen else Color.White)
                }
                PlaylistStoneButton(onClick = onRepeat, active = repeat, modifier = control,
                    contentPadding = 2.dp) {
                    StoneLabel("↻", if (repeat) MonsterGreen else Color.White, 16.sp)
                }
                if (inQueue) {
                    PlaylistStoneButton(onClick = { queueOptions = true }, modifier = control,
                        contentPadding = 2.dp) {
                        ToolbarStoneLabel("CLEAR", MonsterGreen, labelSize)
                    }
                    PlaylistStoneButton(onClick = { saveQueueError = ""; saveQueueName = ""; saveQueueDialog = true },
                        queueTone = true, contentPadding = 2.dp,
                        modifier = Modifier.weight(1.65f).height(controlHeight)
                            .semantics { contentDescription = AppLanguage.text("SAVE AS PL") }) {
                        ToolbarStoneLabel("SAVE AS PL", Color.White, labelSize)
                    }
                } else {
                    PlaylistStoneButton(onClick = { createPlaylist = true }, modifier = control,
                        contentPadding = 2.dp) {
                        StoneLabel("＋", Color.White, 16.sp)
                    }
                    PlaylistStoneButton(onClick = { mergeMode = true; mergeSelection.clear(); mergeNaming = false },
                        active = mergeMode, modifier = control, contentPadding = 2.dp) {
                        ToolbarStoneLabel("MERGE", Color.White, labelSize)
                    }
                    PlaylistStoneButton(onClick = { if (!zipImportBusy) onImportZipAt(-2) }, modifier = control,
                        active = zipImportBusy, contentPadding = 2.dp) {
                        if (zipImportBusy) WaitStoneLabel(labelSize) else ToolbarStoneLabel("⇩ PL", Color.White, labelSize)
                    }
                }
            }
        }

        val context = LocalContext.current
        val gesturePrefs = remember { context.getSharedPreferences("breakmonster_ui", 0) }
        var swipeDemo by remember { mutableStateOf(false) }
        LaunchedEffect(selected, queueSelectionMode) {
            if(!queueSelectionMode && selected!=store.queueIndex && !gesturePrefs.getBoolean("playlistSwipeRightHintDone",false)) {
                swipeDemo = true
                try {
                    delay(2600)
                    gesturePrefs.edit().putBoolean("playlistSwipeRightHintDone", true).apply()
                } finally {
                    swipeDemo = false
                }
            }
        }
        if(swipeDemo) {
            val transition=androidx.compose.animation.core.rememberInfiniteTransition(label="swipe-right-demo")
            val slide by transition.animateFloat(initialValue=0f,targetValue=54f,animationSpec=androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(500),androidx.compose.animation.core.RepeatMode.Reverse),label="swipe-right")
            Row(Modifier.fillMaxWidth().height(34.dp).padding(horizontal=12.dp),verticalAlignment=Alignment.CenterVertically) {
                FittedControlText(AppLanguage.text("SWIPE RIGHT TO REMOVE"),color=Amber,fontSize=13.sp,fontWeight=FontWeight.Black,modifier=Modifier.weight(1f))
                Text(AppLanguage.text("♪  SONG  →"),color=Color.White,fontSize=13.sp,fontWeight=FontWeight.Bold,modifier=Modifier.graphicsLayer { translationX=slide }.background(Color(0xAA113B25),RoundedCornerShape(7.dp)).border(1.dp,MonsterGreen.copy(alpha=.55f),RoundedCornerShape(7.dp)).padding(horizontal=10.dp,vertical=4.dp))
            }
        }
        if(mergeMode) Spacer(Modifier.height(2.dp))
        if(showHint && !mergeMode) GestureManual(R.drawable.playlist_gesture_hint, Modifier.fillMaxWidth().height(150.dp).padding(vertical=4.dp))
        if(showReorderHint && store.lists[selected].size>1) ReorderGestureHelp(Modifier.fillMaxWidth().height(42.dp))
        // Separate the playlist/QUEUE controls from song rows. The SAVE AS PL
        // overlay is anchored to the parent Box, not to this scrolling list.
        Spacer(Modifier.height(20.dp))
        SongListArea {
        LazyColumn(Modifier.fillMaxSize().then(if(mergeMode) Modifier.graphicsLayer { alpha=0.22f } else Modifier).background(if(selected==store.queueIndex) Brush.verticalGradient(listOf(Color(0x665B3B05),Color(0x333A2708),Color.Transparent)) else Brush.verticalGradient(listOf(Color.Transparent,Color.Transparent))), state=listState, contentPadding=PaddingValues(bottom = if(selected==store.queueIndex) 110.dp else 0.dp)) {
            itemsIndexed(visibleEntries, key={_,e->e.uri}) { index,e ->
                val isDragging = draggingUri == e.uri
                Row(Modifier.fillMaxWidth().height(playlistSongRowHeight)
                    .graphicsLayer { translationY = if(isDragging) dragOffsetY else 0f }
                    .zIndex(if(isDragging) 1f else 0f)
                    .background(if(queueSelectionMode) { if(store.isInQueue(e.uri)) Amber.copy(alpha=.40f) else Color(0xB30A2417) } else if(e.uri in flashing) MonsterGreen.copy(alpha=.55f) else if(playingPlaylistContext == store.playbackContext(selected) && e.uri == playingUri) Amber.copy(alpha=.5f) else Color.Transparent)
                    .pointerInput(e.uri,selected,queueSelectionMode,e.sourceKind) {
                        if(selected==store.queueIndex || (!queueSelectionMode && selected!=store.queueIndex)) {
                            var totalX=0f
                            detectHorizontalDragGestures(
                                onHorizontalDrag={ change, amount -> totalX+=amount; change.consume() },
                                onDragEnd={ if(totalX >= 96.dp.toPx()) {
                                    if(selected==store.queueIndex) {
                                        if(e.sourceKind=="SEARCH_SAVE") { moveFromQueue=e; moveError="" }
                                        else { store.removeUris(store.queueIndex,setOf(e.uri)); onSwipeRemoved(store.queueIndex+1) }
                                    } else {
                                        store.removeUris(selected, setOf(e.uri))
                                        gesturePrefs.edit().putBoolean("playlistSwipeRightHintDone", true).apply()
                                        swipeDemo = false
                                        onGestureLearned()
                                        onSwipeRemoved(selected + 1)
                                    }
                                } },
                                onDragCancel={ totalX=0f }
                            )
                        }
                    }
                    .pointerInput(e.uri,selected,localQuery) {
                        var lastTarget: String? = null
                        detectDragGesturesAfterLongPress(
                            onDragStart = { draggingUri=e.uri; dragOffsetY=0f; lastTarget=null },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                dragOffsetY += dragAmount.y
                                val layout=listState.layoutInfo
                                val active=layout.visibleItemsInfo.firstOrNull { it.key==e.uri }
                                if(active!=null) {
                                    val center=active.offset+dragOffsetY+active.size/2f
                                    val neighbors=layout.visibleItemsInfo.filter { it.key is String && it.key!=e.uri }
                                    val target=neighbors.minByOrNull { kotlin.math.abs(center-(it.offset+it.size/2f)) }
                                    if(target!=null && target.key is String) {
                                        val targetCenter=target.offset+target.size/2f
                                        val movingUp=target.index<active.index
                                        val crossed=if(movingUp) center<targetCenter else center>targetCenter
                                        val targetUri=target.key as String
                                        if(crossed && targetUri!=lastTarget && store.moveRelative(selected,e.uri,targetUri,after=!movingUp)) {
                                            dragOffsetY += if(movingUp) target.size.toFloat() else -target.size.toFloat()
                                            lastTarget=targetUri
                                            onReorderGestureLearned()
                                        }
                                    }
                                    val edge=56f
                                    val now=SystemClock.elapsedRealtime()
                                    if(now-lastAutoScrollAt>70L && center<layout.viewportStartOffset+edge) {
                                        lastAutoScrollAt=now; scope.launch { listState.scrollBy(-24f) }
                                    } else if(now-lastAutoScrollAt>70L && center>layout.viewportEndOffset-edge) {
                                        lastAutoScrollAt=now; scope.launch { listState.scrollBy(24f) }
                                    }
                                }
                            },
                            onDragEnd = { draggingUri=null; dragOffsetY=0f },
                            onDragCancel = { draggingUri=null; dragOffsetY=0f }
                        )
                    }
                    .clickable {
                        if(queueSelectionMode && selected==store.queueIndex) Unit // QUEUE is a review screen, never toggle its rows during selection.
                        else if(queueSelectionMode && !e.missing) store.toggleQueueEntry(e.copy(sourceKind="USER_PLAYLIST",sourcePlaylistIndex=selected,sourceContext=store.playbackContext(selected)))
                        else if(marked.isNotEmpty()) { if(e.uri in marked) marked.remove(e.uri) else marked.add(e.uri) }
                        else if(!e.missing) onPlay(e.uri)
                    }
                    .padding(start = 12.dp, end = SongControlWidth + 4.dp, top = 3.dp, bottom = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    // BMR stations use a 1950s radio badge instead of song numbers.
                    // Ordinary BMQ / LOCAL / WEB entries retain their original ordinals.
                    if (e.isRadioStation()) {
                        Box(
                            modifier = Modifier.width(34.dp * rowScale)
                                .padding(end = 5.dp * rowScale),
                            contentAlignment = Alignment.Center
                        ) {
                            RadioStationBadge(Modifier.size(30.dp * rowScale))
                        }
                    } else {
                        val ordinal = "${index + 1}."
                        Text(
                            ordinal, color = MonsterGreen, fontSize = (19f * rowScale).sp,
                            fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false,
                            style = TextStyle(platformStyle = PlatformTextStyle(includeFontPadding = false)),
                            modifier = Modifier.widthIn(min = 34.dp * rowScale)
                                .padding(end = 5.dp * rowScale)
                        )
                    }
                    MarqueeFilenameText(e.name.replace(Regex("^\\d{4}[_\\s-]+"), ""), Modifier.weight(1f), Color.White, songTextSize.floatValue.sp, FontWeight.SemiBold,
                        TextStyle(lineHeight=songTextSize.floatValue.sp,platformStyle=PlatformTextStyle(includeFontPadding=false)))
                    // Keep the missing-file warning; successful matches need no row label.
                    if(e.missing) { FittedControlText(AppLanguage.text("MISSING"),color=Color(0xFFFF8A80),fontSize=12.sp,fontWeight=FontWeight.Black,maxLines=1) }
                    Spacer(Modifier.width(5.dp))
                    if (e.isRadioStation()) {
                        val isFavorite = favorites.contains(e.uri)
                        Box(Modifier.size(37.dp * rowScale).clickable {
                            if (!isFavorite) favorites.add(RadioStation(e.sourceContext, e.name, e.uri))
                            // Removing a starred favorite happens only in RADIO with ARE YOU SURE.
                        }, contentAlignment = Alignment.Center) {
                            Text(if (isFavorite) "★" else "☆", color = Color(0xFFFFBE46), fontSize = (29f * rowScale).sp,
                                fontWeight = FontWeight.Black)
                        }
                    } else Box(Modifier.width(84.dp * rowScale).height(28.dp * rowScale).background(Color(0xFF00BFC4),RoundedCornerShape(6.dp)).clickable { entryMenu=e },contentAlignment=Alignment.Center) {
                        FittedControlText(AppLanguage.text("EDIT"),color=Color.White,fontSize=(12f * rowScale).sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(horizontal=4.dp))
                    }
                    if (e.isRadioStation()) Unit
                    else if(e.youtube){Spacer(Modifier.width(5.dp));YouTubeBadge(Modifier.size(34.dp * rowScale))}
                    else {Spacer(Modifier.width(5.dp));MediaTypeBadge(Uri.parse(e.uri).lastPathSegment.orEmpty().substringAfterLast('.', ""), rowScale)}
                }
                HorizontalDivider(color=Color.White.copy(alpha=.05f))
            }
        }
        }
    }

    }
    if (radioHubOpen) RadioHub(onClose = { radioHubOpen = false }, onPlay = onPlayRadio)
    if(entryMenu != null) {
        val entry = entryMenu!!
        AlertDialog(onDismissRequest={entryMenu=null}, title={Text(entry.name, maxLines=2)},
            text={Column {
                TextButton(onClick={entryRename=entry;entryRenameText=entry.name;entryMenu=null}){FittedControlText(AppLanguage.text("RENAME"))}
                TextButton(onClick={entryMove=entry;entryMenu=null}){FittedControlText(AppLanguage.text("MOVE TO…"))}
                TextButton(onClick={entryDelete=entry;entryMenu=null}){FittedControlText(AppLanguage.text("DELETE"),color=Color.Red)}
            }}, confirmButton={TextButton(onClick={entryMenu=null}){FittedControlText(AppLanguage.text("CANCEL"))}})
    }
    if(entryRename != null) AlertDialog(onDismissRequest={entryRename=null}, title={FittedControlText(AppLanguage.text("RENAME"))},
        text={OutlinedTextField(entryRenameText,{entryRenameText=it.take(120)},singleLine=true)},
        confirmButton={TextButton(onClick={store.renameEntry(selected,entryRename!!.uri,entryRenameText);entryRename=null}){FittedControlText(AppLanguage.text("SAVE"))}},
        dismissButton={TextButton(onClick={entryRename=null}){FittedControlText(AppLanguage.text("CANCEL"))}})
    if(entryMove != null) AlertDialog(onDismissRequest={entryMove=null}, title={FittedControlText(AppLanguage.text("MOVE TO…"))},
        text={Column(Modifier.heightIn(max=360.dp).verticalScroll(rememberScrollState())) {
            store.availableIndices().filter{it!=selected}.forEach { destination ->
                TextButton(onClick={
                    val entry=entryMove!!
                    if(store.moveEntryTo(selected,destination,entry.uri)) uiToast(context,"MOVED TO ${playlistUiName(store, destination)}",Toast.LENGTH_SHORT).show()
                    else uiToast(context,"ALREADY IN ${playlistUiName(store, destination)}",Toast.LENGTH_SHORT).show()
                    entryMove=null
                }){Text(playlistUiName(store, destination),fontSize=19.sp)}
            }
        }}, confirmButton={TextButton(onClick={entryMove=null}){FittedControlText(AppLanguage.text("CANCEL"))}})
    if(entryDelete != null) AlertDialog(onDismissRequest={entryDelete=null},title={FittedControlText(AppLanguage.text("REMOVE FROM PLAYLIST?"))},
        text={Text(AppLanguage.text("Original media file will not be deleted."))},
        confirmButton={TextButton(onClick={store.removeUris(selected,setOf(entryDelete!!.uri));entryDelete=null}){FittedControlText(AppLanguage.text("DELETE"),color=Color.Red)}},
        dismissButton={TextButton(onClick={entryDelete=null}){FittedControlText(AppLanguage.text("CANCEL"))}})
    if(deletePlaylistConfirm) AlertDialog(
        onDismissRequest={deletePlaylistConfirm=false},
        title={FittedControlText(AppLanguage.text("ARE YOU SURE?"),fontWeight=FontWeight.Black)},
        text={Text(AppLanguage.text(if(marked.isNotEmpty()) "Delete the selected songs from ${playlistUiName(store, selected)}? Original media files will stay untouched." else "Delete playlist ${playlistUiName(store, selected)}? Media files will stay untouched."))},
        confirmButton={TextButton(onClick={
            if(marked.isNotEmpty()) { store.removeUris(selected,marked.toSet()); marked.clear() }
            else { if(store.delete(selected)) onSelected(store.activeIndex) else uiToast(context,"Playlist could not be deleted",Toast.LENGTH_LONG).show() }
            deletePlaylistConfirm=false
        }){FittedControlText(AppLanguage.text("YES"))}},
        dismissButton={TextButton(onClick={deletePlaylistConfirm=false}){FittedControlText(AppLanguage.text("CANCEL"))}}
    )
    if(queueOptions) AlertDialog(onDismissRequest={queueOptions=false},title={FittedControlText(AppLanguage.text("QUEUE OPTIONS"),fontWeight=FontWeight.Black)},text={Column {
        TextButton(onClick={queueOptions=false;clearQueueConfirm=true}) { FittedControlText(AppLanguage.text("CLEAR QUEUE"),fontWeight=FontWeight.Bold) }
        TextButton(onClick={queueOptions=false;exportError="";exportName="";exportDialog=true}) { FittedControlText(AppLanguage.text("EXPORT AS PLAYLIST"),fontWeight=FontWeight.Bold) }
    }},confirmButton={})
    if(clearQueueConfirm) AlertDialog(onDismissRequest={clearQueueConfirm=false},title={FittedControlText(AppLanguage.text("ARE YOU SURE?"),fontWeight=FontWeight.Black)},text={Text(AppLanguage.text("Clear all QUEUE entries? Original files and playlists will stay untouched."))},confirmButton={TextButton(onClick={
        if(store.clearQueue()) uiToast(context,"QUEUE CLEARED",Toast.LENGTH_SHORT).show() else uiToast(context,"Could not save the empty QUEUE.",Toast.LENGTH_LONG).show()
        clearQueueConfirm=false
    }){FittedControlText(AppLanguage.text("YES"))}},dismissButton={TextButton(onClick={clearQueueConfirm=false}){FittedControlText(AppLanguage.text("CANCEL"))}})
    if(moveFromQueue!=null) AlertDialog(onDismissRequest={moveFromQueue=null;moveError=""},title={FittedControlText(AppLanguage.text("MOVE TO PLAYLIST"),fontWeight=FontWeight.Black)},text={Column {
        Column(Modifier.fillMaxWidth().heightIn(max=380.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            store.availableIndices().filter { it!=store.queueIndex }.forEach { destination ->
                PlaylistStoneButton(onClick={
                    val moving=moveFromQueue!!
                    if(store.moveSearchSaveFromQueue(moving,destination)) { moveFromQueue=null;moveError="";uiToast(context,"MOVED TO ${playlistUiName(store, destination)}",Toast.LENGTH_SHORT).show() }
                    else moveError="Move failed. The song remains in QUEUE."
                },modifier=Modifier.fillMaxWidth().height(46.dp)) { Text(playlistUiName(store, destination),color=Color.White,fontWeight=FontWeight.Black,maxLines=1,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth()) }
            }
        }
        if(moveError.isNotBlank()) Text(moveError,color=Color(0xFFFF8A80),fontSize=15.sp)
    }},confirmButton={TextButton(onClick={moveFromQueue=null;moveError=""}){FittedControlText(AppLanguage.text("CANCEL"))}})
    if(mergeNaming) AlertDialog(
        onDismissRequest={mergeNaming=false},
        title={FittedControlText(AppLanguage.text("NEW MERGED PLAYLIST"))},
        text={OutlinedTextField(mergeName,{mergeName=it.take(24)},singleLine=true,label={FittedControlText(AppLanguage.text("Name"))})},
        confirmButton={TextButton(enabled=mergeName.isNotBlank(),onClick={
            val sources=mergeSelection.distinct().filter { it in store.lists.indices && it!=store.queueIndex && !store.isPinnedTab(it) }.sorted()
            if(sources.size>=2) {
                val combined=sources.flatMap { store.lists[it].toList() }
                // Create first: only playlist references are removed; original media files are never deleted.
                val newIndex=store.createImported(mergeName.trim(),combined)
                val newId=store.playbackContext(newIndex)
                sources.asReversed().forEach { store.delete(it) }
                val resulting=(0 until store.size).firstOrNull { store.playbackContext(it)==newId }
                if(resulting!=null) { store.activate(resulting);onSelected(resulting) }
            }
            mergeNaming=false;mergeMode=false;mergeSelection.clear()
        }){FittedControlText(AppLanguage.text("DONE"))}},
        dismissButton={TextButton(onClick={mergeNaming=false}){FittedControlText(AppLanguage.text("CANCEL"))}}
    )
    if(createPlaylist) AlertDialog(onDismissRequest={createPlaylist=false},title={FittedControlText(AppLanguage.text("ADD NEW PL"),fontWeight=FontWeight.Black)},text={OutlinedTextField(newName,{newName=it.take(24)},singleLine=true,label={FittedControlText(AppLanguage.text("Playlist name"))})},confirmButton={TextButton(onClick={onCreatePlaylist(newName);newName="";createPlaylist=false}){FittedControlText(AppLanguage.text("CREATE"))}},dismissButton={TextButton(onClick={createPlaylist=false}){FittedControlText(AppLanguage.text("CANCEL"))}})
    if(saveQueueDialog) AlertDialog(
        onDismissRequest = { saveQueueDialog = false },
        title = { FittedControlText(AppLanguage.text("SAVE AS PL"), fontWeight = FontWeight.Black) },
        text = {
            Column {
                Text(AppLanguage.text("Save a copy of all QUEUE tracks. QUEUE and playback stay unchanged."), fontSize = 16.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = saveQueueName,
                    onValueChange = { saveQueueName = it.take(24); saveQueueError = "" },
                    singleLine = true,
                    label = { FittedControlText(AppLanguage.text("Playlist name")) }
                )
                if (saveQueueError.isNotBlank()) Text(saveQueueError, color = Color(0xFFFF8A80), fontSize = 15.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val name = saveQueueName.trim()
                when {
                    store.lists[store.queueIndex].isEmpty() -> saveQueueError = "QUEUE is empty."
                    name.isBlank() -> saveQueueError = "Enter a playlist name."
                    store.availableIndices().any { playlistUiName(store, it).equals(name, true) } ->
                        saveQueueError = "That name already exists."
                    else -> {
                        val created = store.saveQueueAsPlaylist(name)
                        if (created == null) saveQueueError = "Could not save. QUEUE remains unchanged."
                        else {
                            uiToast(context, "SAVED ${playlistUiName(store, created)}", Toast.LENGTH_LONG).show()
                            saveQueueDialog = false
                            saveQueueName = ""
                            saveQueueError = ""
                        }
                    }
                }
            }) { FittedControlText(AppLanguage.text("SAVE"), fontWeight = FontWeight.Black) }
        },
        dismissButton = { TextButton(onClick = { saveQueueDialog = false }) { FittedControlText(AppLanguage.text("CANCEL")) } }
    )
    if(exportDialog) AlertDialog(onDismissRequest={exportDialog=false},title={FittedControlText(AppLanguage.text("EXPORT AS PL"),fontWeight=FontWeight.Black)},text={Column {
        OutlinedTextField(exportName,{exportName=it.take(24);exportError=""},singleLine=true,label={FittedControlText(AppLanguage.text("Playlist name"))})
        if(exportError.isNotBlank()) Text(exportError,color=Color(0xFFFF8A80),fontSize=15.sp)
    }},confirmButton={TextButton(onClick={
        val clean=exportName.trim()
        when {
            store.lists[store.queueIndex].isEmpty() -> exportError="QUEUE is empty."
            clean.isBlank() -> exportError="Enter a playlist name."
            store.availableIndices().any { playlistUiName(store, it).equals(clean,true) } -> exportError="That name already exists. Choose another."
            else -> {
                val created=onExportQueue(clean)
                if(created!=null) { onSelected(created); exportName=""; exportError=""; exportDialog=false; uiToast(context,"EXPORTED TO ${playlistUiName(store, created)}",Toast.LENGTH_LONG).show() }
                else exportError="Export failed. QUEUE has been preserved."
            }
        }
    }){FittedControlText(AppLanguage.text("EXPORT"))}},dismissButton={TextButton(onClick={exportDialog=false}){FittedControlText(AppLanguage.text("CANCEL"))}})
}

@Composable
private fun XlFixedSearchField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    blinkAlpha: State<Float>,
    onSearch: () -> Unit
) {
    val fontScale = LocalDensity.current.fontScale.coerceAtLeast(1f)
    Row(Modifier.fillMaxWidth().height((62f * fontScale).dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        SearchInputField(value = value, onValueChange = onValueChange,
            placeholder = placeholder, blinkAlpha = blinkAlpha, onSearch = onSearch,
            modifier = Modifier.weight(1f).fillMaxHeight())
        PlaylistStoneButton(onClick = onSearch,
            modifier = Modifier.width(58.dp).fillMaxHeight()
                .semantics { contentDescription = "Submit $placeholder" }) {
            Canvas(Modifier.size(26.dp)) {
                val center = androidx.compose.ui.geometry.Offset(size.width * .4f, size.height * .4f)
                drawCircle(Color.White, radius = size.minDimension * .27f, center = center,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.5.dp.toPx()))
                drawLine(Color.White,
                    androidx.compose.ui.geometry.Offset(size.width * .6f, size.height * .6f),
                    androidx.compose.ui.geometry.Offset(size.width * .9f, size.height * .9f),
                    strokeWidth = 3.dp.toPx())
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BreakPlaylistTabs(store: BreakPlaylistStore, selected:Int, onSelected:(Int)->Unit, onImportPlaylist:()->Unit, onImportZipAt:(Int)->Unit,
    onOpenRadio: () -> Unit,
    loadingPlaylists: Set<String>,
    playlistSearchOpen: Boolean, onSearchPlaylists: () -> Boolean,
    xlSearchControls: XlSearchControls,
    onQueueTap: () -> Unit, onOpenLocalFiles: () -> Unit,
    xlUiState: XlPlaylistUiState,
    fullBrowser: Boolean,
    showNormalTabs: Boolean,
    mergeMode:Boolean=false, mergeSelection:List<Int> = emptyList(), onMergePick:(Int)->Unit = {}) {
    val context = LocalContext.current
    var renameIndex by remember { mutableIntStateOf(-1) }
    var renameValue by remember { mutableStateOf("") }
    var menuIndex by remember { mutableIntStateOf(-1) }
    var deleteIndex by remember { mutableIntStateOf(-1) }
    // Shared tablet/phone XL chooser; browser-owned state survives opening
    // playlists, QUEUE, LOCAL FILES and search results.
    var xlMode by xlUiState.mode
    var xlChooserVisible by xlUiState.chooserVisible
    var xlReturningFromSearch by xlUiState.returningFromSearch
    var xlWebSearchUrl by xlUiState.webSearchUrl
    val xlKeyboard = LocalSoftwareKeyboardController.current
    // A web result must never remain mounted after selection mode or PRO ends.
    LaunchedEffect(xlSearchControls.queueSelectionMode, xlSearchControls.webEnabled) {
        if (!xlSearchControls.queueSelectionMode || !xlSearchControls.webEnabled) {
            xlWebSearchUrl = null
        }
    }
    val xlListState = xlUiState.listState
    var xlMovingIndex by remember { mutableIntStateOf(-1) }
    var xlPendingOrder by remember { mutableStateOf<List<Int>?>(null) }
    var xlMoveSlots by remember { mutableStateOf<List<Int>?>(null) }
    var xlDragging by remember { mutableStateOf(false) }
    var xlPointerY by remember { mutableFloatStateOf(0f) }
    var xlPhoneSearchDialog by remember { mutableStateOf<String?>(null) }
    val compactPhoneXl = LocalConfiguration.current.smallestScreenWidthDp < 600
    val xlNativeDensity = Density(context.resources.displayMetrics.density * if (compactPhoneXl) 0.85f else 1f,
        context.resources.configuration.fontScale)
    LaunchedEffect(xlSearchControls.queueSelectionMode) {
        if (!xlSearchControls.queueSelectionMode) xlPhoneSearchDialog = null
    }

    fun parkXlAtPointer() {
        val order = xlPendingOrder ?: return
        val from = order.indexOf(xlMovingIndex)
        val hit = xlListState.layoutInfo.visibleItemsInfo.firstOrNull {
            xlPointerY >= it.offset && xlPointerY < it.offset + it.size
        } ?: return
        val firstMovable = order.takeWhile { store.isPinnedTab(it) }.size
        // XL also has navigation rows; match the actual playlist identity.
        // Hovering QUEUE, LOCAL FILES or a pinned list is not a MOVE target.
        val slots = xlMoveSlots ?: return
        val target = slots.indexOfFirst { store.playbackContext(it) == hit.key }
        if (target < firstMovable) return
        if (from >= firstMovable && from != target) {
            xlPendingOrder = order.toMutableList().apply { add(target, removeAt(from)) }
        }
    }
    fun finishXlDrag() {
        xlPendingOrder?.let { order ->
            if (!store.saveTabOrder(order)) {
                uiToast(context, "MOVE failed. List order unchanged.", Toast.LENGTH_LONG).show()
            }
        }
        xlPendingOrder = null
        xlDragging = false
        xlMovingIndex = -1
    }
    fun exitXl() {
        xlPhoneSearchDialog = null
        xlWebSearchUrl = null
        xlKeyboard?.hide()
        xlReturningFromSearch = false
        xlPendingOrder = null
        xlDragging = false
        xlMovingIndex = -1
        xlMode = false
        xlChooserVisible = false
    }
    // Hide the modal while the existing cloud browser is open. On return,
    // reuse the same chooser/list state instead of navigating to another list.
    LaunchedEffect(playlistSearchOpen, xlReturningFromSearch) {
        if (xlReturningFromSearch && !playlistSearchOpen) {
            xlReturningFromSearch = false
            if (xlMode) xlChooserVisible = true
        }
    }
    // Back from songs returns to the same chooser and retained scroll position.
    BackHandler(enabled = !fullBrowser && xlMode && !xlChooserVisible && !xlReturningFromSearch && menuIndex < 0 &&
        renameIndex < 0 && deleteIndex < 0) { xlChooserVisible = true }
    LaunchedEffect(xlDragging) {
        if (!xlDragging) return@LaunchedEffect
        var previous = withFrameNanos { it }
        while (xlDragging) {
            val now = withFrameNanos { it }
            val seconds = ((now - previous) / 1_000_000_000f).coerceIn(0f, .05f)
            previous = now
            val layout = xlListState.layoutInfo
            val edge = with(xlNativeDensity) { 64.dp.toPx() }
            val top = layout.viewportStartOffset.toFloat()
            val bottom = layout.viewportEndOffset.toFloat()
            val speed = when {
                xlPointerY < top + edge -> -((top + edge - xlPointerY) / edge).coerceIn(0f, 1f)
                xlPointerY > bottom - edge -> ((xlPointerY - bottom + edge) / edge).coerceIn(0f, 1f)
                else -> 0f
            }
            if (speed != 0f) {
                xlListState.scrollBy(speed * with(xlNativeDensity) { 600.dp.toPx() } * seconds)
                parkXlAtPointer()
            }
        }
    }
    fun submitXlWebSearch() {
        val query = xlSearchControls.webQuery.trim()
        if (query.isNotEmpty() && xlSearchControls.onAllowWebSearch()) {
            xlPendingOrder = null
            xlMovingIndex = -1
            xlDragging = false
            xlKeyboard?.hide()
            xlPhoneSearchDialog = null
            xlWebSearchUrl = "https://www.youtube.com/results?search_query=" +
                URLEncoder.encode(query, "UTF-8")
        }
    }
    fun submitXlLocalSearch() {
        if (xlSearchControls.localQuery.isNotBlank()) {
            xlPendingOrder = null
            xlMovingIndex = -1
            xlDragging = false
            xlWebSearchUrl = null
            xlKeyboard?.hide()
            xlPhoneSearchDialog = null
            xlSearchControls.onLocalSearch()
        }
    }
    if (xlChooserVisible && xlMode) {
        // The player has a virtual 800dp phone canvas. This modal uses actual
        // device density so touch targets, text and system insets remain native.
        val fixedHeightScale = if (compactPhoneXl) 2f / 3f else 1f
        val scrollingHeightScale = if (compactPhoneXl) 0.5f else 1f
        CompositionLocalProvider(LocalDensity provides xlNativeDensity) {
        Dialog(onDismissRequest = {
            if (xlWebSearchUrl != null) xlWebSearchUrl = null else exitXl()
        },
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = true)) {
            Column(Modifier.fillMaxSize().background(Color(0xFF101812))
                .padding(horizontal = 12.dp, vertical = 8.dp)) {
                val webResultUrl = xlWebSearchUrl.takeIf {
                    xlSearchControls.queueSelectionMode && xlSearchControls.webEnabled
                }
                var xlWebFull by remember(webResultUrl) { mutableStateOf(false) }
                BackHandler(enabled = xlWebFull) { xlWebFull = false }
                if (!xlWebFull) {
                // Fixed header is outside LazyColumn; only playlist stones scroll.
                Row(Modifier.fillMaxWidth()
                    .height((64f * fixedHeightScale * xlNativeDensity.fontScale.coerceAtLeast(1f)).dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PlaylistStoneButton(onClick = {
                        if (onSearchPlaylists()) {
                            xlWebSearchUrl = null
                            xlKeyboard?.hide()
                            // Discard an unfinished MOVE without changing saved order.
                            xlPendingOrder = null
                            xlMovingIndex = -1
                            xlDragging = false
                            xlReturningFromSearch = true
                            xlChooserVisible = false
                        }
                    }, modifier = Modifier.weight(2f).fillMaxHeight()
                        .semantics { contentDescription = AppLanguage.text("SEARCH PLAYLISTS") }) {
                        if (compactPhoneXl) HeaderStoneText("SEARCH\nPLAYLISTS", 12.sp, 2)
                        else FittedControlText(AppLanguage.text("SEARCH PLAYLISTS"),
                            modifier = Modifier.fillMaxWidth().basicMarquee(
                                iterations = Int.MAX_VALUE, initialDelayMillis = 1200),
                            color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center, maxLines = 1, softWrap = false,
                            overflow = TextOverflow.Clip)
                    }
                    PlaylistStoneButton(onClick = { exitXl() }, active = true,
                        modifier = Modifier.weight(1f).fillMaxHeight()
                            .semantics { contentDescription = AppLanguage.text("NORMAL") }) {
                        if (compactPhoneXl) HeaderStoneText("NORMAL", 17.sp, 1)
                        else FittedControlText(AppLanguage.text("NORMAL"), color = Color.White, fontSize = 21.sp,
                            modifier = Modifier.fillMaxWidth().basicMarquee(
                                iterations = Int.MAX_VALUE, initialDelayMillis = 1200),
                            textAlign = TextAlign.Center, fontWeight = FontWeight.Black,
                            maxLines = 1, softWrap = false, overflow = TextOverflow.Clip)
                    }
                }
                Spacer(Modifier.height(8.dp))
                // Fixed XL controls, same touch size as SEARCH PLAYLISTS / EXIT.
                Row(Modifier.fillMaxWidth().height((64f * fixedHeightScale * xlNativeDensity.fontScale.coerceAtLeast(1f)).dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PlaylistStoneButton(onClick = {
                        xlPendingOrder = null
                        xlMovingIndex = -1
                        xlDragging = false
                        onSelected(store.queueIndex)
                        // Show QUEUE songs: leaving the chooser is essential, otherwise
                        // the full-screen XL dialog keeps covering the selected queue.
                        xlChooserVisible = false
                    }, queueTone = true, active = selected == store.queueIndex,
                        modifier = Modifier.weight(1f).fillMaxHeight()
                            .semantics { contentDescription = AppLanguage.text("QUEUE") }) {
                        FittedControlText(AppLanguage.text("QUEUE"), color = Color.White, fontSize = 22.sp,
                            fontWeight = FontWeight.Black)
                    }
                    PlaylistStoneButton(onClick = { xlChooserVisible = false; onOpenRadio() },
                        modifier = Modifier.weight(1f).fillMaxHeight()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioStationBadge(Modifier.size(24.dp))
                            FittedControlText("RADIO", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Black)
                        }
                    }
                    PlaylistStoneButton(onClick = { onQueueTap() },
                        redTone = true, redActive = xlSearchControls.queueSelectionMode,
                        modifier = Modifier.weight(1f).fillMaxHeight()
                            .semantics { contentDescription = if (xlSearchControls.queueSelectionMode) "DONE" else "ADD TO QUEUE" }) {
                        Text(AppLanguage.text(if (xlSearchControls.queueSelectionMode) "DONE" else "ADD TO QUEUE"),
                            color = Color.White.copy(alpha = if (xlSearchControls.queueSelectionMode)
                                xlSearchControls.blinkAlpha.value else 1f),
                            fontSize = 18.sp, fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center, maxLines = 2)
                    }
                }
                if (xlSearchControls.queueSelectionMode) {
                    Spacer(Modifier.height(8.dp))
                    // ONE fixed horizontal row. At phone width the search labels
                    // remain full-size touch targets and open a native-size dialog,
                    // rather than compressing two TextFields into ~100dp each.
                    Row(Modifier.fillMaxWidth().height(60.dp * fixedHeightScale),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        if (LocalConfiguration.current.screenWidthDp < 600) {
                            PlaylistStoneButton(onClick = { xlPhoneSearchDialog = "web" },
                                modifier = Modifier.weight(1f).fillMaxHeight()
                                    .semantics { contentDescription = AppLanguage.text("WEB SEARCH") }) {
                                FittedControlText(AppLanguage.text("WEB SEARCH"), color = Color.White, fontSize = 17.sp,
                                    fontWeight = FontWeight.Black, maxLines = 1)
                            }
                            PlaylistStoneButton(onClick = { xlPhoneSearchDialog = "local" },
                                modifier = Modifier.weight(1f).fillMaxHeight()
                                    .semantics { contentDescription = AppLanguage.text("LOCAL SEARCH") }) {
                                FittedControlText(AppLanguage.text("LOCAL SEARCH"), color = Color.White, fontSize = 17.sp,
                                    fontWeight = FontWeight.Black, maxLines = 1)
                            }
                        } else {
                            Box(Modifier.weight(1f).fillMaxHeight()) {
                                XlFixedSearchField(
                                    value = xlSearchControls.webQuery,
                                    onValueChange = xlSearchControls.onWebQuery,
                                    placeholder = "WEB SEARCH",
                                    blinkAlpha = remember { mutableFloatStateOf(1f) },
                                    onSearch = ::submitXlWebSearch)
                            }
                            Box(Modifier.weight(1f).fillMaxHeight()) {
                                XlFixedSearchField(
                                    value = xlSearchControls.localQuery,
                                    onValueChange = xlSearchControls.onLocalQuery,
                                    placeholder = "LOCAL SEARCH",
                                    blinkAlpha = remember { mutableFloatStateOf(1f) },
                                    onSearch = ::submitXlLocalSearch)
                            }
                        }
                    }
                }
                // Search dialog dismissal is synchronized from the same mode state
                // without writing state during Compose layout.
                if (xlPhoneSearchDialog != null) {
                    val web = xlPhoneSearchDialog == "web"
                    AlertDialog(onDismissRequest = { xlPhoneSearchDialog = null },
                        title = { Text(AppLanguage.text(if (web) "WEB SEARCH" else "LOCAL SEARCH")) },
                        text = {
                            OutlinedTextField(
                                value = if (web) xlSearchControls.webQuery else xlSearchControls.localQuery,
                                onValueChange = if (web) xlSearchControls.onWebQuery else xlSearchControls.onLocalQuery,
                                label = { FittedControlText(AppLanguage.text("Search music")) },
                                singleLine = true,
                                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                    imeAction = androidx.compose.ui.text.input.ImeAction.Search),
                                keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                                    onSearch = { if (web) submitXlWebSearch() else submitXlLocalSearch() }),
                                modifier = Modifier.fillMaxWidth())
                        },
                        confirmButton = {
                            TextButton(onClick = { if (web) submitXlWebSearch() else submitXlLocalSearch() }) {
                                FittedControlText(AppLanguage.text("SEARCH"), fontWeight = FontWeight.Black)
                            }
                        }, dismissButton = {
                            TextButton(onClick = { xlPhoneSearchDialog = null }) { FittedControlText(AppLanguage.text("CANCEL")) }
                        })
                }
                Spacer(Modifier.height(10.dp))
                }
                // Keep hit-test slots stationary until release; reflowing under the pointer oscillates.
                val xlOrder = if (xlMovingIndex >= 0) xlMoveSlots ?: store.playlistTabIndices() else store.playlistTabIndices()
                if (webResultUrl != null) {
                    // Use the existing result panel and save handler inside XL.
                    // Key each query because the panel loads its URL in factory.
                    key(webResultUrl) {
                        Box(Modifier.weight(1f).fillMaxWidth()) {
                        YoutubeSearchPanel(url = webResultUrl,
                            textSize = xlSearchControls.webTextSize.floatValue,
                            onSelected = { id, title, url ->
                                xlSearchControls.onWebSelected(id, title, url)
                                xlWebSearchUrl = null
                            },
                            onClose = { xlWebSearchUrl = null },
                            modifier = Modifier.fillMaxSize(),
                            releaseOnDispose = true)
                        Column(Modifier.align(Alignment.BottomEnd),
                            verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            val controlHeight = if (compactPhoneXl) 120.dp else 208.dp
                            BrowserFullToggle(xlWebFull, controlHeight) { xlWebFull = !xlWebFull }
                            SongTextSizeControls("web", xlSearchControls.webTextSize, controlHeight)
                        }
                        }
                    }
                } else {
                LazyColumn(Modifier.weight(1f).fillMaxWidth()
                    .pointerInput(xlMovingIndex) {
                        if (xlMovingIndex < 0) return@pointerInput
                        detectVerticalDragGestures(
                            onDragStart = { position ->
                                val row = xlListState.layoutInfo.visibleItemsInfo.firstOrNull {
                                    position.y >= it.offset && position.y < it.offset + it.size
                                }
                                if (row?.key == store.playbackContext(xlMovingIndex)) {
                                    xlPendingOrder = xlMoveSlots ?: store.playlistTabIndices()
                                    xlPointerY = position.y
                                    xlDragging = true
                                }
                            },
                            onVerticalDrag = { change, _ ->
                                if (xlDragging) {
                                    change.consume()
                                    xlPointerY = change.position.y
                                    parkXlAtPointer()
                                }
                            },
                            onDragEnd = { if (xlDragging) finishXlDrag() },
                            onDragCancel = { xlPendingOrder = null; xlDragging = false }
                        )
                    }, state = xlListState,
                    // In MOVE mode the parent owns vertical drag gestures; normal
                    // LazyColumn scrolling otherwise steals the movement gesture.
                    // Edge auto-scroll below still works while moving.
                    userScrollEnabled = xlMovingIndex < 0,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 48.dp)) {
                    // Navigation is part of the scrolling XL list, never the
                    // saved playlist order. WELCOME remains the first real tab.
                    item(key = "xl-navigation:local-files") {
                        PlaylistStoneButton(onClick = {
                            // Browse local songs while keeping XL mode and scroll.
                            xlPendingOrder = null
                            xlMovingIndex = -1
                            xlDragging = false
                            xlWebSearchUrl = null
                            xlChooserVisible = false
                            xlKeyboard?.hide()
                            onOpenLocalFiles()
                        }, localTone = true, modifier = Modifier.fillMaxWidth()
                            .height((84f * scrollingHeightScale * xlNativeDensity.fontScale.coerceAtLeast(1f)).dp)
                            .semantics { contentDescription = AppLanguage.text("LOCAL FILES") }) {
                            FittedControlText(AppLanguage.text("LOCAL FILES"),
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp)
                                    .basicMarquee(iterations = Int.MAX_VALUE, initialDelayMillis = 1200),
                                color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center, maxLines = 1, softWrap = false,
                                overflow = TextOverflow.Clip)
                        }
                    }
                    items(xlOrder, key = { store.playbackContext(it) }) { index ->
                        val loading = store.playbackContext(index) in loadingPlaylists
                        PlaylistStoneButton(
                            onClick = {
                                if (loading) return@PlaylistStoneButton
                                if (xlMovingIndex >= 0) {
                                    // Tap-to-park also works in XL: no pixel-perfect
                                    // dragging required for accessibility.
                                    val order = (xlPendingOrder ?: store.playlistTabIndices()).toMutableList()
                                    val from = order.indexOf(xlMovingIndex)
                                    val firstMovable = order.takeWhile { store.isPinnedTab(it) }.size
                                    val target = order.indexOf(index)
                                    if (from >= firstMovable && target >= firstMovable &&
                                        !store.isPinnedTab(xlMovingIndex)) {
                                        order.removeAt(from)
                                        order.add(target, xlMovingIndex)
                                        if (!store.saveTabOrder(order)) {
                                            uiToast(context, "MOVE failed. List order unchanged.", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                    xlMovingIndex = -1
                                    xlPendingOrder = null
                                    xlDragging = false
                                } else {
                                    store.activate(index)
                                    onSelected(index)
                                    xlChooserVisible = false
                                }
                            },
                            onLongClick = {
                                if (!loading && index != store.queueIndex && !xlDragging && xlMovingIndex < 0) {
                                    menuIndex = index
                                    renameValue = store.names[index].value
                                    xlChooserVisible = false
                                }
                            },
                            active = index == selected || index == xlMovingIndex,
                            redActive = index == xlMovingIndex,
                            welcomeTone = index == store.welcomePlaylistIndex(),
                            modifier = Modifier.fillMaxWidth().height((84f * scrollingHeightScale * xlNativeDensity.fontScale.coerceAtLeast(1f)).dp)) {
                            if (loading) WaitStoneLabel() else Box(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = if (compactPhoneXl) 0.dp else 10.dp)
                                .clipToBounds(), contentAlignment = Alignment.Center) {
                                Text(playlistUiName(store, index),
                                    modifier = Modifier.fillMaxWidth().basicMarquee(
                                        iterations = Int.MAX_VALUE, initialDelayMillis = 1200),
                                    color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Center, softWrap = false,
                                    maxLines = 1, overflow = TextOverflow.Clip)
                            }
                        }
                    }
                }
                }
            }
        }
        }
    }
    var movingIndex by remember { mutableIntStateOf(-1) }
    var pendingTabOrder by remember { mutableStateOf<List<Int>?>(null) }
    var moveStartOrder by remember { mutableStateOf<List<Int>?>(null) }
    var dragCenterContentX by remember { mutableFloatStateOf(0f) }
    var dragPointerViewportX by remember { mutableFloatStateOf(0f) }
    var draggingTab by remember { mutableStateOf(false) }
    val density = LocalDensity.current
    val stoneWidthPx = with(density) { 160.dp.toPx() }
    val slotPitchPx = with(density) { 165.dp.toPx() }
    val queueNavigationWidthDp = 160f * 4f / 3f
    val playlistStartDp = queueNavigationWidthDp + 165f + 5f
    val playlistStartPx = with(density) { playlistStartDp.dp.toPx() }
    val edgePx = with(density) { 58.dp.toPx() }
    val maxScrollSpeedPx = with(density) { 650.dp.toPx() }
    val tabScroll = rememberScrollState()
    var viewportWidthPx by remember { mutableFloatStateOf(0f) }
    val helpPrefs = remember(context) {
        context.getSharedPreferences("breakmonster_ui", Context.MODE_PRIVATE)
    }
    val firstInstall = remember(context) {
        @Suppress("DEPRECATION")
        val info = context.packageManager.getPackageInfo(context.packageName, 0)
        info.firstInstallTime == info.lastUpdateTime
    }
    val canShowScrollHint = showNormalTabs && !xlMode && movingIndex < 0 && tabScroll.value == 0 &&
        tabScroll.maxValue in 1 until Int.MAX_VALUE
    val arrowAlpha = remember { androidx.compose.animation.core.Animatable(.15f) }
    var showScrollHint by remember { mutableStateOf(false) }
    LaunchedEffect(canShowScrollHint) {
        val key = "normal_playlist_scroll_help_shown"
        if (!canShowScrollHint || !firstInstall || helpPrefs.getBoolean(key, false)) return@LaunchedEffect
        if (!helpPrefs.edit().putBoolean(key, true).commit()) return@LaunchedEffect
        showScrollHint = true
        try {
            repeat(3) {
                arrowAlpha.animateTo(.85f, tween(600))
                arrowAlpha.animateTo(.15f, tween(600))
            }
        } finally {
            showScrollHint = false
        }
    }

    fun updateParkingSlot() {
        val order = pendingTabOrder ?: return
        val from = order.indexOf(movingIndex)
        val minimum = order.takeWhile { store.isPinnedTab(it) }.size
        if (from < minimum || from < 0 || minimum > order.lastIndex) return
        val target = ((dragCenterContentX - playlistStartPx - stoneWidthPx / 2f) / slotPitchPx)
            .roundToInt().coerceIn(minimum, order.lastIndex)
        if (target != from) {
            pendingTabOrder = order.toMutableList().apply {
                removeAt(from)
                add(target, movingIndex)
            }
        }
    }

    // Continue scrolling even while the finger is stationary at an edge. Include
    // the actual clamped scroll delta in content coordinates to keep the stone
    // under the finger and advance the parking slot all the way to either end.
    LaunchedEffect(movingIndex, draggingTab) {
        if (movingIndex < 0 || !draggingTab) return@LaunchedEffect
        var previousFrame = withFrameNanos { it }
        while (draggingTab) {
            val frame = withFrameNanos { it }
            val seconds = ((frame - previousFrame) / 1_000_000_000f).coerceIn(0f, .05f)
            previousFrame = frame
            val edge = minOf(edgePx, viewportWidthPx / 3f)
            val speed = when {
                edge <= 0f -> 0f
                dragPointerViewportX < edge -> -maxScrollSpeedPx *
                    ((edge - dragPointerViewportX) / edge).coerceIn(0f, 1f)
                dragPointerViewportX > viewportWidthPx - edge -> maxScrollSpeedPx *
                    ((dragPointerViewportX - viewportWidthPx + edge) / edge).coerceIn(0f, 1f)
                else -> 0f
            }
            if (speed != 0f) {
                val consumed = tabScroll.scrollBy(speed * seconds)
                dragCenterContentX += consumed
                updateParkingSlot()
            }
        }
    }

    if (showNormalTabs) Box(Modifier.fillMaxWidth().height(58.dp)) {
      Row(Modifier.fillMaxSize().padding(horizontal=4.dp, vertical=4.dp), verticalAlignment=Alignment.CenterVertically) {
        val baseOrder = moveStartOrder ?: store.playlistTabIndices()
        val parkedOrder = pendingTabOrder ?: baseOrder
        Box(Modifier.fillMaxSize().padding(end=if(showScrollHint) 100.dp else 0.dp)
            .onSizeChanged { viewportWidthPx = it.width.toFloat() }
            .horizontalScroll(tabScroll, enabled = movingIndex < 0)) {
          Box(Modifier.width((playlistStartDp + baseOrder.size * 165f - 5f)
              .coerceAtLeast(0f).dp).height(50.dp)) {
            if (movingIndex >= 0) {
                val parkingIndex = parkedOrder.indexOf(movingIndex)
                if (parkingIndex >= 0) Box(
                    Modifier.offset(x = (playlistStartDp + parkingIndex * 165f).dp)
                        .size(width = 160.dp, height = 50.dp)
                        .background(MonsterGreen.copy(alpha = .10f), RoundedCornerShape(9.dp))
                        .border(2.dp, MonsterGreen.copy(alpha = .8f), RoundedCornerShape(9.dp)),
                    contentAlignment = Alignment.Center
                ) { FittedControlText(AppLanguage.text("↓"), color = MonsterGreen, fontSize = 26.sp, fontWeight = FontWeight.Black) }
            }
            Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(5.dp)) {
            // First NORMAL stone is QUEUE (4/3 the standard tab width).
            // XL has just one entry point: the centered main PLAYLISTS stone.
            PlaylistStoneButton(onClick = {
                onSelected(store.queueIndex)
            }, queueTone = true,
                modifier = Modifier.width(queueNavigationWidthDp.dp).height(50.dp)
                    .semantics { contentDescription = AppLanguage.text("QUEUE / ADD TO QUEUE") }) {
                FittedControlText(AppLanguage.text("QUEUE"), color = Color.White,
                    fontSize = 16.sp, fontWeight = FontWeight.Black, maxLines = 1,
                    overflow = TextOverflow.Ellipsis)
            }
            PlaylistStoneButton(onClick = onOpenRadio,
                modifier = Modifier.width(160.dp).height(50.dp)
                    .semantics { contentDescription = "RADIO · COUNTRY AND FAVORITES" }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioStationBadge(Modifier.size(26.dp))
                    Spacer(Modifier.width(5.dp))
                    FittedControlText("RADIO", color = Color.White, fontSize = 16.sp,
                        fontWeight = FontWeight.Black)
                }
            }
            baseOrder.forEachIndexed { baseIndex, i ->
                // Freeze physical slots for this MOVE session; only translations
                // change. Reordering cannot dispose/restart the dragged pointer.
                key(store.playbackContext(i), movingIndex) {
                val loading = store.playbackContext(i) in loadingPlaylists
                val isMoving = i == movingIndex
                val parkingIndex = parkedOrder.indexOf(i).coerceAtLeast(0)
                val neighborShift by animateFloatAsState(
                    targetValue = if (isMoving) 0f else (parkingIndex - baseIndex) * slotPitchPx,
                    animationSpec = tween(160), label = "playlist-parking-$i"
                )
                PlaylistStoneButton(
                    onClick={
                        // MOVE is committed on pointer release, not on a second tap.
                        if (!loading && movingIndex == -1) {
                            if(mergeMode) { if(!store.isPinnedTab(i)) onMergePick(i) } else { store.activate(i); onSelected(i) }
                        }
                    },
                    onLongClick={ if(!loading && !mergeMode && movingIndex == -1 && i != store.queueIndex) {
                        menuIndex=i; renameValue=store.names[i].value
                    } },
                    active=isMoving || if(mergeMode) i in mergeSelection else store.activeIndex==i,
                    welcomeTone=i==store.welcomePlaylistIndex(),
                    modifier=Modifier.width(160.dp).height(50.dp)
                        .zIndex(if (isMoving) 5f else 0f)
                        .graphicsLayer {
                            translationX = if (isMoving)
                                dragCenterContentX - (playlistStartPx + baseIndex * slotPitchPx + stoneWidthPx / 2f)
                            else neighborShift
                        }
                        .then(if (isMoving) Modifier.pointerInput(i) {
                            detectHorizontalDragGestures(
                                onDragStart = { position ->
                                    dragCenterContentX = playlistStartPx + baseIndex * slotPitchPx + stoneWidthPx / 2f
                                    dragPointerViewportX = playlistStartPx + baseIndex * slotPitchPx - tabScroll.value + position.x
                                    draggingTab = true
                                },
                                onHorizontalDrag = { change, delta ->
                                    change.consume()
                                    dragCenterContentX += delta
                                    dragPointerViewportX += delta
                                    updateParkingSlot()
                                },
                                onDragEnd = {
                                    // The finger lifted: park and persist immediately.
                                    draggingTab = false
                                    updateParkingSlot()
                                    val finalOrder = pendingTabOrder ?: moveStartOrder
                                    if (finalOrder != null && store.saveTabOrder(finalOrder)) {
                                        movingIndex = -1
                                        pendingTabOrder = null
                                        moveStartOrder = null
                                    } else {
                                        uiToast(context, "MOVE failed. List order unchanged.", Toast.LENGTH_LONG).show()
                                    }
                                },
                                onDragCancel = {
                                    // Cancelled pointers must not write an accidental reorder.
                                    draggingTab = false
                                    movingIndex = -1
                                    pendingTabOrder = null
                                    moveStartOrder = null
                                }
                            )
                        } else Modifier)
                ) {
                    if (loading) WaitStoneLabel() else BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) {
                        val number = store.importedSplitNumber(i)
                        if (number != null) Text(number.toString(), color=Color.White.copy(alpha=0.17f), fontSize=(maxHeight.value * .85f).sp, fontWeight=FontWeight.Black, maxLines=1)
                        MarqueeFilenameText(playlistUiName(store, i), Modifier.fillMaxWidth(), Color.White, 16.sp, FontWeight.Black)
                    }
                }
                }
            }
            }
          }
        }
      }
      if(showScrollHint) {
        SharpLeftTriangle(
            Modifier.align(Alignment.CenterEnd).padding(end=2.dp).size(width=64.dp,height=43.dp),
            Color.White.copy(alpha=arrowAlpha.value))
      }
    }
    CompositionLocalProvider(LocalDensity provides if (xlMode) xlNativeDensity else LocalDensity.current) {
    if (menuIndex >= 0) AlertDialog(
        onDismissRequest = { menuIndex = -1; if (xlMode) xlChooserVisible = true },
        title = { Text(playlistUiName(store, menuIndex), fontWeight = FontWeight.Black, maxLines = 2) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(AppLanguage.text(if (xlMode) "MOVE: drag vertically or tap the destination stone. Hold near the top or bottom to scroll." else "Drag the stone to a new place and lift your finger to save. Hold at an edge to scroll."), fontSize = 16.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        if (xlMode) {
                            xlMovingIndex = menuIndex
                            xlMoveSlots = store.playlistTabIndices()
                            xlPendingOrder = xlMoveSlots
                            xlDragging = false
                            xlChooserVisible = true
                            menuIndex = -1
                        } else {
                        movingIndex = menuIndex
                        val initialOrder = store.playlistTabIndices()
                        moveStartOrder = initialOrder
                        pendingTabOrder = initialOrder
                        dragCenterContentX = playlistStartPx + initialOrder.indexOf(movingIndex) * slotPitchPx + stoneWidthPx / 2f
                        draggingTab = false
                        menuIndex = -1
                        }
                    }, enabled = !store.isPinnedTab(menuIndex), modifier = Modifier.weight(1f)) { FittedControlText(AppLanguage.text("MOVE"), maxLines = 1) }
                    Button(onClick = { renameIndex = menuIndex; menuIndex = -1 }, modifier = Modifier.weight(1f)) {
                        FittedControlText(AppLanguage.text("RENAME"), maxLines = 1)
                    }
                }
                OutlinedButton(onClick = { deleteIndex = menuIndex; menuIndex = -1 }, modifier = Modifier.fillMaxWidth()) {
                    FittedControlText(AppLanguage.text("DELETE PLAYLIST"), color = Color(0xFFFF7B72), maxLines = 1)
                }
                TextButton(onClick = { menuIndex = -1; if (xlMode) xlChooserVisible = true }, modifier = Modifier.fillMaxWidth()) {
                    FittedControlText(AppLanguage.text("CANCEL"), maxLines = 1)
                }
            }
        },
        confirmButton = {},
        dismissButton = {}
    )
    if(renameIndex>=0) AlertDialog(
        onDismissRequest={renameIndex=-1; if(xlMode) xlChooserVisible=true},
        title={FittedControlText(AppLanguage.text("Rename playlist"))},
        text={OutlinedTextField(renameValue,{renameValue=it.take(24)},singleLine=true)},
        confirmButton={TextButton(onClick={store.rename(renameIndex,renameValue);renameIndex=-1; if(xlMode) xlChooserVisible=true}){FittedControlText(AppLanguage.text("SAVE"))}},
        dismissButton={TextButton(onClick={renameIndex=-1; if(xlMode) xlChooserVisible=true}){FittedControlText(AppLanguage.text("CANCEL"))}}
    )
    if(deleteIndex>=0) AlertDialog(onDismissRequest={deleteIndex=-1; if(xlMode) xlChooserVisible=true},title={FittedControlText(AppLanguage.text("ARE YOU SURE?"),fontSize=23.sp,fontWeight=FontWeight.Black)},text={Text(AppLanguage.text("Delete playlist ${playlistUiName(store, deleteIndex)}? Media files will stay untouched."),fontSize=18.sp)},confirmButton={Button(onClick={if(store.delete(deleteIndex)) onSelected(store.activeIndex) else uiToast(context,"Playlist could not be deleted",Toast.LENGTH_LONG).show();deleteIndex=-1; if(xlMode) xlChooserVisible=true}){FittedControlText(AppLanguage.text("DELETE PLAYLIST"))}},dismissButton={TextButton(onClick={deleteIndex=-1; if(xlMode) xlChooserVisible=true}){FittedControlText(AppLanguage.text("CANCEL"))}})
    }
}

@Composable
private fun GestureManual(resource:Int, modifier:Modifier=Modifier){
    AndroidView(modifier=modifier, factory={ context -> GestureGifView(context,resource) })
}
private enum class ArrowDirection { Left, UpDown }
@Composable
private fun ThickArrow(direction:ArrowDirection, modifier:Modifier=Modifier, color:Color=Color.White) {
    Canvas(modifier) {
        val stroke = size.minDimension * .42f
        val path = Path()
        if (direction == ArrowDirection.Left) {
            drawLine(color, androidx.compose.ui.geometry.Offset(size.width*.96f,size.height*.5f), androidx.compose.ui.geometry.Offset(size.width*.16f,size.height*.5f), stroke, cap=androidx.compose.ui.graphics.StrokeCap.Round)
            path.moveTo(size.width*.10f,size.height*.5f); path.lineTo(size.width*.62f,size.height*.02f); path.lineTo(size.width*.62f,size.height*.98f); path.close()
            drawPath(path,color)
        } else {
            drawLine(color, androidx.compose.ui.geometry.Offset(size.width*.5f,size.height*.1f), androidx.compose.ui.geometry.Offset(size.width*.5f,size.height*.9f), stroke, cap=androidx.compose.ui.graphics.StrokeCap.Round)
            path.moveTo(size.width*.5f,size.height*.08f); path.lineTo(size.width*.08f,size.height*.4f); path.lineTo(size.width*.92f,size.height*.4f); path.close()
            drawPath(path,color)
            path.reset()
            path.moveTo(size.width*.5f,size.height*.92f); path.lineTo(size.width*.08f,size.height*.6f); path.lineTo(size.width*.92f,size.height*.6f); path.close()
            drawPath(path,color)
        }
    }
}

/** Solid, sharp triangle used by the ADD TO QUEUE and playlist help indicators. */
@Composable
private fun SharpLeftTriangle(modifier: Modifier = Modifier, color: Color = Color.White) {
    Canvas(modifier) {
        val path = Path().apply {
            moveTo(size.width * .04f, size.height * .5f)
            lineTo(size.width * .96f, size.height * .04f)
            lineTo(size.width * .96f, size.height * .96f)
            close()
        }
        drawPath(path, color)
    }
}

private fun songRowControlScale(size: Float, defaultSize: Float): Float =
    if (size < defaultSize) {
        0.6f + 0.4f * (size - MIN_SONG_TEXT_SIZE) / (defaultSize - MIN_SONG_TEXT_SIZE)
    } else {
        1f + 0.3f * (size - defaultSize) / (42f - defaultSize)
    }

/** Keep the existing heights above 14sp and add two denser steps below it. */
private fun songRowHeight(fontSize: Float, local: Boolean): Dp =
    if (local) {
        if (fontSize < 14f) (40f + (fontSize - MIN_SONG_TEXT_SIZE) * 3f).dp
        else (fontSize + 38f).dp
    } else {
        if (fontSize < 14f) (40f + (fontSize - MIN_SONG_TEXT_SIZE) * 2f).dp
        else (48f + (fontSize - 14f) * (8f / 9f)).dp
    }

/** Extend the song bars past the browser's end inset. The root controls overlay
 * their background, while row content leaves the controls' hit area clear. */
@Composable
private fun SongListArea(content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier.fillMaxSize().layout { measurable, constraints ->
            val width = constraints.maxWidth
            val child = measurable.measure(constraints.copy(
                minWidth = width + BrowserEndInset.roundToPx(),
                maxWidth = width + BrowserEndInset.roundToPx()
            ))
            layout(width, child.height) { child.placeRelative(0, 0) }
        },
        content = content
    )
}

/** Independent, persistent song-title sizing for each list area. */
@Composable
private fun rememberSongTextSize(section: String, initialSize: Float): MutableFloatState {
    val context = LocalContext.current
    return remember(section) {
        mutableFloatStateOf(context.getSharedPreferences("song_text_sizes", Context.MODE_PRIVATE)
            .getFloat(section, initialSize).coerceIn(MIN_SONG_TEXT_SIZE, 42f))
    }
}

@Composable
private fun BrowserFullToggle(full: Boolean, controlHeight: Dp, onToggle: () -> Unit) {
    val toggleLabel = if (full) "BACK" else "FULL"
    val toggleShape = RoundedCornerShape(7.dp)
    Box(
        modifier = Modifier.size(SongControlWidth, controlHeight)
            .background(Color(0xFF12271B), toggleShape)
            .border(2.dp, MonsterGreen.copy(alpha = .75f), toggleShape)
            .clickable(onClickLabel = toggleLabel, onClick = onToggle)
            .semantics { contentDescription = toggleLabel },
        contentAlignment = Alignment.Center
    ) {
        Text(
            toggleLabel.toList().joinToString("\n"),
            modifier = Modifier.clearAndSetSemantics { },
            color = Color.White,
            fontSize = 11.sp,
            lineHeight = 12.sp,
            fontWeight = FontWeight.Black,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun SongTextSizeControls(section: String, size: MutableFloatState, controlHeight: Dp) {
    val context = LocalContext.current
    fun adjust(delta: Float) {
        size.floatValue = (size.floatValue + delta).coerceIn(MIN_SONG_TEXT_SIZE, 42f)
        context.getSharedPreferences("song_text_sizes", Context.MODE_PRIVATE)
            .edit().putFloat(section, size.floatValue).apply()
    }
    Box(Modifier.size(SongControlWidth, controlHeight)) {
        Column(Modifier.fillMaxSize()
            .clearAndSetSemantics { }
            .background(Color(0xFF12271B), RoundedCornerShape(7.dp))
            .border(2.dp, MonsterGreen.copy(alpha = .75f), RoundedCornerShape(7.dp))) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                FittedControlText(AppLanguage.text("+"), color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black,
                    style = TextStyle(platformStyle = PlatformTextStyle(includeFontPadding = false)))
            }
            HorizontalDivider(color = MonsterGreen.copy(alpha = .4f))
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                FittedControlText(AppLanguage.text("−"), color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black,
                    style = TextStyle(platformStyle = PlatformTextStyle(includeFontPadding = false)))
            }
        }
        // Two hit targets, matching the visible halves; no extra icons, paint or
        // ripple outside the original control. Root z-order gives these taps
        // priority over the MP3/OTHER/dinosaur badge region underneath.
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxWidth().weight(1f)
                .clickable(
                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                    indication = null
                ) { adjust(2f) }
                .semantics { contentDescription = "Increase song text and row height in $section" })
            Spacer(Modifier.height(1.dp))
            Box(Modifier.fillMaxWidth().weight(1f)
                .clickable(
                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                    indication = null
                ) { adjust(-2f) }
                .semantics { contentDescription = "Decrease song text and row height in $section" })
        }
    }
}

/** Bounded one-line filename; basicMarquee is stationary when text fits. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MarqueeFilenameText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.White,
    fontSize: androidx.compose.ui.unit.TextUnit = 18.sp,
    fontWeight: FontWeight = FontWeight.Normal,
    style: TextStyle = TextStyle.Default
) {
    key(text) {
        Text(
            text = text,
            color = color,
            fontSize = fontSize,
            fontWeight = fontWeight,
            style = style,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Clip,
            modifier = modifier.clipToBounds().basicMarquee(iterations = Int.MAX_VALUE, initialDelayMillis = 900)
        )
    }
}

@Composable
private fun ReorderGestureHelp(modifier:Modifier=Modifier){
    val transition=androidx.compose.animation.core.rememberInfiniteTransition(label="reorder-help")
    val offset by transition.animateFloat(initialValue=0f,targetValue=8f,animationSpec=androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(550),androidx.compose.animation.core.RepeatMode.Reverse),label="drag-arrow")
    Row(modifier,verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.Center){
        FittedControlText(AppLanguage.text("☝"),fontSize=23.sp,color=MonsterGreen)
        Spacer(Modifier.width(8.dp))
        FittedControlText(AppLanguage.text("LONG PRESS"),fontSize=15.sp,fontWeight=FontWeight.Black,color=Color.White)
        ThickArrow(ArrowDirection.UpDown, Modifier.padding(horizontal=8.dp).size(width=18.dp,height=28.dp).offset(y=offset.dp), MonsterGreen)
        FittedControlText(AppLanguage.text("  DRAG TO REORDER"),fontSize=15.sp,fontWeight=FontWeight.Black,color=Color.White)
    }
}
@Suppress("DEPRECATION")
private class GestureGifView(context:Context, resource:Int):android.view.View(context){
    private val movie=context.resources.openRawResource(resource).use{android.graphics.Movie.decodeStream(it)}
    private val started=android.os.SystemClock.uptimeMillis()
    init{setLayerType(LAYER_TYPE_SOFTWARE,null)}
    override fun onDraw(canvas:android.graphics.Canvas){super.onDraw(canvas);val a=movie?:return;a.setTime(((android.os.SystemClock.uptimeMillis()-started)%a.duration().coerceAtLeast(1)).toInt());val scale=minOf(width.toFloat()/a.width(),height.toFloat()/a.height());canvas.save();canvas.translate((width-a.width()*scale)/2,(height-a.height()*scale)/2);canvas.scale(scale,scale);a.draw(canvas,0f,0f);canvas.restore();if(isAttachedToWindow)postInvalidateDelayed(40)}
}
private fun swipeFeedbackResource(added:Boolean, playlist:Int):Int{
    val r=if(added) listOf(R.drawable.swipe_added_p1,R.drawable.swipe_added_p2,R.drawable.swipe_added_p3,R.drawable.swipe_added_p4) else listOf(R.drawable.swipe_removed_p1,R.drawable.swipe_removed_p2,R.drawable.swipe_removed_p3,R.drawable.swipe_removed_p4)
    return r[(playlist-1).coerceIn(0,3)]
}

private fun importM3uPlaylist(context:Context, uri:Uri, library:List<BreakItem>, store:BreakPlaylistStore):Int {
    return runCatching {
        val displayName=runCatching { context.contentResolver.query(uri,arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),null,null,null)?.use { c -> if(c.moveToFirst()) c.getString(0) else null } }.getOrNull() ?: "Imported playlist.m3u"
        if(!displayName.endsWith(".m3u",true) && !displayName.endsWith(".m3u8",true)) error("Choose an M3U or M3U8 playlist.")
        val lines=context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readLines() } ?: error("Playlist file could not be read.")
        val entries=mutableListOf<BreakPlaylistEntry>(); var metadata:String?=null
        lines.forEachIndexed { index, raw ->
            val line=raw.trim().removePrefix("\uFEFF")
            if(line.isBlank()) return@forEachIndexed
            if(line.startsWith("#EXTINF",true)){ metadata=line.substringAfter(',',"").trim().takeIf{it.isNotBlank()}; return@forEachIndexed }
            if(line.startsWith('#')) return@forEachIndexed
            val pathName=line.substringAfterLast('/').substringAfterLast('\\').substringBeforeLast('.')
            val taggedTitle=metadata?.substringAfterLast(" - ")?.trim().orEmpty()
            val wanted=normalizePlaylistTitle(taggedTitle.ifBlank { pathName })
            val matched=library.firstOrNull { normalizePlaylistTitle(it.name)==wanted }
            val direct=if(line.startsWith("content://",true)) runCatching {
                val externalUri=Uri.parse(line)
                context.contentResolver.openInputStream(externalUri)?.use { } ?: error("playlist URI is not readable")
                runCatching { context.contentResolver.takePersistableUriPermission(externalUri,Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                androidx.documentfile.provider.DocumentFile.fromSingleUri(context,externalUri)?.let { BreakItem(it,metadata?.takeIf{it.isNotBlank()} ?: pathName,externalUri.toString().contains("youtube",true)) }
            }.getOrNull() else runCatching { java.io.File(line).takeIf { it.isFile }?.let { BreakItem(androidx.documentfile.provider.DocumentFile.fromFile(it),metadata?.takeIf{it.isNotBlank()} ?: pathName,false) } }.getOrNull()
            if(matched!=null) entries.add(BreakPlaylistEntry(matched.name,matched.file.uri.toString(),matched.isYoutube,false))
            else if(direct!=null) entries.add(BreakPlaylistEntry(direct.name,direct.file.uri.toString(),direct.isYoutube,false))
            else entries.add(BreakPlaylistEntry(metadata?.takeIf{it.isNotBlank()} ?: pathName,"missing://entry/$index?source="+Uri.encode(line),false,true))
            metadata=null
        }
        val index=store.createImported(displayName.substringBeforeLast('.'),entries)
        val matched=entries.count{!it.missing}; val missing=entries.size-matched
        uiToast(context,"PLAYLIST IMPORTED · $matched MATCHED · $missing MISSING",android.widget.Toast.LENGTH_LONG).show()
        index
    }.getOrElse {
        uiToast(context,it.message ?: "Playlist import failed.",android.widget.Toast.LENGTH_LONG).show()
        store.activeIndex
    }
}

private fun normalizePlaylistTitle(value:String):String = value.substringBeforeLast('.').lowercase(Locale.ROOT)
    .replace(Regex("\\([^)]*\\)|\\[[^\\]]*\\]"), " ")
    .replace(Regex("[^\\p{L}\\p{N}]+")," ").trim().replace(Regex("\\s+")," ")

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun StoneButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    brightActive: Boolean = false,
    enabled: Boolean = true,
    onLongClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val stoneShape = GenericShape { size, _ ->
        moveTo(size.width * .06f, 0f)
        lineTo(size.width * .91f, size.height * .03f)
        lineTo(size.width, size.height * .18f)
        lineTo(size.width * .96f, size.height * .88f)
        lineTo(size.width * .84f, size.height)
        lineTo(size.width * .08f, size.height * .96f)
        lineTo(0f, size.height * .80f)
        lineTo(size.width * .02f, size.height * .12f)
        close()
    }
    val edge = if (active) MonsterGreen else Color(0xFF4A5147)
    val top = if (active) { if (brightActive) Color(0xFF32E35A) else Color(0xFF345E3A) } else Color(0xFF30332E)
    val bottom = if (active) { if (brightActive) Color(0xFF12A936) else Color(0xFF172B1B) } else Color(0xFF20221F)
    Box(
        modifier = modifier
            .padding(2.dp)
            .heightIn(min = 48.dp)
            .background(Brush.verticalGradient(listOf(top, bottom)), stoneShape)
            .border(2.dp, edge, stoneShape)
            .drawBehind {
                val crack = Color.Black.copy(alpha = .28f)
                drawLine(crack, androidx.compose.ui.geometry.Offset(size.width * .17f, size.height * .18f), androidx.compose.ui.geometry.Offset(size.width * .28f, size.height * .31f), 1.3.dp.toPx())
                drawLine(crack, androidx.compose.ui.geometry.Offset(size.width * .74f, size.height * .70f), androidx.compose.ui.geometry.Offset(size.width * .84f, size.height * .61f), 1.2.dp.toPx())
                drawLine(edge.copy(alpha = .24f), androidx.compose.ui.geometry.Offset(size.width * .08f, size.height * .10f), androidx.compose.ui.geometry.Offset(size.width * .86f, size.height * .08f), 1.dp.toPx())
            }
            .then(if (onLongClick == null) Modifier.combinedClickable(enabled = enabled, onClick = onClick, onLongClick = {}) else Modifier.combinedClickable(enabled = enabled, onClick = onClick, onLongClick = onLongClick))
            .padding(horizontal = 8.dp, vertical = 0.dp),
        contentAlignment = Alignment.Center,
        content = { Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) { content() } }
    )
}

@Composable
private fun WaitStoneLabel(fontSize: TextUnit = 13.sp) {
    Row(
        Modifier.semantics { contentDescription = AppLanguage.text("Loading, please wait") },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        CircularProgressIndicator(Modifier.size(12.dp), color = MonsterGreen, strokeWidth = 2.dp)
        FittedControlText(AppLanguage.text("WAIT"), color = Color.White, fontSize = fontSize, fontWeight = FontWeight.Black, maxLines = 1)
    }
}

@Composable
private fun ToolbarStoneLabel(text: String, color: Color, fontSize: TextUnit) {
    val measurer = rememberTextMeasurer()
    BoxWithConstraints(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        val style = TextStyle(fontSize = fontSize, fontWeight = FontWeight.Black)
        val textWidth = measurer.measure(text, style = style, maxLines = 1, softWrap = false).size.width
        val available = with(LocalDensity.current) { maxWidth.toPx() }
        val scale = (available / textWidth.coerceAtLeast(1)).coerceIn(0f, 1f)
        StoneLabel(text, color, (fontSize.value * scale).coerceAtLeast(1f).sp)
    }
}

@Composable
private fun BoxScope.StoneLabel(text:String, color:Color, fontSize:TextUnit) {
    Text(
        text=text,
        modifier=Modifier.align(Alignment.Center).fillMaxWidth(),
        color=color,
        fontSize=fontSize,
        lineHeight=fontSize,
        fontWeight=FontWeight.Black,
        maxLines=1,
        softWrap=false,
        textAlign=TextAlign.Center,
        style=TextStyle(platformStyle=PlatformTextStyle(includeFontPadding=false))
    )
}

/** Keep the exact header labels visible even when Android's accessibility
 *  font size changes. Stone buttons have 8dp of interior horizontal padding:
 *  measure the rendered text rather than assuming a fixed number of letters fit.
 */
@Composable
private fun HeaderStoneText(label: String, requestedSize: TextUnit, lineCount: Int) {
    val localizedLabel = AppLanguage.text(label)
    BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val measurer = rememberTextMeasurer()
        val density = LocalDensity.current
        val actualWidthPx = with(density) { maxWidth.roundToPx() }.coerceAtLeast(1)
        val natural = measurer.measure(
            text = localizedLabel,
            style = TextStyle(fontSize = requestedSize, fontWeight = FontWeight.Black),
            softWrap = false,
            maxLines = lineCount,
            constraints = Constraints()
        )
        val fittedScale = (actualWidthPx.toFloat() / natural.size.width.coerceAtLeast(1))
            .coerceIn(0.65f, 1f)
        val fittedSize = (requestedSize.value * fittedScale * 0.96f).sp
        Text(
            text = localizedLabel,
            color = Color.White,
            fontSize = fittedSize,
            lineHeight = (fittedSize.value * 1.14f).sp,
            fontWeight = FontWeight.Black,
            textAlign = TextAlign.Center,
            maxLines = lineCount,
            softWrap = false,
            overflow = TextOverflow.Clip,
            style = TextStyle(platformStyle = PlatformTextStyle(includeFontPadding = false))
        )
    }
}

/** Carved, irregular stone used by the playlist controls only. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PlaylistStoneButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    redActive: Boolean = false,
    blueTone: Boolean = false,
    redTone: Boolean = false,
    raised: Boolean = false,
    queueTone: Boolean = false,
    mySavesTone: Boolean = false,
    localTone: Boolean = false,
    welcomeTone: Boolean = false,
    onLongClick: (() -> Unit)? = null,
    contentPadding: Dp = 8.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val stoneShape = GenericShape { size, _ ->
        moveTo(size.width * .08f, size.height * .04f)
        lineTo(size.width * .43f, size.height * .01f)
        lineTo(size.width * .49f, size.height * .045f)
        lineTo(size.width * .91f, size.height * .025f)
        lineTo(size.width * .985f, size.height * .22f)
        lineTo(size.width * .96f, size.height * .76f)
        lineTo(size.width * .88f, size.height * .97f)
        lineTo(size.width * .57f, size.height * .94f)
        lineTo(size.width * .50f, size.height * .99f)
        lineTo(size.width * .12f, size.height * .96f)
        lineTo(size.width * .015f, size.height * .79f)
        lineTo(size.width * .04f, size.height * .25f)
        close()
    }
    val edge = when {
        redActive -> Color(0xFFFFD45C)
        redTone -> Color(0xFFCE746C)
        blueTone -> Color(0xFF7BAFD8)
        queueTone -> Color(0xFF99958A) // charcoal stone
        localTone -> Color(0xFF72B1CF) // slate blue stone
        welcomeTone -> Color(0xFFC7A66A) // warm sandstone
        active -> Color(0xFFB3C478)
        mySavesTone -> Color(0xFF8B8A6E)
        else -> Color(0xFF77796D)
    }
    val light = when {
        redActive -> Color(0xFF9E281C)
        redTone -> Color(0xFF893B37)
        blueTone -> Color(0xFF315F87)
        queueTone -> Color(0xFF58534D)
        localTone -> Color(0xFF3B748A)
        welcomeTone -> Color(0xFF8E7040)
        active -> Color(0xFF747B53)
        mySavesTone -> Color(0xFF707064)
        else -> Color(0xFF64665E)
    }
    val dark = when {
        redActive -> Color(0xFF300B08)
        redTone -> Color(0xFF381415)
        blueTone -> Color(0xFF142B46)
        queueTone -> Color(0xFF1C1B1B)
        localTone -> Color(0xFF122735)
        welcomeTone -> Color(0xFF302318)
        active -> Color(0xFF303522)
        mySavesTone -> Color(0xFF34352E)
        else -> Color(0xFF292B28)
    }
    val mid = when {
        redActive -> Color(0xFF681918)
        redTone -> Color(0xFF592426)
        blueTone -> Color(0xFF22476E)
        else -> Color(0xFF484A43)
    }
    Box(
        modifier = modifier
            .padding(if (raised) 0.dp else 2.dp)
            .then(if (raised) Modifier.shadow(5.dp, stoneShape, clip = false) else Modifier)
            .background(Brush.verticalGradient(listOf(light, mid, dark)), stoneShape)
            .border(if (raised) 4.dp else if(redActive) 3.dp else 2.dp, edge, stoneShape)
            .drawBehind {
                val px = size.width
                val py = size.height
                // Shallow top/left relief and a darker lower edge give the stone depth.
                drawLine(Color.White.copy(alpha = .20f), androidx.compose.ui.geometry.Offset(px * .10f, py * .15f), androidx.compose.ui.geometry.Offset(px * .20f, py * .08f), 1.6.dp.toPx())
                drawLine(Color.Black.copy(alpha = .36f), androidx.compose.ui.geometry.Offset(px * .12f, py * .86f), androidx.compose.ui.geometry.Offset(px * .85f, py * .90f), 1.7.dp.toPx())
                val crack = Color.Black.copy(alpha = .48f)
                drawLine(crack, androidx.compose.ui.geometry.Offset(px * .22f, py * .20f), androidx.compose.ui.geometry.Offset(px * .29f, py * .43f), 1.3.dp.toPx())
                drawLine(crack, androidx.compose.ui.geometry.Offset(px * .29f, py * .43f), androidx.compose.ui.geometry.Offset(px * .24f, py * .55f), 1.1.dp.toPx())
                drawLine(crack, androidx.compose.ui.geometry.Offset(px * .78f, py * .53f), androidx.compose.ui.geometry.Offset(px * .70f, py * .69f), 1.3.dp.toPx())
                drawLine(edge.copy(alpha = .34f), androidx.compose.ui.geometry.Offset(px * .35f, py * .16f), androidx.compose.ui.geometry.Offset(px * .69f, py * .14f), 1.dp.toPx())
                if (redActive) {
                    drawLine(Color.White.copy(alpha = .32f), androidx.compose.ui.geometry.Offset(px * .10f, py * .13f), androidx.compose.ui.geometry.Offset(px * .86f, py * .13f), (if (raised) 4.dp else 3.dp).toPx())
                    drawLine(Color.Black.copy(alpha = .72f), androidx.compose.ui.geometry.Offset(px * .12f, py * .82f), androidx.compose.ui.geometry.Offset(px * .87f, py * .82f), (if (raised) 6.dp else 4.dp).toPx())
                }
            }
            .then(if (onLongClick == null) Modifier.combinedClickable(onClick = onClick, onLongClick = {}) else Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick))
            .padding(horizontal = contentPadding),
        contentAlignment = Alignment.Center,
        content = { Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) { content() } }
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun RoundModeButton(
    selected: Boolean,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier.size(58.dp),
    content: @Composable BoxScope.() -> Unit
) {
    val bg = if (selected) Amber else MutedGreen
    val border = if (selected) Color.White.copy(alpha = .55f) else Color.Black.copy(alpha = .4f)
    Box(
        modifier = modifier.clip(RoundedCornerShape(18.dp))
            .background(bg)
            .border(2.dp, border, RoundedCornerShape(18.dp))
            .semantics { this.contentDescription = contentDescription }
            .combinedClickable(onClick = onClick, onLongClick = {}),
        contentAlignment = Alignment.Center,
        content = content
    )
}

/** A fixed, purely decorative copy of the muted rope from RopeVolumeSlider.
 * No rock/thumb or input handler: the top border must not change system volume.
 */
@Composable
private fun WindowTopRope(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val y = size.height / 2f
        drawLine(Color.Black.copy(alpha = .48f),
            androidx.compose.ui.geometry.Offset(0f, y + 2.dp.toPx()),
            androidx.compose.ui.geometry.Offset(size.width, y + 2.dp.toPx()), 9.dp.toPx())
        drawLine(Color(0xFF6B5635),
            androidx.compose.ui.geometry.Offset(0f, y),
            androidx.compose.ui.geometry.Offset(size.width, y), 8.dp.toPx())
        drawLine(Color(0xFF9A7B49).copy(alpha = .72f),
            androidx.compose.ui.geometry.Offset(0f, y - 1.dp.toPx()),
            androidx.compose.ui.geometry.Offset(size.width, y - 1.dp.toPx()), 2.dp.toPx())
        var x = 8.dp.toPx()
        while (x < size.width) {
            drawLine(Color(0xFF3D3020).copy(alpha = .65f),
                androidx.compose.ui.geometry.Offset(x - 4.dp.toPx(), y - 4.dp.toPx()),
                androidx.compose.ui.geometry.Offset(x + 4.dp.toPx(), y + 4.dp.toPx()), 1.2.dp.toPx())
            x += 18.dp.toPx()
        }
    }
}

@Composable
private fun RopeVolumeSlider(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val audio = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val max = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var level by remember { mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max) }
    fun setLevel(v: Float) {
        level = v.coerceIn(0f, 1f)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (level * max).toInt(), 0)
    }
    Canvas(
        modifier = modifier.pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { p -> setLevel(p.x / size.width.toFloat()) },
                onDrag = { change, _ -> setLevel(change.position.x / size.width.toFloat()); change.consume() }
            )
        }
    ) {
        val y = size.height / 2f
        // dark shadow under the rope
        drawLine(Color.Black.copy(alpha=.48f), androidx.compose.ui.geometry.Offset(0f, y + 2.dp.toPx()), androidx.compose.ui.geometry.Offset(size.width, y + 2.dp.toPx()), 9.dp.toPx())
        // old rope body, deliberately muted rather than fluorescent
        drawLine(Color(0xFF6B5635), androidx.compose.ui.geometry.Offset(0f, y), androidx.compose.ui.geometry.Offset(size.width, y), 8.dp.toPx())
        drawLine(Color(0xFF9A7B49).copy(alpha=.72f), androidx.compose.ui.geometry.Offset(0f, y - 1.dp.toPx()), androidx.compose.ui.geometry.Offset(size.width, y - 1.dp.toPx()), 2.dp.toPx())
        // rope twist marks
        var x = 8.dp.toPx()
        while (x < size.width) {
            drawLine(Color(0xFF3D3020).copy(alpha=.65f), androidx.compose.ui.geometry.Offset(x - 4.dp.toPx(), y - 4.dp.toPx()), androidx.compose.ui.geometry.Offset(x + 4.dp.toPx(), y + 4.dp.toPx()), 1.2.dp.toPx())
            x += 18.dp.toPx()
        }
        val cx = level * size.width
        val stone = Path().apply {
            moveTo(cx - 12.dp.toPx(), y - 9.dp.toPx()); lineTo(cx + 8.dp.toPx(), y - 11.dp.toPx())
            lineTo(cx + 13.dp.toPx(), y - 2.dp.toPx()); lineTo(cx + 10.dp.toPx(), y + 9.dp.toPx())
            lineTo(cx - 8.dp.toPx(), y + 11.dp.toPx()); lineTo(cx - 14.dp.toPx(), y + 3.dp.toPx()); close()
        }
        drawPath(stone, Color(0xFF5A5A50))
        drawPath(stone, Color(0xFF8A8979), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5.dp.toPx()))
        drawLine(Color.Black.copy(alpha=.35f), androidx.compose.ui.geometry.Offset(cx-5.dp.toPx(), y-4.dp.toPx()), androidx.compose.ui.geometry.Offset(cx+4.dp.toPx(), y+3.dp.toPx()), 1.dp.toPx())
    }
}

@Composable
private fun RopeProgressDisplay(value: Float, onSeekFraction: (Float) -> Unit, modifier: Modifier = Modifier) {
    // The rope is a seek control again: tap anywhere or drag the stone knob.
    // Seeking is committed on release to avoid flooding the playback service.
    var dragFraction by remember { mutableFloatStateOf(value.coerceIn(0f, 1f)) }
    var dragging by remember { mutableStateOf(false) }
    val shownFraction = if (dragging) dragFraction else value.coerceIn(0f, 1f)
    val currentSeek by rememberUpdatedState(onSeekFraction)
    val interactiveModifier = modifier
        .semantics { contentDescription = AppLanguage.text("Song position. Tap or drag to seek.") }
        .pointerInput(Unit) {
            detectTapGestures { offset ->
                if (size.width > 0) currentSeek((offset.x / size.width).coerceIn(0f, 1f))
            }
        }
        .pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { offset ->
                    dragging = true
                    dragFraction = if (size.width > 0) (offset.x / size.width).coerceIn(0f, 1f) else value
                },
                onDrag = { change, _ ->
                    dragFraction = if (size.width > 0) (change.position.x / size.width).coerceIn(0f, 1f) else dragFraction
                    change.consume()
                },
                onDragEnd = { dragging = false; currentSeek(dragFraction) },
                onDragCancel = { dragging = false }
            )
        }
    Canvas(interactiveModifier) {
        val y = size.height / 2f
        val ropeDark = Color(0xFF3B2A18)
        val rope = Color(0xFF8C6A3D)
        val ropeHi = Color(0xFFB99558)
        drawLine(Color.Black.copy(alpha=.55f), androidx.compose.ui.geometry.Offset(0f, y + 2.dp.toPx()), androidx.compose.ui.geometry.Offset(size.width, y + 2.dp.toPx()), 9.dp.toPx())
        drawLine(ropeDark, androidx.compose.ui.geometry.Offset(0f, y), androidx.compose.ui.geometry.Offset(size.width, y), 8.dp.toPx())
        drawLine(rope, androidx.compose.ui.geometry.Offset(0f, y), androidx.compose.ui.geometry.Offset(size.width, y), 6.dp.toPx())
        drawLine(ropeHi.copy(alpha=.65f), androidx.compose.ui.geometry.Offset(0f, y - 1.5.dp.toPx()), androidx.compose.ui.geometry.Offset(size.width, y - 1.5.dp.toPx()), 1.5.dp.toPx())
        var x = 8.dp.toPx()
        while (x < size.width) {
            drawLine(ropeDark.copy(alpha=.72f), androidx.compose.ui.geometry.Offset(x-4.dp.toPx(), y-3.dp.toPx()), androidx.compose.ui.geometry.Offset(x+4.dp.toPx(), y+3.dp.toPx()), 1.dp.toPx())
            x += 17.dp.toPx()
        }
        val cx = shownFraction * size.width
        val r = 11.dp.toPx()
        drawCircle(Color.Black.copy(alpha=.5f), r + 2.dp.toPx(), androidx.compose.ui.geometry.Offset(cx, y + 2.dp.toPx()))
        drawCircle(Color(0xFF4A4B43), r, androidx.compose.ui.geometry.Offset(cx, y))
        drawCircle(Color(0xFF858574), r, androidx.compose.ui.geometry.Offset(cx, y), style = androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))
        drawCircle(Color.White.copy(alpha=.16f), r*.42f, androidx.compose.ui.geometry.Offset(cx-r*.25f, y-r*.28f))
    }
}

/**
 * Bottom-bar title with its own measured horizontal scroll viewport.
 * Unlike a clipped Text + basicMarquee, this scrolls the actual overflowing
 * filename in one line and resets on every track change. Short names stay still.
 */
@Composable
private fun PlaybackBar(model: BreakMonsterModel, backupBusy: Boolean, nameValue:String, onNameChange:(String)->Unit, onSaveYoutube: () -> Unit, saveToQueue: Boolean, onTransitionNext: () -> Unit, onTransitionStop: () -> Unit, onFeedMonster: () -> Unit, onMixerOpen: () -> Unit, modifier: Modifier = Modifier) {
    val pendingYoutubeSave = model.youtubeCanSave && model.youtubeVideoId != null
    val ytActive = model.youtubeVideoId != null && !pendingYoutubeSave
    val localActive = model.localTrackUri != null
    Surface(
        color = Color(0xF500140C),
        tonalElevation = 4.dp,
        modifier = modifier.fillMaxWidth().border(1.dp, Amber.copy(alpha = .65f))
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp)) {
            if (pendingYoutubeSave) {
                OutlinedTextField(
                    value=nameValue,
                    onValueChange=onNameChange,
                    singleLine=true,
                    label={FittedControlText(AppLanguage.text("IME NUMERE"),fontSize=11.sp)},
                    textStyle=TextStyle(color=Color.White,fontSize=15.sp,fontWeight=FontWeight.Bold),
                    modifier=Modifier.fillMaxWidth().height(48.dp),
                    colors=androidx.compose.material3.OutlinedTextFieldDefaults.colors(focusedTextColor=Color.White,unfocusedTextColor=Color.White,focusedBorderColor=MonsterGreen,unfocusedBorderColor=MonsterGreen.copy(alpha=.6f),focusedLabelColor=MonsterGreen,unfocusedLabelColor=MonsterGreen)
                )
            }
            BoxWithConstraints(Modifier.fillMaxWidth()) {
            val phone = LocalConfiguration.current.smallestScreenWidthDp < 600
            val compact = maxWidth < 550.dp
            val narrow = maxWidth < 390.dp
            Row(
                Modifier.fillMaxWidth().height(72.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(if(narrow) 1.dp else if(compact) 3.dp else 8.dp)
            ) {
                Button(
                    onClick = { model.previousLocal() },
                    enabled = localActive || ytActive,
                    modifier = Modifier.size(width = if(narrow) 32.dp else if(compact) 35.dp else 52.dp, height = 52.dp)
                        .semantics { contentDescription = AppLanguage.text("Previous track") },
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MutedGreen, contentColor = Color.White)
                ) { FittedControlText(AppLanguage.text("|◀"), fontSize = 19.sp, fontWeight = FontWeight.Black) }
                Button(
                    onClick = {
                        if (ytActive) {
                            model.toggleLocalPause()
                        } else model.toggleLocalPause()
                    },
                    enabled = ytActive || localActive,
                    modifier = Modifier.size(width = if(narrow) 32.dp else if(compact) 37.dp else 60.dp, height = 52.dp),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color.Black)
                ) { Text(AppLanguage.text(if (if (ytActive) model.youtubePlaying else model.localPlaying) "Ⅱ" else "▶"), fontSize = 26.sp, fontWeight = FontWeight.Black) }

                Button(
                    onClick = {
                        onTransitionStop()
                        if (ytActive) {
                            model.stopPlayback()
                        } else model.stopPlayback()
                    },
                    enabled = ytActive || localActive,
                    modifier = Modifier.size(width = if(narrow) 32.dp else if(compact) 37.dp else 60.dp, height = 52.dp),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MutedGreen, contentColor = Color.White)
                ) { FittedControlText(AppLanguage.text("■"), fontSize = 24.sp) }

                if (pendingYoutubeSave && !model.youtubeSaved) {
                    Button(
                        onClick = onSaveYoutube,
                        modifier = Modifier.height(52.dp).weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MutedGreen, contentColor = Color.White)
                    ) { Text(AppLanguage.text(if (saveToQueue) "SAVE TO QUEUE" else "WEB SAVE"), fontWeight = FontWeight.Black, fontSize = if(compact) 14.sp else 17.sp, maxLines=1) }
                } else {
                    PlaylistStoneButton(
                        onClick = {
                            if (ytActive) onTransitionNext()
                            if (ytActive || localActive) model.nextLocal()
                        },
                        active = ytActive || localActive,
                        modifier = Modifier.width(if (narrow) 47.dp else if (compact) 60.dp else 75.dp).height(54.dp)
                    ) { FittedControlText(AppLanguage.text("|▶"), color = Color.White, fontWeight = FontWeight.Black, fontSize = if (phone) 20.sp else 34.sp, maxLines = 1, softWrap = false) }
                }

                MixerFxProButtons(
                    onMixerOpen = onMixerOpen, onClick = onFeedMonster, backupBusy = backupBusy,
                    modifier = Modifier.weight(3f), compact = compact, narrow = narrow
                )
            }
            }
            val pos = if (ytActive) (model.youtubeCurrentSecond * 1000).toInt() else model.localPosition
            val dur = if (ytActive) (model.youtubeDurationSecond * 1000).toInt() else model.localDuration
            RopeProgressDisplay(
                value = if (dur > 0) pos.coerceIn(0, dur).toFloat() / dur else 0f,
                onSeekFraction = { fraction ->
                    if (dur > 0 && (ytActive || localActive)) {
                        model.seekLocal((fraction.coerceIn(0f, 1f) * dur).toInt())
                    }
                },
                modifier = Modifier.fillMaxWidth().height(28.dp)
            )
            Text(AppLanguage.text("${timeLabel(pos)} / ${timeLabel(dur)}"), color = MonsterGreen,
                fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
    }
}

private fun timeLabel(ms: Int): String = "%d:%02d".format(Locale.ROOT, ms / 60000, ms / 1000 % 60)

@Composable
private fun YouTubeBadge(modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(id = R.drawable.pro_file_badge_trex),
        contentDescription = null,
        modifier = modifier.padding(4.dp),
        contentScale = ContentScale.Fit
    )
}

@Composable
private fun ShuffleGlyph(crossed:Boolean, modifier:Modifier=Modifier, tint:Color=Color.White) {
    Canvas(modifier) {
        val w=size.width; val h=size.height
        val inset=w*.13f; val half=h*.5f; val stroke=(h*.095f).coerceAtLeast(1.5.dp.toPx())
        fun arrow(x1:Float,y1:Float,x2:Float,y2:Float) {
            drawLine(tint,androidx.compose.ui.geometry.Offset(x1,y1),androidx.compose.ui.geometry.Offset(x2,y2),stroke,cap=androidx.compose.ui.graphics.StrokeCap.Round)
            val direction=if(x2>=x1) 1f else -1f
            val back=x2-direction*w*.18f
            val head=h*.16f
            drawLine(tint,androidx.compose.ui.geometry.Offset(x2,y2),androidx.compose.ui.geometry.Offset(back,y2-head),stroke,cap=androidx.compose.ui.graphics.StrokeCap.Round)
            drawLine(tint,androidx.compose.ui.geometry.Offset(x2,y2),androidx.compose.ui.geometry.Offset(back,y2+head),stroke,cap=androidx.compose.ui.graphics.StrokeCap.Round)
        }
        if(crossed) {
            arrow(inset,h*.25f,w-inset,h*.75f)
            arrow(w-inset,h*.25f,inset,h*.75f)
        } else {
            arrow(inset,h*.31f,w-inset,h*.31f)
            arrow(w-inset,h*.69f,inset,h*.69f)
        }
    }
}

@Composable
private fun MediaTypeBadge(extension: String, scale: Float = 1f) {
    val ext=extension.uppercase(Locale.ROOT).ifBlank { "FILE" }
    val label=when(ext){"WAVE"->"WAV";"M4V"->"MP4";"3G2"->"3GP";"M2TS"->"TS";else->ext}
    val video=ext in setOf("MP4","M4V","MOV","3GP","3G2","MKV","WEBM","AVI","TS","M2TS","MPEG","MPG")
    Box(Modifier.widthIn(min = 42.dp * scale).height(28.dp * scale).background(if(video)Color(0xFF34483A)else Color(0xFF263B2E),RoundedCornerShape(6.dp)).border(1.dp,MonsterGreen.copy(alpha=.6f),RoundedCornerShape(6.dp)),contentAlignment=Alignment.Center){
        Text(AppLanguage.text(label),color=Color.White,fontSize=(10f * scale).sp,fontWeight=FontWeight.Black,maxLines=1,modifier=Modifier.padding(horizontal=4.dp))
    }
}

private class YoutubeJsBridge(
    private val web: WebView,
    private val onSelected: (String, String?, String) -> Unit
) {
    @JavascriptInterface
    fun select(url: String?, title: String?, channel: String?) {
        val id = BreakMonsterModel.extractYoutubeVideoId(url) ?: return
        val canonical = "https://www.youtube.com/watch?v=$id"
        web.post { onSelected(id, youtubeSongName(channel, title), canonical) }
    }
}

/** Result labels belong to the page; selecting one presses its ORIGINAL DOM button. */
private data class CloudSearchChoice(val title: String, val detail: String)

/**
 * The site can find results while Android WebView clips its HTML dialog. A tiny
 * read-only JS bridge copies ONLY rendered result captions into a native Compose
 * dialog. The original Cloudflare buttons still own the load and save actions.
 */
private class CloudResultsBridge(
    private val webView: WebView,
    private val onResults: (List<CloudSearchChoice>) -> Unit
) {
    @JavascriptInterface
    fun present(json: String?) {
        if (json.isNullOrBlank() || json.length > 65_536) return
        val choices = runCatching {
            val values = JSONArray(json)
            if (values.length() !in 1..100) return@runCatching emptyList()
            (0 until values.length()).map { index ->
                val value = values.getJSONObject(index)
                CloudSearchChoice(
                    value.optString("title").trim().take(220),
                    value.optString("detail").trim().take(220)
                )
            }.filter { it.title.isNotBlank() }
        }.getOrDefault(emptyList())
        if (choices.isEmpty()) return
        webView.post {
            val url = runCatching { Uri.parse(webView.url) }.getOrNull()
            // Android JS interfaces are callable by subframes. Never accept
            // requests when the main WebView is off our fixed HTTPS origin.
            if (url?.scheme.equals("https", true) &&
                url?.host.equals(Uri.parse(PLAYLIST_WEB_URL).host, true)) {
                onResults(choices)
            }
        }
    }
}

/** Install after the page loads. Works with both old <dialog> and new div popup. */
private val CLOUD_RESULTS_OBSERVER_JS = """(function(){
  if(window.__bmNativeChoicesInstalled)return;
  window.__bmNativeChoicesInstalled=true;
  var wasOpen=false, scheduled=false;
  function inspect(){
    scheduled=false;
    try{
      var modal=document.getElementById('choices');
      var list=document.getElementById('choiceList');
      if(!modal || !list || !window.BrakePlaylistResults)return;
      var rows=list.querySelectorAll('button');
      var open=rows.length>0 && (modal.tagName==='DIALOG' ? modal.open===true : !modal.hasAttribute('hidden'));
      if(open && !wasOpen){
        var result=[];
        for(var i=0;i<rows.length && i<100;i++){
          var b=rows[i];
          var strong=b.querySelector('strong');
          var small=b.querySelector('small');
          result.push({title:(strong?strong.textContent:b.textContent||'').trim(),
                       detail:(small?small.textContent:'').trim()});
        }
        window.BrakePlaylistResults.present(JSON.stringify(result));
      }
      wasOpen=open;
    }catch(e){}
  }
  function update(){if(!scheduled){scheduled=true;requestAnimationFrame(inspect);}}
  var observer=new MutationObserver(update);
  observer.observe(document.documentElement,{subtree:true,childList:true,attributes:true,
    attributeFilter:['open','hidden','class','style']});
  update();
})();"""

/**
 * Only SEARCH PLAYLISTS opens this address-bar-free in-app browser.
 * Cloudflare continues to perform the search, choice loading and SAVE PLAYLIST.
 * A native results chooser bypasses the Android WebView modal-rendering bug.
 */
private class CloudZipDownloadBridge(private val context: Context) {
    private data class PendingZip(
        val id: String, val uri: Uri, val expected: Long, val output: java.io.OutputStream,
        val name: String, var received: Long = 0, var nextChunk: Int = 0
    )
    private var pending: PendingZip? = null
    private val maxBytes = 40L * 1024L * 1024L
    private fun toast(message: String) = android.os.Handler(android.os.Looper.getMainLooper()).post {
        uiToast(context, message, Toast.LENGTH_LONG).show()
    }
    private fun safeName(suggested: String?): String = (suggested ?: "BrakeMonster_Playlist.zip")
        .substringAfterLast('/').substringAfterLast('\\')
        .replace(Regex("[^a-zA-Z0-9._ -]"), "_").take(100)
        .let { if (it.endsWith(".zip", true)) it else "$it.zip" }
    private fun deletePending() {
        val old = pending ?: return
        runCatching { old.output.close() }
        runCatching { context.contentResolver.delete(old.uri, null, null) }
        pending = null
    }
    @JavascriptInterface
    @Synchronized fun beginZip(name: String?, expectedBytes: Long): String {
        deletePending()
        if (expectedBytes !in 22..maxBytes) { toast("ZIP download failed: invalid size (${expectedBytes} bytes)"); return "" }
        val safe = safeName(name)
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, safe)
            put(MediaStore.Downloads.MIME_TYPE, "application/zip")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        return try {
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Android could not create the Downloads file")
            val output = try { resolver.openOutputStream(uri, "w") }
                catch (e: Exception) { resolver.delete(uri, null, null); throw e }
                ?: run { resolver.delete(uri, null, null); throw IllegalStateException("Android could not open the ZIP file") }
            val id = java.util.UUID.randomUUID().toString()
            pending = PendingZip(id, uri, expectedBytes, output, safe)
            id
        } catch (e: Exception) {
            toast("ZIP download failed: ${e.message ?: "cannot create Downloads file"}")
            ""
        }
    }
    @JavascriptInterface
    @Synchronized fun writeZipChunk(id: String, index: Int, base64: String): Boolean {
        val file = pending
        if (file == null || file.id != id || index != file.nextChunk || base64.length > 350_000) {
            deletePending(); toast("ZIP download failed: invalid or out-of-order data"); return false
        }
        return try {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            if (bytes.isEmpty() || bytes.size > 256 * 1024 || file.received + bytes.size > file.expected || file.received + bytes.size > maxBytes)
                throw IllegalArgumentException("ZIP chunk exceeds the allowed size")
            if (file.received == 0L && (bytes.size < 4 || bytes[0] != 0x50.toByte() || bytes[1] != 0x4b.toByte()))
                throw IllegalArgumentException("File does not have a ZIP signature")
            file.output.write(bytes)
            file.received += bytes.size
            file.nextChunk++
            true
        } catch (e: Exception) {
            deletePending(); toast("ZIP download failed: ${e.message ?: "cannot write ZIP data"}")
            false
        }
    }
    @JavascriptInterface
    @Synchronized fun finishZip(id: String): Boolean {
        val file = pending
        if (file == null || file.id != id) { deletePending(); toast("ZIP download failed: download session expired"); return false }
        try {
            if (file.received != file.expected) throw IllegalStateException("incomplete ZIP (${file.received}/${file.expected} bytes)")
            file.output.flush(); file.output.close()
            var entries = 0
            context.contentResolver.openInputStream(file.uri)?.use { input ->
                java.util.zip.ZipInputStream(java.io.BufferedInputStream(input)).use { zip ->
                    val buffer = ByteArray(32 * 1024)
                    while (true) {
                        val entry = zip.nextEntry ?: break
                        entries++
                        while (zip.read(buffer) >= 0) { }
                        zip.closeEntry()
                    }
                }
            } ?: throw IllegalStateException("cannot verify saved ZIP")
            if (entries == 0) throw IllegalStateException("ZIP contains no playlist data")
            val actualSize = context.contentResolver.openInputStream(file.uri)?.use { stream ->
                var total = 0L; val buffer = ByteArray(32 * 1024); while (true) { val n=stream.read(buffer); if(n<0)break; total+=n }; total
            } ?: -1L
            if (actualSize != file.expected) throw IllegalStateException("saved file size does not match")
            val published = context.contentResolver.update(file.uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
            if (published <= 0) throw IllegalStateException("Android could not publish the verified ZIP")
            pending = null
            toast("DOWNLOAD COMPLETE · ${file.name}")
            return true
        } catch (e: Exception) {
            deletePending()
            toast("ZIP download failed: ${e.message ?: "ZIP verification failed"}")
            return false
        }
    }
    @JavascriptInterface
    @Synchronized fun failZip(id: String?, message: String?) {
        if (id.isNullOrBlank() || pending?.id == id) deletePending()
        toast("ZIP download failed: ${(message ?: "transfer failed").take(120)}")
    }
    @JavascriptInterface
    fun downloadError(message: String) { toast("ZIP download failed: ${message.take(120)}") }
}

/** Transfer client-generated blobs as ordered, bounded binary chunks; never refetch a revoked blob URL. */
private val CLOUD_ZIP_DOWNLOAD_JS = """(function(){
 if(window.__brakeZipHookInstalled)return;
 window.__brakeZipHookInstalled=true;
 var blobs=Object.create(null), busy=false;
 var nativeCreate=URL.createObjectURL.bind(URL), nativeRevoke=URL.revokeObjectURL.bind(URL);
 URL.createObjectURL=function(value){
   var url=nativeCreate(value);
   if(value instanceof Blob)blobs[url]=value;
   return url;
 };
 // Cloudflare may revoke the URL immediately after clicking its download anchor.
 // Retain our Blob reference until Android has completed the transfer.
 URL.revokeObjectURL=function(url){
   nativeRevoke(url);
   if(!busy)delete blobs[url];
 };
 async function sendBlob(blob,name){
   var id='';
   if(busy){BrakeZipDownload.downloadError('Another ZIP download is in progress');return;}
   busy=true;
   try{
     if(!blob || blob.size<22 || blob.size>41943040)throw Error('ZIP size is outside the 40 MB limit');
     id=BrakeZipDownload.beginZip(name||'BrakeMonster_Playlist.zip',blob.size);
     if(!id)throw Error('Android could not start ZIP transfer');
     // Use bounded slices: do not allocate the entire archive a second time.
     var chunkSize=96*1024,index=0;
     for(var offset=0;offset<blob.size;offset+=chunkSize){
       var part=new Uint8Array(await blob.slice(offset,Math.min(offset+chunkSize,blob.size)).arrayBuffer());
       var binary='';
       for(var i=0;i<part.length;i+=0x8000)
         binary+=String.fromCharCode.apply(null,part.subarray(i,Math.min(i+0x8000,part.length)));
       if(!BrakeZipDownload.writeZipChunk(id,index++,btoa(binary)))throw Error('Android rejected ZIP chunk');
     }
     if(!BrakeZipDownload.finishZip(id))return;
   }catch(e){try{BrakeZipDownload.failZip(id,String(e));}catch(_){} }
   finally{busy=false;}
 }
 async function download(url,name){
   try{
     if(url.indexOf('blob:')===0){
       var blob=blobs[url];
       if(!blob){var r=await fetch(url);if(!r.ok)throw Error('Blob unavailable');blob=await r.blob();}
       await sendBlob(blob,name);delete blobs[url];return;
     }
     if(url.indexOf('data:')===0){var d=await fetch(url);await sendBlob(await d.blob(),name);return;}
     var parsed=new URL(url,location.href);
     if(parsed.protocol!=='https:')throw Error('Only HTTPS ZIP downloads are supported');
     var response=await fetch(parsed.href,{credentials:'include'});
     if(!response.ok)throw Error('HTTP '+response.status);
     await sendBlob(await response.blob(),name);
   }catch(e){BrakeZipDownload.downloadError(String(e));}
 }
 window.__bmDownloadByUrl=download;
 document.addEventListener('click',function(event){
   var a=event.target&&event.target.closest&&event.target.closest('a[href]');if(!a)return;
   var href=a.href||'';
   if(a.hasAttribute('download')||href.indexOf('blob:')===0||href.indexOf('data:')===0){
     event.preventDefault();event.stopImmediatePropagation();
     download(href,a.getAttribute('download')||'BrakeMonster_Playlist.zip');
   }
 },true);
 var nativeClick=HTMLAnchorElement.prototype.click;
 HTMLAnchorElement.prototype.click=function(){
   var href=this.href||'';
   if(this.hasAttribute('download')||href.indexOf('blob:')===0||href.indexOf('data:')===0){
     download(href,this.getAttribute('download')||'BrakeMonster_Playlist.zip');return;
   }
   return nativeClick.apply(this,arguments);
 };
})();"""

@Composable
private fun PlaylistCloudBrowser(
    onClose: () -> Unit,
    onWebView: (WebView?) -> Unit,
    onPlaylistLink: (Uri) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var webView by remember { mutableStateOf<WebView?>(null) }
    var canGoBack by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(true) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var choices by remember { mutableStateOf<List<CloudSearchChoice>>(emptyList()) }

    fun closeResults() {
        choices = emptyList()
        // Close the site's original overlay too. This is page UI only;
        // cancellation does not clear filters, search, or imported data.
        webView?.evaluateJavascript("""(function(){var close=document.getElementById('closeDialog');
          if(close)close.click();else{var d=document.getElementById('choices');
            if(d){if(typeof d.close==='function')d.close();else d.hidden=true;}}})();""", null)
    }

    Column(modifier.background(Color.Black).safeDrawingPadding()) {
        Row(
            Modifier.fillMaxWidth().height(64.dp)
                .background(DeepGreen)
                .border(BorderStroke(1.dp, Amber))
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TextButton(
                onClick = { webView?.goBack() }, enabled = canGoBack,
                modifier = Modifier.height(54.dp)
            ) { FittedControlText(AppLanguage.text("BACK"), color = if (canGoBack) Color.White else Color.Gray, fontSize = 19.sp, fontWeight = FontWeight.Black) }
            TextButton(onClick = { webView?.loadUrl(PLAYLIST_WEB_URL) }, modifier = Modifier.height(54.dp)) {
                FittedControlText(AppLanguage.text("HOME"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Black)
            }
            TextButton(onClick = {
                closeResults()
                webView?.evaluateJavascript("""(function(){var b=document.getElementById('resetSearchButton');if(b){b.click();return 'cleared';}return 'unavailable';})();""", null)
            }, modifier = Modifier.height(54.dp)) {
                FittedControlText(AppLanguage.text("CLEAR"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Black)
            }
            Button(
                onClick = onClose, modifier = Modifier.height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color.Black)
            ) { FittedControlText(AppLanguage.text("CLOSE  ✕"), fontSize = 18.sp, fontWeight = FontWeight.Black) }
        }
        Box(Modifier.fillMaxWidth().weight(1f).background(Color.Black)) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { uiContext ->
                    WebView(uiContext).apply {
                        setBackgroundColor(AndroidColor.BLACK)
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        // Chrome-like responsive viewport, without an address field.
                        settings.useWideViewPort = true
                        settings.loadWithOverviewMode = false
                        settings.textZoom = 100
                        settings.allowFileAccess = false
                        settings.allowContentAccess = false
                        settings.mediaPlaybackRequiresUserGesture = true
                        settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
                        settings.setSupportMultipleWindows(false)
                        CookieManager.getInstance().setAcceptCookie(true)
                        addJavascriptInterface(CloudResultsBridge(this) { found ->
                            choices = found
                        }, "BrakePlaylistResults")
                        webChromeClient = WebChromeClient()
                        addJavascriptInterface(CloudZipDownloadBridge(uiContext.applicationContext), "BrakeZipDownload")
                        setDownloadListener { url, _, contentDisposition, _, _ ->
                            val escapedUrl = org.json.JSONObject.quote(url)
                            val fallbackName = contentDisposition?.substringAfter("filename=", "")?.trim(' ', '\"', '\'')
                            val escapedName = org.json.JSONObject.quote(fallbackName?.takeIf { it.isNotBlank() } ?: "BrakeMonster_Playlist.zip")
                            evaluateJavascript("""(function(){if(window.__bmDownloadByUrl){window.__bmDownloadByUrl($escapedUrl,$escapedName);}else{BrakeZipDownload.downloadError('Download handler is not ready');}})();""", null)
                        }
                        webViewClient = object : WebViewClient() {
                            private fun navigate(raw: String?): Boolean {
                                if (raw.isNullOrBlank()) return true
                                val uri = Uri.parse(raw)
                                if (uri.scheme.equals("brakemonster", true)) {
                                    if (uri.host.equals("save-playlist", true)) onPlaylistLink(uri)
                                    return true
                                }
                                if (!uri.scheme.equals("https", true)) return true
                                if (uri.host.equals(Uri.parse(PLAYLIST_WEB_URL).host, true)) return false
                                runCatching {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE))
                                }.onFailure { uiToast(context, "Cannot open external link", Toast.LENGTH_SHORT).show() }
                                return true
                            }
                            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = navigate(request?.url?.toString())
                            @Suppress("DEPRECATION")
                            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean = navigate(url)
                            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                                loading = true
                                loadError = null
                                choices = emptyList()
                                canGoBack = view?.canGoBack() == true
                            }
                            override fun onPageFinished(view: WebView?, url: String?) {
                                loading = false
                                canGoBack = view?.canGoBack() == true
                                if (runCatching { Uri.parse(url).host.equals(Uri.parse(PLAYLIST_WEB_URL).host, true) &&
                                    Uri.parse(url).scheme.equals("https", true) }.getOrDefault(false)) {
                                    view?.evaluateJavascript(CLOUD_RESULTS_OBSERVER_JS, null)
                                    view?.evaluateJavascript(CLOUD_ZIP_DOWNLOAD_JS, null)
                                }
                            }
                            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                                canGoBack = view?.canGoBack() == true
                            }
                            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: android.webkit.WebResourceError?) {
                                if (request?.isForMainFrame == true) {
                                    loading = false
                                    loadError = "Playlist website unavailable. Check connection and press RELOAD."
                                }
                            }
                        }
                        webView = this
                        onWebView(this)
                        loadUrl(PLAYLIST_WEB_URL)
                    }
                },
                onRelease = { released ->
                    onWebView(null)
                    if (webView === released) webView = null
                    released.removeJavascriptInterface("BrakePlaylistResults")
                    released.removeJavascriptInterface("BrakeZipDownload")
                    released.stopLoading()
                    released.destroy()
                }
            )
            if (loading) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter),
                    color = Amber,
                    trackColor = DeepGreen
                )
            }
            loadError?.let { message ->
                Column(
                    Modifier.align(Alignment.Center).fillMaxWidth(.86f)
                        .background(DeepGreen, RoundedCornerShape(14.dp))
                        .border(2.dp, Amber, RoundedCornerShape(14.dp))
                        .padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(message, color = Color.White, fontSize = 22.sp, textAlign = TextAlign.Center)
                    Button(onClick = { webView?.reload() }, colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color.Black)) {
                        FittedControlText(AppLanguage.text("RETRY"), fontSize = 20.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }
    }

    if (choices.isNotEmpty()) {
        Dialog(onDismissRequest = ::closeResults, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Column(
                Modifier.fillMaxWidth(.94f).fillMaxHeight(.88f)
                    .background(Color(0xFF08180F), RoundedCornerShape(16.dp))
                    .border(2.dp, MonsterGreen, RoundedCornerShape(16.dp))
                    .padding(12.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth().heightIn(min = 62.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(AppLanguage.text("CHOOSE A RESULT (${choices.size})"), color = Color.White,
                        fontWeight = FontWeight.Black, fontSize = 21.sp,
                        modifier = Modifier.weight(1f))
                    Button(onClick = ::closeResults,
                        colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color.Black)) {
                        FittedControlText(AppLanguage.text("CLOSE ✕"), fontSize = 18.sp, fontWeight = FontWeight.Black)
                    }
                }
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(top = 12.dp, bottom = 16.dp)
                ) {
                    itemsIndexed(choices) { index, choice ->
                        Column(
                            Modifier.fillMaxWidth()
                                .background(Color(0xFF214B35), RoundedCornerShape(12.dp))
                                .border(1.dp, MonsterGreen.copy(alpha = .45f), RoundedCornerShape(12.dp))
                                .clickable {
                                    // Only an integer index is passed to JS. Click the
                                    // site's existing bound button, preserving search,
                                    // playlist paging and SAVE PLAYLIST unchanged.
                                    choices = emptyList()
                                    webView?.evaluateJavascript(
                                        """(function(){var list=document.getElementById('choiceList');
                                          var b=list&&list.querySelectorAll('button')[$index];
                                          if(b)b.click();})();""", null
                                    )
                                }
                                .padding(18.dp)
                        ) {
                            Text(choice.title, color = Color.White, fontSize = 20.sp,
                                fontWeight = FontWeight.Bold)
                            if (choice.detail.isNotBlank()) {
                                Spacer(Modifier.height(8.dp))
                                Text(choice.detail, color = Color(0xFFD7F6DF), fontSize = 17.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun YoutubeSearchPanel(
    url: String,
    textSize: Float,
    onSelected: (String, String?, String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    releaseOnDispose: Boolean = false
) {
    val context = LocalContext.current
    var webView by remember { mutableStateOf<WebView?>(null) }
    // XL may create several queries in one session. Release each owned result
    // WebView when its query closes; normal view keeps its existing lifecycle.
    DisposableEffect(releaseOnDispose) {
        onDispose {
            if (releaseOnDispose) {
                webView?.stopLoading()
                webView?.removeJavascriptInterface("BreakHost")
                webView?.destroy()
            }
        }
    }

    Box(modifier.background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { uiContext ->
                val created = WebView(uiContext)
                webView = created
                CookieManager.getInstance().apply {
                    setAcceptCookie(true)
                    setAcceptThirdPartyCookies(created, true)
                }
                created.apply {
                    setBackgroundColor(AndroidColor.BLACK)
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.textZoom = (textSize * 4f).toInt()
                    settings.mediaPlaybackRequiresUserGesture = true
                    addJavascriptInterface(YoutubeJsBridge(this, onSelected), "BreakHost")
                    webChromeClient = WebChromeClient()
                    webViewClient = object : WebViewClient() {
                        private fun intercept(raw: String?): Boolean {
                            val id = BreakMonsterModel.extractYoutubeVideoId(raw) ?: return false
                            onSelected(id, null, "https://www.youtube.com/watch?v=$id")
                            return true
                        }
                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = intercept(request?.url?.toString())
                        @Suppress("DEPRECATION")
                        override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean = intercept(url)
                        override fun onPageFinished(view: WebView, pageUrl: String) {
                            super.onPageFinished(view, pageUrl)
                            val host = Uri.parse(pageUrl).host.orEmpty()
                            if (host != "youtube.com" && !host.endsWith(".youtube.com")) return
                            val js = """(function(){
                              document.querySelectorAll('video,audio').forEach(function(v){v.muted=true;v.pause();});
                              if(window.__breakMonsterTap)return;
                              window.__breakMonsterTap=true;
                              var style=document.createElement('style');
                              style.textContent=`
                                .bm-video-row { display:flex !important; align-items:flex-start !important; }
                                .bm-video-thumb {
                                  position:relative !important; box-sizing:border-box !important;
                                  width:min(76px,22vw) !important; min-width:0 !important;
                                  max-width:min(76px,22vw) !important; flex:0 0 min(76px,22vw) !important;
                                  height:auto !important; aspect-ratio:16/9; overflow:hidden !important;
                                  margin:0 8px 0 0 !important;
                                }
                                .bm-video-thumb :is(a, yt-image, ytm-thumbnail, ytd-thumbnail, .yt-core-image),
                                .bm-video-thumb img {
                                  box-sizing:border-box !important; width:100% !important;
                                  min-width:0 !important; max-width:100% !important;
                                  height:100% !important; max-height:100% !important;
                                }
                                .bm-video-thumb img {
                                  position:absolute !important; inset:0 !important;
                                  object-fit:contain !important;
                                }
                                :is(ytm-shorts-lockup-view-model,ytm-shorts-lockup-view-model-v2,yt-shorts-lockup-view-model,
                                    ytm-reel-item-renderer,ytd-reel-item-renderer,.shortsLockupViewModelHost,
                                    .shortsLockupViewModelHostEndpoint) {
                                  box-sizing:border-box !important; width:min(76px,22vw) !important;
                                  min-width:0 !important; max-width:min(76px,22vw) !important;
                                  flex:0 0 min(76px,22vw) !important;
                                }
                                :is(ytm-shorts-lockup-view-model,ytm-shorts-lockup-view-model-v2,yt-shorts-lockup-view-model,
                                    ytm-reel-item-renderer,ytd-reel-item-renderer,.shortsLockupViewModelHost)
                                  :is(.shortsLockupViewModelThumbnail,.shortsLockupViewModelThumbnailContainer,ytm-thumbnail,yt-image) {
                                  width:100% !important; max-width:100% !important;
                                  height:auto !important; aspect-ratio:9/16; overflow:hidden !important;
                                }
                                .bm-video-info :is(yt-avatar-shape,ytm-channel-thumbnail,.yt-spec-avatar-shape) {
                                  width:24px !important; height:24px !important;
                                }
                                .bm-video-info {
                                  position:relative !important; inset:auto !important;
                                  flex:1 1 0 !important; min-width:0 !important;
                                  width:auto !important; max-width:none !important;
                                  margin-inline-start:0 !important;
                                }
                                .media-item-headline, .compact-media-item-headline,
                                .yt-lockup-metadata-view-model__title, #video-title {
                                  height:auto !important; max-height:none !important;
                                  white-space:normal !important; overflow-wrap:anywhere;
                                  -webkit-line-clamp:unset !important;
                                }`;
                              document.head.appendChild(style);
                              var cards='ytm-video-with-context-renderer,ytm-compact-video-renderer,ytm-video-card-renderer,yt-lockup-view-model,ytd-video-renderer,ytd-compact-video-renderer';
                              var titles='#video-title,.media-item-headline,.compact-media-item-headline,.yt-lockup-metadata-view-model__title,h3';
                              var resultCards=cards+',ytm-playlist-renderer,ytm-compact-playlist-renderer,ytm-radio-renderer,ytm-compact-radio-renderer,ytd-playlist-renderer,ytd-radio-renderer';
                              function compactThumbnails(){
                                document.querySelectorAll(resultCards).forEach(function(card){
                                  if(card.querySelector('.bm-video-row') || card.classList.contains('bm-video-row'))return;
                                  var heading=card.querySelector(titles+',.playlist-title,.compact-media-item-title,[role=heading]');
                                  // /vi/ and /vi_webp/ identify actual video art, excluding channel avatars.
                                  var art=Array.from(card.querySelectorAll('img')).find(function(img){
                                    return /\/vi(?:_webp)?\//.test(img.currentSrc || img.src || '');
                                  });
                                  if(!heading || !art)return;
                                  var thumb=art;
                                  while(thumb.parentElement && thumb.parentElement!==card && !thumb.parentElement.contains(heading)){
                                    thumb=thumb.parentElement;
                                  }
                                  var row=thumb.parentElement;
                                  if(!row || !row.contains(heading) || thumb.contains(heading))return;
                                  var info=heading;
                                  while(info.parentElement && info.parentElement!==row)info=info.parentElement;
                                  row.classList.add('bm-video-row');
                                  thumb.classList.add('bm-video-thumb');
                                  info.classList.add('bm-video-info');
                                });
                              }
                              var pending=false;
                              function scheduleThumbnails(){
                                if(pending)return;
                                pending=true;
                                requestAnimationFrame(function(){pending=false;compactThumbnails();});
                              }
                              compactThumbnails();
                              new MutationObserver(scheduleThumbnails).observe(document.body,{
                                childList:true,subtree:true,attributes:true,attributeFilter:['src','srcset']
                              });
                              function read(node){
                                return node ? (node.getAttribute('title') || node.textContent || '').replace(/\s+/g,' ').trim() : '';
                              }
                              function videoId(href){
                                try {
                                  var u=new URL(href,location.href);
                                  if(u.hostname==='youtu.be')return u.pathname.split('/')[1];
                                  if(u.hostname!=='youtube.com'&&!u.hostname.endsWith('.youtube.com'))return null;
                                  if(u.pathname==='/watch')return u.searchParams.get('v');
                                  if(/^\/(shorts|live)\//.test(u.pathname))return u.pathname.split('/')[2];
                                } catch(e) {}
                                return null;
                              }
                              document.addEventListener('click',function(ev){
                                var link=ev.target.closest('a[href]');
                                var card=ev.target.closest(cards);
                                if(link && !videoId(link.href))return;
                                var heading=card && card.querySelector(titles);
                                var titleLink=heading && (heading.closest('a[href]') || heading.querySelector('a[href]'));
                                var target=link || titleLink;
                                var id=target && videoId(target.href);
                                if(!id || !/^[A-Za-z0-9_-]{6,20}$/.test(id))return;
                                var title=read(heading);
                                var channel=card && read(card.querySelector(
                                  'ytd-channel-name a,ytm-channel-name a,a[href^="/@"],a[href^="/channel/"]'
                                ));
                                ev.preventDefault();
                                ev.stopImmediatePropagation();
                                BreakHost.select('https://www.youtube.com/watch?v='+id,title,channel || '');
                              },true);
                            })()"""
                            view.evaluateJavascript(js, null)
                        }
                    }
                    loadUrl(url)
                }
            },
            update = { it.settings.textZoom = (textSize * 4f).toInt() }
        )

    }
}

/** A successful ZIP import returns the first newly created playlist to display. */
private data class ZipPlaylistImportResult(val message: String, val openIndex: Int? = null)

/** Import ZIP contents off the UI thread; each root/folder collection becomes one playlist. */
private suspend fun importYtMonsterZip(context: Context, uri: Uri, store: BreakPlaylistStore, model: BreakMonsterModel,
    onLoading: (Int, Boolean) -> Unit): ZipPlaylistImportResult = try {
    val groups = withContext(Dispatchers.IO) {
        val collected = linkedMapOf<String, MutableList<Pair<String, String>>>()
        var skipped = 0
        java.util.zip.ZipInputStream(context.contentResolver.openInputStream(uri) ?: error("Cannot open ZIP")).use { zip ->
            var count = 0
            while (true) {
                val entry = zip.nextEntry ?: break
                count++
                check(count <= 1_000_000) { "ZIP exceeds the 1,000,000-entry safety limit" }
                if (!entry.isDirectory && (entry.name.endsWith(".yt", true) || entry.name.endsWith(".bmq", true))) {
                    val path = entry.name.replace('\\', '/')
                    val name = path.substringAfterLast('/').substringBeforeLast('.').trim()
                    val parent = path.substringBeforeLast('/', "").trim('/')
                    val collection = parent.replace("/", " • ").ifBlank { "YT IMPORT" }
                    val bytes = zip.readBytes()
                    if (bytes.size > 8192 || name.isBlank()) skipped++
                    else {
                        val content = bytes.toString(Charsets.UTF_8).removePrefix("\uFEFF").trim()
                        val decoded = runCatching { BmqCodec.decode(content) }.getOrNull()
                        if (decoded == null) skipped++
                        else collected.getOrPut(collection) { mutableListOf() }
                            .add(name to "https://www.youtube.com/watch?v=$decoded")
                    }
                }
                zip.closeEntry()
            }
        }
        Pair(collected, skipped)
    }
    val (collections, skippedAtRead) = groups
    if (collections.isEmpty()) ZipPlaylistImportResult("0 imported, $skippedAtRead skipped")
    else {
        val jobs = collections.mapNotNull { (name, links) ->
            store.createUnique(name)?.let { onLoading(it, true); it to links }
        }
        if (jobs.isEmpty()) return ZipPlaylistImportResult("ZIP import failed: could not create playlists.")
        var imported = 0
        var firstImportedIndex: Int? = null
        var rejected = skippedAtRead + (collections.size - jobs.size)
        suspendCoroutine<ZipPlaylistImportResult> { continuation ->
            fun runAt(index: Int) {
                if (index >= jobs.size) {
                    continuation.resume(ZipPlaylistImportResult("ZIP: $imported imported, $rejected skipped in ${jobs.size} playlists", firstImportedIndex))
                    return
                }
                val (destination, links) = jobs[index]
                model.importYoutubeLinksToPlaylist(destination, links,
                    { saved, failed ->
                        val entries=saved.map { (name,fileUri,videoId) -> BreakPlaylistEntry(name,fileUri,true,sourceKind="ZIP_IMPORT",videoId=videoId) }
                        if(store.addEntries(destination,entries)) entries.size to failed else 0 to (entries.size+failed)
                    }
                ) { added, failed ->
                    onLoading(destination, false)
                    if (added > 0 && firstImportedIndex == null) firstImportedIndex = destination
                    imported += added
                    rejected += failed
                    runAt(index + 1)
                }
            }
            runAt(0)
        }
    }
} catch (error: Throwable) {
    ZipPlaylistImportResult("ZIP import failed: ${error.message ?: error.javaClass.simpleName}")
}

private fun playlistUiName(store: BreakPlaylistStore, index: Int): String =
    if (index == store.queueIndex) AppLanguage.text("QUEUE") else store.displayName(index)

private fun uiToast(context: android.content.Context, text: CharSequence, duration: Int): android.widget.Toast =
    android.widget.Toast.makeText(context, AppLanguage.text(text.toString()), duration)
