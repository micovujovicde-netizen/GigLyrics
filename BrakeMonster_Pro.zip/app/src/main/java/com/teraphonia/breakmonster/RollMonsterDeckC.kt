package com.teraphonia.breakmonster

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Process
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs
import kotlin.math.floor

/** Independent PCM output deck used only by RollMonster. */
internal class RollMonsterDeckC {
    private data class Request(
        val pcm: RollMonsterAudioProcessor.PcmSnapshot,
        val preset: Int,
        val loop: Boolean
    )

    private val pending = AtomicReference<Request?>(null)
    private val releaseAtBoundary = AtomicBoolean(false)
    @Volatile private var running = false
    @Volatile private var track: AudioTrack? = null
    @Volatile var active: Boolean = false
        private set

    fun start(pcm: RollMonsterAudioProcessor.PcmSnapshot, preset: Int, loop: Boolean, initialVolume: Float = 1f, onFinished: () -> Unit): Boolean {
        if (pcm.channels !in 1..2 || pcm.sampleRate !in 8_000..192_000 || pcm.samples.isEmpty()) return false
        if (active) {
            pending.set(Request(pcm, preset, loop))
            releaseAtBoundary.set(false)
            return true
        }
        val channelMask = if (pcm.channels == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
        val minSize = AudioTrack.getMinBufferSize(pcm.sampleRate, channelMask, AudioFormat.ENCODING_PCM_FLOAT)
        if (minSize <= 0) return false
        val output = runCatching {
            AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder()
                    .setSampleRate(pcm.sampleRate)
                    .setChannelMask(channelMask)
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT).build())
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setBufferSizeInBytes(maxOf(minSize * 2, pcm.sampleRate * pcm.channels / 2))
                .build()
        }.getOrNull() ?: return false
        runCatching { output.setVolume(initialVolume.coerceIn(0f, 1f)) }
        track = output
        active = true
        running = true
        pending.set(null)
        releaseAtBoundary.set(false)
        Thread({ render(Request(pcm, preset, loop), onFinished) }, "BrakeMonster-Deck-C").apply {
            priority = Process.THREAD_PRIORITY_AUDIO
            isDaemon = true
            start()
        }
        return true
    }

    fun changeAtBoundary(pcm: RollMonsterAudioProcessor.PcmSnapshot, preset: Int, loop: Boolean): Boolean {
        if (!active) return false
        pending.set(Request(pcm, preset, loop))
        releaseAtBoundary.set(false)
        return true
    }

    fun setVolume(value: Float) { track?.let { runCatching { it.setVolume(value.coerceIn(0f, 1f)) } } }
    fun pause() { track?.let { runCatching { if (it.playState == AudioTrack.PLAYSTATE_PLAYING) it.pause() } } }
    fun resume() { track?.let { runCatching { if (it.playState == AudioTrack.PLAYSTATE_PAUSED) it.play() } } }

    fun releaseAtBoundary() {
        if (active) {
            pending.set(null)
            releaseAtBoundary.set(true)
        }
    }

    fun stopImmediately() {
        running = false
        pending.set(null)
        track?.let { runCatching { it.pause(); it.flush(); it.release() } }
        track = null
        active = false
    }

    private fun render(initial: Request, onFinished: () -> Unit) {
        var request = initial
        var phrase = makePhrase(request)
        var offset = 0
        var totalWrittenFrames = 0L
        val out = track ?: return
        try {
            out.play()
            while (running) {
                val phraseFrames = phrase.size / request.pcm.channels
                val leftFrames = phraseFrames - offset
                val countFrames = minOf(2_048, leftFrames)
                val result = out.write(phrase, offset * request.pcm.channels, countFrames * request.pcm.channels, AudioTrack.WRITE_BLOCKING)
                if (result < 0) break
                offset += result / request.pcm.channels
                totalWrittenFrames += result.toLong() / request.pcm.channels
                if (offset >= phraseFrames) {
                    phraseNumber++
                    offset = 0
                    val next = pending.getAndSet(null)
                    if (next != null) {
                        request = next
                        phrase = makePhrase(request)
                    } else if (releaseAtBoundary.getAndSet(false) || !request.loop) {
                        // Let the hardware drain this completed phrase before returning to A/B.
                        val target = totalWrittenFrames
                        while (running && out.playbackHeadPosition.toLong() < target) Thread.sleep(2)
                        break
                    }
                }
            }
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        } catch (_: Throwable) {
            // The service will resume the paused song deck on completion.
        } finally {
            running = false
            runCatching { out.pause(); out.flush(); out.release() }
            if (track === out) track = null
            active = false
            onFinished()
        }
    }

    private fun makePhrase(request: Request): FloatArray {
        val source = request.pcm.samples
        val channels = request.pcm.channels
        val frames = source.size / channels
        val out = FloatArray(source.size)
        val bpm = request.pcm.bpm.coerceIn(40, 220)
        val segment = maxOf(1, frames / 8)
        for (frame in 0 until frames) {
            val phase = frame.toDouble() / frames
            val sourceFrame = when (request.preset) {
                0 -> { // shuffle small eighth-note fragments
                    val part = frame / segment
                    val order = intArrayOf(0, 2, 1, 3, 4, 6, 5, 7)
                    order[part.coerceIn(0, 7)] * segment + frame % segment
                }
                1 -> if ((frame / segment) % 2 == 1) frames - 1 - frame else frame
                2 -> if ((frame / segment) % 2 == 0) frame else frame
                3, 4 -> frame
                5 -> (frame / maxOf(1, frames / 16)) * maxOf(1, frames / 16) % frames
                6 -> (frame / maxOf(1, frames / 4)) * maxOf(1, frames / 4) % frames
                7 -> frames - 1 - frame
                8 -> if ((frame / segment) % 2 == 0) frame else frames - 1 - frame
                9 -> (frame * (1.0 - 0.72 * phase)).toInt().coerceIn(0, frames - 1)
                10 -> if (((frame * bpm / request.pcm.sampleRate) % 13) == 0) frames - 1 - frame else frame
                11 -> ((frame / 3) * 3).coerceAtMost(frames - 1)
                else -> frame
            }.coerceIn(0, frames - 1)
            var gain = when (request.preset) {
                2 -> if ((frame / segment) % 2 == 0) 0.18f else 1f
                3 -> if ((frame / segment) % 2 == 0) 1f else 0.04f
                4 -> if ((frame / maxOf(1, frames / 8)) % 2 == 0) 1f else 0.03f
                10 -> if ((frame / maxOf(1, frames / 8)) % 3 == 0) 0.25f else 1f
                else -> 1f
            }
            for (channel in 0 until channels) out[frame * channels + channel] =
                (source[sourceFrame * channels + channel] * gain).coerceIn(-1f, 1f)
        }
        val seamFrames = minOf(maxOf(1, request.pcm.sampleRate / 200), frames / 8)
        for (k in 0 until seamFrames) {
            val t = (k + 1f) / (seamFrames + 1f)
            val headFrame = k
            val tailFrame = frames - seamFrames + k
            for (channel in 0 until channels) {
                val seam = out[headFrame * channels + channel] * t + out[tailFrame * channels + channel] * (1f - t)
                out[headFrame * channels + channel] = seam
                out[tailFrame * channels + channel] = seam
            }
        }
        return out
    }
}
