package com.teraphonia.breakmonster

import java.io.InterruptedIOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/**
 * Never erase user playlist entries merely because an extractor/stream failed.
 * A definitive YouTube video-unavailable response is different from an expired
 * signed CDN URL, HTTP 403/429, network failure or changing extractor protocol.
 */
internal object DeadYoutubeFailure {
    fun permanentlyUnavailable(failure: Throwable): Boolean {
        val causes = generateSequence(failure) { it.cause }.take(8).toList()
        if (causes.any { it is SocketTimeoutException || it is ConnectException ||
                    it is UnknownHostException || it is InterruptedIOException }) return false
        val description = causes.joinToString(" ") { "${it.javaClass.simpleName} ${it.message.orEmpty()}" }.lowercase()
        // Never delete on an access-control or extraction failure. These may clear
        // with a network/region/account change or a NewPipeExtractor update.
        val temporary = listOf("timeout", "timed out", "network", "connection", "dns", "ssl",
            "429", "403", "captcha", "recaptcha", "sign in", "login", "login required",
            "age restricted", "age-restricted", "age verification", "premium", "members only",
            "not available in your country", "not available in your region", "geo", "region blocked",
            "extract", "decipher", "signature", "nsig", "n-sig", "javascript", "no audio-only stream")
        if (temporary.any { it in description }) return false
        val explicit = listOf("video is unavailable", "video unavailable", "video is not available",
            "this video is private", "private video", "this video has been removed",
            "video has been removed", "this video has been deleted", "video has been deleted",
            "video does not exist", "video not found", "this video isn't available anymore")
        // Only a video-specific unavailable response from NewPipe can justify
        // permanent removal, not generic HTTP/Media3 failures.
        return causes.any { it.javaClass.simpleName == "ContentNotAvailableException" } &&
            explicit.any { it in description }
    }
}
