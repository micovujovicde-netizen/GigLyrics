package com.teraphonia.breakmonster

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/** A complete playlist snapshot; no playlist is changed until every asset validates. */
internal object PlaylistBackup {
    private const val FORMAT = "BrakeMonster-all-playlists"
    private fun digest(bytes: ByteArray) = MessageDigest.getInstance("SHA-256").digest(bytes)
        .joinToString("") { "%02x".format(it.toInt() and 255) }

    suspend fun write(context: Context, destination: Uri, snapshot: JSONObject) = withContext(Dispatchers.IO) {
        val assets = JSONArray()
        val seen = HashSet<String>()
        val playlists = snapshot.getJSONArray("playlists")
        context.contentResolver.openOutputStream(destination, "wt").use { output ->
            checkNotNull(output) { "Cannot open backup destination" }
            ZipOutputStream(output.buffered()).use { zip ->
                for (i in 0 until playlists.length()) {
                    val entries = playlists.getJSONObject(i).getJSONArray("entries")
                    for (n in 0 until entries.length()) {
                        val row = entries.getJSONObject(n)
                        val uri = row.getString("uri")
                        if (row.optBoolean("missing")) continue
                        if (!seen.add(uri)) continue
                        val youtube = row.optBoolean("yt")
                        val extension = if (youtube) "bmq" else Uri.parse(uri).lastPathSegment.orEmpty()
                            .substringAfterLast('.', "audio").lowercase().takeIf { it.matches(Regex("[a-z0-9]{1,8}")) } ?: "audio"
                        val path = "assets/${assets.length()}.$extension"
                        val asset = JSONObject().put("uri", uri).put("path", path)
                        if (youtube) {
                            val raw = runCatching { open(context, uri).use { it.readBytesLimited(8192).toString(Charsets.UTF_8) } }.getOrNull()
                            val id = raw?.let { runCatching { BmqCodec.decode(it) }.getOrNull() }
                                ?: row.optString("videoId").takeIf { it.matches(Regex("[A-Za-z0-9_-]{11}")) }
                                ?: error("Cannot back up BMQ: ${row.getString("name")}")
                            val bytes = ("https://www.youtube.com/watch?v=$id\n").toByteArray(Charsets.UTF_8)
                            zip.putNextEntry(ZipEntry(path)); zip.write(bytes); zip.closeEntry()
                            asset.put("videoId", id).put("sha256", digest(bytes))
                        } else {
                            val sha = MessageDigest.getInstance("SHA-256")
                            zip.putNextEntry(ZipEntry(path))
                            open(context, uri).use { input ->
                                val buffer = ByteArray(65536)
                                while (true) {
                                    val count = input.read(buffer)
                                    if (count < 0) break
                                    sha.update(buffer, 0, count); zip.write(buffer, 0, count)
                                }
                            }
                            zip.closeEntry()
                            asset.put("sha256", sha.digest().joinToString("") { "%02x".format(it.toInt() and 255) })
                        }
                        assets.put(asset)
                    }
                }
                snapshot.put("format", FORMAT).put("version", 1).put("assets", assets)
                zip.putNextEntry(ZipEntry("manifest.json"))
                zip.write(snapshot.toString().toByteArray(Charsets.UTF_8)); zip.closeEntry()
            }
        }
    }

    private fun open(context: Context, value: String): java.io.InputStream {
        val uri = Uri.parse(value)
        return if (uri.scheme == "file") File(requireNotNull(uri.path)).inputStream()
        else checkNotNull(context.contentResolver.openInputStream(uri)) { "Cannot read playlist file" }
    }

    data class Prepared(val snapshot: JSONObject, val directory: File)

    suspend fun read(context: Context, source: Uri): Prepared = withContext(Dispatchers.IO) {
        val temporary = File.createTempFile("playlist_backup_", ".zip", context.cacheDir)
        val directory = File(context.filesDir, "restored_playlists/${UUID.randomUUID()}")
        try {
            open(context, source.toString()).use { input -> temporary.outputStream().use { input.copyTo(it) } }
            ZipFile(temporary).use { zip ->
                val manifest = zip.getEntry("manifest.json") ?: error("This is not a BACKUP ALL ZIP")
                val bytes = zip.getInputStream(manifest).use { it.readBytesLimited(32 * 1024 * 1024) }
                val root = JSONObject(bytes.toString(Charsets.UTF_8))
                check(root.getString("format") == FORMAT && root.getInt("version") == 1) { "Unsupported backup" }
                val lists = root.getJSONArray("playlists")
                check(lists.length() in 6..10000) { "Invalid playlist count" }
                val assets = root.getJSONArray("assets")
                check(assets.length() <= 100000) { "Invalid asset count" }
                check(directory.mkdirs()) { "Cannot create restore folder" }
                val replacements = HashMap<String, String>()
                val assetPaths = HashSet<String>()
                var extractedBytes = 0L
                for (i in 0 until assets.length()) {
                    val asset = assets.getJSONObject(i)
                    val path = asset.getString("path")
                    check(path.matches(Regex("assets/[0-9]+\\.[a-z0-9]{1,8}"))) { "Invalid backup path" }
                    check(assetPaths.add(path)) { "Duplicate backup path" }
                    val entry = zip.getEntry(path) ?: error("Backup file missing: $path")
                    val target = File(directory, path.substringAfter('/'))
                    val sha = MessageDigest.getInstance("SHA-256")
                    zip.getInputStream(entry).use { input ->
                        target.outputStream().use { out ->
                            val buffer = ByteArray(65536)
                            var total = 0L
                            while (true) {
                                val count = input.read(buffer)
                                if (count < 0) break
                                total += count
                                extractedBytes += count
                                check(extractedBytes <= 32L * 1024 * 1024 * 1024) { "Backup too large" }
                                check(total <= 16L * 1024 * 1024 * 1024) { "Backup file too large" }
                                sha.update(buffer, 0, count); out.write(buffer, 0, count)
                            }
                        }
                    }
                    check(sha.digest().joinToString("") { "%02x".format(it.toInt() and 255) } == asset.getString("sha256")) { "Damaged backup file: $path" }
                    if (asset.has("videoId")) {
                        val id = asset.getString("videoId")
                        check(id.matches(Regex("[A-Za-z0-9_-]{11}"))) { "Invalid video ID" }
                        target.writeText(BmqCodec.encode(id))
                    }
                    check(replacements.put(asset.getString("uri"), Uri.fromFile(target).toString()) == null) { "Duplicate backup asset" }
                }
                for (i in 0 until lists.length()) {
                    val list = lists.getJSONObject(i)
                    check(list.getString("id").isNotBlank()) { "Playlist identity missing" }
                    val rows = list.getJSONArray("entries")
                    for (n in 0 until rows.length()) {
                        val row = rows.getJSONObject(n)
                        row.getString("name")
                        val oldUri = row.getString("uri")
                        val newUri = replacements[oldUri]
                        check(newUri != null || row.optBoolean("missing")) { "Incomplete backup" }
                        if (newUri != null) row.put("uri", newUri)
                    }
                }
                Prepared(root, directory)
            }
        } catch (error: Throwable) {
            directory.deleteRecursively()
            throw error
        } finally { temporary.delete() }
    }

    private fun java.io.InputStream.readBytesLimited(limit: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val bytes = ByteArray(8192)
        while (true) {
            val n = read(bytes)
            if (n < 0) break
            check(out.size() + n <= limit) { "Backup manifest too large" }
            out.write(bytes, 0, n)
        }
        return out.toByteArray()
    }
}
