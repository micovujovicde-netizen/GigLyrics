package com.teraphonia.breakmonster

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Small, short-lived Cloudflare transfer; each track becomes a device-keyed .bmq on import. */
internal object CloudPlaylistTransfer {
    internal data class Playlist(val title: String, val tracks: List<Pair<String, String>>)
    private const val TRANSFER_LIMIT_BYTES = 1_700_000
    private const val MAX_TRACKS = 10_000 // transport safety only
    private val videoId = Regex("^[A-Za-z0-9_-]{11}$")
    private val transferToken = Regex("^[A-Za-z0-9_-]{32}$")

    fun verifiedTransferUri(deepLink: Uri): Uri {
        require(deepLink.scheme == "brakemonster" && deepLink.host == "save-playlist") { "Invalid playlist action" }
        val original = deepLink.getQueryParameter("url") ?: error("Transfer address missing")
        val endpoint = Uri.parse(original)
        // Exact, fixed Cloudflare origin: no editable endpoint and no redirect-based SSRF.
        val trusted = Uri.parse("https://playlist-cloud.micovujovic-de.workers.dev")
        require(endpoint.scheme == "https" && endpoint.host.equals(trusted.host, ignoreCase = true) &&
            (endpoint.port == -1 || endpoint.port == 443) && endpoint.userInfo == null &&
            endpoint.query == null && endpoint.fragment == null && endpoint.pathSegments.size == 3 &&
            endpoint.pathSegments[0] == "api" && endpoint.pathSegments[1] == "transfers" &&
            transferToken.matches(endpoint.pathSegments[2])) { "Unknown playlist transfer source" }
        return endpoint
    }

    fun transferKey(endpoint: Uri): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(endpoint.toString().toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it.toInt() and 255) }
    }

    fun previouslySaved(context: Context, key: String): Boolean = context
        .getSharedPreferences("breakmonster_cloud", Context.MODE_PRIVATE)
        .getStringSet("saved_transfers_v1", emptySet()).orEmpty().contains(key)

    fun markSaved(context: Context, key: String) {
        val prefs = context.getSharedPreferences("breakmonster_cloud", Context.MODE_PRIVATE)
        val previous = prefs.getStringSet("saved_transfers_v1", emptySet()).orEmpty()
        val updated = (previous.toList().takeLast(39) + key).toSet()
        check(prefs.edit().putStringSet("saved_transfers_v1", updated).commit()) { "Import receipt not saved" }
    }

    suspend fun fetch(endpoint: Uri): Playlist = withContext(Dispatchers.IO) {
        val connection = (URL(endpoint.toString()).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000
            readTimeout = 25000
            instanceFollowRedirects = false
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Cache-Control", "no-store")
        }
        try {
            check(connection.responseCode == HttpURLConnection.HTTP_OK) {
                if (connection.responseCode == 404) "Playlist transfer expired. Press SAVE PLAYLIST on the website again."
                else "Transfer unavailable (HTTP ${connection.responseCode})"
            }
            val buffer = ByteArrayOutputStream()
            connection.inputStream.use { stream ->
                val chunk = ByteArray(8192)
                while (true) {
                    val n = stream.read(chunk)
                    if (n < 0) break
                    check(buffer.size() + n <= TRANSFER_LIMIT_BYTES) { "Playlist too large to import" }
                    buffer.write(chunk, 0, n)
                }
            }
            val root = JSONObject(buffer.toString("UTF-8"))
            check(root.optInt("version") == 1) { "Unsupported transfer format" }
            val title = root.optString("title").trim().take(200)
            check(title.isNotEmpty()) { "Playlist title missing" }
            val items = root.getJSONArray("tracks")
            check(items.length() in 1..MAX_TRACKS) { "Invalid number of songs" }
            val found = HashSet<String>()
            val tracks = ArrayList<Pair<String, String>>(items.length())
            for (i in 0 until items.length()) {
                val track = items.getJSONObject(i)
                val id = track.optString("id")
                val name = track.optString("title").trim().take(200)
                check(videoId.matches(id) && name.isNotBlank()) { "Invalid item in playlist" }
                if (found.add(id)) tracks.add(name to "https://www.youtube.com/watch?v=$id")
            }
            check(tracks.isNotEmpty()) { "Playlist has no valid songs" }
            Playlist(title, tracks)
        } finally { connection.disconnect() }
    }
}
