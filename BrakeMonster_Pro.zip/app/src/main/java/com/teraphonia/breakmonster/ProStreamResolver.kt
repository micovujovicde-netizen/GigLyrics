package com.teraphonia.breakmonster

import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.stream.StreamInfo
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.GZIPInputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CompletableFuture
import android.os.SystemClock

/** Resolve a link to a short-lived audio-only CDN URL on a worker thread. */
internal object ProStreamResolver {
    private const val USER_AGENT = "Mozilla/5.0 (Android 12; Mobile; rv:140.0) Gecko/140.0 Firefox/140.0"
    @Volatile private var initialized = false
    private data class CachedStream(val url: String, val expiresAt: Long)
    private val streamCache = ConcurrentHashMap<String, CachedStream>()
    // A promoted track can request its successor while speculative warmup
    // is still resolving it. Share the extraction instead of making two
    // simultaneous NewPipe/network requests for the same YouTube ID.
    private val inFlight = ConcurrentHashMap<String, CompletableFuture<String>>()
    private val network = object : Downloader() {
        override fun execute(request: Request): Response {
            val connection = (URL(request.url()).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15000
                readTimeout = 25000
                instanceFollowRedirects = true
                requestMethod = request.httpMethod()
                setRequestProperty("User-Agent", USER_AGENT)
                setRequestProperty("Accept-Encoding", "gzip")
                request.headers()?.forEach { (name, values) ->
                    if (name.isNotBlank() && values.isNotEmpty()) setRequestProperty(name, values.joinToString(", "))
                }
                request.dataToSend()?.let { bytes ->
                    doOutput = true
                    outputStream.use { it.write(bytes) }
                }
            }
            try {
                val code = connection.responseCode
                val stream = if (code in 200..399) connection.inputStream else connection.errorStream
                val body = if (stream == null || request.httpMethod().equals("HEAD", true)) "" else {
                    val uncompressed = if (connection.contentEncoding?.contains("gzip", ignoreCase = true) == true)
                        GZIPInputStream(stream) else stream
                    uncompressed.bufferedReader(Charsets.UTF_8).use { it.readText() }
                }
                return Response(code, connection.responseMessage ?: "", connection.headerFields.filterKeys { it != null }.mapKeys { it.key!! }, body, connection.url.toString())
            } finally { connection.disconnect() }
        }
    }
    private fun prepare() {
        if (initialized) return
        synchronized(this) {
            if (!initialized) {
                NewPipe.init(network)
                initialized = true
            }
        }
    }
    fun resolveAudio(videoId: String): String {
        val canonicalId = BmqCodec.extractId(videoId) ?: error("Invalid track reference")
        val now = SystemClock.elapsedRealtime()
        streamCache[canonicalId]?.takeIf { it.expiresAt > now }?.let {
            BlackBox.log("BMQ RESOLVER CACHE HIT id=$canonicalId")
            return it.url
        }
        val work = CompletableFuture<String>()
        val ongoing = inFlight.putIfAbsent(canonicalId, work)
        if (ongoing != null) {
            BlackBox.log("BMQ RESOLVER JOIN existing extraction id=$canonicalId")
            return ongoing.get()
        }
        try {
            // Another call may have filled the cache between our initial check
            // and obtaining the exclusive extraction slot.
            streamCache[canonicalId]?.takeIf { it.expiresAt > SystemClock.elapsedRealtime() }?.let {
                work.complete(it.url)
                return it.url
            }
            prepare()
            val info = StreamInfo.getInfo(ServiceList.YouTube, "https://www.youtube.com/watch?v=$canonicalId")
            // Preserve the previous audio choice/quality and MediaPlayer codec.
            val streams = info.audioStreams.filter { it.isUrl && it.content.startsWith("https://") }
            val chosen = streams.maxByOrNull { stream ->
                (if (stream.format?.name == "M4A") 1_000_000 else 0) + stream.averageBitrate.coerceAtLeast(0)
            } ?: error("No audio-only stream available for this track")
            val url = chosen.content
            // Use completion time for cache freshness; resolving can be slow.
            streamCache[canonicalId] = CachedStream(url, SystemClock.elapsedRealtime() + 4 * 60 * 1000L)
            work.complete(url)
            return url
        } catch (error: Throwable) {
            work.completeExceptionally(error)
            throw error
        } finally {
            inFlight.remove(canonicalId, work)
        }
    }

}
