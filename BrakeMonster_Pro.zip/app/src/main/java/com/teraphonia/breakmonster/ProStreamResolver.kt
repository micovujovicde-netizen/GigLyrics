package com.teraphonia.breakmonster

import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.stream.StreamInfo
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.GZIPInputStream
import java.util.concurrent.ConcurrentHashMap
import android.os.SystemClock

/** Resolve a link to a short-lived audio-only CDN URL on a worker thread. */
internal object ProStreamResolver {
    private const val USER_AGENT = "Mozilla/5.0 (Android 12; Mobile; rv:140.0) Gecko/140.0 Firefox/140.0"
    @Volatile private var initialized = false
    private data class CachedStream(val url: String, val expiresAt: Long)
    private val streamCache = ConcurrentHashMap<String, CachedStream>()
    private val network = object : Downloader() {
        override fun execute(request: Request): Response {
            val connection = (URL(request.url()).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15000
                readTimeout = 25000
                instanceFollowRedirects = true
                requestMethod = request.httpMethod()
                setRequestProperty("User-Agent", USER_AGENT)
                setRequestProperty("Accept-Encoding", "gzip")
                request.headers()?.forEach { (name, values) ->
                    if (name.isNotBlank() && values.isNotEmpty()) setRequestProperty(name, values.joinToString(", "))
                }
                request.dataToSend()?.let { bytes ->
                    doOutput = true
                    outputStream.use { it.write(bytes) }
                }
            }
            try {
                val code = connection.responseCode
                val stream = if (code in 200..399) connection.inputStream else connection.errorStream
                val body = if (stream == null || request.httpMethod().equals("HEAD", true)) "" else {
                    val uncompressed = if (connection.contentEncoding?.contains("gzip", ignoreCase = true) == true)
                        GZIPInputStream(stream) else stream
                    uncompressed.bufferedReader(Charsets.UTF_8).use { it.readText() }
                }
                return Response(code, connection.responseMessage ?: "", connection.headerFields.filterKeys { it != null }.mapKeys { it.key!! }, body, connection.url.toString())
            } finally { connection.disconnect() }
        }
    }
    private fun prepare() {
        if (initialized) return
        synchronized(this) {
            if (!initialized) {
                NewPipe.init(network)
                initialized = true
            }
        }
    }
    fun resolveAudio(videoId: String): String {
        val canonicalId = BmqCodec.extractId(videoId) ?: error("Invalid track reference")
        val now = SystemClock.elapsedRealtime()
        streamCache[canonicalId]?.takeIf { it.expiresAt > now }?.let {
            BlackBox.log("BMQ RESOLVER CACHE HIT id=$canonicalId")
            return it.url
        }
        prepare()
        val info = StreamInfo.getInfo(ServiceList.YouTube, "https://www.youtube.com/watch?v=$canonicalId")
        val streams = info.audioStreams.filter { it.isUrl && it.content.startsWith("https://") }
        val chosen = streams.maxByOrNull { stream ->
            (if(stream.format?.name == "M4A") 1_000_000 else 0) + stream.averageBitrate.coerceAtLeast(0)
        }
            ?: error("No audio-only stream available for this track")
        return chosen.content.also { streamCache[canonicalId] = CachedStream(it, now + 4 * 60 * 1000L) }
    }
}
