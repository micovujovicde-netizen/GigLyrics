package com.teraphonia.breakmonster;

/** One bounded retry for a missing installer result, never for a final result. */
final class UpdateRetryGate {
    static boolean mayRetry(int retriesUsed, boolean finalResult, boolean installed,
                            boolean foregroundIdle, boolean sessionActive,
                            long foregroundWaitMs) {
        return retriesUsed == 0 && !finalResult && !installed && foregroundIdle
                && !sessionActive && foregroundWaitMs >= 3000L;
    }
}
