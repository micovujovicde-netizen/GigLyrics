package com.teraphonia.breakmonster;

/** One bounded retry for a missing installer result, never for a final result. */
final class UpdateRetryGate {
    // PackageInstaller STATUS_FAILURE=1 is generic; cancel/block/invalid/etc.
    // are explicit terminal outcomes and must not be silently retried.
    static boolean retryableStatus(int status, int retriesUsed) {
        return status == 1 && retriesUsed == 0;
    }
    static boolean mayRetry(int retriesUsed, boolean finalResult, boolean installed,
                            boolean foregroundIdle, boolean sessionActive,
                            long foregroundWaitMs) {
        return retriesUsed == 0 && !finalResult && !installed && foregroundIdle
                && !sessionActive && foregroundWaitMs >= 3000L;
    }
}
