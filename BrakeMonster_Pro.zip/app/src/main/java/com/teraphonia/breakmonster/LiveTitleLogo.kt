@file:Suppress("DEPRECATION")

package com.teraphonia.breakmonster

import android.content.Context
import android.graphics.Canvas
import android.graphics.Movie
import android.os.SystemClock
import android.view.View
import androidx.compose.foundation.Image
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Original animated title served by teraphonia.com, including its original timing. */
@Composable
internal fun LiveTitleLogo(modifier: Modifier = Modifier, bottomAligned: Boolean = false) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var resumed by remember { mutableStateOf(owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) }
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, _ ->
            resumed = owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
    val movie by produceState<Movie?>(null, context.applicationContext) {
        value = withContext(Dispatchers.IO) { LiveTitleMovie.load(context.applicationContext) }
    }
    val animation = movie
    if (animation == null) {
        Image(painterResource(R.drawable.breakmonster_title_poster),
            contentDescription = AppLanguage.text("BreakMonster"),
            contentScale = ContentScale.Fit, modifier = modifier)
    } else {
        AndroidView(
            factory = { LiveTitleView(it, animation, bottomAligned) },
            update = {
                it.contentDescription = AppLanguage.text("BreakMonster")
                it.animate(resumed)
            },
            onRelease = { it.animate(false) },
            modifier = modifier
        )
    }
}

private object LiveTitleMovie {
    @Volatile private var cached: Movie? = null
    fun load(context: Context): Movie? = cached ?: synchronized(this) {
        cached ?: runCatching {
            context.resources.openRawResource(R.drawable.breakmonster_live_title).use { Movie.decodeStream(it) }
        }.onFailure { BlackBox.log("LIVE TITLE GIF decode failed ${it.javaClass.simpleName}") }
            .getOrNull()?.also { cached = it }
    }
}

/** Native ABOUT dialog uses the same animated title as the Compose header. */
internal fun liveTitleNativeView(context: Context): View {
    val animation = LiveTitleMovie.load(context)
    return if (animation != null) LiveTitleView(context, animation, false).apply {
        contentDescription = AppLanguage.text("BreakMonster")
        animate(true)
    } else android.widget.ImageView(context).apply {
        setImageResource(R.drawable.breakmonster_title_poster)
        scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
    }
}

private class LiveTitleView(context: Context, private val movie: Movie, private val bottomAligned: Boolean) : View(context) {
    // Union of nontransparent pixels over all 24 original GIF frames. Remove only
    // empty canvas space while rendering; no source image/frame is rewritten.
    private val artLeft = 288f
    private val artTop = 73f
    private val artWidth = 1023f
    private val artHeight = 255f
    private var running = false
    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }
    fun animate(value: Boolean) { running = value; if (value) invalidate() }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); invalidate() }
    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) invalidate()
    }
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = resolveSize(suggestedMinimumWidth, widthMeasureSpec)
        val desiredHeight = (w * artHeight / artWidth).toInt()
        setMeasuredDimension(w, resolveSize(desiredHeight, heightMeasureSpec))
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val scale = minOf(width / artWidth, height / artHeight)
        val top = if (bottomAligned) height - artHeight * scale else (height - artHeight * scale) / 2f
        canvas.save()
        canvas.translate((width - artWidth * scale) / 2f, top)
        canvas.scale(scale, scale)
        canvas.clipRect(0f, 0f, artWidth, artHeight)
        movie.setTime((SystemClock.uptimeMillis() % movie.duration().coerceAtLeast(1)).toInt())
        movie.draw(canvas, -artLeft, -artTop)
        canvas.restore()
        if (running && isAttachedToWindow && windowVisibility == VISIBLE && isShown) postInvalidateDelayed(40L)
    }
}
