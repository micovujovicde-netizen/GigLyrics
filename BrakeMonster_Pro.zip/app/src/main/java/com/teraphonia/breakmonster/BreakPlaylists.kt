package com.teraphonia.breakmonster

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.*
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

internal data class BreakPlaylistEntry(
    val name:String,
    val uri:String,
    val youtube:Boolean,
    val missing:Boolean=false,
    /** Origin is persisted so QUEUE swipe behavior never depends on display text or filenames. */
    val sourceKind:String="EXISTING_SELECTION",
    val sourcePlaylistIndex:Int=-1,
    val videoId:String?=null,
    val sourceContext:String=""
)

/** Eight built-in playlists plus user-created lists, persisted without touching media files. */
internal class BreakPlaylistStore(private val context: Context) {
    private val prefs=context.getSharedPreferences("breakmonster_playlists",0)
    var onPlaylistEntryAdded: ((Int) -> Unit)? = null
    var onPlaylistChanged: ((Int) -> Unit)? = null
    private val welcomeTitle = "WELCOME TO BRAKE MONSTER AND TERAPHONIA WORLD"
    val lists=mutableStateListOf<MutableList<BreakPlaylistEntry>>()
    val names=mutableStateListOf<MutableState<String>>()
    private val ids=mutableStateListOf<String>()
    private val identityCache=mutableMapOf<String,String>()
    var activeIndex by mutableIntStateOf(prefs.getInt("active",0).coerceAtLeast(0)); private set

    /** QUEUE lives in the same persisted playlist table at reserved index 8. */
    val queueIndex:Int get() = 8

    init {
        var n=prefs.getInt("count",8).coerceAtLeast(8)
        if (!prefs.getBoolean("queue_layout_v1", false)) {
            // Preserve legacy user playlists by inserting the reserved QUEUE row before them.
            val edit = prefs.edit()
            if (n > queueIndex) {
                for (i in n - 1 downTo queueIndex) {
                    edit.putString("p${i+1}", prefs.getString("p$i", "[]"))
                        .putString("name_${i+1}", prefs.getString("name_$i", ""))
                        .putString("id_${i+1}", prefs.getString("id_$i", ""))
                    val split = prefs.getInt("split_number_$i", 0)
                    if (split > 0) edit.putInt("split_number_${i+1}", split)
                    else edit.remove("split_number_${i+1}")
                    edit.remove("p$i").remove("name_$i").remove("id_$i").remove("split_number_$i")
                }
                n++
            }
            val previousActive=prefs.getInt("active",0)
            val migratedActive=if(previousActive>=queueIndex) previousActive+1 else previousActive
            val finalCount=n.coerceAtLeast(queueIndex + 1)
            check(edit.putBoolean("queue_layout_v1", true).putInt("count", finalCount)
                .putInt("active",migratedActive.coerceAtMost(finalCount-1)).commit()) { "Could not initialize playlist storage" }
            n = n.coerceAtLeast(queueIndex + 1)
        }
        repeat(n){ i ->
            val stableId=prefs.getString("id_$i",null)?.takeIf { it.isNotBlank() } ?: UUID.randomUUID().toString().also { id ->
                check(prefs.edit().putString("id_$i",id).commit()) { "Could not persist playlist identity" }
            }
            ids.add(stableId)
            lists.add(mutableStateListOf())
            names.add(mutableStateOf(prefs.getString("name_$i","").orEmpty()))
            load(i)
        }
        // MY SAVES was the legacy name for the first ordinary playlist. Keep its
        // entries and stored URIs intact while restoring the P1 label.
        if (names.isNotEmpty() && (names[0].value.isBlank() || names[0].value.equals("MY SAVES", true))) {
            names[0].value = "P1"
            check(prefs.edit().putString("name_0", "P1").commit()) { "Could not migrate MY SAVES to P1" }
        }
        seedWelcomePlaylistOnce()
        activeIndex=prefs.getInt("active",activeIndex).coerceIn(0,lists.lastIndex)
    }
    /** Install the optional, deletable welcome playlist only once. Never resurrect after user deletion. */
    private fun seedWelcomePlaylistOnce() {
        if (prefs.getBoolean("teraphonia_welcome_seeded_v1", false)) return
        val rows = runCatching { context.assets.open("teraphonia_welcome/songs.tsv")
            .bufferedReader(Charsets.UTF_8).use { it.readLines() } }.getOrDefault(emptyList())
        if (rows.isEmpty()) return
        val directory = java.io.File(context.filesDir, "user_playlists/teraphonia_welcome").apply { mkdirs() }
        val entries = rows.mapNotNull { row ->
            val parts = row.split('\t', limit = 2)
            if (parts.size != 2) return@mapNotNull null
            val title = parts[0]
            val url = parts[1]
            val id = BmqCodec.extractId(url) ?: return@mapNotNull null
            runCatching {
                val filename = if (title.startsWith("WELCOME SONG")) "WELCOME SONG.bmq" else
                    (title.replace(Regex("[^a-zA-Z0-9 _-]"), "_").take(95) + ".bmq")
                val output = java.io.File(directory, filename)
                if (!output.exists()) output.writeText(BmqCodec.encode(url), Charsets.UTF_8)
                BreakPlaylistEntry(title, Uri.fromFile(output).toString(), true,
                    sourceKind="BUNDLED_WELCOME", videoId=id)
            }.getOrNull()
        }
        if (entries.isEmpty()) return
        val existing = lists.indices.firstOrNull { displayName(it) == welcomeTitle }
        val index = existing ?: create(welcomeTitle)
        if (existing == null) {
            lists[index].clear()
            lists[index].addAll(entries)
            save(index)
        }
        prefs.edit().putBoolean("teraphonia_welcome_seeded_v1", true).commit()
    }
    fun welcomePlaylistIndex():Int = lists.indices.firstOrNull { names[it].value == welcomeTitle } ?: -1
    val size:Int get()=lists.size
    fun playbackContext(i:Int):String = "user:${ids.getOrNull(i) ?: "missing:$i"}"
    fun displayName(i:Int)=if(i==queueIndex) "QUEUE" else names.getOrNull(i)?.value?.ifBlank { if(i<8) "P${i+1}" else "PLAYLIST ${i+1}" } ?: "P1"
    fun importedSplitNumber(i:Int):Int? = prefs.getInt("split_number_$i",0).takeIf { it > 0 }
    fun setImportedSplitNumber(i:Int, number:Int) {
        if (i in 8 until lists.size && number > 0) prefs.edit().putInt("split_number_$i",number).apply()
    }
    fun activate(i:Int){ if(i in lists.indices){ activeIndex=i; prefs.edit().putInt("active",i).apply() } }
    fun rename(i:Int,v:String){ if(i in lists.indices && i!=queueIndex){ names[i].value=v.trim().take(24); prefs.edit().putString("name_$i",names[i].value).apply() } }
    @Synchronized fun create(name:String="") : Int {
        val i=lists.size
        val clean=if(name==welcomeTitle) name else name.trim().take(24)
        val id=UUID.randomUUID().toString()
        check(prefs.edit().putInt("count",i+1).putString("name_$i",clean).putString("id_$i",id).putString("p$i","[]").putInt("active",i).commit()) { "Could not persist playlist" }
        lists.add(mutableStateListOf())
        names.add(mutableStateOf(clean))
        ids.add(id)
        activeIndex=i
        return i
    }
    @Synchronized fun createUnique(name:String):Int? {
        val base=name.trim().take(24).ifBlank { "YT IMPORT" }
        var candidate=base
        var suffix=2
        while(lists.indices.any { displayName(it).equals(candidate,true) }) {
            val marker=" ($suffix)"
            candidate=base.take((24-marker.length).coerceAtLeast(1))+marker
            suffix++
        }
        return runCatching { create(candidate) }.getOrNull()
    }
    fun createImported(name:String, entries:List<BreakPlaylistEntry>):Int {
        val i=create(name)
        lists[i].clear(); lists[i].addAll(entries); save(i)
        return i
    }
    fun delete(i:Int){
        if(i !in lists.indices || i==queueIndex) return
        val splitNumbers=(i until lists.size).associateWith { prefs.getInt("split_number_$it",0) }
        lists.removeAt(i); names.removeAt(i)
        ids.removeAt(i)
        if(i < queueIndex) {
            // Keep reserved QUEUE at index 8 when an ordinary P1–P8 slot is
            // deleted; any user-created playlists remain after it.
            lists.add(queueIndex - 1, mutableStateListOf())
            names.add(queueIndex - 1, mutableStateOf(""))
            ids.add(queueIndex - 1,UUID.randomUUID().toString())
        }
        while(lists.size<queueIndex+1){ lists.add(queueIndex, mutableStateListOf());names.add(queueIndex, mutableStateOf(""));ids.add(queueIndex,UUID.randomUUID().toString()) }
        val e=prefs.edit().putInt("count",lists.size)
        e.remove("p$i").remove("name_$i").remove("id_$i").remove("split_number_$i")
        for(n in i until lists.size){
            e.putString("p$n",encode(n)).putString("name_$n",names[n].value).putString("id_$n",ids[n])
            val previous=splitNumbers[n+1] ?: 0
            if(previous>0) e.putInt("split_number_$n",previous) else e.remove("split_number_$n")
        }
        activeIndex=activeIndex.coerceAtMost(lists.lastIndex)
        e.putInt("active",activeIndex).apply()
    }
    fun add(item:BreakItem):Boolean = addUri(activeIndex,item.name,item.file.uri.toString(),item.isYoutube)
    fun ensureBundledP1(items:List<BreakItem>){
        items.forEach { item ->
            val uri=item.file.uri.toString()
            val name=if(item.file.name.equals("BRAKE MONSTER WELCOME SONG.mp3",true)) "BRAKE MONSTER WELCOME SONG" else item.name
            val oldIndex=lists[0].indexOfFirst { it.uri==uri || it.name.equals(name,true) }
            if(oldIndex>=0) lists[0][oldIndex]=BreakPlaylistEntry(name,uri,item.isYoutube)
            else lists[0].add(BreakPlaylistEntry(name,uri,item.isYoutube))
        }
        save(0)
    }
    @Synchronized fun addUri(i:Int,name:String,uri:String,youtube:Boolean,sourceKind:String="EXISTING_SELECTION",sourcePlaylistIndex:Int=-1,sourceContext:String=""):Boolean {
        if(i !in lists.indices) return false
        val l=lists[i]
        if(i==queueIndex && l.any{sourceIdentity(it.uri,it.youtube)==sourceIdentity(uri,youtube)}) return false
        if(l.any{it.uri==uri}) return false
        val entry=BreakPlaylistEntry(name,uri,youtube,sourceKind=sourceKind,sourcePlaylistIndex=sourcePlaylistIndex,videoId=if(youtube) readYoutubeId(uri) else null,sourceContext=sourceContext)
        val updated=l.toList()+entry
        if(!runCatching { prefs.edit().putString("p$i",encodeEntries(updated)).commit() }.getOrDefault(false)) return false
        l.add(entry)
        onPlaylistEntryAdded?.invoke(i)
        onPlaylistChanged?.invoke(i)
        return true
    }
    suspend fun addEntries(i:Int,entries:List<BreakPlaylistEntry>):Boolean {
        if(i !in lists.indices) return false
        if(entries.isEmpty()) return true
        val existing=lists[i].mapTo(HashSet()) { it.uri }
        val additions=entries.filter { existing.add(it.uri) }
        if(additions.isEmpty()) return true
        val updated=lists[i].toList()+additions
        val persisted=withContext(Dispatchers.IO) { runCatching { prefs.edit().putString("p$i",encodeEntries(updated)).commit() }.getOrDefault(false) }
        if(!persisted) return false
        lists[i].addAll(additions)
        onPlaylistEntryAdded?.invoke(i)
        onPlaylistChanged?.invoke(i)
        return true
    }
    fun isInQueue(uri:String):Boolean {
        val key=sourceIdentity(uri, true)
        return lists.getOrNull(queueIndex).orEmpty().any { sourceIdentity(it.uri,it.youtube)==key }
    }
    fun toggleQueueEntry(entry:BreakPlaylistEntry):Boolean {
        val queue=lists.getOrNull(queueIndex) ?: return false
        val key=sourceIdentity(entry.uri, entry.youtube)
        val existing=queue.indexOfFirst { sourceIdentity(it.uri,it.youtube)==key }
        val updated=queue.toMutableList()
        if(existing>=0) {
            updated.removeAt(existing)
            if(!runCatching { prefs.edit().putString("p$queueIndex",encodeEntries(updated)).commit() }.getOrDefault(false)) return false
            queue.clear();queue.addAll(updated)
            onPlaylistChanged?.invoke(queueIndex)
            return false
        }
        updated.add(entry.copy(
            missing=false,
            sourcePlaylistIndex=entry.sourcePlaylistIndex,
            videoId=entry.videoId ?: if(entry.youtube) readYoutubeId(entry.uri) else null
        ))
        if(!runCatching { prefs.edit().putString("p$queueIndex",encodeEntries(updated)).commit() }.getOrDefault(false)) return false
        queue.add(updated.last())
        onPlaylistChanged?.invoke(queueIndex)
        return true
    }
    /** Persist destination first and QUEUE removal in one commit; playback is not touched. */
    @Synchronized fun moveSearchSaveFromQueue(entry:BreakPlaylistEntry,destination:Int):Boolean {
        if(destination !in lists.indices || destination==queueIndex) return false
        val queue=lists.getOrNull(queueIndex) ?: return false
        val sourceIndex=queue.indexOfFirst { it.uri==entry.uri && it.sourceKind=="SEARCH_SAVE" }
        if(sourceIndex<0) return false
        val target=lists[destination]
        if(target.any { it.uri==entry.uri }) return false
        val copied=target.toList()+queue[sourceIndex]
        val remaining=queue.toMutableList().also { it.removeAt(sourceIndex) }
        val ok=runCatching { prefs.edit().putString("p$destination",encodeEntries(copied)).putString("p$queueIndex",encodeEntries(remaining)).commit() }.getOrDefault(false)
        if(!ok) return false
        target.add(queue[sourceIndex]); queue.removeAt(sourceIndex)
        onPlaylistChanged?.invoke(destination); onPlaylistChanged?.invoke(queueIndex)
        return true
    }
    @Synchronized fun clearQueue():Boolean {
        val queue=lists.getOrNull(queueIndex) ?: return false
        if(!runCatching { prefs.edit().putString("p$queueIndex","[]").commit() }.getOrDefault(false)) return false
        queue.clear(); onPlaylistChanged?.invoke(queueIndex); return true
    }
    private fun sourceIdentity(uri:String, youtube:Boolean):String {
        val cacheKey="$youtube:$uri"
        identityCache[cacheKey]?.let { return it }
        if (youtube) {
            val id=readYoutubeId(uri)
            if (!id.isNullOrBlank()) return "yt:$id".also { identityCache[cacheKey]=it }
        }
        return "uri:$uri".also { identityCache[cacheKey]=it }
    }
    /** Atomically persist a new playlist and an empty QUEUE; memory changes only after commit. */
    @Synchronized fun exportQueue(name:String):Int? {
        val clean=if(name==welcomeTitle) name else name.trim().take(24)
        if(clean.isBlank() || lists.indices.any { displayName(it).equals(clean,true) }) return null
        val queue=lists.getOrNull(queueIndex) ?: return null
        if(queue.isEmpty()) return null
        val destination=lists.size
        val copied=queue.toList()
        val serialized=encodeEntries(copied)
        val id=UUID.randomUUID().toString()
        val edit=prefs.edit().putString("p$destination",serialized).putString("name_$destination",clean).putString("id_$destination",id)
            .putInt("count",destination+1).putString("p$queueIndex","[]")
        if(!runCatching { edit.commit() }.getOrDefault(false)) return null
        lists.add(mutableStateListOf<BreakPlaylistEntry>().apply { addAll(copied) })
        names.add(mutableStateOf(clean))
        ids.add(id)
        queue.clear()
        onPlaylistChanged?.invoke(queueIndex)
        activeIndex=destination
        prefs.edit().putInt("active",destination).apply()
        return destination
    }
    /** Add an imported YouTube link while replacing stale copies of that same title/video. */
    fun addImportedYoutube(i:Int,name:String,uri:String):Boolean {
        if(i !in lists.indices) return false
        val incomingId=readYoutubeId(uri) ?: return false
        val l=lists[i]
        val alreadyPresent=l.any{it.uri==uri}
        val stale=l.filter { entry ->
            if(!entry.youtube || !entry.name.equals(name,true) || entry.uri==uri) false
            else {
                val oldId=readYoutubeId(entry.uri)
                oldId==null || oldId==incomingId
            }
        }.map{it.uri}.toSet()
        if(stale.isNotEmpty()) l.removeAll{it.uri in stale}
        if(alreadyPresent) { if(stale.isNotEmpty()) save(i); return false }
        l.add(BreakPlaylistEntry(name,uri,true)); save(i); return true
    }
    private fun readYoutubeId(value:String):String? = runCatching {
        val uri=Uri.parse(value)
        val text=if(uri.scheme=="file") java.io.File(uri.path.orEmpty()).takeIf{it.isFile}?.readText(Charsets.UTF_8)
            else context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use{it.readText()}
        BmqCodec.decode(text.orEmpty())
    }.getOrNull()
    fun renameEntry(i:Int,uri:String,newName:String):Boolean {
        if(i !in lists.indices || newName.isBlank()) return false
        val idx=lists[i].indexOfFirst{it.uri==uri}
        if(idx<0)return false
        lists[i][idx]=lists[i][idx].copy(name=newName.trim().take(120))
        save(i);return true
    }
    fun moveEntryTo(source:Int,destination:Int,uri:String):Boolean {
        if(source !in lists.indices || destination !in lists.indices || source==destination)return false
        val entry=lists[source].firstOrNull{it.uri==uri}?:return false
        val movingKey=sourceIdentity(entry.uri,entry.youtube)
        if(lists[destination].any{it.uri==uri || (destination==queueIndex && sourceIdentity(it.uri,it.youtube)==movingKey)})return false
        if(source==queueIndex || destination==queueIndex) {
            val movedTarget=lists[destination].toList()+entry
            val remainingSource=lists[source].filterNot{it.uri==uri}
            val persisted=runCatching {
                prefs.edit().putString("p$destination",encodeEntries(movedTarget)).putString("p$source",encodeEntries(remainingSource)).commit()
            }.getOrDefault(false)
            if(!persisted) return false
            lists[destination].add(entry)
            lists[source].removeAll{it.uri==uri}
            return true
        }
        lists[destination].add(entry);save(destination)
        lists[source].removeAll{it.uri==uri};save(source)
        return true
    }
    fun remove(i:Int,index:Int){ if(i in lists.indices && index in lists[i].indices){lists[i].removeAt(index);save(i)} }
    fun removeUris(i:Int, uris:Set<String>){
        if(i !in lists.indices || uris.isEmpty()) return
        val entries=lists[i]
        val updated=entries.filterNot{it.uri in uris}
        if(updated.size==entries.size) return
        if(i==queueIndex) {
            if(!runCatching { prefs.edit().putString("p$i",encodeEntries(updated)).commit() }.getOrDefault(false)) return
            entries.clear();entries.addAll(updated)
            onPlaylistChanged?.invoke(i)
        } else {
            entries.removeAll{it.uri in uris};save(i)
        }
    }
    fun move(i:Int,from:Int,to:Int){ if(i !in lists.indices)return;val l=lists[i]; if(from in l.indices && to in l.indices && from!=to){ val x=l.removeAt(from);l.add(to,x);save(i)} }
    /** Reorder one stable row key relative to another and persist the new order immediately. */
    fun moveRelative(i:Int, movingUri:String, targetUri:String, after:Boolean):Boolean {
        if(i !in lists.indices || movingUri==targetUri) return false
        val l=lists[i]
        val from=l.indexOfFirst{it.uri==movingUri}
        val target=l.indexOfFirst{it.uri==targetUri}
        if(from<0 || target<0) return false
        val updated=l.toMutableList()
        val entry=updated.removeAt(from)
        val targetAfterRemoval=updated.indexOfFirst{it.uri==targetUri}
        if(targetAfterRemoval<0) return false
        updated.add((targetAfterRemoval+if(after)1 else 0).coerceIn(0,updated.size),entry)
        if(i==queueIndex) {
            if(!runCatching { prefs.edit().putString("p$i",encodeEntries(updated)).commit() }.getOrDefault(false)) return false
            l.clear();l.addAll(updated)
            onPlaylistChanged?.invoke(i)
        } else {
            l.clear();l.addAll(updated);save(i)
        }
        return true
    }
    fun moveUrisByStep(i:Int, uris:Set<String>, direction:Int):Boolean {
        if(i !in lists.indices || uris.isEmpty() || direction==0) return false
        val l=lists[i]; var moved=false
        if(direction<0){ for(n in 1 until l.size){ if(l[n].uri in uris && l[n-1].uri !in uris){ val x=l[n-1];l[n-1]=l[n];l[n]=x;moved=true } } }
        else { for(n in l.size-2 downTo 0){ if(l[n].uri in uris && l[n+1].uri !in uris){ val x=l[n+1];l[n+1]=l[n];l[n]=x;moved=true } } }
        if(moved) save(i); return moved
    }
    fun resolve(i:Int):List<BreakItem> = lists.getOrNull(i).orEmpty().filterNot { it.missing }.mapNotNull { e -> runCatching { val uri=Uri.parse(e.uri); val doc=if(uri.scheme=="file") DocumentFile.fromFile(java.io.File(uri.path.orEmpty())) else DocumentFile.fromSingleUri(context,uri); doc?.let { BreakItem(it,e.name,e.youtube) } }.getOrNull() }
    fun removeMedia(uri:String){ lists.indices.forEach { i -> lists[i].removeAll{it.uri==uri};save(i) } }
    fun renameMedia(uri:String,name:String){ lists.indices.forEach { i -> var changed=false;lists[i].indices.forEach { n -> if(lists[i][n].uri==uri){lists[i][n]=lists[i][n].copy(name=name);changed=true} };if(changed)save(i) } }
    private fun load(i:Int){ runCatching { val a=JSONArray(prefs.getString("p$i","[]")); repeat(a.length()){ n-> val o=a.getJSONObject(n);lists[i].add(BreakPlaylistEntry(o.getString("name"),o.getString("uri"),o.optBoolean("yt"),o.optBoolean("missing",false),o.optString("sourceKind","EXISTING_SELECTION"),o.optInt("sourcePlaylistIndex",-1),o.optString("videoId").takeIf{it.isNotBlank()},o.optString("sourceContext",""))) } } }
    private fun encode(i:Int):String = encodeEntries(lists[i])
    private fun encodeEntries(entries:List<BreakPlaylistEntry>):String { val a=JSONArray();entries.forEach{a.put(JSONObject().put("name",it.name).put("uri",it.uri).put("yt",it.youtube).put("missing",it.missing).put("sourceKind",it.sourceKind).put("sourcePlaylistIndex",it.sourcePlaylistIndex).put("videoId",it.videoId).put("sourceContext",it.sourceContext))};return a.toString() }
    private fun save(i:Int){ prefs.edit().putString("p$i",encode(i)).apply(); onPlaylistChanged?.invoke(i) }
}
