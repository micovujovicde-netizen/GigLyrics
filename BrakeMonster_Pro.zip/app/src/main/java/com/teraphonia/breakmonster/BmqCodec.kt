package com.teraphonia.breakmonster

import android.content.Context
import android.net.Uri
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * BMQ is a protected TRACK REFERENCE, not an audio recording or permanent stream URL.
 * BMQ1 uses an installation-scoped Android Keystore AES-GCM key; copied BMQ1 files
 * cannot be opened on another installation.
 */
internal object BmqCodec {
    private const val ALIAS = "brakemonster_pro_bmq_v1"
    private const val PREFIX_DEVICE = "BMQ1:"
    private val idRegex = Regex("^[A-Za-z0-9_-]{11}$")

    fun extractId(link: String?): String? {
        val raw = link?.trim().orEmpty()
        if (idRegex.matches(raw)) return raw
        val uri = runCatching { Uri.parse(raw) }.getOrNull() ?: return null
        val host = uri.host?.lowercase()?.removePrefix("www.")?.removePrefix("m.") ?: return null
        val candidate = when (host) {
            "youtu.be" -> uri.pathSegments.firstOrNull()
            "youtube.com", "music.youtube.com" -> if(uri.pathSegments.firstOrNull() == "watch") uri.getQueryParameter("v") else null
            else -> null
        }
        return candidate?.takeIf(idRegex::matches)
    }

    private fun deviceKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder(ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build())
        }.generateKey()
    }

    private fun encrypt(id: String, key: SecretKey, prefix: String): String {
        require(idRegex.matches(id)) { "Invalid audio reference" }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        cipher.updateAAD(prefix.toByteArray(Charsets.US_ASCII))
        val encrypted = cipher.doFinal(id.toByteArray(Charsets.US_ASCII))
        val packed = cipher.iv + encrypted
        return prefix + Base64.encodeToString(packed, Base64.NO_WRAP)
    }

    private fun decrypt(body: String, key: SecretKey, prefix: String): String {
        val data = Base64.decode(body, Base64.DEFAULT)
        require(data.size in 28..512) { "Invalid BMQ length" }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, data.copyOfRange(0, 12)))
        cipher.updateAAD(prefix.toByteArray(Charsets.US_ASCII))
        val id = cipher.doFinal(data.copyOfRange(12, data.size)).toString(Charsets.US_ASCII)
        require(idRegex.matches(id)) { "Invalid BMQ video ID" }
        return id
    }

    fun encode(link: String): String = encrypt(extractId(link) ?: error("Invalid YouTube URL"), deviceKey(), PREFIX_DEVICE)

    /** Encrypt a bundled playlist in one Keystore session on an IO dispatcher. */
    fun encodeBundledIds(ids: List<String>): List<String> {
        if (ids.isEmpty()) return emptyList()
        val key = deviceKey()
        return ids.map { id -> encrypt(id, key, PREFIX_DEVICE) }
    }

    fun decode(contents: String): String {
        val data = contents.trim()
        return when {
            data.startsWith(PREFIX_DEVICE) -> decrypt(data.removePrefix(PREFIX_DEVICE), deviceKey(), PREFIX_DEVICE)
            else -> extractId(data) ?: error("Not a valid BMQ or YouTube reference")
        }
    }

    fun convertToDevice(contents: String): String = encode(decode(contents))

    fun readReference(context: Context, uri: Uri): String {
        val body = if(uri.scheme == "file") {
            val file = File(uri.path.orEmpty())
            require(file.length() < 8192) { "BMQ file too large" }
            file.readText(Charsets.UTF_8)
        } else {
            context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText().take(8192) }
                ?: error("Cannot read BMQ file")
        }
        return decode(body)
    }

    /** Convert only app-owned files; do not modify another app's documents. */
    fun migrateOwnedYt(context: Context, root: File) {
        if (!root.isDirectory) return
        root.walkTopDown().filter { it.isFile && it.extension.equals("yt", true) }.forEach { file ->
            runCatching {
                if (file.length() > 8192) return@runCatching
                val target = File(file.parentFile, "${file.nameWithoutExtension}.bmq")
                val id = extractId(file.readText(Charsets.UTF_8)) ?: return@runCatching
                if (!target.exists()) atomicWrite(target, encode(id))
                // Keep the original .yt for already-saved legacy playlist URIs.
                // New imports and saves use only .bmq; migration never breaks P1-P8.
            }.onFailure { BlackBox.log("BMQ migrate failed ${file.name}: ${it.javaClass.simpleName}") }
        }
    }

    fun atomicWrite(target: File, body: String) {
        target.parentFile?.mkdirs()
        val temp = File.createTempFile("bmq_", ".tmp", target.parentFile)
        try {
            temp.writeText(body, Charsets.UTF_8)
            check(temp.renameTo(target)) { "BMQ write failed" }
        } finally { temp.delete() }
    }
}
