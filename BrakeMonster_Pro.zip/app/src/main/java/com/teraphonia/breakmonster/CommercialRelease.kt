package com.teraphonia.breakmonster

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import androidx.compose.runtime.*
import androidx.core.content.FileProvider
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import java.io.File
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import javax.net.ssl.HttpsURLConnection

/** Independent of the audio service. No commercial path sends a player command. */
internal class CommercialRelease(private val activity: MainActivity, private val busy: () -> Boolean) {
    // QA entitlements must never survive into a production build installed over the same APK.
    private val prefs = activity.getSharedPreferences(
        if (BuildConfig.BM_LICENSE_TEST_MODE) "bm_commercial_v1_TEST" else "bm_commercial_v1",
        Context.MODE_PRIVATE
    )
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var checkoutReturnJob: Job? = null
    private var testCheckoutStarting = false
    private val manifestUrl = "https://teraphonia.com/releases/latest.json"
    private val api = if (BuildConfig.BM_LICENSE_TEST_MODE)
        "https://brakemonster-license-test.micovujovic-de.workers.dev/v1"
    else "https://brakemonster-license.micovujovic-de.workers.dev/v1"
    private val day = 86_400_000L
    private var pending: Release? = null
    private var dismissed = false // session = process lifetime, survives Activity recreation below
    private var dialog: AlertDialog? = null
    private var checking = false
    private var downloading = false
    private var auxiliaryDialog: AlertDialog? = null
    private var checkoutErrorDialog: AlertDialog? = null
    private val licenseRefreshMutex = Mutex()
    private val devicesDialog by lazy {
        LicenseDevicesDialog(activity, scope, ::deviceRequest, ::refreshLicense) {
            licenseRefreshMutex.withLock {
                prefs.edit().putBoolean("active", false).putLong("valid_until", 0L)
                    .putString("entitlement_type", "free").remove("confirmed").apply()
                readCachedLicense()
            }
            refreshLicense()
            Unit
        }
    }
    private suspend fun deviceRequest(path: String, body: JSONObject?): JSONObject {
        return withContext(Dispatchers.IO) {
            val c = connection("$api/$path")
            try {
                c.setRequestProperty("Authorization", "Bearer $token")
                if (body != null) {
                    c.requestMethod = "POST"
                    c.doOutput = true
                    c.setRequestProperty("Content-Type", "application/json")
                    c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                }
                val status = c.responseCode
                if (status != 200) {
                    val reason = when (status) {
                        400 -> "Invalid activation code or request."
                        401 -> "Installation could not be authenticated. Please retry."
                        403 -> "This license is not active. Check the subscription."
                        404 -> if (path == "activation-code")
                            "No paid license code is available for this installation, or the server does not support activation yet."
                            else "Code or device not found. Check the code and retry."
                        409 -> "All three device slots are occupied. Open MY DEVICES and release a slot."
                        429 -> "Too many requests. Please wait before retrying."
                        else -> "Activation service unavailable. Please retry."
                    }
                    throw java.io.IOException("$reason (HTTP $status)")
                }
                val bytes = c.inputStream.use { input ->
                    val output = java.io.ByteArrayOutputStream()
                    val buffer = ByteArray(4096)
                    while (output.size() <= 65_536) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        output.write(buffer, 0, count)
                    }
                    output.toByteArray()
                }
                require(bytes.size <= 65_536) { "Invalid activation response." }
                JSONObject(bytes.toString(Charsets.UTF_8))
            } catch (error: java.net.SocketTimeoutException) {
                throw java.io.IOException("Connection timed out. You can safely retry.", error)
            } catch (error: java.net.UnknownHostException) {
                throw java.io.IOException("Offline. Connect to the internet and retry.", error)
            } finally {
                c.disconnect()
            }
        }
    }
    private var deferredMessage: Pair<String, String>? = null
    var active by mutableStateOf(false); private set
    // Server-authoritative entitlement kind: paid, lifetime, trial, grace, free.
    var entitlementType by mutableStateOf("free"); private set
    private val trialFingerprint: String? by lazy {
        val androidId = Settings.Secure.getString(activity.contentResolver, Settings.Secure.ANDROID_ID)
        androidId?.takeIf { it.isNotBlank() && it != "9774d56d682e549c" }?.let { id ->
            val input = "BM_TRIAL_V1|${activity.packageName}|$id"
            MessageDigest.getInstance("SHA-256")
                .digest(input.toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
        }
    }
    var licenseStatus by mutableStateOf("PRO not activated. Checkout is available only after final release approval."); private set
    var updateStatus by mutableStateOf("Not checked"); private set
    private val token: String = prefs.getString("device_token", null) ?: ByteArray(32).also {
        SecureRandom().nextBytes(it)
    }.joinToString("") { "%02x".format(it) }.also { prefs.edit().putString("device_token", it).commit() }

    data class Release(val code: Long, val name: String, val url: String, val sha: String, val size: Long, val notes: String)
    companion object { private var sessionDismissed = false }
    private fun canShowMessage() = activity.lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED) && !activity.isFinishing && !activity.isDestroyed
    private fun idle() = canShowMessage() && !busy()
    private fun installed() = activity.packageManager.getPackageInfo(activity.packageName, 0)
    private fun versionCode() = if (Build.VERSION.SDK_INT >= 28) installed().longVersionCode else installed().versionCode.toLong()
    fun versionName(): String = installed().versionName.orEmpty()
    fun start() {
        readCachedLicense()
        runCatching {
            val cached = JSONObject(prefs.getString("release_manifest", "{}").orEmpty())
            if(cached.optBoolean("available")) pending = parseRelease(cached).takeIf { it.code > versionCode() }
        }
        scope.launch {
            checkUpdates(false)
            refreshLicense()
            var lastLicense = SystemClock.elapsedRealtime()
            while (isActive) {
                delay(1500)
                readCachedLicense()
                if (idle() && pending != null && !dismissed && !sessionDismissed && dialog == null) showUpdate()
                if (System.currentTimeMillis() - prefs.getLong("update_attempt", 0) >= day) checkUpdates(false)
                if (SystemClock.elapsedRealtime() - lastLicense >= 15 * 60_000L) {
                    lastLicense = SystemClock.elapsedRealtime(); refreshLicense()
                }
                // Only an unsolicited UPDATE prompt may be dismissed when playback starts.
                // auxiliaryDialog also owns BUY PRO / TEST PLAN, subscription and help
                // dialogs explicitly opened by the user; playback must never close them.
                if (busy()) {
                    dialog?.dismiss(); dialog = null
                }
                if (canShowMessage() && deferredMessage != null) {
                    val next = deferredMessage!!; deferredMessage = null; message(next.first, next.second)
                }
            }
        }
    }
    // A paid checkout runs in the browser. Refresh immediately when the app returns,
    // without waiting for the 15-minute poll. Never interrupt playback.
    fun onReturnToApp() {
        checkoutReturnJob?.cancel()
        checkoutReturnJob = scope.launch {
            refreshLicense()
            // A newly purchased YEARLY/LIFETIME entitlement may arrive after an already
            // active MONTHLY entitlement. Never stop retrying just because active=true.
            val purchaseStarted = prefs.getLong("checkout_started", 0L)
            val elapsed = System.currentTimeMillis() - purchaseStarted
            if (purchaseStarted > 0L && elapsed in 0..(15 * 60_000L)) {
                for (pause in listOf(5_000L, 10_000L, 15_000L, 20_000L)) {
                    if (prefs.getLong("checkout_started", 0L) == 0L) break
                    delay(pause)
                    refreshLicense()
                }
            }
        }
    }
    fun close() { devicesDialog.close(); dialog?.dismiss(); auxiliaryDialog?.dismiss(); checkoutErrorDialog?.dismiss(); scope.cancel() }
    private fun readCachedLicense() {
        val now = System.currentTimeMillis()
        val confirmed = prefs.getLong("confirmed", 0)
        val validUntil = prefs.getLong("valid_until", 0)
        // At most 72 hours since confirmation, never beyond the paid/trial period.
        active = prefs.getBoolean("active", false) && now >= confirmed && now < validUntil && now - confirmed <= 3 * day
        entitlementType = if (active) prefs.getString("entitlement_type", "paid") ?: "paid" else "free"
        BreakPlaybackService.setProAccess(active)
        if (!active && confirmed > 0) licenseStatus = "FREE mode. Your music and playlists are safe. Buy PRO to unlock premium features."
    }
    private fun connection(url: String): HttpsURLConnection {
        require(URL(url).protocol == "https")
        return (URL(url).openConnection() as HttpsURLConnection).apply {
            connectTimeout = 10_000; readTimeout = 15_000; instanceFollowRedirects = false
        }
    }
    private fun json(
        url: String, auth: Boolean = false, post: Boolean = false, body: String = "{}",
        onHttpStatus: (Int) -> Unit = {}
    ): JSONObject {
        val c = connection(url)
        try {
            if (auth) c.setRequestProperty("Authorization", "Bearer $token")
            if (auth && url == "$api/license") {
                trialFingerprint?.let { c.setRequestProperty("X-BM-Trial-Device", it) }
            }
            if (post) { c.requestMethod = "POST"; c.doOutput = true; c.setRequestProperty("Content-Type", "application/json"); c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) } }
            val httpStatus = c.responseCode
            onHttpStatus(httpStatus)
            require(httpStatus == 200) { "Service unavailable" }
            val bytes = c.inputStream.use { input ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(4096)
                while(output.size() <= 65_536) { val n = input.read(buffer); if(n < 0) break; output.write(buffer, 0, n) }
                output.toByteArray()
            }
            require(bytes.size <= 65_536)
            return JSONObject(bytes.toString(Charsets.UTF_8))
        } finally { c.disconnect() }
    }
    private suspend fun refreshLicense(): Boolean = licenseRefreshMutex.withLock {
        try {
            val result = withContext(Dispatchers.IO) { json("$api/license", true) }
            val now = System.currentTimeMillis()
            val enabledByServer = result.optBoolean("active", false)
            val until = LicenseValidity.confirmedPaidUntil(
                active = enabledByServer,
                plan = result.optString("plan", ""),
                rawUntil = result.opt("validUntil"),
                nowMillis = now
            )
            val enabled = enabledByServer && until > now
            // The Worker, not the phone clock, grants TRIAL and GRACE.
            // Older production Worker responses without entitlementType remain paid-only.
            val kind = result.optString("entitlementType", if (enabled) "paid" else "free")
                .takeIf { it in setOf("free", "paid", "lifetime", "trial", "grace") } ?: "free"
            prefs.edit().putBoolean("active", enabled).putLong("valid_until", until)
                .putString("entitlement_type", if (enabled) kind else "free")
                .putLong("confirmed", now).apply()
            // Old MONTHLY entitlement is not proof that the new checkout completed.
            val started = prefs.getLong("checkout_started", 0L)
            val baseline = prefs.getLong("checkout_baseline_until", 0L)
            if (enabled && started > 0L && until > baseline) {
                prefs.edit().remove("checkout_started").remove("checkout_baseline_until").apply()
                BlackBox.log("LICENSE CHECKOUT CONFIRMED higher paid-until")
            }
            readCachedLicense()
            licenseStatus = result.optString("status", if(active) "Active" else "FREE mode")
            return@withLock enabled && kind in setOf("paid", "lifetime", "grace")
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            readCachedLicense()
            licenseStatus = if(active) "Offline: last confirmed license (up to 72 hours, within subscription period)." else "Online license check unavailable. Playback remains available."
            return@withLock false
        }
    }
    fun requirePro(feature: String) {
        if (active) return
        if (!canShowMessage()) return
        val d = AlertDialog.Builder(activity)
            .setTitle(AppLanguage.text("BRAKEMONSTER PRO · $feature"))
            .setMessage(AppLanguage.text("Your 7-day PRO trial or subscription has ended. ") +
                AppLanguage.text("LOCAL FILES and basic playback remain available. Your playlists and settings are safe."))
            .setPositiveButton(AppLanguage.text("BUY PRO")) { _, _ -> buy() }
            .setNegativeButton(AppLanguage.text("CONTINUE FREE"), null).create()
        style(d)
    }
    fun buy() {
        if (!BuildConfig.BM_LICENSE_TEST_MODE) {
            // Preserve approved PRODUCTION behavior: website controls LIVE sales.
            prefs.edit().putLong("checkout_baseline_until", prefs.getLong("valid_until", 0L))
                .putLong("checkout_started", System.currentTimeMillis()).apply()
            open("https://teraphonia.com/buy.html#device=$token")
            return
        }
        showTestPlanPicker()
    }

    // A single accessible selection screen for all three TEST Creem products.
    // Plan IDs and API credentials remain exclusively on the TEST Worker.
    private fun showTestPlanPicker() {
        if (testCheckoutStarting || activity.isFinishing || activity.isDestroyed) return
        auxiliaryDialog?.dismiss()
        val dp = activity.resources.displayMetrics.density
        fun dip(value: Int) = (value * dp + 0.5f).toInt()
        val container = android.widget.LinearLayout(activity).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(dip(12), dip(8), dip(12), dip(8))
            setBackgroundColor(android.graphics.Color.BLACK)
        }
        container.addView(android.widget.TextView(activity).apply {
            text = AppLanguage.text("TEST MODE — no real charge")
            textSize = 19f
            setTextColor(android.graphics.Color.WHITE)
            gravity = android.view.Gravity.CENTER
            setPadding(0, dip(6), 0, dip(12))
        })
        val choice = AlertDialog.Builder(activity)
            .setTitle(AppLanguage.text("🦖 SELECT TEST PLAN"))
            .setView(container)
            .setNegativeButton(AppLanguage.text("CANCEL"), null)
            .create()
        for ((plan, label) in listOf(
            "monthly" to "MONTHLY  €2.99",
            "yearly" to "YEARLY  €19.90",
            "lifetime" to "LIFETIME  €39.00"
        )) {
            container.addView(android.widget.Button(activity).apply {
                text = AppLanguage.text(label)
                textSize = 21f
                isAllCaps = false
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(android.graphics.Color.BLACK)
                backgroundTintList = android.content.res.ColorStateList.valueOf(android.graphics.Color.rgb(134, 245, 0))
                minHeight = dip(70)
                layoutParams = android.widget.LinearLayout.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT, dip(72)
                ).apply { setMargins(0, dip(4), 0, dip(4)) }
                setOnClickListener {
                    // Keep the plan picker visible while the server responds.
                    // On failure show a diagnostic message; close only after the browser opens.
                    startTestCheckout(plan) { choice.dismiss() }
                }
            })
        }
        auxiliaryDialog = choice
        choice.setOnDismissListener { if (auxiliaryDialog === choice) auxiliaryDialog = null }
        style(choice)
    }

    private fun testCheckoutResponse(plan: String): JSONObject {
        val c = connection("$api/checkout")
        try {
            c.setRequestProperty("Authorization", "Bearer $token")
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(JSONObject().put("plan", plan).toString().toByteArray(Charsets.UTF_8)) }
            val status = c.responseCode
            val responseText = (if (status == 200) c.inputStream else c.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText().take(8192) }.orEmpty()
            val result = runCatching { JSONObject(responseText) }.getOrNull()
            if (status != 200) {
                val provider = result?.optInt("providerStatus", 0)?.takeIf { it > 0 }
                val trace = result?.optString("traceId", "")?.takeIf { it.matches(Regex("[A-Za-z0-9-]{8,128}")) }
                val reason = result?.optString("providerMessage", "")?.take(120)
                    ?.takeIf { it.matches(Regex("[A-Za-z0-9 .,:;!?()_-]{1,120}")) }
                val detail = buildString {
                    append("Worker HTTP $status")
                    if (provider != null) append("; Creem HTTP $provider")
                    if (!reason.isNullOrBlank()) append("\n$reason")
                    if (trace != null) append("\nTrace: $trace")
                }
                throw IllegalStateException(detail)
            }
            return result ?: throw IllegalStateException("Invalid checkout response JSON")
        } finally { c.disconnect() }
    }

    private fun startTestCheckout(plan: String, onOpened: () -> Unit) {
        if (testCheckoutStarting || plan !in setOf("monthly", "yearly", "lifetime")) return
        testCheckoutStarting = true
        BlackBox.log("TEST CHECKOUT $plan START")
        scope.launch {
            try {
                val response = withContext(Dispatchers.IO) { testCheckoutResponse(plan) }
                val u = URL(response.getString("url"))
                require(u.protocol == "https" && u.userInfo == null && u.port == -1 &&
                    (u.host == "creem.io" || u.host.endsWith(".creem.io"))) { "Untrusted checkout destination" }
                // Android intent errors must surface instead of disappearing silently.
                activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u.toString())))
                prefs.edit().putLong("checkout_baseline_until", prefs.getLong("valid_until", 0L))
                    .putLong("checkout_started", System.currentTimeMillis()).apply()
                BlackBox.log("TEST CHECKOUT $plan BROWSER OPENED")
                onOpened()
            } catch (e: Exception) {
                val reason = e.message?.take(280) ?: e.javaClass.simpleName
                BlackBox.log("TEST CHECKOUT $plan FAILED ${e.javaClass.simpleName}: $reason")
                message("TEST ${plan.uppercase()} CHECKOUT", "$reason\nNo charge was attempted by the app.")
            } finally { testCheckoutStarting = false }
        }
    }
    fun help() = open("https://teraphonia.com/help.html")
    private fun open(url: String) { runCatching { activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } }
    fun status(onBackup: () -> Unit) {
        scope.launch { refreshLicense() }
        val message = (if (BuildConfig.BM_LICENSE_TEST_MODE) "TEST MODE — no real payments\n" else "") +
            "Installed: ${versionName()} (${versionCode()})\n" +
            "Access: ${entitlementType.uppercase()}\n$licenseStatus\nUpdates: $updateStatus"
        val title = when {
            !active -> "BUY PRO"
            entitlementType in setOf("trial", "grace") -> "TRIAL"
            else -> "BM PRO"
        }
        val backup = android.widget.Button(activity).apply {
            text = AppLanguage.text("BACKUP ALL")
            textSize = 18f
        }
        val actions = android.widget.LinearLayout(activity).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            addView(backup, android.widget.LinearLayout.LayoutParams(
                0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            ))
        }
        val bb = if (BuildConfig.BM_LICENSE_TEST_MODE) android.widget.Button(activity).apply {
            text = AppLanguage.text("BB")
            textSize = 18f
            contentDescription = "Black Box: TEST license fingerprint"
            actions.addView(this, android.widget.LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        } else null
        val panel = android.widget.LinearLayout(activity).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            addView(actions)
        }
        val activation = android.widget.Button(activity).apply {
            text = if (active && entitlementType in setOf("paid", "lifetime", "grace"))
                AppLanguage.text("MY DEVICES") else AppLanguage.text("ACTIVATE PRO")
            textSize = 20f
            minHeight = (64 * resources.displayMetrics.density).toInt()
            setOnClickListener { devicesDialog.show() }
        }
        panel.addView(activation)
        if (active && entitlementType in setOf("paid", "lifetime", "grace")) scope.launch {
            try {
                val result = deviceRequest("activation-code", null)
                if (result.getInt("deviceLimit") == 3)
                    activation.text = AppLanguage.text("MY DEVICES — ${result.getInt("used")}/3")
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                // The dialog remains available to show a retriable connection error.
            }
        }
        fun dp(value: Int) = (value * activity.resources.displayMetrics.density).toInt()
        val content = android.widget.LinearLayout(activity).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        content.addView(android.widget.ImageView(activity).apply {
            setImageResource(R.drawable.breakmonster_logo)
            adjustViewBounds = true
            contentDescription = "BrakeMonster PRO"
        }, android.widget.LinearLayout.LayoutParams(-1, dp(90)))
        content.addView(android.widget.ImageView(activity).apply {
            setImageResource(R.drawable.teraphonia_wordmark)
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            contentDescription = "TERAPHONIA · Open teraphonia.com"
            isFocusable = true
            setPadding(dp(16), dp(8), dp(16), dp(12))
            setOnClickListener { open("https://teraphonia.com") }
        }, android.widget.LinearLayout.LayoutParams(-1, dp(76)))
        content.addView(android.widget.TextView(activity).apply {
            text = AppLanguage.text("$title\n$message")
            textSize = 20f
            setTextColor(android.graphics.Color.WHITE)
            setPadding(0, 0, 0, dp(12))
        })
        content.addView(panel)
        val d = AlertDialog.Builder(activity).setView(android.widget.ScrollView(activity).apply {
            isFillViewport = true
            addView(content)
        }).create()
        fun action(label: String, run: () -> Unit) {
            content.addView(android.widget.Button(activity).apply {
                text = AppLanguage.text(label)
                textSize = 18f
                minHeight = dp(56)
                setOnClickListener { d.dismiss(); run() }
            }, android.widget.LinearLayout.LayoutParams(-1, -2))
        }
        action(if (BuildConfig.BM_LICENSE_TEST_MODE && active) "TEST PLANS" else "CHECK FOR UPDATES") {
            if (BuildConfig.BM_LICENSE_TEST_MODE && active) buy() else scope.launch { checkUpdates(true) }
        }
        action(if (active && entitlementType in setOf("paid", "lifetime")) "MANAGE SUBSCRIPTION" else "BUY PRO") {
            if (active && entitlementType in setOf("paid", "lifetime")) manage() else buy()
        }
        action("LANGUAGE") { AppLanguage.choose(activity) { status(onBackup) } }
        action("HELP") { help() }
        action("CLOSE") {}
        backup.setOnClickListener { d.dismiss(); onBackup() }
        bb?.setOnClickListener { showLicenseFingerprint() }
        style(d)
    }
    private fun showLicenseFingerprint() {
        if (!BuildConfig.BM_LICENSE_TEST_MODE) return
        val fingerprint = MessageDigest.getInstance("SHA-256")
            .digest(token.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        val localUntil = prefs.getLong("valid_until", 0L)
        val localReport = buildString {
            appendLine("TEST · ${versionName()} (${versionCode()})")
            appendLine("Checked at (UTC): ${java.time.Instant.now()}")
            appendLine("Endpoint: $api/license")
            appendLine("token_hash (SHA-256): $fingerprint")
            appendLine("Trial header available: ${trialFingerprint != null}")
            appendLine("App access: ${entitlementType.uppercase()} (active=$active)")
            appendLine("Cached validUntil (ms): $localUntil")
            appendLine("Cache confirmed (ms): ${prefs.getLong("confirmed", 0L)}")
            append("Checkout pending since (ms): ${prefs.getLong("checkout_started", 0L)}")
        }
        var report = "$localReport\n\nChecking TEST license…"
        val diagnostic = AlertDialog.Builder(activity)
            .setTitle(AppLanguage.text("BB · TEST LICENSE"))
            .setMessage(report)
            .setPositiveButton(AppLanguage.text("COPY"), null)
            .setNegativeButton(AppLanguage.text("CLOSE"), null)
            .create()
        style(diagnostic)
        val messageView = diagnostic.findViewById<android.widget.TextView>(android.R.id.message)
        messageView?.apply {
            textSize = 17f
            setTextIsSelectable(true)
        }
        val copy = diagnostic.getButton(AlertDialog.BUTTON_POSITIVE)
        copy.isEnabled = false
        copy.setOnClickListener {
            val clipboard = activity.getSystemService(android.content.ClipboardManager::class.java)
            clipboard?.setPrimaryClip(android.content.ClipData.newPlainText("BB TEST LICENSE", report))
        }
        val check = scope.launch {
            val serverReport = withContext(Dispatchers.IO) {
                var status: Int? = null
                try {
                    val reply = json("$api/license", auth = true, onHttpStatus = { status = it })
                    val plan = reply.optString("plan").takeIf {
                        it in setOf("monthly", "yearly", "lifetime", "trial", "grace", "free")
                    } ?: "unknown"
                    val kind = reply.optString("entitlementType").takeIf {
                        it in setOf("paid", "lifetime", "trial", "grace", "free")
                    } ?: "unknown"
                    val until = reply.opt("validUntil")?.toString()
                        ?.takeIf { it.length <= 40 && it.matches(Regex("[0-9TtZz:+.\\-]+")) } ?: "missing/invalid"
                    "HTTP $status · active=${reply.optBoolean("active", false)}\n" +
                        "Server plan: $plan\nServer access: $kind\nServer validUntil: $until"
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    "HTTP ${status ?: "no response"} · ${e.javaClass.simpleName}"
                }
            }
            report = "$localReport\n\n$serverReport"
            messageView?.text = report
            copy.isEnabled = true
        }
        diagnostic.setOnDismissListener { check.cancel() }
    }

    // TEST diagnostic: reveal the server's HTTP status without showing credentials,
    // subscription identifiers, response headers, or the private portal URL.
    // Production continues to show a generic non-sensitive message.
    private fun portalRequest(): JSONObject {
        val c = connection("$api/portal")
        try {
            c.setRequestProperty("Authorization", "Bearer $token")
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write("{}".toByteArray(Charsets.UTF_8)) }
            val statusCode = c.responseCode
            val stream = if (statusCode == 200) c.inputStream else c.errorStream
            val responseText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText().take(8192) }.orEmpty()
            if (statusCode != 200) {
                val description = runCatching { JSONObject(responseText).optString("error", "") }
                    .getOrDefault("").filter { it.code in 32..126 }.take(120)
                throw IllegalStateException("HTTP $statusCode" + if (description.isNotBlank()) ": $description" else "")
            }
            return JSONObject(responseText)
        } finally { c.disconnect() }
    }
    private fun manage() { scope.launch {
        try {
            val result = withContext(Dispatchers.IO) { portalRequest() }
            val url = result.getString("url")
            val u = URL(url)
            require(u.protocol == "https" && u.userInfo == null && u.port == -1 &&
                (u.host == "creem.io" || u.host.endsWith(".creem.io"))) { "Invalid secure portal destination" }
            activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            val body = if (BuildConfig.BM_LICENSE_TEST_MODE)
                "TEST portal failed: " + (e.message?.take(180) ?: e.javaClass.simpleName) +
                    "\nNo payment was attempted."
            else "Subscription management is unavailable. Contact teraphonia8@gmail.com."
            message("SUBSCRIPTION", body)
        }
    } }
    private fun message(title: String, body: String) {
        if (activity.isFinishing || activity.isDestroyed) return
        // User-facing failures must be visible even when music is playing.
        if (!canShowMessage()) { deferredMessage = title to body; return }
        val d = AlertDialog.Builder(activity).setTitle(AppLanguage.text(title)).setMessage(AppLanguage.text(body)).setPositiveButton(AppLanguage.text("OK"), null).create()
        if (title.startsWith("TEST ") && title.endsWith(" CHECKOUT")) {
            // Error dialog overlays the still-open plan picker; it does not replace it.
            checkoutErrorDialog?.dismiss()
            checkoutErrorDialog = d
            d.setOnDismissListener { if (checkoutErrorDialog === d) checkoutErrorDialog = null }
        } else auxiliaryDialog = d
        style(d)
    }
    private fun style(d: AlertDialog) {
        d.show()
        val density = activity.resources.displayMetrics.density
        val green = android.graphics.Color.rgb(6,38,25)
        val gold = android.graphics.Color.rgb(210,188,130)
        d.window?.setBackgroundDrawable(android.graphics.drawable.GradientDrawable().apply {
            setColor(green)
            cornerRadius = 18 * density
            setStroke((2 * density).toInt(), gold)
        })
        fun decorate(view: android.view.View) {
            if (view is android.widget.TextView) view.setTextColor(
                if (view.text.toString() == "TERAPHONIA") gold else android.graphics.Color.WHITE
            )
            if (view is android.widget.Button) {
                view.textSize = 18f
                view.minHeight = (56 * density).toInt()
                view.setTextColor(android.graphics.Color.rgb(182,242,59))
                view.backgroundTintList = android.content.res.ColorStateList.valueOf(android.graphics.Color.rgb(35,53,38))
            }
            if (view is android.view.ViewGroup) for (i in 0 until view.childCount) decorate(view.getChildAt(i))
        }
        d.window?.decorView?.let { decorate(it) }
        d.findViewById<android.widget.TextView>(android.R.id.message)?.textSize = 22f
    }
    private suspend fun checkUpdates(manual: Boolean) {
        if (checking) return
        if (!manual && System.currentTimeMillis() - prefs.getLong("update_attempt", 0) < day) return
        checking = true
        prefs.edit().putLong("update_attempt", System.currentTimeMillis()).apply()
        try {
            val r = withContext(Dispatchers.IO) { json(manifestUrl) }
            if (!r.getBoolean("available")) {
                prefs.edit().remove("release_manifest").apply()
                pending = null; updateStatus = "No verified public APK has been released."
            } else {
                val release = parseRelease(r)
                prefs.edit().putString("release_manifest", r.toString()).apply()
                updateStatus = "Latest: ${release.name} (${release.code}). " + if(release.code > versionCode()) "Update available." else "YOU HAVE THE LATEST VERSION."
                pending = release.takeIf { it.code > versionCode() }
                if (manual && pending != null && idle()) { dismissed = false; sessionDismissed = false; showUpdate() }
            }
            if (manual && (pending == null || !idle())) message("CHECK FOR UPDATES", "Installed: ${versionName()} (${versionCode()})\n$updateStatus" + if(!idle() && pending != null) "\nNotification deferred until playback stops." else "")
        } catch (_: Exception) {
            updateStatus = "Cannot check updates. Check your internet connection and try again."
            if (manual) message("CHECK FOR UPDATES", "Installed: ${versionName()}\n$updateStatus")
        } finally { checking = false }
    }
    private fun parseRelease(r: JSONObject): Release {
        require(r.getString("applicationId") == activity.packageName)
        val release = Release(r.getLong("versionCode"), r.getString("versionName"), r.getString("apkUrl"), r.getString("sha256").lowercase(), r.getLong("sizeBytes"), r.getString("notes").take(220))
        require(release.code > 0 && release.name.length in 1..60 && release.size in 1..536_870_912L && release.sha.matches(Regex("[a-f0-9]{64}")))
        require(officialApk(release.url))
        return release
    }
    private fun officialApk(url: String): Boolean = runCatching {
        val u = URL(url)
        u.protocol == "https" && u.userInfo == null && u.port == -1 && u.host == "github.com" && u.path.startsWith("/micovujovicde-netizen/teraphonia-site/releases/download/") && u.path.endsWith(".apk")
    }.getOrDefault(false)
    private fun showUpdate() {
        val r = pending ?: return
        if (!idle() || downloading) return
        dialog = AlertDialog.Builder(activity).setTitle(AppLanguage.text("🦖 NEW BRAKEMONSTER VERSION!"))
            .setMessage(AppLanguage.text("CURRENT VERSION: ${versionName()}\nNEW VERSION: ${r.name}\nWHAT'S NEW: ${r.notes}"))
            .setPositiveButton(AppLanguage.text("UPDATE NOW")) { _, _ -> dialog = null; dismissed = true; sessionDismissed = true; download(r) }
            .setNegativeButton(AppLanguage.text("LATER")) { _, _ -> dismissed = true; sessionDismissed = true; dialog = null }
            .setOnCancelListener { dismissed = true; sessionDismissed = true; dialog = null }.create().also { style(it) }
    }
    private fun download(r: Release) {
        if (downloading) return
        downloading = true
        val progress = android.widget.ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        val progressDialog = AlertDialog.Builder(activity).setTitle(AppLanguage.text("DOWNLOAD UPDATE")).setView(progress)
            .setMessage(AppLanguage.text("Downloading official APK…")).setNegativeButton(AppLanguage.text("HIDE"), null).create()
        auxiliaryDialog = progressDialog
        style(progressDialog)
        scope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    val dest = File(activity.cacheDir, "updates").apply { mkdirs() }
                    val partial = File.createTempFile("download-", ".part", dest); val target = File(dest, "BrakeMonster-${r.code}.apk")
                    try {
                        var url = r.url; var c: HttpsURLConnection? = null
                        for (hop in 0..4) {
                            c = connection(url)
                            if (c.responseCode == 200) break
                            require(c.responseCode in listOf(301,302,303,307,308))
                            val next = URL(URL(url), c.getHeaderField("Location")); c.disconnect()
                            require(next.protocol == "https" && next.userInfo == null && next.port == -1 && next.host in setOf("github.com", "release-assets.githubusercontent.com", "objects.githubusercontent.com"))
                            url = next.toString()
                        }
                        val streamConnection = requireNotNull(c)
                        try {
                            require(streamConnection.responseCode == 200)
                            val hash = MessageDigest.getInstance("SHA-256"); var total = 0L; var lastProgress = -1
                            streamConnection.inputStream.use { input -> partial.outputStream().use { output ->
                                val buffer = ByteArray(32768)
                                while(true) {
                                    currentCoroutineContext().ensureActive()
                                    val n = input.read(buffer); if(n < 0) break
                                    total += n; require(total <= r.size)
                                    hash.update(buffer,0,n); output.write(buffer,0,n)
                                    val pct = (total * 100 / r.size).toInt()
                                    if(pct != lastProgress) { lastProgress = pct; withContext(Dispatchers.Main) { progress.progress = pct } }
                                }
                            } }
                            require(total == r.size && hash.digest().joinToString("") { "%02x".format(it) } == r.sha) { "APK integrity mismatch" }
                        } finally { streamConnection.disconnect() }
                        verifyApk(partial, r)
                        if(target.exists()) check(target.delete())
                        check(partial.renameTo(target)); target
                    } catch (e: Exception) { partial.delete(); throw e }
                }
                progressDialog.dismiss(); auxiliaryDialog = null
                if(idle()) offerInstall(file) else message("UPDATE READY", "APK verified. Open HELP / ABOUT → CHECK FOR UPDATES after stopping playback, then UPDATE NOW to install.")
            } catch (e: CancellationException) { progressDialog.dismiss(); throw e }
            catch (_: Exception) { progressDialog.dismiss(); message("UPDATE FAILED", "Download or security verification failed. No APK was installed. Try again when online.") }
            finally { downloading = false }
        }
    }
    @Suppress("DEPRECATION")
    private fun verifyApk(file: File, r: Release) {
        val flags = if(Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
        val pm = activity.packageManager
        val archive = requireNotNull(pm.getPackageArchiveInfo(file.path, flags))
        val current = pm.getPackageInfo(activity.packageName, flags)
        require(archive.packageName == activity.packageName)
        val code = if(Build.VERSION.SDK_INT >= 28) archive.longVersionCode else archive.versionCode.toLong()
        require(code == r.code && code > versionCode() && archive.versionName == r.name)
        require((archive.applicationInfo?.minSdkVersion ?: Int.MAX_VALUE) <= Build.VERSION.SDK_INT)
        val incoming = if(Build.VERSION.SDK_INT >= 28) archive.signingInfo?.apkContentsSigners else archive.signatures
        val existing = if(Build.VERSION.SDK_INT >= 28) current.signingInfo?.apkContentsSigners else current.signatures
        require(!incoming.isNullOrEmpty() && !existing.isNullOrEmpty())
        require(incoming.map { it.toCharsString() }.toSet() == existing.map { it.toCharsString() }.toSet()) { "Signing key mismatch" }
    }
    private fun offerInstall(file: File) {
        if (!idle()) return
        val d = AlertDialog.Builder(activity).setTitle(AppLanguage.text("APK VERIFIED")).setMessage(AppLanguage.text("Android will ask you to confirm this update. Your playlists and settings stay in place."))
            .setPositiveButton(AppLanguage.text("INSTALL")) { _, _ ->
                if(!idle()) return@setPositiveButton
                if(Build.VERSION.SDK_INT >= 26 && !activity.packageManager.canRequestPackageInstalls()) {
                    message("ALLOW APP UPDATES", "Allow installs from BrakeMonster in Android settings, then retry UPDATE NOW.")
                    activity.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}")))
                } else {
                    val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.updates", file)
                    runCatching { activity.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
                        .onFailure { message("INSTALLATION", "Android installer is unavailable. No update was installed.") }
                }
            }.setNegativeButton(AppLanguage.text("LATER"), null).create()
        auxiliaryDialog = d
        style(d)
    }
}
