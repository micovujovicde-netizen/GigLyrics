package com.teraphonia.breakmonster

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import androidx.compose.runtime.*
import androidx.core.content.FileProvider
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import javax.net.ssl.HttpsURLConnection

/** Independent of the audio service. No commercial path sends a player command. */
internal class CommercialRelease(private val activity: MainActivity, private val busy: () -> Boolean) {
    private val prefs = activity.getSharedPreferences("bm_commercial_v1", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val manifestUrl = "https://teraphonia.com/releases/latest.json"
    private val api = "https://api.teraphonia.com/v1"
    private val day = 86_400_000L
    private var pending: Release? = null
    private var dismissed = false // session = process lifetime, survives Activity recreation below
    private var dialog: AlertDialog? = null
    private var checking = false
    private var downloading = false
    private var auxiliaryDialog: AlertDialog? = null
    private var deferredMessage: Pair<String, String>? = null
    var active by mutableStateOf(false); private set
    var licenseStatus by mutableStateOf("Not activated. Billing is not yet available."); private set
    var updateStatus by mutableStateOf("Not checked"); private set
    private val token: String = prefs.getString("device_token", null) ?: ByteArray(32).also {
        SecureRandom().nextBytes(it)
    }.joinToString("") { "%02x".format(it) }.also { prefs.edit().putString("device_token", it).commit() }

    data class Release(val code: Long, val name: String, val url: String, val sha: String, val size: Long, val notes: String)
    companion object { private var sessionDismissed = false }
    private fun idle() = activity.lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED) && !activity.isFinishing && !busy()
    private fun installed() = activity.packageManager.getPackageInfo(activity.packageName, 0)
    private fun versionCode() = if (Build.VERSION.SDK_INT >= 28) installed().longVersionCode else installed().versionCode.toLong()
    fun versionName(): String = installed().versionName.orEmpty()
    fun start() {
        readCachedLicense()
        runCatching {
            val cached = JSONObject(prefs.getString("release_manifest", "{}").orEmpty())
            if(cached.optBoolean("available")) pending = parseRelease(cached).takeIf { it.code > versionCode() }
        }
        scope.launch {
            checkUpdates(false)
            refreshLicense()
            var lastLicense = SystemClock.elapsedRealtime()
            while (isActive) {
                delay(1500)
                readCachedLicense()
                if (idle() && pending != null && !dismissed && !sessionDismissed && dialog == null) showUpdate()
                if (System.currentTimeMillis() - prefs.getLong("update_attempt", 0) >= day) checkUpdates(false)
                if (SystemClock.elapsedRealtime() - lastLicense >= 15 * 60_000L) {
                    lastLicense = SystemClock.elapsedRealtime(); refreshLicense()
                }
                // A playback start removes any automatic update dialog immediately.
                if (busy()) {
                    dialog?.dismiss(); dialog = null
                    auxiliaryDialog?.dismiss(); auxiliaryDialog = null
                }
                if (idle() && deferredMessage != null) {
                    val next = deferredMessage!!; deferredMessage = null; message(next.first, next.second)
                }
            }
        }
    }
    fun close() { dialog?.dismiss(); auxiliaryDialog?.dismiss(); scope.cancel() }
    private fun readCachedLicense() {
        val now = System.currentTimeMillis()
        val confirmed = prefs.getLong("confirmed", 0)
        val validUntil = prefs.getLong("valid_until", 0)
        // At most 72 hours since confirmation, never beyond the paid/trial period.
        active = prefs.getBoolean("active", false) && now >= confirmed && now < validUntil && now - confirmed <= 3 * day
        if (!active && confirmed > 0) licenseStatus = "License expired or needs an online check. Playback remains available."
    }
    private fun connection(url: String): HttpsURLConnection {
        require(URL(url).protocol == "https")
        return (URL(url).openConnection() as HttpsURLConnection).apply {
            connectTimeout = 10_000; readTimeout = 15_000; instanceFollowRedirects = false
        }
    }
    private fun json(url: String, auth: Boolean = false, post: Boolean = false): JSONObject {
        val c = connection(url)
        try {
            if (auth) c.setRequestProperty("Authorization", "Bearer $token")
            if (post) { c.requestMethod = "POST"; c.doOutput = true; c.setRequestProperty("Content-Type", "application/json"); c.outputStream.use { it.write("{}".toByteArray()) } }
            require(c.responseCode == 200) { "Service unavailable" }
            val bytes = c.inputStream.use { input ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(4096)
                while(output.size() <= 65_536) { val n = input.read(buffer); if(n < 0) break; output.write(buffer, 0, n) }
                output.toByteArray()
            }
            require(bytes.size <= 65_536)
            return JSONObject(bytes.toString(Charsets.UTF_8))
        } finally { c.disconnect() }
    }
    private suspend fun refreshLicense() {
        try {
            val result = withContext(Dispatchers.IO) { json("$api/license", true) }
            val now = System.currentTimeMillis()
            val until = result.getLong("validUntil")
            val enabled = result.getBoolean("active") && until > now
            prefs.edit().putBoolean("active", enabled).putLong("valid_until", until).putLong("confirmed", now).apply()
            readCachedLicense()
            licenseStatus = result.optString("status", if(active) "Active" else "Not activated")
        } catch (_: Exception) {
            readCachedLicense()
            licenseStatus = if(active) "Offline: last confirmed license (up to 72 hours, within subscription period)." else "Online license check unavailable. Playback remains available."
        }
    }
    fun buy() = open("https://teraphonia.com/buy.html#device=$token")
    fun help() = open("https://teraphonia.com/help.html")
    private fun open(url: String) { runCatching { activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } }
    fun status() {
        scope.launch { refreshLicense() }
        val message = "Installed: ${versionName()} (${versionCode()})\n$licenseStatus\nUpdates: $updateStatus"
        val d = AlertDialog.Builder(activity).setTitle(if(active) "BM PRO · HELP / ABOUT" else "HELP / ABOUT")
            .setMessage(message).setPositiveButton("CHECK FOR UPDATES") { _, _ -> scope.launch { checkUpdates(true) } }
            .setNegativeButton("HELP") { _, _ -> help() }
            .setNeutralButton(if(active) "MANAGE SUBSCRIPTION" else "BUY PRO") { _, _ -> if(active) manage() else buy() }.create()
        style(d)
    }
    private fun manage() { scope.launch {
        try {
            val result = withContext(Dispatchers.IO) { json("$api/portal", true, true) }
            val url = result.getString("url"); val u = URL(url)
            require(u.protocol == "https" && (u.host == "creem.io" || u.host.endsWith(".creem.io")))
            open(url)
        } catch (_: Exception) { message("SUBSCRIPTION", "Subscription management is unavailable. Contact teraphonia8@gmail.com.") }
    } }
    private fun message(title: String, body: String) {
        if (activity.isFinishing || activity.isDestroyed) return
        if (!idle()) { deferredMessage = title to body; return }
        auxiliaryDialog = AlertDialog.Builder(activity).setTitle(title).setMessage(body).setPositiveButton("OK", null).create().also { style(it) }
    }
    private fun style(d: AlertDialog) {
        d.show()
        d.window?.setBackgroundDrawableResource(android.R.color.black)
        d.findViewById<android.widget.TextView>(android.R.id.message)?.apply { textSize = 22f; setTextColor(android.graphics.Color.WHITE) }
        listOf(-1,-2,-3).forEach { d.getButton(it)?.apply { textSize = 18f; minHeight = (56 * resources.displayMetrics.density).toInt(); setTextColor(android.graphics.Color.rgb(134,245,0)) } }
    }
    private suspend fun checkUpdates(manual: Boolean) {
        if (checking) return
        if (!manual && System.currentTimeMillis() - prefs.getLong("update_attempt", 0) < day) return
        checking = true
        prefs.edit().putLong("update_attempt", System.currentTimeMillis()).apply()
        try {
            val r = withContext(Dispatchers.IO) { json(manifestUrl) }
            if (!r.getBoolean("available")) {
                prefs.edit().remove("release_manifest").apply()
                pending = null; updateStatus = "No verified public APK has been released."
            } else {
                val release = parseRelease(r)
                prefs.edit().putString("release_manifest", r.toString()).apply()
                updateStatus = "Latest: ${release.name} (${release.code}). " + if(release.code > versionCode()) "Update available." else "YOU HAVE THE LATEST VERSION."
                pending = release.takeIf { it.code > versionCode() }
                if (manual && pending != null && idle()) { dismissed = false; sessionDismissed = false; showUpdate() }
            }
            if (manual && (pending == null || !idle())) message("CHECK FOR UPDATES", "Installed: ${versionName()} (${versionCode()})\n$updateStatus" + if(!idle() && pending != null) "\nNotification deferred until playback stops." else "")
        } catch (_: Exception) {
            updateStatus = "Cannot check updates. Check your internet connection and try again."
            if (manual) message("CHECK FOR UPDATES", "Installed: ${versionName()}\n$updateStatus")
        } finally { checking = false }
    }
    private fun parseRelease(r: JSONObject): Release {
        require(r.getString("applicationId") == activity.packageName)
        val release = Release(r.getLong("versionCode"), r.getString("versionName"), r.getString("apkUrl"), r.getString("sha256").lowercase(), r.getLong("sizeBytes"), r.getString("notes").take(220))
        require(release.code > 0 && release.name.length in 1..60 && release.size in 1..536_870_912L && release.sha.matches(Regex("[a-f0-9]{64}")))
        require(officialApk(release.url))
        return release
    }
    private fun officialApk(url: String): Boolean = runCatching {
        val u = URL(url)
        u.protocol == "https" && u.userInfo == null && u.port == -1 && u.host == "github.com" && u.path.startsWith("/micovujovicde-netizen/teraphonia-site/releases/download/") && u.path.endsWith(".apk")
    }.getOrDefault(false)
    private fun showUpdate() {
        val r = pending ?: return
        if (!idle() || downloading) return
        dialog = AlertDialog.Builder(activity).setTitle("🦖 NEW BRAKEMONSTER VERSION!")
            .setMessage("CURRENT VERSION: ${versionName()}\nNEW VERSION: ${r.name}\nWHAT'S NEW: ${r.notes}")
            .setPositiveButton("UPDATE NOW") { _, _ -> dialog = null; dismissed = true; sessionDismissed = true; download(r) }
            .setNegativeButton("LATER") { _, _ -> dismissed = true; sessionDismissed = true; dialog = null }
            .setOnCancelListener { dismissed = true; sessionDismissed = true; dialog = null }.create().also { style(it) }
    }
    private fun download(r: Release) {
        if (downloading) return
        downloading = true
        val progress = android.widget.ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        val progressDialog = AlertDialog.Builder(activity).setTitle("DOWNLOAD UPDATE").setView(progress)
            .setMessage("Downloading official APK…").setNegativeButton("HIDE", null).create()
        auxiliaryDialog = progressDialog
        style(progressDialog)
        scope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    val dest = File(activity.cacheDir, "updates").apply { mkdirs() }
                    val partial = File.createTempFile("download-", ".part", dest); val target = File(dest, "BrakeMonster-${r.code}.apk")
                    try {
                        var url = r.url; var c: HttpsURLConnection? = null
                        for (hop in 0..4) {
                            c = connection(url)
                            if (c.responseCode == 200) break
                            require(c.responseCode in listOf(301,302,303,307,308))
                            val next = URL(URL(url), c.getHeaderField("Location")); c.disconnect()
                            require(next.protocol == "https" && next.userInfo == null && next.port == -1 && next.host in setOf("github.com", "release-assets.githubusercontent.com", "objects.githubusercontent.com"))
                            url = next.toString()
                        }
                        val streamConnection = requireNotNull(c)
                        try {
                            require(streamConnection.responseCode == 200)
                            val hash = MessageDigest.getInstance("SHA-256"); var total = 0L; var lastProgress = -1
                            streamConnection.inputStream.use { input -> partial.outputStream().use { output ->
                                val buffer = ByteArray(32768)
                                while(true) {
                                    currentCoroutineContext().ensureActive()
                                    val n = input.read(buffer); if(n < 0) break
                                    total += n; require(total <= r.size)
                                    hash.update(buffer,0,n); output.write(buffer,0,n)
                                    val pct = (total * 100 / r.size).toInt()
                                    if(pct != lastProgress) { lastProgress = pct; withContext(Dispatchers.Main) { progress.progress = pct } }
                                }
                            } }
                            require(total == r.size && hash.digest().joinToString("") { "%02x".format(it) } == r.sha) { "APK integrity mismatch" }
                        } finally { streamConnection.disconnect() }
                        verifyApk(partial, r)
                        if(target.exists()) check(target.delete())
                        check(partial.renameTo(target)); target
                    } catch (e: Exception) { partial.delete(); throw e }
                }
                progressDialog.dismiss(); auxiliaryDialog = null
                if(idle()) offerInstall(file) else message("UPDATE READY", "APK verified. Open HELP / ABOUT → CHECK FOR UPDATES after stopping playback, then UPDATE NOW to install.")
            } catch (e: CancellationException) { progressDialog.dismiss(); throw e }
            catch (_: Exception) { progressDialog.dismiss(); message("UPDATE FAILED", "Download or security verification failed. No APK was installed. Try again when online.") }
            finally { downloading = false }
        }
    }
    @Suppress("DEPRECATION")
    private fun verifyApk(file: File, r: Release) {
        val flags = if(Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
        val pm = activity.packageManager
        val archive = requireNotNull(pm.getPackageArchiveInfo(file.path, flags))
        val current = pm.getPackageInfo(activity.packageName, flags)
        require(archive.packageName == activity.packageName)
        val code = if(Build.VERSION.SDK_INT >= 28) archive.longVersionCode else archive.versionCode.toLong()
        require(code == r.code && code > versionCode() && archive.versionName == r.name)
        require((archive.applicationInfo?.minSdkVersion ?: Int.MAX_VALUE) <= Build.VERSION.SDK_INT)
        val incoming = if(Build.VERSION.SDK_INT >= 28) archive.signingInfo?.apkContentsSigners else archive.signatures
        val existing = if(Build.VERSION.SDK_INT >= 28) current.signingInfo?.apkContentsSigners else current.signatures
        require(!incoming.isNullOrEmpty() && !existing.isNullOrEmpty())
        require(incoming.map { it.toCharsString() }.toSet() == existing.map { it.toCharsString() }.toSet()) { "Signing key mismatch" }
    }
    private fun offerInstall(file: File) {
        if (!idle()) return
        val d = AlertDialog.Builder(activity).setTitle("APK VERIFIED").setMessage("Android will ask you to confirm this update. Your playlists and settings stay in place.")
            .setPositiveButton("INSTALL") { _, _ ->
                if(!idle()) return@setPositiveButton
                if(Build.VERSION.SDK_INT >= 26 && !activity.packageManager.canRequestPackageInstalls()) {
                    message("ALLOW APP UPDATES", "Allow installs from BrakeMonster in Android settings, then retry UPDATE NOW.")
                    activity.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}")))
                } else {
                    val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.updates", file)
                    runCatching { activity.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
                        .onFailure { message("INSTALLATION", "Android installer is unavailable. No update was installed.") }
                }
            }.setNegativeButton("LATER", null).create()
        auxiliaryDialog = d
        style(d)
    }
}
