package com.teraphonia.breakmonster

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageInstaller
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.io.File

/** Observe the actual install result instead of treating an APK viewer handoff as success. */
internal class UpdateInstallSession(
    private val activity: MainActivity,
    private val scope: CoroutineScope,
    private val idle: () -> Boolean,
    private val installed: (Long) -> Boolean,
    private val validate: suspend (File, Long) -> Unit,
    private val status: (String) -> Unit,
    private val finished: (Int) -> Unit
) {
    private val installer = activity.packageManager.packageInstaller
    private val prefs = activity.getSharedPreferences("bm_update_session_v1", Context.MODE_PRIVATE)
    private val action = "${activity.packageName}.UPDATE_SESSION_RESULT"
    private var sessionId = -1
    private var retriesUsed = 0
    private var terminal = false
    private var preparing = false
    private var confirmation: Intent? = null
    private var confirmationStarted = false
    private var genericFailureReported = false
    private var file: File? = null
    private var target = 0L
    private var watch: Job? = null
    val inProgress: Boolean get() = preparing || (sessionId >= 0 && !terminal)

    private val receiver = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != action || intent.getIntExtra(PackageInstaller.EXTRA_SESSION_ID, -1) != sessionId) return
            if (!intent.hasExtra(PackageInstaller.EXTRA_STATUS)) return
            val result = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
            BlackBox.log("UPDATE SESSION result=$result id=$sessionId retry=$retriesUsed detail=${intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE).orEmpty().take(250)}")
            if (result == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                confirmation = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                else intent.getParcelableExtra(Intent.EXTRA_INTENT)
                if (confirmation == null) { finish(PackageInstaller.STATUS_FAILURE); return }
                showConfirmation()
            } else if (UpdateRetryGate.retryableStatus(result, retriesUsed)) {
                genericFailureReported = true
                // Samsung/Android can finish a dropped first attempt with a generic
                // failure rather than no callback. v272 treated that as final.
                status("Installation interrupted. Preparing one automatic retry…")
                armWatch()
            } else {
                finish(result)
            }
        }
    }
    init {
        // Mutable PendingIntent is required for PackageInstaller status extras on API 35.
        // The intent is package-scoped and this receiver is not exported.
        ContextCompat.registerReceiver(activity, receiver, IntentFilter(action), ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    fun onResumed() {
        if (!inProgress) return
        if (!confirmationStarted && confirmation != null) showConfirmation()
    }

    suspend fun begin(apk: File, version: Long, automatic: Boolean = false) {
        if (preparing || (!automatic && inProgress)) return
        if (automatic && (terminal || retriesUsed != 0)) return
        if (!automatic) terminal = false
        preparing = true
        try {
            validate(apk, version)
            if (!idle() || installed(version) || (automatic && terminal)) return
            val oldId = if (sessionId >= 0) sessionId else prefs.getInt("session_id", -1)
            // Never create a competing session while Android reports active install work.
            if (oldId >= 0 && installer.getSessionInfo(oldId)?.isActive == true && !genericFailureReported) {
                status("Android is still processing the update. Please wait.")
                return
            }
            if (automatic) retriesUsed++ else retriesUsed = 0
            if (oldId >= 0) runCatching { installer.abandonSession(oldId) }
            terminal = false
            genericFailureReported = false
            confirmation = null; confirmationStarted = false
            file = apk; target = version
            status(if (automatic) "Installation did not start. Retrying automatically once…" else "Preparing Android installation…")
            val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL).apply {
                setAppPackageName(activity.packageName)
                setSize(apk.length())
                if (Build.VERSION.SDK_INT >= 31) setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_REQUIRED)
            }
            val id = installer.createSession(params)
            sessionId = id
            BlackBox.log("UPDATE SESSION created id=$id target=$version retry=$retriesUsed")
            prefs.edit().putInt("session_id", id).apply()
            val mutable = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val result = PendingIntent.getBroadcast(activity, id,
                Intent(action).setPackage(activity.packageName), PendingIntent.FLAG_UPDATE_CURRENT or mutable)
            try {
                withContext(Dispatchers.IO) {
                    installer.openSession(id).use { session ->
                        session.openWrite("base.apk", 0, apk.length()).use { output ->
                            apk.inputStream().use { input ->
                                val buffer = ByteArray(32768)
                                while (true) {
                                    currentCoroutineContext().ensureActive()
                                    val n = input.read(buffer)
                                    if (n < 0) break
                                    output.write(buffer, 0, n)
                                }
                            }
                            session.fsync(output)
                        }
                    }
                }
                // The activity may have gone to the background during the copy. Commit
                // can finish staging, but the confirmation is opened only while idle.
                installer.openSession(id).use { it.commit(result.intentSender) }
                armWatch()
            } catch (e: Exception) {
                runCatching { installer.abandonSession(id) }
                throw e
            }
        } catch (e: CancellationException) { throw e }
        catch (_: Exception) { finish(PackageInstaller.STATUS_FAILURE) }
        finally { preparing = false }
    }

    private fun showConfirmation() {
        if (!idle() || terminal || confirmationStarted) return
        val prompt = confirmation ?: return
        confirmationStarted = true
        status("Confirm installation in Android. Update is not confirmed yet.")
        // A rejected handoff is handled by the same bounded watchdog. Do not
        // reset this flag and let the foreground poll launch unlimited prompts.
        runCatching { activity.startActivity(prompt) }
            .onSuccess { BlackBox.log("UPDATE SESSION confirmation opened id=$sessionId retry=$retriesUsed") }
            .onFailure { BlackBox.log("UPDATE SESSION confirmation launch failed id=$sessionId error=${it.javaClass.simpleName}") }
        armWatch()
    }

    private fun armWatch() {
        watch?.cancel()
        watch = scope.launch {
            var foregroundWait = 0L
            while (isActive && !terminal) {
                delay(250)
                if (installed(target)) { finish(PackageInstaller.STATUS_SUCCESS); return@launch }
                if (!idle() || !activity.hasWindowFocus()) { foregroundWait = 0; continue }
                foregroundWait += 250
                // A final generic failure is authoritative even if SessionInfo
                // briefly retains its old active flag. A live install with no
                // failure callback is still protected from a competing retry.
                val active = installer.getSessionInfo(sessionId)?.isActive == true && !genericFailureReported
                if (foregroundWait == 3000L) BlackBox.log("UPDATE SESSION watchdog id=$sessionId active=$active retry=$retriesUsed")
                // Give initial staging/verification 15 seconds. After an Android
                // confirmation closes without any result, allow a 3-second grace.
                val missingResultWait = foregroundWait - if (confirmationStarted) 0L else 12000L
                if (UpdateRetryGate.mayRetry(retriesUsed, terminal, false, true, active, missingResultWait)) {
                    // No success/error/cancel result and no active installation: repeat
                    // the complete session once using the same locally verified APK.
                    val apk = file ?: return@launch
                    val oldId = sessionId
                    begin(apk, target, automatic = true)
                    if (terminal || sessionId != oldId) return@launch
                }
                if (missingResultWait >= 3000 && retriesUsed >= 1 && !active) {
                    finish(PackageInstaller.STATUS_FAILURE)
                    return@launch
                }
            }
        }
    }

    private fun finish(result: Int) {
        if (terminal) return
        terminal = true
        watch?.cancel(); watch = null
        confirmation = null
        if (result != PackageInstaller.STATUS_SUCCESS && sessionId >= 0 &&
            installer.getSessionInfo(sessionId)?.isActive != true) {
            runCatching { installer.abandonSession(sessionId) }
        }
        prefs.edit().remove("session_id").apply()
        // In particular, STATUS_FAILURE_ABORTED (cancel/abort) is terminal and never retried.
        finished(result)
    }

    fun close() {
        watch?.cancel()
        runCatching { activity.unregisterReceiver(receiver) }
    }
}
