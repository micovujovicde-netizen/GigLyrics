package com.teraphonia.breakmonster

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp

/** Caption-only fitting; music titles and user playlist names never pass here. */
@Composable
internal fun FittedControlText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontWeight: FontWeight? = null,
    textAlign: TextAlign? = null,
    maxLines: Int = 1,
    softWrap: Boolean = false,
    overflow: TextOverflow = TextOverflow.Clip,
    style: TextStyle = LocalTextStyle.current,
    lineHeight: TextUnit = TextUnit.Unspecified
) {
    val measurer = rememberTextMeasurer()
    val baseSize = if (fontSize == TextUnit.Unspecified) style.fontSize else fontSize
    val size = if (baseSize == TextUnit.Unspecified) 16.sp else baseSize
    BoxWithConstraints(modifier) {
        val measured = measurer.measure(text, style.merge(TextStyle(fontSize = size, fontWeight = fontWeight)), softWrap = false, maxLines = maxLines)
        val ratio = if (constraints.hasBoundedWidth) {
            (constraints.maxWidth.toFloat() / measured.size.width.coerceAtLeast(1)).coerceIn(.72f, 1f)
        } else 1f
        Text(text, color = color, fontSize = (size.value * ratio).sp,
            fontWeight = fontWeight, textAlign = textAlign, maxLines = maxLines,
            softWrap = softWrap, overflow = overflow, style = style, lineHeight = lineHeight)
    }
}
