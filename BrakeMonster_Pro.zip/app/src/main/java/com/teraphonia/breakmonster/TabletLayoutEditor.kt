package com.teraphonia.breakmonster

import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Tablet-only layout settings. Reading and writing these values never touches
// playback/playlist settings, and phones always use their old coordinates.
internal data class TabletElementPlacement(
    val dx: Float = 0f,
    val dy: Float = 0f,
    val widthPlus: Float = 0f,
    val heightPlus: Float = 0f,
    val fontScale: Float = 1f
)

internal val TABLET_EDITABLE_HEADER = listOf("local", "logo", "find")

internal fun tabletLayoutLabel(id: String): String = when (id) {
    "local" -> "LOCAL FILES"
    "logo" -> "BRAKEMONSTER LOGO"
    "find" -> "FIND YOUR PLAYLISTS"
    else -> "ELEMENT"
}

internal class TabletLayoutState(private val preferences: SharedPreferences) {
    val elements = mutableStateMapOf<String, TabletElementPlacement>()
    var isEditing by mutableStateOf(false)
        private set
    var selected by mutableStateOf("local")
        private set

    init { load() }

    private fun read(id: String) = TabletElementPlacement(
        dx = preferences.getFloat("${id}_dx", 0f).coerceIn(-250f, 250f),
        dy = preferences.getFloat("${id}_dy", 0f).coerceIn(-140f, 260f),
        widthPlus = preferences.getFloat("${id}_w", 0f).coerceIn(-120f, 300f),
        heightPlus = preferences.getFloat("${id}_h", 0f).coerceIn(-80f, 170f),
        fontScale = preferences.getFloat("${id}_font", 1f).coerceIn(.75f, 1.5f)
    )

    private fun load() { TABLET_EDITABLE_HEADER.forEach { elements[it] = read(it) } }
    fun placement(id: String): TabletElementPlacement = elements[id] ?: TabletElementPlacement()
    fun begin() { load(); selected = "local"; isEditing = true }
    fun select(id: String) { if (id in TABLET_EDITABLE_HEADER) selected = id }

    fun move(id: String, x: Float, y: Float) {
        val old = placement(id)
        elements[id] = old.copy(
            dx = (old.dx + x).coerceIn(-250f, 250f),
            dy = (old.dy + y).coerceIn(-140f, 260f)
        )
    }

    fun resize(id: String, width: Float, height: Float) {
        val old = placement(id)
        val minWidthPlus = if (id == "logo") -170f else if (id == "find") -55f else -45f
        elements[id] = old.copy(
            widthPlus = (old.widthPlus + width).coerceIn(minWidthPlus, 300f),
            heightPlus = (old.heightPlus + height).coerceIn(if (id == "logo") -60f else -25f, 140f)
        )
    }

    fun changeFont(amount: Float) {
        if (selected == "logo") return
        val old = placement(selected)
        elements[selected] = old.copy(fontScale = (old.fontScale + amount).coerceIn(.75f, 1.5f))
    }

    fun resetSelected() { elements[selected] = TabletElementPlacement() }
    fun cancel() { load(); isEditing = false }
    fun save(): Boolean {
        val editor = preferences.edit()
        TABLET_EDITABLE_HEADER.forEach { id ->
            val p = placement(id)
            editor.putFloat("${id}_dx", p.dx)
            editor.putFloat("${id}_dy", p.dy)
            editor.putFloat("${id}_w", p.widthPlus)
            editor.putFloat("${id}_h", p.heightPlus)
            editor.putFloat("${id}_font", p.fontScale)
        }
        val saved = editor.commit()
        if (saved) isEditing = false
        return saved
    }
}

/** A hit surface directly on the real element. Drag = move; amber corner = resize.
 * The surface exists only in edit mode, so normal taps/actions are untouched.
 */
@Composable
internal fun TabletLayoutGrab(
    id: String,
    selected: Boolean,
    onSelect: (String) -> Unit,
    onMove: (String, Float, Float) -> Unit,
    onResize: (String, Float, Float) -> Unit
) {
    val density = LocalDensity.current
    Box(
        modifier = Modifier.fillMaxSize()
            .border(if (selected) 3.dp else 2.dp, if (selected) Color(0xFFFFB52E) else Color(0xFF91FA40), RoundedCornerShape(9.dp))
            .background(Color(0x1900FF66), RoundedCornerShape(9.dp))
            .pointerInput(id) {
                detectDragGestures(onDragStart = { onSelect(id) }) { change, amount ->
                    change.consume()
                    onMove(id, amount.x / density.density, amount.y / density.density)
                }
            }
            .clickable { onSelect(id) }
    ) {
        Box(
            Modifier.align(Alignment.BottomEnd)
                .size(39.dp)
                .background(Color(0xFFFFB52E), RoundedCornerShape(topStart = 12.dp, bottomEnd = 8.dp))
                .pointerInput(id) {
                    detectDragGestures(onDragStart = { onSelect(id) }) { change, amount ->
                        change.consume()
                        onResize(id, amount.x / density.density, amount.y / density.density)
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Text("↘", color = Color.Black, fontSize = 26.sp, fontWeight = FontWeight.Black)
        }
    }
}

/** Buttons are intentionally large enough for editing from a tablet at arm's length. */
@Composable
internal fun TabletLayoutPanel(
    state: TabletLayoutState,
    onSaved: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    Surface(
        modifier = modifier.fillMaxWidth().padding(horizontal = 10.dp)
            .border(2.dp, Color(0xFFFFB52E), RoundedCornerShape(12.dp)),
        shape = RoundedCornerShape(12.dp),
        color = Color(0xF5001B10),
        shadowElevation = 12.dp
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("LAYOUT EDIT  •  ${tabletLayoutLabel(state.selected)}", color = Color(0xFFFFB52E),
                    fontSize = 17.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f), maxLines = 1)
                EditorAction("CANCEL") { state.cancel() }
                EditorAction("SAVE", Color(0xFF86F500)) {
                    if (state.save()) onSaved()
                    else Toast.makeText(context, "LAYOUT SAVE FAILED", Toast.LENGTH_LONG).show()
                }
            }
            Text("Drag a highlighted element to MOVE. Drag its yellow ↘ corner to RESIZE.",
                color = Color.White, fontSize = 13.sp, maxLines = 1)
            Spacer(Modifier.height(5.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                TABLET_EDITABLE_HEADER.forEach { id ->
                    EditorAction(tabletLayoutLabel(id),
                        if (state.selected == id) Color(0xFF86F500) else Color.White,
                        Modifier.weight(1f)) { state.select(id) }
                }
            }
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                EditorAction("W −", modifier = Modifier.weight(1f)) { state.resize(state.selected, -8f, 0f) }
                EditorAction("W +", modifier = Modifier.weight(1f)) { state.resize(state.selected, 8f, 0f) }
                EditorAction("H −", modifier = Modifier.weight(1f)) { state.resize(state.selected, 0f, -6f) }
                EditorAction("H +", modifier = Modifier.weight(1f)) { state.resize(state.selected, 0f, 6f) }
                EditorAction("A −", modifier = Modifier.weight(1f)) { state.changeFont(-.05f) }
                EditorAction("A +", modifier = Modifier.weight(1f)) { state.changeFont(.05f) }
                EditorAction("RESET", Color(0xFFFFB52E), Modifier.weight(1.45f)) { state.resetSelected() }
            }
        }
    }
}

@Composable
private fun EditorAction(label: String, color: Color = Color.White, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = modifier.height(45.dp), contentPadding = PaddingValues(horizontal = 5.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF435046), contentColor = color),
        shape = RoundedCornerShape(7.dp)) {
        Text(label, textAlign = TextAlign.Center, fontWeight = FontWeight.Black, fontSize = 13.sp, maxLines = 1)
    }
}
