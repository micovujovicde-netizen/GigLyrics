package com.teraphonia.breakmonster;

/** Center within real scroll bounds; never create blank leading/trailing slots. */
final class PlaylistTabFollow {
    static int offsetFromRoot(int currentScroll, float buttonLeft, float buttonWidth,
                              float viewportLeft, float viewportWidth, int maxScroll) {
        return offset(buttonLeft - viewportLeft + currentScroll, buttonWidth, viewportWidth, maxScroll);
    }
    static int offset(float start, float buttonWidth, float viewportWidth, int maxScroll) {
        if (viewportWidth <= 0 || maxScroll <= 0) return 0;
        int center = Math.round(start + buttonWidth / 2f - viewportWidth / 2f);
        return Math.max(0, Math.min(center, maxScroll));
    }
}
