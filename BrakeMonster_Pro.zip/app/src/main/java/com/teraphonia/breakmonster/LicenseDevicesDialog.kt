package com.teraphonia.breakmonster

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Path
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.PathShape
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlinx.coroutines.*
import org.json.JSONObject
import java.util.Locale

/** Uses the existing installation credential through CommercialRelease. */
internal class LicenseDevicesDialog(
    private val activity: MainActivity,
    private val scope: CoroutineScope,
    private val request: suspend (String, JSONObject?) -> JSONObject,
    private val refresh: suspend () -> Boolean,
    private val releaseCurrent: suspend () -> Unit
) {
    private var dialog: AlertDialog? = null
    private var job: Job? = null
    private var confirmation: AlertDialog? = null

    fun close() {
        job?.cancel()
        confirmation?.dismiss()
        dialog?.dismiss()
    }

    fun show() {
        close()
        val green = Color.rgb(134, 245, 0)
        fun dp(value: Int) = (value * activity.resources.displayMetrics.density).toInt()
        val body = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        fun label(value: String) = TextView(activity).apply {
            text = AppLanguage.text(value)
            textSize = 22f
            setTextColor(Color.WHITE)
            setPadding(0, dp(8), 0, dp(8))
            body.addView(this)
        }
        label("Enter your activation code. One license supports 3 devices.")
        val code = EditText(activity).apply {
            hint = AppLanguage.text("BM1-...")
            textSize = 22f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or
                android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
            body.addView(this, LinearLayout.LayoutParams(-1, dp(64)))
        }
        val status = label("")
        status.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        val controls = mutableListOf<Button>()
        fun button(title: String, parent: LinearLayout = body): Button {
            val path = Path().apply {
                moveTo(8f, 0f); lineTo(94f, 0f); lineTo(100f, 12f)
                lineTo(96f, 48f); lineTo(6f, 50f); lineTo(0f, 38f); close()
            }
            return Button(activity).apply {
                text = AppLanguage.text(title)
                maxLines = 2
                ellipsize = null
                textSize = 19f
                setTextColor(green)
                minHeight = dp(64)
                isAllCaps = false
                background = ShapeDrawable(PathShape(path, 100f, 50f)).apply {
                    paint.color = Color.rgb(66, 69, 60)
                }
                setPadding(dp(10), dp(10), dp(10), dp(10))
                parent.addView(this, LinearLayout.LayoutParams(-1, -2).apply {
                    topMargin = dp(8)
                })
                controls.add(this)
            }
        }
        fun canonicalCode() = code.text.toString().trim().uppercase(Locale.ROOT)
        fun input(): JSONObject {
            val value = canonicalCode()
            val compact = value.replace(Regex("[\\s-]"), "")
            require(value.length <= 120 && Regex("BM1[0-9A-HJKMNP-TV-Z]{26}").matches(compact)) {
                "Enter a valid BM1 activation code."
            }
            return JSONObject().put("code", value)
        }
        fun runAction(action: suspend () -> Unit) {
            if (job?.isActive == true) return
            job = scope.launch {
                controls.forEach { it.isEnabled = false }
                code.isEnabled = false
                status.text = AppLanguage.text("WAIT...")
                try {
                    action()
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (error: Exception) {
                    status.text = AppLanguage.text(error.message ?: "Connection unavailable. Please try again.")
                } finally {
                    controls.forEach { it.isEnabled = true }
                    code.isEnabled = true
                }
            }
        }
        fun checkCount(result: JSONObject): Int {
            require(result.getInt("deviceLimit") == 3) { "Unexpected device limit from server." }
            return result.getInt("used").also {
                require(it >= 0) { "Invalid device count from server." }
            }
        }
        val activate = button("ACTIVATE")
        val showCode = button("SHOW ACTIVATION CODE")
        val copy = button("COPY ACTIVATION CODE")
        copy.visibility = View.GONE
        val devices = button("MY DEVICES")
        val rows = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            body.addView(this)
        }
        suspend fun loadDevices() {
            val result = request("devices", input())
            val used = checkCount(result)
            val items = result.getJSONArray("devices")
            require(items.length() == used) { "Incomplete device list from server." }
            rows.removeAllViews()
            devices.text = AppLanguage.text("MY DEVICES — $used/3")
            for (index in 0 until items.length()) {
                val item = items.getJSONObject(index)
                val deviceId = item.getString("deviceId")
                require(Regex("[a-f0-9]{16}").matches(deviceId)) { "Invalid device identifier." }
                val current = item.getBoolean("thisDevice")
                val release = button("RELEASE · ${item.getInt("slot")} · ${deviceId.take(8)}" +
                    if (current) " · THIS DEVICE" else "", rows)
                release.setOnClickListener {
                    confirmation = AlertDialog.Builder(activity)
                        .setTitle(AppLanguage.text("RELEASE DEVICE?"))
                        .setMessage(AppLanguage.text("Release slot ${item.getInt("slot")}") +
                            if (current) AppLanguage.text(" on this device? Keep your activation code to activate it again.") else "?")
                        .setNegativeButton(AppLanguage.text("CANCEL"), null)
                        .setPositiveButton(AppLanguage.text("RELEASE")) { _, _ ->
                            runAction {
                                val response = request("release", input().put("deviceId", deviceId))
                                require(response.getBoolean("released")) { "Server did not confirm release." }
                                checkCount(response)
                                if (current) releaseCurrent()
                                loadDevices()
                                status.text = AppLanguage.text("Device released. A replacement device can now activate.")
                            }
                        }.create().also { confirm ->
                            confirm.show()
                            confirm.window?.setBackgroundDrawableResource(android.R.color.black)
                            confirm.findViewById<TextView>(android.R.id.message)?.apply {
                                textSize = 22f
                                setTextColor(Color.WHITE)
                            }
                            listOf(-1, -2).forEach { which ->
                                confirm.getButton(which).apply {
                                    textSize = 18f
                                    minHeight = dp(56)
                                    setTextColor(green)
                                }
                            }
                        }
                }
            }
            status.text = AppLanguage.text("$used of 3 device slots used.")
        }
        activate.setOnClickListener {
            runAction {
                val result = request("activate", input())
                require(result.getBoolean("active")) { "Server did not confirm activation." }
                checkCount(result)
                val confirmed = refresh()
                loadDevices()
                status.text = AppLanguage.text(if (confirmed) "PRO ACTIVATED" else
                    "Activation recorded. PRO is not yet confirmed by the license server. Check your connection and retry.")
            }
        }
        showCode.setOnClickListener {
            runAction {
                val result = request("activation-code", null)
                val used = checkCount(result)
                val value = result.getString("code")
                val compact = value.replace(Regex("[\\s-]"), "")
                require(value.length <= 120 && Regex("BM1[0-9A-HJKMNP-TV-Z]{26}").matches(compact)) {
                    "Invalid server activation code."
                }
                code.setText(value)
                copy.visibility = View.VISIBLE
                devices.text = AppLanguage.text("MY DEVICES — $used/3")
                loadDevices()
            }
        }
        copy.setOnClickListener {
            val clipboard = activity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("BrakeMonster activation code", canonicalCode())
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                clip.description.extras = android.os.PersistableBundle().apply {
                    putBoolean("android.content.extra.IS_SENSITIVE", true)
                }
            }
            clipboard.setPrimaryClip(clip)
            status.text = AppLanguage.text("Activation code copied. Share only with your own devices.")
        }
        devices.setOnClickListener { runAction { loadDevices() } }
        val scroll = ScrollView(activity).apply {
            isFillViewport = true
            addView(body)
        }
        dialog = AlertDialog.Builder(activity).setTitle(AppLanguage.text("ACTIVATE PRO · MY DEVICES"))
            .setView(scroll).setNegativeButton(AppLanguage.text("CLOSE"), null).create().also { window ->
                window.setOnDismissListener {
                    job?.cancel()
                    confirmation?.dismiss()
                }
                window.show()
                window.window?.apply {
                    setBackgroundDrawableResource(android.R.color.black)
                    setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
                    setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                }
                window.getButton(-2).apply {
                    textSize = 20f
                    minHeight = dp(56)
                    setTextColor(green)
                }
                window.window?.decorView?.post {
                    val maxHeight = (activity.resources.displayMetrics.heightPixels * 0.82).toInt()
                    scroll.layoutParams = scroll.layoutParams.apply { height = maxHeight - dp(110) }
                }
            }
    }
}
