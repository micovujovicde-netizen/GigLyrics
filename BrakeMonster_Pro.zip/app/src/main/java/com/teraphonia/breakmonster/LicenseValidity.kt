package com.teraphonia.breakmonster

import java.time.Instant

/**
 * Interprets the licensing server's paid-until value, without modifying playback.
 * TEST v4.1 returns epoch milliseconds, while PRODUCTION v4.2 returns ISO-8601.
 * An active, server-confirmed lifetime entitlement has no expiry, but the caller
 * must still enforce the independent maximum 72-hour offline confirmation age.
 */
internal object LicenseValidity {
    fun confirmedPaidUntil(active: Boolean, plan: String?, rawUntil: Any?, nowMillis: Long): Long {
        if (!active) return 0L
        if (plan == "lifetime") return Long.MAX_VALUE
        val until = when (rawUntil) {
            is Number -> rawUntil.toLong()
            is String -> rawUntil.toLongOrNull()
                ?: runCatching { Instant.parse(rawUntil).toEpochMilli() }.getOrNull()
            else -> null
        } ?: return 0L
        return until.takeIf { it > nowMillis } ?: 0L
    }
}
