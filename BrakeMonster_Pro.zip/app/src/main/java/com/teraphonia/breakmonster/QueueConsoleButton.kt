package com.teraphonia.breakmonster

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.*

// Make the visible console another 10% wider than the user-tested v272.
internal const val QUEUE_CONSOLE_WIDTH_SCALE = 1.07f * 1.10f * 1.10f
internal const val QUEUE_CONSOLE_NORMAL_WIDTH_DP = 50f * 3f * QUEUE_CONSOLE_WIDTH_SCALE
private const val PREVIOUS_XL_WEIGHT = (2f * 1.07f * 1.10f) / (2f - 1.07f * .10f)
private const val NEW_XL_SHARE = PREVIOUS_XL_WEIGHT / (PREVIOUS_XL_WEIGHT + 2f) * 1.10f
internal const val QUEUE_CONSOLE_XL_WEIGHT = 2f * NEW_XL_SHARE / (1f - NEW_XL_SHARE)

/** Same approved WebP, with only the two vinyl surfaces moving underneath its foreground. */
@Composable
internal fun QueueConsoleButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    active: Boolean = false
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var resumed by remember { mutableStateOf(lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) }
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, _ ->
            resumed = lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val art by produceState<QueueConsoleArt?>(null, context.applicationContext) {
        value = withContext(Dispatchers.Default) { QueueConsoleArt.load(context.applicationContext) }
    }
    Box(
        modifier = modifier
            .semantics {
                contentDescription = AppLanguage.text("QUEUE")
                selected = active
            }
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        val loaded = art
        if (loaded == null) {
            Image(painterResource(R.drawable.queue_dj_console), contentDescription = null,
                contentScale = ContentScale.FillBounds, modifier = Modifier.fillMaxSize())
        } else {
            AndroidView(
                factory = { QueueConsoleView(it, loaded) },
                update = { it.setState(active, resumed) },
                onRelease = { it.stop() },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

private data class ConsoleRecord(val cx: Float, val cy: Float, val rx: Float, val ry: Float, val left: Boolean) {
    // Ring only: original gold center labels, spindles, heads and beaks stay in place.
    fun visibleVinyl(): Path {
        val annulus = Path().apply {
            fillType = Path.FillType.EVEN_ODD
            addOval(RectF(cx-rx, cy-ry, cx+rx, cy+ry), Path.Direction.CW)
            addOval(RectF(cx-rx*.40f, cy-ry*.40f, cx+rx*.40f, cy+ry*.40f), Path.Direction.CW)
        }
        val head = Path().apply {
            if (left) {
                moveTo(0f, 0f); lineTo(477f, 0f); lineTo(477f, 239f)
                lineTo(459f, 276f); lineTo(418f, 306f); lineTo(403f, 355f)
                lineTo(393f, 377f); lineTo(379f, 359f); lineTo(360f, 303f)
                lineTo(284f, 260f); lineTo(0f, 260f)
            } else {
                moveTo(2172f, 0f); lineTo(1678f, 0f); lineTo(1678f, 239f)
                lineTo(1701f, 277f); lineTo(1750f, 305f); lineTo(1769f, 356f)
                lineTo(1781f, 378f); lineTo(1795f, 357f); lineTo(1812f, 300f)
                lineTo(1888f, 260f); lineTo(2172f, 260f)
            }
            close()
        }
        return Path().apply { op(annulus, head, Path.Op.DIFFERENCE) }
    }
}

/** Small textures are prepared once off the main thread, shared by NORMAL and XL. */
private class QueueConsoleArt(val stone: Bitmap, val records: List<Pair<ConsoleRecord, Bitmap>>) {
    companion object {
        @Volatile private var cached: QueueConsoleArt? = null
        fun load(context: Context): QueueConsoleArt = cached ?: synchronized(this) {
            cached ?: run {
                val stone = BitmapFactory.decodeResource(context.resources, R.drawable.queue_dj_console,
                    BitmapFactory.Options().apply { inScaled = false })
                val records = listOf(
                    ConsoleRecord(530f, 304f, 278f, 168f, true),
                    ConsoleRecord(1651f, 304f, 278f, 168f, false)
                )
                QueueConsoleArt(stone, records.map { it to vinylTexture(stone, it) }).also { cached = it }
            }
        }
        private fun vinylTexture(source: Bitmap, record: ConsoleRecord): Bitmap {
            val size = 256
            val original = IntArray(source.width * source.height)
            source.getPixels(original, 0, source.width, 0, 0, source.width, source.height)
            val pixels = IntArray(size * size)
            for (y in 0 until size) for (x in 0 until size) {
                val nx = (x + .5f) / size * 2f - 1f
                val ny = (y + .5f) / size * 2f - 1f
                val radius = sqrt(nx*nx + ny*ny).coerceAtMost(.999f)
                val angle = atan2(ny, nx)
                // Sample a clean lower sector of the approved vinyl. This avoids copying
                // a grandmother's face/beak into the rotating texture. Reflection repeats
                // smoothly around the circle, so the full 360-degree loop has no jump.
                val sampleAngle = if (record.left) 1.30f + .50f * sin(angle) else 1.85f + .50f * sin(angle)
                val sx = (record.cx + record.rx * radius * cos(sampleAngle)).roundToInt().coerceIn(0, source.width-1)
                val sy = (record.cy + record.ry * radius * sin(sampleAngle)).roundToInt().coerceIn(0, source.height-1)
                pixels[y*size+x] = original[sy*source.width+sx]
            }
            return Bitmap.createBitmap(pixels, size, size, Bitmap.Config.ARGB_8888)
        }
    }
}

/** Canvas animation works on Android 8+; no animated-WebP decoder/version fallback to a still. */
private class QueueConsoleView(context: Context, private val art: QueueConsoleArt) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val clips = art.records.map { it.first.visibleVinyl() }
    private val contour = queueConsoleContour()
    private val diskRect = RectF(-1f, -1f, 1f, 1f)
    private var active = false
    private var running = false
    private val started = SystemClock.uptimeMillis()
    init { importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO }
    fun setState(selected: Boolean, animate: Boolean) {
        if (active != selected || running != animate) {
            active = selected; running = animate; invalidate()
        }
    }
    fun stop() { running = false }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); invalidate() }
    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) invalidate()
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        // Previous 7% extension plus another 10%; original artwork height preserved.
        val scale = minOf(width/(art.stone.width*QUEUE_CONSOLE_WIDTH_SCALE), height.toFloat()/art.stone.height)
        canvas.save()
        canvas.translate((width-art.stone.width*scale*QUEUE_CONSOLE_WIDTH_SCALE)/2f, (height-art.stone.height*scale)/2f)
        canvas.scale(scale*QUEUE_CONSOLE_WIDTH_SCALE, scale)
        canvas.clipPath(contour)
        canvas.drawBitmap(art.stone, 0f, 0f, paint)
        val angle = ((SystemClock.uptimeMillis()-started) % 2000L) * .18f
        art.records.forEachIndexed { index, (record, texture) ->
            canvas.save()
            canvas.clipPath(clips[index])
            canvas.translate(record.cx, record.cy)
            canvas.scale(record.rx, record.ry)
            canvas.rotate(angle)
            canvas.drawBitmap(texture, null, diskRect, paint)
            canvas.restore()
        }
        // Draw the 2dp PL/RADIO-style line inward, directly on the alpha contour.
        // Clipping keeps all transparent space clear and preserves the exact height.
        outlinePaint.style = Paint.Style.STROKE
        outlinePaint.strokeJoin = Paint.Join.ROUND
        outlinePaint.strokeWidth = 4f * resources.displayMetrics.density / scale
        outlinePaint.color = if (active) 0xFFB3C478.toInt() else 0xFF77796D.toInt()
        canvas.drawPath(contour, outlinePaint)
        canvas.restore()
        if (running && isAttachedToWindow && windowVisibility == VISIBLE && isShown) postInvalidateDelayed(40L)
    }
}
