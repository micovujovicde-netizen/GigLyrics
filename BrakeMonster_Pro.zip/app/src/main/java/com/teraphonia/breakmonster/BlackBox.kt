package com.teraphonia.breakmonster

import android.os.SystemClock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BlackBox {
    private const val MAX = 500
    private var appContext: android.content.Context? = null
    private var startupReport: String? = null
    private const val LOG_FILE = "blackbox_last_session.txt"
    private const val CRASH_FILE = "blackbox_crash.txt"
    private const val FIRST_AUDIO_ERROR_FILE = "blackbox_first_audio_error.txt"
    @Synchronized fun ensureInitialized(context: android.content.Context) {
        if (appContext == null) initialize(context)
    }
    /** Keep the FIRST playback failure on disk even if the playlist later changes. */
    @Synchronized fun audioFailure(stage: String, track: String?, cause: Throwable? = null) {
        val detail = buildString {
            appendLine("FIRST AUDIO FAILURE · ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())}")
            appendLine("Stage: $stage")
            appendLine("Track: ${track ?: "unknown"}")
            if (cause != null) {
                appendLine("Exception: ${cause.javaClass.name}: ${cause.message.orEmpty()}")
                appendLine(android.util.Log.getStackTraceString(cause).take(10000))
            }
        }
        log("AUDIO FAILURE stage=$stage track=${track ?: "unknown"} cause=${cause?.javaClass?.simpleName ?: "none"}: ${cause?.message.orEmpty().take(300)}")
        val ctx = appContext ?: return
        val first = ctx.getFileStreamPath(FIRST_AUDIO_ERROR_FILE)
        if (!first.exists()) runCatching { first.writeText(detail) }
    }
    /** Read durable logs, not only the in-memory last 500 events. */
    @Synchronized fun exportAudioReport(version: String): String {
        val ctx = appContext
        val first = ctx?.getFileStreamPath(FIRST_AUDIO_ERROR_FILE)
        val events = ctx?.getFileStreamPath(LOG_FILE)
        return buildString {
            appendLine("BRAKEMONSTER PRO · AUDIO BLACK BOX")
            appendLine("Version: $version")
            appendLine("Generated: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}")
            appendLine("Device: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}; Android ${android.os.Build.VERSION.RELEASE}")
            appendLine("----------------------------------")
            appendLine("FIRST FAILURE (preserved)")
            appendLine(runCatching { first?.takeIf { it.exists() }?.readText() }.getOrNull() ?: "No audio failure recorded")
            appendLine("----------------------------------")
            appendLine("RECENT EVENTS")
            val logText = runCatching { events?.takeIf { it.exists() }?.readText() }.getOrNull()
            appendLine(logText?.takeLast(160000) ?: lines.joinToString("\n"))
        }
    }
    @Synchronized fun clearAudioReport() {
        val ctx = appContext
        ctx?.getFileStreamPath(FIRST_AUDIO_ERROR_FILE)?.delete()
        ctx?.getFileStreamPath(LOG_FILE)?.delete()
        lines.clear()
        log("AUDIO BLACK BOX RESET")
    }
    @Synchronized fun initialize(context: android.content.Context) {
        appContext = context.applicationContext
        startupReport = runCatching { context.getFileStreamPath(CRASH_FILE).takeIf { it.exists() }?.readText() }.getOrNull()
            ?: runCatching { context.getFileStreamPath(LOG_FILE).takeIf { it.exists() }?.readText() }.getOrNull()
        log("APP START pid=${android.os.Process.myPid()}")
    }
    @Synchronized fun previousReport(): String? {
        val ctx = appContext ?: return null
        val crash = runCatching { ctx.getFileStreamPath(CRASH_FILE).takeIf { it.exists() }?.readText() }.getOrNull()
        val previous = runCatching { ctx.getFileStreamPath(LOG_FILE).takeIf { it.exists() }?.readText() }.getOrNull()
        return startupReport?.takeIf { it.isNotBlank() }
    }
    @Synchronized fun acknowledgeReport() {
        appContext?.getFileStreamPath(CRASH_FILE)?.delete()
        startupReport = null
    }
    @Synchronized fun recordCrash(thread: Thread, error: Throwable) {
        val dump = "FATAL on ${thread.name}\n" + android.util.Log.getStackTraceString(error) + "\n" + report("crash")
        runCatching { appContext?.openFileOutput(CRASH_FILE, android.content.Context.MODE_PRIVATE)?.bufferedWriter()?.use { it.write(dump) } }
    }
    private val lines = ArrayDeque<String>()
    private val clock = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    @Synchronized fun log(event: String) {
        val line = "${clock.format(Date())} [${Thread.currentThread().name}] $event"
        if (lines.size >= MAX) lines.removeFirst()
        lines.addLast(line)
        runCatching {
            val ctx = appContext
            if (ctx != null) {
                val file = ctx.getFileStreamPath(LOG_FILE)
                if (file.length() > 262144L) file.writeText("[log truncated]\n")
                ctx.openFileOutput(LOG_FILE, android.content.Context.MODE_APPEND).bufferedWriter().use { it.appendLine(line) }
            }
        }
    }
    inline fun <T> timed(name: String, block: () -> T): T {
        val t = SystemClock.elapsedRealtime()
        log("START $name")
        return try { block() } catch (e: Throwable) { log("ERROR $name ${e.javaClass.simpleName}: ${e.message}"); throw e }
        finally {
            val ms = SystemClock.elapsedRealtime() - t
            val flag = when { ms >= 5000 -> " !!!>5s"; ms >= 2000 -> " !!>2s"; ms >= 500 -> " !>500ms"; else -> "" }
            log("END $name ${ms}ms$flag")
        }
    }
    @Synchronized fun report(version: String): String {
        val rt=Runtime.getRuntime(); val used=(rt.totalMemory()-rt.freeMemory())/1024/1024
        return buildString {
            appendLine("BRAKEMONSTER BLACK BOX")
            appendLine("Version: $version")
            appendLine("Device: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}; Android ${android.os.Build.VERSION.RELEASE} (SDK ${android.os.Build.VERSION.SDK_INT})")
            appendLine("Memory: ${used}MB used / ${rt.maxMemory()/1024/1024}MB max")
            appendLine("--- LAST ${lines.size} EVENTS ---")
            lines.forEach { appendLine(it) }
        }
    }
}
