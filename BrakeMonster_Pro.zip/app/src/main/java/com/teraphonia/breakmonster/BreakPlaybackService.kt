package com.teraphonia.breakmonster

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

internal const val MIN_MIX_BUFFER_PERCENT = 5
internal const val MANUAL_MIX_BUFFER_PERCENT = 10

class BreakPlaybackService : Service() {
    data class Entry(val uri: String, val name: String)
    data class StartRequest(
        val files: List<Entry>,
        val selectedUri: String?,
        val random: Boolean,
        val repeat: Boolean,
        val volume: Float,
        val crossfader: Float = -1f,
        val autoMix: Boolean = true,
        val crossfadeSeconds: Int = 2
    )
    data class Snapshot(
        val trackUri: String? = null,
        val trackName: String? = null,
        val preparing: Boolean = false,
        val playing: Boolean = false,
        val position: Int = 0,
        val duration: Int = 0,
        val random: Boolean = false,
        val repeat: Boolean = false,
        val sessionActive: Boolean = false,
        val deckAReady: Boolean = false,
        val deckBReady: Boolean = false,
        val deckBPreparing: Boolean = false,
        val deckBRecovering: Boolean = false,
        val bufferedPercentA: Int = 0,
        val bufferedPercentB: Int = 0,
        val bufferingA: Boolean = false,
        val bufferingB: Boolean = false,
        val crossfading: Boolean = false,
        val crossfader: Float = 0f,
        // Increments only after the manual B-deck handover has really completed.
        val manualMixCompletions: Long = 0L,
        val autoMix: Boolean = false,
        val crossfadeSeconds: Int = 2,
        val transitionRequested: Boolean = false,
        val standbyTrackUri: String? = null
    )

    companion object {
        private const val CHANNEL_ID = "breakmonster_playback"
        private const val NOTIFICATION_ID = 9207
        private const val ACTION_START = "com.teraphonia.breakmonster.START"
        private const val ACTION_TOGGLE = "com.teraphonia.breakmonster.TOGGLE"
        private const val ACTION_PREVIOUS = "com.teraphonia.breakmonster.PREVIOUS"
        private const val ACTION_NEXT = "com.teraphonia.breakmonster.NEXT"
        private const val ACTION_STOP = "com.teraphonia.breakmonster.STOP"
        private const val ACTION_PREBUFFER_FIRST_QUEUE = "com.teraphonia.breakmonster.PREBUFFER_FIRST_QUEUE"
        @Volatile private var configuredCrossfader = -1f
        @Volatile private var configuredAutoMix = true
        @Volatile private var configuredCrossfadeSeconds = 2

        @Volatile private var activeInstance: BreakPlaybackService? = null
        @Volatile private var pendingStart: StartRequest? = null
        @Volatile private var pendingFirstQueue: Entry? = null
        @Volatile var onSingleTrackCompleted: (() -> Unit)? = null
        @Volatile var onTrackChanged: ((String) -> Unit)? = null
        @Volatile var snapshot: Snapshot = Snapshot()
            private set

        fun start(context: Context, request: StartRequest) {
            pendingStart = request.copy(
                crossfader = configuredCrossfader,
                autoMix = configuredAutoMix,
                crossfadeSeconds = configuredCrossfadeSeconds
            )
            context.startForegroundService(Intent(context, BreakPlaybackService::class.java).setAction(ACTION_START))
        }
        /** Extend a playing single-track session without restarting deck A. */
        fun appendToActivePlaylist(expectedCurrentUri: String, entry: Entry): Boolean {
            val service = activeInstance ?: return false
            if (!snapshot.sessionActive || snapshot.trackUri != expectedCurrentUri) return false
            return service.appendStandbyEntry(entry)
        }
        /** Silent B-deck warm-up for the first manually selected QUEUE entry.
         * No change to the playing playlist, NEXT order or audio focus.
         */
        fun prebufferFirstQueued(context: Context, entry: Entry?) {
            val service = activeInstance
            if (service != null) {
                service.stageFirstQueued(entry)
            } else if (entry != null) {
                pendingFirstQueue = entry
                context.startForegroundService(Intent(context, BreakPlaybackService::class.java).setAction(ACTION_PREBUFFER_FIRST_QUEUE))
            } else {
                // An immediate undo can occur before the new service is created.
                pendingFirstQueue = null
            }
        }
        fun seekTo(value: Int) { activeInstance?.seekInternal(value) }
        fun next() { activeInstance?.nextInternal() }
        fun previous() { activeInstance?.previousInternal() }
        fun togglePause() { activeInstance?.toggleInternal() }
        fun setRandom(value: Boolean) { activeInstance?.setRandomInternal(value) }
        fun setRepeat(value: Boolean) { activeInstance?.setRepeatInternal(value) }
        fun setVolume(value: Float) { activeInstance?.setVolumeInternal(value) }
        fun setMixer(crossfader: Float, autoMix: Boolean, seconds: Int) {
            configuredCrossfader = crossfader.coerceIn(-1f, 1f)
            configuredAutoMix = autoMix
            configuredCrossfadeSeconds = seconds.coerceIn(1, 12)
            activeInstance?.setMixerInternal(crossfader, autoMix, seconds)
        }
        fun stop(context: Context) {
            pendingStart = null
            activeInstance?.stopInternal() ?: context.stopService(Intent(context, BreakPlaybackService::class.java))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val resolverScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var resolverJob: Job? = null
    private var activeSourceJob: Job? = null
    private var playbackGeneration = 0
    private var streamTrack = false
    private var startedAudioAt = 0L
    private var lastAudioFailure: String? = null

    // Deck B is prepared silently while deck A plays. Never shares A's resolver job.
    private var standbyPlayer: MediaPlayer? = null
    private var standbyEntry: Entry? = null
    private var standbyPrepared = false
    private var standbyRecovering = false
    private val standbyRetries = mutableMapOf<String, Int>()
    private var standbyStartedAt = 0L
    private var standbyOrderPosition = -1
    private var stagedFirstQueueUri: String? = null
    private var standbyJob: Job? = null
    private var standbySourceJob: Job? = null
    private var standbyGeneration = 0
    private var player: MediaPlayer? = null
    // Independent of UI snapshot: only onPrepared makes MediaPlayer queryable.
    private var playerPrepared = false
    private var bufferedPercentA = 0
    private var bufferedPercentB = 0
    private var bufferingA = false
    private var bufferingB = false
    private var crossfader = 0f
    private var autoMix = true
    private var crossfadeSeconds = 2
    private var crossfadeStartedAt = 0L
    private var crossfadePausedElapsed = 0L
    private var suppressAutoCrossfadeUntil = 0L
    private var crossfading = false
    private var transitionRequested = false
    private var manualOverlap = false
    private var manualMixRequested = false
    private var manualMixCompletions = 0L
    private var manualFaderAwaitingRelease = false
    private var files: List<Entry> = emptyList()
    private var order: List<Int> = emptyList()
    private var orderPosition = -1
    private var random = false
    private var repeat = false
    private var volume = 1f
    private var current: Entry? = null
    private lateinit var mediaSession: MediaSession

    // Local audio is owned by this foreground service, never by the UI/PiP.
    // Audio focus handles calls and other temporary system interruptions.
    private val audioManager by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    private val musicAudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()
    private var ownsAudioFocus = false
    private var resumeAfterTemporaryFocusLoss = false
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_GAIN -> {
                ownsAudioFocus = true
                if (resumeAfterTemporaryFocusLoss) {
                    resumeAfterTemporaryFocusLoss = false
                    val p = player
                    if (p != null && playerPrepared && !snapshot.preparing && !snapshot.playing && snapshot.sessionActive) {
                        runCatching { p.start() }.onSuccess {
                            if (crossfading) standbyPlayer?.let { runCatching { it.start() } }
                            if (crossfading) crossfadeStartedAt = SystemClock.elapsedRealtime() - crossfadePausedElapsed
                            publish(playing = true)
                            updateNotification()
                        }
                    }
                }
            }
            AudioManager.AUDIOFOCUS_LOSS -> {
                ownsAudioFocus = false
                resumeAfterTemporaryFocusLoss = false
                pauseForAudioInterruption()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                ownsAudioFocus = false
                // Do not duck through a telephone call: pause until focus returns.
                resumeAfterTemporaryFocusLoss = snapshot.playing ||
                    (snapshot.preparing && snapshot.sessionActive)
                pauseForAudioInterruption()
            }
        }
    }
    private val focusRequest by lazy {
        AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(musicAudioAttributes)
            .setOnAudioFocusChangeListener(focusListener, handler)
            .setWillPauseWhenDucked(true)
            .setAcceptsDelayedFocusGain(true)
            .build()
    }

    private fun acquireAudioFocus(): Boolean {
        if (ownsAudioFocus) return true
        return when (audioManager.requestAudioFocus(focusRequest)) {
            AudioManager.AUDIOFOCUS_REQUEST_GRANTED -> {
                ownsAudioFocus = true
                true
            }
            AudioManager.AUDIOFOCUS_REQUEST_DELAYED -> {
                resumeAfterTemporaryFocusLoss = true
                false
            }
            else -> {
                resumeAfterTemporaryFocusLoss = false
                false
            }
        }
    }

    private fun releaseAudioFocus() {
        resumeAfterTemporaryFocusLoss = false
        // Also cancels delayed focus grants queued behind an ongoing call.
        runCatching { audioManager.abandonAudioFocusRequest(focusRequest) }
        ownsAudioFocus = false
    }

    private fun pauseForAudioInterruption() {
        if (snapshot.playing) {
            player?.let { runCatching { it.pause() } }
            if (crossfading) {
                standbyPlayer?.let { runCatching { it.pause() } }
                crossfadePausedElapsed = SystemClock.elapsedRealtime() - crossfadeStartedAt
            }
            publish(playing = false)
            updateNotification()
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            val p = player
            if (p != null && snapshot.sessionActive && playerPrepared) {
                // MediaPlayer is still IDLE while BMQ/NewPipe resolves the URL.
                // Calling getDuration() in IDLE forces MEDIA_ERROR_UNKNOWN (-38).
                // Read BOTH position and duration only after onPrepared has fired.
                val pos = if (snapshot.preparing) snapshot.position else runCatching { p.currentPosition }.getOrDefault(snapshot.position)
                val dur = if (snapshot.preparing) snapshot.duration
                    else if (snapshot.duration > 0) snapshot.duration
                    else runCatching { p.duration }.getOrDefault(0).coerceAtLeast(0)
                publish(position = pos, duration = dur,
                    deckAReady = playerPrepared, deckBReady = standbyPrepared,
                    deckBPreparing = standbyEntry != null && !standbyPrepared,
                    bufferedPercentA = bufferedPercentA, bufferedPercentB = bufferedPercentB,
                    bufferingA = bufferingA, bufferingB = bufferingB,
                    crossfading = crossfading,
                    crossfader = crossfader, autoMix = autoMix, crossfadeSeconds = crossfadeSeconds)
                val decksMixReady = standbyOrderPosition >= 0 && playerPrepared && standbyPrepared &&
                    bufferedPercentA >= MIN_MIX_BUFFER_PERCENT && bufferedPercentB >= MIN_MIX_BUFFER_PERCENT
                if (autoMix && SystemClock.elapsedRealtime() >= suppressAutoCrossfadeUntil &&
                    !crossfading && decksMixReady && snapshot.playing && transitionRequested) {
                    beginCrossfade()
                } else if (autoMix && SystemClock.elapsedRealtime() >= suppressAutoCrossfadeUntil &&
                    !crossfading && decksMixReady && dur > 0 && snapshot.playing) {
                    val remaining = dur - pos
                    if (remaining <= crossfadeSeconds * 1000) beginCrossfade()
                }
                if (crossfading && manualOverlap && snapshot.playing) applyDeckVolumes()
                else if (crossfading && snapshot.playing) updateCrossfade()
                updatePlaybackState()
            }
            handler.postDelayed(this, 250L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        activeInstance = this
        BlackBox.ensureInitialized(applicationContext)
        BlackBox.log("AUDIO SERVICE created")
        createChannel()
        mediaSession = MediaSession(this, "BreakMonster").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() { if (!snapshot.playing) toggleInternal() }
                override fun onPause() { if (snapshot.playing) toggleInternal() }
                override fun onSkipToNext() { nextInternal() }
                override fun onSkipToPrevious() { previousInternal() }
                override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                    return super.onMediaButtonEvent(mediaButtonIntent)
                }
                override fun onStop() { stopInternal() }
                override fun onSeekTo(pos: Long) { seekInternal(pos.toInt()) }
            })
            setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)
            isActive = true
        }
        handler.post(ticker)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PREBUFFER_FIRST_QUEUE -> {
                val entry = pendingFirstQueue
                pendingFirstQueue = null
                if (entry != null) {
                    if (!snapshot.sessionActive) startForeground(NOTIFICATION_ID, buildNotification("QUEUE PREBUFFER", false))
                    stageFirstQueued(entry)
                } else if (!snapshot.sessionActive) {
                    stopSelf()
                }
            }
            ACTION_START -> {
                val request = pendingStart
                pendingStart = null
                if (request == null || request.files.isEmpty()) {
                    stopInternal()
                    return START_NOT_STICKY
                }
                lastAudioFailure = null
                // Explicit playback selection takes ownership of any staged B deck.
                stagedFirstQueueUri = null
                val selectedLabel = request.selectedUri?.substringAfterLast('/') ?: "first"
                BlackBox.log("AUDIO PLAYLIST START count=${request.files.size} selected=$selectedLabel")
                random = request.random
                repeat = request.repeat
                volume = request.volume.coerceIn(0f, 1f)
                crossfader = request.crossfader.coerceIn(-1f, 1f)
                autoMix = request.autoMix
                crossfadeSeconds = request.crossfadeSeconds.coerceIn(1, 12)
                transitionRequested = false
                files = request.files.distinctBy { it.uri }
                BlackBox.log("QUEUE size=${files.size} selectedIndex=${request.selectedUri?.let { wanted -> files.indexOfFirst { it.uri == wanted } } ?: 0}")
                startForeground(NOTIFICATION_ID, buildNotification("BreakMonster", false))
                val selected = request.selectedUri?.let { wanted -> files.indexOfFirst { it.uri == wanted } }?.takeIf { it >= 0 }
                rebuildOrder(selected)
                if (order.isEmpty()) stopInternal() else {
                    val keepCurrent = snapshot.sessionActive && player != null && playerPrepared
                    if (keepCurrent) {
                        val sameTrack = request.selectedUri == current?.uri
                        // rebuildOrder() is based on the new request snapshot. When the
                        // active item is kept, it is always at snapshot position zero;
                        // retaining the old position makes NEXT point past the new list.
                        orderPosition = if (sameTrack) 0 else orderPosition
                        transitionRequested = !sameTrack
                        publish(random = random, repeat = repeat, sessionActive = true, preparing = false, playing = snapshot.playing)
                        BlackBox.log("AUDIO QUEUE REPLACED count=${files.size} selectedIndex=${selected ?: 0} keepActive=true sameTrack=$sameTrack")
                        if (sameTrack) preloadNextDeck() else preloadNextDeck(0)
                    } else {
                        crossfading = false
                        publish(random = random, repeat = repeat, sessionActive = true, preparing = true)
                        orderPosition = 0
                        BlackBox.log("AUDIO SESSION CREATE queue=${files.size}")
                        playIndex(order[0])
                    }
                }
            }
            ACTION_TOGGLE -> toggleInternal()
            ACTION_NEXT -> nextInternal()
            ACTION_PREVIOUS -> previousInternal()
            ACTION_STOP -> stopInternal()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun rebuildOrder(firstIndex: Int? = null) {
        val all = files.indices.toList()
        if (all.isEmpty()) {
            order = emptyList(); orderPosition = -1; return
        }
        val first = firstIndex?.takeIf { it in all }
        val rest = if (first == null) all else all.filter { it != first }
        val previousFileIndex = current?.let { now -> files.indexOfFirst { it.uri == now.uri } } ?: -1
        val orderedRest = if (random) {
            val shuffled = rest.shuffled().toMutableList()
            if (first == null && shuffled.size > 1 && shuffled.first() == previousFileIndex) {
                val swap = shuffled.indexOfFirst { it != previousFileIndex }
                if (swap > 0) java.util.Collections.swap(shuffled, 0, swap)
            }
            shuffled
        } else rest
        order = if (first == null) { if (random) all.shuffled() else all } else listOf(first) + orderedRest
        orderPosition = if (order.isEmpty()) -1 else 0
    }

    private fun playIndex(index: Int) {
        val entry = files.getOrNull(index) ?: return
        if (standbyEntry?.uri == entry.uri && standbyPrepared && standbyPlayer != null) {
            val ready = standbyPlayer!!
            val oldActive = player
            playbackGeneration++
            resolverJob?.cancel(); resolverJob = null
            activeSourceJob?.cancel(); activeSourceJob = null
            standbyPlayer = oldActive
            standbyEntry = null; standbyPrepared = false; standbyStartedAt = 0L
            stagedFirstQueueUri = null
            if (oldActive != null) {
                runCatching { oldActive.stop() }
                runCatching { oldActive.reset() }
            }
            player = ready; playerPrepared = true; current = entry
            onTrackChanged?.invoke(entry.uri)
            streamTrack = isStream(entry)
            val duration = runCatching { ready.duration }.getOrDefault(0).coerceAtLeast(0)
            publish(trackUri = entry.uri, trackName = entry.name, preparing = false,
                playing = false, position = 0, duration = duration, sessionActive = true, deckAReady = true,
                deckBReady = false, deckBPreparing = false)
            if (acquireAudioFocus()) {
                runCatching { ready.start() }.onSuccess {
                    startedAudioAt = SystemClock.elapsedRealtime()
                    standbyStartedAt = 0L
                    crossfading = false; manualOverlap = false
                    crossfader = -1f; configuredCrossfader = -1f
                    BlackBox.log("PLAYER ROLE SWAP A=${entry.name} mode=NEXT audioSessionPreserved=true")
                    publish(playing = true, crossfading = false, crossfader = -1f, deckAReady = true,
                        deckBReady = false, deckBPreparing = false)
                    bufferedPercentA = bufferedPercentB
                    bufferedPercentB = 0
                    preloadNextDeck()
                }.onFailure { failCurrent(ready, "Deck B promotion", it) }
            }
            updateNotification()
            return
        }
        releasePlayer()
        current = entry
        onTrackChanged?.invoke(entry.uri)
        lastAudioFailure = null
        val sourceUri = Uri.parse(entry.uri)
        streamTrack = entry.uri.startsWith("https://www.youtube.com/watch?v=") ||
            sourceUri.path.orEmpty().endsWith(".bmq", ignoreCase = true) ||
            sourceUri.path.orEmpty().endsWith(".yt", ignoreCase = true)
        startedAudioAt = 0L
        bufferedPercentA = 0
        bufferingA = false
        BlackBox.log("AUDIO TRACK START ${orderPosition + 1}/${order.size} name=${entry.name} kind=${if (streamTrack) "BMQ" else "LOCAL"}")
        publish(trackUri = entry.uri, trackName = entry.name, preparing = true,
            playing = false, position = 0, duration = 0, sessionActive = true,
            deckAReady = false, deckBReady = false, deckBPreparing = false, crossfading = false)
        updateNotification()

        if (!streamTrack) {
            prepareResolvedSource(entry, null)
            return
        }

        // IMPORTANT: Do not even create a MediaPlayer in the IDLE state while
        // NewPipe is still looking for the stream URL. This prevents state
        // queries or callbacks from sending commands to an unloaded player.
        val generation = playbackGeneration
        val resolveStarted = SystemClock.elapsedRealtime()
        BlackBox.log("BMQ RESOLVE BEGIN track=${entry.name} deck=A")
        val resolvingWakeLock = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "BrakeMonsterPro:audioResolve")
        runCatching { resolvingWakeLock.acquire(60_000L) }
        resolverJob = resolverScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        val id = if (entry.uri.startsWith("https://www.youtube.com/watch?v="))
                            BmqCodec.extractId(entry.uri) ?: error("Invalid YouTube video ID")
                        else BmqCodec.readReference(applicationContext, Uri.parse(entry.uri))
                        ProStreamResolver.resolveAudio(id)
                    }
                }
                // A manual NEXT/STOP can happen during network extraction.
                if (generation != playbackGeneration || current?.uri != entry.uri || !snapshot.sessionActive)
                    return@launch
                result.fold(
                    onSuccess = { url ->
                        BlackBox.log("BMQ RESOLVE DURATION track=${entry.name} durationMs=${SystemClock.elapsedRealtime() - resolveStarted} deck=A")
                        BlackBox.log("BMQ RESOLVE OK track=${entry.name} · creating MediaPlayer")
                        prepareResolvedSource(entry, url)
                    },
                    onFailure = { error ->
                        failEntry(entry, "BMQ NewPipe resolve", error)
                    }
                )
            } finally {
                runCatching { if (resolvingWakeLock.isHeld) resolvingWakeLock.release() }
            }
        }
    }

    /** Called on the service main thread ONLY after the BMQ URL has been
     * resolved. The player is not queried until its onPrepared callback.
     */
    private fun prepareResolvedSource(entry: Entry, streamUrl: String?, standby: Boolean = false, reusable: MediaPlayer? = null) {
        if (!snapshot.sessionActive && !(standby && stagedFirstQueueUri == entry.uri)) return
        if (!standby && current?.uri != entry.uri) return
        if (standby && standbyEntry?.uri != entry.uri) return
        val p = reusable ?: MediaPlayer()
        val deckName = if (standby) "B" else "A"
        val prepareStartedAt = SystemClock.elapsedRealtime()
        val standbyLoadToken = standbyGeneration
        val activeLoadToken = playbackGeneration
        BlackBox.log("AUDIO PLAYER CREATE deck=$deckName audioSessionId=${runCatching { p.audioSessionId }.getOrDefault(-1)} reused=${reusable != null}")
        if (standby) standbyPlayer = p else {
            playerPrepared = false
            player = p
        }
        try {
            if (reusable != null) reusable.reset()
            p.setAudioAttributes(musicAudioAttributes)
            p.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            p.setVolume(volume, volume)
            p.setOnPreparedListener {
                val callbackIsCurrent = if (standby)
                    standbyPlayer === p && standbyEntry?.uri == entry.uri && standbyGeneration == standbyLoadToken
                else player === p && current?.uri == entry.uri && playbackGeneration == activeLoadToken
                if (callbackIsCurrent) {
                    if (player === p) playerPrepared = true
                    val duration = runCatching { p.duration }.getOrDefault(0).coerceAtLeast(0)
                    BlackBox.log("AUDIO PREPARED track=${entry.name} durationMs=$duration")
                    BlackBox.log("BUFFER PREPARATION DURATION track=${entry.name} durationMs=${SystemClock.elapsedRealtime() - prepareStartedAt} deck=$deckName")
                    if (p === standbyPlayer) {
                        standbyPrepared = true
                        standbyRecovering = false
                        standbyRetries.remove(entry.uri)
                        if (!isStream(entry)) bufferedPercentB = 100
                        bufferingB = false
                        BlackBox.log("DECK B READY track=${entry.name} durationMs=$duration")
                        publish(deckBReady = true, deckBPreparing = false, deckBRecovering = false, bufferedPercentB = bufferedPercentB, bufferingB = false)
                        if (manualMixRequested && !autoMix) tryStartManualMix("standby_ready_callback")
                        applyDeckVolumes()
                        if (transitionRequested) {
                            val outgoingPlaying = runCatching { player?.isPlaying == true }.getOrDefault(false)
                            if (outgoingPlaying) beginCrossfade() else {
                                BlackBox.log("QUEUE WAIT ENDED BEFORE READY target=${entry.name}; starting ready deck without crossfade")
                                runCatching { p.setVolume(volume, volume); p.start() }
                                    .onSuccess { standbyStartedAt = SystemClock.elapsedRealtime(); promoteStandby() }
                                    .onFailure { failEntry(entry, "standby start after outgoing completion", it) }
                            }
                        }
                        return@setOnPreparedListener
                    }
                    if (!isStream(entry)) bufferedPercentA = 100
                    bufferingA = false
                    val mayPlay = acquireAudioFocus()
                    if (mayPlay) {
                        runCatching { p.start() }.onSuccess {
                            resumeAfterTemporaryFocusLoss = false
                            startedAudioAt = SystemClock.elapsedRealtime()
                            lastAudioFailure = null
                            BlackBox.log("AUDIO PLAYING track=${entry.name} durationMs=$duration")
                            publish(preparing = false, playing = true, duration = duration, deckAReady = true, bufferedPercentA = bufferedPercentA, bufferingA = false)
                            applyDeckVolumes()
                            preloadNextDeck()
                        }.onFailure { error ->
                            failCurrent(p, "MediaPlayer.start", error)
                        }
                    } else {
                        BlackBox.log("AUDIO PREPARED waiting for audio focus track=${entry.name}")
                        publish(preparing = false, playing = false, duration = duration)
                    }
                    updateNotification()
                }
            }
            p.setOnCompletionListener {
                if (player === p && current?.uri == entry.uri) {
                    if (streamTrack && (startedAudioAt == 0L ||
                            SystemClock.elapsedRealtime() - startedAudioAt < 2500L)) {
                        failCurrent(p, "premature MediaPlayer completion (less than 2.5s)")
                        return@setOnCompletionListener
                    }
                    BlackBox.log("TRACK COMPLETION track=${entry.name} crossfading=$crossfading")
                    if (crossfading) return@setOnCompletionListener
                    if (transitionRequested) {
                        publish(preparing = true, playing = false, position = snapshot.duration)
                        if (standbyPrepared) {
                            BlackBox.log("QUEUE REQUESTED TARGET READY AFTER OUTGOING END track=${standbyEntry?.name}")
                            standbyPlayer?.let { next ->
                                runCatching { next.setVolume(volume, volume); next.start() }
                                    .onSuccess { standbyStartedAt = SystemClock.elapsedRealtime(); promoteStandby() }
                                    .onFailure { failEntry(standbyEntry ?: entry, "standby start after completion", it) }
                            }
                        } else BlackBox.log("QUEUE WAITING FOR REQUESTED DECK READY track=${standbyEntry?.name}")
                        return@setOnCompletionListener
                    }
                    val expectedNextPosition = if (orderPosition + 1 in order.indices) orderPosition + 1 else if (repeat) 0 else -1
                    if (standbyPrepared && standbyOrderPosition == expectedNextPosition) {
                        BlackBox.log("QUEUE READY DECK PROMOTION track=${standbyEntry?.name} reason=completion")
                        promoteStandby()
                        return@setOnCompletionListener
                    }
                    if (expectedNextPosition in order.indices) {
                        // Keep the completed active deck and any valid standby load in
                        // place until the real NEXT is ready. Advancing directly here
                        // used to tear down the in-flight standby buffer and restart
                        // the next track on deck A, producing a gap and skipping mix.
                        transitionRequested = true
                        publish(preparing = true, playing = false, position = snapshot.duration)
                        if (standbyOrderPosition != expectedNextPosition || standbyEntry?.uri != files.getOrNull(order[expectedNextPosition])?.uri) {
                            preloadNextDeck(expectedNextPosition)
                        }
                        BlackBox.log("QUEUE WAITING FOR NEXT DECK READY position=$expectedNextPosition track=${standbyEntry?.name}")
                        return@setOnCompletionListener
                    }
                    releasePlayer(clearB = false)
                    publish(preparing = false, playing = false, position = snapshot.duration)
                    if (files.size == 1 && !repeat) {
                        BlackBox.log("QUEUE SERVICE FINISHED count=1")
                        publish(trackUri = null, trackName = null, position = 0, duration = 0, sessionActive = true)
                        onSingleTrackCompleted?.invoke()
                        stopInternal()
                    } else {
                        BlackBox.log("QUEUE SERVICE ADVANCE ${orderPosition + 1}/${order.size}")
                        advanceInternal()
                    }
                }
            }
            p.setOnErrorListener { _, what, extra ->
                if (standby && standbyPlayer === p && standbyEntry?.uri == entry.uri && standbyGeneration == standbyLoadToken) {
                    BlackBox.log("DECK B ERROR what=$what extra=$extra track=${entry.name}")
                    recoverStandby(entry, standbyOrderPosition, "media_error")
                } else if (!standby && player === p && current?.uri == entry.uri && playbackGeneration == activeLoadToken) {
                    failCurrent(p, "MediaPlayer error what=$what extra=$extra whilePreparing=${snapshot.preparing}")
                }
                true
            }
            p.setOnInfoListener { _, what, _ ->
                val currentLoad = if (standby) standbyPlayer === p && standbyEntry?.uri == entry.uri && standbyGeneration == standbyLoadToken
                    else player === p && current?.uri == entry.uri && playbackGeneration == activeLoadToken
                if (!currentLoad) return@setOnInfoListener true
                when (what) {
                    MediaPlayer.MEDIA_INFO_BUFFERING_START -> {
                        if (standby) bufferingB = true else bufferingA = true
                        BlackBox.log("AUDIO BUFFERING START track=${entry.name} deck=$deckName")
                        publish(bufferingA = bufferingA, bufferingB = bufferingB)
                    }
                    MediaPlayer.MEDIA_INFO_BUFFERING_END -> {
                        if (standby) bufferingB = false else bufferingA = false
                        BlackBox.log("AUDIO BUFFERING END track=${entry.name} deck=$deckName")
                        publish(bufferingA = bufferingA, bufferingB = bufferingB)
                    }
                }
                true
            }
            p.setOnBufferingUpdateListener { _, percent ->
                val currentLoad = if (standby) standbyPlayer === p && standbyEntry?.uri == entry.uri && standbyGeneration == standbyLoadToken
                    else player === p && current?.uri == entry.uri && playbackGeneration == activeLoadToken
                if (!currentLoad) return@setOnBufferingUpdateListener
                val value = percent.coerceIn(0, 100)
                if (standby) bufferedPercentB = value else bufferedPercentA = value
                publish(bufferedPercentA = bufferedPercentA, bufferedPercentB = bufferedPercentB)
                BlackBox.log("AUDIO BUFFER PROGRESS deck=$deckName track=${entry.name} percent=$value")
                if (autoMix && transitionRequested && snapshot.playing && !crossfading && playerPrepared && standbyPrepared &&
                    bufferedPercentA >= MIN_MIX_BUFFER_PERCENT && bufferedPercentB >= MIN_MIX_BUFFER_PERCENT) beginCrossfade()
                else if (!autoMix && manualMixRequested && !crossfading && playerPrepared && standbyPrepared &&
                    bufferedPercentA >= MANUAL_MIX_BUFFER_PERCENT && bufferedPercentB >= MANUAL_MIX_BUFFER_PERCENT) tryStartManualMix("both_decks_buffer_ready")
            }
            val generation = playbackGeneration
            val standbyToken = standbyGeneration
            val sourceSetup = resolverScope.launch {
                try {
                    val configured = withContext(Dispatchers.IO) {
                        runCatching {
                            if (streamUrl != null) {
                                BlackBox.log("AUDIO STREAM DATASOURCE track=${entry.name} deck=$deckName")
                                p.setDataSource(applicationContext, Uri.parse(streamUrl), mapOf(
                                    "User-Agent" to "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/130.0 Mobile Safari/537.36",
                                    "Referer" to "https://www.youtube.com/"
                                ))
                            } else {
                                val mediaUri = Uri.parse(entry.uri)
                                val afd = runCatching { contentResolver.openAssetFileDescriptor(mediaUri, "r") }.getOrNull()
                                if (afd != null) {
                                    afd.use { descriptor ->
                                        if (descriptor.declaredLength >= 0L)
                                            p.setDataSource(descriptor.fileDescriptor, descriptor.startOffset, descriptor.declaredLength)
                                        else p.setDataSource(descriptor.fileDescriptor)
                                    }
                                } else p.setDataSource(applicationContext, mediaUri)
                            }
                        }
                    }
                    if (!snapshot.sessionActive || (standby && (standbyToken != standbyGeneration || standbyPlayer !== p || standbyEntry?.uri != entry.uri)) ||
                        (!standby && (generation != playbackGeneration || player !== p || current?.uri != entry.uri))) {
                        runCatching { p.release() }
                        return@launch
                    }
                    configured.fold(
                        onSuccess = {
                            try {
                                p.prepareAsync()
                                BlackBox.log("AUDIO PREPARE_ASYNC track=${entry.name} deck=$deckName · waiting for buffer")
                            } catch (error: Exception) {
                                if (standby) recoverStandby(entry, standbyOrderPosition, "prepare") else failCurrent(p, if (streamUrl != null) "BMQ MediaPlayer prepare" else "local MediaPlayer prepare", error)
                            }
                        },
                        onFailure = { error ->
                            if (standby) {
                                BlackBox.log("DECK B DATASOURCE FAILED track=${entry.name} ${error.javaClass.simpleName}")
                                recoverStandby(entry, standbyOrderPosition, "datasource")
                            } else failCurrent(p, if (streamUrl != null) "BMQ MediaPlayer datasource" else "local MediaPlayer datasource", error)
                        }
                    )
                } catch (cancelled: CancellationException) {
                    if (player !== p && standbyPlayer !== p) runCatching { p.release() }
                    throw cancelled
                }
            }
            if (standby) standbySourceJob = sourceSetup else activeSourceJob = sourceSetup
        } catch (error: Exception) {
            if (standby) {
                BlackBox.log("DECK B PREPARE FAILED track=${entry.name} ${error.javaClass.simpleName}")
                recoverStandby(entry, standbyOrderPosition, "setup")
            } else failCurrent(p, if (streamUrl != null) "BMQ MediaPlayer prepare" else "local MediaPlayer prepare", error)
        }
    }

    /** Halt on the FIRST error instead of racing through the entire playlist.
     * Manual NEXT still works so users can test a different recording.
     */
    private fun failCurrent(p: MediaPlayer, stage: String, error: Throwable? = null) {
        if (player !== p) return
        val failed = current ?: return
        failEntry(failed, stage, error)
    }

    private fun failEntry(entry: Entry, stage: String, error: Throwable? = null) {
        if (current?.uri != entry.uri || !snapshot.sessionActive) return
        lastAudioFailure = stage
        BlackBox.audioFailure(stage, entry.name, error)
        BlackBox.log("PLAYBACK FAILURE track=${entry.name} stage=$stage recovery=${files.size > 1}")
        releasePlayer()
        publish(preparing = false, playing = false, deckAReady = false, deckBReady = false, deckBPreparing = false)
        updateNotification()
        if (files.size > 1) handler.post { advanceInternal() } else handler.post { stopInternal() }
    }

    private fun advanceInternal() {
        if (files.isEmpty()) { stopInternal(); return }
        val next = orderPosition + 1
        if (next in order.indices) {
            orderPosition = next
            playIndex(order[next])
            return
        }
        if (repeat) {
            rebuildOrder()
            if (order.isNotEmpty()) {
                orderPosition = 0
                playIndex(order[0])
            } else stopInternal()
        } else {
            BlackBox.log("QUEUE SERVICE FINISHED count=${files.size}")
            onSingleTrackCompleted?.invoke()
            stopInternal()
        }
    }

    private fun isStream(entry: Entry): Boolean {
        val u = Uri.parse(entry.uri)
        return entry.uri.startsWith("https://www.youtube.com/watch?v=") ||
            u.path.orEmpty().endsWith(".bmq", true) || u.path.orEmpty().endsWith(".yt", true)
    }

    private fun clearStandby() {
        if (crossfading) {
            BlackBox.log("CROSSFADE CANCEL reason=standby_cleared current=${current?.name} target=${standbyEntry?.name}")
            crossfading = false
            manualOverlap = false
            crossfader = -1f
            runCatching { player?.setVolume(volume, volume) }
            publish(crossfading = false, crossfader = -1f)
        }
        standbyGeneration++
        standbyJob?.cancel(); standbyJob = null
        val setupInFlight = standbySourceJob?.isActive == true
        standbySourceJob?.cancel(); standbySourceJob = null
        val old = standbyPlayer
        if (manualMixRequested) BlackBox.log("MANUAL MIX REQUEST FAILED reason=standby_cancelled_or_failed")
        standbyPlayer = null; standbyEntry = null; standbyPrepared = false; standbyStartedAt = 0L
        standbyRecovering = false
        manualMixRequested = false
        if (old != null) {
            val sessionId = if (setupInFlight) -1 else runCatching { old.audioSessionId }.getOrDefault(-1)
            BlackBox.log("AUDIO PLAYER DESTROY deck=B audioSessionId=$sessionId deferred=$setupInFlight")
            if (!setupInFlight) runCatching { old.release() }
        }
        bufferedPercentB = 0
        bufferingB = false
        publish(deckBReady = false, deckBPreparing = false, deckBRecovering = false, bufferedPercentB = 0, bufferingB = false)
    }

    /** Retry a failed NEXT twice, keeping the target visible as recovery state. */
    private fun recoverStandby(entry: Entry, position: Int, reason: String) {
        val retry = standbyRetries[entry.uri] ?: 0
        val wasStaged = position == -1 && stagedFirstQueueUri == entry.uri
        clearStandby()
        standbyEntry = entry
        standbyOrderPosition = position
        standbyRecovering = true
        bufferingB = false
        bufferedPercentB = 0
        publish(deckBReady = false, deckBPreparing = false, deckBRecovering = true,
            bufferingB = false, bufferedPercentB = 0, standbyUri = entry.uri)
        if (retry >= 2) {
            BlackBox.log("DECK B ERROR RECOVERY EXHAUSTED track=${entry.name} reason=$reason")
            return
        }
        standbyRetries[entry.uri] = retry + 1
        val token = standbyGeneration
        BlackBox.log("DECK B RETRY scheduled=${retry + 1}/2 track=${entry.name} reason=$reason")
        handler.postDelayed({
            if (token == standbyGeneration && (snapshot.sessionActive || wasStaged) &&
                (!wasStaged || stagedFirstQueueUri == entry.uri) &&
                standbyEntry?.uri == entry.uri && current?.uri != entry.uri) {
                standbyRecovering = false
                if (wasStaged) preloadNextDeck(previewEntry = entry) else preloadNextDeck(position)
            }
        }, 700L)
    }

    private fun appendStandbyEntry(entry: Entry): Boolean {
        if (!snapshot.sessionActive || current?.uri != snapshot.trackUri || player == null) return false
        if (files.any { it.uri == entry.uri }) return false
        files = files + entry
        // The new entry is next in the existing playback order, not a new session.
        val index = files.lastIndex
        order = order + index
        BlackBox.log("DECK B DYNAMIC PLAYLIST ADD track=${entry.name} index=$index")
        if (!crossfading) preloadNextDeck()
        return true
    }

    /** Reserve B for the selected QUEUE first track without joining active playback. */
    private fun stageFirstQueued(entry: Entry?) {
        handler.post {
            if (entry == null) {
                if (stagedFirstQueueUri != null) {
                    val oldUri = stagedFirstQueueUri
                    stagedFirstQueueUri = null
                    if (standbyOrderPosition == -1 && standbyEntry?.uri == oldUri) clearStandby()
                    if (!snapshot.sessionActive) stopInternal()
                }
                return@post
            }
            if (entry.uri == current?.uri) {
                // The first QUEUE track is already on deck A.
                if (stagedFirstQueueUri != null) {
                    stagedFirstQueueUri = null
                    if (standbyOrderPosition == -1) clearStandby()
                }
                return@post
            }
            // Never interrupt an in-flight transition or replace the normal
            // next song of an active, multi-track playlist.
            if (crossfading || transitionRequested || nextOrderPosition() >= 0) {
                BlackBox.log("QUEUE FIRST PREBUFFER deferred active next or transition track=${entry.name}")
                return@post
            }
            if (standbyEntry?.uri == entry.uri && standbyOrderPosition == -1 &&
                (standbyPrepared || standbyJob?.isActive == true || standbySourceJob?.isActive == true || standbyPlayer != null)) return@post
            stagedFirstQueueUri = entry.uri
            BlackBox.log("QUEUE FIRST PREBUFFER requested deck=B track=${entry.name} playbackUntouched=true")
            preloadNextDeck(previewEntry = entry)
        }
    }

    private fun nextOrderPosition(): Int =
        if (orderPosition + 1 in order.indices) orderPosition + 1 else if (repeat && order.isNotEmpty()) 0 else -1

    private fun preloadNextDeck(targetOrderPosition: Int? = null, previewEntry: Entry? = null) {
        val nextPosition = if (previewEntry != null) -1 else targetOrderPosition ?: nextOrderPosition()
        val nextIndex = if (nextPosition >= 0) order.getOrNull(nextPosition) else null
        val entry = previewEntry ?: nextIndex?.let { files.getOrNull(it) }
        // The usual active-deck onPrepared() call must not erase an independent
        // staged QUEUE buffer when the playing playlist has no NEXT track.
        if (entry == null && previewEntry == null && stagedFirstQueueUri != null &&
            standbyOrderPosition == -1 && standbyEntry?.uri == stagedFirstQueueUri) return
        if (entry != null && standbyEntry?.uri == entry.uri &&
            (standbyPrepared || standbyJob?.isActive == true || standbySourceJob?.isActive == true || standbyPlayer != null)) {
            standbyOrderPosition = nextPosition
            if (previewEntry == null && stagedFirstQueueUri == entry.uri) stagedFirstQueueUri = null
            BlackBox.log("DECK B PRELOAD PRESERVED track=${entry.name} ready=$standbyPrepared")
            return
        }
        if (crossfading) {
            BlackBox.log("CROSSFADE CANCEL reason=next_changed current=${current?.name} target=${standbyEntry?.name}")
            crossfading = false
            manualOverlap = false
            crossfader = -1f
            runCatching { player?.setVolume(volume, volume) }
            publish(crossfading = false, crossfader = -1f)
        }
        standbyGeneration++
        standbyJob?.cancel(); standbyJob = null
        val setupInFlight = standbySourceJob?.isActive == true
        standbySourceJob?.cancel(); standbySourceJob = null
        if (setupInFlight) {
            standbyPlayer = null
            BlackBox.log("DECK B SOURCE SETUP CANCELLED; release deferred")
        } else if (standbyPlayer != null) {
            runCatching { standbyPlayer?.stop() }
        }
        standbyEntry = null
        standbyPrepared = false
        standbyRecovering = false
        standbyStartedAt = 0L
        if (manualMixRequested) BlackBox.log("MANUAL MIX REQUEST CANCELLED reason=standby_replaced")
        manualMixRequested = !autoMix && crossfader > -0.999f
        standbyOrderPosition = -1
        bufferingB = false
        bufferedPercentB = 0
        if (entry == null) {
            publish(deckBReady = false, deckBPreparing = false, deckBRecovering = false,
                bufferedPercentB = 0, bufferingB = false, standbyUri = null)
            return
        }
        standbyOrderPosition = nextPosition
        if (previewEntry == null) stagedFirstQueueUri = null
        standbyEntry = entry
        val token = standbyGeneration
        BlackBox.log("DECK B PRELOAD BEGIN index=${nextIndex} track=${entry.name}")
        publish(deckBReady = false, deckBPreparing = true, deckBRecovering = false,
            bufferedPercentB = 0, bufferingB = false, standbyUri = entry.uri)
        if (!isStream(entry)) {
            prepareResolvedSource(entry, null, standby = true, reusable = standbyPlayer)
            return
        }
        val resolveStarted = SystemClock.elapsedRealtime()
        standbyJob = resolverScope.launch {
            val resolved = withContext(Dispatchers.IO) {
                runCatching {
                    val id = if (entry.uri.startsWith("https://www.youtube.com/watch?v="))
                        BmqCodec.extractId(entry.uri) ?: error("Invalid YouTube ID")
                    else BmqCodec.readReference(applicationContext, Uri.parse(entry.uri))
                    ProStreamResolver.resolveAudio(id)
                }
            }
            if (token != standbyGeneration || standbyEntry?.uri != entry.uri) return@launch
            BlackBox.log("BMQ RESOLVE DURATION track=${entry.name} durationMs=${SystemClock.elapsedRealtime() - resolveStarted} deck=B")
            resolved.onSuccess { prepareResolvedSource(entry, it, standby = true, reusable = standbyPlayer) }
                .onFailure {
                    BlackBox.log("DECK B RESOLVE FAILED track=${entry.name} ${it.javaClass.simpleName}; active deck continues")
                    if (manualMixRequested) BlackBox.log("MANUAL MIX REQUEST FAILED reason=standby_source_resolution_failed track=${entry.name}")
                    // Keep A playing; clear the failed B load and let queue advance at completion.
                    recoverStandby(entry, standbyOrderPosition, "resolve")
                }
        }
    }

    private fun beginCrossfade() {
        val next = standbyPlayer ?: return
        val entry = standbyEntry ?: return
        if (!standbyPrepared || bufferedPercentA < MIN_MIX_BUFFER_PERCENT || bufferedPercentB < MIN_MIX_BUFFER_PERCENT || crossfading || player == null) return
        try {
            next.setVolume(0f, 0f)
            next.start()
            standbyStartedAt = SystemClock.elapsedRealtime()
            crossfading = true
            crossfadeStartedAt = SystemClock.elapsedRealtime()
            crossfadePausedElapsed = 0L
            BlackBox.log("CROSSFade START from=${current?.name} to=${entry.name} seconds=$crossfadeSeconds mode=${if (transitionRequested) "requested" else "auto"}")
            publish(crossfading = true)
        } catch (error: Throwable) {
            BlackBox.audioFailure("crossfade standby start", entry.name, error)
            BlackBox.log("CROSSFade START FAILED track=${entry.name}; continue A")
            recoverStandby(entry, standbyOrderPosition, "crossfade_start")
        }
    }

    private fun updateCrossfade() {
        val durationMs = crossfadeSeconds * 1000L
        val fraction = ((SystemClock.elapsedRealtime() - crossfadeStartedAt).toFloat() / durationMs).coerceIn(0f, 1f)
        val oldGain = kotlin.math.cos(fraction * (Math.PI / 2.0)).toFloat()
        val newGain = kotlin.math.sin(fraction * (Math.PI / 2.0)).toFloat()
        player?.let { runCatching { it.setVolume(volume * oldGain, volume * oldGain) } }
        standbyPlayer?.let { runCatching { it.setVolume(volume * newGain, volume * newGain) } }
        crossfader = (fraction * 2f - 1f).coerceIn(-1f, 1f)
        publish(crossfader = crossfader)
        if (fraction >= 1f) {
            BlackBox.log("CROSSFade END from=${current?.name} to=${standbyEntry?.name}")
            promoteStandby()
        }
    }

    private fun promoteStandby() {
        val promoted = standbyPlayer ?: return
        val entry = standbyEntry ?: return
        val completedManualMix = manualOverlap && !autoMix
        val wasAlreadyPlaying = runCatching { promoted.isPlaying }.getOrDefault(false)
        val promotedStartedAt = standbyStartedAt
        val promotedBufferedPercent = bufferedPercentB
        val promotedBuffering = bufferingB
        val oldActive = player
        val nextOrderPosition = standbyOrderPosition
        if (oldActive != null) {
            runCatching { oldActive.stop() }
            runCatching { oldActive.reset() }
        }
        player = promoted
        playerPrepared = true
        standbyPlayer = oldActive
        standbyEntry = null
        standbyPrepared = false
        standbyStartedAt = 0L
        manualMixRequested = false
        bufferingB = false
        standbyOrderPosition = -1
        current = entry
        streamTrack = isStream(entry)
        orderPosition = nextOrderPosition.takeIf { it in order.indices } ?: (orderPosition + 1)
        transitionRequested = false
        crossfading = false
        bufferingA = promotedBuffering
        bufferedPercentA = promotedBufferedPercent
        bufferingB = false
        manualOverlap = false
        crossfader = -1f
        configuredCrossfader = -1f
        if (completedManualMix) manualMixCompletions++
        if (completedManualMix) manualFaderAwaitingRelease = true
        bufferedPercentA = bufferedPercentB
        bufferedPercentB = 0
        if (!wasAlreadyPlaying) {
            runCatching { promoted.setVolume(volume, volume); promoted.start() }
                .onFailure { failCurrent(promoted, "standby promotion start", it); return }
        }
        startedAudioAt = if (wasAlreadyPlaying && promotedStartedAt > 0L) promotedStartedAt else SystemClock.elapsedRealtime()
        onTrackChanged?.invoke(entry.uri)
        val duration = runCatching { promoted.duration }.getOrDefault(0).coerceAtLeast(0)
        val position = runCatching { promoted.currentPosition }.getOrDefault(0).coerceAtLeast(0)
        BlackBox.log("PLAYER ROLE SWAP A=${entry.name} queueIndex=${orderPosition} sessionPreserved=true")
        publish(trackUri = entry.uri, trackName = entry.name, preparing = false, playing = true,
            position = position, duration = duration, deckAReady = true, deckBReady = false, deckBPreparing = false,
            crossfading = false, crossfader = -1f, manualMixCompletions = manualMixCompletions,
            bufferedPercentA = bufferedPercentA, bufferedPercentB = 0,
            bufferingA = bufferingA, bufferingB = false)
        applyDeckVolumes()
        // The old A instance becomes the next standby deck after reset.
        preloadNextDeck()
        updateNotification()
    }

    private fun standbyActuallyReady(): Boolean {
        val p = standbyPlayer ?: return false
        val entry = standbyEntry ?: return false
        return standbyPrepared && bufferedPercentB >= MIN_MIX_BUFFER_PERCENT && standbyOrderPosition >= 0 && !snapshot.deckBPreparing &&
            runCatching { p.duration >= 0 }.getOrDefault(false) && standbyEntry?.uri == entry.uri
    }

    private fun tryStartManualMix(reason: String): Boolean {
        if (autoMix) {
            BlackBox.log("MANUAL MIX REQUEST REJECTED reason=automatic_mode reasonAt=$reason")
            return false
        }
        if (crossfading && manualOverlap) return true
        val active = player
        val standby = standbyPlayer
        val entry = standbyEntry
        val failure = when {
            active == null -> "active_deck_missing"
            !playerPrepared -> "active_deck_not_prepared"
            bufferedPercentA < MANUAL_MIX_BUFFER_PERCENT -> "active_deck_buffer_below_${MANUAL_MIX_BUFFER_PERCENT}pct"
            bufferedPercentB < MANUAL_MIX_BUFFER_PERCENT -> "standby_deck_buffer_below_${MANUAL_MIX_BUFFER_PERCENT}pct"
            !runCatching { active.isPlaying }.getOrDefault(false) -> "active_deck_not_playing"
            entry == null -> "standby_track_missing"
            standby == null -> "standby_player_missing"
            standbyOrderPosition < 0 -> "standby_queue_position_invalid"
            !standbyPrepared -> "standby_onPrepared_not_received"
            snapshot.deckBPreparing -> "standby_snapshot_still_preparing"
            !runCatching { standby.duration >= 0 }.getOrDefault(false) -> "standby_player_not_queryable"
            else -> null
        }
        if (failure != null) {
            BlackBox.log("MANUAL MIX REQUEST WAIT reason=$failure detail=$reason track=${entry?.name ?: "unknown"} deckBReady=$standbyPrepared bufferingB=$bufferingB")
            return false
        }
        val readyStandby = standby ?: return false
        try {
            if (!runCatching { readyStandby.isPlaying }.getOrDefault(false)) {
                readyStandby.setVolume(0f, 0f)
                readyStandby.start()
            }
            standbyStartedAt = SystemClock.elapsedRealtime()
            manualOverlap = true
            manualMixRequested = true
            crossfading = true
            crossfadeStartedAt = SystemClock.elapsedRealtime()
            crossfadePausedElapsed = 0L
            BlackBox.log("MANUAL MIX START from=${current?.name} to=${entry?.name} reason=$reason deckBActuallyReady=true")
            publish(crossfading = true)
            return true
        } catch (error: Throwable) {
            BlackBox.audioFailure("manual mix start", entry?.name, error)
            BlackBox.log("MANUAL MIX REQUEST FAILED reason=standby_start_exception detail=${error.javaClass.simpleName}:${error.message}")
            return false
        }
    }

    private fun applyDeckVolumes() {
        if (crossfading && !manualOverlap) return
        if (!autoMix && manualMixRequested && !manualOverlap) tryStartManualMix("apply_deck_volumes")
        val canUseStandby = manualOverlap || (standbyActuallyReady() &&
            (autoMix || (bufferedPercentA >= MANUAL_MIX_BUFFER_PERCENT && bufferedPercentB >= MANUAL_MIX_BUFFER_PERCENT)))
        val normalized = if (!canUseStandby) 0f
            else ((crossfader + 1f) / 2f).coerceIn(0f, 1f)
        val gainA = kotlin.math.cos(normalized * (Math.PI / 2.0)).toFloat()
        val gainB = kotlin.math.sin(normalized * (Math.PI / 2.0)).toFloat()
        player?.let { runCatching { it.setVolume(volume * gainA, volume * gainA) } }
        standbyPlayer?.let { runCatching { it.setVolume(volume * gainB, volume * gainB) } }
        if (manualOverlap && crossfader >= 0.999f) {
            BlackBox.log("MANUAL MIX END from=${current?.name} to=${standbyEntry?.name} reason=fader_full_right")
            promoteStandby()
        }
    }

    private fun settleManualOverlap() {
        if (!manualOverlap) return
        val start = ((crossfader + 1f) / 2f).coerceIn(0f, 1f)
        val began = SystemClock.elapsedRealtime()
        val duration = 280L
        crossfading = false
        manualOverlap = false
        fun tick() {
            val t = ((SystemClock.elapsedRealtime() - began).toFloat() / duration).coerceIn(0f, 1f)
            val x = start * (1f - t)
            val gainA = kotlin.math.cos(x * (Math.PI / 2.0)).toFloat()
            val gainB = kotlin.math.sin(x * (Math.PI / 2.0)).toFloat()
            player?.let { runCatching { it.setVolume(volume * gainA, volume * gainA) } }
            standbyPlayer?.let { runCatching { it.setVolume(volume * gainB, volume * gainB) } }
            if (t < 1f) handler.postDelayed({ tick() }, 20L) else {
                standbyPlayer?.let { runCatching { it.pause() }; runCatching { it.seekTo(0) }; runCatching { it.setVolume(0f, 0f) } }
                crossfader = -1f
                publish(crossfading = false, crossfader = -1f)
                BlackBox.log("MANUAL CROSSFade END settled=true autoResume=true")
            }
        }
        tick()
    }

    private fun setMixerInternal(position: Float, automatic: Boolean, seconds: Int) {
        handler.post {
            val previousAuto = autoMix
            val requestedPosition = position.coerceIn(-1f, 1f)
            if (automatic) {
                manualFaderAwaitingRelease = false
            } else if (manualFaderAwaitingRelease) {
                // Ignore any queued B-side slider callbacks while the user's
                // finger is still down. The UI sends A once that gesture ends.
                if (requestedPosition <= -0.999f) {
                    manualFaderAwaitingRelease = false
                } else {
                    crossfader = -1f
                    manualMixRequested = false
                    publish(crossfader = -1f, autoMix = false, crossfadeSeconds = crossfadeSeconds)
                    return@post
                }
            }
            crossfader = if (automatic) requestedPosition else requestedPosition.coerceIn(crossfader, 1f)
            autoMix = automatic
            crossfadeSeconds = seconds.coerceIn(1, 12)
            if (automatic) {
                manualMixRequested = false
                if (manualOverlap) {
                    settleManualOverlap()
                    suppressAutoCrossfadeUntil = SystemClock.elapsedRealtime() + 1_000L
                    publish(crossfader = crossfader, autoMix = true, crossfadeSeconds = crossfadeSeconds)
                    BlackBox.log("MANUAL MIX END mode=automatic return=smooth settleMs=280 autoResumeDelayMs=1000")
                    return@post
                }
                if (!previousAuto && crossfader > -0.999f) {
                    // A was never mixed if B was not ready. Reset the logical fader
                    // without starting an unwanted transition.
                    crossfader = -1f
                    runCatching { player?.setVolume(volume, volume) }
                    BlackBox.log("MANUAL MIX END mode=automatic return=active_deck_only")
                }
            } else {
                // Manual control is one-way: once the gesture leaves A it can
                // advance toward B, but never pull the mix back toward A.
                manualMixRequested = crossfader > -0.999f
                if (crossfading && !manualOverlap) {
                    // Take over an automatic transition from its current real gains.
                    manualOverlap = true
                    BlackBox.log("MANUAL MIX TAKEOVER from_automatic=true")
                } else if (manualMixRequested && !manualOverlap) {
                    tryStartManualMix("fader_gesture")
                }
                applyDeckVolumes()
            }
            publish(crossfader = crossfader, autoMix = autoMix, crossfadeSeconds = crossfadeSeconds)
            BlackBox.log("MIXER CONFIG crossfader=$crossfader auto=$autoMix seconds=$crossfadeSeconds")
        }
    }

    private fun seekInternal(value: Int) {
        handler.post {
            val p = player ?: return@post
            if (!playerPrepared || snapshot.preparing || snapshot.duration <= 0) return@post
            val target = value.coerceIn(0, snapshot.duration)
            runCatching { p.seekTo(target) }
            publish(position = target)
        }
    }

    private fun nextInternal() {
        handler.post {
            if (!snapshot.sessionActive) return@post
            val base = if (transitionRequested && standbyOrderPosition >= 0) standbyOrderPosition else orderPosition
            val target = if (base + 1 in order.indices) base + 1 else if (repeat && order.isNotEmpty()) 0 else -1
            if (target < 0) { BlackBox.log("QUEUE MANUAL NEXT ignored at end index=$orderPosition size=${order.size}"); return@post }
            BlackBox.log("QUEUE MANUAL NEXT index=$orderPosition target=$target size=${order.size} keepActive=true")
            if (crossfading) {
                crossfading = false
                manualOverlap = false
                crossfader = -1f
                runCatching { player?.setVolume(volume, volume) }
                publish(crossfading = false, crossfader = -1f)
            }
            transitionRequested = true
            if (standbyPrepared && standbyOrderPosition == target) beginCrossfade() else preloadNextDeck(target)
        }
    }

    private fun previousInternal() {
        handler.post {
            if (!snapshot.sessionActive || order.isEmpty()) return@post
            BlackBox.log("QUEUE MANUAL PREVIOUS index=$orderPosition previous=${orderPosition - 1} size=${order.size}")
            val prev = if (orderPosition > 0) orderPosition - 1 else if (repeat) order.lastIndex else -1
            if (prev >= 0) {
                if (crossfading) {
                    crossfading = false
                    manualOverlap = false
                    crossfader = -1f
                    runCatching { player?.setVolume(volume, volume) }
                    publish(crossfading = false, crossfader = -1f)
                }
                transitionRequested = true
                BlackBox.log("QUEUE MANUAL PREVIOUS index=$orderPosition target=$prev keepActive=true")
                if (standbyPrepared && standbyOrderPosition == prev) beginCrossfade() else preloadNextDeck(prev)
            } else if (snapshot.position > 3000) {
                seekInternal(0)
            } else if (repeat) {
                releasePlayer()
                orderPosition = order.lastIndex
                playIndex(order[orderPosition])
            } else {
                seekInternal(0)
            }
        }
    }

    private fun toggleInternal() {
        handler.post {
            val p = player ?: return@post
            if (!playerPrepared || snapshot.preparing) return@post
            if (snapshot.playing) {
                resumeAfterTemporaryFocusLoss = false
                runCatching { p.pause() }
                if (crossfading) {
                    standbyPlayer?.let { runCatching { it.pause() } }
                    crossfadePausedElapsed = SystemClock.elapsedRealtime() - crossfadeStartedAt
                }
                publish(playing = false)
                releaseAudioFocus()
            } else if (acquireAudioFocus()) {
                runCatching { p.start() }.onSuccess {
                    if (crossfading) standbyPlayer?.let { runCatching { it.start() } }
                    if (crossfading) crossfadeStartedAt = SystemClock.elapsedRealtime() - crossfadePausedElapsed
                    resumeAfterTemporaryFocusLoss = false
                    publish(playing = true)
                }
            }
            updateNotification()
        }
    }

    private fun refreshStandbyIfNextChanged() {
        if (!playerPrepared || !snapshot.sessionActive) return
        val nextPosition = nextOrderPosition()
        val nextUri = order.getOrNull(nextPosition)?.let { files.getOrNull(it)?.uri }
        if (nextUri == standbyEntry?.uri && nextUri != null) {
            standbyOrderPosition = nextPosition
            BlackBox.log("DECK B PRELOAD PRESERVED reason=playback_order next=${standbyEntry?.name}")
            return
        }
        if (nextUri == null && standbyEntry == null) return
        clearStandby()
        preloadNextDeck()
    }

    private fun setRandomInternal(value: Boolean) {
        handler.post {
            if (random == value) return@post
            random = value
            val currentIndex = current?.let { now -> files.indexOfFirst { it.uri == now.uri } }?.takeIf { it >= 0 }
            rebuildOrder(currentIndex)
            refreshStandbyIfNextChanged()
            publish(random = random)
            updateNotification()
        }
    }

    private fun setRepeatInternal(value: Boolean) {
        handler.post {
            if (repeat == value) return@post
            repeat = value
            refreshStandbyIfNextChanged()
            publish(repeat = repeat)
            updateNotification()
        }
    }

    private fun setVolumeInternal(value: Float) {
        handler.post {
            volume = value.coerceIn(0f, 1f)
            applyDeckVolumes()
        }
    }

    private fun stopInternal() {
        stagedFirstQueueUri = null
        val stopNow = Runnable {
            BlackBox.log("AUDIO SESSION DESTROY queue=${files.size} track=${current?.name}")
            releasePlayer()
            releaseAudioFocus()
            files = emptyList(); order = emptyList(); orderPosition = -1; current = null
            manualFaderAwaitingRelease = false
            snapshot = Snapshot(random = random, repeat = repeat)
            updatePlaybackState()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        if (Looper.myLooper() == Looper.getMainLooper()) stopNow.run() else handler.post(stopNow)
    }

    private fun releasePlayer(clearB: Boolean = true) {
        if (clearB) clearStandby()
        playbackGeneration++
        resolverJob?.cancel()
        resolverJob = null
        val setupInFlight = activeSourceJob?.isActive == true
        activeSourceJob?.cancel()
        activeSourceJob = null
        val p = player
        player = null
        playerPrepared = false
        if (p != null) {
            val sessionId = if (setupInFlight) -1 else runCatching { p.audioSessionId }.getOrDefault(-1)
            BlackBox.log("AUDIO PLAYER DESTROY deck=A audioSessionId=$sessionId deferred=$setupInFlight")
            if (!setupInFlight) runCatching { p.release() }
        }
    }

    private fun publish(
        trackUri: String? = snapshot.trackUri,
        trackName: String? = snapshot.trackName,
        preparing: Boolean = snapshot.preparing,
        playing: Boolean = snapshot.playing,
        position: Int = snapshot.position,
        duration: Int = snapshot.duration,
        random: Boolean = snapshot.random,
        repeat: Boolean = snapshot.repeat,
        sessionActive: Boolean = snapshot.sessionActive,
        deckAReady: Boolean = snapshot.deckAReady,
        deckBReady: Boolean = snapshot.deckBReady,
        deckBPreparing: Boolean = snapshot.deckBPreparing,
        deckBRecovering: Boolean = snapshot.deckBRecovering,
        bufferedPercentA: Int = snapshot.bufferedPercentA,
        bufferedPercentB: Int = snapshot.bufferedPercentB,
        bufferingA: Boolean = snapshot.bufferingA,
        bufferingB: Boolean = snapshot.bufferingB,
        crossfading: Boolean = snapshot.crossfading,
        crossfader: Float = snapshot.crossfader,
        manualMixCompletions: Long = snapshot.manualMixCompletions,
        autoMix: Boolean = snapshot.autoMix,
        crossfadeSeconds: Int = snapshot.crossfadeSeconds,
        transitionRequestedState: Boolean = transitionRequested,
        standbyUri: String? = standbyEntry?.uri
    ) {
        snapshot = Snapshot(trackUri, trackName, preparing, playing, position.coerceAtLeast(0), duration.coerceAtLeast(0), random, repeat, sessionActive,
            deckAReady, deckBReady, deckBPreparing, deckBRecovering, bufferedPercentA.coerceIn(0, 100), bufferedPercentB.coerceIn(0, 100),
            bufferingA, bufferingB, crossfading, crossfader, manualMixCompletions, autoMix, crossfadeSeconds, transitionRequestedState, standbyUri)
    }

    private fun updatePlaybackState() {
        if (!::mediaSession.isInitialized) return
        val state = when {
            snapshot.preparing -> PlaybackState.STATE_BUFFERING
            snapshot.playing -> PlaybackState.STATE_PLAYING
            snapshot.sessionActive -> PlaybackState.STATE_PAUSED
            else -> PlaybackState.STATE_STOPPED
        }
        val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_STOP or PlaybackState.ACTION_SEEK_TO
        mediaSession.setMetadata(MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, snapshot.trackName ?: "BrakeMonster")
            .putString(MediaMetadata.METADATA_KEY_ARTIST, "BrakeMonster")
            .putLong(MediaMetadata.METADATA_KEY_DURATION, snapshot.duration.toLong())
            .build())
        mediaSession.setPlaybackState(
            PlaybackState.Builder().setActions(actions)
                .setState(state, snapshot.position.toLong(), if (snapshot.playing) 1f else 0f).build()
        )
    }

    private fun createChannel() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "BreakMonster playback", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Keeps BreakMonster music playing in the background"
                setShowBadge(false)
            }
        )
    }

    private fun servicePendingIntent(action: String, requestCode: Int): PendingIntent = PendingIntent.getService(
        this, requestCode, Intent(this, BreakPlaybackService::class.java).setAction(action),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun buildNotification(title: String, playing: Boolean): Notification {
        val openApp = PendingIntent.getActivity(
            this, 10, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val playPauseIcon = if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val playPauseLabel = if (playing) "Pause" else "Play"
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_play)
            .setContentTitle(title.ifBlank { "BreakMonster" })
            .setContentText(lastAudioFailure?.let { "AUDIO ERROR · Open MIXER > BLACK BOX" } ?: "BreakMonster player")
            .setContentIntent(openApp)
            .setOngoing(playing || snapshot.preparing)
            .setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(Notification.Action.Builder(playPauseIcon, playPauseLabel, servicePendingIntent(ACTION_TOGGLE, 11)).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_previous, "Previous", servicePendingIntent(ACTION_PREVIOUS, 14)).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_next, "Next", servicePendingIntent(ACTION_NEXT, 12)).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Stop", servicePendingIntent(ACTION_STOP, 13)).build())
            .setStyle(Notification.MediaStyle().setMediaSession(mediaSession.sessionToken).setShowActionsInCompactView(0, 2))
            .build()
    }

    private fun updateNotification() {
        if (!snapshot.sessionActive) return
        updatePlaybackState()
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(snapshot.trackName ?: "BreakMonster", snapshot.playing))
    }

    // HOME/minimize keeps playback. Removing the app task is an explicit close: stop and release.
    override fun onTaskRemoved(rootIntent: Intent?) {
        stopInternal()
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        BlackBox.log("AUDIO SERVICE destroyed queue=${files.size} track=${current?.name}")
        resolverScope.cancel()
        handler.removeCallbacks(ticker)
        releasePlayer()
        releaseAudioFocus()
        if (::mediaSession.isInitialized) {
            mediaSession.isActive = false
            mediaSession.release()
        }
        if (activeInstance === this) activeInstance = null
        snapshot = Snapshot(random = random, repeat = repeat)
        super.onDestroy()
    }
}
