package com.teraphonia.breakmonster

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// The same readiness threshold applies to NEXT, QUEUE, playlist selections,
// automatic transitions and manual mixing. The Exo adapter reports the
// fraction of its 40-second ahead-buffer target, not of the entire song.
internal const val MANUAL_MIX_BUFFER_PERCENT = 2
internal const val MIN_MIX_BUFFER_PERCENT = MANUAL_MIX_BUFFER_PERCENT

class BreakPlaybackService : Service() {
    data class Entry(val uri: String, val name: String)
    data class StartRequest(
        val files: List<Entry>,
        val selectedUri: String?,
        val random: Boolean,
        val repeat: Boolean,
        val volume: Float,
        val crossfader: Float = -1f,
        val autoMix: Boolean = true,
        val crossfadeSeconds: Int = 2
    )
    data class Snapshot(
        val trackUri: String? = null,
        val trackName: String? = null,
        val preparing: Boolean = false,
        val playing: Boolean = false,
        val position: Int = 0,
        val duration: Int = 0,
        val random: Boolean = false,
        val repeat: Boolean = false,
        val sessionActive: Boolean = false,
        val deckAReady: Boolean = false,
        val deckBReady: Boolean = false,
        val deckBPreparing: Boolean = false,
        val deckBRecovering: Boolean = false,
        val bufferedPercentA: Int = 0,
        val bufferedPercentB: Int = 0,
        val bufferingA: Boolean = false,
        val bufferingB: Boolean = false,
        val crossfading: Boolean = false,
        val crossfader: Float = 0f,
        // Increments only after the manual B-deck handover has really completed.
        val manualMixCompletions: Long = 0L,
        val autoMix: Boolean = false,
        val crossfadeSeconds: Int = 2,
        val transitionRequested: Boolean = false,
        val standbyTrackUri: String? = null,
        val standbyMixReady: Boolean = false
    )

    companion object {
        private const val CHANNEL_ID = "breakmonster_playback"
        private const val NOTIFICATION_ID = 9207
        private const val ACTION_START = "com.teraphonia.breakmonster.START"
        private const val ACTION_TOGGLE = "com.teraphonia.breakmonster.TOGGLE"
        private const val ACTION_PREVIOUS = "com.teraphonia.breakmonster.PREVIOUS"
        private const val ACTION_NEXT = "com.teraphonia.breakmonster.NEXT"
        private const val ACTION_STOP = "com.teraphonia.breakmonster.STOP"
        private const val ACTION_PREBUFFER_FIRST_QUEUE = "com.teraphonia.breakmonster.PREBUFFER_FIRST_QUEUE"
        @Volatile private var configuredCrossfader = -1f
        @Volatile private var configuredAutoMix = true
        @Volatile private var configuredCrossfadeSeconds = 2

        @Volatile private var activeInstance: BreakPlaybackService? = null
        @Volatile private var pendingStart: StartRequest? = null
        @Volatile private var pendingFirstQueue: Entry? = null
        @Volatile private var pendingEarlyNext = false
        @Volatile var onSingleTrackCompleted: (() -> Unit)? = null
        @Volatile var onTrackChanged: ((String) -> Unit)? = null
        @Volatile var snapshot: Snapshot = Snapshot()
            private set

        fun start(context: Context, request: StartRequest) {
            pendingStart = request.copy(
                crossfader = configuredCrossfader,
                autoMix = configuredAutoMix,
                crossfadeSeconds = configuredCrossfadeSeconds
            )
            context.startForegroundService(Intent(context, BreakPlaybackService::class.java).setAction(ACTION_START))
        }
        /** Extend a playing single-track session without restarting deck A. */
        /** Add a saved WEB/QUEUE/GHOST track directly after the audible song.
         * Uses the existing A/B transport, never replaces the active deck.
         */
        fun insertAfterPlaying(entry: Entry) {
            activeInstance?.enqueueNextPriority(entry)
        }
        /** After a successful WEB SAVE, immediately request a soft A→B mix.
         * Saving and preparing the NEXT slot are separate from interrupting A.
         */
        fun autoMixSavedWeb(entry: Entry) {
            activeInstance?.enqueueSavedWebTransition(entry)
        }

        fun appendToActivePlaylist(expectedCurrentUri: String, entry: Entry): Boolean {
            val service = activeInstance ?: return false
            if (!snapshot.sessionActive || snapshot.trackUri != expectedCurrentUri) return false
            return service.appendStandbyEntry(entry)
        }
        /** Silent B-deck warm-up for the first manually selected QUEUE entry.
         * No change to the playing playlist, NEXT order or audio focus.
         */
        fun prebufferFirstQueued(context: Context, entry: Entry?) {
            val service = activeInstance
            if (service != null) {
                service.stageFirstQueued(entry)
            } else if (entry != null) {
                pendingFirstQueue = entry
                context.startForegroundService(Intent(context, BreakPlaybackService::class.java).setAction(ACTION_PREBUFFER_FIRST_QUEUE))
            } else {
                // An immediate undo can occur before the new service is created.
                pendingFirstQueue = null
            }
        }
        fun seekTo(value: Int) { activeInstance?.seekInternal(value) }
        fun next() {
            val service = activeInstance
            if ((service == null || !snapshot.sessionActive) && pendingStart != null) {
                // A fast NEXT can arrive before Android has delivered ACTION_START.
                pendingEarlyNext = true
                return
            }
            service?.nextInternal()
        }
        /** Change the upcoming playlist without sending a new START or clearing deck A. */
        fun updateActiveQueue(expectedCurrentUri: String, updated: List<Entry>, shuffle: Boolean, looping: Boolean): Boolean {
            val service = activeInstance ?: return false
            if (!snapshot.sessionActive || snapshot.trackUri != expectedCurrentUri) return false
            service.replaceUpcomingEntries(expectedCurrentUri, updated, shuffle, looping)
            return true
        }
        fun previous() { activeInstance?.previousInternal() }
        fun togglePause() { activeInstance?.toggleInternal() }
        fun setRandom(value: Boolean) { activeInstance?.setRandomInternal(value) }
        fun setRepeat(value: Boolean) { activeInstance?.setRepeatInternal(value) }
        fun setVolume(value: Float) { activeInstance?.setVolumeInternal(value) }
        fun setMixer(crossfader: Float, autoMix: Boolean, seconds: Int) {
            configuredCrossfader = crossfader.coerceIn(-1f, 1f)
            configuredAutoMix = autoMix
            configuredCrossfadeSeconds = seconds.coerceIn(1, 12)
            activeInstance?.setMixerInternal(crossfader, autoMix, seconds)
        }
        fun setRollPreset(index: Int, bars: Double): Boolean = activeInstance?.setRollPresetInternal(index, bars) ?: false
        fun currentRollBpm(): Int = activeInstance?.player?.rollBpm ?: 0
        fun releaseRollEffect() { activeInstance?.releaseRollEffectInternal() }
        fun stop(context: Context) {
            pendingStart = null
            pendingEarlyNext = false
            activeInstance?.stopInternal() ?: context.stopService(Intent(context, BreakPlaybackService::class.java))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val resolverScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var resolverJob: Job? = null
    private var playbackGeneration = 0
    private var streamTrack = false
    private var startedAudioAt = 0L
    private var lastAudioFailure: String? = null

    // Deck B is prepared silently while deck A plays. Never shares A's resolver job.
    private var standbyPlayer: ExoDeckPlayer? = null
    private var standbyEntry: Entry? = null
    private var standbyPrepared = false
    private var standbyRecovering = false
    private val standbyRetries = mutableMapOf<String, Int>()
    private val unplayableStandbyUris = mutableSetOf<String>()
    private var standbyLoadStartedAt = 0L
    // Media3 may say "prepared" while its network buffer is still at 0%.
    // Measure raw progress independently of the optimistic UI readiness value.
    private var standbyLastProgressAt = 0L
    private var standbyLastRawPercent = 0
    // First health check after 3 seconds; retry only a genuinely stalled
    // load after 6 seconds. These are stall limits, not loading delays.
    private val standbyHealthCheckMs = 3_000L
    private val standbyLoadTimeoutMs = 6_000L
    private val standbyPreparedStallTimeoutMs = 6_000L
    private var standbyHealthCheckLogged = false
    private var standbyStartedAt = 0L
    private var standbyOrderPosition = -1
    private var stagedFirstQueueUri: String? = null
    private var standbyJob: Job? = null
    // EndlessMix-style scheduling turbo: resolve the following URL in advance,
    // without replacing either MediaPlayer or touching deck A's playback.
    private var followingUrlJob: Job? = null
    private var followingUrlUri: String? = null
    private var standbyGeneration = 0
    private var player: ExoDeckPlayer? = null
    // Independent of UI snapshot: only onPrepared makes Media3 queryable.
    private var playerPrepared = false
    private var bufferedPercentA = 0
    private var bufferedPercentB = 0
    private var bufferingA = false
    private var bufferingB = false
    private var crossfader = 0f
    private var autoMix = true
    private var crossfadeSeconds = 2
    private var crossfadeStartedAt = 0L
    private var crossfadePausedElapsed = 0L
    private var suppressAutoCrossfadeUntil = 0L
    private var randomRebuildAfterHandover = false
    private var crossfading = false
    private var transitionRequested = false
    // For an explicit selection, ExoPlayer READY is a valid signal to prime
    // the incoming deck. A displayed 0% may mean the buffered-duration meter
    // cannot yet measure this stream. Keep A audible until B is *actually*
    // playing; never crossfade into a silent/loading deck.
    private var selectionPrimedDeck: ExoDeckPlayer? = null
    // NEXT pressed while B is already audible must not be silently discarded.
    // Apply it after the A/B handover, when there is once again a free deck.
    private var nextAfterHandover = false
    private val priorityAfterHandover = mutableListOf<Entry>()
    // A SAVE made during an ongoing mix must wait until the current handover.
    private var savedWebMixAfterHandoverUri: String? = null
    private var manualOverlap = false
    private var manualMixRequested = false
    private var manualMixCompletions = 0L
    private var manualFaderAwaitingRelease = false
    private var files: List<Entry> = emptyList()
    private var order: List<Int> = emptyList()
    private var orderPosition = -1
    private var random = false
    private var repeat = false
    private var volume = 1f
    private var current: Entry? = null
    private lateinit var mediaSession: MediaSession
    private var activeRollPreset = -1
    private var activeRollBars = 1.0

    private fun setRollPresetInternal(index: Int, bars: Double): Boolean {
        // The UI snapshot is published on a timer and may lag a live deck during
        // preparation/promotion. Gate on the physical player that will receive PCM.
        val audibleDeck = player ?: return false
        if (index !in 0..11 || bars <= 0.0 || !audibleDeck.isPlaying || crossfading || audibleDeck.rollBpm !in 40..220) return false
        // A preset is only accepted once PCM has actually passed through the sink.
        // Without this check the UI can claim ACTIVE while Android bypasses the processor.
        if (!audibleDeck.hasRollPcmOutput()) {
            BlackBox.log("ROLLMONSTER NO PCM: active audio sink has not delivered frames")
            return false
        }
        releaseRollEffectInternal()
        activeRollPreset = index
        activeRollBars = bars
        audibleDeck.setRollPreset(index, bars)
        BlackBox.log("ROLLMONSTER ACTIVATE preset=$index deck=A bpm=${audibleDeck.rollBpm}")
        return true
    }

    private fun releaseRollEffectInternal() {
        if (activeRollPreset >= 0) BlackBox.log("ROLLMONSTER RELEASE preset=$activeRollPreset")
        activeRollPreset = -1
        player?.releaseRollEffect()
        standbyPlayer?.releaseRollEffect()
    }

    // Local audio is owned by this foreground service, never by the UI/PiP.
    // Audio focus handles calls and other temporary system interruptions.
    private val audioManager by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    private val musicAudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()
    private var ownsAudioFocus = false
    private var resumeAfterTemporaryFocusLoss = false
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_GAIN -> {
                ownsAudioFocus = true
                if (resumeAfterTemporaryFocusLoss) {
                    resumeAfterTemporaryFocusLoss = false
                    val p = player
                    if (p != null && playerPrepared && !snapshot.preparing && !snapshot.playing && snapshot.sessionActive) {
                        runCatching { p.start() }.onSuccess {
                            if (crossfading) standbyPlayer?.let { runCatching { it.start() } }
                            if (crossfading) crossfadeStartedAt = SystemClock.elapsedRealtime() - crossfadePausedElapsed
                            publish(playing = true)
                            updateNotification()
                        }
                    }
                }
            }
            AudioManager.AUDIOFOCUS_LOSS -> {
                ownsAudioFocus = false
                resumeAfterTemporaryFocusLoss = false
                pauseForAudioInterruption()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                ownsAudioFocus = false
                // Do not duck through a telephone call: pause until focus returns.
                resumeAfterTemporaryFocusLoss = snapshot.playing ||
                    (snapshot.preparing && snapshot.sessionActive)
                pauseForAudioInterruption()
            }
        }
    }
    private val focusRequest by lazy {
        AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(musicAudioAttributes)
            .setOnAudioFocusChangeListener(focusListener, handler)
            .setWillPauseWhenDucked(true)
            .setAcceptsDelayedFocusGain(true)
            .build()
    }

    private fun acquireAudioFocus(): Boolean {
        if (ownsAudioFocus) return true
        return when (audioManager.requestAudioFocus(focusRequest)) {
            AudioManager.AUDIOFOCUS_REQUEST_GRANTED -> {
                ownsAudioFocus = true
                true
            }
            AudioManager.AUDIOFOCUS_REQUEST_DELAYED -> {
                resumeAfterTemporaryFocusLoss = true
                false
            }
            else -> {
                resumeAfterTemporaryFocusLoss = false
                false
            }
        }
    }

    private fun releaseAudioFocus() {
        resumeAfterTemporaryFocusLoss = false
        // Also cancels delayed focus grants queued behind an ongoing call.
        runCatching { audioManager.abandonAudioFocusRequest(focusRequest) }
        ownsAudioFocus = false
    }

    private fun pauseForAudioInterruption() {
        if (snapshot.playing) {
            player?.let { runCatching { it.pause() } }
            if (crossfading) {
                standbyPlayer?.let { runCatching { it.pause() } }
                crossfadePausedElapsed = SystemClock.elapsedRealtime() - crossfadeStartedAt
            }
            publish(playing = false)
            updateNotification()
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            val p = player
            // Poll Exo's actual buffered duration as well as state callbacks.
            // This also catches quiet progress without a state transition.
            player?.pollBuffering()
            standbyPlayer?.pollBuffering()
            if (p != null && snapshot.sessionActive && playerPrepared) {
                // Never treat an unresolved BMQ source as a playable Exo deck.
                // State/position are published only after Media3 is ready.
                val pos = if (snapshot.preparing) snapshot.position else runCatching { p.currentPosition }.getOrDefault(snapshot.position)
                val dur = if (snapshot.preparing) snapshot.duration
                    else if (snapshot.duration > 0) snapshot.duration
                    else runCatching { p.duration }.getOrDefault(0).coerceAtLeast(0)
                publish(position = pos, duration = dur,
                    deckAReady = playerPrepared, deckBReady = standbyPrepared,
                    deckBPreparing = standbyEntry != null && !standbyPrepared,
                    bufferedPercentA = bufferedPercentA, bufferedPercentB = bufferedPercentB,
                    bufferingA = bufferingA, bufferingB = bufferingB,
                    crossfading = crossfading,
                    crossfader = crossfader, autoMix = autoMix, crossfadeSeconds = crossfadeSeconds)
                // A is already audible: it does not have to wait for a fresh
                // onBufferingUpdate(10) merely to mix into a prepared deck B.
                val decksMixReady = standbyOrderPosition >= 0 && playerPrepared && standbyPrepared &&
                    isStandbyBufferEnough() &&
                    (bufferedPercentA >= MIN_MIX_BUFFER_PERCENT || (snapshot.playing && !bufferingA))
                // A clicked song must not be stuck at 0% forever. Prime B as
                // soon as Media3 reports READY, then wait for isPlaying before
                // lowering A's volume. Ordinary automatic transitions and
                // manual mixing retain the normal real-2% buffer requirement.
                if (transitionRequested && !crossfading && playerPrepared && standbyPrepared &&
                    standbyOrderPosition >= 0 && snapshot.playing) {
                    beginCrossfade()
                } else if (autoMix && SystemClock.elapsedRealtime() >= suppressAutoCrossfadeUntil &&
                    !crossfading && decksMixReady && dur > 0 && snapshot.playing) {
                    val remaining = dur - pos
                    if (remaining <= crossfadeSeconds * 1000) beginCrossfade()
                }
                if (crossfading && manualOverlap && snapshot.playing) applyDeckVolumes()
                else if (crossfading && snapshot.playing) updateCrossfade()
                updatePlaybackState()
            }
            // Run in the foreground audio SERVICE, not Activity.onResume():
            // a stalled NEXT must recover even when the app is backgrounded.
            // The old watchdog ignored a stream forever once onPrepared() fired.
            val now = SystemClock.elapsedRealtime()
            val stalledEntry = standbyEntry
            if (stalledEntry != null && !standbyRecovering && !crossfading &&
                standbyLoadStartedAt > 0L && standbyLastProgressAt > 0L &&
                standbyPlayer?.let { runCatching { it.isPlaying }.getOrDefault(false) } != true) {
                val stalledFor = now - standbyLastProgressAt
                val loadingFor = now - standbyLoadStartedAt
                val waitingForBytes = standbyPrepared && standbyOrderPosition >= 0 &&
                    (transitionRequested || !autoMix || manualMixRequested) && isStream(stalledEntry) &&
                    // Silent, unrequested automatic preloads may not emit buffer
                    // callbacks until playback. Only retry when actually needed.
                    standbyLastRawPercent < (if (autoMix) MIN_MIX_BUFFER_PERCENT else MANUAL_MIX_BUFFER_PERCENT)
                if (!standbyHealthCheckLogged && stalledFor >= standbyHealthCheckMs &&
                    (!standbyPrepared || waitingForBytes)) {
                    standbyHealthCheckLogged = true
                    BlackBox.log("DECK B HEALTH CHECK track=${stalledEntry.name} prepared=$standbyPrepared raw=${standbyLastRawPercent}% elapsedMs=$loadingFor")
                    // If no player or resolver remains, revive the missing
                    // operation immediately rather than waiting for Activity resume.
                    if (!standbyPrepared && standbyPlayer == null &&
                        standbyJob?.isActive != true) {
                        recoverStandby(stalledEntry, standbyOrderPosition, "missing_loader_at_3s")
                    }
                }
                if (standbyEntry === stalledEntry && !standbyRecovering) {
                    val loadingTimeout = !standbyPrepared && loadingFor >= standbyLoadTimeoutMs
                    val rawBufferStalled = waitingForBytes && stalledFor >= standbyPreparedStallTimeoutMs
                    if (loadingTimeout || rawBufferStalled) {
                        BlackBox.log("DECK B BUFFER STALL track=${stalledEntry.name} prepared=$standbyPrepared raw=${standbyLastRawPercent}% displayed=${bufferedPercentB}% sinceProgressMs=$stalledFor action=retry")
                        recoverStandby(stalledEntry, standbyOrderPosition,
                            if (rawBufferStalled) "prepared_buffer_stalled" else "load_timeout")
                    }
                }
            }
            handler.postDelayed(this, 250L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        activeInstance = this
        BlackBox.ensureInitialized(applicationContext)
        BlackBox.log("AUDIO SERVICE created")
        createChannel()
        mediaSession = MediaSession(this, "BreakMonster").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() { if (!snapshot.playing) toggleInternal() }
                override fun onPause() { if (snapshot.playing) toggleInternal() }
                override fun onSkipToNext() { nextInternal() }
                override fun onSkipToPrevious() { previousInternal() }
                override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                    return super.onMediaButtonEvent(mediaButtonIntent)
                }
                override fun onStop() { stopInternal() }
                override fun onSeekTo(pos: Long) { seekInternal(pos.toInt()) }
            })
            setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)
            isActive = true
        }
        handler.post(ticker)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PREBUFFER_FIRST_QUEUE -> {
                val entry = pendingFirstQueue
                pendingFirstQueue = null
                if (entry != null) {
                    if (!snapshot.sessionActive) startForeground(NOTIFICATION_ID, buildNotification("QUEUE PREBUFFER", false))
                    stageFirstQueued(entry)
                } else if (!snapshot.sessionActive) {
                    stopSelf()
                }
            }
            ACTION_START -> {
                val request = pendingStart
                pendingStart = null
                if (request == null) {
                    // Two rapid start() calls can enqueue two intents while the
                    // static slot already contains only the latest request.
                    // The old behavior STOPPED an otherwise healthy session.
                    BlackBox.log("AUDIO START duplicate intent ignored; no pending request")
                    return START_NOT_STICKY
                }
                if (request.files.isEmpty()) {
                    BlackBox.log("AUDIO START empty playlist ignored; preserving session")
                    return START_NOT_STICKY
                }
                lastAudioFailure = null
                // An explicit selection uses the SAME transition machinery as
                // QUEUE and NEXT. If an A/B fade is already audible, finish the
                // ownership handover first; don't stop the audible B deck while
                // replacing its playlist underneath it.
                if (crossfading && standbyPlayer != null && standbyEntry != null) {
                    BlackBox.log("UNIFIED SELECT finalizing in-flight transition before new target")
                    nextAfterHandover = false
                    promoteStandby()
                }
                // Explicit playback selection takes ownership of any staged B deck.
                stagedFirstQueueUri = null
                val selectedLabel = request.selectedUri?.substringAfterLast('/') ?: "first"
                BlackBox.log("AUDIO PLAYLIST START count=${request.files.size} selected=$selectedLabel")
                random = request.random
                repeat = request.repeat
                volume = request.volume.coerceIn(0f, 1f)
                crossfader = request.crossfader.coerceIn(-1f, 1f)
                autoMix = request.autoMix
                crossfadeSeconds = request.crossfadeSeconds.coerceIn(1, 12)
                transitionRequested = false
                nextAfterHandover = false
                priorityAfterHandover.clear()
                savedWebMixAfterHandoverUri = null
                randomRebuildAfterHandover = false
                standbyRetries.clear()
                unplayableStandbyUris.clear()
                files = request.files.distinctBy { it.uri }
                BlackBox.log("QUEUE size=${files.size} selectedIndex=${request.selectedUri?.let { wanted -> files.indexOfFirst { it.uri == wanted } } ?: 0}")
                startForeground(NOTIFICATION_ID, buildNotification("BreakMonster", false))
                val selected = request.selectedUri?.let { wanted -> files.indexOfFirst { it.uri == wanted } }?.takeIf { it >= 0 }
                rebuildOrder(selected)
                if (order.isEmpty()) stopInternal() else {
                    val keepCurrent = snapshot.sessionActive && player != null && playerPrepared
                    if (keepCurrent) {
                        val sameTrack = request.selectedUri == current?.uri
                        BlackBox.log("UNIFIED SELECTION source=playlist_or_queue sameTrack=$sameTrack active=${current?.name} selected=${request.selectedUri}")
                        // rebuildOrder() is based on the new request snapshot. When the
                        // active item is kept, it is always at snapshot position zero;
                        // retaining the old position makes NEXT point past the new list.
                        orderPosition = if (sameTrack) 0 else orderPosition
                        transitionRequested = !sameTrack
                        publish(random = random, repeat = repeat, sessionActive = true, preparing = false, playing = snapshot.playing)
                        BlackBox.log("AUDIO QUEUE REPLACED count=${files.size} selectedIndex=${selected ?: 0} keepActive=true sameTrack=$sameTrack")
                        if (sameTrack) preloadNextDeck() else preloadNextDeck(0)
                    } else {
                        crossfading = false
                        publish(random = random, repeat = repeat, sessionActive = true, preparing = true)
                        orderPosition = 0
                        BlackBox.log("AUDIO SESSION CREATE queue=${files.size}")
                        playIndex(order[0])
                    }
                }
                if (pendingEarlyNext && snapshot.sessionActive) {
                    pendingEarlyNext = false
                    BlackBox.log("QUEUE EARLY NEXT delivered after ACTION_START")
                    nextInternal()
                }
            }
            ACTION_TOGGLE -> toggleInternal()
            ACTION_NEXT -> nextInternal()
            ACTION_PREVIOUS -> previousInternal()
            ACTION_STOP -> stopInternal()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun rebuildOrder(firstIndex: Int? = null) {
        val all = files.indices.toList()
        if (all.isEmpty()) {
            order = emptyList(); orderPosition = -1; return
        }
        val first = firstIndex?.takeIf { it in all }
        val rest = if (first == null) all else all.filter { it != first }
        val previousFileIndex = current?.let { now -> files.indexOfFirst { it.uri == now.uri } } ?: -1
        val orderedRest = if (random) {
            val shuffled = rest.shuffled().toMutableList()
            if (first == null && shuffled.size > 1 && shuffled.first() == previousFileIndex) {
                val swap = shuffled.indexOfFirst { it != previousFileIndex }
                if (swap > 0) java.util.Collections.swap(shuffled, 0, swap)
            }
            shuffled
        } else rest
        order = if (first == null) { if (random) all.shuffled() else all } else listOf(first) + orderedRest
        orderPosition = if (order.isEmpty()) -1 else 0
    }

    private fun playIndex(index: Int) {
        val entry = files.getOrNull(index) ?: return
        if (standbyEntry?.uri == entry.uri && standbyPrepared && standbyPlayer != null) {
            val ready = standbyPlayer!!
            val oldActive = player
            playbackGeneration++
            resolverJob?.cancel(); resolverJob = null
            val readyBuffer = bufferedPercentB
            val readyBuffering = bufferingB
            standbyPlayer = oldActive
            standbyEntry = null; standbyPrepared = false; standbyStartedAt = 0L; standbyLoadStartedAt = 0L
            stagedFirstQueueUri = null
            if (oldActive != null) {
                runCatching { oldActive.stop() }
                runCatching { oldActive.reset() }
            }
            player = ready; playerPrepared = true; current = entry
            onTrackChanged?.invoke(entry.uri)
            streamTrack = isStream(entry)
            val duration = runCatching { ready.duration }.getOrDefault(0).coerceAtLeast(0)
            publish(trackUri = entry.uri, trackName = entry.name, preparing = false,
                playing = false, position = 0, duration = duration, sessionActive = true, deckAReady = true,
                deckBReady = false, deckBPreparing = false)
            if (acquireAudioFocus()) {
                runCatching { ready.start() }.onSuccess {
                    startedAudioAt = SystemClock.elapsedRealtime()
                    standbyStartedAt = 0L
                    crossfading = false; manualOverlap = false
                    crossfader = -1f; configuredCrossfader = -1f
                    BlackBox.log("PLAYER ROLE SWAP A=${entry.name} mode=NEXT audioSessionPreserved=true")
                    bufferedPercentA = readyBuffer
                    bufferedPercentB = 0
                    bufferingA = readyBuffering
                    bufferingB = false
                    publish(playing = true, crossfading = false, crossfader = -1f, deckAReady = true,
                        deckBReady = false, deckBPreparing = false, bufferedPercentA = readyBuffer,
                        bufferedPercentB = 0, bufferingA = readyBuffering, bufferingB = false)
                    preloadNextDeck()
                }.onFailure { failCurrent(ready, "Deck B promotion", it) }
            }
            updateNotification()
            return
        }
        releasePlayer()
        current = entry
        onTrackChanged?.invoke(entry.uri)
        lastAudioFailure = null
        val sourceUri = Uri.parse(entry.uri)
        streamTrack = entry.uri.startsWith("https://www.youtube.com/watch?v=") ||
            sourceUri.path.orEmpty().endsWith(".bmq", ignoreCase = true) ||
            sourceUri.path.orEmpty().endsWith(".yt", ignoreCase = true)
        startedAudioAt = 0L
        bufferedPercentA = 0
        bufferingA = false
        BlackBox.log("AUDIO TRACK START ${orderPosition + 1}/${order.size} name=${entry.name} kind=${if (streamTrack) "BMQ" else "LOCAL"}")
        publish(trackUri = entry.uri, trackName = entry.name, preparing = true,
            playing = false, position = 0, duration = 0, sessionActive = true,
            deckAReady = false, deckBReady = false, deckBPreparing = false, crossfading = false)
        updateNotification()

        if (!streamTrack) {
            prepareResolvedSource(entry, null)
            // ExoPlayer A is preparing asynchronously. Start deck B in
            // parallel instead of waiting for A.onPrepared()/A.start().
            preloadNextDeck()
            return
        }

        // IMPORTANT: Do not even create a MediaPlayer in the IDLE state while
        // NewPipe is still looking for the stream URL. This prevents state
        // queries or callbacks from sending commands to an unloaded player.
        val generation = playbackGeneration
        val resolveStarted = SystemClock.elapsedRealtime()
        BlackBox.log("BMQ RESOLVE BEGIN track=${entry.name} deck=A")
        val resolvingWakeLock = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "BrakeMonsterPro:audioResolve")
        runCatching { resolvingWakeLock.acquire(60_000L) }
        resolverJob = resolverScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        val id = if (entry.uri.startsWith("https://www.youtube.com/watch?v="))
                            BmqCodec.extractId(entry.uri) ?: error("Invalid YouTube video ID")
                        else BmqCodec.readReference(applicationContext, Uri.parse(entry.uri))
                        ProStreamResolver.resolveAudio(id)
                    }
                }
                // A manual NEXT/STOP can happen during network extraction.
                if (generation != playbackGeneration || current?.uri != entry.uri || !snapshot.sessionActive)
                    return@launch
                result.fold(
                    onSuccess = { url ->
                        BlackBox.log("BMQ RESOLVE DURATION track=${entry.name} durationMs=${SystemClock.elapsedRealtime() - resolveStarted} deck=A")
                        BlackBox.log("BMQ RESOLVE OK track=${entry.name} · creating ExoPlayer")
                        prepareResolvedSource(entry, url)
                        // URL extraction for A is finished: overlap B's URL
                        // extraction with A's Media3 network preparation.
                        // A's onPrepared remains the ONLY code that starts sound.
                        if (generation == playbackGeneration && current?.uri == entry.uri) {
                            BlackBox.log("TURBO EARLY NEXT PRELOAD after A URL resolved")
                            preloadNextDeck()
                        }
                    },
                    onFailure = { error ->
                        failEntry(entry, "BMQ NewPipe resolve", error)
                    }
                )
            } finally {
                runCatching { if (resolvingWakeLock.isHeld) resolvingWakeLock.release() }
            }
        }
    }

    /** Called on the service main thread ONLY after the BMQ URL has been
     * resolved. The player is not queried until its onPrepared callback.
     */
    private fun prepareResolvedSource(entry: Entry, streamUrl: String?, standby: Boolean = false, reusable: ExoDeckPlayer? = null) {
        if (!snapshot.sessionActive && !(standby && stagedFirstQueueUri == entry.uri)) return
        if (!standby && current?.uri != entry.uri) return
        if (standby && standbyEntry?.uri != entry.uri) return
        val p = reusable ?: ExoDeckPlayer(applicationContext)
        val deckName = if (standby) "B" else "A"
        val prepareStartedAt = SystemClock.elapsedRealtime()
        val standbyLoadToken = standbyGeneration
        val activeLoadToken = playbackGeneration
        BlackBox.log("AUDIO PLAYER CREATE deck=$deckName audioSessionId=${runCatching { p.audioSessionId }.getOrDefault(-1)} reused=${reusable != null}")
        if (standby) standbyPlayer = p else {
            playerPrepared = false
            player = p
        }
        try {
            p.setVolume(volume, volume)
            p.setOnPreparedListener {
                val callbackIsCurrent = if (standby)
                    standbyPlayer === p && standbyEntry?.uri == entry.uri && standbyGeneration == standbyLoadToken
                else player === p && current?.uri == entry.uri && playbackGeneration == activeLoadToken
                if (callbackIsCurrent) {
                    if (player === p) playerPrepared = true
                    val duration = runCatching { p.duration }.getOrDefault(0).coerceAtLeast(0)
                    BlackBox.log("AUDIO PREPARED track=${entry.name} durationMs=$duration")
                    BlackBox.log("BUFFER PREPARATION DURATION track=${entry.name} durationMs=${SystemClock.elapsedRealtime() - prepareStartedAt} deck=$deckName")
                    if (p === standbyPlayer) {
                        standbyPrepared = true
                        standbyRecovering = false
                        // A successful prepare is not successful buffering: keep
                        // the bounded retry count until actual media bytes arrive.
                        standbyLastProgressAt = SystemClock.elapsedRealtime()
                        if (!isStream(entry)) {
                            bufferedPercentB = 100
                            standbyLastRawPercent = 100
                            standbyRetries.remove(entry.uri)
                        }
                        // For streams, do not pretend to have 5% just because
                        // onPrepared fired; the 2% manual gate uses real data.
                        else bufferedPercentB = standbyLastRawPercent
                        bufferingB = false
                        BlackBox.log("DECK B READY track=${entry.name} durationMs=$duration")
                        publish(deckBReady = true, deckBPreparing = false, deckBRecovering = false, bufferedPercentB = bufferedPercentB, bufferingB = false)
                        // Give B a head start on its own network buffer, then
                        // resolve C's audio URL speculatively off the UI thread.
                        handler.postDelayed({
                            if (standbyPlayer === p && standbyEntry?.uri == entry.uri &&
                                standbyGeneration == standbyLoadToken) warmFollowingStreamUrl()
                        }, 1_200L)
                        if (manualMixRequested && !autoMix) tryStartManualMix("standby_ready_callback")
                        applyDeckVolumes()
                        if (transitionRequested) {
                            val outgoingPlaying = runCatching { player?.isPlaying == true }.getOrDefault(false)
                            if (outgoingPlaying) beginCrossfade() else {
                                BlackBox.log("QUEUE WAIT ENDED BEFORE READY target=${entry.name}; starting ready deck without crossfade")
                                runCatching { p.setVolume(volume, volume); p.start() }
                                    .onSuccess { standbyStartedAt = SystemClock.elapsedRealtime(); promoteStandby() }
                                    .onFailure { failEntry(entry, "standby start after outgoing completion", it) }
                            }
                        }
                        return@setOnPreparedListener
                    }
                    if (!isStream(entry)) bufferedPercentA = 100
                    bufferingA = false
                    val mayPlay = acquireAudioFocus()
                    if (mayPlay) {
                        runCatching { p.start() }.onSuccess {
                            resumeAfterTemporaryFocusLoss = false
                            startedAudioAt = SystemClock.elapsedRealtime()
                            lastAudioFailure = null
                            BlackBox.log("AUDIO PLAYING track=${entry.name} durationMs=$duration")
                            publish(preparing = false, playing = true, duration = duration, deckAReady = true, bufferedPercentA = bufferedPercentA, bufferingA = false)
                            applyDeckVolumes()
                            preloadNextDeck()
                            // If B became ready before A, let A take priority
                            // before starting the low-priority URL warmup.
                            warmFollowingStreamUrl()
                        }.onFailure { error ->
                            failCurrent(p, "ExoPlayer.play", error)
                        }
                    } else {
                        BlackBox.log("AUDIO PREPARED waiting for audio focus track=${entry.name}")
                        publish(preparing = false, playing = false, duration = duration)
                    }
                    updateNotification()
                }
            }
            p.setOnCompletionListener {
                if (player === p && current?.uri == entry.uri) {
                    if (streamTrack && (startedAudioAt == 0L ||
                            SystemClock.elapsedRealtime() - startedAudioAt < 2500L)) {
                        failCurrent(p, "premature ExoPlayer completion (less than 2.5s)")
                        return@setOnCompletionListener
                    }
                    BlackBox.log("TRACK COMPLETION track=${entry.name} crossfading=$crossfading")
                    if (crossfading) return@setOnCompletionListener
                    if (transitionRequested) {
                        publish(preparing = true, playing = false, position = snapshot.duration)
                        if (standbyPrepared) {
                            BlackBox.log("QUEUE REQUESTED TARGET READY AFTER OUTGOING END track=${standbyEntry?.name}")
                            standbyPlayer?.let { next ->
                                runCatching { next.setVolume(volume, volume); next.start() }
                                    .onSuccess { standbyStartedAt = SystemClock.elapsedRealtime(); promoteStandby() }
                                    .onFailure { recoverStandby(standbyEntry ?: entry, standbyOrderPosition, "standby_start_after_completion") }
                            }
                        } else BlackBox.log("QUEUE WAITING FOR REQUESTED DECK READY track=${standbyEntry?.name}")
                        return@setOnCompletionListener
                    }
                    val expectedNextPosition = nextOrderPosition()
                    if (standbyPrepared && standbyOrderPosition == expectedNextPosition) {
                        BlackBox.log("QUEUE READY DECK PROMOTION track=${standbyEntry?.name} reason=completion")
                        promoteStandby()
                        return@setOnCompletionListener
                    }
                    if (expectedNextPosition in order.indices) {
                        // Keep the completed active deck and any valid standby load in
                        // place until the real NEXT is ready. Advancing directly here
                        // used to tear down the in-flight standby buffer and restart
                        // the next track on deck A, producing a gap and skipping mix.
                        transitionRequested = true
                        publish(preparing = true, playing = false, position = snapshot.duration)
                        if (standbyOrderPosition != expectedNextPosition || standbyEntry?.uri != files.getOrNull(order[expectedNextPosition])?.uri) {
                            preloadNextDeck(expectedNextPosition)
                        }
                        BlackBox.log("QUEUE WAITING FOR NEXT DECK READY position=$expectedNextPosition track=${standbyEntry?.name}")
                        return@setOnCompletionListener
                    }
                    releasePlayer(clearB = false)
                    publish(preparing = false, playing = false, position = snapshot.duration)
                    if (files.size == 1 && !repeat) {
                        BlackBox.log("QUEUE SERVICE FINISHED count=1")
                        publish(trackUri = null, trackName = null, position = 0, duration = 0, sessionActive = true)
                        onSingleTrackCompleted?.invoke()
                        stopInternal()
                    } else {
                        BlackBox.log("QUEUE SERVICE ADVANCE ${orderPosition + 1}/${order.size}")
                        advanceInternal()
                    }
                }
            }
            // A ExoPlayer changes logical roles at A->B promotion. The callbacks
            // must follow the CURRENT role, not the standby flag captured during
            // creation; otherwise promoted A silently loses buffer/error updates.
            p.setOnErrorListener { _, what, extra ->
                val onB = standbyPlayer === p && standbyEntry?.uri == entry.uri && standbyGeneration == standbyLoadToken
                val onA = player === p && current?.uri == entry.uri
                if (onB) {
                    BlackBox.log("DECK B ERROR what=$what extra=$extra track=${entry.name}")
                    recoverStandby(entry, standbyOrderPosition, "media_error")
                } else if (onA) {
                    failCurrent(p, "ExoPlayer error what=$what extra=$extra whilePreparing=${snapshot.preparing}")
                }
                true
            }
            p.setOnInfoListener { _, what, _ ->
                val onB = standbyPlayer === p && standbyEntry?.uri == entry.uri && standbyGeneration == standbyLoadToken
                val onA = player === p && current?.uri == entry.uri
                if (!onB && !onA) return@setOnInfoListener true
                when (what) {
                    ExoDeckPlayer.BUFFERING_START -> {
                        if (onB) bufferingB = true else bufferingA = true
                        BlackBox.log("AUDIO BUFFERING START track=${entry.name} deck=${if (onB) "B" else "A"}")
                        publish(bufferingA = bufferingA, bufferingB = bufferingB)
                    }
                    ExoDeckPlayer.BUFFERING_END -> {
                        if (onB) bufferingB = false else bufferingA = false
                        BlackBox.log("AUDIO BUFFERING END track=${entry.name} deck=${if (onB) "B" else "A"}")
                        publish(bufferingA = bufferingA, bufferingB = bufferingB)
                    }
                }
                true
            }
            p.setOnBufferingUpdateListener { _, percent ->
                val onB = standbyPlayer === p && standbyEntry?.uri == entry.uri && standbyGeneration == standbyLoadToken
                val onA = player === p && current?.uri == entry.uri
                if (!onB && !onA) return@setOnBufferingUpdateListener
                val value = percent.coerceIn(0, 100)
                if (onB) {
                    if (value > standbyLastRawPercent) {
                        standbyLastRawPercent = value
                        standbyLastProgressAt = SystemClock.elapsedRealtime()
                        standbyHealthCheckLogged = false
                    }
                    if (value >= MANUAL_MIX_BUFFER_PERCENT) {
                        standbyRetries.remove(entry.uri)
                        if (standbyPrepared) warmFollowingStreamUrl()
                    }
                    bufferedPercentB = when {
                        standbyPrepared && !isStream(entry) -> 100
                        standbyPrepared && !bufferingB -> value
                        else -> value
                    }
                } else {
                    bufferedPercentA = if (playerPrepared && !isStream(entry)) 100 else value
                }
                publish(bufferedPercentA = bufferedPercentA, bufferedPercentB = bufferedPercentB)
                BlackBox.log("AUDIO BUFFER PROGRESS deck=${if (onB) "B" else "A"} track=${entry.name} percent=$value")
                if (autoMix && transitionRequested && snapshot.playing && !crossfading && playerPrepared && standbyPrepared &&
                    (bufferedPercentA >= MIN_MIX_BUFFER_PERCENT || !bufferingA) &&
                    isStandbyBufferEnough()) beginCrossfade()
                else if (!autoMix && manualMixRequested && !crossfading && playerPrepared && standbyPrepared &&
                    (bufferedPercentA >= MANUAL_MIX_BUFFER_PERCENT || !bufferingA) &&
                    isStandbyBufferEnough()) tryStartManualMix("both_decks_buffer_ready")
            }
            // Media3 requires all calls on its application looper (main). It
            // opens content:// / file:// or HTTP streams asynchronously; avoid
            // opening a descriptor from a background coroutine and racing release.
            val sourceUri = Uri.parse(streamUrl ?: entry.uri)
            BlackBox.log("EXO SOURCE SET deck=$deckName track=${entry.name} stream=${streamUrl != null}")
            p.setSource(sourceUri)
            p.prepareAsync()
            BlackBox.log("EXO PREPARE_ASYNC deck=$deckName track=${entry.name}")
        } catch (error: Exception) {
            if (standby) {
                BlackBox.log("DECK B PREPARE FAILED track=${entry.name} ${error.javaClass.simpleName}")
                recoverStandby(entry, standbyOrderPosition, "setup")
            } else failCurrent(p, if (streamUrl != null) "BMQ MediaPlayer prepare" else "local MediaPlayer prepare", error)
        }
    }

    /** Halt on the FIRST error instead of racing through the entire playlist.
     * Manual NEXT still works so users can test a different recording.
     */
    private fun failCurrent(p: ExoDeckPlayer, stage: String, error: Throwable? = null) {
        if (player !== p) return
        val failed = current ?: return
        failEntry(failed, stage, error)
    }

    private fun failEntry(entry: Entry, stage: String, error: Throwable? = null) {
        if (current?.uri != entry.uri || !snapshot.sessionActive) return
        lastAudioFailure = stage
        BlackBox.audioFailure(stage, entry.name, error)
        BlackBox.log("PLAYBACK FAILURE track=${entry.name} stage=$stage recovery=${files.size > 1}")
        releasePlayer()
        publish(preparing = false, playing = false, deckAReady = false, deckBReady = false, deckBPreparing = false)
        updateNotification()
        if (files.size > 1) handler.post { advanceInternal() } else handler.post { stopInternal() }
    }

    private fun advanceInternal() {
        if (files.isEmpty()) { stopInternal(); return }
        val next = nextOrderPosition()
        if (next in order.indices) {
            orderPosition = next
            playIndex(order[next])
            return
        }
        if (repeat && unplayableStandbyUris.size < files.size) {
            rebuildOrder()
            val safe = order.indices.firstOrNull { files[order[it]].uri !in unplayableStandbyUris }
            if (safe != null) {
                orderPosition = safe
                playIndex(order[safe])
            } else stopInternal()
        } else {
            BlackBox.log("QUEUE SERVICE FINISHED count=${files.size}")
            onSingleTrackCompleted?.invoke()
            stopInternal()
        }
    }

    private fun isStream(entry: Entry): Boolean {
        val u = Uri.parse(entry.uri)
        return entry.uri.startsWith("https://www.youtube.com/watch?v=") ||
            u.path.orEmpty().endsWith(".bmq", true) || u.path.orEmpty().endsWith(".yt", true)
    }

    private fun clearStandby() {
        cancelFollowingUrlWarmup()
        if (crossfading) {
            BlackBox.log("CROSSFADE CANCEL reason=standby_cleared current=${current?.name} target=${standbyEntry?.name}")
            crossfading = false
            manualOverlap = false
            crossfader = -1f
            runCatching { player?.setVolume(volume, volume) }
            publish(crossfading = false, crossfader = -1f)
        }
        standbyGeneration++
        standbyJob?.cancel(); standbyJob = null
        selectionPrimedDeck = null
        val old = standbyPlayer
        if (manualMixRequested) BlackBox.log("MANUAL MIX REQUEST FAILED reason=standby_cancelled_or_failed")
        standbyPlayer = null; standbyEntry = null; standbyPrepared = false; standbyStartedAt = 0L
        standbyRecovering = false
        standbyLoadStartedAt = 0L
        standbyLastProgressAt = 0L
        standbyLastRawPercent = 0
        standbyHealthCheckLogged = false
        manualMixRequested = false
        if (old != null) {
            val sessionId = runCatching { old.audioSessionId }.getOrDefault(-1)
            BlackBox.log("AUDIO PLAYER DESTROY deck=B audioSessionId=$sessionId deferred=false")
            runCatching { old.release() }
        }
        bufferedPercentB = 0
        bufferingB = false
        publish(deckBReady = false, deckBPreparing = false, deckBRecovering = false, bufferedPercentB = 0, bufferingB = false)
    }

    /** Retry a failed NEXT twice, keeping the target visible as recovery state. */
    private fun recoverStandby(entry: Entry, position: Int, reason: String) {
        val retry = standbyRetries[entry.uri] ?: 0
        val wasStaged = position == -1 && stagedFirstQueueUri == entry.uri
        clearStandby()
        standbyEntry = entry
        standbyOrderPosition = position
        standbyRecovering = true
        bufferingB = false
        bufferedPercentB = 0
        publish(deckBReady = false, deckBPreparing = false, deckBRecovering = true,
            bufferingB = false, bufferedPercentB = 0, standbyUri = entry.uri)
        if (retry >= 2) {
            BlackBox.log("DECK B ERROR RECOVERY EXHAUSTED track=${entry.name} reason=$reason; skipping unavailable NEXT")
            unplayableStandbyUris.add(entry.uri)
            standbyEntry = null
            standbyOrderPosition = -1
            standbyRecovering = false
            standbyLoadStartedAt = 0L
            val candidate = nextPlayableOrderPosition(position.coerceAtLeast(orderPosition))
            if (candidate >= 0) {
                preloadNextDeck(candidate)
            } else if (!snapshot.playing && snapshot.preparing) {
                // Outgoing deck has finished: do not leave QUEUE loading forever.
                transitionRequested = false
                advanceInternal()
            } else {
                transitionRequested = false
                if (!snapshot.sessionActive && stagedFirstQueueUri == entry.uri) {
                    stagedFirstQueueUri = null
                    stopInternal()
                } else publish(deckBRecovering = false, deckBPreparing = false, standbyUri = null)
            }
            return
        }
        standbyRetries[entry.uri] = retry + 1
        val token = standbyGeneration
        BlackBox.log("DECK B RETRY scheduled=${retry + 1}/2 track=${entry.name} reason=$reason")
        handler.postDelayed({
            if (token == standbyGeneration && (snapshot.sessionActive || wasStaged) &&
                (!wasStaged || stagedFirstQueueUri == entry.uri) &&
                standbyEntry?.uri == entry.uri && current?.uri != entry.uri) {
                standbyRecovering = false
                if (wasStaged) preloadNextDeck(previewEntry = entry) else preloadNextDeck(position)
            }
        }, 700L)
    }

    /** In-place live playlist change. Does NOT restart the playing MediaPlayer. */
    private fun replaceUpcomingEntries(expectedUri: String, updated: List<Entry>, shuffle: Boolean, looping: Boolean) {
        handler.post {
            if (!snapshot.sessionActive || current?.uri != expectedUri || player == null) return@post
            val normalized = (listOfNotNull(current) + updated).distinctBy { it.uri }
            val incoming = standbyEntry
            // Once a transition has begun, keep its target until handover so a
            // playlist edit cannot tear down audible deck B mid-crossfade.
            val stable = if (crossfading && incoming != null) (listOf(normalized.first(), incoming) + normalized.drop(1))
                .distinctBy { it.uri } else normalized
            files = stable
            random = shuffle
            repeat = looping
            order = if (shuffle && !crossfading) listOf(0) + files.indices.drop(1).shuffled() else files.indices.toList()
            orderPosition = 0
            unplayableStandbyUris.retainAll(files.map { it.uri }.toSet())
            val next = nextOrderPosition()
            val wanted = order.getOrNull(next)?.let { files.getOrNull(it)?.uri }
            if (!crossfading) {
                if (transitionRequested && wanted != standbyEntry?.uri) transitionRequested = false
                if (standbyEntry?.uri != wanted) preloadNextDeck() else standbyOrderPosition = next
            } else if (incoming != null) {
                standbyOrderPosition = order.indices.firstOrNull { files.getOrNull(order[it])?.uri == incoming.uri } ?: -1
            }
            BlackBox.log("QUEUE LIVE UPDATE size=${files.size} next=${wanted ?: "none"} active=${current?.name} preserved=true")
            publish(random = random, repeat = repeat)
            updateNotification()
        }
    }

    private fun appendStandbyEntry(entry: Entry): Boolean {
        if (!snapshot.sessionActive || current?.uri != snapshot.trackUri || player == null) return false
        if (files.any { it.uri == entry.uri }) return false
        files = files + entry
        // The new entry is next in the existing playback order, not a new session.
        val index = files.lastIndex
        order = order + index
        BlackBox.log("DECK B DYNAMIC PLAYLIST ADD track=${entry.name} index=$index")
        if (!crossfading) preloadNextDeck()
        return true
    }

    private fun enqueueNextPriority(entry: Entry) {
        handler.post {
            if (!snapshot.sessionActive || player == null || current == null || entry.uri == current?.uri) return@post
            if (crossfading) {
                priorityAfterHandover.removeAll { it.uri == entry.uri }
                priorityAfterHandover.add(entry)
                BlackBox.log("PRIORITY NEXT deferred until current crossfade finishes track=${entry.name}")
                return@post
            }
            insertPriorityNow(entry)
        }
    }

    /** Called only after the WEB/QUEUE save is durably persisted.
     * Use the same priority-next and ExoPlayer A/B transport as a normal NEXT,
     * but request a *soft automatic crossfade* without changing the user's
     * selected manual/auto mixer preference. Never restart deck A.
     */
    private fun enqueueSavedWebTransition(entry: Entry) {
        handler.post {
            if (!snapshot.sessionActive || player == null || current == null || entry.uri == current?.uri) {
                BlackBox.log("WEB SAVE AUTO MIX skipped no active/eligible deck track=${entry.name}")
                return@post
            }
            if (crossfading) {
                priorityAfterHandover.removeAll { it.uri == entry.uri }
                priorityAfterHandover.add(entry)
                savedWebMixAfterHandoverUri = entry.uri
                BlackBox.log("WEB SAVE AUTO MIX deferred until handover track=${entry.name}")
                return@post
            }
            insertPriorityNow(entry)
            if (standbyEntry?.uri != entry.uri || !snapshot.playing) {
                BlackBox.log("WEB SAVE AUTO MIX staged only track=${entry.name} audible=${snapshot.playing}")
                return@post
            }
            transitionRequested = true
            BlackBox.log("WEB SAVE AUTO MIX requested A->B track=${entry.name} standbyReady=$standbyPrepared")
            // beginCrossfade primes ExoPlayer B silently and waits for actual
            // playback before fading A. For an unresolved B, the prepared
            // callback and service ticker honor transitionRequested later.
            if (standbyPrepared) beginCrossfade()
        }
    }

    private fun insertPriorityNow(entry: Entry) {
        val active = current ?: return
        if (!snapshot.sessionActive || player == null || entry.uri == active.uri) return
        // The latest explicit choice takes the NEXT position. Existing items
        // retain their sequence, with duplicates removed by URI.
        val following = order.drop((orderPosition + 1).coerceAtLeast(0))
            .mapNotNull { files.getOrNull(it) }
        files = (listOf(active, entry) + following).distinctBy { it.uri }
        order = files.indices.toList()
        orderPosition = 0
        stagedFirstQueueUri = null
        // One explicit queued item takes precedence over RANDOMIZE for the
        // very next handover, without changing the saved shuffle preference.
        transitionRequested = false
        unplayableStandbyUris.remove(entry.uri)
        val preserved = standbyEntry?.uri == entry.uri
        BlackBox.log("PRIORITY NEXT inserted track=${entry.name} source=web_or_queue standbyPreserved=$preserved")
        preloadNextDeck(1)
        updateNotification()
    }

    /** Reserve B for the selected QUEUE first track without joining active playback. */
    private fun stageFirstQueued(entry: Entry?) {
        handler.post {
            if (entry == null) {
                if (stagedFirstQueueUri != null) {
                    val oldUri = stagedFirstQueueUri
                    stagedFirstQueueUri = null
                    if (standbyOrderPosition == -1 && standbyEntry?.uri == oldUri) clearStandby()
                    if (!snapshot.sessionActive) stopInternal()
                }
                return@post
            }
            if (entry.uri == current?.uri) {
                // The first QUEUE track is already on deck A.
                if (stagedFirstQueueUri != null) {
                    stagedFirstQueueUri = null
                    if (standbyOrderPosition == -1) clearStandby()
                }
                return@post
            }
            // Never interrupt an in-flight transition or replace the normal
            // next song of an active, multi-track playlist.
            if (crossfading || transitionRequested || nextOrderPosition() >= 0) {
                BlackBox.log("QUEUE FIRST PREBUFFER deferred active next or transition track=${entry.name}")
                return@post
            }
            if (standbyEntry?.uri == entry.uri && standbyOrderPosition == -1 &&
                (standbyPrepared || standbyJob?.isActive == true || standbyPlayer != null)) return@post
            stagedFirstQueueUri = entry.uri
            BlackBox.log("QUEUE FIRST PREBUFFER requested deck=B track=${entry.name} playbackUntouched=true")
            preloadNextDeck(previewEntry = entry)
        }
    }

    private fun nextPlayableOrderPosition(after: Int): Int {
        if (order.isEmpty()) return -1
        for (offset in 1..order.size) {
            val candidate = after + offset
            if (!repeat && candidate >= order.size) return -1
            val position = ((candidate % order.size) + order.size) % order.size
            val entry = order.getOrNull(position)?.let { files.getOrNull(it) } ?: continue
            if (entry.uri !in unplayableStandbyUris) return position
        }
        return -1
    }

    private fun nextOrderPosition(): Int = nextPlayableOrderPosition(orderPosition)

    private fun cancelFollowingUrlWarmup() {
        followingUrlJob?.cancel()
        followingUrlJob = null
        followingUrlUri = null
    }

    /** Pre-resolve the track AFTER the loaded standby deck.
     * Only its short-lived CDN address is cached: there is no third player,
     * no extra audible deck, and no change to QUEUE order or crossfade rules.
     * The next handover can reuse this URL without another full extraction.
     */
    private fun warmFollowingStreamUrl() {
        if (!snapshot.sessionActive || !snapshot.playing || !standbyPrepared ||
            crossfading || standbyRecovering || bufferingA) return
        val readyEntry = standbyEntry ?: return
        // No speculative extraction may steal bandwidth from an unbuffered B.
        if (isStream(readyEntry) && standbyLastRawPercent < MANUAL_MIX_BUFFER_PERCENT) return
        val nextAfterStandby = standbyOrderPosition.takeIf { it in order.indices } ?: return
        val nextPosition = nextPlayableOrderPosition(nextAfterStandby)
        val upcoming = order.getOrNull(nextPosition)?.let { files.getOrNull(it) } ?: return
        if (!isStream(upcoming) || upcoming.uri == current?.uri || upcoming.uri == standbyEntry?.uri) return
        if (followingUrlUri == upcoming.uri) return
        cancelFollowingUrlWarmup()
        followingUrlUri = upcoming.uri
        val entryUri = upcoming.uri
        BlackBox.log("TURBO URL WARMUP start for following QUEUE entry")
        followingUrlJob = resolverScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val id = if (entryUri.startsWith("https://www.youtube.com/watch?v="))
                        BmqCodec.extractId(entryUri) ?: error("Invalid YouTube ID")
                    else BmqCodec.readReference(applicationContext, Uri.parse(entryUri))
                    ProStreamResolver.resolveAudio(id)
                }
            }
            if (followingUrlUri == entryUri) {
                BlackBox.log(if (result.isSuccess) "TURBO URL WARMUP ready" else "TURBO URL WARMUP skipped (extractor failure)")
                // Failure is nonfatal. Normal deck-B load retries as before.
            }
        }
    }

    private fun preloadNextDeck(targetOrderPosition: Int? = null, previewEntry: Entry? = null) {
        val nextPosition = if (previewEntry != null) -1 else targetOrderPosition ?: nextOrderPosition()
        val nextIndex = if (nextPosition >= 0) order.getOrNull(nextPosition) else null
        val entry = previewEntry ?: nextIndex?.let { files.getOrNull(it) }
        // The usual active-deck onPrepared() call must not erase an independent
        // staged QUEUE buffer when the playing playlist has no NEXT track.
        if (entry == null && previewEntry == null && stagedFirstQueueUri != null &&
            standbyOrderPosition == -1 && standbyEntry?.uri == stagedFirstQueueUri) return
        if (entry != null && standbyEntry?.uri == entry.uri &&
            (standbyPrepared || standbyJob?.isActive == true || standbyPlayer != null)) {
            standbyOrderPosition = nextPosition
            if (previewEntry == null && stagedFirstQueueUri == entry.uri) stagedFirstQueueUri = null
            BlackBox.log("DECK B PRELOAD PRESERVED track=${entry.name} ready=$standbyPrepared")
            return
        }
        cancelFollowingUrlWarmup()
        if (crossfading) {
            BlackBox.log("CROSSFADE CANCEL reason=next_changed current=${current?.name} target=${standbyEntry?.name}")
            crossfading = false
            manualOverlap = false
            crossfader = -1f
            runCatching { player?.setVolume(volume, volume) }
            publish(crossfading = false, crossfader = -1f)
        }
        standbyGeneration++
        standbyJob?.cancel(); standbyJob = null
        selectionPrimedDeck = null
        // Do not stop/release the audible deck. Only B is reusable.
        standbyPlayer?.let { runCatching { it.stop() } }
        standbyEntry = null
        standbyPrepared = false
        standbyRecovering = false
        standbyStartedAt = 0L
        standbyLoadStartedAt = 0L
        standbyLastProgressAt = 0L
        standbyLastRawPercent = 0
        if (manualMixRequested) BlackBox.log("MANUAL MIX REQUEST CANCELLED reason=standby_replaced")
        manualMixRequested = !autoMix && crossfader > -0.999f
        standbyOrderPosition = -1
        bufferingB = false
        bufferedPercentB = 0
        if (entry == null) {
            standbyPlayer?.let { runCatching { it.release() } }
            standbyPlayer = null
            publish(deckBReady = false, deckBPreparing = false, deckBRecovering = false,
                bufferedPercentB = 0, bufferingB = false, standbyUri = null)
            return
        }
        standbyOrderPosition = nextPosition
        if (previewEntry == null) stagedFirstQueueUri = null
        standbyEntry = entry
        standbyLoadStartedAt = SystemClock.elapsedRealtime()
        standbyLastProgressAt = standbyLoadStartedAt
        standbyLastRawPercent = 0
        standbyHealthCheckLogged = false
        val token = standbyGeneration
        BlackBox.log("DECK B PRELOAD BEGIN index=${nextIndex} track=${entry.name}")
        publish(deckBReady = false, deckBPreparing = true, deckBRecovering = false,
            bufferedPercentB = 0, bufferingB = false, standbyUri = entry.uri)
        if (!isStream(entry)) {
            prepareResolvedSource(entry, null, standby = true, reusable = standbyPlayer)
            return
        }
        val resolveStarted = SystemClock.elapsedRealtime()
        standbyJob = resolverScope.launch {
            val resolved = withContext(Dispatchers.IO) {
                runCatching {
                    val id = if (entry.uri.startsWith("https://www.youtube.com/watch?v="))
                        BmqCodec.extractId(entry.uri) ?: error("Invalid YouTube ID")
                    else BmqCodec.readReference(applicationContext, Uri.parse(entry.uri))
                    ProStreamResolver.resolveAudio(id)
                }
            }
            if (token != standbyGeneration || standbyEntry?.uri != entry.uri) return@launch
            BlackBox.log("BMQ RESOLVE DURATION track=${entry.name} durationMs=${SystemClock.elapsedRealtime() - resolveStarted} deck=B")
            resolved.onSuccess { prepareResolvedSource(entry, it, standby = true, reusable = standbyPlayer) }
                .onFailure {
                    BlackBox.log("DECK B RESOLVE FAILED track=${entry.name} ${it.javaClass.simpleName}; active deck continues")
                    if (manualMixRequested) BlackBox.log("MANUAL MIX REQUEST FAILED reason=standby_source_resolution_failed track=${entry.name}")
                    // Keep A playing; clear the failed B load and let queue advance at completion.
                    recoverStandby(entry, standbyOrderPosition, "resolve")
                }
        }
    }

    private fun beginCrossfade() {
        val next = standbyPlayer ?: return
        val entry = standbyEntry ?: return
        // When A is already audible (even if A itself has begun buffering),
        // only B must be playable. Waiting for A to rebuffer defeats NEXT.
        if (!standbyPrepared || crossfading || player == null) return
        // Long recordings, including DJ MIX, must have three real seconds of
        // data before any transition (including a user-pressed NEXT). For
        // ordinary songs the existing READY priming avoids a false 0% stall.
        if ((standbyPlayer?.duration ?: 0) > 480_000 && !isStandbyBufferEnough()) return
        if (transitionRequested) {
            // Media3 STATE_READY means this deck can begin playback, even
            // when its reported buffered-duration percentage is still zero.
            // Do not fade A until B becomes *audibly advancing* (isPlaying).
            if (!runCatching { next.isPlaying }.getOrDefault(false)) {
                if (selectionPrimedDeck !== next) {
                    selectionPrimedDeck = next
                    try {
                        next.setVolume(0f, 0f)
                        next.start()
                        BlackBox.log("UNIFIED SELECT B PRIMED awaiting isPlaying track=${entry.name} meter=${bufferedPercentB}%")
                    } catch (error: Exception) {
                        selectionPrimedDeck = null
                        recoverStandby(entry, standbyOrderPosition, "selected_prime_failed")
                    }
                }
                return
            }
        } else if (!isStandbyBufferEnough()) return
        try {
            selectionPrimedDeck = null
            releaseRollEffectInternal()
            next.setVolume(0f, 0f)
            if (!next.isPlaying) next.start()
            standbyStartedAt = SystemClock.elapsedRealtime()
            crossfading = true
            crossfadeStartedAt = SystemClock.elapsedRealtime()
            crossfadePausedElapsed = 0L
            BlackBox.log("CROSSFade START from=${current?.name} to=${entry.name} seconds=$crossfadeSeconds mode=${if (transitionRequested) "requested" else "auto"}")
            publish(crossfading = true)
        } catch (error: Throwable) {
            BlackBox.audioFailure("crossfade standby start", entry.name, error)
            BlackBox.log("CROSSFade START FAILED track=${entry.name}; continue A")
            recoverStandby(entry, standbyOrderPosition, "crossfade_start")
        }
    }

    private fun updateCrossfade() {
        val durationMs = crossfadeSeconds * 1000L
        val fraction = ((SystemClock.elapsedRealtime() - crossfadeStartedAt).toFloat() / durationMs).coerceIn(0f, 1f)
        val oldGain = kotlin.math.cos(fraction * (Math.PI / 2.0)).toFloat()
        val newGain = kotlin.math.sin(fraction * (Math.PI / 2.0)).toFloat()
        player?.let { runCatching { it.setVolume(volume * oldGain, volume * oldGain) } }
        standbyPlayer?.let { runCatching { it.setVolume(volume * newGain, volume * newGain) } }
        crossfader = (fraction * 2f - 1f).coerceIn(-1f, 1f)
        publish(crossfader = crossfader)
        if (fraction >= 1f) {
            BlackBox.log("CROSSFade END from=${current?.name} to=${standbyEntry?.name}")
            promoteStandby()
        }
    }

    private fun promoteStandby() {
        releaseRollEffectInternal()
        val promoted = standbyPlayer ?: return
        val entry = standbyEntry ?: return
        selectionPrimedDeck = null
        val completedManualMix = manualOverlap && !autoMix
        val wasAlreadyPlaying = runCatching { promoted.isPlaying }.getOrDefault(false)
        val promotedStartedAt = standbyStartedAt
        // Capture B's real readiness BEFORE zeroing the new empty standby B.
        // Otherwise A displays 0% after promotion and WAIT never clears.
        val promotedBufferedPercent = bufferedPercentB
        val promotedBuffering = bufferingB
        val oldActive = player
        val nextOrderPosition = standbyOrderPosition
        if (oldActive != null) {
            // As soon as the fader reaches B, flush the previous song's
            // decoded audio and reset that physical player for the next preload.
            // Never touch the promoted/playing player's buffer.
            runCatching { oldActive.stop() }
            runCatching { oldActive.reset() }
            BlackBox.log("MANUAL/AUTO HANDOVER old A buffer flushed; physical deck available for B preload")
        }
        player = promoted
        playerPrepared = true
        standbyPlayer = oldActive
        standbyEntry = null
        standbyPrepared = false
        standbyStartedAt = 0L
        standbyLoadStartedAt = 0L
        standbyLastProgressAt = 0L
        standbyLastRawPercent = 0
        standbyHealthCheckLogged = false
        manualMixRequested = false
        bufferingB = false
        standbyOrderPosition = -1
        current = entry
        streamTrack = isStream(entry)
        lastAudioFailure = null
        unplayableStandbyUris.remove(entry.uri)
        standbyRetries.remove(entry.uri)
        standbyLastProgressAt = 0L
        standbyLastRawPercent = 0
        orderPosition = nextOrderPosition.takeIf { it in order.indices } ?: (orderPosition + 1)
        if (randomRebuildAfterHandover) {
            randomRebuildAfterHandover = false
            val currentIndex = files.indexOfFirst { it.uri == entry.uri }.takeIf { it >= 0 }
            rebuildOrder(currentIndex)
            BlackBox.log("QUEUE RANDOMIZE deferred reorder applied after handover")
        }
        transitionRequested = false
        crossfading = false
        val savedWebMixTarget = savedWebMixAfterHandoverUri
        savedWebMixAfterHandoverUri = null
        if (priorityAfterHandover.isNotEmpty()) {
            val waiting = priorityAfterHandover.toList()
            priorityAfterHandover.clear()
            // Oldest queued first, with the most recent request directly NEXT.
            waiting.forEach { pending ->
                if (pending.uri != current?.uri) {
                    val nextItems = order.drop(orderPosition + 1).mapNotNull { files.getOrNull(it) }
                    files = (listOfNotNull(current, pending) + nextItems).distinctBy { it.uri }
                    order = files.indices.toList()
                    orderPosition = 0
                }
            }
        }
        bufferingA = promotedBuffering
        bufferingB = false
        manualOverlap = false
        crossfader = -1f
        configuredCrossfader = -1f
        if (completedManualMix) manualMixCompletions++
        if (completedManualMix) manualFaderAwaitingRelease = true
        // After swapping roles, the audible promoted deck is A. Preserve its
        // already confirmed buffer; only the vacated standby deck starts at 0%.
        bufferedPercentA = promotedBufferedPercent
        bufferedPercentB = 0
        BlackBox.log("DECK BUFFER HANDOVER A=${bufferedPercentA}% B=0%; standby refill starts immediately")
        if (!wasAlreadyPlaying) {
            runCatching { promoted.setVolume(volume, volume); promoted.start() }
                .onFailure { failCurrent(promoted, "standby promotion start", it); return }
        }
        startedAudioAt = if (wasAlreadyPlaying && promotedStartedAt > 0L) promotedStartedAt else SystemClock.elapsedRealtime()
        onTrackChanged?.invoke(entry.uri)
        val duration = runCatching { promoted.duration }.getOrDefault(0).coerceAtLeast(0)
        val position = runCatching { promoted.currentPosition }.getOrDefault(0).coerceAtLeast(0)
        BlackBox.log("PLAYER ROLE SWAP A=${entry.name} queueIndex=${orderPosition} sessionPreserved=true")
        publish(trackUri = entry.uri, trackName = entry.name, preparing = false, playing = true,
            position = position, duration = duration, deckAReady = true, deckBReady = false, deckBPreparing = false,
            crossfading = false, crossfader = -1f, manualMixCompletions = manualMixCompletions,
            bufferedPercentA = bufferedPercentA, bufferedPercentB = 0,
            bufferingA = bufferingA, bufferingB = false)
        applyDeckVolumes()
        // Start filling the vacated physical deck with the next QUEUE item
        // immediately, independent of how much is left in the audible track.
        // The slider stays disabled / WAIT visible until deck B is ready.
        preloadNextDeck()
        if (savedWebMixTarget != null && snapshot.playing && standbyEntry?.uri == savedWebMixTarget) {
            transitionRequested = true
            BlackBox.log("WEB SAVE AUTO MIX resumed after handover track=${standbyEntry?.name}")
            if (standbyPrepared) beginCrossfade()
        }
        updateNotification()
        if (nextAfterHandover) {
            nextAfterHandover = false
            BlackBox.log("UNIFIED NEXT resumed after handover")
            handler.post { nextInternal() }
        }
    }

    /** An 8-minute boundary is measured from Media3 metadata, not the full-
     * duration buffer percent. Long mixes need 3 real seconds ahead;
     * regular songs retain the original 2% of the 40-second window (800ms).
     */
    private fun isStandbyBufferEnough(): Boolean {
        val deck = standbyPlayer ?: return false
        if (!standbyPrepared) return false
        val duration = runCatching { deck.duration }.getOrDefault(0)
        val requiredMs = if (duration > 8 * 60_000) 3_000L else 800L
        return deck.bufferedAheadMs >= requiredMs || (!isStream(standbyEntry ?: return false) && bufferedPercentB >= 2)
    }

    private fun standbyActuallyReady(): Boolean {
        val p = standbyPlayer ?: return false
        val entry = standbyEntry ?: return false
        return standbyPrepared && isStandbyBufferEnough() && standbyOrderPosition >= 0 && !snapshot.deckBPreparing &&
            runCatching { p.duration >= 0 }.getOrDefault(false) && standbyEntry?.uri == entry.uri
    }

    private fun tryStartManualMix(reason: String): Boolean {
        if (autoMix) {
            BlackBox.log("MANUAL MIX REQUEST REJECTED reason=automatic_mode reasonAt=$reason")
            return false
        }
        if (crossfading && manualOverlap) return true
        val active = player
        val standby = standbyPlayer
        val entry = standbyEntry
        val failure = when {
            active == null -> "active_deck_missing"
            !playerPrepared -> "active_deck_not_prepared"
            bufferedPercentA < MANUAL_MIX_BUFFER_PERCENT && bufferingA -> "active_deck_buffer_below_${MANUAL_MIX_BUFFER_PERCENT}pct"
            !isStandbyBufferEnough() -> "standby_deck_buffer_below_${if ((standby?.duration ?: 0) > 480_000) "3sec" else "2pct"}"
            !runCatching { active.isPlaying }.getOrDefault(false) -> "active_deck_not_playing"
            entry == null -> "standby_track_missing"
            standby == null -> "standby_player_missing"
            standbyOrderPosition < 0 -> "standby_queue_position_invalid"
            !standbyPrepared -> "standby_onPrepared_not_received"
            snapshot.deckBPreparing -> "standby_snapshot_still_preparing"
            !runCatching { standby.duration >= 0 }.getOrDefault(false) -> "standby_player_not_queryable"
            else -> null
        }
        if (failure != null) {
            BlackBox.log("MANUAL MIX REQUEST WAIT reason=$failure detail=$reason track=${entry?.name ?: "unknown"} deckBReady=$standbyPrepared bufferingB=$bufferingB")
            return false
        }
        val readyStandby = standby ?: return false
        try {
            releaseRollEffectInternal()
            if (!runCatching { readyStandby.isPlaying }.getOrDefault(false)) {
                readyStandby.setVolume(0f, 0f)
                readyStandby.start()
            }
            standbyStartedAt = SystemClock.elapsedRealtime()
            manualOverlap = true
            manualMixRequested = true
            crossfading = true
            crossfadeStartedAt = SystemClock.elapsedRealtime()
            crossfadePausedElapsed = 0L
            BlackBox.log("MANUAL MIX START from=${current?.name} to=${entry?.name} reason=$reason deckBActuallyReady=true")
            publish(crossfading = true)
            return true
        } catch (error: Throwable) {
            BlackBox.audioFailure("manual mix start", entry?.name, error)
            BlackBox.log("MANUAL MIX REQUEST FAILED reason=standby_start_exception detail=${error.javaClass.simpleName}:${error.message}")
            return false
        }
    }

    private fun applyDeckVolumes() {
        if (crossfading && !manualOverlap) return
        if (!autoMix && manualMixRequested && !manualOverlap) tryStartManualMix("apply_deck_volumes")
        val canUseStandby = manualOverlap || (standbyActuallyReady() &&
            (autoMix || ((bufferedPercentA >= MANUAL_MIX_BUFFER_PERCENT || (snapshot.playing && !bufferingA)) &&
                isStandbyBufferEnough())))
        val normalized = if (!canUseStandby) 0f
            else ((crossfader + 1f) / 2f).coerceIn(0f, 1f)
        val gainA = kotlin.math.cos(normalized * (Math.PI / 2.0)).toFloat()
        val gainB = kotlin.math.sin(normalized * (Math.PI / 2.0)).toFloat()
        player?.let { runCatching { it.setVolume(volume * gainA, volume * gainA) } }
        standbyPlayer?.let { runCatching { it.setVolume(volume * gainB, volume * gainB) } }
        if (manualOverlap && crossfader >= 0.999f) {
            BlackBox.log("MANUAL MIX END from=${current?.name} to=${standbyEntry?.name} reason=fader_full_right")
            promoteStandby()
        }
    }

    private fun settleManualOverlap() {
        if (!manualOverlap) return
        val start = ((crossfader + 1f) / 2f).coerceIn(0f, 1f)
        val began = SystemClock.elapsedRealtime()
        val duration = 280L
        crossfading = false
        manualOverlap = false
        fun tick() {
            val t = ((SystemClock.elapsedRealtime() - began).toFloat() / duration).coerceIn(0f, 1f)
            val x = start * (1f - t)
            val gainA = kotlin.math.cos(x * (Math.PI / 2.0)).toFloat()
            val gainB = kotlin.math.sin(x * (Math.PI / 2.0)).toFloat()
            player?.let { runCatching { it.setVolume(volume * gainA, volume * gainA) } }
            standbyPlayer?.let { runCatching { it.setVolume(volume * gainB, volume * gainB) } }
            if (t < 1f) handler.postDelayed({ tick() }, 20L) else {
                standbyPlayer?.let { runCatching { it.pause() }; runCatching { it.seekTo(0) }; runCatching { it.setVolume(0f, 0f) } }
                crossfader = -1f
                publish(crossfading = false, crossfader = -1f)
                BlackBox.log("MANUAL CROSSFade END settled=true autoResume=true")
            }
        }
        tick()
    }

    private fun setMixerInternal(position: Float, automatic: Boolean, seconds: Int) {
        handler.post {
            val previousAuto = autoMix
            val requestedPosition = position.coerceIn(-1f, 1f)
            if (automatic) {
                manualFaderAwaitingRelease = false
            } else if (manualFaderAwaitingRelease) {
                // Ignore any queued B-side slider callbacks while the user's
                // finger is still down. The UI sends A once that gesture ends.
                if (requestedPosition <= -0.999f) {
                    manualFaderAwaitingRelease = false
                } else {
                    crossfader = -1f
                    manualMixRequested = false
                    publish(crossfader = -1f, autoMix = false, crossfadeSeconds = crossfadeSeconds)
                    return@post
                }
            }
            crossfader = if (automatic) requestedPosition else requestedPosition.coerceIn(crossfader, 1f)
            autoMix = automatic
            crossfadeSeconds = seconds.coerceIn(1, 12)
            if (automatic) {
                manualMixRequested = false
                if (manualOverlap) {
                    settleManualOverlap()
                    suppressAutoCrossfadeUntil = SystemClock.elapsedRealtime() + 1_000L
                    publish(crossfader = crossfader, autoMix = true, crossfadeSeconds = crossfadeSeconds)
                    BlackBox.log("MANUAL MIX END mode=automatic return=smooth settleMs=280 autoResumeDelayMs=1000")
                    return@post
                }
                if (!previousAuto && crossfader > -0.999f) {
                    // A was never mixed if B was not ready. Reset the logical fader
                    // without starting an unwanted transition.
                    crossfader = -1f
                    runCatching { player?.setVolume(volume, volume) }
                    BlackBox.log("MANUAL MIX END mode=automatic return=active_deck_only")
                }
            } else {
                // Manual control is one-way: once the gesture leaves A it can
                // advance toward B, but never pull the mix back toward A.
                manualMixRequested = crossfader > -0.999f
                if (crossfading && !manualOverlap) {
                    // Take over an automatic transition from its current real gains.
                    manualOverlap = true
                    BlackBox.log("MANUAL MIX TAKEOVER from_automatic=true")
                } else if (manualMixRequested && !manualOverlap) {
                    tryStartManualMix("fader_gesture")
                }
                applyDeckVolumes()
            }
            publish(crossfader = crossfader, autoMix = autoMix, crossfadeSeconds = crossfadeSeconds)
            BlackBox.log("MIXER CONFIG crossfader=$crossfader auto=$autoMix seconds=$crossfadeSeconds")
        }
    }

    private fun seekInternal(value: Int) {
        handler.post {
            val p = player ?: return@post
            if (!playerPrepared || snapshot.preparing || snapshot.duration <= 0) return@post
            val target = value.coerceIn(0, snapshot.duration)
            runCatching { p.seekTo(target) }
            publish(position = target)
        }
    }

    private fun nextInternal() {
        handler.post {
            if (!snapshot.sessionActive) return@post
            if (crossfading) {
                nextAfterHandover = true
                BlackBox.log("UNIFIED NEXT queued during A/B transition target=${standbyEntry?.name}")
                return@post
            }
            val target = if (transitionRequested && standbyOrderPosition >= 0 &&
                standbyEntry?.uri !in unplayableStandbyUris) standbyOrderPosition else nextOrderPosition()
            if (target < 0) { BlackBox.log("QUEUE MANUAL NEXT ignored at end index=$orderPosition size=${order.size}"); return@post }
            BlackBox.log("QUEUE MANUAL NEXT index=$orderPosition target=$target size=${order.size} standby=${standbyEntry?.name} keepActive=true")
            transitionRequested = true
            // NEXT must be actionable even when the same stalled resolver/player
            // would otherwise be "preserved" by preloadNextDeck().  Never touch A.
            val desired = order.getOrNull(target)?.let { files.getOrNull(it) }
            val stalled = standbyEntry
            if (stalled != null && stalled.uri == desired?.uri &&
                !standbyRecovering && standbyLoadStartedAt > 0L &&
                SystemClock.elapsedRealtime() - standbyLastProgressAt >= standbyHealthCheckMs &&
                (!standbyPrepared || (isStream(stalled) &&
                    standbyLastRawPercent < (if (autoMix) MIN_MIX_BUFFER_PERCENT else MANUAL_MIX_BUFFER_PERCENT)))) {
                BlackBox.log("QUEUE NEXT FORCE RECOVERY track=${stalled.name} waitMs=${SystemClock.elapsedRealtime() - standbyLoadStartedAt} keepActive=true")
                recoverStandby(stalled, target, "next_pressed_stalled_preload")
                return@post
            }
            if (standbyPrepared && standbyOrderPosition == target) {
                if (snapshot.playing) beginCrossfade()
                else standbyPlayer?.let { ready ->
                    if (!acquireAudioFocus()) {
                        BlackBox.log("QUEUE MANUAL NEXT waiting for audio focus track=${standbyEntry?.name}")
                        return@let
                    }
                    runCatching { ready.setVolume(volume, volume); ready.start() }
                        .onSuccess { standbyStartedAt = SystemClock.elapsedRealtime(); promoteStandby() }
                        .onFailure { recoverStandby(standbyEntry ?: return@let, target, "manual_next_start") }
                }
            } else preloadNextDeck(target)
        }
    }

    private fun previousInternal() {
        handler.post {
            if (!snapshot.sessionActive || order.isEmpty()) return@post
            BlackBox.log("QUEUE MANUAL PREVIOUS index=$orderPosition previous=${orderPosition - 1} size=${order.size}")
            val prev = if (orderPosition > 0) orderPosition - 1 else if (repeat) order.lastIndex else -1
            if (prev >= 0) {
                if (crossfading) {
                    crossfading = false
                    manualOverlap = false
                    crossfader = -1f
                    runCatching { player?.setVolume(volume, volume) }
                    publish(crossfading = false, crossfader = -1f)
                }
                transitionRequested = true
                BlackBox.log("QUEUE MANUAL PREVIOUS index=$orderPosition target=$prev keepActive=true")
                if (standbyPrepared && standbyOrderPosition == prev) beginCrossfade() else preloadNextDeck(prev)
            } else if (snapshot.position > 3000) {
                seekInternal(0)
            } else if (repeat) {
                releasePlayer()
                orderPosition = order.lastIndex
                playIndex(order[orderPosition])
            } else {
                seekInternal(0)
            }
        }
    }

    private fun toggleInternal() {
        handler.post {
            val p = player ?: return@post
            if (!playerPrepared || snapshot.preparing) return@post
            if (snapshot.playing) {
                resumeAfterTemporaryFocusLoss = false
                runCatching { p.pause() }
                if (crossfading) {
                    standbyPlayer?.let { runCatching { it.pause() } }
                    crossfadePausedElapsed = SystemClock.elapsedRealtime() - crossfadeStartedAt
                }
                publish(playing = false)
                releaseAudioFocus()
            } else if (acquireAudioFocus()) {
                runCatching { p.start() }.onSuccess {
                    if (crossfading) standbyPlayer?.let { runCatching { it.start() } }
                    if (crossfading) crossfadeStartedAt = SystemClock.elapsedRealtime() - crossfadePausedElapsed
                    resumeAfterTemporaryFocusLoss = false
                    publish(playing = true)
                }
            }
            updateNotification()
        }
    }

    private fun refreshStandbyIfNextChanged() {
        if (!playerPrepared || !snapshot.sessionActive) return
        if (crossfading) {
            BlackBox.log("QUEUE ORDER CHANGE deferred: preserving currently audible transition")
            return
        }
        val nextPosition = nextOrderPosition()
        val nextUri = order.getOrNull(nextPosition)?.let { files.getOrNull(it)?.uri }
        if (nextUri == standbyEntry?.uri && nextUri != null) {
            standbyOrderPosition = nextPosition
            BlackBox.log("DECK B PRELOAD PRESERVED reason=playback_order next=${standbyEntry?.name}")
            return
        }
        if (nextUri == null && standbyEntry == null) return
        clearStandby()
        preloadNextDeck()
    }

    private fun setRandomInternal(value: Boolean) {
        handler.post {
            if (random == value) return@post
            random = value
            if (crossfading) {
                randomRebuildAfterHandover = true
                BlackBox.log("QUEUE RANDOMIZE change deferred until A/B handover")
                publish(random = random)
                updateNotification()
                return@post
            }
            val currentIndex = current?.let { now -> files.indexOfFirst { it.uri == now.uri } }?.takeIf { it >= 0 }
            rebuildOrder(currentIndex)
            refreshStandbyIfNextChanged()
            publish(random = random)
            updateNotification()
        }
    }

    private fun setRepeatInternal(value: Boolean) {
        handler.post {
            if (repeat == value) return@post
            repeat = value
            refreshStandbyIfNextChanged()
            publish(repeat = repeat)
            updateNotification()
        }
    }

    private fun setVolumeInternal(value: Float) {
        handler.post {
            volume = value.coerceIn(0f, 1f)
            applyDeckVolumes()
        }
    }

    private fun stopInternal() {
        releaseRollEffectInternal()
        stagedFirstQueueUri = null
        val stopNow = Runnable {
            BlackBox.log("AUDIO SESSION DESTROY queue=${files.size} track=${current?.name}")
            releasePlayer()
            releaseAudioFocus()
            files = emptyList(); order = emptyList(); orderPosition = -1; current = null
            manualFaderAwaitingRelease = false
            randomRebuildAfterHandover = false
            priorityAfterHandover.clear()
            savedWebMixAfterHandoverUri = null
            unplayableStandbyUris.clear()
            standbyRetries.clear()
            snapshot = Snapshot(random = random, repeat = repeat)
            updatePlaybackState()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        if (Looper.myLooper() == Looper.getMainLooper()) stopNow.run() else handler.post(stopNow)
    }

    private fun releasePlayer(clearB: Boolean = true) {
        releaseRollEffectInternal()
        if (clearB) clearStandby()
        playbackGeneration++
        resolverJob?.cancel()
        resolverJob = null
        val p = player
        player = null
        playerPrepared = false
        if (p != null) {
            val sessionId = runCatching { p.audioSessionId }.getOrDefault(-1)
            BlackBox.log("AUDIO PLAYER DESTROY deck=A audioSessionId=$sessionId deferred=false")
            runCatching { p.release() }
        }
    }

    private fun publish(
        trackUri: String? = snapshot.trackUri,
        trackName: String? = snapshot.trackName,
        preparing: Boolean = snapshot.preparing,
        playing: Boolean = snapshot.playing,
        position: Int = snapshot.position,
        duration: Int = snapshot.duration,
        random: Boolean = snapshot.random,
        repeat: Boolean = snapshot.repeat,
        sessionActive: Boolean = snapshot.sessionActive,
        deckAReady: Boolean = snapshot.deckAReady,
        deckBReady: Boolean = snapshot.deckBReady,
        deckBPreparing: Boolean = snapshot.deckBPreparing,
        deckBRecovering: Boolean = snapshot.deckBRecovering,
        bufferedPercentA: Int = snapshot.bufferedPercentA,
        bufferedPercentB: Int = snapshot.bufferedPercentB,
        bufferingA: Boolean = snapshot.bufferingA,
        bufferingB: Boolean = snapshot.bufferingB,
        crossfading: Boolean = snapshot.crossfading,
        crossfader: Float = snapshot.crossfader,
        manualMixCompletions: Long = snapshot.manualMixCompletions,
        autoMix: Boolean = snapshot.autoMix,
        crossfadeSeconds: Int = snapshot.crossfadeSeconds,
        transitionRequestedState: Boolean = transitionRequested,
        standbyUri: String? = standbyEntry?.uri
    ) {
        snapshot = Snapshot(trackUri, trackName, preparing, playing, position.coerceAtLeast(0), duration.coerceAtLeast(0), random, repeat, sessionActive,
            deckAReady, deckBReady, deckBPreparing, deckBRecovering, bufferedPercentA.coerceIn(0, 100), bufferedPercentB.coerceIn(0, 100),
            bufferingA, bufferingB, crossfading, crossfader, manualMixCompletions, autoMix, crossfadeSeconds, transitionRequestedState, standbyUri,
            isStandbyBufferEnough())
    }

    private fun updatePlaybackState() {
        if (!::mediaSession.isInitialized) return
        val state = when {
            snapshot.preparing -> PlaybackState.STATE_BUFFERING
            snapshot.playing -> PlaybackState.STATE_PLAYING
            snapshot.sessionActive -> PlaybackState.STATE_PAUSED
            else -> PlaybackState.STATE_STOPPED
        }
        val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_STOP or PlaybackState.ACTION_SEEK_TO
        mediaSession.setMetadata(MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, snapshot.trackName ?: "BrakeMonster")
            .putString(MediaMetadata.METADATA_KEY_ARTIST, "BrakeMonster")
            .putLong(MediaMetadata.METADATA_KEY_DURATION, snapshot.duration.toLong())
            .build())
        mediaSession.setPlaybackState(
            PlaybackState.Builder().setActions(actions)
                .setState(state, snapshot.position.toLong(), if (snapshot.playing) 1f else 0f).build()
        )
    }

    private fun createChannel() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "BreakMonster playback", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Keeps BreakMonster music playing in the background"
                setShowBadge(false)
            }
        )
    }

    private fun servicePendingIntent(action: String, requestCode: Int): PendingIntent = PendingIntent.getService(
        this, requestCode, Intent(this, BreakPlaybackService::class.java).setAction(action),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun buildNotification(title: String, playing: Boolean): Notification {
        val openApp = PendingIntent.getActivity(
            this, 10, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val playPauseIcon = if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val playPauseLabel = if (playing) "Pause" else "Play"
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_play)
            .setContentTitle(title.ifBlank { "BreakMonster" })
            .setContentText(lastAudioFailure?.let { "AUDIO ERROR · Open MIXER > BLACK BOX" } ?: "BreakMonster player")
            .setContentIntent(openApp)
            .setOngoing(playing || snapshot.preparing)
            .setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(Notification.Action.Builder(playPauseIcon, playPauseLabel, servicePendingIntent(ACTION_TOGGLE, 11)).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_previous, "Previous", servicePendingIntent(ACTION_PREVIOUS, 14)).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_next, "Next", servicePendingIntent(ACTION_NEXT, 12)).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Stop", servicePendingIntent(ACTION_STOP, 13)).build())
            .setStyle(Notification.MediaStyle().setMediaSession(mediaSession.sessionToken).setShowActionsInCompactView(0, 2))
            .build()
    }

    private fun updateNotification() {
        if (!snapshot.sessionActive) return
        updatePlaybackState()
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(snapshot.trackName ?: "BreakMonster", snapshot.playing))
    }

    // HOME/minimize keeps playback. Removing the app task is an explicit close: stop and release.
    override fun onTaskRemoved(rootIntent: Intent?) {
        stopInternal()
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        BlackBox.log("AUDIO SERVICE destroyed queue=${files.size} track=${current?.name}")
        resolverScope.cancel()
        handler.removeCallbacks(ticker)
        releasePlayer()
        releaseAudioFocus()
        if (::mediaSession.isInitialized) {
            mediaSession.isActive = false
            mediaSession.release()
        }
        if (activeInstance === this) activeInstance = null
        snapshot = Snapshot(random = random, repeat = repeat)
        super.onDestroy()
    }
}
