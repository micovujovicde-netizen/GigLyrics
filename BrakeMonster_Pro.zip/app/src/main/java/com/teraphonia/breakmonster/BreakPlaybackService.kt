package com.teraphonia.breakmonster

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.audiofx.Visualizer
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class BreakPlaybackService : Service() {
    data class Entry(val uri: String, val name: String)
    data class StartRequest(
        val files: List<Entry>,
        val selectedUri: String?,
        val random: Boolean,
        val repeat: Boolean,
        val volume: Float,
        val crossfader: Float = -1f,
        val autoMix: Boolean = false,
        val crossfadeSeconds: Int = 6
    )
    data class Snapshot(
        val trackUri: String? = null,
        val trackName: String? = null,
        val preparing: Boolean = false,
        val playing: Boolean = false,
        val position: Int = 0,
        val duration: Int = 0,
        val random: Boolean = false,
        val repeat: Boolean = false,
        val sessionActive: Boolean = false,
        val deckAReady: Boolean = false,
        val deckBReady: Boolean = false,
        val deckBPreparing: Boolean = false,
        val meterAAvailable: Boolean = false,
        val meterBAvailable: Boolean = false,
        val crossfading: Boolean = false,
        val levelA: Float = 0f,
        val levelB: Float = 0f,
        val crossfader: Float = 0f,
        val autoMix: Boolean = false,
        val crossfadeSeconds: Int = 6
    )

    companion object {
        private const val CHANNEL_ID = "breakmonster_playback"
        private const val NOTIFICATION_ID = 9207
        private const val ACTION_START = "com.teraphonia.breakmonster.START"
        private const val ACTION_TOGGLE = "com.teraphonia.breakmonster.TOGGLE"
        private const val ACTION_PREVIOUS = "com.teraphonia.breakmonster.PREVIOUS"
        private const val ACTION_NEXT = "com.teraphonia.breakmonster.NEXT"
        private const val ACTION_STOP = "com.teraphonia.breakmonster.STOP"
        @Volatile private var configuredCrossfader = -1f
        @Volatile private var configuredAutoMix = false
        @Volatile private var configuredCrossfadeSeconds = 6

        @Volatile private var activeInstance: BreakPlaybackService? = null
        @Volatile private var pendingStart: StartRequest? = null
        @Volatile var onSingleTrackCompleted: (() -> Unit)? = null
        @Volatile var onTrackChanged: ((String) -> Unit)? = null
        @Volatile var snapshot: Snapshot = Snapshot()
            private set

        fun start(context: Context, request: StartRequest) {
            pendingStart = request.copy(
                crossfader = configuredCrossfader,
                autoMix = configuredAutoMix,
                crossfadeSeconds = configuredCrossfadeSeconds
            )
            context.startForegroundService(Intent(context, BreakPlaybackService::class.java).setAction(ACTION_START))
        }
        fun seekTo(value: Int) { activeInstance?.seekInternal(value) }
        fun next() { activeInstance?.nextInternal() }
        fun previous() { activeInstance?.previousInternal() }
        fun togglePause() { activeInstance?.toggleInternal() }
        fun setRandom(value: Boolean) { activeInstance?.setRandomInternal(value) }
        fun setRepeat(value: Boolean) { activeInstance?.setRepeatInternal(value) }
        fun setVolume(value: Float) { activeInstance?.setVolumeInternal(value) }
        fun setMixer(crossfader: Float, autoMix: Boolean, seconds: Int) {
            configuredCrossfader = crossfader.coerceIn(-1f, 1f)
            configuredAutoMix = autoMix
            configuredCrossfadeSeconds = seconds.takeIf { it in listOf(3, 6, 9) } ?: 6
            activeInstance?.setMixerInternal(crossfader, autoMix, seconds)
        }
        fun stop(context: Context) {
            pendingStart = null
            activeInstance?.stopInternal() ?: context.stopService(Intent(context, BreakPlaybackService::class.java))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val resolverScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var resolverJob: Job? = null
    private var activeSourceJob: Job? = null
    private var playbackGeneration = 0
    private var streamTrack = false
    private var startedAudioAt = 0L
    private var lastAudioFailure: String? = null

    // Deck B is prepared silently while deck A plays. Never shares A's resolver job.
    private var standbyPlayer: MediaPlayer? = null
    private var standbyEntry: Entry? = null
    private var standbyPrepared = false
    private var standbyStartedAt = 0L
    private var standbyJob: Job? = null
    private var standbySourceJob: Job? = null
    private var standbyGeneration = 0
    private var player: MediaPlayer? = null
    // Independent of UI snapshot: only onPrepared makes MediaPlayer queryable.
    private var playerPrepared = false
    private var standbyVisualizer: Visualizer? = null
    private var activeVisualizer: Visualizer? = null
    private var meterAAvailable = false
    private var meterBAvailable = false
    private var crossfader = 0f
    private var autoMix = false
    private var crossfadeSeconds = 6
    private var crossfadeStartedAt = 0L
    private var crossfadePausedElapsed = 0L
    private var crossfading = false
    private var manualOverlap = false
    private var levelA = 0f
    private var levelB = 0f
    @Volatile private var peakGuardA = 1f
    @Volatile private var peakGuardB = 1f
    private var files: List<Entry> = emptyList()
    private var order: List<Int> = emptyList()
    private var orderPosition = -1
    private var random = false
    private var repeat = false
    private var volume = 1f
    private var current: Entry? = null
    private lateinit var mediaSession: MediaSession

    // Local audio is owned by this foreground service, never by the UI/PiP.
    // Audio focus handles calls and other temporary system interruptions.
    private val audioManager by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    private val musicAudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()
    private var ownsAudioFocus = false
    private var resumeAfterTemporaryFocusLoss = false
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_GAIN -> {
                ownsAudioFocus = true
                if (resumeAfterTemporaryFocusLoss) {
                    resumeAfterTemporaryFocusLoss = false
                    val p = player
                    if (p != null && playerPrepared && !snapshot.preparing && !snapshot.playing && snapshot.sessionActive) {
                        runCatching { p.start() }.onSuccess {
                            if (crossfading) standbyPlayer?.let { runCatching { it.start() } }
                            if (crossfading) crossfadeStartedAt = SystemClock.elapsedRealtime() - crossfadePausedElapsed
                            publish(playing = true)
                            updateNotification()
                        }
                    }
                }
            }
            AudioManager.AUDIOFOCUS_LOSS -> {
                ownsAudioFocus = false
                resumeAfterTemporaryFocusLoss = false
                pauseForAudioInterruption()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                ownsAudioFocus = false
                // Do not duck through a telephone call: pause until focus returns.
                resumeAfterTemporaryFocusLoss = snapshot.playing ||
                    (snapshot.preparing && snapshot.sessionActive)
                pauseForAudioInterruption()
            }
        }
    }
    private val focusRequest by lazy {
        AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(musicAudioAttributes)
            .setOnAudioFocusChangeListener(focusListener, handler)
            .setWillPauseWhenDucked(true)
            .setAcceptsDelayedFocusGain(true)
            .build()
    }

    private fun acquireAudioFocus(): Boolean {
        if (ownsAudioFocus) return true
        return when (audioManager.requestAudioFocus(focusRequest)) {
            AudioManager.AUDIOFOCUS_REQUEST_GRANTED -> {
                ownsAudioFocus = true
                true
            }
            AudioManager.AUDIOFOCUS_REQUEST_DELAYED -> {
                resumeAfterTemporaryFocusLoss = true
                false
            }
            else -> {
                resumeAfterTemporaryFocusLoss = false
                false
            }
        }
    }

    private fun releaseAudioFocus() {
        resumeAfterTemporaryFocusLoss = false
        // Also cancels delayed focus grants queued behind an ongoing call.
        runCatching { audioManager.abandonAudioFocusRequest(focusRequest) }
        ownsAudioFocus = false
    }

    private fun pauseForAudioInterruption() {
        if (snapshot.playing) {
            player?.let { runCatching { it.pause() } }
            if (crossfading) {
                standbyPlayer?.let { runCatching { it.pause() } }
                crossfadePausedElapsed = SystemClock.elapsedRealtime() - crossfadeStartedAt
            }
            publish(playing = false)
            updateNotification()
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            val p = player
            if (p != null && snapshot.sessionActive && playerPrepared) {
                // MediaPlayer is still IDLE while BMQ/NewPipe resolves the URL.
                // Calling getDuration() in IDLE forces MEDIA_ERROR_UNKNOWN (-38).
                // Read BOTH position and duration only after onPrepared has fired.
                val pos = if (snapshot.preparing) snapshot.position else runCatching { p.currentPosition }.getOrDefault(snapshot.position)
                val dur = if (snapshot.preparing) snapshot.duration
                    else if (snapshot.duration > 0) snapshot.duration
                    else runCatching { p.duration }.getOrDefault(0).coerceAtLeast(0)
                publish(position = pos, duration = dur,
                    deckAReady = playerPrepared, deckBReady = standbyPrepared,
                    deckBPreparing = standbyEntry != null && !standbyPrepared,
                    meterAAvailable = meterAAvailable, meterBAvailable = meterBAvailable,
                    crossfading = crossfading, levelA = levelA, levelB = levelB,
                    crossfader = crossfader, autoMix = autoMix, crossfadeSeconds = crossfadeSeconds)
                if (autoMix && !crossfading && playerPrepared && standbyPrepared && dur > 0 && snapshot.playing) {
                    val remaining = dur - pos
                    if (remaining <= crossfadeSeconds * 1000) beginCrossfade()
                }
                if (crossfading && manualOverlap && snapshot.playing) applyDeckVolumes()
                else if (crossfading && snapshot.playing) updateCrossfade()
                updatePlaybackState()
            }
            handler.postDelayed(this, 250L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        activeInstance = this
        BlackBox.ensureInitialized(applicationContext)
        BlackBox.log("AUDIO SERVICE created")
        createChannel()
        mediaSession = MediaSession(this, "BreakMonster").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() { if (!snapshot.playing) toggleInternal() }
                override fun onPause() { if (snapshot.playing) toggleInternal() }
                override fun onSkipToNext() { nextInternal() }
                override fun onSkipToPrevious() { previousInternal() }
                override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                    return super.onMediaButtonEvent(mediaButtonIntent)
                }
                override fun onStop() { stopInternal() }
                override fun onSeekTo(pos: Long) { seekInternal(pos.toInt()) }
            })
            setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)
            isActive = true
        }
        handler.post(ticker)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val request = pendingStart
                pendingStart = null
                if (request == null || request.files.isEmpty()) {
                    stopInternal()
                    return START_NOT_STICKY
                }
                lastAudioFailure = null
                val selectedLabel = request.selectedUri?.substringAfterLast('/') ?: "first"
                BlackBox.log("AUDIO PLAYLIST START count=${request.files.size} selected=$selectedLabel")
                random = request.random
                repeat = request.repeat
                volume = request.volume.coerceIn(0f, 1f)
                crossfader = request.crossfader.coerceIn(-1f, 1f)
                autoMix = request.autoMix
                crossfadeSeconds = request.crossfadeSeconds.takeIf { it in listOf(3, 6, 9) } ?: 6
                crossfading = false
                files = request.files.distinctBy { it.uri }
                BlackBox.log("QUEUE size=${files.size} selectedIndex=${request.selectedUri?.let { wanted -> files.indexOfFirst { it.uri == wanted } } ?: 0}")
                publish(random = random, repeat = repeat, sessionActive = true, preparing = true)
                startForeground(NOTIFICATION_ID, buildNotification("BreakMonster", false))
                val selected = request.selectedUri?.let { wanted -> files.indexOfFirst { it.uri == wanted } }?.takeIf { it >= 0 }
                rebuildOrder(selected)
                if (order.isEmpty()) stopInternal() else {
                    orderPosition = 0
                    BlackBox.log("AUDIO SESSION CREATE queue=${files.size}")
                    playIndex(order[0])
                }
            }
            ACTION_TOGGLE -> toggleInternal()
            ACTION_NEXT -> nextInternal()
            ACTION_PREVIOUS -> previousInternal()
            ACTION_STOP -> stopInternal()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun rebuildOrder(firstIndex: Int? = null) {
        val all = files.indices.toList()
        if (all.isEmpty()) {
            order = emptyList(); orderPosition = -1; return
        }
        val first = firstIndex?.takeIf { it in all }
        val rest = if (first == null) all else all.filter { it != first }
        val orderedRest = if (random) rest.shuffled() else rest
        order = if (first == null) { if (random) all.shuffled() else all } else listOf(first) + orderedRest
        orderPosition = if (order.isEmpty()) -1 else 0
    }

    private fun playIndex(index: Int) {
        val entry = files.getOrNull(index) ?: return
        if (standbyEntry?.uri == entry.uri && standbyPrepared && standbyPlayer != null) {
            val ready = standbyPlayer!!
            val oldActive = player
            playbackGeneration++
            resolverJob?.cancel(); resolverJob = null
            activeSourceJob?.cancel(); activeSourceJob = null
            releaseMeter(standby = false)
            releaseMeter(standby = true)
            standbyPlayer = oldActive
            standbyEntry = null; standbyPrepared = false; standbyStartedAt = 0L
            if (oldActive != null) {
                runCatching { oldActive.stop() }
                runCatching { oldActive.reset() }
            }
            player = ready; playerPrepared = true; current = entry
            onTrackChanged?.invoke(entry.uri)
            streamTrack = isStream(entry)
            val duration = runCatching { ready.duration }.getOrDefault(0).coerceAtLeast(0)
            publish(trackUri = entry.uri, trackName = entry.name, preparing = false,
                playing = false, position = 0, duration = duration, sessionActive = true, deckAReady = true,
                deckBReady = false, deckBPreparing = false)
            if (acquireAudioFocus()) {
                runCatching { ready.start() }.onSuccess {
                    startedAudioAt = SystemClock.elapsedRealtime()
                    standbyStartedAt = 0L
                    val oldGuard = peakGuardA; peakGuardA = peakGuardB; peakGuardB = oldGuard
                    crossfading = false; manualOverlap = false
                    crossfader = -1f; configuredCrossfader = -1f
                    BlackBox.log("PLAYER ROLE SWAP A=${entry.name} mode=NEXT audioSessionPreserved=true")
                    publish(playing = true, crossfading = false, crossfader = -1f, deckAReady = true,
                        deckBReady = false, deckBPreparing = false)
                    attachMeter(ready, standby = false)
                    preloadNextDeck()
                }.onFailure { failCurrent(ready, "Deck B promotion", it) }
            }
            updateNotification()
            return
        }
        releasePlayer()
        current = entry
        onTrackChanged?.invoke(entry.uri)
        lastAudioFailure = null
        val sourceUri = Uri.parse(entry.uri)
        streamTrack = entry.uri.startsWith("https://www.youtube.com/watch?v=") ||
            sourceUri.path.orEmpty().endsWith(".bmq", ignoreCase = true) ||
            sourceUri.path.orEmpty().endsWith(".yt", ignoreCase = true)
        startedAudioAt = 0L
        BlackBox.log("AUDIO TRACK START ${orderPosition + 1}/${order.size} name=${entry.name} kind=${if (streamTrack) "BMQ" else "LOCAL"}")
        publish(trackUri = entry.uri, trackName = entry.name, preparing = true,
            playing = false, position = 0, duration = 0, sessionActive = true,
            deckAReady = false, deckBReady = false, deckBPreparing = false, crossfading = false)
        updateNotification()

        if (!streamTrack) {
            prepareResolvedSource(entry, null)
            return
        }

        // IMPORTANT: Do not even create a MediaPlayer in the IDLE state while
        // NewPipe is still looking for the stream URL. This prevents state
        // queries or callbacks from sending commands to an unloaded player.
        val generation = playbackGeneration
        val resolveStarted = SystemClock.elapsedRealtime()
        BlackBox.log("BMQ RESOLVE BEGIN track=${entry.name} deck=A")
        val resolvingWakeLock = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "BrakeMonsterPro:audioResolve")
        runCatching { resolvingWakeLock.acquire(60_000L) }
        resolverJob = resolverScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        val id = if (entry.uri.startsWith("https://www.youtube.com/watch?v="))
                            BmqCodec.extractId(entry.uri) ?: error("Invalid YouTube video ID")
                        else BmqCodec.readReference(applicationContext, Uri.parse(entry.uri))
                        ProStreamResolver.resolveAudio(id)
                    }
                }
                // A manual NEXT/STOP can happen during network extraction.
                if (generation != playbackGeneration || current?.uri != entry.uri || !snapshot.sessionActive)
                    return@launch
                result.fold(
                    onSuccess = { url ->
                        BlackBox.log("BMQ RESOLVE DURATION track=${entry.name} durationMs=${SystemClock.elapsedRealtime() - resolveStarted} deck=A")
                        BlackBox.log("BMQ RESOLVE OK track=${entry.name} · creating MediaPlayer")
                        prepareResolvedSource(entry, url)
                    },
                    onFailure = { error ->
                        failEntry(entry, "BMQ NewPipe resolve", error)
                    }
                )
            } finally {
                runCatching { if (resolvingWakeLock.isHeld) resolvingWakeLock.release() }
            }
        }
    }

    /** Called on the service main thread ONLY after the BMQ URL has been
     * resolved. The player is not queried until its onPrepared callback.
     */
    private fun prepareResolvedSource(entry: Entry, streamUrl: String?, standby: Boolean = false, reusable: MediaPlayer? = null) {
        if (!snapshot.sessionActive) return
        if (!standby && current?.uri != entry.uri) return
        if (standby && standbyEntry?.uri != entry.uri) return
        val p = reusable ?: MediaPlayer()
        val deckName = if (standby) "B" else "A"
        val prepareStartedAt = SystemClock.elapsedRealtime()
        if (standby) peakGuardB = 1f else peakGuardA = 1f
        BlackBox.log("AUDIO PLAYER CREATE deck=$deckName audioSessionId=${runCatching { p.audioSessionId }.getOrDefault(-1)} reused=${reusable != null}")
        if (standby) standbyPlayer = p else {
            playerPrepared = false
            player = p
        }
        try {
            if (reusable != null) reusable.reset()
            p.setAudioAttributes(musicAudioAttributes)
            p.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            p.setVolume(volume, volume)
            p.setOnPreparedListener {
                if (player === p || standbyPlayer === p) {
                    if (player === p) playerPrepared = true
                    val duration = runCatching { p.duration }.getOrDefault(0).coerceAtLeast(0)
                    BlackBox.log("AUDIO PREPARED track=${entry.name} durationMs=$duration")
                    BlackBox.log("BUFFER PREPARATION DURATION track=${entry.name} durationMs=${SystemClock.elapsedRealtime() - prepareStartedAt} deck=$deckName")
                    if (p === standbyPlayer) {
                        standbyPrepared = true
                        attachMeter(p, standby = true)
                        BlackBox.log("DECK B READY track=${entry.name} durationMs=$duration")
                        applyDeckVolumes()
                        publish(deckBReady = true, deckBPreparing = false)
                        return@setOnPreparedListener
                    }
                    attachMeter(p, standby = false)
                    val mayPlay = acquireAudioFocus()
                    if (mayPlay) {
                        runCatching { p.start() }.onSuccess {
                            resumeAfterTemporaryFocusLoss = false
                            startedAudioAt = SystemClock.elapsedRealtime()
                            lastAudioFailure = null
                            BlackBox.log("AUDIO PLAYING track=${entry.name} durationMs=$duration")
                            publish(preparing = false, playing = true, duration = duration, deckAReady = true)
                            applyDeckVolumes()
                            preloadNextDeck()
                        }.onFailure { error ->
                            failCurrent(p, "MediaPlayer.start", error)
                        }
                    } else {
                        BlackBox.log("AUDIO PREPARED waiting for audio focus track=${entry.name}")
                        publish(preparing = false, playing = false, duration = duration)
                    }
                    updateNotification()
                }
            }
            p.setOnCompletionListener {
                if (player === p) {
                    if (streamTrack && (startedAudioAt == 0L ||
                            SystemClock.elapsedRealtime() - startedAudioAt < 2500L)) {
                        failCurrent(p, "premature MediaPlayer completion (less than 2.5s)")
                        return@setOnCompletionListener
                    }
                    BlackBox.log("TRACK COMPLETION track=${entry.name} crossfading=$crossfading")
                    if (crossfading) return@setOnCompletionListener
                    releasePlayer(clearB = false)
                    publish(preparing = false, playing = false, position = snapshot.duration)
                    if (files.size == 1) {
                        BlackBox.log("QUEUE SERVICE FINISHED count=1")
                        publish(trackUri = null, trackName = null, position = 0, duration = 0, sessionActive = true)
                        onSingleTrackCompleted?.invoke()
                        stopInternal()
                    } else {
                        BlackBox.log("QUEUE SERVICE ADVANCE ${orderPosition + 1}/${order.size}")
                        if (standbyPrepared && standbyEntry?.uri == files.getOrNull(order.getOrNull(orderPosition + 1) ?: -1)?.uri) {
                            promoteStandby()
                        } else advanceInternal()
                    }
                }
            }
            p.setOnErrorListener { _, what, extra ->
                if (standbyPlayer === p) {
                    BlackBox.log("DECK B ERROR what=$what extra=$extra track=${entry.name}")
                    clearStandby()
                } else if (player === p) {
                    failCurrent(p, "MediaPlayer error what=$what extra=$extra whilePreparing=${snapshot.preparing}")
                }
                true
            }
            p.setOnInfoListener { _, what, _ ->
                if (player === p) {
                    when (what) {
                        MediaPlayer.MEDIA_INFO_BUFFERING_START -> BlackBox.log("AUDIO BUFFERING START track=${entry.name}")
                        MediaPlayer.MEDIA_INFO_BUFFERING_END -> BlackBox.log("AUDIO BUFFERING END track=${entry.name}")
                    }
                }
                true
            }
            val generation = playbackGeneration
            val standbyToken = standbyGeneration
            val sourceSetup = resolverScope.launch {
                try {
                    val configured = withContext(Dispatchers.IO) {
                        runCatching {
                            if (streamUrl != null) {
                                BlackBox.log("AUDIO STREAM DATASOURCE track=${entry.name} deck=$deckName")
                                p.setDataSource(applicationContext, Uri.parse(streamUrl), mapOf(
                                    "User-Agent" to "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/130.0 Mobile Safari/537.36",
                                    "Referer" to "https://www.youtube.com/"
                                ))
                            } else {
                                val mediaUri = Uri.parse(entry.uri)
                                val afd = runCatching { contentResolver.openAssetFileDescriptor(mediaUri, "r") }.getOrNull()
                                if (afd != null) {
                                    afd.use { descriptor ->
                                        if (descriptor.declaredLength >= 0L)
                                            p.setDataSource(descriptor.fileDescriptor, descriptor.startOffset, descriptor.declaredLength)
                                        else p.setDataSource(descriptor.fileDescriptor)
                                    }
                                } else p.setDataSource(applicationContext, mediaUri)
                            }
                        }
                    }
                    if (!snapshot.sessionActive || (standby && (standbyToken != standbyGeneration || standbyPlayer !== p || standbyEntry?.uri != entry.uri)) ||
                        (!standby && (generation != playbackGeneration || player !== p || current?.uri != entry.uri))) {
                        runCatching { p.release() }
                        return@launch
                    }
                    configured.fold(
                        onSuccess = {
                            try {
                                p.prepareAsync()
                                BlackBox.log("AUDIO PREPARE_ASYNC track=${entry.name} deck=$deckName · waiting for buffer")
                            } catch (error: Exception) {
                                if (standby) clearStandby() else failCurrent(p, if (streamUrl != null) "BMQ MediaPlayer prepare" else "local MediaPlayer prepare", error)
                            }
                        },
                        onFailure = { error ->
                            if (standby) {
                                BlackBox.log("DECK B DATASOURCE FAILED track=${entry.name} ${error.javaClass.simpleName}")
                                clearStandby()
                            } else failCurrent(p, if (streamUrl != null) "BMQ MediaPlayer datasource" else "local MediaPlayer datasource", error)
                        }
                    )
                } catch (cancelled: CancellationException) {
                    if (player !== p && standbyPlayer !== p) runCatching { p.release() }
                    throw cancelled
                }
            }
            if (standby) standbySourceJob = sourceSetup else activeSourceJob = sourceSetup
        } catch (error: Exception) {
            if (standby) {
                BlackBox.log("DECK B PREPARE FAILED track=${entry.name} ${error.javaClass.simpleName}")
                clearStandby()
            } else failCurrent(p, if (streamUrl != null) "BMQ MediaPlayer prepare" else "local MediaPlayer prepare", error)
        }
    }

    /** Halt on the FIRST error instead of racing through the entire playlist.
     * Manual NEXT still works so users can test a different recording.
     */
    private fun failCurrent(p: MediaPlayer, stage: String, error: Throwable? = null) {
        if (player !== p) return
        val failed = current ?: return
        failEntry(failed, stage, error)
    }

    private fun failEntry(entry: Entry, stage: String, error: Throwable? = null) {
        if (current?.uri != entry.uri || !snapshot.sessionActive) return
        lastAudioFailure = stage
        BlackBox.audioFailure(stage, entry.name, error)
        BlackBox.log("PLAYBACK FAILURE track=${entry.name} stage=$stage recovery=${files.size > 1}")
        releasePlayer()
        publish(preparing = false, playing = false, deckAReady = false, deckBReady = false, deckBPreparing = false)
        updateNotification()
        if (files.size > 1) handler.post { advanceInternal() } else handler.post { stopInternal() }
    }

    private fun advanceInternal() {
        if (files.isEmpty()) { stopInternal(); return }
        val next = orderPosition + 1
        if (next in order.indices) {
            orderPosition = next
            playIndex(order[next])
            return
        }
        if (repeat) {
            rebuildOrder()
            if (order.isNotEmpty()) {
                orderPosition = 0
                playIndex(order[0])
            } else stopInternal()
        } else {
            BlackBox.log("QUEUE SERVICE FINISHED count=${files.size}")
            onSingleTrackCompleted?.invoke()
            stopInternal()
        }
    }

    private fun isStream(entry: Entry): Boolean {
        val u = Uri.parse(entry.uri)
        return entry.uri.startsWith("https://www.youtube.com/watch?v=") ||
            u.path.orEmpty().endsWith(".bmq", true) || u.path.orEmpty().endsWith(".yt", true)
    }

    private fun clearStandby() {
        standbyGeneration++
        standbyJob?.cancel(); standbyJob = null
        val setupInFlight = standbySourceJob?.isActive == true
        standbySourceJob?.cancel(); standbySourceJob = null
        releaseMeter(standby = true)
        val old = standbyPlayer
        standbyPlayer = null; standbyEntry = null; standbyPrepared = false; standbyStartedAt = 0L
        if (old != null) {
            val sessionId = if (setupInFlight) -1 else runCatching { old.audioSessionId }.getOrDefault(-1)
            BlackBox.log("AUDIO PLAYER DESTROY deck=B audioSessionId=$sessionId deferred=$setupInFlight")
            if (!setupInFlight) runCatching { old.release() }
        }
        levelB = 0f
        publish(deckBReady = false, deckBPreparing = false, levelB = 0f)
    }

    private fun preloadNextDeck() {
        standbyGeneration++
        standbyJob?.cancel(); standbyJob = null
        val setupInFlight = standbySourceJob?.isActive == true
        standbySourceJob?.cancel(); standbySourceJob = null
        if (setupInFlight) {
            standbyPlayer = null
            BlackBox.log("DECK B SOURCE SETUP CANCELLED; release deferred")
        } else if (standbyPlayer != null) {
            releaseMeter(standby = true)
            runCatching { standbyPlayer?.stop() }
        }
        standbyEntry = null
        standbyPrepared = false
        standbyStartedAt = 0L
        levelB = 0f
        val nextIndex = order.getOrNull(orderPosition + 1) ?: if (repeat) order.firstOrNull() else null
        val entry = nextIndex?.let { files.getOrNull(it) } ?: return
        standbyEntry = entry
        val token = standbyGeneration
        BlackBox.log("DECK B PRELOAD BEGIN index=${nextIndex} track=${entry.name}")
        publish(deckBReady = false, deckBPreparing = true)
        if (!isStream(entry)) {
            prepareResolvedSource(entry, null, standby = true, reusable = standbyPlayer)
            return
        }
        val resolveStarted = SystemClock.elapsedRealtime()
        standbyJob = resolverScope.launch {
            val resolved = withContext(Dispatchers.IO) {
                runCatching {
                    val id = if (entry.uri.startsWith("https://www.youtube.com/watch?v="))
                        BmqCodec.extractId(entry.uri) ?: error("Invalid YouTube ID")
                    else BmqCodec.readReference(applicationContext, Uri.parse(entry.uri))
                    ProStreamResolver.resolveAudio(id)
                }
            }
            if (token != standbyGeneration || standbyEntry?.uri != entry.uri) return@launch
            BlackBox.log("BMQ RESOLVE DURATION track=${entry.name} durationMs=${SystemClock.elapsedRealtime() - resolveStarted} deck=B")
            resolved.onSuccess { prepareResolvedSource(entry, it, standby = true, reusable = standbyPlayer) }
                .onFailure {
                    BlackBox.log("DECK B RESOLVE FAILED track=${entry.name} ${it.javaClass.simpleName}")
                    // Leave A playing. Completion will resolve the next track on demand.
                    standbyEntry = null
                    publish(deckBPreparing = false)
                }
        }
    }

    private fun beginCrossfade() {
        val next = standbyPlayer ?: return
        val entry = standbyEntry ?: return
        if (!standbyPrepared || crossfading || player == null) return
        try {
            next.setVolume(0f, 0f)
            next.start()
            standbyStartedAt = SystemClock.elapsedRealtime()
            crossfading = true
            crossfadeStartedAt = SystemClock.elapsedRealtime()
            crossfadePausedElapsed = 0L
            BlackBox.log("CROSSFade START from=${current?.name} to=${entry.name} seconds=$crossfadeSeconds mode=auto")
            publish(crossfading = true)
        } catch (error: Throwable) {
            BlackBox.audioFailure("crossfade standby start", entry.name, error)
            BlackBox.log("CROSSFade START FAILED track=${entry.name}; continue A")
            clearStandby()
        }
    }

    private fun updateCrossfade() {
        val durationMs = crossfadeSeconds * 1000L
        val fraction = ((SystemClock.elapsedRealtime() - crossfadeStartedAt).toFloat() / durationMs).coerceIn(0f, 1f)
        val oldGain = kotlin.math.cos(fraction * (Math.PI / 2.0)).toFloat()
        val newGain = kotlin.math.sin(fraction * (Math.PI / 2.0)).toFloat()
        player?.let { runCatching { it.setVolume(volume * oldGain * peakGuardA, volume * oldGain * peakGuardA) } }
        standbyPlayer?.let { runCatching { it.setVolume(volume * newGain * peakGuardB, volume * newGain * peakGuardB) } }
        crossfader = (fraction * 2f - 1f).coerceIn(-1f, 1f)
        publish(crossfader = crossfader)
        if (fraction >= 1f) {
            BlackBox.log("CROSSFade END from=${current?.name} to=${standbyEntry?.name}")
            promoteStandby()
        }
    }

    private fun promoteStandby() {
        val promoted = standbyPlayer ?: return
        val entry = standbyEntry ?: return
        val wasAlreadyPlaying = runCatching { promoted.isPlaying }.getOrDefault(false)
        val promotedStartedAt = standbyStartedAt
        val oldActive = player
        val oldIndex = orderPosition
        releaseMeter(standby = true)
        releaseMeter(standby = false)
        if (oldActive != null) {
            runCatching { oldActive.stop() }
            runCatching { oldActive.reset() }
        }
        player = promoted
        playerPrepared = true
        standbyPlayer = oldActive
        standbyEntry = null
        standbyPrepared = false
        standbyStartedAt = 0L
        current = entry
        streamTrack = isStream(entry)
        orderPosition = if (oldIndex + 1 <= order.lastIndex) oldIndex + 1 else if (repeat) 0 else oldIndex + 1
        crossfading = false
        manualOverlap = false
        crossfader = -1f
        configuredCrossfader = -1f
        val oldGuard = peakGuardA; peakGuardA = peakGuardB; peakGuardB = oldGuard
        if (!wasAlreadyPlaying) {
            runCatching { promoted.setVolume(volume, volume); promoted.start() }
                .onFailure { failCurrent(promoted, "standby promotion start", it); return }
        }
        startedAudioAt = if (wasAlreadyPlaying && promotedStartedAt > 0L) promotedStartedAt else SystemClock.elapsedRealtime()
        attachMeter(promoted, standby = false)
        onTrackChanged?.invoke(entry.uri)
        val duration = runCatching { promoted.duration }.getOrDefault(0).coerceAtLeast(0)
        BlackBox.log("PLAYER ROLE SWAP A=${entry.name} queueIndex=${orderPosition} sessionPreserved=true")
        publish(trackUri = entry.uri, trackName = entry.name, preparing = false, playing = true,
            position = 0, duration = duration, deckAReady = true, deckBReady = false, deckBPreparing = false,
            crossfading = false, crossfader = -1f, levelB = 0f)
        applyDeckVolumes()
        // The old A instance becomes the next standby deck after reset.
        preloadNextDeck()
        updateNotification()
    }

    private fun applyDeckVolumes() {
        if (crossfading && !manualOverlap) return
        if (!autoMix && crossfader > -0.999f && standbyPrepared && !manualOverlap) {
            runCatching {
                standbyPlayer?.setVolume(0f, 0f)
                standbyPlayer?.start()
                standbyStartedAt = SystemClock.elapsedRealtime()
                manualOverlap = true
                crossfading = true
                crossfadeStartedAt = SystemClock.elapsedRealtime()
                crossfadePausedElapsed = 0L
                BlackBox.log("MANUAL CROSSFade START from=${current?.name} to=${standbyEntry?.name}")
            }.onFailure {
                BlackBox.audioFailure("manual crossfader start", standbyEntry?.name, it)
                clearStandby()
            }
        }
        val normalized = if (!standbyPrepared && !manualOverlap) 0f
            else ((crossfader + 1f) / 2f).coerceIn(0f, 1f)
        val gainA = kotlin.math.cos(normalized * (Math.PI / 2.0)).toFloat()
        val gainB = kotlin.math.sin(normalized * (Math.PI / 2.0)).toFloat()
        player?.let { runCatching { it.setVolume(volume * gainA * peakGuardA, volume * gainA * peakGuardA) } }
        standbyPlayer?.let { runCatching { it.setVolume(volume * gainB * peakGuardB, volume * gainB * peakGuardB) } }
        if (manualOverlap && crossfader >= 0.999f) {
            BlackBox.log("MANUAL CROSSFade END from=${current?.name} to=${standbyEntry?.name}")
            promoteStandby()
        }
    }

    private fun setMixerInternal(position: Float, automatic: Boolean, seconds: Int) {
        handler.post {
            crossfader = position.coerceIn(-1f, 1f)
            autoMix = automatic
            crossfadeSeconds = seconds.takeIf { it in listOf(3, 6, 9) } ?: 6
            if (!automatic) {
                if (crossfading && !manualOverlap) manualOverlap = true
                if (crossfader > -0.999f && standbyPrepared && !manualOverlap) {
                    runCatching {
                        standbyPlayer?.setVolume(0f, 0f)
                        standbyPlayer?.start()
                        standbyStartedAt = SystemClock.elapsedRealtime()
                        manualOverlap = true
                        crossfading = true
                        crossfadeStartedAt = SystemClock.elapsedRealtime()
                        crossfadePausedElapsed = 0L
                        BlackBox.log("MANUAL CROSSFade START from=${current?.name} to=${standbyEntry?.name}")
                    }.onFailure {
                        BlackBox.audioFailure("manual crossfader start", standbyEntry?.name, it)
                        clearStandby()
                    }
                }
                if (crossfader <= -0.999f && manualOverlap) {
                    standbyPlayer?.let { runCatching { it.pause() }; runCatching { it.seekTo(0) } }
                    manualOverlap = false
                    crossfading = false
                }
                applyDeckVolumes()
            }
            publish(crossfader = crossfader, autoMix = autoMix, crossfadeSeconds = crossfadeSeconds)
            BlackBox.log("MIXER CONFIG crossfader=$crossfader auto=$autoMix seconds=$crossfadeSeconds")
        }
    }

    private fun attachMeter(p: MediaPlayer, standby: Boolean) {
        val visualizer = runCatching {
            Visualizer(p.audioSessionId).apply {
                val size = Visualizer.getCaptureSizeRange().last()
                captureSize = size
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer, waveform: ByteArray, samplingRate: Int) {
                        var sum = 0.0
                        waveform.forEach { sample ->
                            val normalized = (sample.toInt() and 0xff) - 128
                            sum += normalized * normalized
                        }
                        val rms = if (waveform.isEmpty()) 0f else (kotlin.math.sqrt(sum / waveform.size) / 128.0).toFloat().coerceIn(0f, 1f)
                        val peak = waveform.maxOfOrNull { kotlin.math.abs((it.toInt() and 0xff) - 128) } ?: 0
                        if (standby) {
                            levelB = rms
                            peakGuardB = if (peak > 118) minOf(peakGuardB, 118f / peak) else (peakGuardB + .002f).coerceAtMost(1f)
                        } else {
                            levelA = rms
                            peakGuardA = if (peak > 118) minOf(peakGuardA, 118f / peak) else (peakGuardA + .002f).coerceAtMost(1f)
                        }
                        if (peak > 118) handler.post { applyDeckVolumes() }
                    }
                    override fun onFftDataCapture(v: Visualizer, fft: ByteArray, samplingRate: Int) = Unit
                }, Visualizer.getMaxCaptureRate(), true, false)
                enabled = true
            }
            }.onFailure { BlackBox.log("AUDIO METER unavailable deck=${if (standby) "B" else "A"} ${it.javaClass.simpleName}") }.getOrNull()
        if (standby) {
            standbyVisualizer = visualizer
            meterBAvailable = visualizer != null
        } else {
            activeVisualizer = visualizer
            meterAAvailable = visualizer != null
        }
    }

    private fun releaseMeter(standby: Boolean) {
        val meter = if (standby) standbyVisualizer else activeVisualizer
        if (standby) standbyVisualizer = null else activeVisualizer = null
        if (standby) meterBAvailable = false else meterAAvailable = false
        runCatching { meter?.enabled = false }
        runCatching { meter?.release() }
        if (standby) levelB = 0f else levelA = 0f
    }

    private fun seekInternal(value: Int) {
        handler.post {
            val p = player ?: return@post
            if (!playerPrepared || snapshot.preparing || snapshot.duration <= 0) return@post
            val target = value.coerceIn(0, snapshot.duration)
            runCatching { p.seekTo(target) }
            publish(position = target)
        }
    }

    private fun nextInternal() {
        handler.post {
            if (!snapshot.sessionActive) return@post
            BlackBox.log("QUEUE MANUAL NEXT index=$orderPosition next=${orderPosition + 1} size=${order.size}")
            releasePlayer(clearB = false)
            publish(preparing = false, playing = false)
            advanceInternal()
        }
    }

    private fun previousInternal() {
        handler.post {
            if (!snapshot.sessionActive || order.isEmpty()) return@post
            BlackBox.log("QUEUE MANUAL PREVIOUS index=$orderPosition previous=${orderPosition - 1} size=${order.size}")
            val prev = orderPosition - 1
            if (prev >= 0) {
                releasePlayer()
                orderPosition = prev
                playIndex(order[prev])
            } else if (snapshot.position > 3000) {
                seekInternal(0)
            } else if (repeat) {
                releasePlayer()
                orderPosition = order.lastIndex
                playIndex(order[orderPosition])
            } else {
                seekInternal(0)
            }
        }
    }

    private fun toggleInternal() {
        handler.post {
            val p = player ?: return@post
            if (!playerPrepared || snapshot.preparing) return@post
            if (snapshot.playing) {
                resumeAfterTemporaryFocusLoss = false
                runCatching { p.pause() }
                if (crossfading) {
                    standbyPlayer?.let { runCatching { it.pause() } }
                    crossfadePausedElapsed = SystemClock.elapsedRealtime() - crossfadeStartedAt
                }
                publish(playing = false)
                releaseAudioFocus()
            } else if (acquireAudioFocus()) {
                runCatching { p.start() }.onSuccess {
                    if (crossfading) standbyPlayer?.let { runCatching { it.start() } }
                    if (crossfading) crossfadeStartedAt = SystemClock.elapsedRealtime() - crossfadePausedElapsed
                    resumeAfterTemporaryFocusLoss = false
                    publish(playing = true)
                }
            }
            updateNotification()
        }
    }

    private fun setRandomInternal(value: Boolean) {
        handler.post {
            if (random == value) return@post
            random = value
            val currentIndex = current?.let { now -> files.indexOfFirst { it.uri == now.uri } }?.takeIf { it >= 0 }
            rebuildOrder(currentIndex)
            clearStandby()
            if (playerPrepared && snapshot.playing) preloadNextDeck()
            publish(random = random)
            updateNotification()
        }
    }

    private fun setRepeatInternal(value: Boolean) {
        handler.post {
            repeat = value
            if (playerPrepared && snapshot.playing) {
                clearStandby()
                preloadNextDeck()
            }
            publish(repeat = repeat)
            updateNotification()
        }
    }

    private fun setVolumeInternal(value: Float) {
        handler.post {
            volume = value.coerceIn(0f, 1f)
            applyDeckVolumes()
        }
    }

    private fun stopInternal() {
        val stopNow = Runnable {
            BlackBox.log("AUDIO SESSION DESTROY queue=${files.size} track=${current?.name}")
            releasePlayer()
            releaseAudioFocus()
            files = emptyList(); order = emptyList(); orderPosition = -1; current = null
            snapshot = Snapshot(random = random, repeat = repeat)
            updatePlaybackState()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        if (Looper.myLooper() == Looper.getMainLooper()) stopNow.run() else handler.post(stopNow)
    }

    private fun releasePlayer(clearB: Boolean = true) {
        if (clearB) clearStandby()
        playbackGeneration++
        resolverJob?.cancel()
        resolverJob = null
        val setupInFlight = activeSourceJob?.isActive == true
        activeSourceJob?.cancel()
        activeSourceJob = null
        val p = player
        player = null
        playerPrepared = false
        releaseMeter(standby = false)
        if (p != null) {
            val sessionId = if (setupInFlight) -1 else runCatching { p.audioSessionId }.getOrDefault(-1)
            BlackBox.log("AUDIO PLAYER DESTROY deck=A audioSessionId=$sessionId deferred=$setupInFlight")
            if (!setupInFlight) runCatching { p.release() }
        }
    }

    private fun publish(
        trackUri: String? = snapshot.trackUri,
        trackName: String? = snapshot.trackName,
        preparing: Boolean = snapshot.preparing,
        playing: Boolean = snapshot.playing,
        position: Int = snapshot.position,
        duration: Int = snapshot.duration,
        random: Boolean = snapshot.random,
        repeat: Boolean = snapshot.repeat,
        sessionActive: Boolean = snapshot.sessionActive,
        deckAReady: Boolean = snapshot.deckAReady,
        deckBReady: Boolean = snapshot.deckBReady,
        deckBPreparing: Boolean = snapshot.deckBPreparing,
        meterAAvailable: Boolean = snapshot.meterAAvailable,
        meterBAvailable: Boolean = snapshot.meterBAvailable,
        crossfading: Boolean = snapshot.crossfading,
        levelA: Float = snapshot.levelA,
        levelB: Float = snapshot.levelB,
        crossfader: Float = snapshot.crossfader,
        autoMix: Boolean = snapshot.autoMix,
        crossfadeSeconds: Int = snapshot.crossfadeSeconds
    ) {
        snapshot = Snapshot(trackUri, trackName, preparing, playing, position.coerceAtLeast(0), duration.coerceAtLeast(0), random, repeat, sessionActive,
            deckAReady, deckBReady, deckBPreparing, meterAAvailable, meterBAvailable,
            crossfading, levelA.coerceIn(0f, 1f), levelB.coerceIn(0f, 1f), crossfader, autoMix, crossfadeSeconds)
    }

    private fun updatePlaybackState() {
        if (!::mediaSession.isInitialized) return
        val state = when {
            snapshot.preparing -> PlaybackState.STATE_BUFFERING
            snapshot.playing -> PlaybackState.STATE_PLAYING
            snapshot.sessionActive -> PlaybackState.STATE_PAUSED
            else -> PlaybackState.STATE_STOPPED
        }
        val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_STOP or PlaybackState.ACTION_SEEK_TO
        mediaSession.setMetadata(MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, snapshot.trackName ?: "BrakeMonster")
            .putString(MediaMetadata.METADATA_KEY_ARTIST, "BrakeMonster")
            .putLong(MediaMetadata.METADATA_KEY_DURATION, snapshot.duration.toLong())
            .build())
        mediaSession.setPlaybackState(
            PlaybackState.Builder().setActions(actions)
                .setState(state, snapshot.position.toLong(), if (snapshot.playing) 1f else 0f).build()
        )
    }

    private fun createChannel() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "BreakMonster playback", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Keeps BreakMonster music playing in the background"
                setShowBadge(false)
            }
        )
    }

    private fun servicePendingIntent(action: String, requestCode: Int): PendingIntent = PendingIntent.getService(
        this, requestCode, Intent(this, BreakPlaybackService::class.java).setAction(action),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun buildNotification(title: String, playing: Boolean): Notification {
        val openApp = PendingIntent.getActivity(
            this, 10, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val playPauseIcon = if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val playPauseLabel = if (playing) "Pause" else "Play"
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_play)
            .setContentTitle(title.ifBlank { "BreakMonster" })
            .setContentText(lastAudioFailure?.let { "AUDIO ERROR · Open MIXER > BLACK BOX" } ?: "BreakMonster player")
            .setContentIntent(openApp)
            .setOngoing(playing || snapshot.preparing)
            .setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(Notification.Action.Builder(playPauseIcon, playPauseLabel, servicePendingIntent(ACTION_TOGGLE, 11)).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_previous, "Previous", servicePendingIntent(ACTION_PREVIOUS, 14)).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_next, "Next", servicePendingIntent(ACTION_NEXT, 12)).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Stop", servicePendingIntent(ACTION_STOP, 13)).build())
            .setStyle(Notification.MediaStyle().setMediaSession(mediaSession.sessionToken).setShowActionsInCompactView(0, 2))
            .build()
    }

    private fun updateNotification() {
        if (!snapshot.sessionActive) return
        updatePlaybackState()
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(snapshot.trackName ?: "BreakMonster", snapshot.playing))
    }

    // HOME/minimize keeps playback. Removing the app task is an explicit close: stop and release.
    override fun onTaskRemoved(rootIntent: Intent?) {
        stopInternal()
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        resolverScope.cancel()
        handler.removeCallbacks(ticker)
        releasePlayer()
        releaseAudioFocus()
        if (::mediaSession.isInitialized) {
            mediaSession.isActive = false
            mediaSession.release()
        }
        if (activeInstance === this) activeInstance = null
        snapshot = Snapshot(random = random, repeat = repeat)
        super.onDestroy()
    }
}
