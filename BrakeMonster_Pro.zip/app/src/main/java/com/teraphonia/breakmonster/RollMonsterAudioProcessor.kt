package com.teraphonia.breakmonster

import android.os.SystemClock
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.floor

/** Small PCM-domain performance processor. It never changes ExoPlayer position: input is
 * consumed continuously and short captured fragments are repeated only in the output. */
internal class RollMonsterAudioProcessor : AudioProcessor {
    private val shufflePermutation = intArrayOf(0, 4, 2, 6, 1, 5, 3, 7)
    data class Command(val preset: Int, val bars: Double, val bpm: Int, val anchorNs: Long, val generation: Long)

    @Volatile var bpm: Int = 0
        private set
    @Volatile private var anchorNs: Long = SystemClock.elapsedRealtimeNanos()
    private fun publishAnalyzedTempo(value: Int, phaseNs: Long = SystemClock.elapsedRealtimeNanos()) {
        if (value in 40..220) { bpm = value; anchorNs = phaseNs }
    }

    private val command = AtomicReference<Command?>(null)
    @Volatile var processedFrames: Long = 0L
        private set
    private var generation = 0L
    private var commandPresent = false
    fun activate(preset: Int, bars: Double) {
        val tempo = bpm
        if (preset in -1..11 && bars > 0.0 && tempo in 40..220) command.set(Command(preset, bars, tempo, anchorNs, ++generation))
    }
    fun deactivate() { command.set(null) }

    private var inputFormat = AudioProcessor.AudioFormat.NOT_SET
    private var outputFormat = AudioProcessor.AudioFormat.NOT_SET
    private var output = AudioProcessor.EMPTY_BUFFER
    private var reusableOutput = AudioProcessor.EMPTY_BUFFER
    private var channels = 0
    private var bytesPerSample = 0
    private var floatPcm = false
    private var sampleRate = 0
    private var ring = FloatArray(0)
    private var ringFrames = 0
    private var ringWrite = 0
    private var loop = FloatArray(0)
    private var loopFrames = 0
    private var targetLoopFrames = 0
    private var loopCursor = 0.0
    private var frameCounter = 0L
    private var activationFrame = Long.MAX_VALUE
    private var active: Command? = null
    private var pendingCommand: Command? = null
    private var seenGeneration = -1L
    private var wet = 0f
    private var wetTarget = 0f
    private var blendStep = 0f
    private var blendFrames = 0
    private var effectFrames = 0L
    private var wetFrame = FloatArray(2)
    private var lowPassState = FloatArray(2)
    private var delayLine = FloatArray(0)
    private var delayWrite = 0
    private var delayWriteValues = FloatArray(2)
    private var chaosState = 0x6D2B79F5
    private var chaosGain = 1f
    private var lowChopCoefficient = 0f
    private var highChopCoefficient = 0f
    private var chaosFilterCoefficient = 0f
    private var deactivateAfterFade = false
    @Volatile var effectRunning = false
        private set
    private var inputEnded = false
    private var analysisFrames = 0
    private var envelopeAccumulator = 0f
    private var envelopeSamples = 0
    private val envelope = FloatArray(1600)
    @Volatile private var envelopeWrite = 0
    @Volatile private var envelopeCount = 0
    private var lastTempoAnalysisAt = 0L
    @Volatile private var tempoAnalysisRequested = false
    @Volatile private var tempoWorkerRunning = false
    @Volatile private var tempoWorker: Thread? = null

    fun resetTempoAnalysis() {
        bpm = 0
        anchorNs = SystemClock.elapsedRealtimeNanos()
        analysisFrames = 0; envelopeAccumulator = 0f; envelopeSamples = 0
        envelopeWrite = 0; envelopeCount = 0; lastTempoAnalysisAt = 0L
        envelope.fill(0f)
    }

    override fun configure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT && inputAudioFormat.encoding != C.ENCODING_PCM_FLOAT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        inputFormat = inputAudioFormat
        outputFormat = inputAudioFormat
        channels = inputAudioFormat.channelCount
        wetFrame = FloatArray(channels)
        lowPassState = FloatArray(channels)
        delayWriteValues = FloatArray(channels)
        sampleRate = inputAudioFormat.sampleRate
        lowChopCoefficient = onePoleCoefficient(420.0, sampleRate)
        highChopCoefficient = onePoleCoefficient(2400.0, sampleRate)
        chaosFilterCoefficient = onePoleCoefficient(1400.0, sampleRate)
        bytesPerSample = if (inputAudioFormat.encoding == C.ENCODING_PCM_FLOAT) 4 else 2
        floatPcm = bytesPerSample == 4
        // 8 bars at the minimum supported 40 BPM take 48 seconds.
        ringFrames = (sampleRate * 48.1f).toInt().coerceAtLeast(1)
        ring = FloatArray(ringFrames * channels)
        // Preallocated per-deck delay memory. No delay allocation occurs in queueInput().
        delayLine = FloatArray((sampleRate * 1.5f).toInt().coerceAtLeast(2) * channels)
        loop = FloatArray(ringFrames * channels)
        reusableOutput = ByteBuffer.allocateDirect(sampleRate * channels * bytesPerSample)
            .order(ByteOrder.LITTLE_ENDIAN)
        startTempoWorker()
        clearState()
        return outputFormat
    }

    override fun isActive(): Boolean = outputFormat != AudioProcessor.AudioFormat.NOT_SET
    override fun getOutput(): ByteBuffer {
        val result = output
        output = AudioProcessor.EMPTY_BUFFER
        if (result !== AudioProcessor.EMPTY_BUFFER) reusableOutput = result
        return result
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val frames = inputBuffer.remaining() / (bytesPerSample * channels)
        if (frames == 0) return
        val input = inputBuffer.slice().order(ByteOrder.LITTLE_ENDIAN)
        val needed = frames * channels * bytesPerSample
        val out = if (!reusableOutput.hasRemaining() && reusableOutput !== AudioProcessor.EMPTY_BUFFER && reusableOutput.capacity() >= needed) {
            reusableOutput.clear().limit(needed)
            reusableOutput.order(ByteOrder.LITTLE_ENDIAN)
        } else ByteBuffer.allocateDirect(needed).order(ByteOrder.LITTLE_ENDIAN)
        consumeCommand()
        for (frame in 0 until frames) {
            if (frameCounter >= activationFrame && active != null && loopFrames == 0) captureLoop()
            // Non-loop effects stay active until the performer presses the same button again.
            val hasEffectFrame = active != null && loopFrames > 0 && frameCounter >= activationFrame
            if (hasEffectFrame && active?.preset == -1) processEffect(wetFrame)
            for (ch in 0 until channels) {
                val dry = if (floatPcm) input.float else input.short.toFloat() / 32768f
                val source = dry.coerceIn(-1f, 1f)
                delayWriteValues[ch] = source
                ring[ringWrite * channels + ch] = source
                envelopeAccumulator += kotlin.math.abs(source)
                val effect = if (hasEffectFrame) {
                    if (active?.preset == -1) wetFrame[ch] else liveEffect(source, ch)
                } else source
                delayLine[delayWrite * channels + ch] = delayWriteValues[ch]
                // Fade to the live PCM in the last 12 ms of a scheduled release,
                // while still rendering the entire loop phrase.
                val effectiveWet = wet
                val mixed = source * (1f - effectiveWet) + effect * effectiveWet
                val bounded = mixed.coerceIn(-1f, 1f)
                if (floatPcm) out.putFloat(bounded)
                else out.putShort((bounded * 32767f).toInt().toShort())
            }
            envelopeSamples += channels
            if (envelopeSamples >= channels * (sampleRate / 100).coerceAtLeast(1)) {
                envelope[envelopeWrite] = envelopeAccumulator / envelopeSamples
                envelopeWrite = (envelopeWrite + 1) % envelope.size
                envelopeCount = (envelopeCount + 1).coerceAtMost(envelope.size)
                envelopeAccumulator = 0f
                envelopeSamples = 0
                analysisFrames++
                if (analysisFrames >= 800 && analysisFrames - lastTempoAnalysisAt >= 150) {
                    tempoAnalysisRequested = true
                    lastTempoAnalysisAt = analysisFrames.toLong()
                }
            }
            if (hasEffectFrame && active?.preset != -1) effectFrames++
            ringWrite = (ringWrite + 1) % ringFrames
            delayWrite = (delayWrite + 1) % (delayLine.size / channels).coerceAtLeast(1)
            frameCounter++
            if (blendFrames > 0) {
                wet = (wet + blendStep).coerceIn(0f, 1f)
                blendFrames--
                if (blendFrames == 0) {
                    wet = wetTarget
                    if (deactivateAfterFade && wet == 0f) {
                        active = null
                        loopFrames = 0
                        effectRunning = false
                        deactivateAfterFade = false
                    }
                    if (wet == 0f && pendingCommand != null) {
                        val next = pendingCommand!!
                        pendingCommand = null
                        active = next
                        effectRunning = next.preset >= 0
                        loopFrames = 0
                        loopCursor = 0.0
                        effectFrames = 0L
                        deactivateAfterFade = false
                        scheduleActivation(next)
                    }
                }
            }
        }
        processedFrames += frames.toLong()
        out.flip()
        output = out
        inputBuffer.position(inputBuffer.limit())
    }

    private fun consumeCommand() {
        val request = command.get()
        if (request == null) {
            if (!commandPresent) return
            commandPresent = false
            pendingCommand = null
            deactivateAfterFade = true
            wetTarget = 0f
            blendFrames = (sampleRate * 0.012f).toInt().coerceAtLeast(1)
            blendStep = (wetTarget - wet) / blendFrames
            return
        }
        if (request.generation == seenGeneration) return
        commandPresent = true
        seenGeneration = request.generation
        if (active != null && wet > 0f) {
            pendingCommand = request
            deactivateAfterFade = false
            wetTarget = 0f
            blendFrames = (sampleRate * 0.012f).toInt().coerceAtLeast(1)
            blendStep = (wetTarget - wet) / blendFrames
            return
        }
        active = request
        effectRunning = request.preset >= 0
        pendingCommand = null
        deactivateAfterFade = false
        loopFrames = 0
        loopCursor = 0.0
        effectFrames = 0L
        scheduleActivation(request)
    }

    private fun targetFramesFor(request: Command): Int =
        floor(sampleRate * 60.0 / request.bpm * 4.0 * request.bars).toInt().coerceIn(2, ringFrames - 1)

    private fun scheduleActivation(request: Command) {
        targetLoopFrames = targetFramesFor(request)
        loopFrames = 0
        // Effects engage on the next PCM frame; never wait for a bar boundary.
        activationFrame = frameCounter
        wetTarget = 1f
        blendFrames = (sampleRate * 0.012f).toInt().coerceAtLeast(1)
        blendStep = (wetTarget - wet) / blendFrames
    }

    private fun captureLoop() {
        loopFrames = targetLoopFrames.coerceIn(2, ringFrames - 1)
        val start = (ringWrite - loopFrames + ringFrames) % ringFrames
        val firstFrames = minOf(loopFrames, ringFrames - start)
        val firstSamples = firstFrames * channels
        System.arraycopy(ring, start * channels, loop, 0, firstSamples)
        val restSamples = (loopFrames - firstFrames) * channels
        if (restSamples > 0) System.arraycopy(ring, 0, loop, firstSamples, restSamples)
        loopCursor = 0.0
        wetTarget = 1f
        blendFrames = (sampleRate * 0.012f).toInt().coerceAtLeast(1)
        blendStep = (wetTarget - wet) / blendFrames
    }

    /** Realtime PCM effects. PCM input is always consumed in order; reverse and
     * scratch read only bounded captured history and never alter ExoPlayer position. */
    private fun liveEffect(sample: Float, channel: Int): Float {
        val cmd = active ?: return sample
        val beat = (sampleRate * 60.0 / cmd.bpm.coerceIn(40, 220)).coerceAtLeast(1.0)
        val phase = (effectFrames % beat.toLong().coerceAtLeast(1L)) / beat
        val delayCapacity = (delayLine.size / channels).coerceAtLeast(1)
        delayWriteValues[channel] = sample
        return when (cmd.preset) {
            0 -> { // SHUFFLE: bijective eighth-note permutation of the preceding beat.
                val eighth = beat / 8.0
                val outSlot = (phase * 8.0).toInt().coerceIn(0, 7)
                val within = phase * beat - outSlot * eighth
                val sourcePosition = shufflePermutation[outSlot] * eighth + within
                historyAt(beat + phase * beat - sourcePosition, channel)
            }
            1 -> { // BOUNCE: forward/reverse half-beat passes over the prior beat.
                val leg = (phase * 2.0).toInt().coerceIn(0, 1)
                val within = (phase * 2.0) - leg
                val sourcePosition = leg * beat / 2.0 + (if (leg == 0) within else 1.0 - within) * beat / 2.0
                historyAt(beat + phase * beat - sourcePosition, channel)
            }
            2 -> { // SYNCOP: offbeat, tempo-locked delay with bounded feedback.
                val delayFrames = (beat / 2.0).toInt().coerceIn(1, delayCapacity - 1)
                val delayed = delayAt(delayFrames, channel, delayCapacity)
                delayWriteValues[channel] = (sample + delayed * 0.24f).coerceIn(-1f, 1f)
                (sample * 0.72f + delayed * 0.48f).coerceIn(-1f, 1f)
            }
            3 -> { // GATE: beat-synced amplitude envelope with short attack/release edges.
                val edge = (sampleRate * 0.006).coerceAtLeast(1.0) / beat
                val local = phase % 0.5
                val gain = when {
                    local < edge -> (local / edge).toFloat()
                    local > 0.5 - edge -> ((0.5 - local) / edge).toFloat()
                    phase < 0.5 -> 1f
                    else -> 0.035f
                }
                sample * gain.coerceIn(0f, 1f)
            }
            4 -> { // CHOP: alternating low/high-pass sections, not volume chopping.
                val highSection = ((phase * 8.0).toInt() and 1) == 1
                val coefficient = if (highSection) highChopCoefficient else lowChopCoefficient
                val low = lowPassState[channel] + coefficient * (sample - lowPassState[channel])
                lowPassState[channel] = low
                if (highSection) (sample - low) else low
            }
            5 -> { // STUTTER: repeatedly retrigger a captured 1/8-beat grain.
                val grain = (beat / 8.0).toInt().coerceIn(2, loopFrames.coerceAtLeast(2))
                loopAt((effectFrames % grain).toDouble(), channel)
            }
            6 -> { // RETRIGGER: retrigger the captured beat at the original tempo.
                val segment = beat.toInt().coerceIn(2, loopFrames.coerceAtLeast(2))
                loopAt((effectFrames % segment).toDouble(), channel)
            }
            7 -> { // REVERSE: play a bounded captured beat backwards.
                val segment = beat.toInt().coerceIn(2, loopFrames.coerceAtLeast(2))
                val position = loopFrames - 1.0 - (effectFrames % segment)
                loopAt(position, channel)
            }
            8 -> { // SCRATCH: variable-speed forward/back platter motion in captured PCM.
                val segment = loopFrames.coerceAtLeast(2)
                val u = (effectFrames % (sampleRate * 0.7).toInt().coerceAtLeast(2)) /
                    (sampleRate * 0.7).toInt().coerceAtLeast(2).toDouble()
                val triangle = if (u < 0.5) u * 2.0 else 2.0 - u * 2.0
                loopAt(triangle * (segment - 1), channel)
            }
            9 -> { // BRAKE: decelerating playback head through one captured beat.
                val segment = beat.toInt().coerceIn(2, loopFrames.coerceAtLeast(2))
                val u = phase
                val start = loopFrames - segment
                val position = (start + segment * (u - 0.42 * u * u)).coerceIn(start.toDouble(), loopFrames - 1.0)
                loopAt(position, channel)
            }
            10 -> { // CHAOS: bounded, modulated multitap delay plus moving filter cutoff.
                if (channel == 0 && effectFrames % (sampleRate / 10).coerceAtLeast(1) == 0L) {
                    chaosState = chaosState xor (chaosState shl 13)
                    chaosState = chaosState xor (chaosState ushr 17)
                    chaosState = chaosState xor (chaosState shl 5)
                    chaosGain = 0.18f + ((chaosState ushr 1) and 0xFF).toFloat() / 900f
                    val cutoff = 300.0 + (chaosState and 0x7FF).toDouble() * 2.2
                    chaosFilterCoefficient = onePoleCoefficient(cutoff, sampleRate)
                }
                val delayA = (beat * (0.18 + (chaosState and 0x3F) / 220.0)).toInt().coerceIn(1, delayCapacity - 1)
                val delayB = (delayA * 1.61).toInt().coerceIn(1, delayCapacity - 1)
                val echoes = delayAt(delayA, channel, delayCapacity) * 0.35f + delayAt(delayB, channel, delayCapacity) * 0.20f
                delayWriteValues[channel] = (sample + echoes * chaosGain).coerceIn(-1f, 1f)
                lowPassState[channel] += chaosFilterCoefficient * (sample + echoes - lowPassState[channel])
                (sample * 0.55f + lowPassState[channel] * 0.45f).coerceIn(-1f, 1f)
            }
            11 -> { // TRIPLET: tempo-locked triplet echo with damped feedback.
                val one = (beat / 3.0).toInt().coerceIn(1, delayCapacity - 1)
                val two = (beat * 2.0 / 3.0).toInt().coerceIn(1, delayCapacity - 1)
                val echoes = delayAt(one, channel, delayCapacity) * 0.44f + delayAt(two, channel, delayCapacity) * 0.25f
                delayWriteValues[channel] = (sample + echoes * 0.36f).coerceIn(-1f, 1f)
                (sample * 0.78f + echoes * 0.65f).coerceIn(-1f, 1f)
            }
            else -> sample
        }
    }

    private fun historyAt(ageFrames: Double, channel: Int): Float {
        val age = ageFrames.coerceIn(0.0, (ringFrames - 1).toDouble())
        val whole = floor(age).toInt()
        val fraction = (age - whole).toFloat()
        val first = (ringWrite - whole + ringFrames) % ringFrames
        val second = (first - 1 + ringFrames) % ringFrames
        val a = ring[first * channels + channel]
        val b = ring[second * channels + channel]
        return a + (b - a) * fraction
    }

    private fun loopAt(position: Double, channel: Int): Float {
        val length = loopFrames.coerceAtLeast(1)
        val pos = position.coerceIn(0.0, (length - 1).toDouble())
        val base = floor(pos).toInt()
        val next = (base + 1).coerceAtMost(length - 1)
        val fraction = (pos - base).toFloat()
        val a = loop[base * channels + channel]
        val b = loop[next * channels + channel]
        return a + (b - a) * fraction
    }

    private fun delayAt(delayFrames: Int, channel: Int, capacity: Int): Float {
        val index = (delayWrite - delayFrames + capacity) % capacity
        return delayLine[index * channels + channel]
    }

    private fun onePoleCoefficient(cutoff: Double, rate: Int): Float =
        (1.0 - kotlin.math.exp(-2.0 * Math.PI * cutoff / rate.coerceAtLeast(1))).toFloat()

    private fun processEffect(result: FloatArray) {
        val len = loopFrames.coerceAtLeast(1)
        val base = loopCursor.toInt().coerceIn(0, len - 1)
        val frac = (loopCursor - base).toFloat()
        val next = (base + 1) % len
        for (ch in 0 until channels) {
            val a = loop[base * channels + ch]
            val b = loop[next * channels + ch]
            result[ch] = a + (b - a) * frac
        }
        loopCursor += 1.0
        if (loopCursor >= len) loopCursor = 0.0
        effectFrames++
    }

    override fun queueEndOfStream() { inputEnded = true }
    override fun isEnded(): Boolean = inputEnded && output === AudioProcessor.EMPTY_BUFFER
    override fun flush() {
        output = AudioProcessor.EMPTY_BUFFER
        reusableOutput.position(0)
        reusableOutput.limit(0)
        inputEnded = false
        clearState()
    }
    override fun reset() {
        stopTempoWorker()
        flush()
        inputFormat = AudioProcessor.AudioFormat.NOT_SET
        outputFormat = AudioProcessor.AudioFormat.NOT_SET
        ring = FloatArray(0); loop = FloatArray(0); delayLine = FloatArray(0); reusableOutput = AudioProcessor.EMPTY_BUFFER
        channels = 0; sampleRate = 0; bytesPerSample = 0
        wetFrame = FloatArray(2)
        lowPassState = FloatArray(2); delayWriteValues = FloatArray(2)
    }

    private fun clearState() {
        ring.fill(0f)
        loop.fill(0f)
        delayLine.fill(0f)
        lowPassState.fill(0f)
        delayWriteValues.fill(0f)
        processedFrames = 0L; ringWrite = 0; delayWrite = 0; frameCounter = 0L; active = null; pendingCommand = null; deactivateAfterFade = false; seenGeneration = -1L; commandPresent = false
        loopFrames = 0; targetLoopFrames = 0; loopCursor = 0.0; wet = 0f; wetTarget = 0f
        activationFrame = Long.MAX_VALUE; blendFrames = 0; effectFrames = 0L
    }

    /** Keep normalized autocorrelation off ExoPlayer's realtime PCM callback. */
    private fun startTempoWorker() {
        if (tempoWorkerRunning) return
        tempoWorkerRunning = true
        tempoWorker = Thread({
            while (tempoWorkerRunning) {
                if (tempoAnalysisRequested) {
                    tempoAnalysisRequested = false
                    estimateTempo()
                } else {
                    try { Thread.sleep(20L) } catch (_: InterruptedException) { }
                }
            }
        }, "BrakeMonster-tempo").apply { isDaemon = true; start() }
    }

    private fun stopTempoWorker() {
        tempoWorkerRunning = false
        tempoAnalysisRequested = false
        tempoWorker?.interrupt()
        tempoWorker = null
    }

    /** Estimate tempo from the actual PCM amplitude envelope (10 ms bins), using normalized autocorrelation. */
    private fun estimateTempo() {
        val count = envelopeCount
        if (count < 800) return
        val minLag = 27 // 40..220 BPM
        val maxLag = 150
        val window = minOf(count - maxLag, 1100)
        if (window < 250) return
        fun sample(i: Int): Float = envelope[(envelopeWrite - count + i + envelope.size) % envelope.size]
        var mean = 0.0
        for (i in count - window until count) mean += sample(i)
        mean /= window
        var energy = 0.0
        for (i in count - window until count) { val d = sample(i) - mean; energy += d * d }
        if (energy < 1e-6) return
        var bestLag = 0
        var best = 0.0
        for (lag in minLag..maxLag) {
            var correlation = 0.0
            var left = 0.0
            var right = 0.0
            for (i in count - window until count - lag) {
                val a = sample(i) - mean
                val b = sample(i + lag) - mean
                correlation += a * b; left += a * a; right += b * b
            }
            val score = if (left > 0 && right > 0) correlation / kotlin.math.sqrt(left * right) else 0.0
            if (score > best) { best = score; bestLag = lag }
        }
        if (bestLag > 0 && best >= 0.18) {
            var estimated = (6000.0 / bestLag).toInt()
            while (estimated < 60) estimated *= 2
            while (estimated > 180) estimated /= 2
            publishAnalyzedTempo(estimated)
        }
    }
}
