package com.teraphonia.breakmonster

import android.os.SystemClock
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.floor

/** Small PCM-domain performance processor. It never changes ExoPlayer position: input is
 * consumed continuously and short captured fragments are repeated only in the output. */
internal class RollMonsterAudioProcessor : AudioProcessor {
    data class Command(val preset: Int, val bars: Double, val bpm: Int, val anchorNs: Long, val generation: Long)

    @Volatile var bpm: Int = 0
        private set
    @Volatile private var anchorNs: Long = SystemClock.elapsedRealtimeNanos()
    private fun publishAnalyzedTempo(value: Int, phaseNs: Long = SystemClock.elapsedRealtimeNanos()) {
        if (value in 40..220) { bpm = value; anchorNs = phaseNs }
    }

    private val command = AtomicReference<Command?>(null)
    @Volatile var processedFrames: Long = 0L
        private set
    private var generation = 0L
    private var commandPresent = false
    fun activate(preset: Int, bars: Double) {
        val tempo = bpm
        if (preset in -1..11 && bars > 0.0 && tempo in 40..220) command.set(Command(preset, bars, tempo, anchorNs, ++generation))
    }
    fun deactivate() { command.set(null) }

    private var inputFormat = AudioProcessor.AudioFormat.NOT_SET
    private var outputFormat = AudioProcessor.AudioFormat.NOT_SET
    private var output = AudioProcessor.EMPTY_BUFFER
    private var reusableOutput = AudioProcessor.EMPTY_BUFFER
    private var channels = 0
    private var bytesPerSample = 0
    private var floatPcm = false
    private var sampleRate = 0
    private var ring = FloatArray(0)
    private var ringFrames = 0
    private var ringWrite = 0
    private var loop = FloatArray(0)
    private var loopFrames = 0
    private var targetLoopFrames = 0
    private var loopCursor = 0.0
    private var frameCounter = 0L
    private var activationFrame = Long.MAX_VALUE
    private var active: Command? = null
    private var pendingCommand: Command? = null
    private var releaseAtBoundary = false
    private var exitFadeFrames = 0
    private var seenGeneration = -1L
    private var wet = 0f
    private var wetTarget = 0f
    private var blendStep = 0f
    private var blendFrames = 0
    private var effectFrames = 0L
    private var oldPreset = -1
    private var newPreset = -1
    private var wetFrame = FloatArray(2)
    private var inputEnded = false
    private var analysisFrames = 0
    private var envelopeAccumulator = 0f
    private var envelopeSamples = 0
    private val envelope = FloatArray(1600)
    private var envelopeWrite = 0
    private var envelopeCount = 0
    private var lastTempoAnalysisAt = 0L

    fun resetTempoAnalysis() {
        bpm = 0
        anchorNs = SystemClock.elapsedRealtimeNanos()
        analysisFrames = 0; envelopeAccumulator = 0f; envelopeSamples = 0
        envelopeWrite = 0; envelopeCount = 0; lastTempoAnalysisAt = 0L
        envelope.fill(0f)
    }

    override fun configure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT && inputAudioFormat.encoding != C.ENCODING_PCM_FLOAT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        inputFormat = inputAudioFormat
        outputFormat = inputAudioFormat
        channels = inputAudioFormat.channelCount
        wetFrame = FloatArray(channels)
        sampleRate = inputAudioFormat.sampleRate
        bytesPerSample = if (inputAudioFormat.encoding == C.ENCODING_PCM_FLOAT) 4 else 2
        floatPcm = bytesPerSample == 4
        ringFrames = (sampleRate * 32.2f).toInt().coerceAtLeast(1)
        ring = FloatArray(ringFrames * channels)
        clearState()
        return outputFormat
    }

    override fun isActive(): Boolean = outputFormat != AudioProcessor.AudioFormat.NOT_SET
    override fun getOutput(): ByteBuffer {
        val result = output
        output = AudioProcessor.EMPTY_BUFFER
        if (result !== AudioProcessor.EMPTY_BUFFER) reusableOutput = result
        return result
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val frames = inputBuffer.remaining() / (bytesPerSample * channels)
        if (frames == 0) return
        val input = inputBuffer.slice().order(ByteOrder.LITTLE_ENDIAN)
        val needed = frames * channels * bytesPerSample
        val out = if (!reusableOutput.hasRemaining() && reusableOutput !== AudioProcessor.EMPTY_BUFFER && reusableOutput.capacity() >= needed) {
            reusableOutput.clear().limit(needed)
            reusableOutput.order(ByteOrder.LITTLE_ENDIAN)
        } else ByteBuffer.allocateDirect(needed).order(ByteOrder.LITTLE_ENDIAN)
        consumeCommand()
        for (frame in 0 until frames) {
            if (frameCounter >= activationFrame && active != null && loopFrames == 0) captureLoop()
            // Commit all user requests only after the current two-bar phrase.
            if (active != null && loopFrames > 0 && effectFrames > 0L && effectFrames % loopFrames.toLong() == 0L) {
                if (releaseAtBoundary) {
                    active = null
                    releaseAtBoundary = false
                    pendingCommand = null
                    loopFrames = 0
                    wet = 0f
                    wetTarget = 0f
                    blendFrames = 0
                } else if (pendingCommand != null) {
                    active = pendingCommand
                    pendingCommand = null
                    effectFrames = 0L
                    loopCursor = 0.0
                }
            }
            val hasEffectFrame = active != null && loopFrames > 0 && frameCounter >= activationFrame
            if (hasEffectFrame) processEffect(wetFrame)
            for (ch in 0 until channels) {
                val dry = if (floatPcm) input.float else input.short.toFloat() / 32768f
                val source = dry.coerceIn(-1f, 1f)
                ring[ringWrite * channels + ch] = source
                envelopeAccumulator += kotlin.math.abs(source)
                val effect = if (hasEffectFrame) wetFrame[ch] else source
                // Fade to the live PCM in the last 12 ms of a scheduled release,
                // while still rendering the entire loop phrase.
                val exitGain = if (releaseAtBoundary && hasEffectFrame && exitFadeFrames > 0) {
                    (loopFrames.toLong() - (effectFrames - 1L) % loopFrames.toLong()).toFloat()
                        .div(exitFadeFrames).coerceIn(0f, 1f)
                } else 1f
                val effectiveWet = wet * exitGain
                val mixed = source * (1f - effectiveWet) + effect * effectiveWet
                val bounded = mixed.coerceIn(-1f, 1f)
                if (floatPcm) out.putFloat(bounded)
                else out.putShort((bounded * 32767f).toInt().toShort())
            }
            envelopeSamples += channels
            if (envelopeSamples >= channels * (sampleRate / 100).coerceAtLeast(1)) {
                envelope[envelopeWrite] = envelopeAccumulator / envelopeSamples
                envelopeWrite = (envelopeWrite + 1) % envelope.size
                envelopeCount = (envelopeCount + 1).coerceAtMost(envelope.size)
                envelopeAccumulator = 0f
                envelopeSamples = 0
                analysisFrames++
                if (analysisFrames >= 800 && analysisFrames - lastTempoAnalysisAt >= 150) {
                    estimateTempo()
                    lastTempoAnalysisAt = analysisFrames.toLong()
                }
            }
            ringWrite = (ringWrite + 1) % ringFrames
            frameCounter++
            if (blendFrames > 0) {
                wet = (wet + blendStep).coerceIn(0f, 1f)
                blendFrames--
                if (blendFrames == 0) {
                    wet = wetTarget
                    if (wet == 0f && pendingCommand != null) {
                        val next = pendingCommand!!
                        pendingCommand = null
                        active = next
                        scheduleActivation(next)
                    }
                }
            }
        }
        processedFrames += frames.toLong()
        out.flip()
        output = out
        inputBuffer.position(inputBuffer.limit())
    }

    private fun consumeCommand() {
        val request = command.get()
        if (request == null) {
            if (!commandPresent) return
            commandPresent = false
            if (active != null && loopFrames > 0) {
                releaseAtBoundary = true
                pendingCommand = null
                exitFadeFrames = (sampleRate * 0.012f).toInt().coerceAtLeast(1)
            } else {
                active = null
                pendingCommand = null
                loopFrames = 0
                activationFrame = Long.MAX_VALUE
                wet = 0f
                wetTarget = 0f
                blendFrames = 0
            }
            return
        }
        if (request.generation == seenGeneration) return
        commandPresent = true
        seenGeneration = request.generation
        if (active != null && loopFrames > 0) {
            // Queue FX/LOOP replacement at the exact end of the current phrase.
            pendingCommand = request
            releaseAtBoundary = false
            return
        }
        active = request
        pendingCommand = null
        releaseAtBoundary = false
        loopFrames = 0
        loopCursor = 0.0
        effectFrames = 0L
        scheduleActivation(request)
    }

    private fun scheduleActivation(request: Command) {
        targetLoopFrames = floor(sampleRate * 60.0 / request.bpm * 4.0 * request.bars).toInt().coerceIn(2, ringFrames - 1)
        loopFrames = 0
        // Quantize activation to the NEXT full loop boundary. The preceding
        // complete 1/2/4 bars are already in the PCM ring at that instant.
        // A real downbeat phase detector is still needed for absolute song alignment.
        val period = targetLoopFrames.toLong()
        activationFrame = ((frameCounter / period) + 1L) * period
        wetTarget = 1f
        blendFrames = (sampleRate * 0.012f).toInt().coerceAtLeast(1)
        blendStep = (wetTarget - wet) / blendFrames
    }

    private fun captureLoop() {
        loopFrames = targetLoopFrames.coerceIn(2, ringFrames - 1)
        loop = FloatArray(loopFrames * channels)
        var index = (ringWrite - loopFrames + ringFrames) % ringFrames
        for (frame in 0 until loopFrames) {
            for (ch in 0 until channels) loop[frame * channels + ch] = ring[index * channels + ch]
            index = (index + 1) % ringFrames
        }
        loopCursor = 0.0
        wet = 0f
        wetTarget = 1f
        blendFrames = (sampleRate * 0.012f).toInt().coerceAtLeast(1)
        blendStep = 1f / blendFrames
    }

    private fun processEffect(result: FloatArray) {
        val cmd = active ?: return
        val len = loopFrames.coerceAtLeast(1)
        val beatFrames = sampleRate * 60.0 / cmd.bpm.coerceIn(30, 240)
        val phaseBeat = (effectFrames % beatFrames.toLong().coerceAtLeast(1L)).toDouble() / beatFrames
        var pos = loopCursor
        var gain = 1.0
        var advance = 1.0
        when (cmd.preset) {
            -1 -> Unit // clean, unmodified musical loop
            0 -> { val swing = if (phaseBeat < 0.6667) 1.0 else 0.5; advance = swing }
            1 -> { val leg = (effectFrames / len).toInt(); if (leg % 2 == 1) pos = len - 1.0 - loopCursor }
            2 -> { if (phaseBeat < 0.5) gain = 0.08 }
            3 -> gain = if (phaseBeat < 0.5) 1.0 else 0.035
            4 -> gain = if ((floor(phaseBeat * 8).toInt() % 2) == 0) 1.0 else 0.025
            5 -> advance = if (effectFrames % (len * 4L) < len) 0.0 else 1.0
            6 -> advance = if (effectFrames % (len * 2L) < len) 0.0 else 1.0
            7 -> pos = len - 1.0 - loopCursor
            8 -> { val x = (loopCursor * 2.0) % (len * 2.0); pos = if (x < len) x else len * 2.0 - x - 1.0; advance = 1.7 }
            9 -> { val elapsed = effectFrames / sampleRate.toDouble(); advance = (1.0 - elapsed * 0.20).coerceAtLeast(0.18) }
            10 -> { gain = if ((floor(phaseBeat * 8).toInt() % 3) == 0) 0.22 else 1.0; advance = if (phaseBeat > .65) 1.8 else .65 }
            11 -> Unit
            /* old preset mappings retained in the twelve special-effect slots:
            5 -> { // 2:1 swing feel, alternating long and short fragment holds
                val swing = if (phaseBeat < 0.6667) 1.0 else 0.5
                advance = swing
            }
            6 -> { val leg = (effectFrames / len).toInt(); if (leg % 2 == 1) pos = len - 1.0 - loopCursor }
            7 -> { // offbeat accents; suppress the on-beat half
                if (phaseBeat < 0.5) gain = 0.08
            }
            8 -> gain = if (phaseBeat < 0.5) 1.0 else 0.035
            9 -> gain = if ((floor(phaseBeat * 8).toInt() % 2) == 0) 1.0 else 0.025
            10 -> advance = if (effectFrames % (len * 4L) < len) 0.0 else 1.0
            11 -> advance = if (effectFrames % (len * 2L) < len) 0.0 else 1.0
            12 -> pos = len - 1.0 - loopCursor
            13 -> { val x = (loopCursor * 2.0) % (len * 2.0); pos = if (x < len) x else len * 2.0 - x - 1.0; advance = 1.7 }
            14 -> { val elapsed = effectFrames / sampleRate.toDouble(); advance = (1.0 - elapsed * 0.20).coerceAtLeast(0.18) }
            15 -> { gain = if ((floor(phaseBeat * 8).toInt() % 3) == 0) 0.22 else 1.0; advance = if (phaseBeat > .65) 1.8 else .65 }
            */
        }
        val base = pos.toInt().coerceIn(0, len - 1)
        val frac = (pos - floor(pos)).coerceIn(0.0, 1.0).toFloat()
        val next = (base + 1) % len
        for (ch in 0 until channels) {
            val a = loop[base * channels + ch]
            val b = loop[next * channels + ch]
            result[ch] = ((a + (b - a) * frac) * gain).toFloat()
        }
        loopCursor += advance
        if (loopCursor >= len || loopCursor < 0) loopCursor %= len.toDouble()
        effectFrames++
    }

    override fun queueEndOfStream() { inputEnded = true }
    override fun isEnded(): Boolean = inputEnded && output === AudioProcessor.EMPTY_BUFFER
    override fun flush() { output = AudioProcessor.EMPTY_BUFFER; reusableOutput = AudioProcessor.EMPTY_BUFFER; inputEnded = false; clearState() }
    override fun reset() {
        flush()
        inputFormat = AudioProcessor.AudioFormat.NOT_SET
        outputFormat = AudioProcessor.AudioFormat.NOT_SET
        ring = FloatArray(0); loop = FloatArray(0); channels = 0; sampleRate = 0; bytesPerSample = 0
        wetFrame = FloatArray(2)
    }

    private fun clearState() {
        processedFrames = 0L; ringWrite = 0; frameCounter = 0L; active = null; pendingCommand = null; releaseAtBoundary = false; exitFadeFrames = 0; seenGeneration = -1L; commandPresent = false
        loopFrames = 0; targetLoopFrames = 0; loopCursor = 0.0; wet = 0f; wetTarget = 0f
        activationFrame = Long.MAX_VALUE; blendFrames = 0; effectFrames = 0L
    }

    /** Estimate tempo from the actual PCM amplitude envelope (10 ms bins), using normalized autocorrelation. */
    private fun estimateTempo() {
        val count = envelopeCount
        if (count < 800) return
        val minLag = 27 // 40..220 BPM
        val maxLag = 150
        val window = minOf(count - maxLag, 1100)
        if (window < 250) return
        fun sample(i: Int): Float = envelope[(envelopeWrite - count + i + envelope.size) % envelope.size]
        var mean = 0.0
        for (i in count - window until count) mean += sample(i)
        mean /= window
        var energy = 0.0
        for (i in count - window until count) { val d = sample(i) - mean; energy += d * d }
        if (energy < 1e-6) return
        var bestLag = 0
        var best = 0.0
        for (lag in minLag..maxLag) {
            var correlation = 0.0
            var left = 0.0
            var right = 0.0
            for (i in count - window until count - lag) {
                val a = sample(i) - mean
                val b = sample(i + lag) - mean
                correlation += a * b; left += a * a; right += b * b
            }
            val score = if (left > 0 && right > 0) correlation / kotlin.math.sqrt(left * right) else 0.0
            if (score > best) { best = score; bestLag = lag }
        }
        if (bestLag > 0 && best >= 0.18) {
            var estimated = (6000.0 / bestLag).toInt()
            while (estimated < 60) estimated *= 2
            while (estimated > 180) estimated /= 2
            publishAnalyzedTempo(estimated)
        }
    }
}
