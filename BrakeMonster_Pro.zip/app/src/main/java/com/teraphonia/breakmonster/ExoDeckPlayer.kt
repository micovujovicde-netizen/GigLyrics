package com.teraphonia.breakmonster

import android.content.Context
import android.net.Uri
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.AudioSink

/**
 * Physical Media3 audio deck. The service owns QUEUE/NEXT, audio focus, and mixer
 * policy; this adapter only handles media data, playback, and real buffer events.
 * All operations and listener callbacks run on the Android main looper.
 */
@OptIn(UnstableApi::class)
internal class ExoDeckPlayer(context: Context) {
    companion object {
        const val BUFFERING_START = 701
        const val BUFFERING_END = 702
    }

    private val httpFactory = DefaultHttpDataSource.Factory()
        .setAllowCrossProtocolRedirects(true)
        .setConnectTimeoutMs(8_000)
        .setReadTimeoutMs(8_000)
        .setDefaultRequestProperties(mapOf(
            "User-Agent" to "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/130.0 Mobile Safari/537.36",
            "Referer" to "https://www.youtube.com/"
        ))
    private val sourceFactory = DefaultDataSource.Factory(context.applicationContext, httpFactory)
    private val rollProcessor = RollMonsterAudioProcessor()
    private val renderersFactory = object : DefaultRenderersFactory(context.applicationContext) {
        override fun buildAudioSink(
            context: Context,
            enableFloatOutput: Boolean,
            enableAudioOutputPlaybackParams: Boolean
        ): AudioSink = DefaultAudioSink.Builder(context)
            .setAudioProcessors(arrayOf(rollProcessor))
            .build()
    }
    private val delegate = ExoPlayer.Builder(context.applicationContext, renderersFactory)
        .setMediaSourceFactory(androidx.media3.exoplayer.source.DefaultMediaSourceFactory(sourceFactory))
        .setLoadControl(DefaultLoadControl.Builder()
            .setBufferDurationsMs(2_000, 40_000, 750, 1_250)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build())
        .setLooper(Looper.getMainLooper())
        // Keep streaming and decoding alive when the UI is backgrounded.
        .setWakeMode(C.WAKE_MODE_NETWORK)
        .build().apply {
            // Audio focus remains solely under BreakPlaybackService control.
            setAudioAttributes(AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), false)
            repeatMode = Player.REPEAT_MODE_OFF
            playWhenReady = false
        }

    private var preparedListener: (() -> Unit)? = null
    private var completionListener: (() -> Unit)? = null
    private var errorListener: ((ExoDeckPlayer, Int, Int) -> Boolean)? = null
    private var infoListener: ((ExoDeckPlayer, Int, Int) -> Boolean)? = null
    private var bufferingListener: ((ExoDeckPlayer, Int) -> Unit)? = null
    private var preparedDispatched = false
    private var lastBufferPercent = -1
    private var lastBuffering: Boolean? = null
    private var released = false
    private var hasSource = false

    init {
        delegate.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (released || !hasSource) return
                if (state == Player.STATE_READY && !preparedDispatched) {
                    preparedDispatched = true
                    preparedListener?.invoke()
                }
                if (state == Player.STATE_ENDED) completionListener?.invoke()
                dispatchBufferState()
                pollBuffering()
            }

            override fun onIsLoadingChanged(isLoading: Boolean) {
                if (released || !hasSource) return
                dispatchBufferState()
                pollBuffering()
            }

            override fun onPlayerError(error: PlaybackException) {
                if (!released && hasSource) {
                    errorListener?.invoke(this@ExoDeckPlayer, error.errorCode, 0)
                }
            }
        })
    }

    val audioSessionId: Int get() = delegate.audioSessionId
    val duration: Int get() = delegate.duration.takeIf { it != C.TIME_UNSET && it >= 0L }
        ?.coerceAtMost(Int.MAX_VALUE.toLong())?.toInt() ?: 0
    val currentPosition: Int get() = delegate.currentPosition.coerceIn(0L, Int.MAX_VALUE.toLong()).toInt()
    val isPlaying: Boolean get() = delegate.isPlaying
    val isPrepared: Boolean get() = hasSource && preparedDispatched
    val bufferedAheadMs: Long get() = if (!released && hasSource)
        maxOf((delegate.bufferedPosition - delegate.currentPosition).coerceAtLeast(0L),
            delegate.totalBufferedDuration.coerceAtLeast(0L)) else 0L

    fun setSource(uri: Uri) {
        check(!released) { "Exo deck already released" }
        reset()
        hasSource = true
        delegate.setMediaItem(MediaItem.fromUri(uri))
    }

    fun prepareAsync() {
        check(hasSource && !released) { "Exo deck has no media source" }
        delegate.prepare() // Media3 prepare() is asynchronous.
    }

    fun start() {
        check(hasSource && !released) { "Exo deck not initialized" }
        delegate.play()
    }

    fun pause() { if (!released) delegate.pause() }
    fun stop() { if (!released) { releaseRollEffect(); delegate.stop(); delegate.playWhenReady = false } }
    fun seekTo(positionMs: Int) { if (!released && hasSource) delegate.seekTo(positionMs.toLong()) }
    fun reset() {
        if (released) return
        releaseRollEffect()
        hasSource = false
        preparedDispatched = false
        lastBufferPercent = -1
        lastBuffering = null
        delegate.stop()
        delegate.clearMediaItems()
        delegate.playWhenReady = false
    }
    fun release() { if (!released) { releaseRollEffect(); released = true; delegate.release() } }
    fun setVolume(left: Float, right: Float) {
        if (!released) delegate.volume = ((left + right) * 0.5f).coerceIn(0f, 1f)
    }
    fun setRollPreset(index: Int) { if (!released) rollProcessor.activate(index) }
    fun releaseRollEffect() { rollProcessor.deactivate() }
    fun setOnPreparedListener(listener: () -> Unit) { preparedListener = listener }
    fun setOnCompletionListener(listener: () -> Unit) { completionListener = listener }
    fun setOnErrorListener(listener: (ExoDeckPlayer, Int, Int) -> Boolean) { errorListener = listener }
    fun setOnInfoListener(listener: (ExoDeckPlayer, Int, Int) -> Boolean) { infoListener = listener }
    fun setOnBufferingUpdateListener(listener: (ExoDeckPlayer, Int) -> Unit) { bufferingListener = listener }

    private fun dispatchBufferState() {
        val stalled = delegate.playbackState == Player.STATE_BUFFERING
        if (stalled == lastBuffering) return
        lastBuffering = stalled
        infoListener?.invoke(this, if (stalled) BUFFERING_START else BUFFERING_END, 0)
    }

    /**
     * Consistent, actionable ahead-buffer percentage for EVERY selection path.
     * A whole-track percent is unsuitable here: 2% of a 90-minute file can
     * require 108 seconds before NEXT becomes available, despite Media3 READY.
     * Instead 100% means our configured 40-second look-ahead is filled; 2% is
     * 800 ms of actual queued audio. Media3 READY still controls playability.
     */
    fun pollBuffering() {
        if (released || !hasSource) return
        val aheadMs = (delegate.bufferedPosition - delegate.currentPosition).coerceAtLeast(0L)
        val bufferedMs = maxOf(aheadMs, delegate.totalBufferedDuration.coerceAtLeast(0L))
        val percent = ((bufferedMs * 100L) / 40_000L).coerceIn(0L, 100L).toInt()
        if (percent != lastBufferPercent) {
            lastBufferPercent = percent
            bufferingListener?.invoke(this, percent)
        }
    }
}
