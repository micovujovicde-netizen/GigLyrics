package com.teraphonia.breakmonster

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.roundToInt

/**
 * Always-installed, in-stream PCM DSP for the actual decoded audio (after RollMonster LOOP).
 * No ExoPlayer seek, stop, renderer rebuild, AudioTrack recreation, or audio focus changes.
 * Commands arrive from the main thread and are picked up on the audio thread atomically.
 * Changing an effect crossfades via dry PCM; all parameter updates are smoothed.
 */
internal class LiveFxAudioProcessor : AudioProcessor {
    companion object {
        const val OFF = -1
        const val LPF = 0
        const val HPF = 1
        const val BAND_PASS = 2
        const val NOTCH = 3
        const val BAND_KILL = 4
        const val DELAY = 5
        const val FLANGER = 6
        const val AUTO_PAN = 7
    }

    private data class Settings(val type: Int, val amount: Float, val division: Int, val bpm: Int)
    private val control = AtomicReference(Settings(OFF, .5f, 1, 0))
    fun set(type: Int, amount: Float, division: Int, bpm: Int) {
        control.set(Settings(type.coerceIn(OFF, AUTO_PAN), amount.coerceIn(0f, 1f), division.coerceIn(0, 2), bpm.takeIf { it in 40..220 } ?: 0))
    }

    @Volatile var processedFrames: Long = 0L
        private set

    private var format = AudioProcessor.AudioFormat.NOT_SET
    private var channels = 0
    private var sampleRate = 0
    private var floatPcm = false
    private var byteWidth = 0
    private var output = AudioProcessor.EMPTY_BUFFER
    private var spare = AudioProcessor.EMPTY_BUFFER
    private var endOfStream = false
    private var currentType = OFF
    private var wet = 0.0
    private var smoothedAmount = .5
    private var coefficientCounter = 0
    private var phase = 0.0
    private var delay = FloatArray(0)
    private var delaySize = 0
    private var delayCursor = 0
    private var z1 = DoubleArray(0)
    private var z2 = DoubleArray(0)
    private var bass = DoubleArray(0)
    private var trebleLowpass = DoubleArray(0)
    private var b0 = 1.0
    private var b1 = 0.0
    private var b2 = 0.0
    private var a1 = 0.0
    private var a2 = 0.0

    override fun configure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT && inputAudioFormat.encoding != C.ENCODING_PCM_FLOAT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        format = inputAudioFormat
        channels = inputAudioFormat.channelCount
        sampleRate = inputAudioFormat.sampleRate
        floatPcm = inputAudioFormat.encoding == C.ENCODING_PCM_FLOAT
        byteWidth = if (floatPcm) 4 else 2
        z1 = DoubleArray(channels)
        z2 = DoubleArray(channels)
        bass = DoubleArray(channels)
        trebleLowpass = DoubleArray(channels)
        // Enough history for a quarter-note delay at 40 BPM (1.5 s) + safety margin.
        delaySize = (sampleRate * 2.1).toInt().coerceAtLeast(2048)
        delay = FloatArray(delaySize * channels)
        clearAudioState()
        return inputAudioFormat
    }

    override fun isActive(): Boolean = format != AudioProcessor.AudioFormat.NOT_SET

    override fun queueInput(inputBuffer: ByteBuffer) {
        if (channels <= 0 || sampleRate <= 0) return
        val frames = inputBuffer.remaining() / (channels * byteWidth)
        if (frames == 0) return
        val bytes = frames * channels * byteWidth
        val source = inputBuffer.slice().order(ByteOrder.LITTLE_ENDIAN)
        val dest = if (spare !== AudioProcessor.EMPTY_BUFFER && !spare.hasRemaining() && spare.capacity() >= bytes) {
            spare.clear()
            spare.limit(bytes)
            spare.order(ByteOrder.LITTLE_ENDIAN)
        } else ByteBuffer.allocateDirect(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val settings = control.get()
        val ramp = 1.0 / (sampleRate * 0.025).coerceAtLeast(1.0)
        val tempo = settings.bpm.takeIf { it in 40..220 } ?: 0
        val noteBeats = when (settings.division) { 0 -> 1.0; 1 -> .5; else -> .25 }
        val periodSeconds = if (tempo > 0) 60.0 * (4.0 * noteBeats) / tempo else 1.0
        val delaySamples = if (tempo > 0) {
            ((60.0 / tempo) * noteBeats * sampleRate).toInt().coerceIn(1, delaySize - 1)
        } else 0
        val bassAlpha = 1.0 - kotlin.math.exp(-2.0 * PI * 250.0 / sampleRate)
        val trebleAlpha = 1.0 - kotlin.math.exp(-2.0 * PI * 2300.0 / sampleRate)
        for (frame in 0 until frames) {
            if (currentType != settings.type) {
                wet = max(0.0, wet - ramp)
                if (wet <= 0.00001) {
                    currentType = settings.type
                    z1.fill(0.0); z2.fill(0.0)
                    bass.fill(0.0); trebleLowpass.fill(0.0)
                    phase = 0.0
                    coefficientCounter = 0
                }
            } else {
                wet = if (currentType == OFF) max(0.0, wet - ramp) else min(1.0, wet + ramp)
            }
            if (++coefficientCounter >= 64) {
                coefficientCounter = 0
                smoothedAmount += (settings.amount.toDouble() - smoothedAmount) * .2
                if (currentType in LPF..NOTCH) updateBiquad(currentType, smoothedAmount)
            }
            val sweep = if (currentType == FLANGER || currentType == AUTO_PAN) sin(2.0 * PI * phase) else 0.0
            val flangerReadDelay = sampleRate * (.001 + .008 * smoothedAmount * (.5 + .5 * sweep))
            for (ch in 0 until channels) {
                val dry = if (floatPcm) source.float.toDouble() else source.short.toDouble() / 32768.0
                val d = dry.coerceIn(-1.0, 1.0)
                var effect = d
                var record = d
                when (currentType) {
                    LPF, HPF, BAND_PASS, NOTCH -> {
                        val value = b0 * d + z1[ch]
                        z1[ch] = b1 * d - a1 * value + z2[ch]
                        z2[ch] = b2 * d - a2 * value
                        effect = value
                    }
                    BAND_KILL -> {
                        bass[ch] += bassAlpha * (d - bass[ch])
                        trebleLowpass[ch] += trebleAlpha * (d - trebleLowpass[ch])
                        val low = bass[ch]
                        val high = d - trebleLowpass[ch]
                        val mid = d - low - high
                        // Continuous morph between the three kills, so dragging
                        // across BASS/MID/HIGH never makes a discontinuous jump.
                        val t = smoothedAmount.coerceIn(0.0, 1.0) * 2.0
                        val removed = if (t < 1.0) low * (1.0 - t) + mid * t
                                      else mid * (2.0 - t) + high * (t - 1.0)
                        effect = d - removed
                    }
                    DELAY -> if (delaySamples > 0) {
                        val read = (delayCursor - delaySamples + delaySize) % delaySize
                        val delayed = delay[read * channels + ch].toDouble()
                        record = d + delayed * .28
                        effect = d + delayed * (.65 * smoothedAmount)
                    }
                    FLANGER -> if (tempo > 0) {
                        val readAt = delayCursor - flangerReadDelay
                        val base = kotlin.math.floor(readAt).toInt()
                        val fraction = readAt - kotlin.math.floor(readAt)
                        val i0 = ((base % delaySize) + delaySize) % delaySize
                        val i1 = (i0 + 1) % delaySize
                        val delayed = delay[i0 * channels + ch] * (1.0 - fraction) + delay[i1 * channels + ch] * fraction
                        record = d + delayed * .12
                        effect = d + delayed * (.65 * smoothedAmount)
                    }
                    AUTO_PAN -> if (tempo > 0) {
                        // If a decoder reports mono PCM, use tremolo rather than silently losing pan.
                        val pan = sweep * smoothedAmount
                        val gain = if (channels == 1) (1.0 + .3 * pan) else if (ch % 2 == 0)
                            sqrt((1.0 - pan) / (1.0 + kotlin.math.abs(pan)))
                        else sqrt((1.0 + pan) / (1.0 + kotlin.math.abs(pan)))
                        effect = d * gain
                    }
                }
                // Delay/flanger contain the dry signal; filters replace it. Type changes
                // fade through dry without seeking or disrupting decoded PCM consumption.
                val mixed = (d + (effect - d) * wet).coerceIn(-1.0, 1.0)
                if (floatPcm) dest.putFloat(mixed.toFloat())
                else dest.putShort((mixed * 32768.0).roundToInt().coerceIn(-32768, 32767).toShort())
                // Fill delay history continuously, even when a filter is OFF.
                // Starting Delay or Flanger then acts on the song already playing.
                delay[delayCursor * channels + ch] = record.coerceIn(-1.0, 1.0).toFloat()
            }
            delayCursor++
            if (delayCursor >= delaySize) delayCursor = 0
            if (currentType == FLANGER || currentType == AUTO_PAN) {
                phase += 1.0 / (sampleRate * periodSeconds)
                if (phase >= 1.0) phase -= 1.0
            }
        }
        dest.flip()
        output = dest
        processedFrames += frames.toLong()
        inputBuffer.position(inputBuffer.limit())
    }

    private fun updateBiquad(type: Int, knob: Double) {
        val maxFreq = min(16000.0, sampleRate * .45)
        val minFreq = if (type == LPF || type == HPF) 60.0 else 120.0
        val f = minFreq * (maxFreq / minFreq).pow(knob.coerceIn(0.0, 1.0))
        val omega = 2.0 * PI * f / sampleRate
        val c = cos(omega)
        val alpha = sin(omega) / (2.0 * if (type == BAND_PASS) 1.0 else .70710678118)
        val a0 = 1.0 + alpha
        when (type) {
            LPF -> { b0 = (1-c)/2/a0; b1 = (1-c)/a0; b2 = b0 }
            HPF -> { b0 = (1+c)/2/a0; b1 = -(1+c)/a0; b2 = b0 }
            BAND_PASS -> { b0 = alpha/a0; b1 = 0.0; b2 = -alpha/a0 }
            NOTCH -> { b0 = 1/a0; b1 = -2*c/a0; b2 = 1/a0 }
        }
        a1 = -2*c/a0
        a2 = (1-alpha)/a0
    }

    override fun getOutput(): ByteBuffer {
        val result = output
        output = AudioProcessor.EMPTY_BUFFER
        if (result !== AudioProcessor.EMPTY_BUFFER) spare = result
        return result
    }
    override fun queueEndOfStream() { endOfStream = true }
    override fun isEnded(): Boolean = endOfStream && output === AudioProcessor.EMPTY_BUFFER
    override fun flush() {
        output = AudioProcessor.EMPTY_BUFFER
        spare = AudioProcessor.EMPTY_BUFFER
        endOfStream = false
        clearAudioState()
    }
    override fun reset() {
        flush()
        format = AudioProcessor.AudioFormat.NOT_SET
        channels = 0; sampleRate = 0
        delay = FloatArray(0); delaySize = 0
        z1 = DoubleArray(0); z2 = DoubleArray(0)
        bass = DoubleArray(0); trebleLowpass = DoubleArray(0)
    }
    private fun clearAudioState() {
        currentType = OFF; wet = 0.0; phase = 0.0
        smoothedAmount = .5; coefficientCounter = 0
        z1.fill(0.0); z2.fill(0.0)
        bass.fill(0.0); trebleLowpass.fill(0.0)
        delay.fill(0f); delayCursor = 0
    }
}
