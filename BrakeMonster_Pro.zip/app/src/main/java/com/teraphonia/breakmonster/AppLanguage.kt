package com.teraphonia.breakmonster

import android.app.AlertDialog
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject

/** Presentation only. Never changes the Android installation identity or player. */
internal object AppLanguage {
    var current by mutableStateOf("en")
        private set
    private var tables = mapOf<String, Map<String, String>>()
    private var choice = "auto"
    fun initialize(context: Context) {
        tables = listOf("cnr", "de", "es", "it").associateWith { lang ->
            val json = JSONObject(context.assets.open("ui-$lang.json").bufferedReader().use { it.readText() })
            json.keys().asSequence().associateWith { json.getString(it) }
        }
        choice = context.getSharedPreferences("bm_language", Context.MODE_PRIVATE).getString("language", "auto") ?: "auto"
        current = resolve(context, choice)
    }
    private fun resolve(context: Context, value: String): String {
        if (value != "auto") return value.takeIf { it in setOf("en", "cnr", "de", "es", "it") } ?: "en"
        return when (context.resources.configuration.locales[0].language) {
            "cnr", "sr", "hr", "bs", "sh", "me" -> "cnr"
            "de" -> "de"
            "es" -> "es"
            "it" -> "it"
            else -> "en"
        }
    }
    fun text(source: String): String {
        val lang = current // Compose tracks this read, including calls from child labels.
        if (lang == "en") return source
        val values = tables[lang] ?: return source
        values[source]?.let { return it }
        val http = source.indexOf(" (HTTP ")
        if (http > 0) return text(source.substring(0, http)) + source.substring(http)

        for ((key, target) in values) {
            if (!key.contains("%s")) continue
            val regex = Regex("^" + key.split("%s").joinToString("(.+?)") { Regex.escape(it) } + "$")
            val match = regex.matchEntire(source) ?: continue
            var index = 0
            return target.split("%s").mapIndexed { i, part ->
                if (i == 0) part else match.groupValues[++index] + part
            }.joinToString("")
        }
        // Multi-line commercial status is translated line by line, preserving values.
        if (source.contains('\n')) return source.split('\n').joinToString("\n") { text(it) }
        for (prefix in listOf("Installed:", "Access:", "Updates:", "CURRENT VERSION:", "NEW VERSION:", "WHAT'S NEW:")) {
            if (source.startsWith(prefix)) return (values[prefix] ?: prefix) + source.removePrefix(prefix)
        }
        return source
    }
    fun choose(activity: MainActivity, onChanged: () -> Unit) {
        val codes = listOf("auto", "cnr", "en", "de", "it", "es")
        val names = arrayOf(text("AUTOMATIC"), "Crnogorski", "English", "Deutsch", "Italiano", "Español")
        val dialog = AlertDialog.Builder(activity).setCustomTitle(android.widget.TextView(activity).apply {
            this.text = AppLanguage.text("LANGUAGE")
            textSize = 24f
            setTextColor(android.graphics.Color.WHITE)
            setPadding(24, 24, 24, 16)
        })
            .setSingleChoiceItems(names, codes.indexOf(choice).coerceAtLeast(0)) { d, which ->
                choice = codes[which]
                activity.getSharedPreferences("bm_language", Context.MODE_PRIVATE).edit().putString("language", choice).apply()
                current = resolve(activity, choice)
                d.dismiss()
                onChanged()
            }.setNegativeButton(text("CANCEL"), null).create()
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.black)
        dialog.listView.setBackgroundColor(android.graphics.Color.rgb(6,38,25))
        for (i in 0 until dialog.listView.childCount) {
            (dialog.listView.getChildAt(i) as? android.widget.TextView)?.apply {
                setTextColor(android.graphics.Color.WHITE)
                textSize = 22f
                minHeight = (64 * resources.displayMetrics.density).toInt()
            }
        }
        dialog.listView.setOnHierarchyChangeListener(object : android.view.ViewGroup.OnHierarchyChangeListener {
            override fun onChildViewAdded(parent: android.view.View?, child: android.view.View?) {
                (child as? android.widget.TextView)?.apply { setTextColor(android.graphics.Color.WHITE); textSize = 22f; minHeight = (64 * resources.displayMetrics.density).toInt() }
            }
            override fun onChildViewRemoved(parent: android.view.View?, child: android.view.View?) {}
        })
    }
}
