plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.teraphonia.breakmonster"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.teraphonia.breakmonster.pro"
        minSdk = 26
        targetSdk = 35
        versionCode = 233
        versionName = if (System.getenv("BM_LICENSE_TEST_MODE") == "true") "1.0.187-pro.116-TEST" else "1.0.187-pro.116"
        // Explicit QA build option; defaults to real production API with checkout disabled server-side.
        buildConfigField("boolean", "BM_LICENSE_TEST_MODE", if (System.getenv("BM_LICENSE_TEST_MODE") == "true") "true" else "false")
    }

    buildFeatures { compose = true; buildConfig = true }
    signingConfigs {
        create("commercial") {
            val signingPath = System.getenv("BM_KEYSTORE_PATH")
            if (!signingPath.isNullOrBlank()) {
                storeFile = file(signingPath)
                storePassword = System.getenv("BM_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("BM_KEY_ALIAS")
                keyPassword = System.getenv("BM_KEY_PASSWORD")
            }
        }
    }
    buildTypes { getByName("release") {
        if (!System.getenv("BM_KEYSTORE_PATH").isNullOrBlank()) signingConfig = signingConfigs.getByName("commercial")
    } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin { jvmToolchain(17) }

dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.01.00"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.7")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("com.github.TeamNewPipe:NewPipeExtractor:v0.26.5")
    implementation("androidx.media3:media3-exoplayer:1.6.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.6.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.6.1")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
