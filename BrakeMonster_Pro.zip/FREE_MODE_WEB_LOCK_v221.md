# BRAKEMONSTER PRO - v221 TEST candidate: FREE mode online entry locks

Source: v220 TEST trial/grace candidate (initial v219 source SHA-256 ea5da96bd7e378be7e1f7a0d45eeca4fd1aca9458574c071a4312745a5271ca9).
Android versionCode=221; versionName=1.0.184-pro.105-TEST when BM_LICENSE_TEST_MODE=true.

- WEB SEARCH and FIND YOUR PLAYLISTS remain accessible in TRIAL (7 days), PAID, GRACE (3 days) and LIFETIME, based on existing server-confirmed CommercialRelease.active.
- After PRO access expires both stones remain visible; taps open the BUY PRO/CONTINUE FREE dialog, rather than online search.
- Online WebView and search modal close on entitlement loss. Browser rendering is also guarded synchronously.
- WEB SEARCH voice recognition results and search confirm/result selections are rechecked to prevent stale background callbacks from bypassing a FREE lock.
- FIND YOUR PLAYLISTS Cloud browser is locked and direct ACTION_VIEW cloud-import links cannot bypass the lock; recheck before executing a queued import.
- Previously downloaded playlists, QUEUE, LOCAL FILES and basic playback are preserved. No SQL/Worker change from v220 required.
- PRODUCTION unmodified; TEST v220 migration and Worker deployment still required before TEST trial/grace end-to-end validation.

Validation: exact callback guards checked in Kotlin source; Gradle Android build/device test NOT completed in this environment.
