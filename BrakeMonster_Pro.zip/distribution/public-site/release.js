"use strict";
(async () => {
 const status = document.getElementById("release-status");
 const details = document.getElementById("release-details");
 const button = document.getElementById("download");
 // Static hosting cannot enforce a license. Never expose an APK URL here.
 button.disabled = true;
 button.removeAttribute("href");
 status.textContent = "Protected download is not enabled yet. Payment and license integration is pending.";
 try {
  const response = await fetch("releases/latest.json", {cache:"no-store", signal:AbortSignal.timeout(10000)});
  if (!response.ok) throw Error("Release metadata unavailable");
  const release = await response.json();
  if (release.applicationId !== "com.teraphonia.breakmonster.pro" ||
      !Number.isSafeInteger(release.candidateVersionCode) || release.candidateVersionCode < 1 ||
      typeof release.candidateVersionName !== "string" ||
      !/^\d+\.\d+\.\d+-pro\.\d+$/.test(release.candidateVersionName)) throw Error("Invalid release metadata");
  details.textContent = "Prepared version: " + release.candidateVersionName + " (" + release.candidateVersionCode + "). " +
   (release.buildVerified === true ? "Signed release build verified; device testing and protected delivery are still required." : "Android build, signing and device verification pending.");
 } catch (_) {
  status.textContent = "Protected download is not enabled. Release information is currently unavailable.";
 }
})();
