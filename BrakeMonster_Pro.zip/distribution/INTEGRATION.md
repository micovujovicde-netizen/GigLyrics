# BrakeMonster PRO — priprema za teraphonia.com

STATUS: izvorni kandidat 211 / 1.0.176-pro.95. Lokalni Android build je
blokiran mrezom; SDK, originalni signing key i Android uredjaj nijesu dostupni.
Ovaj paket pripreme sam po sebi NE SADRZI provjeren APK.

## Bez objavljivanja placenog APK-a

Ne uploadovati cijeli BrakeMonster-PRO-WEBSITE.zip u postojeci workflow sajta:
workflow automatski raspakuje ZIP i mogao bi objaviti privatni APK.
Za javni sajt koristiti ISKLJUCIVO sadrzaj public-site/.
private/ mora ostati van GitHub Pages, javnih repozitorijuma i javnih Releases.
Ni skriven URL ni onemoguceno dugme nijesu zastita javno hostovanog APK-a.
DOWNLOAD je namjerno disabled u HTML-u i nikada se ne aktivira u release.js.
releases/latest.json nema URL APK-a. Naplata ostaje iskljucena.
Ne postavljati available=true niti omogucavati checkout bez povezanog,
provjerenog sistema naplate i server-side provjere prava pristupa.

public-site/ je pripremljen iz postojeceg TERAPHONIA_Website.zip u repozitorijumu
micovujovicde-netizen/teraphonia-site (Git blob 297c0dfc13d7eb523a351f9222d2d85d31d8751c).
Izmijenjen je samo dio za BrakeMonster, status download-a i stari tekst o
cijeni/trial-u. Ostali projekti, dizajn i linkovi ostaju sacuvani.
Nista nije pushovano ni objavljeno. Cloudflare Worker nije mijenjan.

## Izrada stvarnog distributivnog paketa

Na masina sa JDK 17, Android SDK 35 i mreznim pristupom Gradle/Maven/JitPack:

    ./gradlew --no-daemon :app:assembleRelease :app:lintRelease
    python3 tools/package_website_release.py app/build/outputs/apk/release/app-release.apk out

Koristiti POSTOJECI kljuc i BM_KEYSTORE_PATH, BM_KEYSTORE_PASSWORD,
BM_KEY_ALIAS, BM_KEY_PASSWORD. BM_EXPECTED_CERT_SHA256 mora biti fingerprint
originalnog instaliranog APK-a. Ne generisati novi ili debug kljuc.
Prilozeni GitHub workflow radi isti postupak ako su originalni secrets dostupni.
Nedostajuci kljuc daje samo unsigned build; takav APK se ne pakuje niti objavljuje.
Ne stavljati secrets u izvorni ZIP ili javni repozitorijum.

Skripta prije pakovanja provjerava APK strukturu, apksigner, fingerprint,
package, verziju, minSdk i debuggable flag. Zatim stvara:

- out/BrakeMonster-PRO.apk
- out/BrakeMonster-PRO-WEBSITE.zip (private APK + public-site + verzija i SHA-256)
- out/APK-VERIFICATION.json

Ovi izlazi su za privatni artefakt, bez publikacije. Workflow ne uploaduje placene APK/website artefakte iz javnog repozitorijuma.
Za njih koristiti privatni repozitorijum ili zasticen servis isporuke.
SHA-256 i potpis u tom paketu generisu se iz stvarnog APK-a, nikad iz izvornog ZIP-a.

## Obavezna Android provjera nakon builda

1. Instalacija preko postojece verzije bez deinstalacije, ocuvani podaci.
2. Pokretanje i XL prvo na A9+, zatim A7, pa telefon; portrait/landscape,
   statusna i navigaciona traka, uvecani sistemski fontovi.
3. XL ne animira; dimenzije standardnog reda i susjedi ne mijenjaju poziciju.
4. EXIT je fiksan; kratki nazivi centrirani; dugi nazivi marquee do posljednjeg
   slova, bez elipse i bez crtanja preko okvira.
5. Long-press, Rename, Move (drag i tap), Delete, skrol uz ivice,
   povratak iz pjesama Back dugmetom i cuvanje XL skrol pozicije.
6. A/B, AUTO MIX, NEXT, crossfader, RollMonster, QUEUE, LOCAL FILES,
   WEB SEARCH, CF i backup/import regresioni test na uredjaju.

Source-code diff nije dokaz prolaska runtime testova.
