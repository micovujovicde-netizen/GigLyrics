-- Execute ONLY against the correct D1 database (test or production).
CREATE TABLE IF NOT EXISTS license_devices (
  license_id TEXT NOT NULL,
  token_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (license_id,token_hash)
);
CREATE INDEX IF NOT EXISTS idx_bm_license_devices_token
  ON license_devices(token_hash);
