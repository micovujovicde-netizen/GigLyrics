-- TEST DATABASE ONLY: brakemonster-licenses-test
-- Execute BEFORE deploying worker-test-v220.js. No existing data is modified.
CREATE TABLE IF NOT EXISTS bm_trial_devices (
  device_fingerprint TEXT PRIMARY KEY NOT NULL,
  first_seen_ms INTEGER NOT NULL CHECK(first_seen_ms > 0)
);
