// V4.1 TEST ONLY - BrakeMonster TEST Worker; not for PRODUCTION.
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// ../brakemonster-license/brakemonster-license/workers/test/worker.js
var __defProp2 = Object.defineProperty;
var __name2 = /* @__PURE__ */ __name((target, value) => __defProp2(target, "name", { value, configurable: true }), "__name");
var PRODUCTS = Object.freeze({
  monthly: "prod_38aihCnx3ramvwkUxxJC5v",
  yearly: "prod_4obIqGpmmfW6S7Hfm0p9Gn",
  lifetime: "prod_1RKZxe64ISMSTIEJ5umurL"
});
var PRODUCT_PLAN = new Map(Object.entries(PRODUCTS).map(([plan, id2]) => [id2, plan]));
var KNOWN_EVENTS = /* @__PURE__ */ new Set([
  "subscription.paid",
  "subscription.canceled",
  "subscription.expired",
  "subscription.active",
  "subscription.update",
  "subscription.paused",
  "subscription.trialing",
  "checkout.completed",
  "refund.created",
  "dispute.created"
]);
var WRITE_EVENTS = /* @__PURE__ */ new Set([
  "subscription.paid",
  "subscription.canceled",
  "subscription.active",
  "subscription.update",
  "checkout.completed",
  "refund.created",
  "dispute.created"
]);
function json(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    "x-content-type-options": "nosniff"
  } });
}
__name(json, "json");
__name2(json, "json");
function str(v, max = 1e3) {
  return typeof v === "string" && v.length > 0 && v.length <= max ? v : null;
}
__name(str, "str");
__name2(str, "str");
function id(v) {
  return str(typeof v === "string" ? v : v?.id);
}
__name(id, "id");
__name2(id, "id");
function dateISO(v) {
  if (typeof v !== "string")
    return null;
  const millis = Date.parse(v);
  return Number.isFinite(millis) ? new Date(millis).toISOString() : null;
}
__name(dateISO, "dateISO");
__name2(dateISO, "dateISO");
function customer(obj) {
  return id(obj?.customer) || id(obj?.order?.customer);
}
__name(customer, "customer");
__name2(customer, "customer");
function email(obj) {
  return str(obj?.customer?.email, 320);
}
__name(email, "email");
__name2(email, "email");
function product(obj) {
  return id(obj?.product) || id(obj?.order?.product) || id(obj?.subscription?.product);
}
__name(product, "product");
__name2(product, "product");
function testPayload(ev, obj) {
  const items = [
    ev,
    obj,
    obj?.order,
    obj?.subscription,
    obj?.customer,
    obj?.transaction,
    obj?.product
  ];
  for (const v of items) {
    if (!v || typeof v !== "object")
      continue;
    if (v.test === true || v.test_mode === true || v.is_test === true)
      return true;
    if (typeof v.mode === "string" && ["test", "sandbox"].includes(v.mode.toLowerCase()))
      return true;
    if (typeof v.environment === "string" && ["test", "sandbox"].includes(v.environment.toLowerCase()))
      return true;
    if (typeof v.id === "string" && /^(?:evt|ch|ord|sub|tran|txn|cust|ref|disp)_test(?:_|$)/i.test(v.id))
      return true;
  }
  return false;
}
__name(testPayload, "testPayload");
__name2(testPayload, "testPayload");
async function signatureValid(raw, supplied, secret) {
  if (!secret || typeof secret !== "string" || typeof supplied !== "string" || !/^[0-9a-fA-F]{64}$/.test(supplied.trim()))
    return false;
  const bytes = new TextEncoder();
  const key = await crypto.subtle.importKey("raw", bytes.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const calc = new Uint8Array(await crypto.subtle.sign("HMAC", key, bytes.encode(raw)));
  const theirs = supplied.trim().match(/../g).map((hex) => parseInt(hex, 16));
  let delta = 0;
  for (let i = 0; i < 32; i++)
    delta |= calc[i] ^ theirs[i];
  return delta === 0;
}
__name(signatureValid, "signatureValid");
__name2(signatureValid, "signatureValid");
function bearer(request) {
  const auth = request.headers.get("Authorization") || "";
  const match = /^Bearer ([0-9a-f]{64})$/.exec(auth);
  return match ? match[1] : null;
}
__name(bearer, "bearer");
__name2(bearer, "bearer");
async function deviceHash(token) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(token));
  return Array.from(new Uint8Array(digest), (v) => v.toString(16).padStart(2, "0")).join("");
}
__name(deviceHash, "deviceHash");
__name2(deviceHash, "deviceHash");
var SITE_ORIGINS = /* @__PURE__ */ new Set(["https://teraphonia.com", "https://www.teraphonia.com"]);
function withCors(response, request) {
  const origin = request.headers.get("Origin");
  if (!origin || !SITE_ORIGINS.has(origin))
    return response;
  const headers = new Headers(response.headers);
  headers.set("access-control-allow-origin", origin);
  headers.set("access-control-allow-methods", "GET, POST, OPTIONS");
  headers.set("access-control-allow-headers", "Authorization, Content-Type");
  headers.set("vary", "Origin");
  return new Response(response.body, { status: response.status, headers });
}
__name(withCors, "withCors");
__name2(withCors, "withCors");
function billingOn(env) {
  return env.BILLING_ENABLED === "true" && Boolean(env.CREEM_API_KEY);
}
__name(billingOn, "billingOn");
__name2(billingOn, "billingOn");
// V220 TEST ONLY: first server-confirmed activation gets seven days.
// Uses an app-signature-scoped Android fingerprint rather than the install token,
 // so a normal uninstall/reinstall does not reset the trial on the same device.
const TRIAL_DAYS = 7;
const GRACE_DAYS = 3;
const ONE_DAY_MS = 86400000;
async function entitlement(db, hash, trialDevice) {
  const rows = await db.prepare(`SELECT l.status,l.expires_at,l.product_id FROM licenses l
    INNER JOIN license_devices d ON d.license_id=l.id WHERE d.token_hash=?1`).bind(hash).all();
  const now = Date.now();
  // Register first use even when the account already has paid access.
  // Otherwise a subscriber could receive a fresh trial months later.
  let trialStart = 0;
  if (trialDevice) {
    await db.prepare(`INSERT OR IGNORE INTO bm_trial_devices(device_fingerprint,first_seen_ms)
       VALUES(?1,?2)`).bind(trialDevice,now).run();
    const record = await db.prepare(`SELECT first_seen_ms FROM bm_trial_devices
       WHERE device_fingerprint=?1`).bind(trialDevice).first();
    trialStart = Number(record?.first_seen_ms) || 0;
  }
  let paidUntil = 0;
  let paidPlan = "free";
  let graceUntil = 0;
  for (const r of rows.results || []) {
    if (r.status === "lifetime" && r.product_id === PRODUCTS.lifetime) {
      return {active:true,validUntil:253402300799000,status:"Lifetime",plan:"lifetime",entitlementType:"lifetime"};
    }
    if (!["active","canceled"].includes(r.status)) continue;
    const plan = PRODUCT_PLAN.get(r.product_id);
    if (plan !== "monthly" && plan !== "yearly") continue;
    const until = Date.parse(r.expires_at || "");
    if (!Number.isFinite(until)) continue;
    if (until > now && until > paidUntil) {
      paidUntil = until;
      paidPlan = plan;
    }
    // Grace is only for a previously paid subscription still awaiting renewal,
    // not a canceled, refunded, revoked or disputed subscription.
    if (r.status === "active" && until <= now && until + GRACE_DAYS * ONE_DAY_MS > now && until + GRACE_DAYS * ONE_DAY_MS > graceUntil) {
      graceUntil = until + GRACE_DAYS * ONE_DAY_MS;
    }
  }
  if (paidUntil > now) return {active:true,validUntil:paidUntil,status:"Paid PRO",plan:paidPlan,entitlementType:"paid"};
  if (graceUntil > now) return {active:true,validUntil:graceUntil,status:"3-day renewal grace",plan:"grace",entitlementType:"grace"};
  if (Number.isSafeInteger(trialStart) && trialStart > 0 && trialStart <= now) {
    const trialUntil = trialStart + TRIAL_DAYS * ONE_DAY_MS;
    if (now < trialUntil) return {active:true,validUntil:trialUntil,status:"7-day PRO trial",plan:"trial",entitlementType:"trial"};
  }
  return {active:false,validUntil:0,status:"FREE — trial/subscription ended",plan:"free",entitlementType:"free"};
}
__name(entitlement, "entitlement");
__name2(entitlement, "entitlement");
function hashFromMetadata(obj) {
  const values = [obj?.metadata?.bm_device_hash, obj?.subscription?.metadata?.bm_device_hash];
  const val = values.find((v) => typeof v === "string" && /^[a-f0-9]{64}$/.test(v));
  return val || null;
}
__name(hashFromMetadata, "hashFromMetadata");
__name2(hashFromMetadata, "hashFromMetadata");
function bindingStatements(db, obj, eventType) {
  const hash = hashFromMetadata(obj);
  if (!hash)
    return [];
  if (!PRODUCT_PLAN.has(product(obj)))
    return [];
  let key = null;
  if (eventType === "subscription.paid")
    key = id(obj);
  if (eventType === "checkout.completed") {
    if (obj.status !== "completed" || obj?.order?.status !== "paid")
      return [];
    key = id(obj.subscription) || id(obj.order);
  }
  if (!key)
    return [];
  if (eventType === "checkout.completed" && PRODUCT_PLAN.get(product(obj)) !== "lifetime")
    return [db.prepare(`INSERT OR IGNORE INTO license_devices (license_id,token_hash)
            SELECT id,?2 FROM licenses WHERE id=?1 AND last_paid_transaction_id IS NOT NULL`).bind(key, hash)];
  return [db.prepare(`INSERT OR IGNORE INTO license_devices (license_id,token_hash) VALUES(?1,?2)`).bind(key, hash)];
}
__name(bindingStatements, "bindingStatements");
__name2(bindingStatements, "bindingStatements");
async function checkout(request, env) {
  if (!billingOn(env))
    return json({ error: "Checkout not enabled" }, 503);
  const rawToken = bearer(request);
  if (!rawToken)
    return json({ error: "Invalid installation credential" }, 401);
  const raw = await request.text();
  if (raw.length > 2048)
    return json({ error: "Invalid request" }, 400);
  let input;
  try {
    input = JSON.parse(raw);
  } catch {
    return json({ error: "Invalid JSON" }, 400);
  }
  const plan = input?.plan;
  if (!Object.hasOwn(PRODUCTS, plan))
    return json({ error: "Invalid TEST plan" }, 400);
  const hash = await deviceHash(rawToken);
  const creem = await fetch("https://test-api.creem.io/v1/checkouts", {
    method: "POST",
    headers: { "x-api-key": env.CREEM_API_KEY, "content-type": "application/json" },
    body: JSON.stringify({
      product_id: PRODUCTS[plan],
      units: 1,
      request_id: crypto.randomUUID(),
      success_url: "https://teraphonia.com/purchase-complete.html",
      metadata: { bm_device_hash: hash, bm_origin: "brakemonster_android" }
    }),
    redirect: "manual"
  });
  if (!creem.ok) {
    let providerTrace = null, providerCode = null, providerMessage = null;
    try {
      const failure = await creem.json();
      providerTrace = typeof failure?.trace_id === "string" ? failure.trace_id.slice(0, 128) : null;
      providerCode = typeof failure?.code === "string" ? failure.code.slice(0, 80) : null;
      const rawMessage = [
        failure?.message,
        failure?.error?.message,
        typeof failure?.error === "string" ? failure.error : null
      ].find((v) => typeof v === "string" && v.length);
      providerMessage = typeof rawMessage === "string" ? rawMessage.replace(/[^A-Za-z0-9 .,:;!?()_-]/g, " ").slice(0, 160) : null;
    } catch (_) {
    }
    // TEST-only diagnostics: compare the YEARLY product against the known-working MONTHLY product.
    // Creem's documented product lookup uses GET /v1/products/{id} (not ?product_id=).
    let productLookupStatus = null, productLookupMatches = null;
    let monthlyLookupStatus = null, monthlyLookupMatches = null;
    let yearlyProductStatus = null, yearlyBillingPeriod = null, yearlyProductMode = null;
    if (plan === "yearly" && creem.status === 404) {
      for (const [checkPlan, checkId] of [["yearly", PRODUCTS.yearly], ["monthly", PRODUCTS.monthly]]) {
        try {
          const lookup = await fetch("https://test-api.creem.io/v1/products/" + encodeURIComponent(checkId), {
            method: "GET",
            headers: { "x-api-key": env.CREEM_API_KEY },
            redirect: "manual"
          });
          let matches = null;
          if (lookup.ok) {
            const productData = await lookup.json();
            matches = productData?.id === checkId;
            if (checkPlan === "yearly") {
              yearlyProductStatus = typeof productData?.status === "string" ? productData.status.slice(0, 40) : null;
              yearlyBillingPeriod = typeof productData?.billing_period === "string" ? productData.billing_period.slice(0, 40) : null;
              yearlyProductMode = typeof productData?.mode === "string" ? productData.mode.slice(0, 40) : null;
            }
          }
          if (checkPlan === "yearly") {
            productLookupStatus = lookup.status;
            productLookupMatches = matches;
          } else {
            monthlyLookupStatus = lookup.status;
            monthlyLookupMatches = matches;
          }
        } catch (e) {
          console.error("CREEM_TEST_PRODUCT_LOOKUP_EXCEPTION", checkPlan, String(e?.name || "unknown").slice(0, 80));
        }
      }
    }
    console.error("CREEM_TEST_CHECKOUT_REJECTED", JSON.stringify({
      plan,
      httpStatus: creem.status,
      trace_id: providerTrace,
      code: providerCode,
      message: providerMessage,
      productLookupStatus,
      productLookupMatches,
      monthlyLookupStatus,
      monthlyLookupMatches,
      yearlyProductStatus,
      yearlyBillingPeriod,
      yearlyProductMode
    }));
    return json({
      error: "Creem TEST checkout rejected",
      providerStatus: creem.status,
      traceId: providerTrace,
      code: providerCode,
      providerMessage
    }, 502);
  }
  const payload = await creem.json();
  let u;
  try {
    u = new URL(payload.checkout_url);
  } catch {
    console.error("CREEM_TEST_CHECKOUT_INVALID_RESPONSE");
    return json({ error: "Invalid checkout response" }, 502);
  }
  if (u.protocol !== "https:" || u.username || u.password || u.port || !(u.hostname === "creem.io" || u.hostname.endsWith(".creem.io")))
    return json({ error: "Invalid checkout destination" }, 502);
  return json({ url: u.toString() });
}
__name(checkout, "checkout");
__name2(checkout, "checkout");
function eventStatement(db, event, action) {
  return db.prepare(`INSERT INTO webhook_events (event_id,event_type,status,processed_at) VALUES (?1,?2,?3,CURRENT_TIMESTAMP)`).bind(event.id, event.eventType, action);
}
__name(eventStatement, "eventStatement");
__name2(eventStatement, "eventStatement");
async function isAlreadyHandled(db, eventID) {
  return Boolean(await db.prepare("SELECT event_id FROM webhook_events WHERE event_id=?1").bind(eventID).first());
}
__name(isAlreadyHandled, "isAlreadyHandled");
__name2(isAlreadyHandled, "isAlreadyHandled");
async function saveEvent(db, event, action, changes = []) {
  await db.batch([...changes, eventStatement(db, event, action)]);
  return json({ received: true, action });
}
__name(saveEvent, "saveEvent");
__name2(saveEvent, "saveEvent");
function stmtPaid(db, obj, ms) {
  const plan = PRODUCT_PLAN.get(product(obj));
  if (plan !== "monthly" && plan !== "yearly")
    return { action: "unmatched_product", sql: [] };
  const subId = id(obj), custId = customer(obj), expires = dateISO(obj.current_period_end_date), txn = id(obj.last_transaction_id);
  if (!subId || !custId || !expires || !txn || !["active", "scheduled_cancel", "canceled"].includes(obj.status))
    return { error: "Incomplete subscription.paid \u2014 requires verified transaction and period" };
  const s = db.prepare(`INSERT INTO licenses (id,creem_customer_id,creem_subscription_id,product_id,customer_email, status,expires_at,last_event_ms,last_paid_transaction_id,updated_at) VALUES (?1,?2,?3,?4,?5,'active',?6,?7,?8,CURRENT_TIMESTAMP) ON CONFLICT(id) DO UPDATE SET creem_customer_id=excluded.creem_customer_id, product_id=excluded.product_id, customer_email=COALESCE(excluded.customer_email, licenses.customer_email), status='active',expires_at=excluded.expires_at, last_event_ms=excluded.last_event_ms, last_paid_transaction_id=excluded.last_paid_transaction_id, updated_at=CURRENT_TIMESTAMP WHERE excluded.last_event_ms > licenses.last_event_ms AND (licenses.status != 'revoked' OR excluded.last_paid_transaction_id IS NOT licenses.last_paid_transaction_id)`).bind(subId, custId, subId, product(obj), email(obj), expires, ms, txn);
  const transaction = db.prepare(`INSERT OR IGNORE INTO license_transactions (transaction_id,license_id) VALUES (?1,?2)`).bind(txn, subId);
  return { action: "paid", sql: [s, transaction] };
}
__name(stmtPaid, "stmtPaid");
__name2(stmtPaid, "stmtPaid");
function stmtRecurringCheckout(obj) {
  if (obj?.status !== "completed" || obj?.order?.status !== "paid" || !id(obj?.subscription))
    return { error: "Incomplete recurring checkout" };
  return { action: "checkout_recorded_wait_for_subscription_paid", sql: [] };
}
__name(stmtRecurringCheckout, "stmtRecurringCheckout");
__name2(stmtRecurringCheckout, "stmtRecurringCheckout");
function stmtLifetime(db, obj, ms) {
  if (product(obj) !== PRODUCTS.lifetime)
    return { action: "unmatched_product", sql: [] };
  const order = obj.order, orderID = id(order), customerID = customer(obj), txn = id(order?.transaction) || id(obj.transaction);
  if (obj.status !== "completed" || order?.status !== "paid" || !orderID || !customerID)
    return { error: "Incomplete paid Lifetime checkout" };
  const upsert = db.prepare(`INSERT INTO licenses (id,creem_customer_id,creem_order_id,product_id,customer_email,status, expires_at,last_event_ms,last_paid_transaction_id,updated_at) VALUES (?1,?2,?3,?4,?5,'lifetime',NULL,?6,?7,CURRENT_TIMESTAMP) ON CONFLICT(id) DO UPDATE SET creem_customer_id=excluded.creem_customer_id, customer_email=COALESCE(excluded.customer_email,licenses.customer_email), product_id=excluded.product_id, status='lifetime', expires_at=NULL, last_event_ms=excluded.last_event_ms, last_paid_transaction_id=COALESCE(excluded.last_paid_transaction_id,licenses.last_paid_transaction_id), updated_at=CURRENT_TIMESTAMP WHERE excluded.last_event_ms>licenses.last_event_ms AND licenses.status!='revoked'`).bind(orderID, customerID, orderID, PRODUCTS.lifetime, email(obj), ms, txn);
  const sql = [upsert];
  if (txn)
    sql.push(db.prepare(`INSERT OR IGNORE INTO license_transactions (transaction_id,license_id) VALUES(?1,?2)`).bind(txn, orderID));
  return { action: txn ? "lifetime_paid" : "lifetime_paid_transaction_link_missing", sql };
}
__name(stmtLifetime, "stmtLifetime");
__name2(stmtLifetime, "stmtLifetime");
function stmtCanceled(db, obj, ms) {
  const subId = id(obj), end = dateISO(obj.current_period_end_date);
  if (!subId || !end)
    return { error: "Incomplete cancellation" };
  const sql = [db.prepare(`UPDATE licenses SET status='canceled', expires_at=CASE WHEN expires_at IS NULL OR expires_at<?1 THEN ?1 ELSE expires_at END, last_event_ms=?2,updated_at=CURRENT_TIMESTAMP WHERE creem_subscription_id=?3 AND last_event_ms<?2 AND status!='revoked'`).bind(end, ms, subId)];
  return { action: "canceled_until_period_end", sql };
}
__name(stmtCanceled, "stmtCanceled");
__name2(stmtCanceled, "stmtCanceled");
function stmtSubscriptionReactivated(db, obj, ms) {
  const subId = id(obj);
  const productId = product(obj);
  const plan = PRODUCT_PLAN.get(productId);
  const providerEnd = dateISO(obj?.current_period_end_date);
  if (!subId || plan !== "monthly" && plan !== "yearly")
    return { action: "reactivation_unmatched_ignored", sql: [] };
  if (obj?.status !== "active" || !providerEnd || Date.parse(providerEnd) <= Date.now())
    return { action: "reactivation_nonactive_or_expired_ignored", sql: [] };
  const sql = [db.prepare(`UPDATE licenses SET status='active', last_event_ms=?1, updated_at=CURRENT_TIMESTAMP
        WHERE creem_subscription_id=?2 AND product_id=?3 AND status='canceled'
          AND last_paid_transaction_id IS NOT NULL
          AND expires_at>?4 AND last_event_ms<?1`).bind(ms, subId, productId, (/* @__PURE__ */ new Date()).toISOString())];
  return { action: "reactivation_sync_existing_paid_only", sql };
}
__name(stmtSubscriptionReactivated, "stmtSubscriptionReactivated");
__name2(stmtSubscriptionReactivated, "stmtSubscriptionReactivated");
async function stmtReversal(db, type, obj, ms) {
  const txn = id(obj?.transaction), sub = id(obj?.subscription);
  if (type === "refund.created" && obj?.transaction?.status !== "refunded")
    return { action: "partial_refund_needs_review", sql: [] };
  if (!txn)
    return { action: "reversal_missing_transaction_needs_review", sql: [] };
  const linked = await db.prepare(`SELECT id,last_paid_transaction_id,creem_subscription_id,product_id FROM licenses WHERE last_paid_transaction_id=?1 LIMIT 1`).bind(txn).first();
  if (!linked || sub && linked.creem_subscription_id && sub !== linked.creem_subscription_id)
    return { action: "unmatched_or_historical_transaction_needs_review", sql: [] };
  const revokedAt = new Date(ms).toISOString();
  return { action: type === "refund.created" ? "refunded_revoke" : "disputed_revoke", sql: [
    db.prepare(`UPDATE licenses SET status='revoked',expires_at=?1, last_event_ms=?2,updated_at=CURRENT_TIMESTAMP WHERE id=?3 AND last_paid_transaction_id=?4 AND last_event_ms<?2`).bind(revokedAt, ms, linked.id, txn)
  ] };
}
__name(stmtReversal, "stmtReversal");
__name2(stmtReversal, "stmtReversal");
var worker_default = {
  async fetch(request, env) {
    const u = new URL(request.url);
    if (u.pathname === "/" && request.method === "GET") {
      return json({
        service: "BrakeMonster PRO Licensing",
        status: "online",
        webhookConfigured: Boolean(env.CREEM_WEBHOOK_SECRET),
        storageConfigured: Boolean(env.DB),
        productConfigured: true,
        liveWritesEnabled: false,
        testMode: true,
        testWritesEnabled: true,
        billingEnabled: billingOn(env),
        version: "commercial-v4.1.6-test-trial-grace"
      });
    }
    const origin = request.headers.get("Origin");
    if (origin && !SITE_ORIGINS.has(origin))
      return json({ error: "Origin forbidden" }, 403);
    if (u.pathname === "/v1/health" && request.method === "GET")
      return withCors(json({ status: "online", billingEnabled: billingOn(env), version: "commercial-v4.1.6-test-trial-grace" }), request);
    if (u.pathname === "/v1/license" && request.method === "GET") {
      if (!env.DB)
        return json({ error: "Database unavailable" }, 503);
      const token = bearer(request);
      if (!token)
        return json({ error: "Unauthorized" }, 401);
      try {
        const trialDevice = request.headers.get("X-BM-Trial-Device");
        if (trialDevice !== null && !/^[0-9a-f]{64}$/.test(trialDevice))
          return json({ error: "Invalid trial device fingerprint" }, 400);
        const result = await entitlement(env.DB, await deviceHash(token), trialDevice);
        return withCors(json(result), request);
      } catch (e) {
        console.error("Entitlement D1 failure");
        return json({ error: "Database unavailable" }, 503);
      }
    }
    if (u.pathname === "/v1/checkout" && request.method === "OPTIONS")
      return withCors(new Response(null, { status: 204, headers: { "cache-control": "no-store" } }), request);
    if (u.pathname === "/v1/checkout" && request.method === "POST")
      try {
        return withCors(await checkout(request, env), request);
      } catch (e) {
        console.error("CREEM_TEST_CHECKOUT_EXCEPTION", String(e?.name || "unknown").slice(0, 80));
        return withCors(json({ error: "Checkout unavailable" }, 503), request);
      }
    if (u.pathname === "/v1/portal" && request.method === "POST") {
      const deviceToken = bearer(request);
      if (!deviceToken) return json({ error: "Unauthorized" }, 401);
      if (!env.DB || !env.CREEM_API_KEY) return json({ error: "TEST portal unavailable" }, 503);
      try {
        const hash = await deviceHash(deviceToken);
        const owner = await env.DB.prepare(`SELECT l.creem_customer_id
                    FROM licenses l JOIN license_devices d ON d.license_id=l.id
                    WHERE d.token_hash=?1 AND l.creem_customer_id IS NOT NULL
                    ORDER BY l.last_event_ms DESC LIMIT 1`).bind(hash).first();
        if (!owner?.creem_customer_id) return json({ error: "No verified TEST purchase for this device" }, 404);
        const creem = await fetch("https://test-api.creem.io/v1/customers/billing", {
          method: "POST",
          redirect: "manual",
          headers: { "x-api-key": env.CREEM_API_KEY, "content-type": "application/json" },
          body: JSON.stringify({ customer_id: owner.creem_customer_id })
        });
        if (!creem.ok) {
          let providerCode = null, traceId = null;
          try {
            const failure = await creem.json();
            const safe = /* @__PURE__ */ __name2((v, limit) => typeof v === "string" && /^[A-Za-z0-9_.-]+$/.test(v) ? v.slice(0, limit) : null, "safe");
            providerCode = safe(failure?.code, 60);
            traceId = safe(failure?.trace_id, 100);
          } catch (_) {
          }
          console.error("CREEM_TEST_PORTAL_REJECTED", JSON.stringify({ httpStatus: creem.status, code: providerCode, trace_id: traceId }));
          const suffix = providerCode ? "; code " + providerCode : "";
          return json({
            error: "Creem TEST rejected request (HTTP " + creem.status + suffix + ")",
            providerStatus: creem.status,
            code: providerCode,
            traceId
          }, 502);
        }
        const payload = await creem.json();
        let link;
        try {
          link = new URL(payload.customer_portal_link);
        } catch (_) {
          return json({ error: "Invalid TEST portal response" }, 502);
        }
        if (link.protocol !== "https:" || link.username || link.password || link.port || !(link.hostname === "creem.io" || link.hostname.endsWith(".creem.io")))
          return json({ error: "Untrusted portal destination" }, 502);
        return withCors(json({ url: link.toString() }), request);
      } catch (error) {
        console.error("CREEM_TEST_PORTAL_ERROR", String(error?.name || "unknown").slice(0, 80));
        return json({ error: "TEST portal unavailable" }, 503);
      }
    }
    if (u.pathname !== "/webhook")
      return json({ error: "Not found" }, 404);
    if (request.method !== "POST")
      return json({ error: "Method not allowed" }, 405);
    if (!env.DB || !env.CREEM_WEBHOOK_SECRET)
      return json({ error: "Backend configuration incomplete" }, 503);
    const length = Number(request.headers.get("content-length") || 0);
    if (length > 25e4)
      return json({ error: "Payload too large" }, 413);
    const raw = await request.text();
    if (raw.length > 25e4)
      return json({ error: "Payload too large" }, 413);
    if (!await signatureValid(raw, request.headers.get("creem-signature"), env.CREEM_WEBHOOK_SECRET))
      return json({ error: "Invalid signature" }, 401);
    let event;
    try {
      event = JSON.parse(raw);
    } catch {
      return json({ error: "Invalid JSON" }, 400);
    }
    if (!str(event?.id) || !str(event?.eventType) || !Number.isSafeInteger(event?.created_at) || event.created_at <= 0 || !event.object || typeof event.object !== "object" || Array.isArray(event.object))
      return json({ error: "Invalid event" }, 400);
    try {
      if (await isAlreadyHandled(env.DB, event.id))
        return json({ received: true, duplicate: true });
      const obj = event.object, ms = event.created_at;
      if (!testPayload(event, obj))
        return await saveEvent(env.DB, event, "non_test_ignored");
      if (!KNOWN_EVENTS.has(event.eventType))
        return await saveEvent(env.DB, event, "unknown_ignored");
      if (!WRITE_EVENTS.has(event.eventType))
        return await saveEvent(env.DB, event, "non_payment_synced_no_access_change");
      let result;
      switch (event.eventType) {
        case "subscription.paid":
          result = stmtPaid(env.DB, obj, ms);
          break;
        case "checkout.completed":
          result = PRODUCT_PLAN.get(product(obj)) === "lifetime" ? stmtLifetime(env.DB, obj, ms) : ["monthly", "yearly"].includes(PRODUCT_PLAN.get(product(obj))) ? stmtRecurringCheckout(obj) : { action: "unmatched_product", sql: [] };
          break;
        case "subscription.canceled":
          result = stmtCanceled(env.DB, obj, ms);
          break;
        case "subscription.active":
        case "subscription.update":
          result = stmtSubscriptionReactivated(env.DB, obj, ms);
          break;
        default:
          result = await stmtReversal(env.DB, event.eventType, obj, ms);
      }
      if (result.error)
        return json({ error: result.error }, 422);
      const bindings = bindingStatements(env.DB, obj, event.eventType);
      return await saveEvent(env.DB, event, result.action, [...result.sql, ...bindings]);
    } catch (err) {
      if (await isAlreadyHandled(env.DB, event.id).catch(() => false))
        return json({ received: true, duplicate: true });
      console.error("License webhook D1 failure", String(err?.message || "unknown").slice(0, 200));
      return json({ error: "Storage unavailable; retry delivery" }, 503);
    }
  }
};
export {
  worker_default as default
};
