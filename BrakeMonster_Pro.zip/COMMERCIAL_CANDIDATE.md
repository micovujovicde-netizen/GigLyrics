# BrakeMonster PRO — source candidate 211 / 1.0.176-pro.95

UNVERIFIED ANDROID RELEASE. See XL_UI_RELEASE_REPORT.md for current evidence.
Source baseline SHA-256: 98e5948c2c671dff7a122afc50164002805f3a4bd5368dbdc81d0f15d102468a

Local build was attempted and failed before Kotlin compilation because the
Gradle distribution could not be downloaded (Network is unreachable).
No Android SDK, original signing key or Android test device is available here.
No APK is supplied or represented as verified. Historical reports apply to older
source candidates and are not test evidence for this version.

Original signing configuration remains unchanged. Use only the existing original
key, BM_KEYSTORE_PATH, BM_KEYSTORE_PASSWORD, BM_KEY_ALIAS, BM_KEY_PASSWORD,
and the original installed APK certificate in BM_EXPECTED_CERT_SHA256.
No debug or replacement signing key is generated.

Build: ./gradlew --no-daemon :app:assembleRelease :app:lintRelease
Package after successful original-key build:
python3 tools/package_website_release.py app/build/outputs/apk/release/app-release.apk out

Website preparation: distribution/public-site/. DOWNLOAD is disabled.
No public APK, billing, license or checkout activation. Protect private APK bytes
server-side before enabling any paid download. No live site or Worker changes.
