# BrakeMonster PRO 1.0.172-pro.91 / 207 — UNVERIFIED CANDIDATE
Based exclusively on the attached stable ZIP, SHA-256:
f9d4559a55a399329e95916db80b2069f89b5a28dd04d40a0de7d6713ccb806d
Baseline version: 206 / 1.0.171-pro.90.

No official APK is supplied. Local compilation cannot download Gradle; Android SDK and original signing key are unavailable.
Source code is not a declaration of working commercial release. All Android runtime checks remain pending.
Existing historical *.txt reports describe older changes, not verification of this candidate.

Build on a machine with JDK 17, Android SDK 35 and access to Gradle/Maven/JitPack:
    ./gradlew :app:assembleRelease :app:lintRelease
Signing environment: BM_KEYSTORE_PATH, BM_KEYSTORE_PASSWORD, BM_KEY_ALIAS, BM_KEY_PASSWORD.
Use ONLY the original installed app's signing key. Do not commit it or use a replacement/debug key.
The workflow uses private GitHub secrets BM_KEYSTORE_B64 and the corresponding credentials,
plus BM_EXPECTED_CERT_SHA256 pinned to the original installed APK. It never publishes a GitHub Release.
Without signing secrets it compiles only and exposes no unsigned APK as an official download.

HELP / ABOUT: tap the label below the PRO button, or long-press that stone.
Native dialogs use real device density so the existing scaled player canvas does not shrink update dialogs.
License and update work uses a separate coroutine scope, never a player-stop action.
All existing playback features remain accessible: commercial feature restrictions have NOT been defined or enforced.
Server is prepared separately; no live billing, device recovery or multi-device activation is enabled.
The automatic scheduler runs while the Activity exists; closed-process scheduled jobs are not implemented.
Automatic checks occur on startup when the 24-hour interval allows and then while the app remains open.
Manual checks bypass the interval on explicit request.

Playlist deletion erases persisted entries/name and keeps a tombstone plus vacant stable address.
That address is never reused or shifted, protecting live playback, QUEUE and source references.
Deleted lists are filtered from tabs, search and destination choices. Seed flags prevent factory resurrection.
Deleting the audible source keeps the current deck, disables upcoming repeat for that deleted source,
and leaves an already audible crossfade target intact until its handover completes.
Physical verification is mandatory for this edge case and offline/update behavior.
