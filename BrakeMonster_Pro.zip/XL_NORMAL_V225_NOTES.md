BrakeMonster PRO v225 — XL/NORMAL controls

Source: user-supplied BrakeMonster_Pro.zip (v224 / 1.0.185-pro.108).
NORMAL: main PLAYLISTS stone becomes XL; compact ADD TO QUEUE / DONE next to it. Only this mode control blinks red when active. Existing small playlist stones remain; QUEUE stone is navigation, not mode toggle.
XL: fixed QUEUE and ADD TO QUEUE / DONE row directly below SEARCH PLAYLISTS / NORMAL; controls do not scroll with playlists. Only mode control blinks red; queue gets distinct charcoal stone tone. XL search and local buttons no longer blink. XL mode and queue mode persist independently.
No changes to Cloudflare, GitHub, playback engine or payment code.
Validation: archive integrity checked; Android compile unavailable because Gradle 8.9 distribution cannot be downloaded in this offline environment. Build and device test required.
