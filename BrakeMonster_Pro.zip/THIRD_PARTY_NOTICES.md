# BrakeMonster PRO third-party notices

- AndroidX and Jetpack Compose — Google / Android Open Source Project.
- NewPipeExtractor v0.26.5 — Team NewPipe, GPL-3.0-or-later.
  https://github.com/TeamNewPipe/NewPipeExtractor
  https://www.gnu.org/licenses/gpl-3.0.html
  Maven coordinate: `com.github.TeamNewPipe:NewPipeExtractor:v0.26.5`

If distributing binaries incorporating NewPipeExtractor, applicable GPLv3
obligations include providing the Corresponding Source for the covered work.
YouTube service terms and playback availability are separate obligations and
restrictions, even when distributing outside Google Play.

BMQ security: saved YouTube track references are encrypted using the Android
Keystore for device-based protection. This does not grant ownership of the
underlying media or guarantee portability across installations.
