# BrakeMonster PRO third-party notices

- AndroidX and Jetpack Compose — Google / Android Open Source Project.
- NewPipeExtractor v0.26.5 — Team NewPipe, GPL-3.0-or-later.
  https://github.com/TeamNewPipe/NewPipeExtractor
  https://www.gnu.org/licenses/gpl-3.0.html
  Maven coordinate: `com.github.TeamNewPipe:NewPipeExtractor:v0.26.5`

If distributing binaries incorporating NewPipeExtractor, applicable GPLv3
obligations include providing the Corresponding Source for the covered work.
YouTube service terms and playback availability are separate obligations and
restrictions, even when distributing outside Google Play.

BMQ security: factory archive references are encrypted with a key embedded in
this app, so determined reverse engineers can recover it. At install, files
are rewrapped using Android Keystore for device-based encryption; this is a
barrier against straightforward copying, not cryptographically enforceable
multi-device licensing or ownership of the underlying media content.
