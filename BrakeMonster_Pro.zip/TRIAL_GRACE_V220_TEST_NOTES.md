# BRAKEMONSTER PRO — v220 TEST trial and grace candidate

## Source and scope
- Input: user-provided BrakeMonster_Pro.zip with versionCode 219.
- Original SHA-256: `ea5da96bd7e378be7e1f7a0d45eeca4fd1aca9458574c071a4312745a5271ca9`.
- New app source: versionCode 220, versionName 1.0.184-pro.104-TEST **only when** `BM_LICENSE_TEST_MODE=true` at build time. The ordinary branch still uses the production license endpoint; DO NOT publish it until production support is separately reviewed.
- PRODUCTION Worker, production D1 database and secrets were not changed.

## Behavior prepared for TEST
1. New device: 7 days PRO trial after its FIRST successful server-side `/v1/license` check. No credit card needed. The trial is not reset by a standard reinstall with the same Android OS user, package ID, app signing certificate and device identifier. Device/factory reset or a different signature can change this identifier; this is **best effort**, not unbreakable fraud protection.
2. Paid monthly/yearly: active until last server-confirmed subscription expiry.
3. Failed recurring renewal: 3 extra days for a previously paid **active** subscription, calculated on the server from its last paid expiry; canceled or revoked subscriptions do not get this grace.
4. Lifetime: permanent, subject to preexisting online/offline license verification rules.
5. After trial/grace expiration: FREE mode. Existing tracks, QUEUE, playlists and settings are never deleted. LOCAL FILES/basic playback remain. MIX/AUTO MIX, FX and online playlist search entrances require PRO.
6. A 72-hour cached offline confirmation limit stays in place; the cache can never extend the end time given by the server. A first install without Internet can play locally, but the 7-day PRO trial starts only after successful online activation.
7. A user with an active trial can still buy PRO during the trial.

## TEST DEPLOY ORDER (mandatory)
1. In Cloudflare TEST D1 **brakemonster-licenses-test ONLY**, run `server/MIGRATION_TEST_V220_TRIAL.sql`. Do not run against production.
2. In the SEPARATE license GitHub repo, import the dedicated `BrakeMonster_TEST_TRIAL_GRACE.zip` into `workers/test/` (contains exactly one root `worker.js`). Wait for Auto-unpack to commit `workers/test/worker.js`; do not put YAML inside that file.
3. Run the existing SAFE release with `TEST / CHECK_ONLY`; after checks pass, run `TEST / DEPLOY / DEPLOY_TEST`. PRODUCTION remains unchanged.
4. Upload **exact** `BrakeMonster_Pro.zip` from the output folder to the Android app GitHub repo root. For the TEST candidate, run the Android build using `license_test_mode=true` in the manually invoked workflow. Verify the APK is signed with the expected certificate.
5. Test using a NEW, never-before-registered TEST trial fingerprint, without resetting/reinstalling the primary stage device. Verify: 7-day trial; after expiry FREE; paid renewal adds three days; lifetime; no deletion; local playback; premium control gates; subscription renewals; existing paid TEST entitlements; and a second install on the same signing identity.

## What was tested here
- `node --check server/worker-test-v220.js`: PASS.
- `node verification/test_trial_grace.mjs`: 10 synthetic TEST Worker scenarios PASS. This tests Worker entitlement logic with a D1-like mock, not live Cloudflare.
- SQLite dry-run: migration is idempotent; first trial timestamp not reset: PASS.
- Kotlin `tools/LicenseValidityTest.kt`: 11 unit checks PASS, unchanged existing routine.
- Android Gradle build: NOT RUN TO COMPLETION. Gradle 8.9 wrapper cannot download here and no Android SDK is present; no APK is supplied or claimed tested.

## Remaining commercial release gates
- New TEST D1 migration and TEST Worker need a real Cloudflare deployment and end-to-end checks.
- Android APK must pass GitHub compilation/lint, installation and stage tests.
- Production Worker must receive a separately audited migration/implementation, not a copy of the TEST Worker.
- Product subscriptions for users who reinstall will need an independent, verified restore mechanism. The trial fingerprint is not a purchased-license restore credential.
