# BrakeMonster PRO — XL UI + website preparation

Datum: 2026-10-29
STATUS: IMPLEMENTIRAN IZVORNI KANDIDAT. NIJE VERIFIKOVAN ANDROID RELEASE.

## Izvor i verzija

Iskljucivo prilozeni BrakeMonster_Pro.zip.
SHA-256: 98e5948c2c671dff7a122afc50164002805f3a4bd5368dbdc81d0f15d102468a
Ulaz: versionCode 210; versionName 1.0.175-pro.94.
Izlazni izvor: versionCode 211; versionName 1.0.176-pro.95.
applicationId: com.teraphonia.breakmonster.pro (nepromijenjen).
Aktivni Compose UI: app/src/main/java/com/teraphonia/breakmonster/MainActivity.kt.

## Stvarno promijenjeno

- XL dugme: staticki kameni izgled, maksimalno popunjena postojeca povrsina
  160x50dp, jaca ivica, reljef i sjenka; visina reda i mjesta susjeda ostaju ista.
  Dostavljeni izvor vec nije imao animirane rotirajuce lampice na XL dugmetu.
  Animacija susjednog indikatora horizontalne liste nije XL animacija i ostaje.
- EXIT je vec postojao u ulaznom ZIP-u. Zadrzan je fiksno iznad skrol liste,
  uz reset MOVE stanja i povratak na standardni PLAYLISTS prikaz.
- XL nazivi vise ne koriste Ellipsis. Centrirani jednolinijski basicMarquee
  u odvojeno ogranicenom viewport-u sa unutrasnjim marginama.
- Native gustina i sistemska velicina fonta u XL modalnom prikazu i menijima,
  nezavisno od postojece virtuelne 800dp telefonske glavne povrsine.
- Visine XL dugmadi prilagodjene font scale-u; safeDrawingPadding i dodatna
  donja margina liste radi statusne/navigacione trake. XL nema horizontalni red.
- MOVE u XL podrzava vertikalni drag i skrol uz ivice, kao i raniji tap na
  odrediste. Koristi postojece saveTabOrder bez promjene identiteta lista.
- Poslije rename/delete/cancel vraca XL izbor. Android Back iz pjesama vraca
  isti izbor i zapamcenu skrol poziciju. EXIT zatvara XL rezim.
- Standardni horizontalni strip i njegov postojeći drag ostaju, radi ocuvanja
  postojecih funkcija. Bez horizontalnog skrolovanja odnosi se na XL izbor.
- Website priprema izvedena iz stvarnog repozitorijuma teraphonia-site;
  sacuvan dizajn i sekcija drugih projekata. DOWNLOAD je disabled, bez javnog
  APK URL-a. Uklonjen stari price/trial tekst iz BM prodajnih djelova.
- Originalni signing sistem (BM_KEYSTORE_* / BM_KEY_ALIAS) nije zamijenjen.
  Novi kljuc nije generisan. Workflow/script pripremaju privatne izlaze tek
  iz stvarnog release APK-a provjerenog originalnim fingerprint-om.
- Workflow ne uploaduje placeni APK kao artefakt javnog repozitorijuma.

## Izvrsene provjere

PASS: ulazni ZIP SHA-256 i otvaranje arhive; identifikacija verzije i UI.
PASS: byte comparison originalnih runtime fajlova za A/B, audio engine,
RollMonster, playback service, playlist persistence, backup/import, CF i
commercial runtime; svi ostaju identicni originalnom prilogu.
PASS: sve izmjene postojeceg MainActivity.kt ogranicene na uvoze,
BreakPlaylistTabs i opt-in reljef PlaylistStoneButton; ostale funkcije identicne.
PASS: node --check za website JavaScript.
PASS: 4 izvrsena JS testa: zakljucan DOWNLOAD pri unavailable release-u,
available=true sa javnim APK URL-om, neispravnom manifestu i network gresci.
PASS: Python syntax compilation za release packaging skriptu.
PASS: YAML parse oba workflow-a (ne dokazuje izvrsavanje GitHub Actions).
PASS: skripta odbija izvorni ZIP predstavljen kao APK i ne pravi izlaz.
PASS: zavrsne arhive otvorene i svi CRC sadrzaji provjereni; checksumovi
izracunati iz stvarnih isporucenih fajlova.

## Blokirano / NIJE izvrseno

./gradlew --no-daemon :app:assembleRelease :app:lintRelease je pokrenut
poslije izmjena. Zastao je prije kompilacije pri preuzimanju Gradle 8.9:
java.net.SocketException: Network is unreachable (vidi verification/release-build.log).
Android SDK, Gradle distribucija i dependency cache nijesu dostupni.
Nema lokalnog originalnog signing kljuca niti signing environment podataka.
Nema Android uredjaja/emulatora/adb-a u ovom okruzenju.

NE MOZE se potvrditi: Kotlin/Compose kompilacija, uspjesan release build,
APK potpis, stvarna APK verzija/package/debuggable flag, instalacija,
pokretanje, UI na A9+/A7/telefonu ni funkcionalni audio regresioni testovi.
Pregled izvora i byte comparison nijesu zamjena za runtime test.

## Isporuka i granice

BrakeMonster_Pro.zip sadrzi izmijenjeni kompletni izvor, provjere i pripremu sajta.
BrakeMonster-PRO-WEBSITE.zip je IZRICITO PAKET PRIPREME BEZ APK-a, jer
stvarni potpisani release nije mogao biti napravljen. Sadrzi public-site/, verziju,
uputstvo, ovaj izvjestaj, status blokade i alat za dovrsetak paketa.
BrakeMonster-PRO.apk NIJE isporucen; ne postoji stvarni build koji bi ga opravdao.
Ni SHA-256 APK-a ni signing fingerprint nijesu izmisljeni.

Za dovrsetak: build okruzenje s mrezom/SDK-om i originalnim kljucem, pa
provjera na tabletima i telefonu. tools/package_website_release.py tada
pravi stvarni APK i WEBSITE ZIP sa verzijom, SHA-256 i izvjestajem potpisa.

Nista nije pushovano na GitHub niti objavljeno; sajt i Worker nijesu mijenjani.
Naplata, licence, cijena i checkout link nijesu aktivirani.
Ne uploadovati cijeli buduci WEBSITE ZIP na javni hosting; private/ APK
mora ostati van public-site/ i javnih GitHub artefakata.
