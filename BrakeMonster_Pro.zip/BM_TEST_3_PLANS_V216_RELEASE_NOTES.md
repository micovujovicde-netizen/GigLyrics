# 🦖 BrakeMonster PRO — v216, three TEST plans

Source of truth: user-provided `BrakeMonster_Pro.zip`, SHA-256 `09780add0355d32527c7c3fc5cc893507868dd149edf8e7a1505dcb5ee17f1dc`.
Original app: versionCode 215, versionName `1.0.180-pro.99` (`-TEST` when BM_LICENSE_TEST_MODE=true).
New app: versionCode 216, versionName `1.0.181-pro.100` (`-TEST` when BM_LICENSE_TEST_MODE=true).

## Changes (only CommercialRelease.kt and app/build.gradle.kts)
- In TEST builds, BUY PRO now opens a single high-contrast, large-touch-target picker: MONTHLY €2.99 / YEARLY €19.90 / LIFETIME €39.00.
- Selected plan is sent to the existing TEST Worker POST `/v1/checkout` via authenticated JSON body (`plan` = `monthly`, `yearly` or `lifetime`). The Worker retains control of the Creem product IDs and metadata associating a purchase with the installation.
- Checkout URLs are validated to HTTPS under Creem domains; no direct public payment links or keys have been embedded.
- A checkout-start guard avoids double taps creating simultaneous requests.
- When a TEST entitlement is already active, HELP/ABOUT shows a TEST PLANS control so that YEARLY and LIFETIME can still be tested without clearing app data. MANAGE SUBSCRIPTION remains available.
- Production BUY PRO still opens `https://teraphonia.com/buy.html#device=...`; no production API routing, credentials, Cloudflare Worker or audio/player code was changed.

## Existing backend prerequisites
- TEST Worker must be version that accepts three plan names. The previous user-supplied TEST Worker package `BrakeMonster_TEST_3_PLANS.zip` contains all three mappings; this app ZIP does NOT deploy it.
- All three Creem TEST products must exist, TEST billing must be enabled, and valid Creem TEST API and webhook secrets must remain on the TEST Worker.
- TEST and production entitlements remain in different app preferences.

## Build and tests
- Static source/ZIP contract verification performed against original ZIP and three-plan TEST Worker source.
- Full Gradle Android build, signing, device installation, checkout and D1 verification NOT performed here (Android SDK/Gradle caches unavailable).
- From GitHub Actions run workflow `Build BrakeMonster PRO candidate` with `license_test_mode=true`. Do NOT use a push-triggered default build for TEST; it selects PRODUCTION.
- Update must be signed with existing app signing key to install over v215.
- For manual QA: BUY PRO (inactive) -> choose each plan -> ensure Creem TEST checkout; BUY PRO (active) -> HELP/ABOUT -> TEST PLANS; return to app -> entitlement refresh; check corresponding D1 record and Manage Subscription.

## Scope
No source file other than `CommercialRelease.kt` and `app/build.gradle.kts` was modified. No cloud changes or deployment performed.
