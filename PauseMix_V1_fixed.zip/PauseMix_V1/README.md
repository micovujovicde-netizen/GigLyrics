# PauseMix V1

Minimal Android A/B music mixer for breaks, cafés, restaurants and simple background playback.

## V1 flow

1. Search a song in the first window.
2. Import it to deck **A** or **B**.
3. Open **Mixer**.
4. Play A and B independently.
5. Adjust deck volumes and the large crossfader.
6. If the Android device is already connected to a Bluetooth speaker/PA, Android routes the mixed app audio there automatically.

## Included

- YouTube-style search via **NewPipe Extractor**
- Separate Search and Mixer activities
- A/B deck import
- Two simultaneous Media3/ExoPlayer instances
- Per-deck volume
- Equal-power crossfader
- Bluetooth-output indicator
- Simple **Tap BPM** on each deck (tap the BPM label; long-press to reset)
- Source/extractor layer separated from mixer logic

## NewPipe updates

The extractor version is intentionally centralized in:

`gradle.properties`

```
NEWPIPE_VERSION=v0.26.2
```

When YouTube changes and NewPipe publishes a fix, update only that version first.

## Planned next

- automatic BPM analysis
- automatic crossfade near track end
- automatic Similar Song search
- modes: Ex-Yu / English Pop-Rock / Blues-Soul / Folk / Dance / Chill
- endless automatic A/B refill

## Important

This is a technical V1 prototype. Playback from third-party platforms can be affected by platform changes, stream restrictions, or terms/licensing. For commercial/public playback, venue operators should use appropriately licensed music sources.

## Build

Open the folder in Android Studio and sync Gradle.

Recommended:
- JDK 17
- Android SDK 35
- Internet connection for first Gradle sync
