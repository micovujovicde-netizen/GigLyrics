package com.terafon.pausemix

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.terafon.pausemix.databinding.ActivityMainBinding
import com.terafon.pausemix.model.MixerStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val repo = SearchRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val adapter = SearchAdapter(
            onImportA = {
                MixerStore.deckA = it
                Toast.makeText(this, "Imported to A", Toast.LENGTH_SHORT).show()
            },
            onImportB = {
                MixerStore.deckB = it
                Toast.makeText(this, "Imported to B", Toast.LENGTH_SHORT).show()
            }
        )

        binding.results.layoutManager = LinearLayoutManager(this)
        binding.results.adapter = adapter

        fun doSearch() {
            val q = binding.searchInput.text.toString().trim()
            if (q.isBlank()) return
            binding.progress.visibility = View.VISIBLE
            binding.statusText.text = "Searching…"

            lifecycleScope.launch {
                runCatching {
                    withContext(Dispatchers.IO) { repo.search(q) }
                }.onSuccess { results ->
                    adapter.submit(results)
                    binding.statusText.text = "${results.size} results"
                }.onFailure {
                    binding.statusText.text = "Search error: ${it.message ?: "unknown"}"
                }
                binding.progress.visibility = View.GONE
            }
        }

        binding.searchButton.setOnClickListener { doSearch() }
        binding.searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                doSearch()
                true
            } else false
        }

        binding.openMixer.setOnClickListener {
            startActivity(Intent(this, MixerActivity::class.java))
        }
    }
}
