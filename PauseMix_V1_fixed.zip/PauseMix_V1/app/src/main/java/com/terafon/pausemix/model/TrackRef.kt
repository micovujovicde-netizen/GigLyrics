package com.terafon.pausemix.model

data class TrackRef(
    val title: String,
    val uploader: String,
    val url: String,
    val durationSeconds: Long
)
