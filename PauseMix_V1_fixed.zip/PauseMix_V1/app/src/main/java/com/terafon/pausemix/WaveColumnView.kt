package com.terafon.pausemix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.sin

/**
 * High-contrast portrait waveform column.
 * The pattern scrolls upward while the deck is playing.
 */
class WaveColumnView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = resources.displayMetrics.density * 3f
        strokeCap = Paint.Cap.ROUND
    }

    private var running = false
    private var phase = 0f
    private var seed = 0

    fun setTrackSeed(value: String?) {
        seed = value?.hashCode() ?: 0
        invalidate()
    }

    fun setRunning(value: Boolean) {
        if (running == value) return
        running = value
        if (running) postInvalidateOnAnimation() else invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.BLACK)

        val cx = width / 2f
        val rowGap = resources.displayMetrics.density * 10f
        val minHalf = resources.displayMetrics.density * 5f
        val maxHalf = (width * 0.42f).coerceAtLeast(minHalf)
        val rows = (height / rowGap).toInt().coerceAtLeast(1)

        for (i in 0 until rows) {
            val y = height - ((i * rowGap + phase) % (height + rowGap))
            val n = i + seed * 0.013f
            val wave = abs(
                sin(n.toDouble() * 0.71) * 0.62 +
                    sin(n.toDouble() * 0.19) * 0.38
            ).toFloat()
            val half = minHalf + (maxHalf - minHalf) * wave
            canvas.drawLine(cx - half, y, cx + half, y, paint)
        }

        if (running) {
            phase += resources.displayMetrics.density * 2.4f
            if (phase > rowGap) phase -= rowGap
            postInvalidateOnAnimation()
        }
    }
}
