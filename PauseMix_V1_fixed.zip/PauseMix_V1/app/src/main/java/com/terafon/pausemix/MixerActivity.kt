package com.terafon.pausemix

import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Bundle
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.terafon.pausemix.databinding.ActivityMixerBinding
import com.terafon.pausemix.model.MixerStore
import com.terafon.pausemix.model.TrackRef
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.PI

class MixerActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMixerBinding
    private lateinit var playerA: ExoPlayer
    private lateinit var playerB: ExoPlayer

    private var userVolA = 1f
    private var userVolB = 1f
    private var cross = 0.5f

    private val tapA = TapTempo()
    private val tapB = TapTempo()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMixerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        playerA = ExoPlayer.Builder(this).build()
        playerB = ExoPlayer.Builder(this).build()

        binding.backToSearch.setOnClickListener { finish() }

        binding.titleA.text = MixerStore.deckA?.title ?: "EMPTY"
        binding.titleB.text = MixerStore.deckB?.title ?: "EMPTY"
        binding.waveA.setTrackSeed(MixerStore.deckA?.title)
        binding.waveB.setTrackSeed(MixerStore.deckB?.title)

        binding.playA.setOnClickListener { toggleDeck(true, MixerStore.deckA) }
        binding.playB.setOnClickListener { toggleDeck(false, MixerStore.deckB) }

        binding.bpmA.setOnClickListener {
            tapA.tap()?.let { binding.bpmA.text = "$it BPM" }
        }
        binding.bpmA.setOnLongClickListener {
            tapA.reset()
            binding.bpmA.text = "-- BPM  • tap"
            true
        }
        binding.bpmB.setOnClickListener {
            tapB.tap()?.let { binding.bpmB.text = "$it BPM" }
        }
        binding.bpmB.setOnLongClickListener {
            tapB.reset()
            binding.bpmB.text = "-- BPM  • tap"
            true
        }

        binding.volumeA.setOnSeekBarChangeListener(simpleSeek { p ->
            userVolA = p / 100f
            applyVolumes()
        })
        binding.volumeB.setOnSeekBarChangeListener(simpleSeek { p ->
            userVolB = p / 100f
            applyVolumes()
        })
        binding.crossfader.setOnSeekBarChangeListener(simpleSeek { p ->
            cross = p / 100f
            applyVolumes()
        })

        updateOutputIndicator()
        applyVolumes()
    }

    private fun simpleSeek(onProgress: (Int) -> Unit) =
        object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                onProgress(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        }

    private fun toggleDeck(isA: Boolean, track: TrackRef?) {
        if (track == null) {
            Toast.makeText(this, "Import a song first", Toast.LENGTH_SHORT).show()
            return
        }

        val player = if (isA) playerA else playerB
        val button = if (isA) binding.playA else binding.playB

        if (player.mediaItemCount > 0) {
            if (player.isPlaying) {
                player.pause()
                button.text = if (isA) "A  ▶ PLAY" else "B  ▶ PLAY"
                if (isA) binding.waveA.setRunning(false) else binding.waveB.setRunning(false)
            } else {
                player.play()
                button.text = if (isA) "A  II PAUSE" else "B  II PAUSE"
                if (isA) binding.waveA.setRunning(true) else binding.waveB.setRunning(true)
            }
            return
        }

        button.text = if (isA) "A  LOADING" else "B  LOADING"
        lifecycleScope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    AudioResolver.resolveBestAudioUrl(track.url)
                }
            }.onSuccess { direct ->
                player.setMediaItem(MediaItem.fromUri(direct))
                player.prepare()
                player.play()
                button.text = if (isA) "A  II PAUSE" else "B  II PAUSE"
                if (isA) binding.waveA.setRunning(true) else binding.waveB.setRunning(true)
            }.onFailure {
                button.text = if (isA) "A  ▶ PLAY" else "B  ▶ PLAY"
                Toast.makeText(
                    this@MixerActivity,
                    "Stream error: ${it.message ?: "unknown"}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun applyVolumes() {
        // Equal-power crossfade: midpoint keeps both decks audible without a deep level dip.
        val aGain = cos(cross * PI / 2.0).toFloat()
        val bGain = sin(cross * PI / 2.0).toFloat()
        playerA.volume = (userVolA * aGain).coerceIn(0f, 1f)
        playerB.volume = (userVolB * bGain).coerceIn(0f, 1f)
    }

    private fun updateOutputIndicator() {
        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        val outputs = audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val bt = outputs.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
            it.type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
            it.type == AudioDeviceInfo.TYPE_BLE_SPEAKER
        }
        binding.outputIndicator.text =
            if (bt != null) "BT" else "DEVICE"
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized) {
            binding.titleA.text = MixerStore.deckA?.title ?: "EMPTY"
            binding.titleB.text = MixerStore.deckB?.title ?: "EMPTY"
            binding.waveA.setTrackSeed(MixerStore.deckA?.title)
            binding.waveB.setTrackSeed(MixerStore.deckB?.title)
            updateOutputIndicator()
        }
    }

    override fun onDestroy() {
        playerA.release()
        playerB.release()
        super.onDestroy()
    }
}
