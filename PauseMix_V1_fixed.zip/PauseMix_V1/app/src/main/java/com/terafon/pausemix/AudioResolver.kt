package com.terafon.pausemix

import org.schabi.newpipe.extractor.stream.StreamInfo

object AudioResolver {
    fun resolveBestAudioUrl(pageUrl: String): String {
        val info = StreamInfo.getInfo(pageUrl)
        val streams = info.audioStreams
            .filter { it.isUrl }
            .sortedByDescending { it.averageBitrate }

        return streams.firstOrNull()?.content
            ?: throw IllegalStateException("No direct audio stream available")
    }
}
