package com.terafon.pausemix

import com.terafon.pausemix.model.TrackRef
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.StreamType

class SearchRepository {
    fun search(query: String): List<TrackRef> {
        val service = ServiceList.YouTube
        val extractor = service.getSearchExtractor(query)

        // getInitialPage() performs the actual extraction request.
        return extractor.initialPage.items
            .filterIsInstance<StreamInfoItem>()
            .filter {
                it.streamType != StreamType.LIVE_STREAM &&
                it.streamType != StreamType.AUDIO_LIVE_STREAM
            }
            .take(25)
            .map {
                TrackRef(
                    title = it.name,
                    uploader = it.uploaderName ?: "",
                    url = it.url,
                    durationSeconds = it.duration
                )
            }
    }
}
