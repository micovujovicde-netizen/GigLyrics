package com.terafon.pausemix.model

object MixerStore {
    var deckA: TrackRef? = null
    var deckB: TrackRef? = null
}
