# Third-party notices

BreakMonster uses:
- AndroidX / Jetpack Compose libraries by Google/Android Open Source Project.
- android-youtube-player by Pierfrancesco Soffritti for the standard YouTube embedded player surface.

YouTube content remains subject to YouTube's terms, availability, embedding restrictions, and advertisements.
