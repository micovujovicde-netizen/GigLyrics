# BreakMonster 1.0.0

Standalone BREAK player extracted from the attached GigMonster/CdgLite 1.7.20 source.

Core behavior:
- SAF root folder binding with persistent access.
- Dedicated HOME/BACK navigation inside the bound BREAK root.
- Local MP3/WAV/audio/media playback in a foreground media service.
- Sequential/random order, repeat, next, pause/play, seek and persistent background playback.
- YouTube search through YouTube's web search and official embedded player.
- Saved `.yt` links are written into the currently open BreakMonster folder and replay through the official YouTube player.
- Small non-touchable YouTube preview above the transport bar; PiP when leaving the app during YouTube playback.
- Long-press local or `.yt` entries for Rename/Delete.
- Custom BreakMonster stage bitmap, logo and app icon.

## GitHub Actions

`.github/workflows/brakemonster.yml` expects `BrakeMonster.zip` at repository root and uploads artifact `BreakMonster-APK`.
