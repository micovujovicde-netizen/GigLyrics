package com.teraphonia.breakmonster

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class BreakPlaybackService : Service() {
    data class Entry(val uri: String, val name: String)
    data class StartRequest(
        val files: List<Entry>,
        val selectedUri: String?,
        val random: Boolean,
        val repeat: Boolean,
        val volume: Float
    )
    data class Snapshot(
        val trackUri: String? = null,
        val trackName: String? = null,
        val preparing: Boolean = false,
        val playing: Boolean = false,
        val position: Int = 0,
        val duration: Int = 0,
        val random: Boolean = false,
        val repeat: Boolean = false,
        val sessionActive: Boolean = false
    )

    companion object {
        private const val CHANNEL_ID = "breakmonster_playback"
        private const val NOTIFICATION_ID = 9207
        private const val ACTION_START = "com.teraphonia.breakmonster.START"
        private const val ACTION_TOGGLE = "com.teraphonia.breakmonster.TOGGLE"
        private const val ACTION_PREVIOUS = "com.teraphonia.breakmonster.PREVIOUS"
        private const val ACTION_NEXT = "com.teraphonia.breakmonster.NEXT"
        private const val ACTION_STOP = "com.teraphonia.breakmonster.STOP"

        @Volatile private var activeInstance: BreakPlaybackService? = null
        @Volatile private var pendingStart: StartRequest? = null
        @Volatile var onSingleTrackCompleted: (() -> Unit)? = null
        @Volatile var snapshot: Snapshot = Snapshot()
            private set

        fun start(context: Context, request: StartRequest) {
            pendingStart = request
            context.startForegroundService(Intent(context, BreakPlaybackService::class.java).setAction(ACTION_START))
        }
        fun seekTo(value: Int) { activeInstance?.seekInternal(value) }
        fun next() { activeInstance?.nextInternal() }
        fun previous() { activeInstance?.previousInternal() }
        fun togglePause() { activeInstance?.toggleInternal() }
        fun setRandom(value: Boolean) { activeInstance?.setRandomInternal(value) }
        fun setRepeat(value: Boolean) { activeInstance?.setRepeatInternal(value) }
        fun setVolume(value: Float) { activeInstance?.setVolumeInternal(value) }
        fun stop(context: Context) {
            pendingStart = null
            activeInstance?.stopInternal() ?: context.stopService(Intent(context, BreakPlaybackService::class.java))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val resolverScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var resolverJob: Job? = null
    private var playbackGeneration = 0
    private var streamTrack = false
    private var startedAudioAt = 0L
    private var lastAudioFailure: String? = null

    private var player: MediaPlayer? = null
    // Independent of UI snapshot: only onPrepared makes MediaPlayer queryable.
    private var playerPrepared = false
    private var files: List<Entry> = emptyList()
    private var order: List<Int> = emptyList()
    private var orderPosition = -1
    private var random = false
    private var repeat = false
    private var volume = 1f
    private var current: Entry? = null
    private lateinit var mediaSession: MediaSession

    // Local audio is owned by this foreground service, never by the UI/PiP.
    // Audio focus handles calls and other temporary system interruptions.
    private val audioManager by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    private val musicAudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()
    private var ownsAudioFocus = false
    private var resumeAfterTemporaryFocusLoss = false
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_GAIN -> {
                ownsAudioFocus = true
                if (resumeAfterTemporaryFocusLoss) {
                    resumeAfterTemporaryFocusLoss = false
                    val p = player
                    if (p != null && playerPrepared && !snapshot.preparing && !snapshot.playing && snapshot.sessionActive) {
                        runCatching { p.start() }.onSuccess {
                            publish(playing = true)
                            updateNotification()
                        }
                    }
                }
            }
            AudioManager.AUDIOFOCUS_LOSS -> {
                ownsAudioFocus = false
                resumeAfterTemporaryFocusLoss = false
                pauseForAudioInterruption()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                ownsAudioFocus = false
                // Do not duck through a telephone call: pause until focus returns.
                resumeAfterTemporaryFocusLoss = snapshot.playing ||
                    (snapshot.preparing && snapshot.sessionActive)
                pauseForAudioInterruption()
            }
        }
    }
    private val focusRequest by lazy {
        AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(musicAudioAttributes)
            .setOnAudioFocusChangeListener(focusListener, handler)
            .setWillPauseWhenDucked(true)
            .setAcceptsDelayedFocusGain(true)
            .build()
    }

    private fun acquireAudioFocus(): Boolean {
        if (ownsAudioFocus) return true
        return when (audioManager.requestAudioFocus(focusRequest)) {
            AudioManager.AUDIOFOCUS_REQUEST_GRANTED -> {
                ownsAudioFocus = true
                true
            }
            AudioManager.AUDIOFOCUS_REQUEST_DELAYED -> {
                resumeAfterTemporaryFocusLoss = true
                false
            }
            else -> {
                resumeAfterTemporaryFocusLoss = false
                false
            }
        }
    }

    private fun releaseAudioFocus() {
        resumeAfterTemporaryFocusLoss = false
        // Also cancels delayed focus grants queued behind an ongoing call.
        runCatching { audioManager.abandonAudioFocusRequest(focusRequest) }
        ownsAudioFocus = false
    }

    private fun pauseForAudioInterruption() {
        if (snapshot.playing) {
            player?.let { runCatching { it.pause() } }
            publish(playing = false)
            updateNotification()
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            val p = player
            if (p != null && snapshot.sessionActive && playerPrepared) {
                // MediaPlayer is still IDLE while BMQ/NewPipe resolves the URL.
                // Calling getDuration() in IDLE forces MEDIA_ERROR_UNKNOWN (-38).
                // Read BOTH position and duration only after onPrepared has fired.
                val pos = if (snapshot.preparing) snapshot.position else runCatching { p.currentPosition }.getOrDefault(snapshot.position)
                val dur = if (snapshot.preparing) snapshot.duration
                    else if (snapshot.duration > 0) snapshot.duration
                    else runCatching { p.duration }.getOrDefault(0).coerceAtLeast(0)
                publish(position = pos, duration = dur)
                updatePlaybackState()
            }
            handler.postDelayed(this, 250L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        activeInstance = this
        BlackBox.ensureInitialized(applicationContext)
        BlackBox.log("AUDIO SERVICE created")
        createChannel()
        mediaSession = MediaSession(this, "BreakMonster").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() { if (!snapshot.playing) toggleInternal() }
                override fun onPause() { if (snapshot.playing) toggleInternal() }
                override fun onSkipToNext() { nextInternal() }
                override fun onSkipToPrevious() { previousInternal() }
                override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                    return super.onMediaButtonEvent(mediaButtonIntent)
                }
                override fun onStop() { stopInternal() }
                override fun onSeekTo(pos: Long) { seekInternal(pos.toInt()) }
            })
            setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)
            isActive = true
        }
        handler.post(ticker)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val request = pendingStart
                pendingStart = null
                if (request == null || request.files.isEmpty()) {
                    stopInternal()
                    return START_NOT_STICKY
                }
                lastAudioFailure = null
                BlackBox.log("AUDIO PLAYLIST START count=${request.files.size} selected=${request.selectedUri?.substringAfterLast('/') ?: "first"}")
                random = request.random
                repeat = request.repeat
                volume = request.volume.coerceIn(0f, 1f)
                files = request.files.distinctBy { it.uri }
                publish(random = random, repeat = repeat, sessionActive = true, preparing = true)
                startForeground(NOTIFICATION_ID, buildNotification("BreakMonster", false))
                val selected = request.selectedUri?.let { wanted -> files.indexOfFirst { it.uri == wanted } }?.takeIf { it >= 0 }
                rebuildOrder(selected)
                if (order.isEmpty()) stopInternal() else {
                    orderPosition = 0
                    playIndex(order[0])
                }
            }
            ACTION_TOGGLE -> toggleInternal()
            ACTION_NEXT -> nextInternal()
            ACTION_PREVIOUS -> previousInternal()
            ACTION_STOP -> stopInternal()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun rebuildOrder(firstIndex: Int? = null) {
        val all = files.indices.toList()
        if (all.isEmpty()) {
            order = emptyList(); orderPosition = -1; return
        }
        val first = firstIndex?.takeIf { it in all }
        val rest = if (first == null) all else all.filter { it != first }
        val orderedRest = if (random) rest.shuffled() else rest
        order = if (first == null) { if (random) all.shuffled() else all } else listOf(first) + orderedRest
        orderPosition = if (order.isEmpty()) -1 else 0
    }

    private fun playIndex(index: Int) {
        val entry = files.getOrNull(index) ?: return
        releasePlayer()
        current = entry
        lastAudioFailure = null
        val sourceUri = Uri.parse(entry.uri)
        streamTrack = entry.uri.startsWith("https://www.youtube.com/watch?v=") ||
            sourceUri.path.orEmpty().endsWith(".bmq", ignoreCase = true) ||
            sourceUri.path.orEmpty().endsWith(".yt", ignoreCase = true)
        startedAudioAt = 0L
        BlackBox.log("AUDIO TRACK START ${orderPosition + 1}/${order.size} name=${entry.name} kind=${if (streamTrack) "BMQ" else "LOCAL"}")
        publish(trackUri = entry.uri, trackName = entry.name, preparing = true,
            playing = false, position = 0, duration = 0, sessionActive = true)
        updateNotification()

        if (!streamTrack) {
            prepareResolvedSource(entry, null)
            return
        }

        // IMPORTANT: Do not even create a MediaPlayer in the IDLE state while
        // NewPipe is still looking for the stream URL. This prevents state
        // queries or callbacks from sending commands to an unloaded player.
        val generation = playbackGeneration
        BlackBox.log("BMQ RESOLVE BEGIN track=${entry.name}")
        val resolvingWakeLock = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "BrakeMonsterPro:audioResolve")
        runCatching { resolvingWakeLock.acquire(60_000L) }
        resolverJob = resolverScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        val id = if (entry.uri.startsWith("https://www.youtube.com/watch?v="))
                            BmqCodec.extractId(entry.uri) ?: error("Invalid YouTube video ID")
                        else BmqCodec.readReference(applicationContext, Uri.parse(entry.uri))
                        ProStreamResolver.resolveAudio(id)
                    }
                }
                // A manual NEXT/STOP can happen during network extraction.
                if (generation != playbackGeneration || current?.uri != entry.uri || !snapshot.sessionActive)
                    return@launch
                result.fold(
                    onSuccess = { url ->
                        BlackBox.log("BMQ RESOLVE OK track=${entry.name} · creating MediaPlayer")
                        prepareResolvedSource(entry, url)
                    },
                    onFailure = { error ->
                        lastAudioFailure = "BMQ NewPipe resolve"
                        BlackBox.audioFailure("BMQ NewPipe resolve", entry.name, error)
                        publish(preparing = false, playing = false)
                        updateNotification()
                    }
                )
            } finally {
                runCatching { if (resolvingWakeLock.isHeld) resolvingWakeLock.release() }
            }
        }
    }

    /** Called on the service main thread ONLY after the BMQ URL has been
     * resolved. The player is not queried until its onPrepared callback.
     */
    private fun prepareResolvedSource(entry: Entry, streamUrl: String?) {
        if (current?.uri != entry.uri || !snapshot.sessionActive) return
        val p = MediaPlayer()
        playerPrepared = false
        player = p
        try {
            p.setAudioAttributes(musicAudioAttributes)
            p.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            p.setVolume(volume, volume)
            p.setOnPreparedListener {
                if (player === p) {
                    playerPrepared = true
                    val duration = runCatching { p.duration }.getOrDefault(0).coerceAtLeast(0)
                    BlackBox.log("AUDIO PREPARED track=${entry.name} durationMs=$duration")
                    val mayPlay = acquireAudioFocus()
                    if (mayPlay) {
                        runCatching { p.start() }.onSuccess {
                            resumeAfterTemporaryFocusLoss = false
                            startedAudioAt = SystemClock.elapsedRealtime()
                            lastAudioFailure = null
                            BlackBox.log("AUDIO PLAYING track=${entry.name} durationMs=$duration")
                            publish(preparing = false, playing = true, duration = duration)
                        }.onFailure { error ->
                            failCurrent(p, "MediaPlayer.start", error)
                        }
                    } else {
                        BlackBox.log("AUDIO PREPARED waiting for audio focus track=${entry.name}")
                        publish(preparing = false, playing = false, duration = duration)
                    }
                    updateNotification()
                }
            }
            p.setOnCompletionListener {
                if (player === p) {
                    if (streamTrack && (startedAudioAt == 0L ||
                            SystemClock.elapsedRealtime() - startedAudioAt < 2500L)) {
                        failCurrent(p, "premature MediaPlayer completion (less than 2.5s)")
                        return@setOnCompletionListener
                    }
                    BlackBox.log("AUDIO COMPLETED track=${entry.name}")
                    releasePlayer()
                    publish(preparing = false, playing = false, position = snapshot.duration)
                    if (files.size == 1) {
                        publish(trackUri = null, trackName = null, position = 0, duration = 0, sessionActive = true)
                        onSingleTrackCompleted?.invoke()
                    } else advanceInternal()
                }
            }
            p.setOnErrorListener { _, what, extra ->
                if (player === p) {
                    failCurrent(p, "MediaPlayer error what=$what extra=$extra whilePreparing=${snapshot.preparing}")
                }
                true
            }
            p.setOnInfoListener { _, what, _ ->
                if (player === p) {
                    when (what) {
                        MediaPlayer.MEDIA_INFO_BUFFERING_START -> BlackBox.log("AUDIO BUFFERING START track=${entry.name}")
                        MediaPlayer.MEDIA_INFO_BUFFERING_END -> BlackBox.log("AUDIO BUFFERING END track=${entry.name}")
                    }
                }
                true
            }
            if (streamUrl != null) {
                BlackBox.log("AUDIO STREAM DATASOURCE track=${entry.name}")
                // MediaPlayer's header-aware overload requires Context + Uri + headers.
                // The previous two-argument (String, Map) call does not exist.
                p.setDataSource(applicationContext, Uri.parse(streamUrl), mapOf(
                    "User-Agent" to "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/130.0 Mobile Safari/537.36",
                    "Referer" to "https://www.youtube.com/"
                ))
            } else {
                val mediaUri = Uri.parse(entry.uri)
                val afd = runCatching {
                    contentResolver.openAssetFileDescriptor(mediaUri, "r")
                }.getOrNull()
                if (afd != null) {
                    afd.use { descriptor ->
                        if (descriptor.declaredLength >= 0L)
                            p.setDataSource(descriptor.fileDescriptor, descriptor.startOffset, descriptor.declaredLength)
                        else p.setDataSource(descriptor.fileDescriptor)
                    }
                } else {
                    p.setDataSource(applicationContext, mediaUri)
                }
            }
            p.prepareAsync()
            BlackBox.log("AUDIO PREPARE_ASYNC track=${entry.name} · waiting for buffer")
        } catch (error: Exception) {
            failCurrent(p, if (streamUrl != null) "BMQ MediaPlayer prepare" else "local MediaPlayer prepare", error)
        }
    }

    /** Halt on the FIRST error instead of racing through the entire playlist.
     * Manual NEXT still works so users can test a different recording.
     */
    private fun failCurrent(p: MediaPlayer, stage: String, error: Throwable? = null) {
        if (player !== p) return
        lastAudioFailure = stage
        BlackBox.audioFailure(stage, current?.name, error)
        releasePlayer()
        publish(preparing = false, playing = false)
        updateNotification()
    }

    private fun advanceInternal() {
        if (files.isEmpty()) { stopInternal(); return }
        val next = orderPosition + 1
        if (next in order.indices) {
            orderPosition = next
            playIndex(order[next])
            return
        }
        if (repeat) {
            rebuildOrder()
            if (order.isNotEmpty()) {
                orderPosition = 0
                playIndex(order[0])
            } else stopInternal()
        } else stopInternal()
    }

    private fun seekInternal(value: Int) {
        handler.post {
            val p = player ?: return@post
            if (!playerPrepared || snapshot.preparing || snapshot.duration <= 0) return@post
            val target = value.coerceIn(0, snapshot.duration)
            runCatching { p.seekTo(target) }
            publish(position = target)
        }
    }

    private fun nextInternal() {
        handler.post {
            if (!snapshot.sessionActive) return@post
            releasePlayer()
            publish(preparing = false, playing = false)
            advanceInternal()
        }
    }

    private fun previousInternal() {
        handler.post {
            if (!snapshot.sessionActive || order.isEmpty()) return@post
            val prev = orderPosition - 1
            if (prev >= 0) {
                releasePlayer()
                orderPosition = prev
                playIndex(order[prev])
            } else if (snapshot.position > 3000) {
                seekInternal(0)
            } else if (repeat) {
                releasePlayer()
                orderPosition = order.lastIndex
                playIndex(order[orderPosition])
            } else {
                seekInternal(0)
            }
        }
    }

    private fun toggleInternal() {
        handler.post {
            val p = player ?: return@post
            if (!playerPrepared || snapshot.preparing) return@post
            if (snapshot.playing) {
                resumeAfterTemporaryFocusLoss = false
                runCatching { p.pause() }
                publish(playing = false)
                releaseAudioFocus()
            } else if (acquireAudioFocus()) {
                runCatching { p.start() }.onSuccess {
                    resumeAfterTemporaryFocusLoss = false
                    publish(playing = true)
                }
            }
            updateNotification()
        }
    }

    private fun setRandomInternal(value: Boolean) {
        handler.post {
            if (random == value) return@post
            random = value
            val currentIndex = current?.let { now -> files.indexOfFirst { it.uri == now.uri } }?.takeIf { it >= 0 }
            rebuildOrder(currentIndex)
            publish(random = random)
            updateNotification()
        }
    }

    private fun setRepeatInternal(value: Boolean) {
        handler.post {
            repeat = value
            publish(repeat = repeat)
            updateNotification()
        }
    }

    private fun setVolumeInternal(value: Float) {
        handler.post {
            volume = value.coerceIn(0f, 1f)
            player?.setVolume(volume, volume)
        }
    }

    private fun stopInternal() {
        val stopNow = Runnable {
            BlackBox.log("AUDIO SESSION STOP")
            releasePlayer()
            releaseAudioFocus()
            files = emptyList(); order = emptyList(); orderPosition = -1; current = null
            snapshot = Snapshot(random = random, repeat = repeat)
            updatePlaybackState()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        if (Looper.myLooper() == Looper.getMainLooper()) stopNow.run() else handler.post(stopNow)
    }

    private fun releasePlayer() {
        playbackGeneration++
        resolverJob?.cancel()
        resolverJob = null
        val p = player
        player = null
        playerPrepared = false
        if (p != null) runCatching { p.release() }
    }

    private fun publish(
        trackUri: String? = snapshot.trackUri,
        trackName: String? = snapshot.trackName,
        preparing: Boolean = snapshot.preparing,
        playing: Boolean = snapshot.playing,
        position: Int = snapshot.position,
        duration: Int = snapshot.duration,
        random: Boolean = snapshot.random,
        repeat: Boolean = snapshot.repeat,
        sessionActive: Boolean = snapshot.sessionActive
    ) {
        snapshot = Snapshot(trackUri, trackName, preparing, playing, position.coerceAtLeast(0), duration.coerceAtLeast(0), random, repeat, sessionActive)
    }

    private fun updatePlaybackState() {
        if (!::mediaSession.isInitialized) return
        val state = when {
            snapshot.preparing -> PlaybackState.STATE_BUFFERING
            snapshot.playing -> PlaybackState.STATE_PLAYING
            snapshot.sessionActive -> PlaybackState.STATE_PAUSED
            else -> PlaybackState.STATE_STOPPED
        }
        val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_STOP or PlaybackState.ACTION_SEEK_TO
        mediaSession.setMetadata(MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, snapshot.trackName ?: "BrakeMonster")
            .putString(MediaMetadata.METADATA_KEY_ARTIST, "BrakeMonster")
            .putLong(MediaMetadata.METADATA_KEY_DURATION, snapshot.duration.toLong())
            .build())
        mediaSession.setPlaybackState(
            PlaybackState.Builder().setActions(actions)
                .setState(state, snapshot.position.toLong(), if (snapshot.playing) 1f else 0f).build()
        )
    }

    private fun createChannel() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "BreakMonster playback", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Keeps BreakMonster music playing in the background"
                setShowBadge(false)
            }
        )
    }

    private fun servicePendingIntent(action: String, requestCode: Int): PendingIntent = PendingIntent.getService(
        this, requestCode, Intent(this, BreakPlaybackService::class.java).setAction(action),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun buildNotification(title: String, playing: Boolean): Notification {
        val openApp = PendingIntent.getActivity(
            this, 10, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val playPauseIcon = if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val playPauseLabel = if (playing) "Pause" else "Play"
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_play)
            .setContentTitle(title.ifBlank { "BreakMonster" })
            .setContentText(lastAudioFailure?.let { "AUDIO ERROR · Open MIXER > BLACK BOX" } ?: "BreakMonster player")
            .setContentIntent(openApp)
            .setOngoing(playing || snapshot.preparing)
            .setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(Notification.Action.Builder(playPauseIcon, playPauseLabel, servicePendingIntent(ACTION_TOGGLE, 11)).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_previous, "Previous", servicePendingIntent(ACTION_PREVIOUS, 14)).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_next, "Next", servicePendingIntent(ACTION_NEXT, 12)).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Stop", servicePendingIntent(ACTION_STOP, 13)).build())
            .setStyle(Notification.MediaStyle().setMediaSession(mediaSession.sessionToken).setShowActionsInCompactView(0, 2))
            .build()
    }

    private fun updateNotification() {
        if (!snapshot.sessionActive) return
        updatePlaybackState()
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(snapshot.trackName ?: "BreakMonster", snapshot.playing))
    }

    // HOME/minimize keeps playback. Removing the app task is an explicit close: stop and release.
    override fun onTaskRemoved(rootIntent: Intent?) {
        stopInternal()
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        resolverScope.cancel()
        handler.removeCallbacks(ticker)
        releasePlayer()
        releaseAudioFocus()
        if (::mediaSession.isInitialized) {
            mediaSession.isActive = false
            mediaSession.release()
        }
        if (activeInstance === this) activeInstance = null
        snapshot = Snapshot(random = random, repeat = repeat)
        super.onDestroy()
    }
}
