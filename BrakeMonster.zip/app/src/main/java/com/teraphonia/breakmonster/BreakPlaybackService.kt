package com.teraphonia.breakmonster

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

class BreakPlaybackService : Service() {
    data class Entry(val uri: String, val name: String)
    data class StartRequest(
        val files: List<Entry>,
        val selectedUri: String?,
        val random: Boolean,
        val repeat: Boolean,
        val volume: Float
    )
    data class Snapshot(
        val trackUri: String? = null,
        val trackName: String? = null,
        val preparing: Boolean = false,
        val playing: Boolean = false,
        val position: Int = 0,
        val duration: Int = 0,
        val random: Boolean = false,
        val repeat: Boolean = false,
        val sessionActive: Boolean = false
    )

    companion object {
        private const val CHANNEL_ID = "breakmonster_playback"
        private const val NOTIFICATION_ID = 9207
        private const val ACTION_START = "com.teraphonia.breakmonster.START"
        private const val ACTION_TOGGLE = "com.teraphonia.breakmonster.TOGGLE"
        private const val ACTION_NEXT = "com.teraphonia.breakmonster.NEXT"
        private const val ACTION_STOP = "com.teraphonia.breakmonster.STOP"

        @Volatile private var activeInstance: BreakPlaybackService? = null
        @Volatile private var pendingStart: StartRequest? = null
        @Volatile var onSingleTrackCompleted: (() -> Unit)? = null
        @Volatile var snapshot: Snapshot = Snapshot()
            private set

        fun start(context: Context, request: StartRequest) {
            pendingStart = request
            context.startForegroundService(Intent(context, BreakPlaybackService::class.java).setAction(ACTION_START))
        }
        fun seekTo(value: Int) { activeInstance?.seekInternal(value) }
        fun next() { activeInstance?.nextInternal() }
        fun togglePause() { activeInstance?.toggleInternal() }
        fun setRandom(value: Boolean) { activeInstance?.setRandomInternal(value) }
        fun setRepeat(value: Boolean) { activeInstance?.setRepeatInternal(value) }
        fun setVolume(value: Float) { activeInstance?.setVolumeInternal(value) }
        fun stop(context: Context) {
            pendingStart = null
            activeInstance?.stopInternal() ?: context.stopService(Intent(context, BreakPlaybackService::class.java))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var files: List<Entry> = emptyList()
    private var order: List<Int> = emptyList()
    private var orderPosition = -1
    private var random = false
    private var repeat = false
    private var volume = 1f
    private var current: Entry? = null
    private lateinit var mediaSession: MediaSession

    private val ticker = object : Runnable {
        override fun run() {
            val p = player
            if (p != null && snapshot.sessionActive) {
                val pos = if (snapshot.preparing) snapshot.position else runCatching { p.currentPosition }.getOrDefault(snapshot.position)
                val dur = if (snapshot.duration > 0) snapshot.duration else runCatching { p.duration }.getOrDefault(0).coerceAtLeast(0)
                publish(position = pos, duration = dur)
                updatePlaybackState()
            }
            handler.postDelayed(this, 250L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        activeInstance = this
        createChannel()
        mediaSession = MediaSession(this, "BreakMonster").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() { if (!snapshot.playing) toggleInternal() }
                override fun onPause() { if (snapshot.playing) toggleInternal() }
                override fun onSkipToNext() { nextInternal() }
                override fun onStop() { stopInternal() }
                override fun onSeekTo(pos: Long) { seekInternal(pos.toInt()) }
            })
            isActive = true
        }
        handler.post(ticker)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val request = pendingStart
                pendingStart = null
                if (request == null || request.files.isEmpty()) {
                    stopInternal()
                    return START_NOT_STICKY
                }
                random = request.random
                repeat = request.repeat
                volume = request.volume.coerceIn(0f, 1f)
                files = request.files.distinctBy { it.uri }
                publish(random = random, repeat = repeat, sessionActive = true, preparing = true)
                startForeground(NOTIFICATION_ID, buildNotification("BreakMonster", false))
                val selected = request.selectedUri?.let { wanted -> files.indexOfFirst { it.uri == wanted } }?.takeIf { it >= 0 }
                rebuildOrder(selected)
                if (order.isEmpty()) stopInternal() else {
                    orderPosition = 0
                    playIndex(order[0])
                }
            }
            ACTION_TOGGLE -> toggleInternal()
            ACTION_NEXT -> nextInternal()
            ACTION_STOP -> stopInternal()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun rebuildOrder(firstIndex: Int? = null) {
        val all = files.indices.toList()
        if (all.isEmpty()) {
            order = emptyList(); orderPosition = -1; return
        }
        val first = firstIndex?.takeIf { it in all }
        val rest = if (first == null) all else all.filter { it != first }
        val orderedRest = if (random) rest.shuffled() else rest
        order = if (first == null) { if (random) all.shuffled() else all } else listOf(first) + orderedRest
        orderPosition = if (order.isEmpty()) -1 else 0
    }

    private fun playIndex(index: Int) {
        val entry = files.getOrNull(index) ?: return
        releasePlayer()
        current = entry
        publish(trackUri = entry.uri, trackName = entry.name, preparing = true, playing = false, position = 0, duration = 0, sessionActive = true)
        updateNotification()

        val p = MediaPlayer()
        player = p
        p.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
        runCatching { p.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK) }
        p.setVolume(volume, volume)
        p.setOnPreparedListener {
            if (player === p) {
                val duration = runCatching { p.duration }.getOrDefault(0).coerceAtLeast(0)
                p.start()
                publish(preparing = false, playing = true, duration = duration)
                updateNotification()
            }
        }
        p.setOnCompletionListener {
            if (player === p) {
                releasePlayer()
                publish(preparing = false, playing = false, position = snapshot.duration)
                if (files.size == 1) {
                    publish(trackUri = null, trackName = null, position = 0, duration = 0, sessionActive = true)
                    onSingleTrackCompleted?.invoke()
                } else advanceInternal()
            }
        }
        p.setOnErrorListener { _, _, _ ->
            if (player === p) {
                releasePlayer()
                publish(preparing = false, playing = false)
                if (files.size == 1) {
                    publish(trackUri = null, trackName = null, position = 0, duration = 0, sessionActive = true)
                    onSingleTrackCompleted?.invoke()
                } else advanceInternal()
            }
            true
        }
        try {
            val mediaUri = Uri.parse(entry.uri)
            // SAF/content URIs are most reliable through a resolver file descriptor.
            // Fall back to the normal Context+Uri path for providers that do not expose one.
            val afd = runCatching { contentResolver.openAssetFileDescriptor(mediaUri, "r") }.getOrNull()
            if (afd != null) {
                afd.use { descriptor ->
                    if (descriptor.declaredLength >= 0L) {
                        p.setDataSource(descriptor.fileDescriptor, descriptor.startOffset, descriptor.declaredLength)
                    } else {
                        p.setDataSource(descriptor.fileDescriptor)
                    }
                }
            } else {
                p.setDataSource(applicationContext, mediaUri)
            }
            p.prepareAsync()
        } catch (_: Exception) {
            if (player === p) releasePlayer()
            publish(preparing = false, playing = false)
            if (files.size == 1) {
                publish(trackUri = null, trackName = null, position = 0, duration = 0, sessionActive = true)
                onSingleTrackCompleted?.invoke()
            } else advanceInternal()
        }
    }

    private fun advanceInternal() {
        if (files.isEmpty()) { stopInternal(); return }
        val next = orderPosition + 1
        if (next in order.indices) {
            orderPosition = next
            playIndex(order[next])
            return
        }
        if (repeat) {
            rebuildOrder()
            if (order.isNotEmpty()) {
                orderPosition = 0
                playIndex(order[0])
            } else stopInternal()
        } else stopInternal()
    }

    private fun seekInternal(value: Int) {
        handler.post {
            val p = player ?: return@post
            if (snapshot.preparing || snapshot.duration <= 0) return@post
            val target = value.coerceIn(0, snapshot.duration)
            runCatching { p.seekTo(target) }
            publish(position = target)
        }
    }

    private fun nextInternal() {
        handler.post {
            if (!snapshot.sessionActive) return@post
            releasePlayer()
            publish(preparing = false, playing = false)
            advanceInternal()
        }
    }

    private fun toggleInternal() {
        handler.post {
            val p = player ?: return@post
            if (snapshot.preparing) return@post
            if (snapshot.playing) {
                runCatching { p.pause() }
                publish(playing = false)
            } else {
                runCatching { p.start() }
                publish(playing = true)
            }
            updateNotification()
        }
    }

    private fun setRandomInternal(value: Boolean) {
        handler.post {
            if (random == value) return@post
            random = value
            val currentIndex = current?.let { now -> files.indexOfFirst { it.uri == now.uri } }?.takeIf { it >= 0 }
            rebuildOrder(currentIndex)
            publish(random = random)
            updateNotification()
        }
    }

    private fun setRepeatInternal(value: Boolean) {
        handler.post {
            repeat = value
            publish(repeat = repeat)
            updateNotification()
        }
    }

    private fun setVolumeInternal(value: Float) {
        handler.post {
            volume = value.coerceIn(0f, 1f)
            player?.setVolume(volume, volume)
        }
    }

    private fun stopInternal() {
        val stopNow = Runnable {
            releasePlayer()
            files = emptyList(); order = emptyList(); orderPosition = -1; current = null
            snapshot = Snapshot(random = random, repeat = repeat)
            updatePlaybackState()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        if (Looper.myLooper() == Looper.getMainLooper()) stopNow.run() else handler.post(stopNow)
    }

    private fun releasePlayer() {
        val p = player
        player = null
        if (p != null) runCatching { p.release() }
    }

    private fun publish(
        trackUri: String? = snapshot.trackUri,
        trackName: String? = snapshot.trackName,
        preparing: Boolean = snapshot.preparing,
        playing: Boolean = snapshot.playing,
        position: Int = snapshot.position,
        duration: Int = snapshot.duration,
        random: Boolean = snapshot.random,
        repeat: Boolean = snapshot.repeat,
        sessionActive: Boolean = snapshot.sessionActive
    ) {
        snapshot = Snapshot(trackUri, trackName, preparing, playing, position.coerceAtLeast(0), duration.coerceAtLeast(0), random, repeat, sessionActive)
    }

    private fun updatePlaybackState() {
        if (!::mediaSession.isInitialized) return
        val state = when {
            snapshot.preparing -> PlaybackState.STATE_BUFFERING
            snapshot.playing -> PlaybackState.STATE_PLAYING
            snapshot.sessionActive -> PlaybackState.STATE_PAUSED
            else -> PlaybackState.STATE_STOPPED
        }
        val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_STOP or PlaybackState.ACTION_SEEK_TO
        mediaSession.setPlaybackState(
            PlaybackState.Builder().setActions(actions)
                .setState(state, snapshot.position.toLong(), if (snapshot.playing) 1f else 0f).build()
        )
    }

    private fun createChannel() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "BreakMonster playback", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Keeps BreakMonster music playing in the background"
                setShowBadge(false)
            }
        )
    }

    private fun servicePendingIntent(action: String, requestCode: Int): PendingIntent = PendingIntent.getService(
        this, requestCode, Intent(this, BreakPlaybackService::class.java).setAction(action),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun buildNotification(title: String, playing: Boolean): Notification {
        val openApp = PendingIntent.getActivity(
            this, 10, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val playPauseIcon = if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val playPauseLabel = if (playing) "Pause" else "Play"
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_play)
            .setContentTitle(title.ifBlank { "BreakMonster" })
            .setContentText("BreakMonster player")
            .setContentIntent(openApp)
            .setOngoing(playing || snapshot.preparing)
            .setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(Notification.Action.Builder(playPauseIcon, playPauseLabel, servicePendingIntent(ACTION_TOGGLE, 11)).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_next, "Next", servicePendingIntent(ACTION_NEXT, 12)).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Stop", servicePendingIntent(ACTION_STOP, 13)).build())
            .setStyle(Notification.MediaStyle().setMediaSession(mediaSession.sessionToken).setShowActionsInCompactView(0, 1))
            .build()
    }

    private fun updateNotification() {
        if (!snapshot.sessionActive) return
        updatePlaybackState()
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(snapshot.trackName ?: "BreakMonster", snapshot.playing))
    }

    // HOME/minimize keeps playback. Removing the app task is an explicit close: stop and release.
    override fun onTaskRemoved(rootIntent: Intent?) {
        stopInternal()
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        releasePlayer()
        if (::mediaSession.isInitialized) {
            mediaSession.isActive = false
            mediaSession.release()
        }
        if (activeInstance === this) activeInstance = null
        snapshot = Snapshot(random = random, repeat = repeat)
        super.onDestroy()
    }
}
