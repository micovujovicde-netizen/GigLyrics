package com.teraphonia.breakmonster

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.util.Locale

internal data class BreakItem(
    val file: DocumentFile,
    val name: String,
    val isYoutube: Boolean
)

internal val localPlayableExtensions = setOf(
    "mp3", "wav", "wave", "m4a", "aac", "flac", "ogg", "opus", "amr",
    "mp4", "m4v", "mov", "3gp", "3g2", "mkv", "webm", "avi", "ts", "m2ts", "mpeg", "mpg"
)

internal fun DocumentFile.extensionLower(): String =
    name.orEmpty().substringAfterLast('.', "").lowercase(Locale.ROOT)

internal class BreakMonsterModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("breakmonster", 0)

    var rootUri by mutableStateOf(prefs.getString("root", null))
        private set

    var path by mutableStateOf(loadPath())
        private set

    var folders by mutableStateOf<List<DocumentFile>>(emptyList())
        private set
    var tracks by mutableStateOf<List<BreakItem>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    var random by mutableStateOf(prefs.getBoolean("random", false))
        private set
    var repeat by mutableStateOf(prefs.getBoolean("repeat", false))
        private set

    var localTrackUri by mutableStateOf<String?>(null)
        private set
    var localTrackName by mutableStateOf<String?>(null)
        private set
    var localPreparing by mutableStateOf(false)
        private set
    var localPlaying by mutableStateOf(false)
        private set
    var localPosition by mutableIntStateOf(0)
        private set
    var localDuration by mutableIntStateOf(0)
        private set

    var youtubeVideoId by mutableStateOf<String?>(null)
        private set
    var youtubeUrl by mutableStateOf<String?>(null)
        private set
    var youtubeTitle by mutableStateOf<String?>(null)
        private set
    var youtubeSession by mutableIntStateOf(0)
        private set
    var youtubePlaying by mutableStateOf(false)
        private set
    var youtubeCurrentSecond by mutableStateOf(0f)
        private set
    var youtubeDurationSecond by mutableStateOf(0f)
        private set

    var refreshSerial by mutableIntStateOf(0)
        private set

    var message by mutableStateOf<String?>(null)
        private set

    init {
        viewModelScope.launch {
            while (isActive) {
                syncServiceSnapshot()
                delay(150)
            }
        }
    }

    private fun loadPath(): List<String> = runCatching {
        val raw = prefs.getString("path", null) ?: return@runCatching emptyList<String>()
        val json = JSONArray(raw)
        (0 until json.length()).map { json.getString(it) }
    }.getOrDefault(emptyList<String>())

    private fun persistPath() {
        prefs.edit().putString("path", JSONArray(path).toString()).apply()
    }

    fun consumeMessage() { message = null }

    fun setRoot(uri: Uri) {
        rootUri = uri.toString()
        path = emptyList<String>()
        prefs.edit().putString("root", rootUri).putString("path", "[]").apply()
        refreshSerial++
    }

    fun home() {
        if (path.isNotEmpty()) {
            path = emptyList<String>()
            persistPath()
        }
    }

    /** @return true when a folder level was consumed. */
    fun back(): Boolean {
        if (path.isEmpty()) return false
        path = path.dropLast(1)
        persistPath()
        return true
    }

    fun openFolder(dir: DocumentFile) {
        val name = dir.name ?: return
        path = path + name
        persistPath()
    }

    private fun resolveFolder(relative: List<String> = path): DocumentFile? {
        var dir = rootUri?.let { DocumentFile.fromTreeUri(getApplication(), Uri.parse(it)) } ?: return null
        for (name in relative) {
            dir = dir.findFile(name)?.takeIf { it.isDirectory } ?: return null
        }
        return dir
    }

    fun refresh() {
        val target = rootUri ?: run {
            folders = emptyList<DocumentFile>(); tracks = emptyList<BreakItem>(); loading = false; return
        }
        viewModelScope.launch {
            loading = true
            error = null
            try {
                val result = withContext(Dispatchers.IO) {
                    var dir = DocumentFile.fromTreeUri(getApplication(), Uri.parse(target))
                        ?: kotlin.error("Missing root")
                    val resolved = mutableListOf<String>()
                    for (segment in path) {
                        val next = dir.findFile(segment)?.takeIf { it.isDirectory } ?: break
                        dir = next
                        resolved += segment
                    }
                    val children = dir.listFiles().toList()
                    val dirs = children.filter { it.isDirectory }
                        .sortedBy { it.name.orEmpty().lowercase(Locale.ROOT) }
                    val files = children.filter { file ->
                        file.isFile && (file.extensionLower() in localPlayableExtensions || file.extensionLower() == "yt")
                    }.sortedBy { it.name.orEmpty().lowercase(Locale.ROOT) }
                        .map { file ->
                            BreakItem(
                                file = file,
                                name = file.name.orEmpty().substringBeforeLast('.', file.name.orEmpty()),
                                isYoutube = file.extensionLower() == "yt"
                            )
                        }
                    Triple(resolved.toList(), dirs, files)
                }
                val (resolved, dirs, files) = result
                if (resolved != path) {
                    path = resolved
                    persistPath()
                }
                folders = dirs
                tracks = files
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                error = "Folder nije dostupan. Dodirni folder gore desno i izaberi ga ponovo."
            } finally {
                loading = false
            }
        }
    }

    fun startLocal(selected: BreakItem) {
        if (selected.isYoutube) return
        clearYoutube()
        val playable = tracks.filter { !it.isYoutube && it.file.extensionLower() in localPlayableExtensions }
        if (playable.isEmpty()) return
        val request = BreakPlaybackService.StartRequest(
            files = playable.map { BreakPlaybackService.Entry(it.file.uri.toString(), it.file.name ?: it.name) },
            selectedUri = selected.file.uri.toString(),
            random = random,
            repeat = repeat,
            volume = 1f
        )
        BreakPlaybackService.start(getApplication(), request)
    }

    fun toggleLocalPause() = BreakPlaybackService.togglePause()
    fun nextLocal() = BreakPlaybackService.next()
    fun seekLocal(value: Int) = BreakPlaybackService.seekTo(value)
    fun stopLocal() = BreakPlaybackService.stop(getApplication())

    fun setRandom(value: Boolean) {
        random = value
        prefs.edit().putBoolean("random", value).apply()
        BreakPlaybackService.setRandom(value)
    }

    fun setRepeat(value: Boolean) {
        repeat = value
        prefs.edit().putBoolean("repeat", value).apply()
        BreakPlaybackService.setRepeat(value)
    }

    fun selectYoutube(videoId: String, title: String?, sourceUrl: String? = null) {
        stopLocal()
        youtubeVideoId = videoId
        youtubeUrl = sourceUrl?.takeIf { it.isNotBlank() } ?: "https://www.youtube.com/watch?v=$videoId"
        youtubeTitle = title?.trim()?.takeIf { it.isNotBlank() } ?: "YouTube"
        youtubeCurrentSecond = 0f
        youtubeDurationSecond = 0f
        youtubePlaying = false
        youtubeSession++
    }

    fun openSavedYoutube(item: BreakItem) {
        if (!item.isYoutube) return
        viewModelScope.launch {
            val link = withContext(Dispatchers.IO) {
                runCatching {
                    getApplication<Application>().contentResolver.openInputStream(item.file.uri)
                        ?.bufferedReader()?.use { it.readText().trim() }
                }.getOrNull()
            }
            val id = extractYoutubeVideoId(link)
            if (id == null) {
                message = "Sačuvani YT link nije dostupan."
            } else {
                selectYoutube(id, item.name, link)
            }
        }
    }

    fun clearYoutube() {
        youtubeVideoId = null
        youtubeUrl = null
        youtubeTitle = null
        youtubePlaying = false
        youtubeCurrentSecond = 0f
        youtubeDurationSecond = 0f
    }

    fun onYoutubePlaying(value: Boolean) { youtubePlaying = value }
    fun onYoutubeCurrentSecond(value: Float) { youtubeCurrentSecond = value.coerceAtLeast(0f) }
    fun onYoutubeDuration(value: Float) { youtubeDurationSecond = value.coerceAtLeast(0f) }

    fun saveYoutubeToCurrentFolder() {
        val url = youtubeUrl ?: run { message = "Prvo pusti YouTube video."; return }
        val title = youtubeTitle ?: "YouTube"
        viewModelScope.launch {
            val saved = withContext(Dispatchers.IO) {
                val folder = resolveFolder() ?: return@withContext false
                val base = sanitizeFileName(title).ifBlank { "YouTube" }
                val wanted = "$base.yt"
                val existing = folder.listFiles().firstOrNull { it.isFile && it.name.equals(wanted, true) }
                val target = existing ?: folder.createFile("application/octet-stream", wanted) ?: return@withContext false
                getApplication<Application>().contentResolver.openOutputStream(target.uri, "wt")?.use {
                    it.write(url.toByteArray(Charsets.UTF_8))
                } ?: return@withContext false
                true
            }
            if (saved) {
                message = "YT LINK SAVED"
                refreshSerial++
            } else message = "Ne mogu da sačuvam YT link u ovom folderu."
        }
    }

    fun rename(item: BreakItem, newBaseName: String) {
        val clean = sanitizeFileName(newBaseName).trim()
        if (clean.isBlank()) { message = "Ime ne može biti prazno."; return }
        val ext = item.file.extensionLower()
        val wanted = if (ext.isBlank()) clean else "$clean.$ext"
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching { item.file.renameTo(wanted) }.getOrDefault(false) }
            if (!ok) message = "Rename nije uspio."
            refreshSerial++
        }
    }

    fun delete(item: BreakItem) {
        if (localTrackUri == item.file.uri.toString()) stopLocal()
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching { item.file.delete() }.getOrDefault(false) }
            if (!ok) message = "Delete nije uspio."
            refreshSerial++
        }
    }

    private fun syncServiceSnapshot() {
        val s = BreakPlaybackService.snapshot
        localTrackUri = s.trackUri
        localTrackName = s.trackName
        localPreparing = s.preparing
        localPlaying = s.playing
        localPosition = s.position
        localDuration = s.duration
        if (random != s.random && s.sessionActive) random = s.random
        if (repeat != s.repeat && s.sessionActive) repeat = s.repeat
    }

    companion object {
        fun sanitizeFileName(value: String): String = value
            .replace(Regex("[\\/:*?\"<>|]"), "-")
            .replace(Regex("\\s+"), " ")
            .trim().trim('.')
            .take(120)

        fun extractYoutubeVideoId(raw: String?): String? {
            if (raw.isNullOrBlank()) return null
            return runCatching {
                val uri = Uri.parse(raw.trim())
                val host = uri.host?.lowercase(Locale.ROOT).orEmpty().removePrefix("www.").removePrefix("m.")
                val id = when {
                    host == "youtu.be" -> uri.pathSegments.firstOrNull()
                    host == "youtube.com" || host.endsWith(".youtube.com") -> when {
                        uri.path == "/watch" -> uri.getQueryParameter("v")
                        uri.pathSegments.firstOrNull() == "shorts" -> uri.pathSegments.getOrNull(1)
                        uri.pathSegments.firstOrNull() == "live" -> uri.pathSegments.getOrNull(1)
                        uri.pathSegments.firstOrNull() == "embed" -> uri.pathSegments.getOrNull(1)
                        else -> null
                    }
                    else -> null
                }
                id?.takeIf { it.matches(Regex("[A-Za-z0-9_-]{6,20}")) }
            }.getOrNull()
        }
    }
}
