package com.teraphonia.breakmonster

import android.app.Application
import android.content.ContentUris
import android.provider.MediaStore
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream
import java.util.Locale

internal data class BreakItem(
    val file: DocumentFile,
    val name: String,
    val isYoutube: Boolean
)

internal val localPlayableExtensions = setOf(
    "mp3", "wav", "wave", "m4a", "aac", "flac", "ogg", "opus", "amr",
    "mp4", "m4v", "mov", "3gp", "3g2", "mkv", "webm", "avi", "ts", "m2ts", "mpeg", "mpg"
)
internal val importSidecarExtensions = setOf("txt", "lrc", "srt", "cdg", "lyr", "lyr3", "mid", "midi", "kar")

internal fun DocumentFile.extensionLower(): String =
    name.orEmpty().substringAfterLast('.', "").lowercase(Locale.ROOT)

internal class BreakMonsterModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("breakmonster", 0)

    var rootUri by mutableStateOf(prefs.getString("root", null))
        private set

    private var manualRootUris:List<String> = runCatching {
        val raw=prefs.getString("manual_roots",null)
        val saved=if(raw==null) emptyList() else { val a=JSONArray(raw);(0 until a.length()).map{a.getString(it)} }
        (saved + listOfNotNull(rootUri)).distinct()
    }.getOrDefault(listOfNotNull(rootUri))

    var path by mutableStateOf(loadPath())
        private set

    var folders by mutableStateOf<List<DocumentFile>>(emptyList())
        private set
    var tracks by mutableStateOf<List<BreakItem>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    var mediaScanComplete by mutableStateOf(prefs.getBoolean("first_user_scan_complete_v25",false))
        private set
    var mediaScanInProgress by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    var random by mutableStateOf(prefs.getBoolean("random", false))
        private set
    var repeat by mutableStateOf(prefs.getBoolean("repeat", false))
        private set

    var localTrackUri by mutableStateOf<String?>(null)
        private set
    /** Source file owning the active row, including saved YouTube playlist entries. */
    var activePlaybackItemUri by mutableStateOf<String?>(null)
        private set
    var localTrackName by mutableStateOf<String?>(null)
        private set
    var localPreparing by mutableStateOf(false)
        private set
    var localPlaying by mutableStateOf(false)
        private set
    var localPosition by mutableIntStateOf(0)
        private set
    var localDuration by mutableIntStateOf(0)
        private set

    var youtubeVideoId by mutableStateOf<String?>(null)
        private set
    var youtubeUrl by mutableStateOf<String?>(null)
        private set
    var youtubeTitle by mutableStateOf<String?>(null)
        private set
    var youtubeSession by mutableIntStateOf(0)
        private set
    var youtubePlaying by mutableStateOf(false)
        private set
    var youtubeCurrentSecond by mutableStateOf(0f)
        private set
    var youtubeDurationSecond by mutableStateOf(0f)
        private set
    var youtubeSaved by mutableStateOf(false)
        private set
    var youtubeCanSave by mutableStateOf(false)
        private set

    private var playbackQueue: List<BreakItem> = emptyList()
    private var playbackQueueIndex = -1

    var refreshSerial by mutableIntStateOf(0)
        private set

    var message by mutableStateOf<String?>(null)
        private set

    private val installedMediaDir = File(app.filesDir, "installed_media")
    private val brakeMonsterDir = File(app.filesDir, "brakemonster_media")
    private val ytDownloadsDir = File(brakeMonsterDir, "YT DOWNLOADS")
    private var ownedMediaItems by mutableStateOf<List<BreakItem>>(emptyList())
    val brakeMonsterItems: List<BreakItem> get() = ownedMediaItems.filterNot { it.isYoutube }
    val ytDownloadItems: List<BreakItem> get() = ownedMediaItems.filter { it.isYoutube }
    // Compose-facing library must be memory-only. Never rebuild DocumentFiles / parse JSON here.
    private var manualLibraryItems by mutableStateOf<List<BreakItem>>(emptyList())
    // Declared before init because init restores this cache explicitly.
    private var mediaStoreItems: List<BreakItem> = emptyList()
    private var allMusicCache by mutableStateOf<List<BreakItem>>(emptyList())
    val allMusicItems: List<BreakItem> get() = allMusicCache
    /** Every indexed local item, including app-owned imports and their .yt files. */
    val searchableLocalItems: List<BreakItem>
        get() = dedupeMedia(allMusicCache + ownedMediaItems)

    var factoryCategories by mutableStateOf<List<String>>(emptyList())
        private set
    var factoryItems by mutableStateOf<List<BreakItem>>(emptyList())
        private set
    var factoryPlaylistName by mutableStateOf(prefs.getString("factory_playlist", "").orEmpty())
        private set
    var factoryLibraryLoading by mutableStateOf(true)
        private set
    private var factoryByCategory: Map<String, List<BreakItem>> = emptyMap()
    private val factoryLibraryDir = File(app.filesDir, "factory_library")
    private fun rebuildAllMusicCache() {
        allMusicCache = applySavedOrder(
            dedupeMedia(manualLibraryItems + mediaStoreItems).filterNot(::isBundledSeed),
            "order:all_music"
        )
    }
    val installedItems: List<BreakItem> get() = installedMediaDir.listFiles().orEmpty()
        .filter { it.isFile && (it.extension.lowercase(Locale.ROOT) in localPlayableExtensions || it.extension.equals("yt", true)) }
        .map { f -> BreakItem(DocumentFile.fromFile(f), f.nameWithoutExtension, f.extension.equals("yt", true)) }

    init {
        installBundledMedia()
        brakeMonsterDir.mkdirs(); ytDownloadsDir.mkdirs()
        refreshOwnedItems()
        manualLibraryItems = cachedItems("manual_library_cache")
        mediaStoreItems = cachedItems("media_store_cache")
        rebuildAllMusicCache()
        tracks = allMusicCache
        loadFactoryLibrary()
        BreakPlaybackService.onSingleTrackCompleted = { advanceQueue() }
        viewModelScope.launch {
            while (isActive) {
                syncServiceSnapshot()
                delay(150)
            }
        }
        // Do not auto-scan on startup. The first library scan must only start after
        // the user explicitly presses FIND YOUR MUSIC.
    }

    private fun loadFactoryLibrary() {
        viewModelScope.launch {
            val loaded = withContext(Dispatchers.IO) {
                val ordered = linkedMapOf<String, MutableList<BreakItem>>()
                factoryLibraryDir.mkdirs()
                getApplication<Application>().assets.open("factory_collection.zip").use { raw ->
                    ZipInputStream(raw).use { zip ->
                        while (true) {
                            val entry = zip.nextEntry ?: break
                            val name = entry.name.replace('\\', '/')
                            val parts = name.split('/').filter { it.isNotEmpty() }
                            if (!entry.isDirectory && parts.size == 2 && parts[1].endsWith(".yt", true)) {
                                val category = parts[0]
                                val target = File(factoryLibraryDir, "$category/${parts[1]}")
                                val canonicalRoot = factoryLibraryDir.canonicalFile
                                val canonicalTarget = target.canonicalFile
                                if (canonicalTarget.path.startsWith(canonicalRoot.path + File.separator)) {
                                    val bytes = zip.readBytes()
                                    val record = bytes.toString(Charsets.UTF_8).trim()
                                    if (isCanonicalYoutubeUrl(record)) {
                                        val sameAsFactory = target.isFile && runCatching { target.readBytes().contentEquals(bytes) }.getOrDefault(false)
                                        if (!sameAsFactory) {
                                            target.parentFile?.mkdirs()
                                            FileOutputStream(target).use { it.write(bytes) }
                                        }
                                        ordered.getOrPut(category) { mutableListOf() }.add(
                                            BreakItem(DocumentFile.fromFile(target), target.nameWithoutExtension, true)
                                        )
                                    }
                                }
                            }
                            zip.closeEntry()
                        }
                    }
                }
                ordered.mapValues { it.value.toList() }
            }
            factoryByCategory = loaded
            val originalOrder = loaded.keys.toList()
            val storedOrder = prefs.getString("factory_category_order", "").orEmpty().split("\n")
            factoryCategories = storedOrder.filter { it in loaded }.distinct() + originalOrder.filterNot { it in storedOrder }
            val saved = factoryPlaylistName.takeIf { it in loaded }
                ?: loaded.keys.firstOrNull().orEmpty()
            factoryPlaylistName = saved
            factoryItems = loaded[saved].orEmpty()
            if (saved.isNotBlank()) prefs.edit().putString("factory_playlist", saved).apply()
            factoryLibraryLoading = false
        }
    }

    fun moveFactoryCategory(from: Int, to: Int) {
        val old = factoryCategories
        if (from !in old.indices || to !in old.indices || from == to) return
        val updated = old.toMutableList()
        updated.add(to, updated.removeAt(from))
        factoryCategories = updated
        prefs.edit().putString("factory_category_order", updated.joinToString("\n")).apply()
    }

    fun selectFactoryPlaylist(name: String) {
        if (name !in factoryByCategory) return
        factoryPlaylistName = name
        factoryItems = factoryByCategory[name].orEmpty()
        prefs.edit().putString("factory_playlist", name).apply()
    }

    /** Remove only the three obsolete app-bundled starter files once; never touch user media. */
    private fun installBundledMedia() {
        if (prefs.getBoolean("starter_media_removed_58", false)) return
        runCatching {
            val obsolete = listOf(
                File(brakeMonsterDir, "BRAKE MONSTER WELCOME SONG.mp3"),
                File(ytDownloadsDir, "TERAPHONIA - TERAPHONIA DAD.yt"),
                File(ytDownloadsDir, "EDEN - TERAPHONIA DAD.yt")
            )
            obsolete.forEach { if (it.isFile) it.delete() }
            prefs.edit().putBoolean("starter_media_removed_58", true).apply()
        }
    }

    private fun loadPath(): List<String> = runCatching {
        val raw = prefs.getString("path", null) ?: return@runCatching emptyList<String>()
        val json = JSONArray(raw)
        (0 until json.length()).map { json.getString(it) }
    }.getOrDefault(emptyList<String>())

    private fun persistPath() {
        prefs.edit().putString("path", JSONArray(path).toString()).apply()
    }

    fun consumeMessage() { message = null }

    fun setRoot(uri: Uri) {
        rootUri = uri.toString()
        manualRootUris=(manualRootUris+uri.toString()).distinct()
        path = emptyList<String>()
        prefs.edit().putString("root", rootUri).putString("manual_roots",JSONArray(manualRootUris).toString()).putString("path", "[]").apply()
        refreshSerial++
    }

    fun home() {
        BlackBox.log("MODEL home pathDepth=${path.size}")
        if (path.isNotEmpty()) {
            path = emptyList<String>()
            persistPath()
        }
    }

    /** @return true when a folder level was consumed. */
    fun back(): Boolean {
        BlackBox.log("MODEL back pathDepth=${path.size}")
        if (path.isEmpty()) return false
        path = path.dropLast(1)
        persistPath()
        return true
    }

    fun openFolder(dir: DocumentFile) {
        BlackBox.log("MODEL openFolder ${dir.name}")
        val name = dir.name ?: return
        path = path + name
        persistPath()
    }

    /** Find an indexed SAF item in its granted tree and restore that exact folder. */
    fun navigateToLocalItem(item: BreakItem) {
        if (item.file.uri.scheme == "file" || item.file.uri.authority == "media") {
            home()
            refresh()
            return
        }
        val targetUri = item.file.uri.toString()
        viewModelScope.launch {
            val destination = withContext(Dispatchers.IO) {
                for (root in manualRootUris) {
                    val rootDoc = runCatching { DocumentFile.fromTreeUri(getApplication(), Uri.parse(root)) }.getOrNull() ?: continue
                    val visited = HashSet<String>()
                    fun find(dir: DocumentFile, depth: Int, names: List<String>): List<String>? {
                        if (depth > 12 || !visited.add(dir.uri.toString())) return null
                        for (child in runCatching { dir.listFiles().toList() }.getOrDefault(emptyList())) {
                            if (child.uri.toString() == targetUri) return names
                            if (child.isDirectory && !child.name.equals(".thumbnails", true)) {
                                find(child, depth + 1, names + child.name.orEmpty())?.let { return it }
                            }
                        }
                        return null
                    }
                    find(rootDoc, 0, emptyList())?.let { return@withContext root to it }
                }
                null
            }
            if (destination != null) {
                rootUri = destination.first
                path = destination.second
                prefs.edit().putString("root", rootUri).putString("path", JSONArray(path).toString()).apply()
            } else home()
            refresh()
        }
    }

    private fun resolveFolder(relative: List<String> = path): DocumentFile? {
        var dir = rootUri?.let { DocumentFile.fromTreeUri(getApplication(), Uri.parse(it)) } ?: return null
        for (name in relative) {
            if (name.equals(".thumbnails", true)) return null
            dir = dir.findFile(name)?.takeIf { it.isDirectory } ?: return null
        }
        return dir
    }

    fun refresh() {
        val bbStart=android.os.SystemClock.elapsedRealtime()
        BlackBox.log("REFRESH request root=${rootUri!=null} pathDepth=${path.size}")
        val target = rootUri ?: run {
            folders = emptyList<DocumentFile>(); tracks = allMusicItems; loading = false; return
        }
        viewModelScope.launch {
            loading = true
            error = null
            try {
                val result = withContext(Dispatchers.IO) {
                    var dir = DocumentFile.fromTreeUri(getApplication(), Uri.parse(target))
                        ?: kotlin.error("Missing root")
                    val resolved = mutableListOf<String>()
                    for (segment in path) {
                        if (segment.equals(".thumbnails", true)) break
                        val next = dir.findFile(segment)?.takeIf { it.isDirectory } ?: break
                        dir = next
                        resolved += segment
                    }
                    val children = dir.listFiles().toList()
                    val dirs = children.filter { it.isDirectory && !it.name.equals(".thumbnails", true) }
                        .sortedBy { it.name.orEmpty().lowercase(Locale.ROOT) }
                    val rawFiles = children.filter { file ->
                        file.isFile && (file.extensionLower() in localPlayableExtensions || file.extensionLower() == "yt")
                    }
                    val orderKey = "order:" + dir.uri.toString()
                    val savedOrder = prefs.getString(orderKey, null)?.let { raw ->
                        runCatching { JSONArray(raw) }.getOrNull()?.let { a -> (0 until a.length()).map { a.getString(it) } }
                    }.orEmpty()
                    val rank = savedOrder.withIndex().associate { it.value to it.index }
                    val files = rawFiles.sortedWith(compareBy<DocumentFile> { rank[it.uri.toString()] ?: Int.MAX_VALUE }.thenBy { it.name.orEmpty().lowercase(Locale.ROOT) })
                        .map { file ->
                            BreakItem(
                                file = file,
                                name = file.name.orEmpty().substringBeforeLast('.', file.name.orEmpty()),
                                isYoutube = file.extensionLower() == "yt"
                            )
                        }
                    val recursiveManual=if(resolved.isEmpty()) manualRootUris.flatMap { root ->
                        runCatching { scanManualTree(Uri.parse(root)) }.getOrDefault(emptyList())
                    } else emptyList()
                    if(resolved.isEmpty()) {
                manualLibraryItems = recursiveManual
                rebuildAllMusicCache()
                saveItemCache("manual_library_cache",recursiveManual)
            }
                    val combined = if (resolved.isEmpty()) applySavedOrder(dedupeMedia(mediaStoreItems + recursiveManual + files), "order:all_music") else files
                    Triple(resolved.toList(), dirs, combined)
                }
                val (resolved, dirs, files) = result
                if (resolved != path) {
                    path = resolved
                    persistPath()
                }
                folders = dirs
                tracks = files
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                error = "Folder nije dostupan. Dodirni folder gore desno i izaberi ga ponovo."
            } finally {
                loading = false
            }
        }
    }

    private fun scanManualTree(root:Uri):List<BreakItem> {
        val context=getApplication<Application>()
        val result=mutableListOf<BreakItem>()
        val visited=HashSet<String>()
        fun visit(dir:DocumentFile,depth:Int){
            if(depth>12 || !visited.add(dir.uri.toString())) return
            dir.listFiles().forEach { child ->
                if(child.isDirectory){ if(!child.name.equals(".thumbnails",true)) visit(child,depth+1) }
                else if(child.isFile && (child.extensionLower() in localPlayableExtensions || child.extensionLower()=="yt")) {
                    result.add(BreakItem(child,child.name.orEmpty().substringBeforeLast('.',child.name.orEmpty()),child.extensionLower()=="yt"))
                }
            }
        }
        DocumentFile.fromTreeUri(context,root)?.let { visit(it,0) }
        return result
    }

    private fun scanOwnedDir(dir: File, includeYt: Boolean): List<BreakItem> = runCatching {
        if (!dir.exists()) return@runCatching emptyList()
        dir.walkTopDown().filter { f -> f.isFile && (f.extension.lowercase(Locale.ROOT) in localPlayableExtensions || (includeYt && f.extension.equals("yt", true))) }
            .map { f -> BreakItem(DocumentFile.fromFile(f), f.nameWithoutExtension, f.extension.equals("yt", true)) }.toList()
    }.getOrDefault(emptyList())

    private fun refreshOwnedItems() { ownedMediaItems=scanOwnedDir(brakeMonsterDir, true) }

    fun importName(uri: Uri): String = runCatching {
        getApplication<Application>().contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Imported media"

    fun importedNameExists(name: String): Boolean {
        val ext=name.substringAfterLast('.',"").lowercase(Locale.ROOT)
        val dir=if(ext=="yt") ytDownloadsDir else brakeMonsterDir
        return dir.listFiles().orEmpty().any { it.name.equals(name,true) }
    }

    /** Copy a picker-selected document into app-owned storage; the original URI is read only. */
    fun copyImport(uri: Uri, choice: String) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val context = getApplication<Application>()
                    brakeMonsterDir.mkdirs(); ytDownloadsDir.mkdirs()
                    val sourceName = sanitizeFileName(importName(uri)).ifBlank { "Imported media" }
                    val ext = sourceName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                    if (ext !in localPlayableExtensions && ext !in importSidecarExtensions) return@runCatching false
                    val dir = if (ext == "yt") ytDownloadsDir else brakeMonsterDir
                    val existing=dir.listFiles().orEmpty().firstOrNull { it.name.equals(sourceName,true) }
                    var target = File(dir, sourceName)
                    if (existing!=null) {
                        when (choice) {
                            "replace" -> target=existing
                            "keep" -> { val base = sourceName.substringBeforeLast('.', sourceName); val suffix = sourceName.substringAfterLast('.', "").let { if (it.isBlank()) "" else ".$it" }; var n=2; while (dir.listFiles().orEmpty().any { it.name.equals("$base ($n)$suffix",true) }) n++; target=File(dir,"$base ($n)$suffix") }
                            else -> return@runCatching false
                        }
                    }
                    context.contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use { output -> input.copyTo(output) } } ?: return@runCatching false
                    true
                }.getOrDefault(false)
            }
            if (result) { refreshOwnedItems(); message = "IMPORTED"; refreshSerial++ } else message = "Import was cancelled or could not be copied."
        }
    }

    private fun cachedItems(key:String):List<BreakItem> = runCatching {
        val a=JSONArray(prefs.getString(key,"[]"));(0 until a.length()).mapNotNull { i ->
            val o=a.getJSONObject(i);val uri=Uri.parse(o.getString("uri"));
            val doc=if(uri.scheme=="file") DocumentFile.fromFile(File(uri.path.orEmpty())) else DocumentFile.fromSingleUri(getApplication(),uri)
            doc?.let {
                // Do NOT use it.name as optString's default: Kotlin evaluates that default
                // eagerly, causing a ContentResolver query for every cached MediaStore row.
                val cachedName = o.optString("name").takeIf { n -> n.isNotBlank() }
                    ?: uri.lastPathSegment.orEmpty()
                BreakItem(it,cachedName,o.optBoolean("yt",false))
            }
        }
    }.getOrDefault(emptyList())

    private fun saveItemCache(key:String,items:List<BreakItem>) {
        val a=JSONArray();items.forEach { a.put(org.json.JSONObject().put("uri",it.file.uri.toString()).put("name",it.name).put("yt",it.isYoutube)) }
        prefs.edit().putString(key,a.toString()).apply()
    }

    private fun isBundledSeed(item: BreakItem): Boolean {
        // item.name is cached metadata. DocumentFile.name can hit ContentResolver and must
        // never be used from this Compose-facing filter.
        val n = item.name.trim()
        return n.equals("BRAKE MONSTER WELCOME SONG.mp3", true) ||
            n.equals("BRAKE MONSTER WELCOME SONG", true) ||
            n.equals("BRAKE MONSTER.mp3", true) ||
            n.equals("TERAPHONIA - TERAPHONIA DAD.yt", true) ||
            n.equals("TERAPHONIA - TERAPHONIA DAD", true) ||
            n.equals("EDEN - TERAPHONIA DAD.yt", true) ||
            n.equals("EDEN - TERAPHONIA DAD", true)
    }

    private fun dedupeMedia(items:List<BreakItem>):List<BreakItem> {
        // IMPORTANT: never call DocumentFile.length()/name here. For MediaStore URIs those
        // methods perform ContentResolver I/O; this function is also used by Compose-facing
        // getters and previously caused seconds of main-thread blocking for ~1000 songs.
        val seenUris=HashSet<String>()
        return items.filter { item -> seenUris.add(item.file.uri.toString()) }
    }

    private fun applySavedOrder(items:List<BreakItem>, key:String):List<BreakItem> {
        val saved=runCatching { JSONArray(prefs.getString(key,"[]")) }.getOrNull()?.let { a -> (0 until a.length()).map { a.getString(it) } }.orEmpty()
        if(saved.isEmpty()) return items
        val rank=saved.withIndex().associate { it.value to it.index }
        return items.sortedWith(compareBy<BreakItem> { rank[it.file.uri.toString()] ?: Int.MAX_VALUE }.thenBy { it.name.lowercase(Locale.ROOT) })
    }

    fun moveTrack(from: Int, to: Int) {
        if (from !in tracks.indices || to !in tracks.indices || from == to) return
        val m = tracks.toMutableList()
        val item = m.removeAt(from)
        m.add(to, item)
        tracks = m
        val orderKey = if(path.isEmpty()) "order:all_music" else "order:" + (resolveFolder()?.uri?.toString() ?: return)
        prefs.edit().putString(orderKey, JSONArray(m.map { it.file.uri.toString() }).toString()).apply()
    }

    fun saveFolderChildren(relative: List<String>): List<DocumentFile> = runCatching {
        resolveFolder(relative)?.listFiles()?.filter { it.isDirectory && !it.name.equals(".thumbnails", true) }
            ?.sortedBy { it.name.orEmpty().lowercase(Locale.ROOT) }.orEmpty()
    }.getOrDefault(emptyList())

    /** Save a concrete .yt file inside the selected user's physical playlist directory. */
    fun saveYoutubeToPlaylist(playlistIndex: Int, onSaved: (String, String, Boolean) -> Boolean) {
        val rawUrl = youtubeUrl ?: run { message = "Prvo pusti YouTube video."; return }
        val title = youtubeTitle.orEmpty()
        val app = getApplication<Application>()
        val versionInfo = runCatching {
            val info = app.packageManager.getPackageInfo(app.packageName, 0)
            @Suppress("DEPRECATION")
            val code = if (android.os.Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
            "versionName=${info.versionName ?: "unknown"} versionCode=$code"
        }.getOrDefault("versionName=unknown versionCode=unknown")
        var stage = "URL_VALIDATION"
        BlackBox.log("SAVE YT BEGIN $versionInfo playlist=$playlistIndex")
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    stage = "FILE_CREATION"
                    persistYoutubePlaylistFile(playlistIndex, title, rawUrl)
                }
            }
            result.fold(onSuccess = { (name, uri) ->
                try {
                    stage = "PLAYLIST_PERSISTENCE"
                    BlackBox.log("SAVE YT STAGE=$stage name=$name playlist=$playlistIndex")
                    check(onSaved(name, uri, true)) { "Playlist entry could not be persisted" }
                    stage = "BROWSER_REFRESH"
                    refreshSerial++
                    youtubeSaved = true
                    youtubeCanSave = false
                    message = "YT LINK SAVED: $name"
                    BlackBox.log("SAVE YT SUCCESS $versionInfo stage=$stage playlist=$playlistIndex name=$name")
                } catch (e: Throwable) {
                    logSaveYoutubeFailure(versionInfo, stage, playlistIndex, e)
                    message = "SAVE FAILED: ${e.message ?: e.javaClass.simpleName}"
                }
            }, onFailure = { e ->
                logSaveYoutubeFailure(versionInfo, stage, playlistIndex, e)
                message = "SAVE FAILED: ${e.message ?: e.javaClass.simpleName}"
            })
        }
    }

    /** ZIP imports share the exact durable file and playlist entry path used by SAVE YT. */
    fun importYoutubeLinksToPlaylist(
        playlistIndex: Int,
        links: List<Pair<String, String>>,
        onSaved: (String, String, Boolean) -> Boolean,
        onComplete: (added: Int, skipped: Int) -> Unit
    ) {
        viewModelScope.launch {
            val saved = withContext(Dispatchers.IO) {
                links.map { (title, url) -> runCatching { persistYoutubePlaylistFile(playlistIndex, title, url) } }
            }
            var added = 0
            var skipped = 0
            saved.forEach { result ->
                result.fold(
                    onSuccess = { (name, uri) ->
                        if (runCatching { onSaved(name, uri, true) }.getOrDefault(false)) added++ else skipped++
                    },
                    onFailure = { skipped++ }
                )
            }
            refreshSerial++
            onComplete(added, skipped)
        }
    }

    /** The single writer for both YouTube Search saves and imported .yt links. */
    private fun persistYoutubePlaylistFile(playlistIndex: Int, title: String, rawUrl: String): Pair<String, String> {
        val videoId = extractYoutubeVideoId(rawUrl) ?: error("Invalid YouTube video URL")
        val canonicalUrl = "https://www.youtube.com/watch?v=$videoId"
        val base = sanitizeYoutubeFileName(cleanYoutubeTitle(title)).ifBlank { "YouTube" }
        val dir = File(getApplication<Application>().filesDir, "user_playlists/$playlistIndex")
        check(dir.isDirectory || dir.mkdirs()) { "Cannot create playlist folder" }
        var finalName = base
        var file = File(dir, "$finalName.yt")
        var duplicate = 1
        while (file.exists() && file.readText(Charsets.UTF_8).trim() != canonicalUrl) {
            duplicate++
            check(duplicate < 10000) { "Too many duplicate YouTube filenames" }
            val suffix = " ($duplicate)"
            val maxBase = (120 - suffix.length).coerceAtLeast(1)
            finalName = takeFilenameChars(base, maxBase).trimEnd(' ', '.', '-', '_') + suffix
            file = File(dir, "$finalName.yt")
        }
        if (!file.exists()) {
            val temp = File.createTempFile("saveyt_", ".tmp", dir)
            try {
                temp.writeText(canonicalUrl, Charsets.UTF_8)
                check(temp.renameTo(file)) { "Could not finalize YouTube link file" }
            } finally {
                if (temp.exists()) temp.delete()
            }
        }
        check(file.isFile && file.readText(Charsets.UTF_8).trim() == canonicalUrl) { "Saved .yt file verification failed" }
        return finalName to Uri.fromFile(file).toString()
    }

    private fun logSaveYoutubeFailure(version: String, stage: String, playlistIndex: Int, error: Throwable) {
        BlackBox.log("SAVE YT FAILED $version stage=$stage playlist=$playlistIndex exception=${error.javaClass.name}: ${error.message}\n${android.util.Log.getStackTraceString(error)}")
    }

    fun startPlaylist(items: List<BreakItem>, startIndex: Int) {
        if (items.isEmpty() || startIndex !in items.indices) return
        val first=items[startIndex]
        val rest=items.filterIndexed { index, _ -> index!=startIndex }
        playbackQueue = listOf(first) + if(random) rest.shuffled() else rest
        playbackQueueIndex = 0
        startQueueItem()
    }

    /** Search all loaded factory categories without switching the visible category. */
    fun findFactorySongs(query: String): List<Pair<String, List<BreakItem>>> =
        factoryByCategory.mapNotNull { (category, items) ->
            val matches = items.filter { it.name.contains(query, ignoreCase = true) }
            matches.takeIf { it.isNotEmpty() }?.let { category to it }
        }

    fun factoryItemsForSearch(category: String): List<BreakItem> = factoryByCategory[category].orEmpty()

    fun startLocal(selected: BreakItem) {
        // Global search may select a file outside the currently open folder.
        // Always include the selected file in the playback queue; otherwise
        // the old implementation silently returned or played a different item.
        val current = tracks.filter { it.isYoutube || it.file.extensionLower() in localPlayableExtensions }
        val global = allMusicItems.filter { it.isYoutube || it.file.extensionLower() in localPlayableExtensions }
        val playable = when {
            current.any { it.file.uri == selected.file.uri } -> current
            global.any { it.file.uri == selected.file.uri } -> global
            else -> listOf(selected)
        }
        val selectedIndex = playable.indexOfFirst { it.file.uri == selected.file.uri }
        if (selectedIndex < 0) return
        val rest = playable.filterIndexed { index, _ -> index != selectedIndex }
        playbackQueue = listOf(playable[selectedIndex]) + if (random) rest.shuffled() else rest
        playbackQueueIndex = 0
        startQueueItem()
    }

    private fun startQueueItem() {
        val item = playbackQueue.getOrNull(playbackQueueIndex) ?: return
        activePlaybackItemUri = item.file.uri.toString()
        if (item.isYoutube) {
            stopLocal()
            clearYoutube()
            openSavedYoutubeForQueue(item)
            return
        }
        clearYoutube()
        val request = BreakPlaybackService.StartRequest(
            files = listOf(BreakPlaybackService.Entry(item.file.uri.toString(), item.file.name ?: item.name)),
            selectedUri = item.file.uri.toString(),
            random = false,
            repeat = false,
            volume = 1f
        )
        BreakPlaybackService.start(getApplication(), request)
    }

    fun toggleLocalPause() = BreakPlaybackService.togglePause()
    fun nextLocal() {
        if (playbackQueue.isNotEmpty()) {
            stopLocal()
            advanceQueue()
        } else BreakPlaybackService.next()
    }
    fun seekLocal(value: Int) = BreakPlaybackService.seekTo(value)
    fun stopLocal() = BreakPlaybackService.stop(getApplication())

    fun updateRandom(value: Boolean) {
        random = value
        prefs.edit().putBoolean("random", value).apply()
        BreakPlaybackService.setRandom(value)
    }

    fun updateRepeat(value: Boolean) {
        repeat = value
        prefs.edit().putBoolean("repeat", value).apply()
        BreakPlaybackService.setRepeat(value)
    }

    fun selectYoutube(videoId: String, title: String?, sourceUrl: String? = null) {
        activePlaybackItemUri = null
        stopLocal()
        playbackQueue = emptyList()
        playbackQueueIndex = -1
        youtubeVideoId = videoId
        youtubeUrl = sourceUrl?.takeIf { it.isNotBlank() } ?: "https://www.youtube.com/watch?v=$videoId"
        youtubeTitle = title?.trim()?.takeIf { it.isNotBlank() } ?: "YouTube"
        youtubeCurrentSecond = 0f
        youtubeDurationSecond = 0f
        youtubePlaying = false
        youtubeSaved = false
        youtubeCanSave = true
        youtubeSession++
    }

    fun openSavedYoutube(item: BreakItem) {
        if (!item.isYoutube) return
        val current = tracks.filter { it.isYoutube || it.file.extensionLower() in localPlayableExtensions }
        val playable = if(current.any { it.file.uri==item.file.uri }) current else allMusicItems.filter { it.isYoutube || it.file.extensionLower() in localPlayableExtensions }
        val selectedIndex = playable.indexOfFirst { it.file.uri == item.file.uri }
        if (selectedIndex >= 0) {
            val rest = playable.filterIndexed { index, _ -> index != selectedIndex }
            playbackQueue = listOf(playable[selectedIndex]) + if (random) rest.shuffled() else rest
            playbackQueueIndex = 0
        }
        stopLocal()
        clearYoutube()
        openSavedYoutubeForQueue(item)
    }

    private fun openSavedYoutubeForQueue(item: BreakItem) {
        viewModelScope.launch {
            val link = withContext(Dispatchers.IO) {
                runCatching {
                    if(item.file.uri.scheme=="file") File(item.file.uri.path.orEmpty()).takeIf { it.isFile }?.readText()?.trim()
                    else getApplication<Application>().contentResolver.openInputStream(item.file.uri)?.bufferedReader()?.use { it.readText().trim() }
                }.getOrNull()
            }
            val id = extractYoutubeVideoId(link)
            if (id == null) {
                message = "Sačuvani YT link nije dostupan."
            } else {
                youtubeVideoId = id
                youtubeUrl = link
                youtubeTitle = item.name
                youtubeCurrentSecond = 0f
                youtubeDurationSecond = 0f
                youtubePlaying = false
                youtubeSaved = true
                youtubeCanSave = false
                youtubeSession++
            }
        }
    }

    fun clearYoutube() {
        youtubeVideoId = null
        youtubeUrl = null
        youtubeTitle = null
        youtubePlaying = false
        youtubeCurrentSecond = 0f
        youtubeDurationSecond = 0f
        youtubeSaved = false
        youtubeCanSave = false
    }

    fun onYoutubePlaying(value: Boolean) { youtubePlaying = value }
    fun onYoutubeCurrentSecond(value: Float) { youtubeCurrentSecond = value.coerceAtLeast(0f) }
    fun onYoutubeDuration(value: Float) { youtubeDurationSecond = value.coerceAtLeast(0f) }

    fun onYoutubeEnded() {
        if (youtubeCanSave && playbackQueue.isEmpty()) return
        clearYoutube()
        advanceQueue()
    }

    fun stopPlayback() {
        playbackQueue = emptyList()
        playbackQueueIndex = -1
        activePlaybackItemUri = null
        stopLocal()
        clearYoutube()
    }

    override fun onCleared() {
        BreakPlaybackService.onSingleTrackCompleted = null
        super.onCleared()
    }

    private fun advanceQueue() {
        if (playbackQueue.isEmpty()) return
        val next = playbackQueueIndex + 1
        if (next < playbackQueue.size) {
            playbackQueueIndex = next
            startQueueItem()
        } else if (repeat && playbackQueue.isNotEmpty()) {
            playbackQueueIndex = 0
            startQueueItem()
        } else {
            playbackQueue = emptyList()
            playbackQueueIndex = -1
            activePlaybackItemUri = null
            clearYoutube()
            stopLocal()
        }
    }

    fun rename(item: BreakItem, newBaseName: String) {
        val clean = sanitizeFileName(newBaseName).trim()
        if (clean.isBlank()) { message = "Ime ne može biti prazno."; return }
        val ext = item.file.name.orEmpty().substringAfterLast('.', "")
        val wanted = if (ext.isBlank()) clean else "$clean.$ext"
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching { item.file.renameTo(wanted) }.getOrDefault(false) }
            if (!ok) message = "Rename nije uspio."
            refreshOwnedItems(); refreshSerial++
        }
    }

    fun delete(item: BreakItem, onSuccess: (() -> Unit)? = null) {
        if (localTrackUri == item.file.uri.toString()) stopLocal()
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching {
                if(item.file.uri.authority=="media") getApplication<Application>().contentResolver.delete(item.file.uri,null,null)>0
                else item.file.delete()
            }.getOrDefault(false) }
            if (!ok) message = "Delete nije uspio."
            else onSuccess?.invoke()
            refreshOwnedItems()
            refreshSerial++
        }
    }

    fun onMediaStoreDeleteApproved(item:BreakItem){
        val uri=item.file.uri.toString()
        if(localTrackUri==uri) stopLocal()
        mediaStoreItems=mediaStoreItems.filterNot { it.file.uri.toString()==uri }
        manualLibraryItems=manualLibraryItems.filterNot { it.file.uri.toString()==uri }
        rebuildAllMusicCache()
        tracks=tracks.filterNot { it.file.uri.toString()==uri }
        saveItemCache("media_store_cache",mediaStoreItems)
        saveItemCache("manual_library_cache",manualLibraryItems)
        refreshSerial++
    }

    fun findInstalledWelcome():BreakItem? = scanOwnedDir(brakeMonsterDir, true).firstOrNull { it.file.name.equals("BRAKE MONSTER WELCOME SONG.mp3",true) }

    fun bundledP1Items(): List<BreakItem> = scanOwnedDir(brakeMonsterDir, true).filter { item ->
        item.file.name.equals("BRAKE MONSTER WELCOME SONG.mp3",true) ||
        item.file.name.equals("TERAPHONIA - TERAPHONIA DAD.yt",true) ||
        item.file.name.equals("EDEN - TERAPHONIA DAD.yt",true)
    }.sortedBy { if(it.file.name.equals("BRAKE MONSTER WELCOME SONG.mp3",true)) 0 else 1 }

    fun scanMediaStore(showResult:Boolean=true) {
        if(mediaScanInProgress) { BlackBox.log("MEDIA SCAN ignored already running"); return }
        val bbScanStart=android.os.SystemClock.elapsedRealtime()
        mediaScanInProgress=true
        viewModelScope.launch {
            BlackBox.log("MEDIA SCAN DISPATCH -> IO")
            val scanResult=withContext(Dispatchers.IO) {
                val ioStart=android.os.SystemClock.elapsedRealtime()
                BlackBox.log("MEDIA SCAN IO START")
                val resolver=getApplication<Application>().contentResolver
                val collection=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                val columns=arrayOf(MediaStore.Audio.Media._ID,MediaStore.Audio.Media.DISPLAY_NAME,MediaStore.Audio.Media.TITLE)
                val out=mutableListOf<BreakItem>()
                runCatching {
                    resolver.query(collection,columns,"${MediaStore.Audio.Media.IS_MUSIC} != 0",null,"${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
                        val idCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                        val nameCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                        val titleCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                        while(c.moveToNext()) {
                            val uri=ContentUris.withAppendedId(collection,c.getLong(idCol))
                            val rawName=c.getString(nameCol).orEmpty()
                            val display=c.getString(titleCol)?.takeIf{it.isNotBlank()} ?: rawName.substringBeforeLast('.')
                            // Filter seed files from cursor metadata while still on IO. Do not
                            // ask DocumentFile for name/length later on the main thread.
                            val n=rawName.ifBlank { display }
                            val seed=n.equals("BRAKE MONSTER WELCOME SONG.mp3",true) ||
                                n.equals("BRAKE MONSTER WELCOME SONG",true) || n.equals("BRAKE MONSTER.mp3",true) ||
                                n.equals("TERAPHONIA - TERAPHONIA DAD.yt",true) || n.equals("TERAPHONIA - TERAPHONIA DAD",true) ||
                                n.equals("EDEN - TERAPHONIA DAD.yt",true) || n.equals("EDEN - TERAPHONIA DAD",true)
                            if(!seed) {
                                val file=DocumentFile.fromSingleUri(getApplication(),uri) ?: continue
                                out.add(BreakItem(file,display,false))
                            }
                        }
                    }
                }
                val cached=JSONArray()
                out.forEach { cached.put(org.json.JSONObject().put("uri",it.file.uri.toString()).put("name",it.name)) }
                BlackBox.log("MEDIA SCAN IO END ${android.os.SystemClock.elapsedRealtime()-ioStart}ms items=${out.size}")
                Pair(out,cached.toString())
            }
            // Main thread now only swaps already-built in-memory state; no provider calls.
            val (found,cacheJson)=scanResult
            mediaStoreItems=found
            rebuildAllMusicCache()
            tracks=allMusicCache
            mediaScanComplete=true
            prefs.edit().putBoolean("media_scan_complete",true).putBoolean("first_user_scan_complete_v25",true).putString("media_store_cache",cacheJson).apply()
            if(showResult) message="${found.size} SONGS FOUND"
            refreshSerial++
            mediaScanInProgress=false
            BlackBox.log("MEDIA SCAN COMPLETE ${android.os.SystemClock.elapsedRealtime()-bbScanStart}ms items=${found.size}")
        }
    }

    private fun syncServiceSnapshot() {
        val s = BreakPlaybackService.snapshot
        localTrackUri = s.trackUri
        localTrackName = s.trackName
        localPreparing = s.preparing
        localPlaying = s.playing
        localPosition = s.position
        localDuration = s.duration
        if (random != s.random && s.sessionActive) random = s.random
        if (repeat != s.repeat && s.sessionActive) repeat = s.repeat
    }

    /** Safe filename normalization for imported files and Rename; no regex involved. */
    private fun sanitizeFileName(value: String): String {
        val cleaned = StringBuilder(value.length.coerceAtMost(180))
        for (char in value) {
            when {
                char.code < 32 || char.code == 127 || char in "\\/:*?\"<>|" -> cleaned.append('-')
                else -> cleaned.append(char)
            }
        }
        return cleaned.toString().trim().trim('.').take(180).trimEnd(' ', '.')
    }

    companion object {
        private fun isCanonicalYoutubeUrl(value: String): Boolean {
            val prefix = "https://www.youtube.com/watch?v="
            if (!value.startsWith(prefix)) return false
            val id = value.substring(prefix.length)
            return id.length == 11 && id.all { it in 'A'..'Z' || it in 'a'..'z' || it in '0'..'9' || it == '_' || it == '-' }
        }

        /** CdgLite SAVE HERE filename rules, adapted to BrakeMonster internal playlists.
         * No Regex/Pattern compilation on the SAVE YT path.
         */
        /** Strip trailing YouTube time badges, not numbers within real song titles. */
        fun cleanYoutubeTitle(value:String):String {
            var title=value.trim()
            // Entire title is a duration: do not turn the duration into a song name.
            fun isDuration(v:String):Boolean {
                val pieces=v.trim().split(':')
                return pieces.size in 2..3 && pieces.all{it.length in 1..2 && it.all(Char::isDigit)}
            }
            if(isDuration(title))return "YouTube karaoke"
            val parts=title.split(' ')
            if(parts.isNotEmpty() && isDuration(parts.last())) title=parts.dropLast(1).joinToString(" ").trimEnd(' ','-','|','•')
            if(title.isBlank())return "YouTube karaoke"
            return title
        }

        fun sanitizeYoutubeFileName(value: String): String {
            val normalized = StringBuilder(value.length.coerceAtMost(120))
            var pendingSpace = false
            for (char in value) {
                if (char.isWhitespace()) {
                    pendingSpace = normalized.isNotEmpty()
                    continue
                }
                if (pendingSpace && normalized.isNotEmpty()) normalized.append(' ')
                pendingSpace = false
                normalized.append(if (char in "\\/:*?\"<>|" || char.code < 32 || char.code == 127) '-' else char)
            }
            return takeFilenameChars(normalized.toString().trim().trim('.'), 120)
                .trimEnd(' ', '.')
                .ifBlank { "YouTube karaoke" }
        }

        private fun takeFilenameChars(value: String, limit: Int): String {
            val result = StringBuilder(minOf(value.length, limit))
            var offset = 0
            var used = 0
            while (offset < value.length) {
                val codePoint = value.codePointAt(offset)
                val units = Character.charCount(codePoint)
                if (used + units > limit) break
                result.appendCodePoint(codePoint)
                offset += units
                used += units
            }
            return result.toString()
        }

        fun extractYoutubeVideoId(raw: String?): String? {
            if (raw.isNullOrBlank()) return null
            return runCatching {
                val uri = Uri.parse(raw.trim())
                val host = uri.host?.lowercase(Locale.ROOT).orEmpty().removePrefix("www.").removePrefix("m.")
                val id = when {
                    host == "youtu.be" -> uri.pathSegments.firstOrNull()
                    host == "youtube.com" || host.endsWith(".youtube.com") -> when {
                        uri.path == "/watch" -> uri.getQueryParameter("v")
                        uri.pathSegments.firstOrNull() == "shorts" -> uri.pathSegments.getOrNull(1)
                        uri.pathSegments.firstOrNull() == "live" -> uri.pathSegments.getOrNull(1)
                        uri.pathSegments.firstOrNull() == "embed" -> uri.pathSegments.getOrNull(1)
                        else -> null
                    }
                    else -> null
                }
                id?.takeIf { it.length in 6..20 && it.all { char -> char in 'A'..'Z' || char in 'a'..'z' || char in '0'..'9' || char == '_' || char == '-' } }
            }.getOrNull()
        }
    }
}
