package com.teraphonia.breakmonster

import android.app.Application
import android.content.ContentUris
import android.provider.MediaStore
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.util.Locale

internal data class BreakItem(
    val file: DocumentFile,
    val name: String,
    val isYoutube: Boolean
)

internal val localPlayableExtensions = setOf(
    "mp3", "wav", "wave", "m4a", "aac", "flac", "ogg", "opus", "amr",
    "mp4", "m4v", "mov", "3gp", "3g2", "mkv", "webm", "avi", "ts", "m2ts", "mpeg", "mpg"
)

internal fun DocumentFile.extensionLower(): String =
    name.orEmpty().substringAfterLast('.', "").lowercase(Locale.ROOT)

internal class BreakMonsterModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("breakmonster", 0)

    var rootUri by mutableStateOf(prefs.getString("root", null))
        private set

    private var manualRootUris:List<String> = runCatching {
        val raw=prefs.getString("manual_roots",null)
        val saved=if(raw==null) emptyList() else { val a=JSONArray(raw);(0 until a.length()).map{a.getString(it)} }
        (saved + listOfNotNull(rootUri)).distinct()
    }.getOrDefault(listOfNotNull(rootUri))

    var path by mutableStateOf(loadPath())
        private set

    var folders by mutableStateOf<List<DocumentFile>>(emptyList())
        private set
    var tracks by mutableStateOf<List<BreakItem>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    var mediaScanComplete by mutableStateOf(prefs.getBoolean("media_scan_complete",false))
        private set
    var error by mutableStateOf<String?>(null)
        private set

    var random by mutableStateOf(prefs.getBoolean("random", false))
        private set
    var repeat by mutableStateOf(prefs.getBoolean("repeat", false))
        private set

    var localTrackUri by mutableStateOf<String?>(null)
        private set
    var localTrackName by mutableStateOf<String?>(null)
        private set
    var localPreparing by mutableStateOf(false)
        private set
    var localPlaying by mutableStateOf(false)
        private set
    var localPosition by mutableIntStateOf(0)
        private set
    var localDuration by mutableIntStateOf(0)
        private set

    var youtubeVideoId by mutableStateOf<String?>(null)
        private set
    var youtubeUrl by mutableStateOf<String?>(null)
        private set
    var youtubeTitle by mutableStateOf<String?>(null)
        private set
    var youtubeSession by mutableIntStateOf(0)
        private set
    var youtubePlaying by mutableStateOf(false)
        private set
    var youtubeCurrentSecond by mutableStateOf(0f)
        private set
    var youtubeDurationSecond by mutableStateOf(0f)
        private set
    var youtubeSaved by mutableStateOf(false)
        private set
    var youtubeCanSave by mutableStateOf(false)
        private set

    private var playbackQueue: List<BreakItem> = emptyList()
    private var playbackQueueIndex = -1

    var refreshSerial by mutableIntStateOf(0)
        private set

    var message by mutableStateOf<String?>(null)
        private set

    private val installedMediaDir = File(app.filesDir, "installed_media")
    val installedItems: List<BreakItem> get() = installedMediaDir.listFiles().orEmpty()
        .filter { it.isFile && (it.extension.lowercase(Locale.ROOT) in localPlayableExtensions || it.extension.equals("yt", true)) }
        .map { f -> BreakItem(DocumentFile.fromFile(f), f.nameWithoutExtension, f.extension.equals("yt", true)) }

    init {
        installBundledMedia()
        tracks = dedupeMedia(installedItems + cachedItems("manual_library_cache") + cachedItems("media_store_cache"))
        BreakPlaybackService.onSingleTrackCompleted = { advanceQueue() }
        viewModelScope.launch {
            while (isActive) {
                syncServiceSnapshot()
                delay(150)
            }
        }
        val permission=if(android.os.Build.VERSION.SDK_INT>=33) android.Manifest.permission.READ_MEDIA_AUDIO else android.Manifest.permission.READ_EXTERNAL_STORAGE
        if(app.checkSelfPermission(permission)==android.content.pm.PackageManager.PERMISSION_GRANTED) scanMediaStore(showResult=false)
    }

    /** Copies the bundled song and attached saved YouTube links once into app-private storage. */
    private fun installBundledMedia() {
        runCatching {
            if(prefs.getBoolean("installed_media_seeded",false)) return@runCatching
            installedMediaDir.mkdirs()
            val context=getApplication<Application>()
            val media=listOf(
                "BRAKE MONSTER.mp3" to "BRAKE MONSTER WELCOME SONG.mp3",
                "TERAPHONIA - TERAPHONIA DAD.yt" to "TERAPHONIA - TERAPHONIA DAD.yt",
                "EDEN - TERAPHONIA DAD.yt" to "EDEN - TERAPHONIA DAD.yt"
            )
            media.forEach { (asset,targetName) ->
                val target=File(installedMediaDir,targetName)
                if(!target.exists() || target.length()==0L) context.assets.open(asset).use { input -> target.outputStream().use { input.copyTo(it) } }
            }
            if(File(installedMediaDir,"BRAKE MONSTER WELCOME SONG.mp3").length()>0L && media.all { File(installedMediaDir,it.second).length()>0L }) prefs.edit().putBoolean("installed_media_seeded",true).apply()
        }
    }

    private fun loadPath(): List<String> = runCatching {
        val raw = prefs.getString("path", null) ?: return@runCatching emptyList<String>()
        val json = JSONArray(raw)
        (0 until json.length()).map { json.getString(it) }
    }.getOrDefault(emptyList<String>())

    private fun persistPath() {
        prefs.edit().putString("path", JSONArray(path).toString()).apply()
    }

    fun consumeMessage() { message = null }

    fun setRoot(uri: Uri) {
        rootUri = uri.toString()
        manualRootUris=(manualRootUris+uri.toString()).distinct()
        path = emptyList<String>()
        prefs.edit().putString("root", rootUri).putString("manual_roots",JSONArray(manualRootUris).toString()).putString("path", "[]").apply()
        refreshSerial++
    }

    fun home() {
        if (path.isNotEmpty()) {
            path = emptyList<String>()
            persistPath()
        }
    }

    /** @return true when a folder level was consumed. */
    fun back(): Boolean {
        if (path.isEmpty()) return false
        path = path.dropLast(1)
        persistPath()
        return true
    }

    fun openFolder(dir: DocumentFile) {
        val name = dir.name ?: return
        path = path + name
        persistPath()
    }

    private fun resolveFolder(relative: List<String> = path): DocumentFile? {
        var dir = rootUri?.let { DocumentFile.fromTreeUri(getApplication(), Uri.parse(it)) } ?: return null
        for (name in relative) {
            if (name.equals(".thumbnails", true)) return null
            dir = dir.findFile(name)?.takeIf { it.isDirectory } ?: return null
        }
        return dir
    }

    fun refresh() {
        val target = rootUri ?: run {
            folders = emptyList<DocumentFile>(); tracks = dedupeMedia(installedItems + mediaStoreItems); loading = false; return
        }
        viewModelScope.launch {
            loading = true
            error = null
            try {
                val result = withContext(Dispatchers.IO) {
                    var dir = DocumentFile.fromTreeUri(getApplication(), Uri.parse(target))
                        ?: kotlin.error("Missing root")
                    val resolved = mutableListOf<String>()
                    for (segment in path) {
                        if (segment.equals(".thumbnails", true)) break
                        val next = dir.findFile(segment)?.takeIf { it.isDirectory } ?: break
                        dir = next
                        resolved += segment
                    }
                    val children = dir.listFiles().toList()
                    val dirs = children.filter { it.isDirectory && !it.name.equals(".thumbnails", true) }
                        .sortedBy { it.name.orEmpty().lowercase(Locale.ROOT) }
                    val rawFiles = children.filter { file ->
                        file.isFile && (file.extensionLower() in localPlayableExtensions || file.extensionLower() == "yt")
                    }
                    val orderKey = "order:" + dir.uri.toString()
                    val savedOrder = prefs.getString(orderKey, null)?.let { raw ->
                        runCatching { JSONArray(raw) }.getOrNull()?.let { a -> (0 until a.length()).map { a.getString(it) } }
                    }.orEmpty()
                    val rank = savedOrder.withIndex().associate { it.value to it.index }
                    val files = rawFiles.sortedWith(compareBy<DocumentFile> { rank[it.uri.toString()] ?: Int.MAX_VALUE }.thenBy { it.name.orEmpty().lowercase(Locale.ROOT) })
                        .map { file ->
                            BreakItem(
                                file = file,
                                name = file.name.orEmpty().substringBeforeLast('.', file.name.orEmpty()),
                                isYoutube = file.extensionLower() == "yt"
                            )
                        }
                    val recursiveManual=if(resolved.isEmpty()) manualRootUris.flatMap { root ->
                        runCatching { scanManualTree(Uri.parse(root)) }.getOrDefault(emptyList())
                    } else emptyList()
                    if(resolved.isEmpty()) saveItemCache("manual_library_cache",recursiveManual)
                    val combined = if (resolved.isEmpty()) dedupeMedia(installedItems + mediaStoreItems + recursiveManual + files) else files
                    Triple(resolved.toList(), dirs, combined)
                }
                val (resolved, dirs, files) = result
                if (resolved != path) {
                    path = resolved
                    persistPath()
                }
                folders = dirs
                tracks = files
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                error = "Folder nije dostupan. Dodirni folder gore desno i izaberi ga ponovo."
            } finally {
                loading = false
            }
        }
    }

    private fun scanManualTree(root:Uri):List<BreakItem> {
        val context=getApplication<Application>()
        val result=mutableListOf<BreakItem>()
        val visited=HashSet<String>()
        fun visit(dir:DocumentFile,depth:Int){
            if(depth>12 || !visited.add(dir.uri.toString())) return
            dir.listFiles().forEach { child ->
                if(child.isDirectory){ if(!child.name.equals(".thumbnails",true)) visit(child,depth+1) }
                else if(child.isFile && (child.extensionLower() in localPlayableExtensions || child.extensionLower()=="yt")) {
                    result.add(BreakItem(child,child.name.orEmpty().substringBeforeLast('.',child.name.orEmpty()),child.extensionLower()=="yt"))
                }
            }
        }
        DocumentFile.fromTreeUri(context,root)?.let { visit(it,0) }
        return result
    }

    private fun cachedItems(key:String):List<BreakItem> = runCatching {
        val a=JSONArray(prefs.getString(key,"[]"));(0 until a.length()).mapNotNull { i ->
            val o=a.getJSONObject(i);val uri=Uri.parse(o.getString("uri"));
            val doc=if(uri.scheme=="file") DocumentFile.fromFile(File(uri.path.orEmpty())) else DocumentFile.fromSingleUri(getApplication(),uri)
            doc?.let { BreakItem(it,o.optString("name",it.name.orEmpty()),o.optBoolean("yt",false)) }
        }
    }.getOrDefault(emptyList())

    private fun saveItemCache(key:String,items:List<BreakItem>) {
        val a=JSONArray();items.forEach { a.put(org.json.JSONObject().put("uri",it.file.uri.toString()).put("name",it.name).put("yt",it.isYoutube)) }
        prefs.edit().putString(key,a.toString()).apply()
    }

    private fun dedupeMedia(items:List<BreakItem>):List<BreakItem> {
        val seen=HashSet<String>()
        return items.filter { item ->
            val uri=item.file.uri.toString()
            val size=runCatching { item.file.length() }.getOrDefault(0L)
            val canonicalName=if(item.name.trim().startsWith("BRAKE MONSTER",true)) "brake monster welcome song" else item.name.trim().lowercase(Locale.ROOT)
            val key=if(size>0L) "$canonicalName|${item.file.extensionLower()}|$size" else uri
            seen.add(key)
        }
    }

    fun moveTrack(from: Int, to: Int) {
        if (from !in tracks.indices || to !in tracks.indices || from == to) return
        val m = tracks.toMutableList()
        val item = m.removeAt(from)
        m.add(to, item)
        tracks = m
        val dir = resolveFolder() ?: return
        prefs.edit().putString("order:" + dir.uri.toString(), JSONArray(m.map { it.file.uri.toString() }).toString()).apply()
    }

    fun saveFolderChildren(relative: List<String>): List<DocumentFile> = runCatching {
        resolveFolder(relative)?.listFiles()?.filter { it.isDirectory && !it.name.equals(".thumbnails", true) }
            ?.sortedBy { it.name.orEmpty().lowercase(Locale.ROOT) }.orEmpty()
    }.getOrDefault(emptyList())

    fun saveYoutubeToFolder(relative: List<String>) {
        val url = youtubeUrl ?: run { message = "Prvo pusti YouTube video."; return }
        val title = youtubeTitle ?: "YouTube"
        viewModelScope.launch {
            val saved = withContext(Dispatchers.IO) {
                val folder = resolveFolder(relative) ?: return@withContext false
                val base = sanitizeFileName(title).ifBlank { "YouTube" }
                val wanted = "$base.yt"
                val existing = folder.listFiles().firstOrNull { it.isFile && it.name.equals(wanted, true) }
                val target = existing ?: folder.createFile("application/octet-stream", wanted) ?: return@withContext false
                getApplication<Application>().contentResolver.openOutputStream(target.uri, "wt")?.use { it.write(url.toByteArray(Charsets.UTF_8)) } ?: return@withContext false
                true
            }
            if (saved) { message = "YT LINK SAVED"; youtubeSaved = true; youtubeCanSave = false; refreshSerial++ }
            else message = "Ne mogu da sačuvam YT link u ovom folderu."
        }
    }

    fun startPlaylist(items: List<BreakItem>, startIndex: Int) {
        if (items.isEmpty() || startIndex !in items.indices) return
        val first=items[startIndex]
        val rest=items.filterIndexed { index, _ -> index!=startIndex }
        playbackQueue = listOf(first) + if(random) rest.shuffled() else rest
        playbackQueueIndex = 0
        startQueueItem()
    }

    fun startLocal(selected: BreakItem) {
        val playable = tracks.filter { it.isYoutube || it.file.extensionLower() in localPlayableExtensions }
        val selectedIndex = playable.indexOfFirst { it.file.uri == selected.file.uri }
        if (selectedIndex < 0) return
        val rest = playable.filterIndexed { index, _ -> index != selectedIndex }
        playbackQueue = listOf(playable[selectedIndex]) + if (random) rest.shuffled() else rest
        playbackQueueIndex = 0
        startQueueItem()
    }

    private fun startQueueItem() {
        val item = playbackQueue.getOrNull(playbackQueueIndex) ?: return
        if (item.isYoutube) {
            stopLocal()
            clearYoutube()
            openSavedYoutubeForQueue(item)
            return
        }
        clearYoutube()
        val request = BreakPlaybackService.StartRequest(
            files = listOf(BreakPlaybackService.Entry(item.file.uri.toString(), item.file.name ?: item.name)),
            selectedUri = item.file.uri.toString(),
            random = false,
            repeat = false,
            volume = 1f
        )
        BreakPlaybackService.start(getApplication(), request)
    }

    fun toggleLocalPause() = BreakPlaybackService.togglePause()
    fun nextLocal() {
        if (playbackQueue.isNotEmpty()) {
            stopLocal()
            advanceQueue()
        } else BreakPlaybackService.next()
    }
    fun seekLocal(value: Int) = BreakPlaybackService.seekTo(value)
    fun stopLocal() = BreakPlaybackService.stop(getApplication())

    fun updateRandom(value: Boolean) {
        random = value
        prefs.edit().putBoolean("random", value).apply()
        BreakPlaybackService.setRandom(value)
    }

    fun updateRepeat(value: Boolean) {
        repeat = value
        prefs.edit().putBoolean("repeat", value).apply()
        BreakPlaybackService.setRepeat(value)
    }

    fun selectYoutube(videoId: String, title: String?, sourceUrl: String? = null) {
        stopLocal()
        playbackQueue = emptyList()
        playbackQueueIndex = -1
        youtubeVideoId = videoId
        youtubeUrl = sourceUrl?.takeIf { it.isNotBlank() } ?: "https://www.youtube.com/watch?v=$videoId"
        youtubeTitle = title?.trim()?.takeIf { it.isNotBlank() } ?: "YouTube"
        youtubeCurrentSecond = 0f
        youtubeDurationSecond = 0f
        youtubePlaying = false
        youtubeSaved = false
        youtubeCanSave = true
        youtubeSession++
    }

    fun openSavedYoutube(item: BreakItem) {
        if (!item.isYoutube) return
        val playable = tracks.filter { it.isYoutube || it.file.extensionLower() in localPlayableExtensions }
        val selectedIndex = playable.indexOfFirst { it.file.uri == item.file.uri }
        if (selectedIndex >= 0) {
            val rest = playable.filterIndexed { index, _ -> index != selectedIndex }
            playbackQueue = listOf(playable[selectedIndex]) + if (random) rest.shuffled() else rest
            playbackQueueIndex = 0
        }
        stopLocal()
        clearYoutube()
        openSavedYoutubeForQueue(item)
    }

    private fun openSavedYoutubeForQueue(item: BreakItem) {
        viewModelScope.launch {
            val link = withContext(Dispatchers.IO) {
                runCatching {
                    if(item.file.uri.scheme=="file") File(item.file.uri.path.orEmpty()).takeIf { it.isFile }?.readText()?.trim()
                    else getApplication<Application>().contentResolver.openInputStream(item.file.uri)?.bufferedReader()?.use { it.readText().trim() }
                }.getOrNull()
            }
            val id = extractYoutubeVideoId(link)
            if (id == null) {
                message = "Sačuvani YT link nije dostupan."
            } else {
                youtubeVideoId = id
                youtubeUrl = link
                youtubeTitle = item.name
                youtubeCurrentSecond = 0f
                youtubeDurationSecond = 0f
                youtubePlaying = false
                youtubeSaved = true
                youtubeCanSave = false
                youtubeSession++
            }
        }
    }

    fun clearYoutube() {
        youtubeVideoId = null
        youtubeUrl = null
        youtubeTitle = null
        youtubePlaying = false
        youtubeCurrentSecond = 0f
        youtubeDurationSecond = 0f
        youtubeSaved = false
        youtubeCanSave = false
    }

    fun onYoutubePlaying(value: Boolean) { youtubePlaying = value }
    fun onYoutubeCurrentSecond(value: Float) { youtubeCurrentSecond = value.coerceAtLeast(0f) }
    fun onYoutubeDuration(value: Float) { youtubeDurationSecond = value.coerceAtLeast(0f) }

    fun onYoutubeEnded() {
        if (youtubeCanSave && playbackQueue.isEmpty()) return
        clearYoutube()
        advanceQueue()
    }

    fun stopPlayback() {
        playbackQueue = emptyList()
        playbackQueueIndex = -1
        stopLocal()
        clearYoutube()
    }

    override fun onCleared() {
        BreakPlaybackService.onSingleTrackCompleted = null
        super.onCleared()
    }

    private fun advanceQueue() {
        if (playbackQueue.isEmpty()) return
        val next = playbackQueueIndex + 1
        if (next < playbackQueue.size) {
            playbackQueueIndex = next
            startQueueItem()
        } else if (repeat && playbackQueue.isNotEmpty()) {
            playbackQueueIndex = 0
            startQueueItem()
        } else {
            playbackQueue = emptyList()
            playbackQueueIndex = -1
            clearYoutube()
            stopLocal()
        }
    }

    fun rename(item: BreakItem, newBaseName: String) {
        val clean = sanitizeFileName(newBaseName).trim()
        if (clean.isBlank()) { message = "Ime ne može biti prazno."; return }
        val ext = item.file.name.orEmpty().substringAfterLast('.', "")
        val wanted = if (ext.isBlank()) clean else "$clean.$ext"
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching { item.file.renameTo(wanted) }.getOrDefault(false) }
            if (!ok) message = "Rename nije uspio."
            refreshSerial++
        }
    }

    fun delete(item: BreakItem, onSuccess: (() -> Unit)? = null) {
        if (localTrackUri == item.file.uri.toString()) stopLocal()
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching {
                if(item.file.uri.authority=="media") getApplication<Application>().contentResolver.delete(item.file.uri,null,null)>0
                else item.file.delete()
            }.getOrDefault(false) }
            if (!ok) message = "Delete nije uspio."
            else onSuccess?.invoke()
            refreshSerial++
        }
    }

    fun onMediaStoreDeleteApproved(item:BreakItem){
        val uri=item.file.uri.toString()
        if(localTrackUri==uri) stopLocal()
        mediaStoreItems=mediaStoreItems.filterNot { it.file.uri.toString()==uri }
        tracks=tracks.filterNot { it.file.uri.toString()==uri }
        saveItemCache("media_store_cache",mediaStoreItems)
        saveItemCache("manual_library_cache",cachedItems("manual_library_cache").filterNot{it.file.uri.toString()==uri})
        refreshSerial++
    }

    fun findInstalledWelcome():BreakItem? = installedItems.firstOrNull { it.file.name.equals("BRAKE MONSTER WELCOME SONG.mp3",true) }

    fun scanMediaStore(showResult:Boolean=true) {
        viewModelScope.launch {
            val found=withContext(Dispatchers.IO) {
                val resolver=getApplication<Application>().contentResolver
                val collection=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                val columns=arrayOf(MediaStore.Audio.Media._ID,MediaStore.Audio.Media.DISPLAY_NAME,MediaStore.Audio.Media.TITLE)
                val out=mutableListOf<BreakItem>()
                runCatching {
                    resolver.query(collection,columns,"${MediaStore.Audio.Media.IS_MUSIC} != 0",null,"${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
                        val idCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                        val nameCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                        val titleCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                        while(c.moveToNext()) {
                            val uri=ContentUris.withAppendedId(collection,c.getLong(idCol))
                            val display=c.getString(titleCol)?.takeIf{it.isNotBlank()} ?: c.getString(nameCol).orEmpty().substringBeforeLast('.')
                            val file=androidx.documentfile.provider.DocumentFile.fromSingleUri(getApplication(),uri) ?: continue
                            out.add(BreakItem(file,display,false))
                        }
                    }
                }
                out
            }
            mediaStoreItems=found
            mediaScanComplete=true
            val cached=JSONArray()
            found.forEach { cached.put(org.json.JSONObject().put("uri",it.file.uri.toString()).put("name",it.name)) }
            prefs.edit().putBoolean("media_scan_complete",true).putString("media_store_cache",cached.toString()).apply()
            if(showResult) message="${found.size} SONGS FOUND"
            refreshSerial++
        }
    }

    private var mediaStoreItems:List<BreakItem> = runCatching {
        val a=JSONArray(prefs.getString("media_store_cache","[]"));(0 until a.length()).mapNotNull { i ->
            val o=a.getJSONObject(i);val uri=Uri.parse(o.getString("uri"));
            DocumentFile.fromSingleUri(getApplication(),uri)?.let { BreakItem(it,o.optString("name",it.name.orEmpty()),false) }
        }
    }.getOrDefault(emptyList())

    private fun syncServiceSnapshot() {
        val s = BreakPlaybackService.snapshot
        localTrackUri = s.trackUri
        localTrackName = s.trackName
        localPreparing = s.preparing
        localPlaying = s.playing
        localPosition = s.position
        localDuration = s.duration
        if (random != s.random && s.sessionActive) random = s.random
        if (repeat != s.repeat && s.sessionActive) repeat = s.repeat
    }

    companion object {
        fun sanitizeFileName(value: String): String = value
            .replace(Regex("[\\/:*?\"<>|]"), "-")
            .replace(Regex("\\s+"), " ")
            .trim().trim('.')
            .take(120)

        fun extractYoutubeVideoId(raw: String?): String? {
            if (raw.isNullOrBlank()) return null
            return runCatching {
                val uri = Uri.parse(raw.trim())
                val host = uri.host?.lowercase(Locale.ROOT).orEmpty().removePrefix("www.").removePrefix("m.")
                val id = when {
                    host == "youtu.be" -> uri.pathSegments.firstOrNull()
                    host == "youtube.com" || host.endsWith(".youtube.com") -> when {
                        uri.path == "/watch" -> uri.getQueryParameter("v")
                        uri.pathSegments.firstOrNull() == "shorts" -> uri.pathSegments.getOrNull(1)
                        uri.pathSegments.firstOrNull() == "live" -> uri.pathSegments.getOrNull(1)
                        uri.pathSegments.firstOrNull() == "embed" -> uri.pathSegments.getOrNull(1)
                        else -> null
                    }
                    else -> null
                }
                id?.takeIf { it.matches(Regex("[A-Za-z0-9_-]{6,20}")) }
            }.getOrNull()
        }
    }
}
