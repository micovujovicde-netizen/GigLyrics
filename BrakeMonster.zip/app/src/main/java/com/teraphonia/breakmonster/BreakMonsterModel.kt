package com.teraphonia.breakmonster

import android.app.Application
import android.content.ContentUris
import android.provider.MediaStore
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.util.Locale

internal data class BreakItem(
    val file: DocumentFile,
    val name: String,
    val isYoutube: Boolean
)

internal val localPlayableExtensions = setOf(
    "mp3", "wav", "wave", "m4a", "aac", "flac", "ogg", "opus", "amr",
    "mp4", "m4v", "mov", "3gp", "3g2", "mkv", "webm", "avi", "ts", "m2ts", "mpeg", "mpg"
)
internal val importSidecarExtensions = setOf("txt", "lrc", "srt", "cdg", "lyr", "lyr3", "mid", "midi", "kar")

internal fun DocumentFile.extensionLower(): String =
    name.orEmpty().substringAfterLast('.', "").lowercase(Locale.ROOT)

internal class BreakMonsterModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("breakmonster", 0)

    var rootUri by mutableStateOf(prefs.getString("root", null))
        private set

    private var manualRootUris:List<String> = runCatching {
        val raw=prefs.getString("manual_roots",null)
        val saved=if(raw==null) emptyList() else { val a=JSONArray(raw);(0 until a.length()).map{a.getString(it)} }
        (saved + listOfNotNull(rootUri)).distinct()
    }.getOrDefault(listOfNotNull(rootUri))

    var path by mutableStateOf(loadPath())
        private set

    var folders by mutableStateOf<List<DocumentFile>>(emptyList())
        private set
    var tracks by mutableStateOf<List<BreakItem>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    var mediaScanComplete by mutableStateOf(prefs.getBoolean("first_user_scan_complete_v25",false))
        private set
    var mediaScanInProgress by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    var random by mutableStateOf(prefs.getBoolean("random", false))
        private set
    var repeat by mutableStateOf(prefs.getBoolean("repeat", false))
        private set

    var localTrackUri by mutableStateOf<String?>(null)
        private set
    var localTrackName by mutableStateOf<String?>(null)
        private set
    var localPreparing by mutableStateOf(false)
        private set
    var localPlaying by mutableStateOf(false)
        private set
    var localPosition by mutableIntStateOf(0)
        private set
    var localDuration by mutableIntStateOf(0)
        private set

    var youtubeVideoId by mutableStateOf<String?>(null)
        private set
    var youtubeUrl by mutableStateOf<String?>(null)
        private set
    var youtubeTitle by mutableStateOf<String?>(null)
        private set
    var youtubeSession by mutableIntStateOf(0)
        private set
    var youtubePlaying by mutableStateOf(false)
        private set
    var youtubeCurrentSecond by mutableStateOf(0f)
        private set
    var youtubeDurationSecond by mutableStateOf(0f)
        private set
    var youtubeSaved by mutableStateOf(false)
        private set
    var youtubeCanSave by mutableStateOf(false)
        private set

    private var playbackQueue: List<BreakItem> = emptyList()
    private var playbackQueueIndex = -1

    var refreshSerial by mutableIntStateOf(0)
        private set

    var message by mutableStateOf<String?>(null)
        private set

    private val installedMediaDir = File(app.filesDir, "installed_media")
    private val brakeMonsterDir = File(app.filesDir, "brakemonster_media")
    private val ytDownloadsDir = File(brakeMonsterDir, "YT DOWNLOADS")
    private var ownedMediaItems by mutableStateOf<List<BreakItem>>(emptyList())
    val brakeMonsterItems: List<BreakItem> get() = ownedMediaItems.filterNot { it.isYoutube }
    val ytDownloadItems: List<BreakItem> get() = ownedMediaItems.filter { it.isYoutube }
    // Compose-facing library must be memory-only. Never rebuild DocumentFiles / parse JSON here.
    private var manualLibraryItems by mutableStateOf<List<BreakItem>>(emptyList())
    // Declared before init because init restores this cache explicitly.
    private var mediaStoreItems: List<BreakItem> = emptyList()
    private var allMusicCache by mutableStateOf<List<BreakItem>>(emptyList())
    val allMusicItems: List<BreakItem> get() = allMusicCache
    private fun rebuildAllMusicCache() {
        allMusicCache = applySavedOrder(
            dedupeMedia(manualLibraryItems + mediaStoreItems).filterNot(::isBundledSeed),
            "order:all_music"
        )
    }
    val installedItems: List<BreakItem> get() = installedMediaDir.listFiles().orEmpty()
        .filter { it.isFile && (it.extension.lowercase(Locale.ROOT) in localPlayableExtensions || it.extension.equals("yt", true)) }
        .map { f -> BreakItem(DocumentFile.fromFile(f), f.nameWithoutExtension, f.extension.equals("yt", true)) }

    init {
        installBundledMedia()
        brakeMonsterDir.mkdirs(); ytDownloadsDir.mkdirs()
        refreshOwnedItems()
        manualLibraryItems = cachedItems("manual_library_cache")
        mediaStoreItems = cachedItems("media_store_cache")
        rebuildAllMusicCache()
        tracks = allMusicCache
        BreakPlaybackService.onSingleTrackCompleted = { advanceQueue() }
        viewModelScope.launch {
            while (isActive) {
                syncServiceSnapshot()
                delay(150)
            }
        }
        // Do not auto-scan on startup. The first library scan must only start after
        // the user explicitly presses FIND YOUR MUSIC.
    }

    /** Seeds the welcome MP3 into Import and the two supplied links into YT DOWNLOADS. */
    private fun installBundledMedia() {
        runCatching {
            brakeMonsterDir.mkdirs(); ytDownloadsDir.mkdirs()
            val context=getApplication<Application>()
            val media=listOf(
                Triple("BRAKE MONSTER.mp3", File(brakeMonsterDir,"BRAKE MONSTER WELCOME SONG.mp3"), false),
                Triple("TERAPHONIA - TERAPHONIA DAD.yt", File(ytDownloadsDir,"TERAPHONIA - TERAPHONIA DAD.yt"), true),
                Triple("EDEN - TERAPHONIA DAD.yt", File(ytDownloadsDir,"EDEN - TERAPHONIA DAD.yt"), true)
            )
            media.forEach { (asset,target,_) ->
                if(!target.exists() || target.length()==0L) context.assets.open(asset).use { input -> target.outputStream().use { input.copyTo(it) } }
            }
            // Remove legacy seed copies so they can never leak into ALL MUSIC.
            installedMediaDir.listFiles().orEmpty().forEach { it.delete() }
            prefs.edit().putBoolean("installed_media_seeded",true).apply()
        }
    }

    private fun loadPath(): List<String> = runCatching {
        val raw = prefs.getString("path", null) ?: return@runCatching emptyList<String>()
        val json = JSONArray(raw)
        (0 until json.length()).map { json.getString(it) }
    }.getOrDefault(emptyList<String>())

    private fun persistPath() {
        prefs.edit().putString("path", JSONArray(path).toString()).apply()
    }

    fun consumeMessage() { message = null }

    fun setRoot(uri: Uri) {
        rootUri = uri.toString()
        manualRootUris=(manualRootUris+uri.toString()).distinct()
        path = emptyList<String>()
        prefs.edit().putString("root", rootUri).putString("manual_roots",JSONArray(manualRootUris).toString()).putString("path", "[]").apply()
        refreshSerial++
    }

    fun home() {
        BlackBox.log("MODEL home pathDepth=${path.size}")
        if (path.isNotEmpty()) {
            path = emptyList<String>()
            persistPath()
        }
    }

    /** @return true when a folder level was consumed. */
    fun back(): Boolean {
        BlackBox.log("MODEL back pathDepth=${path.size}")
        if (path.isEmpty()) return false
        path = path.dropLast(1)
        persistPath()
        return true
    }

    fun openFolder(dir: DocumentFile) {
        BlackBox.log("MODEL openFolder ${dir.name}")
        val name = dir.name ?: return
        path = path + name
        persistPath()
    }

    private fun resolveFolder(relative: List<String> = path): DocumentFile? {
        var dir = rootUri?.let { DocumentFile.fromTreeUri(getApplication(), Uri.parse(it)) } ?: return null
        for (name in relative) {
            if (name.equals(".thumbnails", true)) return null
            dir = dir.findFile(name)?.takeIf { it.isDirectory } ?: return null
        }
        return dir
    }

    fun refresh() {
        val bbStart=android.os.SystemClock.elapsedRealtime()
        BlackBox.log("REFRESH request root=${rootUri!=null} pathDepth=${path.size}")
        val target = rootUri ?: run {
            folders = emptyList<DocumentFile>(); tracks = allMusicItems; loading = false; return
        }
        viewModelScope.launch {
            loading = true
            error = null
            try {
                val result = withContext(Dispatchers.IO) {
                    var dir = DocumentFile.fromTreeUri(getApplication(), Uri.parse(target))
                        ?: kotlin.error("Missing root")
                    val resolved = mutableListOf<String>()
                    for (segment in path) {
                        if (segment.equals(".thumbnails", true)) break
                        val next = dir.findFile(segment)?.takeIf { it.isDirectory } ?: break
                        dir = next
                        resolved += segment
                    }
                    val children = dir.listFiles().toList()
                    val dirs = children.filter { it.isDirectory && !it.name.equals(".thumbnails", true) }
                        .sortedBy { it.name.orEmpty().lowercase(Locale.ROOT) }
                    val rawFiles = children.filter { file ->
                        file.isFile && (file.extensionLower() in localPlayableExtensions || file.extensionLower() == "yt")
                    }
                    val orderKey = "order:" + dir.uri.toString()
                    val savedOrder = prefs.getString(orderKey, null)?.let { raw ->
                        runCatching { JSONArray(raw) }.getOrNull()?.let { a -> (0 until a.length()).map { a.getString(it) } }
                    }.orEmpty()
                    val rank = savedOrder.withIndex().associate { it.value to it.index }
                    val files = rawFiles.sortedWith(compareBy<DocumentFile> { rank[it.uri.toString()] ?: Int.MAX_VALUE }.thenBy { it.name.orEmpty().lowercase(Locale.ROOT) })
                        .map { file ->
                            BreakItem(
                                file = file,
                                name = file.name.orEmpty().substringBeforeLast('.', file.name.orEmpty()),
                                isYoutube = file.extensionLower() == "yt"
                            )
                        }
                    val recursiveManual=if(resolved.isEmpty()) manualRootUris.flatMap { root ->
                        runCatching { scanManualTree(Uri.parse(root)) }.getOrDefault(emptyList())
                    } else emptyList()
                    if(resolved.isEmpty()) {
                manualLibraryItems = recursiveManual
                rebuildAllMusicCache()
                saveItemCache("manual_library_cache",recursiveManual)
            }
                    val combined = if (resolved.isEmpty()) applySavedOrder(dedupeMedia(mediaStoreItems + recursiveManual + files), "order:all_music") else files
                    Triple(resolved.toList(), dirs, combined)
                }
                val (resolved, dirs, files) = result
                if (resolved != path) {
                    path = resolved
                    persistPath()
                }
                folders = dirs
                tracks = files
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                error = "Folder nije dostupan. Dodirni folder gore desno i izaberi ga ponovo."
            } finally {
                loading = false
            }
        }
    }

    private fun scanManualTree(root:Uri):List<BreakItem> {
        val context=getApplication<Application>()
        val result=mutableListOf<BreakItem>()
        val visited=HashSet<String>()
        fun visit(dir:DocumentFile,depth:Int){
            if(depth>12 || !visited.add(dir.uri.toString())) return
            dir.listFiles().forEach { child ->
                if(child.isDirectory){ if(!child.name.equals(".thumbnails",true)) visit(child,depth+1) }
                else if(child.isFile && (child.extensionLower() in localPlayableExtensions || child.extensionLower()=="yt")) {
                    result.add(BreakItem(child,child.name.orEmpty().substringBeforeLast('.',child.name.orEmpty()),child.extensionLower()=="yt"))
                }
            }
        }
        DocumentFile.fromTreeUri(context,root)?.let { visit(it,0) }
        return result
    }

    private fun scanOwnedDir(dir: File, includeYt: Boolean): List<BreakItem> = runCatching {
        if (!dir.exists()) return@runCatching emptyList()
        dir.walkTopDown().filter { f -> f.isFile && (f.extension.lowercase(Locale.ROOT) in localPlayableExtensions || (includeYt && f.extension.equals("yt", true))) }
            .map { f -> BreakItem(DocumentFile.fromFile(f), f.nameWithoutExtension, f.extension.equals("yt", true)) }.toList()
    }.getOrDefault(emptyList())

    private fun refreshOwnedItems() { ownedMediaItems=scanOwnedDir(brakeMonsterDir, true) }

    fun importName(uri: Uri): String = runCatching {
        getApplication<Application>().contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Imported media"

    fun importedNameExists(name: String): Boolean {
        val ext=name.substringAfterLast('.',"").lowercase(Locale.ROOT)
        val dir=if(ext=="yt") ytDownloadsDir else brakeMonsterDir
        return dir.listFiles().orEmpty().any { it.name.equals(name,true) }
    }

    /** Copy a picker-selected document into app-owned storage; the original URI is read only. */
    fun copyImport(uri: Uri, choice: String) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val context = getApplication<Application>()
                    brakeMonsterDir.mkdirs(); ytDownloadsDir.mkdirs()
                    val sourceName = sanitizeFileName(importName(uri)).ifBlank { "Imported media" }
                    val ext = sourceName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                    if (ext !in localPlayableExtensions && ext !in importSidecarExtensions) return@runCatching false
                    val dir = if (ext == "yt") ytDownloadsDir else brakeMonsterDir
                    val existing=dir.listFiles().orEmpty().firstOrNull { it.name.equals(sourceName,true) }
                    var target = File(dir, sourceName)
                    if (existing!=null) {
                        when (choice) {
                            "replace" -> target=existing
                            "keep" -> { val base = sourceName.substringBeforeLast('.', sourceName); val suffix = sourceName.substringAfterLast('.', "").let { if (it.isBlank()) "" else ".$it" }; var n=2; while (dir.listFiles().orEmpty().any { it.name.equals("$base ($n)$suffix",true) }) n++; target=File(dir,"$base ($n)$suffix") }
                            else -> return@runCatching false
                        }
                    }
                    context.contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use { output -> input.copyTo(output) } } ?: return@runCatching false
                    true
                }.getOrDefault(false)
            }
            if (result) { refreshOwnedItems(); message = "IMPORTED"; refreshSerial++ } else message = "Import was cancelled or could not be copied."
        }
    }

    private fun cachedItems(key:String):List<BreakItem> = runCatching {
        val a=JSONArray(prefs.getString(key,"[]"));(0 until a.length()).mapNotNull { i ->
            val o=a.getJSONObject(i);val uri=Uri.parse(o.getString("uri"));
            val doc=if(uri.scheme=="file") DocumentFile.fromFile(File(uri.path.orEmpty())) else DocumentFile.fromSingleUri(getApplication(),uri)
            doc?.let {
                // Do NOT use it.name as optString's default: Kotlin evaluates that default
                // eagerly, causing a ContentResolver query for every cached MediaStore row.
                val cachedName = o.optString("name").takeIf { n -> n.isNotBlank() }
                    ?: uri.lastPathSegment.orEmpty()
                BreakItem(it,cachedName,o.optBoolean("yt",false))
            }
        }
    }.getOrDefault(emptyList())

    private fun saveItemCache(key:String,items:List<BreakItem>) {
        val a=JSONArray();items.forEach { a.put(org.json.JSONObject().put("uri",it.file.uri.toString()).put("name",it.name).put("yt",it.isYoutube)) }
        prefs.edit().putString(key,a.toString()).apply()
    }

    private fun isBundledSeed(item: BreakItem): Boolean {
        // item.name is cached metadata. DocumentFile.name can hit ContentResolver and must
        // never be used from this Compose-facing filter.
        val n = item.name.trim()
        return n.equals("BRAKE MONSTER WELCOME SONG.mp3", true) ||
            n.equals("BRAKE MONSTER WELCOME SONG", true) ||
            n.equals("BRAKE MONSTER.mp3", true) ||
            n.equals("TERAPHONIA - TERAPHONIA DAD.yt", true) ||
            n.equals("TERAPHONIA - TERAPHONIA DAD", true) ||
            n.equals("EDEN - TERAPHONIA DAD.yt", true) ||
            n.equals("EDEN - TERAPHONIA DAD", true)
    }

    private fun dedupeMedia(items:List<BreakItem>):List<BreakItem> {
        // IMPORTANT: never call DocumentFile.length()/name here. For MediaStore URIs those
        // methods perform ContentResolver I/O; this function is also used by Compose-facing
        // getters and previously caused seconds of main-thread blocking for ~1000 songs.
        val seenUris=HashSet<String>()
        return items.filter { item -> seenUris.add(item.file.uri.toString()) }
    }

    private fun applySavedOrder(items:List<BreakItem>, key:String):List<BreakItem> {
        val saved=runCatching { JSONArray(prefs.getString(key,"[]")) }.getOrNull()?.let { a -> (0 until a.length()).map { a.getString(it) } }.orEmpty()
        if(saved.isEmpty()) return items
        val rank=saved.withIndex().associate { it.value to it.index }
        return items.sortedWith(compareBy<BreakItem> { rank[it.file.uri.toString()] ?: Int.MAX_VALUE }.thenBy { it.name.lowercase(Locale.ROOT) })
    }

    fun moveTrack(from: Int, to: Int) {
        if (from !in tracks.indices || to !in tracks.indices || from == to) return
        val m = tracks.toMutableList()
        val item = m.removeAt(from)
        m.add(to, item)
        tracks = m
        val orderKey = if(path.isEmpty()) "order:all_music" else "order:" + (resolveFolder()?.uri?.toString() ?: return)
        prefs.edit().putString(orderKey, JSONArray(m.map { it.file.uri.toString() }).toString()).apply()
    }

    fun saveFolderChildren(relative: List<String>): List<DocumentFile> = runCatching {
        resolveFolder(relative)?.listFiles()?.filter { it.isDirectory && !it.name.equals(".thumbnails", true) }
            ?.sortedBy { it.name.orEmpty().lowercase(Locale.ROOT) }.orEmpty()
    }.getOrDefault(emptyList())

    fun saveYoutubeToFolder(relative: List<String> = emptyList()) {
        val url = youtubeUrl ?: run { message = "Prvo pusti YouTube video."; return }
        val title = youtubeTitle ?: "YouTube"
        viewModelScope.launch {
            val saved = withContext(Dispatchers.IO) {
                val folder = DocumentFile.fromFile(ytDownloadsDir.apply { mkdirs() })
                val base = sanitizeYoutubeFileName(title).ifBlank { "YouTube" }
                val wanted = "$base.yt"
                val existing = folder.listFiles().firstOrNull { it.isFile && it.name.equals(wanted, true) }
                val target = existing ?: folder.createFile("application/octet-stream", wanted) ?: return@withContext false
                getApplication<Application>().contentResolver.openOutputStream(target.uri, "wt")?.use { it.write(url.toByteArray(Charsets.UTF_8)) } ?: return@withContext false
                true
            }
            if (saved) { refreshOwnedItems(); message = "YT LINK SAVED"; youtubeSaved = true; youtubeCanSave = false; refreshSerial++ }
            else message = "Ne mogu da sačuvam YT link u ovom folderu."
        }
    }

    fun startPlaylist(items: List<BreakItem>, startIndex: Int) {
        if (items.isEmpty() || startIndex !in items.indices) return
        val first=items[startIndex]
        val rest=items.filterIndexed { index, _ -> index!=startIndex }
        playbackQueue = listOf(first) + if(random) rest.shuffled() else rest
        playbackQueueIndex = 0
        startQueueItem()
    }

    fun startLocal(selected: BreakItem) {
        val current = tracks.filter { it.isYoutube || it.file.extensionLower() in localPlayableExtensions }
        val playable = if(current.any { it.file.uri==selected.file.uri }) current else allMusicItems.filter { it.isYoutube || it.file.extensionLower() in localPlayableExtensions }
        val selectedIndex = playable.indexOfFirst { it.file.uri == selected.file.uri }
        if (selectedIndex < 0) return
        val rest = playable.filterIndexed { index, _ -> index != selectedIndex }
        playbackQueue = listOf(playable[selectedIndex]) + if (random) rest.shuffled() else rest
        playbackQueueIndex = 0
        startQueueItem()
    }

    private fun startQueueItem() {
        val item = playbackQueue.getOrNull(playbackQueueIndex) ?: return
        if (item.isYoutube) {
            stopLocal()
            clearYoutube()
            openSavedYoutubeForQueue(item)
            return
        }
        clearYoutube()
        val request = BreakPlaybackService.StartRequest(
            files = listOf(BreakPlaybackService.Entry(item.file.uri.toString(), item.file.name ?: item.name)),
            selectedUri = item.file.uri.toString(),
            random = false,
            repeat = false,
            volume = 1f
        )
        BreakPlaybackService.start(getApplication(), request)
    }

    fun toggleLocalPause() = BreakPlaybackService.togglePause()
    fun nextLocal() {
        if (playbackQueue.isNotEmpty()) {
            stopLocal()
            advanceQueue()
        } else BreakPlaybackService.next()
    }
    fun seekLocal(value: Int) = BreakPlaybackService.seekTo(value)
    fun stopLocal() = BreakPlaybackService.stop(getApplication())

    fun updateRandom(value: Boolean) {
        random = value
        prefs.edit().putBoolean("random", value).apply()
        BreakPlaybackService.setRandom(value)
    }

    fun updateRepeat(value: Boolean) {
        repeat = value
        prefs.edit().putBoolean("repeat", value).apply()
        BreakPlaybackService.setRepeat(value)
    }

    fun selectYoutube(videoId: String, title: String?, sourceUrl: String? = null) {
        stopLocal()
        playbackQueue = emptyList()
        playbackQueueIndex = -1
        youtubeVideoId = videoId
        youtubeUrl = sourceUrl?.takeIf { it.isNotBlank() } ?: "https://www.youtube.com/watch?v=$videoId"
        youtubeTitle = title?.trim()?.takeIf { it.isNotBlank() } ?: "YouTube"
        youtubeCurrentSecond = 0f
        youtubeDurationSecond = 0f
        youtubePlaying = false
        youtubeSaved = false
        youtubeCanSave = true
        youtubeSession++
    }

    fun openSavedYoutube(item: BreakItem) {
        if (!item.isYoutube) return
        val current = tracks.filter { it.isYoutube || it.file.extensionLower() in localPlayableExtensions }
        val playable = if(current.any { it.file.uri==item.file.uri }) current else allMusicItems.filter { it.isYoutube || it.file.extensionLower() in localPlayableExtensions }
        val selectedIndex = playable.indexOfFirst { it.file.uri == item.file.uri }
        if (selectedIndex >= 0) {
            val rest = playable.filterIndexed { index, _ -> index != selectedIndex }
            playbackQueue = listOf(playable[selectedIndex]) + if (random) rest.shuffled() else rest
            playbackQueueIndex = 0
        }
        stopLocal()
        clearYoutube()
        openSavedYoutubeForQueue(item)
    }

    private fun openSavedYoutubeForQueue(item: BreakItem) {
        viewModelScope.launch {
            val link = withContext(Dispatchers.IO) {
                runCatching {
                    if(item.file.uri.scheme=="file") File(item.file.uri.path.orEmpty()).takeIf { it.isFile }?.readText()?.trim()
                    else getApplication<Application>().contentResolver.openInputStream(item.file.uri)?.bufferedReader()?.use { it.readText().trim() }
                }.getOrNull()
            }
            val id = extractYoutubeVideoId(link)
            if (id == null) {
                message = "Sačuvani YT link nije dostupan."
            } else {
                youtubeVideoId = id
                youtubeUrl = link
                youtubeTitle = item.name
                youtubeCurrentSecond = 0f
                youtubeDurationSecond = 0f
                youtubePlaying = false
                youtubeSaved = true
                youtubeCanSave = false
                youtubeSession++
            }
        }
    }

    fun clearYoutube() {
        youtubeVideoId = null
        youtubeUrl = null
        youtubeTitle = null
        youtubePlaying = false
        youtubeCurrentSecond = 0f
        youtubeDurationSecond = 0f
        youtubeSaved = false
        youtubeCanSave = false
    }

    fun onYoutubePlaying(value: Boolean) { youtubePlaying = value }
    fun onYoutubeCurrentSecond(value: Float) { youtubeCurrentSecond = value.coerceAtLeast(0f) }
    fun onYoutubeDuration(value: Float) { youtubeDurationSecond = value.coerceAtLeast(0f) }

    fun onYoutubeEnded() {
        if (youtubeCanSave && playbackQueue.isEmpty()) return
        clearYoutube()
        advanceQueue()
    }

    fun stopPlayback() {
        playbackQueue = emptyList()
        playbackQueueIndex = -1
        stopLocal()
        clearYoutube()
    }

    override fun onCleared() {
        BreakPlaybackService.onSingleTrackCompleted = null
        super.onCleared()
    }

    private fun advanceQueue() {
        if (playbackQueue.isEmpty()) return
        val next = playbackQueueIndex + 1
        if (next < playbackQueue.size) {
            playbackQueueIndex = next
            startQueueItem()
        } else if (repeat && playbackQueue.isNotEmpty()) {
            playbackQueueIndex = 0
            startQueueItem()
        } else {
            playbackQueue = emptyList()
            playbackQueueIndex = -1
            clearYoutube()
            stopLocal()
        }
    }

    fun rename(item: BreakItem, newBaseName: String) {
        val clean = sanitizeFileName(newBaseName).trim()
        if (clean.isBlank()) { message = "Ime ne može biti prazno."; return }
        val ext = item.file.name.orEmpty().substringAfterLast('.', "")
        val wanted = if (ext.isBlank()) clean else "$clean.$ext"
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching { item.file.renameTo(wanted) }.getOrDefault(false) }
            if (!ok) message = "Rename nije uspio."
            refreshOwnedItems(); refreshSerial++
        }
    }

    fun delete(item: BreakItem, onSuccess: (() -> Unit)? = null) {
        if (localTrackUri == item.file.uri.toString()) stopLocal()
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching {
                if(item.file.uri.authority=="media") getApplication<Application>().contentResolver.delete(item.file.uri,null,null)>0
                else item.file.delete()
            }.getOrDefault(false) }
            if (!ok) message = "Delete nije uspio."
            else onSuccess?.invoke()
            refreshOwnedItems()
            refreshSerial++
        }
    }

    fun onMediaStoreDeleteApproved(item:BreakItem){
        val uri=item.file.uri.toString()
        if(localTrackUri==uri) stopLocal()
        mediaStoreItems=mediaStoreItems.filterNot { it.file.uri.toString()==uri }
        manualLibraryItems=manualLibraryItems.filterNot { it.file.uri.toString()==uri }
        rebuildAllMusicCache()
        tracks=tracks.filterNot { it.file.uri.toString()==uri }
        saveItemCache("media_store_cache",mediaStoreItems)
        saveItemCache("manual_library_cache",manualLibraryItems)
        refreshSerial++
    }

    fun findInstalledWelcome():BreakItem? = scanOwnedDir(brakeMonsterDir, true).firstOrNull { it.file.name.equals("BRAKE MONSTER WELCOME SONG.mp3",true) }

    fun bundledP1Items(): List<BreakItem> = scanOwnedDir(brakeMonsterDir, true).filter { item ->
        item.file.name.equals("BRAKE MONSTER WELCOME SONG.mp3",true) ||
        item.file.name.equals("TERAPHONIA - TERAPHONIA DAD.yt",true) ||
        item.file.name.equals("EDEN - TERAPHONIA DAD.yt",true)
    }.sortedBy { if(it.file.name.equals("BRAKE MONSTER WELCOME SONG.mp3",true)) 0 else 1 }

    fun scanMediaStore(showResult:Boolean=true) {
        if(mediaScanInProgress) { BlackBox.log("MEDIA SCAN ignored already running"); return }
        val bbScanStart=android.os.SystemClock.elapsedRealtime()
        mediaScanInProgress=true
        viewModelScope.launch {
            BlackBox.log("MEDIA SCAN DISPATCH -> IO")
            val scanResult=withContext(Dispatchers.IO) {
                val ioStart=android.os.SystemClock.elapsedRealtime()
                BlackBox.log("MEDIA SCAN IO START")
                val resolver=getApplication<Application>().contentResolver
                val collection=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                val columns=arrayOf(MediaStore.Audio.Media._ID,MediaStore.Audio.Media.DISPLAY_NAME,MediaStore.Audio.Media.TITLE)
                val out=mutableListOf<BreakItem>()
                runCatching {
                    resolver.query(collection,columns,"${MediaStore.Audio.Media.IS_MUSIC} != 0",null,"${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
                        val idCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                        val nameCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                        val titleCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                        while(c.moveToNext()) {
                            val uri=ContentUris.withAppendedId(collection,c.getLong(idCol))
                            val rawName=c.getString(nameCol).orEmpty()
                            val display=c.getString(titleCol)?.takeIf{it.isNotBlank()} ?: rawName.substringBeforeLast('.')
                            // Filter seed files from cursor metadata while still on IO. Do not
                            // ask DocumentFile for name/length later on the main thread.
                            val n=rawName.ifBlank { display }
                            val seed=n.equals("BRAKE MONSTER WELCOME SONG.mp3",true) ||
                                n.equals("BRAKE MONSTER WELCOME SONG",true) || n.equals("BRAKE MONSTER.mp3",true) ||
                                n.equals("TERAPHONIA - TERAPHONIA DAD.yt",true) || n.equals("TERAPHONIA - TERAPHONIA DAD",true) ||
                                n.equals("EDEN - TERAPHONIA DAD.yt",true) || n.equals("EDEN - TERAPHONIA DAD",true)
                            if(!seed) {
                                val file=DocumentFile.fromSingleUri(getApplication(),uri) ?: continue
                                out.add(BreakItem(file,display,false))
                            }
                        }
                    }
                }
                val cached=JSONArray()
                out.forEach { cached.put(org.json.JSONObject().put("uri",it.file.uri.toString()).put("name",it.name)) }
                BlackBox.log("MEDIA SCAN IO END ${android.os.SystemClock.elapsedRealtime()-ioStart}ms items=${out.size}")
                Pair(out,cached.toString())
            }
            // Main thread now only swaps already-built in-memory state; no provider calls.
            val (found,cacheJson)=scanResult
            mediaStoreItems=found
            rebuildAllMusicCache()
            tracks=allMusicCache
            mediaScanComplete=true
            prefs.edit().putBoolean("media_scan_complete",true).putBoolean("first_user_scan_complete_v25",true).putString("media_store_cache",cacheJson).apply()
            if(showResult) message="${found.size} SONGS FOUND"
            refreshSerial++
            mediaScanInProgress=false
            BlackBox.log("MEDIA SCAN COMPLETE ${android.os.SystemClock.elapsedRealtime()-bbScanStart}ms items=${found.size}")
        }
    }

    private fun syncServiceSnapshot() {
        val s = BreakPlaybackService.snapshot
        localTrackUri = s.trackUri
        localTrackName = s.trackName
        localPreparing = s.preparing
        localPlaying = s.playing
        localPosition = s.position
        localDuration = s.duration
        if (random != s.random && s.sessionActive) random = s.random
        if (repeat != s.repeat && s.sessionActive) repeat = s.repeat
    }

    companion object {
        /** Keep the artist/song identity and only useful version tags in saved .yt filenames. */
        fun sanitizeYoutubeFileName(value: String): String {
            val tags = linkedSetOf<String>()
            fun rememberTag(word: String, label: String) {
                if (Regex("(?i)\\b${Regex.escape(word)}\\b").containsMatchIn(value)) tags.add(label)
            }
            rememberTag("live", "LIVE")
            rememberTag("official", "OFFICIAL")
            rememberTag("concert", "CONCERT")
            rememberTag("concerts", "CONCERT")

            var title = value.trim()
            // Preserve the actual title before common YouTube/channel annotations.
            title = title.replace(Regex("(?i)\\s*\\|\\s*(?:youtube|official|video|lyrics?|music\\s+video|audio|live|concerts?|full\\s+album|4k|8k|hd|hq|1080p|720p)\\b.*$"), " ")
            title = title.replace(Regex("(?i)(?:[-–—,]\\s*)\\b(?:live|concerts?)\\b(?:\\s+(?:at|in|from|on|footage|video)\\b.*)?$"), " ")
            title = title.replace(Regex("https?://\\S+", RegexOption.IGNORE_CASE), " ")
            title = title.replace(Regex("(?i)\\b(?:official\\s+(?:music\\s+)?(?:video|audio|lyrics?|visualizer)|music\\s+video|lyric(?:s)?\\s+video|full\\s+concert|concert\\s+(?:video|footage|film)|live\\s+(?:performance|version|recording))\\b"), " ")
            // Bracketed notes are release metadata; their useful LIVE/OFFICIAL/CONCERT
            // identity has already been retained as a short suffix tag above.
            title = title.replace(Regex("\\([^)]*\\)|\\[[^]]*]|\\{[^}]*}"), " ")
            title = title.replace(Regex("(?i)\\b(?:official|live|concerts?|4k|8k|hd|hq|1080p|720p|lyrics?|karaoke|visualizer|audio|video|remastered|remaster|full\\s+album|download(?:s)?|free|mp3|mp4|reaction|teaser|preview)\\b"), " ")
            title = title.replace(Regex("\\b(?:19|20)\\d{2}\\b"), " ")
            title = title.replace(Regex("#[\\p{L}\\p{N}_]+"), " ")
                .replace(Regex("[\\s·|,:;_–—-]+$"), " ")
                .replace(Regex("^[\\s·|,:;_–—-]+"), " ")
                .replace(Regex("\\b(?:at|in|from|on)\\s*$", RegexOption.IGNORE_CASE), " ")
                .replace(Regex("\\s+"), " ")
                .trim()
            val tagText = tags.joinToString(" ")
            val baseLimit = (120 - tagText.length - if (tagText.isBlank()) 0 else 1).coerceAtLeast(1)
            val cleanBase = sanitizeFileName(title).take(baseLimit).trimEnd(' ', '-', '_')
            return sanitizeFileName(listOf(cleanBase, tagText).filter { it.isNotBlank() }.joinToString(" "))
        }

        fun sanitizeFileName(value: String): String = value
            .replace(Regex("[\\/:*?\"<>|]"), "-")
            .replace(Regex("\\s+"), " ")
            .trim().trim('.')
            .take(120)

        fun extractYoutubeVideoId(raw: String?): String? {
            if (raw.isNullOrBlank()) return null
            return runCatching {
                val uri = Uri.parse(raw.trim())
                val host = uri.host?.lowercase(Locale.ROOT).orEmpty().removePrefix("www.").removePrefix("m.")
                val id = when {
                    host == "youtu.be" -> uri.pathSegments.firstOrNull()
                    host == "youtube.com" || host.endsWith(".youtube.com") -> when {
                        uri.path == "/watch" -> uri.getQueryParameter("v")
                        uri.pathSegments.firstOrNull() == "shorts" -> uri.pathSegments.getOrNull(1)
                        uri.pathSegments.firstOrNull() == "live" -> uri.pathSegments.getOrNull(1)
                        uri.pathSegments.firstOrNull() == "embed" -> uri.pathSegments.getOrNull(1)
                        else -> null
                    }
                    else -> null
                }
                id?.takeIf { it.matches(Regex("[A-Za-z0-9_-]{6,20}")) }
            }.getOrNull()
        }
    }
}
