package com.teraphonia.breakmonster

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Process
import java.util.concurrent.atomic.AtomicBoolean

/** One-bar 120 BPM real drumstick loop, subtle hall and reduced tempo delay. */
internal class TransitionMetronome(private val context: Context) {
    private val running = AtomicBoolean(false)
    @Volatile private var worker: Thread? = null

    @Synchronized fun start() {
        if (running.get()) return
        running.set(true)
        worker = Thread({ playLoop() }, "BrakeMonster-TransitionClick").apply {
            isDaemon = true
            start()
        }
    }

    @Synchronized fun stop() {
        running.set(false)
        worker?.interrupt()
        worker = null
    }

    private fun playLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
        val sampleRate = 22050
        val bufferSize = AudioTrack.getMinBufferSize(sampleRate,
            AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(4096)
        val track = try {
            AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM).build()
        } catch (_: Exception) { running.set(false); return }
        try {
            // One 2-second bar at 120 BPM, repeated; lower previous playback level by another 1.5 dB.
            track.setVolume((0.35 * Math.pow(10.0, -12.5 / 20.0)).toFloat())
            val bytes = context.assets.open("monster_sticks_1bar_120bpm.pcm").use { it.readBytes() }
            val samples = ShortArray(bytes.size / 2) { n ->
                val lo = bytes[2 * n].toInt() and 0xff
                val hi = bytes[2 * n + 1].toInt()
                ((hi shl 8) or lo).toShort()
            }
            track.play()
            while (running.get() && !Thread.currentThread().isInterrupted) {
                var offset = 0
                while (running.get() && !Thread.currentThread().isInterrupted && offset < samples.size) {
                    val written = track.write(samples, offset, minOf(256, samples.size - offset), AudioTrack.WRITE_BLOCKING)
                    if (written <= 0) break
                    offset += written
                }
            }
        } catch (_: Exception) {
            // Stop may interrupt playback while changing songs.
        } finally {
            runCatching { track.pause(); track.flush(); track.release() }
        }
    }
}
