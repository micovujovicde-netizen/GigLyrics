package com.teraphonia.breakmonster

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Process
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/** Quiet 120 BPM 4/4 wood-click between tracks; no Cubase sample is bundled. */
internal class TransitionMetronome {
    private val running = AtomicBoolean(false)
    @Volatile private var worker: Thread? = null

    @Synchronized fun start() {
        if (running.get()) return
        running.set(true)
        worker = Thread({ playLoop() }, "BrakeMonster-TransitionClick").apply {
            isDaemon = true
            start()
        }
    }

    @Synchronized fun stop() {
        running.set(false)
        worker?.interrupt()
        worker = null
    }

    /** Synthesized wooden drumsticks: a short woody impact, subtle room tail and
     * tempo-locked eighth-note echo. No external copyrighted samples required. */
    private fun stickBeat(accent: Boolean, sampleRate: Int): ShortArray {
        val beatLength = sampleRate / 2 // 120 BPM
        val output = DoubleArray(beatLength)
        val amplitude = if (accent) 11000.0 else 8000.0
        var noiseState = if (accent) 0x13451 else 0x23917
        val dryLength = (sampleRate * 0.048).toInt()
        val dry = DoubleArray(dryLength) { n ->
            val t = n.toDouble() / sampleRate
            noiseState = noiseState * 1664525 + 1013904223
            val noise = ((noiseState ushr 8) and 0xffff) / 32767.5 - 1.0
            // Two resonances approximate the bright crack and wooden body.
            val body = sin(2 * PI * 980.0 * t) * exp(-t * 115.0)
            val wood = sin(2 * PI * 570.0 * t) * exp(-t * 92.0)
            val snap = noise * exp(-t * 260.0)
            amplitude * (0.51 * body + 0.32 * wood + 0.17 * snap)
        }
        fun addTap(start: Int, gain: Double) {
            for (n in dry.indices) {
                val at = start + n
                if (at >= output.size) break
                output[at] += dry[n] * gain
            }
        }
        addTap(0, 1.0)
        // Very light, short small-stage reverb (10% wet, 350 ms decay).
        for (delayMs in intArrayOf(31, 53, 79, 113, 157, 211, 277, 337)) {
            val delay = delayMs * sampleRate / 1000
            val gain = 0.10 * exp(-delayMs / 160.0) / 2.0
            addTap(delay, gain)
        }
        // 1/8-note delay at 120 BPM = 250 ms, 6% wet; one 8% feedback repeat.
        addTap(sampleRate / 4, 0.06)
        // The feedback repeat falls exactly on the next beat, so omit it to
        // prevent an extra click colliding with the following downbeat.
        return ShortArray(beatLength) { n ->
            output[n].toInt().coerceIn(-32768, 32767).toShort()
        }
    }

    private fun playLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
        val sampleRate = 22050
        val bufferSize = AudioTrack.getMinBufferSize(sampleRate,
            AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(4096)
        val track = try {
            AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM).build()
        } catch (_: Exception) { running.set(false); return }
        try {
            // Exact same playback gain as the confirmed audible metronome.
            track.setVolume((0.35 * Math.pow(10.0, -4.0 / 20.0)).toFloat())
            track.play()
            val strong = stickBeat(true, sampleRate)
            val normal = stickBeat(false, sampleRate)
            var beat = 0
            while (running.get() && !Thread.currentThread().isInterrupted) {
                val samples = if (beat % 4 == 0) strong else normal
                var offset = 0
                while (running.get() && !Thread.currentThread().isInterrupted && offset < samples.size) {
                    val count = minOf(512, samples.size - offset)
                    val written = track.write(samples, offset, count, AudioTrack.WRITE_BLOCKING)
                    if (written <= 0) break
                    offset += written
                }
                beat++
            }
        } catch (_: Exception) {
            // Playback may interrupt blocking writes during a player transition.
        } finally {
            runCatching { track.pause(); track.flush(); track.release() }
        }
    }
}
