package com.teraphonia.breakmonster

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Process
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/** Quiet 120 BPM 4/4 wood-click between tracks; no Cubase sample is bundled. */
internal class TransitionMetronome {
    private val running = AtomicBoolean(false)
    @Volatile private var worker: Thread? = null

    @Synchronized fun start() {
        if (running.get()) return
        running.set(true)
        worker = Thread({ playLoop() }, "BrakeMonster-TransitionClick").apply {
            isDaemon = true
            start()
        }
    }

    @Synchronized fun stop() {
        running.set(false)
        worker?.interrupt()
        worker = null
    }

    private fun playLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
        val sampleRate = 22050
        val clickSamples = 1150
        val bufferSize = (AudioTrack.getMinBufferSize(sampleRate,
            AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)).coerceAtLeast(4096)
        val track = try {
            AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM).build()
        } catch (_: Exception) { running.set(false); return }
        try {
            // Retain the requested -4 dB attenuation, but use an audible click signal.
            // Previous effective peak was around -41 dBFS and could be inaudible on a tablet.
            track.setVolume((0.35 * Math.pow(10.0, -4.0 / 20.0)).toFloat())
            track.play()
            var beat = 0
            val silence = ShortArray(sampleRate / 2 - clickSamples)
            while (running.get() && !Thread.currentThread().isInterrupted) {
                val accent = beat % 4 == 0
                val tone = if (accent) 1150.0 else 850.0
                val click = ShortArray(clickSamples) { n ->
                    val t = n.toDouble() / sampleRate
                    val envelope = exp(-t * 95.0)
                    (sin(2 * PI * tone * t) * envelope * (if (accent) 11000 else 8000)).toInt().toShort()
                }
                if (!running.get()) break
                track.write(click, 0, click.size, AudioTrack.WRITE_BLOCKING)
                // Feed silence in small blocks to allow immediate stop when video starts.
                var offset = 0
                while (running.get() && !Thread.currentThread().isInterrupted && offset < silence.size) {
                    val size = minOf(1024, silence.size - offset)
                    track.write(silence, offset, size, AudioTrack.WRITE_BLOCKING)
                    offset += size
                }
                beat++
            }
        } catch (_: Exception) {
            // Player lifecycle may interrupt blocking audio writes.
        } finally {
            runCatching { track.pause(); track.flush(); track.release() }
        }
    }
}
