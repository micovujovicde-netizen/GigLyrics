package com.teraphonia.breakmonster

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Process
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/** One-bar 120 BPM real drumstick loop, subtle hall and reduced tempo delay. */
internal class TransitionMetronome(private val context: Context) {
    private val running = AtomicBoolean(false)
    private val generation = AtomicInteger(0)
    @Volatile private var worker: Thread? = null
    @Volatile private var activeTrack: AudioTrack? = null
    private val baseVolume = (0.35 * Math.pow(10.0, -16.5 / 20.0)).toFloat()

    @Synchronized fun start() {
        if (running.get()) return
        running.set(true)
        val token = generation.incrementAndGet()
        worker = Thread({ playLoop(token) }, "BrakeMonster-TransitionClick").apply {
            isDaemon = true
            start()
        }
    }

    @Synchronized fun stop() {
        running.set(false)
        generation.incrementAndGet()
        worker?.interrupt()
        // Silence the existing AudioTrack immediately, before the next YouTube
        // PLAYING event. Interrupt alone cannot cancel a blocking PCM write.
        runCatching { activeTrack?.setVolume(0f) }
        worker = null
    }

    private fun playLoop(token: Int) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
        val sampleRate = 22050
        val bufferSize = AudioTrack.getMinBufferSize(sampleRate,
            AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(4096)
        val track = try {
            AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM).build()
        } catch (_: Exception) { running.set(false); return }
        try {
            // One 2-second bar at 120 BPM, repeated; playback gain reduced by an additional 4 dB.
            track.setVolume(0f)
            activeTrack = track
            val bytes = context.assets.open("monster_sticks_1bar_120bpm.pcm").use { it.readBytes() }
            val samples = ShortArray(bytes.size / 2) { n ->
                val lo = bytes[2 * n].toInt() and 0xff
                val hi = bytes[2 * n + 1].toInt()
                ((hi shl 8) or lo).toShort()
            }
            if (!running.get() || generation.get() != token) return
            track.play()
            // Small attack ramp removes clicks at the beginning of a transition.
            track.setVolume(baseVolume)
            while (running.get() && generation.get() == token && !Thread.currentThread().isInterrupted) {
                var offset = 0
                while (running.get() && !Thread.currentThread().isInterrupted && offset < samples.size) {
                    val written = track.write(samples, offset, minOf(256, samples.size - offset), AudioTrack.WRITE_BLOCKING)
                    if (written <= 0) break
                    offset += written
                }
            }
        } catch (_: Exception) {
            // Stop may interrupt playback while changing songs.
        } finally {
            runCatching { track.setVolume(0f); track.pause(); track.flush(); track.release() }
            if (activeTrack === track) activeTrack = null
        }
    }
}
