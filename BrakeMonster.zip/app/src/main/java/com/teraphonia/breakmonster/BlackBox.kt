package com.teraphonia.breakmonster

import android.os.SystemClock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BlackBox {
    private const val MAX = 500
    private val lines = ArrayDeque<String>()
    private val clock = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    @Synchronized fun log(event: String) {
        val line = "${clock.format(Date())} [${Thread.currentThread().name}] $event"
        if (lines.size >= MAX) lines.removeFirst()
        lines.addLast(line)
    }
    inline fun <T> timed(name: String, block: () -> T): T {
        val t = SystemClock.elapsedRealtime()
        log("START $name")
        return try { block() } catch (e: Throwable) { log("ERROR $name ${e.javaClass.simpleName}: ${e.message}"); throw e }
        finally {
            val ms = SystemClock.elapsedRealtime() - t
            val flag = when { ms >= 5000 -> " !!!>5s"; ms >= 2000 -> " !!>2s"; ms >= 500 -> " !>500ms"; else -> "" }
            log("END $name ${ms}ms$flag")
        }
    }
    @Synchronized fun report(version: String): String {
        val rt=Runtime.getRuntime(); val used=(rt.totalMemory()-rt.freeMemory())/1024/1024
        return buildString {
            appendLine("BRAKEMONSTER BLACK BOX")
            appendLine("Version: $version")
            appendLine("Device: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}; Android ${android.os.Build.VERSION.RELEASE} (SDK ${android.os.Build.VERSION.SDK_INT})")
            appendLine("Memory: ${used}MB used / ${rt.maxMemory()/1024/1024}MB max")
            appendLine("--- LAST ${lines.size} EVENTS ---")
            lines.forEach { appendLine(it) }
        }
    }
}
