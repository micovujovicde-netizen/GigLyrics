package com.teraphonia.breakmonster

import android.os.SystemClock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BlackBox {
    private const val MAX = 500
    private var appContext: android.content.Context? = null
    private var startupReport: String? = null
    private const val LOG_FILE = "blackbox_last_session.txt"
    private const val CRASH_FILE = "blackbox_crash.txt"
    @Synchronized fun initialize(context: android.content.Context) {
        appContext = context.applicationContext
        startupReport = runCatching { context.getFileStreamPath(CRASH_FILE).takeIf { it.exists() }?.readText() }.getOrNull()
            ?: runCatching { context.getFileStreamPath(LOG_FILE).takeIf { it.exists() }?.readText() }.getOrNull()
        log("APP START pid=${android.os.Process.myPid()}")
    }
    @Synchronized fun previousReport(): String? {
        val ctx = appContext ?: return null
        val crash = runCatching { ctx.getFileStreamPath(CRASH_FILE).takeIf { it.exists() }?.readText() }.getOrNull()
        val previous = runCatching { ctx.getFileStreamPath(LOG_FILE).takeIf { it.exists() }?.readText() }.getOrNull()
        return startupReport?.takeIf { it.isNotBlank() }
    }
    @Synchronized fun acknowledgeReport() {
        appContext?.getFileStreamPath(CRASH_FILE)?.delete()
        startupReport = null
    }
    @Synchronized fun recordCrash(thread: Thread, error: Throwable) {
        val dump = "FATAL on ${thread.name}\n" + android.util.Log.getStackTraceString(error) + "\n" + report("crash")
        runCatching { appContext?.openFileOutput(CRASH_FILE, android.content.Context.MODE_PRIVATE)?.bufferedWriter()?.use { it.write(dump) } }
    }
    private val lines = ArrayDeque<String>()
    private val clock = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    @Synchronized fun log(event: String) {
        val line = "${clock.format(Date())} [${Thread.currentThread().name}] $event"
        if (lines.size >= MAX) lines.removeFirst()
        lines.addLast(line)
        runCatching {
            val ctx = appContext
            if (ctx != null) {
                val file = ctx.getFileStreamPath(LOG_FILE)
                if (file.length() > 262144L) file.writeText("[log truncated]\n")
                ctx.openFileOutput(LOG_FILE, android.content.Context.MODE_APPEND).bufferedWriter().use { it.appendLine(line) }
            }
        }
    }
    inline fun <T> timed(name: String, block: () -> T): T {
        val t = SystemClock.elapsedRealtime()
        log("START $name")
        return try { block() } catch (e: Throwable) { log("ERROR $name ${e.javaClass.simpleName}: ${e.message}"); throw e }
        finally {
            val ms = SystemClock.elapsedRealtime() - t
            val flag = when { ms >= 5000 -> " !!!>5s"; ms >= 2000 -> " !!>2s"; ms >= 500 -> " !>500ms"; else -> "" }
            log("END $name ${ms}ms$flag")
        }
    }
    @Synchronized fun report(version: String): String {
        val rt=Runtime.getRuntime(); val used=(rt.totalMemory()-rt.freeMemory())/1024/1024
        return buildString {
            appendLine("BRAKEMONSTER BLACK BOX")
            appendLine("Version: $version")
            appendLine("Device: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}; Android ${android.os.Build.VERSION.RELEASE} (SDK ${android.os.Build.VERSION.SDK_INT})")
            appendLine("Memory: ${used}MB used / ${rt.maxMemory()/1024/1024}MB max")
            appendLine("--- LAST ${lines.size} EVENTS ---")
            lines.forEach { appendLine(it) }
        }
    }
}
