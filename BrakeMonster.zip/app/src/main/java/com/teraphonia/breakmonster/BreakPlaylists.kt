package com.teraphonia.breakmonster

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.*
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject

internal data class BreakPlaylistEntry(val name:String, val uri:String, val youtube:Boolean)

internal class BreakPlaylistStore(private val context: Context) {
    private val prefs=context.getSharedPreferences("breakmonster_playlists",0)
    val lists=List(4){ mutableStateListOf<BreakPlaylistEntry>() }
    val names=List(4){ mutableStateOf(prefs.getString("name_$it","").orEmpty()) }
    var activeIndex by mutableIntStateOf(prefs.getInt("active",0).coerceIn(0,3)); private set
    init { repeat(4){ load(it) } }
    fun displayName(i:Int)=names[i].value.ifBlank { "P${i+1}" }
    fun activate(i:Int){ if(i in 0..3){ activeIndex=i; prefs.edit().putInt("active",i).apply() } }
    fun rename(i:Int,v:String){ if(i in 0..3){ names[i].value=v.trim().take(24); prefs.edit().putString("name_$i",names[i].value).apply() } }
    fun add(item:BreakItem):Boolean { val l=lists[activeIndex]; val u=item.file.uri.toString(); if(l.any{it.uri==u}) return false; l.add(BreakPlaylistEntry(item.name,u,item.isYoutube)); save(activeIndex); return true }
    fun remove(i:Int,index:Int){ if(i in 0..3 && index in lists[i].indices){lists[i].removeAt(index);save(i)} }
    fun removeUris(i:Int, uris:Set<String>){ if(i !in 0..3 || uris.isEmpty()) return; lists[i].removeAll{it.uri in uris}; save(i) }
    fun move(i:Int,from:Int,to:Int){ val l=lists[i]; if(from in l.indices && to in l.indices && from!=to){ val x=l.removeAt(from);l.add(to,x);save(i)} }
    fun moveUrisByStep(i:Int, uris:Set<String>, direction:Int):Boolean {
        if(i !in 0..3 || uris.isEmpty() || direction==0) return false
        val l=lists[i]; var moved=false
        if(direction<0){ for(n in 1 until l.size){ if(l[n].uri in uris && l[n-1].uri !in uris){ val x=l[n-1];l[n-1]=l[n];l[n]=x;moved=true } } }
        else { for(n in l.size-2 downTo 0){ if(l[n].uri in uris && l[n+1].uri !in uris){ val x=l[n+1];l[n+1]=l[n];l[n]=x;moved=true } } }
        if(moved) save(i); return moved
    }
    fun resolve(i:Int):List<BreakItem> = lists[i].mapNotNull { e -> runCatching { DocumentFile.fromSingleUri(context, Uri.parse(e.uri)) }.getOrNull()?.let { BreakItem(it,e.name,e.youtube) } }
    private fun load(i:Int){ runCatching { val a=JSONArray(prefs.getString("p$i","[]")); repeat(a.length()){ n-> val o=a.getJSONObject(n);lists[i].add(BreakPlaylistEntry(o.getString("name"),o.getString("uri"),o.optBoolean("yt"))) } } }
    private fun save(i:Int){ val a=JSONArray();lists[i].forEach{a.put(JSONObject().put("name",it.name).put("uri",it.uri).put("yt",it.youtube))};prefs.edit().putString("p$i",a.toString()).apply() }
}
