package com.teraphonia.breakmonster

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.*
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject

internal data class BreakPlaylistEntry(val name:String, val uri:String, val youtube:Boolean, val missing:Boolean=false)

/** Eight built-in playlists plus user-created lists, persisted without touching media files. */
internal class BreakPlaylistStore(private val context: Context) {
    private val prefs=context.getSharedPreferences("breakmonster_playlists",0)
    val lists=mutableStateListOf<MutableList<BreakPlaylistEntry>>()
    val names=mutableStateListOf<MutableState<String>>()
    var activeIndex by mutableIntStateOf(prefs.getInt("active",0).coerceAtLeast(0)); private set

    init {
        val n=prefs.getInt("count",8).coerceAtLeast(8)
        repeat(n){ i ->
            lists.add(mutableStateListOf())
            names.add(mutableStateOf(prefs.getString("name_$i","").orEmpty()))
            load(i)
        }
        activeIndex=activeIndex.coerceIn(0,lists.lastIndex)
    }
    val size:Int get()=lists.size
    fun displayName(i:Int)=names.getOrNull(i)?.value?.ifBlank { if(i<8) "P${i+1}" else "PLAYLIST ${i+1}" } ?: "P1"
    fun activate(i:Int){ if(i in lists.indices){ activeIndex=i; prefs.edit().putInt("active",i).apply() } }
    fun rename(i:Int,v:String){ if(i in lists.indices){ names[i].value=v.trim().take(24); prefs.edit().putString("name_$i",names[i].value).apply() } }
    fun create(name:String="") : Int {
        val i=lists.size
        lists.add(mutableStateListOf())
        names.add(mutableStateOf(name.trim().take(24)))
        prefs.edit().putInt("count",lists.size).putString("name_$i",name.trim().take(24)).apply()
        save(i); activate(i)
        return i
    }
    fun createImported(name:String, entries:List<BreakPlaylistEntry>):Int {
        val i=create(name)
        lists[i].clear(); lists[i].addAll(entries); save(i)
        return i
    }
    fun delete(i:Int){
        if(i !in lists.indices) return
        lists.removeAt(i); names.removeAt(i)
        while(lists.size<8){ lists.add(mutableStateListOf());names.add(mutableStateOf("")) }
        val e=prefs.edit().putInt("count",lists.size)
        e.remove("p$i").remove("name_$i")
        for(n in i until lists.size){ e.putString("p$n",encode(n)).putString("name_$n",names[n].value) }
        activeIndex=activeIndex.coerceAtMost(lists.lastIndex)
        e.putInt("active",activeIndex).apply()
    }
    /** One-time migration: empty P1 as explicitly requested, leaving P2+ untouched. */
    fun clearP1ForRelease58() {
        if (prefs.getBoolean("p1_cleared_release_58", false)) return
        lists[0].clear()
        save(0)
        prefs.edit().putBoolean("p1_cleared_release_58", true).apply()
    }
    fun add(item:BreakItem):Boolean = addUri(activeIndex,item.name,item.file.uri.toString(),item.isYoutube)
    fun ensureBundledP1(items:List<BreakItem>){
        items.forEach { item ->
            val uri=item.file.uri.toString()
            val name=if(item.file.name.equals("BRAKE MONSTER WELCOME SONG.mp3",true)) "BRAKE MONSTER WELCOME SONG" else item.name
            val oldIndex=lists[0].indexOfFirst { it.uri==uri || it.name.equals(name,true) }
            if(oldIndex>=0) lists[0][oldIndex]=BreakPlaylistEntry(name,uri,item.isYoutube)
            else lists[0].add(BreakPlaylistEntry(name,uri,item.isYoutube))
        }
        save(0)
    }
    fun addUri(i:Int,name:String,uri:String,youtube:Boolean):Boolean {
        if(i !in lists.indices) return false
        val l=lists[i]; if(l.any{it.uri==uri}) return false
        l.add(BreakPlaylistEntry(name,uri,youtube)); save(i); return true
    }
    /** Add an imported YouTube link while replacing stale copies of that same title/video. */
    fun addImportedYoutube(i:Int,name:String,uri:String):Boolean {
        if(i !in lists.indices) return false
        val incomingId=readYoutubeId(uri) ?: return false
        val l=lists[i]
        val alreadyPresent=l.any{it.uri==uri}
        val stale=l.filter { entry ->
            if(!entry.youtube || !entry.name.equals(name,true) || entry.uri==uri) false
            else {
                val oldId=readYoutubeId(entry.uri)
                oldId==null || oldId==incomingId
            }
        }.map{it.uri}.toSet()
        if(stale.isNotEmpty()) l.removeAll{it.uri in stale}
        if(alreadyPresent) { if(stale.isNotEmpty()) save(i); return false }
        l.add(BreakPlaylistEntry(name,uri,true)); save(i); return true
    }
    private fun readYoutubeId(value:String):String? = runCatching {
        val uri=Uri.parse(value)
        val text=if(uri.scheme=="file") java.io.File(uri.path.orEmpty()).takeIf{it.isFile}?.readText(Charsets.UTF_8)
            else context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use{it.readText()}
        BreakMonsterModel.extractYoutubeVideoId(text)
    }.getOrNull()
    fun renameEntry(i:Int,uri:String,newName:String):Boolean {
        if(i !in lists.indices || newName.isBlank()) return false
        val idx=lists[i].indexOfFirst{it.uri==uri}
        if(idx<0)return false
        lists[i][idx]=lists[i][idx].copy(name=newName.trim().take(120))
        save(i);return true
    }
    fun moveEntryTo(source:Int,destination:Int,uri:String):Boolean {
        if(source !in lists.indices || destination !in lists.indices || source==destination)return false
        val entry=lists[source].firstOrNull{it.uri==uri}?:return false
        if(lists[destination].any{it.uri==uri})return false
        lists[destination].add(entry);save(destination)
        lists[source].removeAll{it.uri==uri};save(source)
        return true
    }
    fun remove(i:Int,index:Int){ if(i in lists.indices && index in lists[i].indices){lists[i].removeAt(index);save(i)} }
    fun removeUris(i:Int, uris:Set<String>){ if(i !in lists.indices || uris.isEmpty()) return; lists[i].removeAll{it.uri in uris}; save(i) }
    fun move(i:Int,from:Int,to:Int){ if(i !in lists.indices)return;val l=lists[i]; if(from in l.indices && to in l.indices && from!=to){ val x=l.removeAt(from);l.add(to,x);save(i)} }
    /** Reorder one stable row key relative to another and persist the new order immediately. */
    fun moveRelative(i:Int, movingUri:String, targetUri:String, after:Boolean):Boolean {
        if(i !in lists.indices || movingUri==targetUri) return false
        val l=lists[i]
        val from=l.indexOfFirst{it.uri==movingUri}
        val target=l.indexOfFirst{it.uri==targetUri}
        if(from<0 || target<0) return false
        val entry=l.removeAt(from)
        val targetAfterRemoval=l.indexOfFirst{it.uri==targetUri}
        if(targetAfterRemoval<0) { l.add(from.coerceAtMost(l.size),entry); return false }
        l.add((targetAfterRemoval+if(after)1 else 0).coerceIn(0,l.size),entry)
        save(i)
        return true
    }
    fun moveUrisByStep(i:Int, uris:Set<String>, direction:Int):Boolean {
        if(i !in lists.indices || uris.isEmpty() || direction==0) return false
        val l=lists[i]; var moved=false
        if(direction<0){ for(n in 1 until l.size){ if(l[n].uri in uris && l[n-1].uri !in uris){ val x=l[n-1];l[n-1]=l[n];l[n]=x;moved=true } } }
        else { for(n in l.size-2 downTo 0){ if(l[n].uri in uris && l[n+1].uri !in uris){ val x=l[n+1];l[n+1]=l[n];l[n]=x;moved=true } } }
        if(moved) save(i); return moved
    }
    fun resolve(i:Int):List<BreakItem> = lists.getOrNull(i).orEmpty().filterNot { it.missing }.mapNotNull { e -> runCatching { val uri=Uri.parse(e.uri); val doc=if(uri.scheme=="file") DocumentFile.fromFile(java.io.File(uri.path.orEmpty())) else DocumentFile.fromSingleUri(context,uri); doc?.let { BreakItem(it,e.name,e.youtube) } }.getOrNull() }
    fun removeMedia(uri:String){ lists.indices.forEach { i -> lists[i].removeAll{it.uri==uri};save(i) } }
    fun renameMedia(uri:String,name:String){ lists.indices.forEach { i -> var changed=false;lists[i].indices.forEach { n -> if(lists[i][n].uri==uri){lists[i][n]=lists[i][n].copy(name=name);changed=true} };if(changed)save(i) } }
    private fun load(i:Int){ runCatching { val a=JSONArray(prefs.getString("p$i","[]")); repeat(a.length()){ n-> val o=a.getJSONObject(n);lists[i].add(BreakPlaylistEntry(o.getString("name"),o.getString("uri"),o.optBoolean("yt"),o.optBoolean("missing",false))) } } }
    private fun encode(i:Int):String { val a=JSONArray();lists[i].forEach{a.put(JSONObject().put("name",it.name).put("uri",it.uri).put("yt",it.youtube).put("missing",it.missing))};return a.toString() }
    private fun save(i:Int){ prefs.edit().putString("p$i",encode(i)).apply() }
}
