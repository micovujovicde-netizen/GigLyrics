package com.teraphonia.breakmonster

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.*
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject

internal data class BreakPlaylistEntry(val name:String, val uri:String, val youtube:Boolean, val missing:Boolean=false)

/** Eight built-in playlists plus user-created lists, persisted without touching media files. */
internal class BreakPlaylistStore(private val context: Context) {
    private val prefs=context.getSharedPreferences("breakmonster_playlists",0)
    val lists=mutableStateListOf<MutableList<BreakPlaylistEntry>>()
    val names=mutableStateListOf<MutableState<String>>()
    var activeIndex by mutableIntStateOf(prefs.getInt("active",0).coerceAtLeast(0)); private set

    init {
        val n=prefs.getInt("count",8).coerceAtLeast(8)
        repeat(n){ i ->
            lists.add(mutableStateListOf())
            names.add(mutableStateOf(prefs.getString("name_$i","").orEmpty()))
            load(i)
        }
        activeIndex=activeIndex.coerceIn(0,lists.lastIndex)
    }
    val size:Int get()=lists.size
    fun displayName(i:Int)=names.getOrNull(i)?.value?.ifBlank { if(i<8) "P${i+1}" else "PLAYLIST ${i+1}" } ?: "P1"
    fun activate(i:Int){ if(i in lists.indices){ activeIndex=i; prefs.edit().putInt("active",i).apply() } }
    fun rename(i:Int,v:String){ if(i in lists.indices){ names[i].value=v.trim().take(24); prefs.edit().putString("name_$i",names[i].value).apply() } }
    fun create(name:String="") : Int {
        val i=lists.size
        lists.add(mutableStateListOf())
        names.add(mutableStateOf(name.trim().take(24)))
        prefs.edit().putInt("count",lists.size).putString("name_$i",name.trim().take(24)).apply()
        save(i); activate(i)
        return i
    }
    fun createImported(name:String, entries:List<BreakPlaylistEntry>):Int {
        val i=create(name)
        lists[i].clear(); lists[i].addAll(entries); save(i)
        return i
    }
    fun delete(i:Int){
        if(i !in lists.indices) return
        lists.removeAt(i); names.removeAt(i)
        while(lists.size<8){ lists.add(mutableStateListOf());names.add(mutableStateOf("")) }
        val e=prefs.edit().putInt("count",lists.size)
        e.remove("p$i").remove("name_$i")
        for(n in i until lists.size){ e.putString("p$n",encode(n)).putString("name_$n",names[n].value) }
        activeIndex=activeIndex.coerceAtMost(lists.lastIndex)
        e.putInt("active",activeIndex).apply()
    }
    fun add(item:BreakItem):Boolean = addUri(activeIndex,item.name,item.file.uri.toString(),item.isYoutube)
    fun ensureWelcome(item:BreakItem){
        val l=lists[0];val uri=item.file.uri.toString()
        val oldIndex=l.indexOfFirst { it.uri==uri || it.name.equals("BRAKE MONSTER",true) || it.name.equals("BRAKE MONSTER.mp3",true) }
        if(oldIndex>=0){l[oldIndex]=BreakPlaylistEntry("BRAKE MONSTER WELCOME SONG",uri,false);save(0)} else addUri(0,"BRAKE MONSTER WELCOME SONG",uri,false)
    }
    fun addUri(i:Int,name:String,uri:String,youtube:Boolean):Boolean {
        if(i !in lists.indices) return false
        val l=lists[i]; if(l.any{it.uri==uri}) return false
        l.add(BreakPlaylistEntry(name,uri,youtube)); save(i); return true
    }
    fun remove(i:Int,index:Int){ if(i in lists.indices && index in lists[i].indices){lists[i].removeAt(index);save(i)} }
    fun removeUris(i:Int, uris:Set<String>){ if(i !in lists.indices || uris.isEmpty()) return; lists[i].removeAll{it.uri in uris}; save(i) }
    fun move(i:Int,from:Int,to:Int){ if(i !in lists.indices)return;val l=lists[i]; if(from in l.indices && to in l.indices && from!=to){ val x=l.removeAt(from);l.add(to,x);save(i)} }
    fun moveUrisByStep(i:Int, uris:Set<String>, direction:Int):Boolean {
        if(i !in lists.indices || uris.isEmpty() || direction==0) return false
        val l=lists[i]; var moved=false
        if(direction<0){ for(n in 1 until l.size){ if(l[n].uri in uris && l[n-1].uri !in uris){ val x=l[n-1];l[n-1]=l[n];l[n]=x;moved=true } } }
        else { for(n in l.size-2 downTo 0){ if(l[n].uri in uris && l[n+1].uri !in uris){ val x=l[n+1];l[n+1]=l[n];l[n]=x;moved=true } } }
        if(moved) save(i); return moved
    }
    fun resolve(i:Int):List<BreakItem> = lists.getOrNull(i).orEmpty().filterNot { it.missing }.mapNotNull { e -> runCatching { val uri=Uri.parse(e.uri); val doc=if(uri.scheme=="file") DocumentFile.fromFile(java.io.File(uri.path.orEmpty())) else DocumentFile.fromSingleUri(context,uri); doc?.let { BreakItem(it,e.name,e.youtube) } }.getOrNull() }
    fun removeMedia(uri:String){ lists.indices.forEach { i -> lists[i].removeAll{it.uri==uri};save(i) } }
    fun renameMedia(uri:String,name:String){ lists.indices.forEach { i -> var changed=false;lists[i].indices.forEach { n -> if(lists[i][n].uri==uri){lists[i][n]=lists[i][n].copy(name=name);changed=true} };if(changed)save(i) } }
    private fun load(i:Int){ runCatching { val a=JSONArray(prefs.getString("p$i","[]")); repeat(a.length()){ n-> val o=a.getJSONObject(n);lists[i].add(BreakPlaylistEntry(o.getString("name"),o.getString("uri"),o.optBoolean("yt"),o.optBoolean("missing",false))) } } }
    private fun encode(i:Int):String { val a=JSONArray();lists[i].forEach{a.put(JSONObject().put("name",it.name).put("uri",it.uri).put("yt",it.youtube).put("missing",it.missing))};return a.toString() }
    private fun save(i:Int){ prefs.edit().putString("p$i",encode(i)).apply() }
}
