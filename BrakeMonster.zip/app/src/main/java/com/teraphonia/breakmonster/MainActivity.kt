package com.teraphonia.breakmonster

import android.app.PictureInPictureParams
import android.os.Build
import android.content.Context
import android.content.Intent
import android.content.MutableContextWrapper
import android.content.res.Configuration
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.os.Bundle
import android.util.Rational
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.documentfile.provider.DocumentFile
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.PlayerConstants
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.options.IFramePlayerOptions
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView
import kotlinx.coroutines.delay
import java.net.URLEncoder
import java.util.Locale

private val DeepGreen = Color(0xFF001B10)
private val PanelGreen = Color(0xE5142E21)
private val Amber = Color(0xFFFFB52E)
private val MonsterGreen = Color(0xFF86F500)
private val MutedGreen = Color(0xFF294535)

class MainActivity : ComponentActivity() {
    private val model by viewModels<BreakMonsterModel>()
    private var pipMode by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = AndroidColor.rgb(0, 27, 16)
        window.navigationBarColor = AndroidColor.rgb(0, 27, 16)
        setContent {
            BreakMonsterTheme {
                BreakMonsterApp(model = model, pipMode = pipMode, moveTaskToBack = { moveTaskToBack(true) })
            }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (model.youtubeVideoId != null && !isInPictureInPictureMode) {
            runCatching {
                enterPictureInPictureMode(
                    PictureInPictureParams.Builder()
                        .setAspectRatio(Rational(16, 9))
                        .build()
                )
            }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        pipMode = isInPictureInPictureMode
    }
}

@Composable
private fun BreakMonsterTheme(content: @Composable () -> Unit) {
    val colors = darkColorScheme(
        primary = Amber,
        secondary = MonsterGreen,
        background = DeepGreen,
        surface = DeepGreen,
        onPrimary = Color.Black,
        onSecondary = Color.Black,
        onBackground = Color.White,
        onSurface = Color.White
    )
    MaterialTheme(colorScheme = colors, content = content)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BreakMonsterApp(
    model: BreakMonsterModel,
    pipMode: Boolean,
    moveTaskToBack: () -> Unit
) {
    val context = LocalContext.current
    var showYoutubeSearchInput by remember { mutableStateOf(false) }
    var youtubeQuery by remember { mutableStateOf("") }
    var youtubeSearchUrl by remember { mutableStateOf<String?>(null) }
    var selectedForMenu by remember { mutableStateOf<BreakItem?>(null) }
    var showSavePicker by remember { mutableStateOf(false) }
    var renameMode by remember { mutableStateOf(false) }
    var renameText by remember { mutableStateOf("") }
    var playerRef by remember { mutableStateOf<YouTubePlayer?>(null) }

    LaunchedEffect(model.youtubeVideoId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (context as? MainActivity)?.setPictureInPictureParams(
                PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .setAutoEnterEnabled(model.youtubeVideoId != null)
                    .build()
            )
        }
    }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                runCatching { context.contentResolver.takePersistableUriPermission(uri, flags) }
                    .getOrElse { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                model.setRoot(uri)
            } catch (_: SecurityException) {
                Toast.makeText(context, "Folder permission nije sačuvan.", Toast.LENGTH_LONG).show()
            }
        }
    }

    LaunchedEffect(model.rootUri, model.path, model.refreshSerial) { model.refresh() }

    LaunchedEffect(model.message) {
        model.message?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            model.consumeMessage()
        }
    }

    BackHandler(enabled = !pipMode) {
        when {
            youtubeSearchUrl != null -> youtubeSearchUrl = null
            showYoutubeSearchInput -> showYoutubeSearchInput = false
            selectedForMenu != null -> selectedForMenu = null
            model.back() -> Unit
            else -> moveTaskToBack()
        }
    }

    Box(Modifier.fillMaxSize()) {
        if (!pipMode) {
            Image(
                painter = painterResource(R.drawable.breakmonster_stage),
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize()
            )

            Image(
                painter = painterResource(R.drawable.breakmonster_logo),
                contentDescription = "BreakMonster",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 8.dp)
                    .fillMaxWidth(.42f)
                    .heightIn(max = 86.dp)
            )

            BoxWithConstraints(Modifier.fillMaxSize()) {
                // Invisible hit zones sit exactly over the artwork's built-in HOME/BACK/FOLDER controls.
                Box(
                    Modifier.offset(x = maxWidth * .012f, y = maxHeight * .006f)
                        .size(width = maxWidth * .12f, height = maxHeight * .10f)
                        .semantics { contentDescription = "Break home" }
                        .combinedClickable(onClick = { model.home() }, onLongClick = {})
                )
                Box(
                    Modifier.offset(x = maxWidth * .125f, y = maxHeight * .006f)
                        .size(width = maxWidth * .14f, height = maxHeight * .10f)
                        .semantics { contentDescription = "Back one folder" }
                        .combinedClickable(onClick = { model.back() }, onLongClick = {})
                )
                Box(
                    Modifier.offset(x = maxWidth * .66f, y = maxHeight * .006f)
                        .size(width = maxWidth * .31f, height = maxHeight * .14f)
                        .semantics { contentDescription = "Choose BreakMonster folder" }
                        .combinedClickable(onClick = { folderPicker.launch(null) }, onLongClick = { folderPicker.launch(null) })
                )
            }

            if (model.rootUri == null) {
                Button(
                    onClick = { folderPicker.launch(null) },
                    colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color.Black),
                    modifier = Modifier.align(Alignment.Center).height(74.dp).padding(horizontal = 24.dp)
                ) {
                    Text("ADD BREAK FOLDER", fontSize = 24.sp, fontWeight = FontWeight.Black)
                }
            } else {
                BreakBrowserArea(
                    model = model,
                    onYoutubeSearch = { showYoutubeSearchInput = true },
                    onOpenFolder = { model.openFolder(it) },
                    onTrack = { item -> model.startLocal(item) },
                    selectedItem = selectedForMenu,
                    onSelect = { item -> selectedForMenu = item },
                    onDeselect = { selectedForMenu = null },
                    onRename = { item -> selectedForMenu = item; renameMode = true; renameText = item.name },
                    onAddFolder = { folderPicker.launch(null) },
                    youtubeSearchUrl = youtubeSearchUrl,
                    onYoutubeSelected = { id, title, url ->
                        model.selectYoutube(id, title, url)
                        youtubeSearchUrl = null
                    },
                    onYoutubeClose = { youtubeSearchUrl = null }
                )
            }

            PlaybackBar(
                model = model,
                youtubePlayer = playerRef,
                onSaveYoutube = { showSavePicker = true },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }

        model.youtubeVideoId?.let { videoId ->
            YoutubeSurface(
                videoId = videoId,
                session = model.youtubeSession,
                pipMode = pipMode,
                onPlayer = { playerRef = it },
                onPlaying = model::onYoutubePlaying,
                onCurrentSecond = model::onYoutubeCurrentSecond,
                onDuration = model::onYoutubeDuration,
                onPlaybackError = {
                    Toast.makeText(context, "YouTube video nije dostupan za embed.", Toast.LENGTH_LONG).show()
                },
                onEnded = model::onYoutubeEnded,
                modifier = if (pipMode) Modifier.fillMaxSize() else Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 10.dp, bottom = 148.dp)
                    .fillMaxWidth(.38f)
                    .aspectRatio(16f / 9f)
            )
        }
    }

    if (showYoutubeSearchInput) {
        AlertDialog(
            onDismissRequest = { showYoutubeSearchInput = false },
            title = { Text("YOUTUBE SEARCH", fontSize = 24.sp, fontWeight = FontWeight.Black) },
            text = {
                OutlinedTextField(
                    value = youtubeQuery,
                    onValueChange = { youtubeQuery = it },
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 22.sp),
                    label = { Text("Search") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val q = youtubeQuery.trim()
                        if (q.isNotBlank()) {
                            youtubeSearchUrl = "https://www.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8")
                            showYoutubeSearchInput = false
                        }
                    },
                    enabled = youtubeQuery.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color.Black)
                ) { Text("SEARCH", fontWeight = FontWeight.Black) }
            },
            dismissButton = { TextButton(onClick = { showYoutubeSearchInput = false }) { Text("CANCEL") } }
        )
    }

    selectedForMenu?.let { item ->
        if (renameMode) AlertDialog(
            onDismissRequest = { renameMode = false },
            title = { Text("RENAME", fontSize = 22.sp, fontWeight = FontWeight.Bold) },
            text = { OutlinedTextField(value = renameText, onValueChange = { renameText = it }, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(fontSize = 22.sp), modifier = Modifier.fillMaxWidth()) },
            confirmButton = { Button(onClick = { model.rename(item, renameText); renameMode = false; selectedForMenu = null }) { Text("SAVE") } },
            dismissButton = { TextButton(onClick = { renameMode = false }) { Text("CANCEL") } }
        )
    }

    if (showSavePicker) {
        var savePath by remember { mutableStateOf(emptyList<String>()) }
        val dirs = remember(savePath, model.refreshSerial) { model.saveFolderChildren(savePath) }
        AlertDialog(
            onDismissRequest = { showSavePicker = false },
            title = { Text(if (savePath.isEmpty()) "SAVE YT" else savePath.joinToString(" / "), fontWeight = FontWeight.Bold) },
            text = { LazyColumn(Modifier.heightIn(max = 420.dp)) {
                if (savePath.isNotEmpty()) item { TextButton(onClick = { savePath = savePath.dropLast(1) }) { Text("⬅ BACK", fontSize = 20.sp) } }
                items(dirs, key = { it.uri.toString() }) { d -> TextButton(onClick = { d.name?.let { savePath = savePath + it } }, modifier = Modifier.fillMaxWidth()) { Text("📁  " + (d.name ?: "Folder"), fontSize = 20.sp, modifier = Modifier.fillMaxWidth()) } }
            } },
            confirmButton = { Button(onClick = { model.saveYoutubeToFolder(savePath); showSavePicker = false }) { Text("SAVE HERE", fontWeight = FontWeight.Black) } },
            dismissButton = { TextButton(onClick = { showSavePicker = false }) { Text("CANCEL") } }
        )
    }

}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BreakBrowserArea(
    model: BreakMonsterModel,
    onYoutubeSearch: () -> Unit,
    onOpenFolder: (DocumentFile) -> Unit,
    onTrack: (BreakItem) -> Unit,
    selectedItem: BreakItem?,
    onSelect: (BreakItem) -> Unit,
    onDeselect: () -> Unit,
    onRename: (BreakItem) -> Unit,
    onAddFolder: () -> Unit,
    youtubeSearchUrl: String?,
    onYoutubeSelected: (String, String?, String) -> Unit,
    onYoutubeClose: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 118.dp, bottom = 142.dp, start = 12.dp, end = 12.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().height(64.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundModeButton(selected = true, contentDescription = "YouTube search", onClick = onYoutubeSearch) {
                YouTubeBadge(Modifier.size(34.dp))
            }
            Spacer(Modifier.width(14.dp))
            RoundModeButton(selected = model.random, contentDescription = if (model.random) "Random on" else "Sequential order", onClick = { model.updateRandom(!model.random) }) {
                Text(if (model.random) "🔀" else "⇉", fontSize = 28.sp)
            }
            Spacer(Modifier.width(14.dp))
            RoundModeButton(selected = model.repeat, contentDescription = if (model.repeat) "Repeat on" else "Repeat off", onClick = { model.updateRepeat(!model.repeat) }) {
                Text("↻", fontSize = 32.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(14.dp))
            RoundModeButton(selected = false, contentDescription = "Add folder", onClick = onAddFolder, modifier = Modifier.width(108.dp).height(58.dp)) {
                Text("ADD FOLDER", fontSize = 14.sp, fontWeight = FontWeight.Black, maxLines = 1)
            }
        }

        Box(modifier = Modifier.fillMaxSize()) {
            Column {
                Text(
                    if (youtubeSearchUrl != null) "BREAK / YOUTUBE" else if (model.path.isEmpty()) "BREAK" else "BREAK / " + model.path.joinToString(" / "),
                    color = Amber,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp)
                )
                if (youtubeSearchUrl != null) {
                    YoutubeSearchPanel(
                        url = youtubeSearchUrl,
                        onSelected = onYoutubeSelected,
                        onClose = onYoutubeClose,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                if (model.loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = MonsterGreen)
                model.error?.let { Text(it, color = Color(0xFFFF8A80), fontSize = 18.sp, modifier = Modifier.padding(12.dp)) }
                LazyColumn(Modifier.fillMaxSize()) {
                    items(model.folders, key = { it.uri.toString() }) { dir ->
                        Row(
                            Modifier.fillMaxWidth().heightIn(min = 68.dp)
                                .combinedClickable(onClick = { onOpenFolder(dir) }, onLongClick = {})
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(R.drawable.breakmonster_folder),
                                contentDescription = null,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.size(52.dp)
                            )
                            Text(
                                dir.name ?: "Folder",
                                color = Color.White,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.weight(1f).padding(start = 8.dp)
                            )
                        }
                        HorizontalDivider(color = Color.White.copy(alpha = .08f))
                    }
                    itemsIndexed(model.tracks, key = { _, it -> it.file.uri.toString() }) { index, item ->
                        val active = model.localTrackUri == item.file.uri.toString()
                        val selected = selectedItem?.file?.uri == item.file.uri
                        Row(
                            Modifier.fillMaxWidth().heightIn(min = 68.dp)
                                .background(if (selected) Amber.copy(alpha=.20f) else if (active) Color(0x77383838) else Color.Transparent)
                                .pointerInput(item.file.uri) {
                                    var dragTotal = 0f
                                    detectDragGesturesAfterLongPress(
                                        onDragStart = { onSelect(item); dragTotal = 0f },
                                        onDragEnd = { dragTotal = 0f }, onDragCancel = { dragTotal = 0f },
                                        onDrag = { change, amount ->
                                            change.consume(); dragTotal += amount.y
                                            val currentIndex = model.tracks.indexOfFirst { it.file.uri == item.file.uri }
                                            if (dragTotal > 55f && currentIndex in 0 until model.tracks.lastIndex) { model.moveTrack(currentIndex, currentIndex + 1); dragTotal = 0f }
                                            else if (dragTotal < -55f && currentIndex > 0) { model.moveTrack(currentIndex, currentIndex - 1); dragTotal = 0f }
                                        }
                                    )
                                }
                                .combinedClickable(onClick = { if (selected) onDeselect() else onTrack(item) }, onLongClick = { onSelect(item) })
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(item.name, color = Color.White, fontSize = 22.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium, modifier = Modifier.weight(1f))
                            if (active) { Spacer(Modifier.width(8.dp)); Text(if (model.localPlaying) "▶" else "Ⅱ", color = MonsterGreen, fontSize = 20.sp) }
                            if (item.isYoutube) { Spacer(Modifier.width(8.dp)); YouTubeBadge(Modifier.size(34.dp)) }
                            if (selected) { Spacer(Modifier.width(8.dp)); Button(onClick = { onRename(item) }, contentPadding = PaddingValues(horizontal=10.dp, vertical=2.dp), modifier=Modifier.height(40.dp)) { Text("RENAME", fontSize=13.sp, fontWeight=FontWeight.Black) } }
                        }
                        HorizontalDivider(color = Color.White.copy(alpha = .08f))
                    }
                    if (!model.loading && model.folders.isEmpty() && model.tracks.isEmpty()) {
                        item {
                            Text("Folder je prazan.", color = Color.White.copy(alpha = .7f), fontSize = 20.sp, modifier = Modifier.padding(18.dp))
                        }
                    }
                }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun RoundModeButton(
    selected: Boolean,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier.size(58.dp),
    content: @Composable BoxScope.() -> Unit
) {
    val bg = if (selected) Amber else MutedGreen
    val border = if (selected) Color.White.copy(alpha = .55f) else Color.Black.copy(alpha = .4f)
    Box(
        modifier = modifier.clip(RoundedCornerShape(18.dp))
            .background(bg)
            .border(2.dp, border, RoundedCornerShape(18.dp))
            .semantics { this.contentDescription = contentDescription }
            .combinedClickable(onClick = onClick, onLongClick = {}),
        contentAlignment = Alignment.Center,
        content = content
    )
}

@Composable
private fun PlaybackBar(model: BreakMonsterModel, youtubePlayer: YouTubePlayer?, onSaveYoutube: () -> Unit, modifier: Modifier = Modifier) {
    val ytActive = model.youtubeVideoId != null
    val localActive = model.localTrackUri != null
    Surface(
        color = Color(0xF500140C),
        tonalElevation = 4.dp,
        modifier = modifier.fillMaxWidth().height(140.dp).border(1.dp, Amber.copy(alpha = .65f))
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 6.dp)) {
            Text(
                when {
                    ytActive -> model.youtubeTitle ?: "YouTube"
                    localActive -> model.localTrackName ?: "BREAK"
                    else -> "BREAKMONSTER READY"
                },
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(
                Modifier.fillMaxWidth().height(58.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        if (ytActive) {
                            if (model.youtubePlaying) youtubePlayer?.pause() else youtubePlayer?.play()
                        } else model.toggleLocalPause()
                    },
                    enabled = ytActive || localActive,
                    modifier = Modifier.size(width = 70.dp, height = 52.dp),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color.Black)
                ) { Text(if (if (ytActive) model.youtubePlaying else model.localPlaying) "Ⅱ" else "▶", fontSize = 26.sp, fontWeight = FontWeight.Black) }

                Button(
                    onClick = {
                        if (ytActive) {
                            youtubePlayer?.pause(); youtubePlayer?.seekTo(0f); model.stopPlayback()
                        } else model.stopPlayback()
                    },
                    enabled = ytActive || localActive,
                    modifier = Modifier.size(width = 70.dp, height = 52.dp),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MutedGreen, contentColor = Color.White)
                ) { Text("■", fontSize = 24.sp) }

                if (ytActive && model.youtubeCanSave && !model.youtubeSaved) {
                    Button(
                        onClick = onSaveYoutube,
                        modifier = Modifier.height(52.dp).weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MutedGreen, contentColor = Color.White)
                    ) { Text("SAVE YT", fontWeight = FontWeight.Black, fontSize = 17.sp) }
                } else {
                    Button(
                        onClick = { model.nextLocal() },
                        enabled = ytActive || localActive,
                        modifier = Modifier.height(52.dp).weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MutedGreen, contentColor = Color.White)
                    ) { Text("NEXT ▶", fontWeight = FontWeight.Black, fontSize = 17.sp) }
                }

                val pos = if (ytActive) (model.youtubeCurrentSecond * 1000).toInt() else model.localPosition
                val dur = if (ytActive) (model.youtubeDurationSecond * 1000).toInt() else model.localDuration
                Text("${timeLabel(pos)} / ${timeLabel(dur)}", color = MonsterGreen, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            val pos = if (ytActive) (model.youtubeCurrentSecond * 1000).toInt() else model.localPosition
            val dur = if (ytActive) (model.youtubeDurationSecond * 1000).toInt() else model.localDuration
            Slider(
                value = if (dur > 0) pos.coerceIn(0, dur).toFloat() else 0f,
                onValueChange = { value -> if (ytActive) youtubePlayer?.seekTo(value / 1000f) else model.seekLocal(value.toInt()) },
                valueRange = 0f..dur.coerceAtLeast(1).toFloat(),
                enabled = dur > 0,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

private fun timeLabel(ms: Int): String = "%d:%02d".format(Locale.ROOT, ms / 60000, ms / 1000 % 60)

@Composable
private fun YouTubeBadge(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val radius = size.minDimension * .20f
        drawRoundRect(color = Color(0xFFFF0000), cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius))
        val p = Path().apply {
            moveTo(size.width * .42f, size.height * .30f)
            lineTo(size.width * .72f, size.height * .50f)
            lineTo(size.width * .42f, size.height * .70f)
            close()
        }
        drawPath(p, Color.White)
    }
}

@Composable
private fun YoutubeSurface(
    videoId: String,
    session: Int,
    pipMode: Boolean,
    onPlayer: (YouTubePlayer?) -> Unit,
    onPlaying: (Boolean) -> Unit,
    onCurrentSecond: (Float) -> Unit,
    onDuration: (Float) -> Unit,
    onPlaybackError: () -> Unit,
    onEnded: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    key(session) {
        Box(
            modifier = modifier.background(Color.Black, RoundedCornerShape(if (pipMode) 0.dp else 10.dp))
                .then(if (pipMode) Modifier else Modifier.border(2.dp, MonsterGreen, RoundedCornerShape(10.dp)))
        ) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { uiContext ->
                    val wrapped = MutableContextWrapper(uiContext)
                    YouTubePlayerView(wrapped).apply {
                        enableAutomaticInitialization = false
                        val options = IFramePlayerOptions.Builder(wrapped)
                            .controls(0)
                            .fullscreen(0)
                            .rel(0)
                            .ivLoadPolicy(3)
                            .ccLoadPolicy(0)
                            .autoplay(1)
                            .mute(0)
                            .build()
                        val listener = object : AbstractYouTubePlayerListener() {
                            override fun onReady(youTubePlayer: YouTubePlayer) {
                                onPlayer(youTubePlayer)
                                youTubePlayer.loadVideo(videoId, 0f)
                            }
                            override fun onStateChange(youTubePlayer: YouTubePlayer, state: PlayerConstants.PlayerState) {
                                onPlaying(state == PlayerConstants.PlayerState.PLAYING)
                                if (state == PlayerConstants.PlayerState.ENDED) onEnded()
                            }
                            override fun onCurrentSecond(youTubePlayer: YouTubePlayer, second: Float) { onCurrentSecond(second) }
                            override fun onVideoDuration(youTubePlayer: YouTubePlayer, duration: Float) { onDuration(duration) }
                            override fun onError(youTubePlayer: YouTubePlayer, error: PlayerConstants.PlayerError) { onPlaybackError() }
                        }
                        initialize(listener, false, options, videoId)
                    }
                },
                update = { view -> (view.context as? MutableContextWrapper)?.baseContext = context },
                onRelease = { view ->
                    onPlayer(null)
                    runCatching { view.release() }
                }
            )
            if (!pipMode) {
                // Mini preview is intentionally display-only. Transport stays in the bottom bar.
                Box(
                    Modifier.matchParentSize().pointerInput(Unit) {
                        awaitPointerEventScope {
                            while (true) {
                                awaitPointerEvent().changes.forEach { it.consume() }
                            }
                        }
                    }
                )
            }
        }
    }
}

private class YoutubeJsBridge(
    private val web: WebView,
    private val onSelected: (String, String?, String) -> Unit
) {
    @JavascriptInterface
    fun select(url: String?, title: String?) {
        val id = BreakMonsterModel.extractYoutubeVideoId(url) ?: return
        val canonical = "https://www.youtube.com/watch?v=$id"
        web.post { onSelected(id, title?.trim(), canonical) }
    }
}

@Composable
private fun YoutubeSearchPanel(
    url: String,
    onSelected: (String, String?, String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var webView by remember { mutableStateOf<WebView?>(null) }

    Box(modifier.background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { uiContext ->
                val created = WebView(uiContext)
                webView = created
                CookieManager.getInstance().apply {
                    setAcceptCookie(true)
                    setAcceptThirdPartyCookies(created, true)
                }
                created.apply {
                    setBackgroundColor(AndroidColor.BLACK)
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = true
                    addJavascriptInterface(YoutubeJsBridge(this, onSelected), "BreakHost")
                    webChromeClient = WebChromeClient()
                    webViewClient = object : WebViewClient() {
                        private fun intercept(raw: String?): Boolean {
                            val id = BreakMonsterModel.extractYoutubeVideoId(raw) ?: return false
                            onSelected(id, null, "https://www.youtube.com/watch?v=$id")
                            return true
                        }
                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = intercept(request?.url?.toString())
                        @Suppress("DEPRECATION")
                        override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean = intercept(url)
                        override fun onPageFinished(view: WebView, pageUrl: String) {
                            super.onPageFinished(view, pageUrl)
                            // Search page stays silent; a selected result is handed to the official native embed player.
                            val js = """(function(){try{
                              document.querySelectorAll('video,audio').forEach(function(v){try{v.muted=true;v.pause();}catch(e){}});
                              if(window.__breakMonsterTap)return; window.__breakMonsterTap=true;
                              function pick(ev){try{
                                var el=ev.target; while(el&&el!==document){
                                  if(el.tagName==='A'&&el.href){
                                    var u=new URL(el.href,location.href),h=u.hostname.replace(/^www\\.|^m\\./,'');
                                    var id=null;
                                    if(h==='youtu.be') id=u.pathname.split('/').filter(Boolean)[0]||null;
                                    else if(h==='youtube.com'||h.endsWith('.youtube.com')){
                                      if(u.pathname==='/watch') id=u.searchParams.get('v');
                                      else if(u.pathname.indexOf('/shorts/')===0||u.pathname.indexOf('/live/')===0) id=u.pathname.split('/')[2]||null;
                                    }
                                    if(id&&/^[A-Za-z0-9_-]{6,20}$/.test(id)){
                                      ev.preventDefault();ev.stopPropagation();if(ev.stopImmediatePropagation)ev.stopImmediatePropagation();
                                      var t='';try{t=(el.getAttribute('title')||el.getAttribute('aria-label')||el.textContent||'').replace(/\\s+/g,' ').trim();}catch(e){}
                                      BreakHost.select('https://www.youtube.com/watch?v='+id,t);return false;
                                    }
                                  }
                                  el=el.parentElement;
                                }
                              }catch(e){}}
                              document.addEventListener('click',pick,true);
                            }catch(e){}})()"""
                            view.evaluateJavascript(js, null)
                        }
                    }
                    loadUrl(url)
                }
            },
            update = { }
        )

    }
}
