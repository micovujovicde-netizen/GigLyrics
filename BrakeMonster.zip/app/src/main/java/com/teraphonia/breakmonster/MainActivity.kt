package com.teraphonia.breakmonster

import android.graphics.Movie
import android.os.SystemClock
import android.app.PictureInPictureParams
import android.app.Activity
import android.app.PendingIntent
import android.app.RemoteAction
import android.graphics.drawable.Icon
import android.os.Build
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.MutableContextWrapper
import android.content.res.Configuration
import android.graphics.Color as AndroidColor
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.AudioAttributes
import android.net.Uri
import android.provider.MediaStore
import android.os.Bundle
import android.speech.RecognizerIntent
import android.content.pm.PackageManager
import android.util.Rational
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.IntentSenderRequest
import androidx.activity.viewModels
import androidx.compose.foundation.Canvas
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.zIndex
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.TextUnit
import androidx.core.content.ContextCompat
import androidx.compose.ui.viewinterop.AndroidView
import androidx.documentfile.provider.DocumentFile
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.PlayerConstants
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.options.IFramePlayerOptions
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.coroutines.suspendCoroutine
import kotlin.coroutines.resume
import java.net.URLEncoder
import java.util.Locale

private val DeepGreen = Color(0xFF001B10)
private val PanelGreen = Color(0xE5142E21)
private val Amber = Color(0xFFFFB52E)
private val MonsterGreen = Color(0xFF86F500)
private val MutedGreen = Color(0xFF294535)
private const val FEED_MONSTER_URL = ""

private data class GlobalSearchHit(
    val title: String,
    val location: String,
    val uri: String,
    val kind: String,
    val item: BreakItem? = null,
    val playlistIndex: Int = -1,
    val playlistItems: List<BreakItem> = emptyList(),
    val selectedIndex: Int = -1,
    val factoryCategory: String = ""
)

class MainActivity : ComponentActivity() {
    private val model by viewModels<BreakMonsterModel>()
    private var pipMode by mutableStateOf(false)
    private var showReturnLogo by mutableStateOf(false)
    private var returnLogoPending = false
    private var introPlayer: MediaPlayer? = null
    private var introWasPlaying = false
    // Playlist file selection must never trigger PiP.
    private var playlistPickerOpen = false
    fun isPlaylistPickerOpen() = playlistPickerOpen
    fun setPlaylistPickerOpen(open: Boolean) {
        playlistPickerOpen = open
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            runCatching {
                setPictureInPictureParams(PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .setAutoEnterEnabled(!open && model.youtubeVideoId != null)
                    .build())
            }
        }
    }
    fun stopIntro() { runCatching { introPlayer?.stop() }; runCatching { introPlayer?.release() }; introPlayer = null }
    private fun startIntroIfDue() {
        val prefs = getSharedPreferences("monster_intro", MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val last = prefs.getLong("last_played", 0L)
        if (last > 0 && now >= last && now - last < 86_400_000L) return
        if (model.localTrackUri != null || model.youtubeVideoId != null) return
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (audio.getStreamVolume(AudioManager.STREAM_MUSIC) == 0 || audio.isMusicActive) return
        runCatching {
            val player = MediaPlayer.create(this, R.raw.monster_intro) ?: return
            introPlayer = player
            player.setOnCompletionListener { stopIntro() }
            player.setOnErrorListener { _, _, _ -> stopIntro(); true }
            player.start()
            introWasPlaying = true
            prefs.edit().putLong("last_played", now).apply()
        }.onFailure { stopIntro() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        BlackBox.initialize(applicationContext)
        val priorHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            BlackBox.recordCrash(thread, throwable)
            priorHandler?.uncaughtException(thread, throwable)
        }
        super.onCreate(savedInstanceState)
        window.statusBarColor = AndroidColor.rgb(0, 27, 16)
        window.navigationBarColor = AndroidColor.rgb(0, 27, 16)
        startIntroIfDue()
        setContent {
            BreakMonsterTheme {
                BreakMonsterApp(model = model, pipMode = pipMode, showReturnLogo = showReturnLogo, moveTaskToBack = { moveTaskToBack(true) })
            }
        }
    }

    override fun onStop() {
        stopIntro()
        super.onStop()
        if (!isChangingConfigurations) returnLogoPending = true
    }

    override fun onResume() {
        super.onResume()
        if (returnLogoPending && !isInPictureInPictureMode) {
            returnLogoPending = false
            showReturnLogo = true
            android.os.Handler(mainLooper).postDelayed({ showReturnLogo = false }, 650L)
        }
    }

    override fun onDestroy() { stopIntro(); super.onDestroy() }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (!playlistPickerOpen && (model.youtubeVideoId != null || model.localTrackUri != null) && !isInPictureInPictureMode) {
            runCatching {
                val builder = PictureInPictureParams.Builder()
                if (model.youtubeVideoId != null) {
                    builder.setAspectRatio(Rational(16, 9))
                } else {
                    builder.setAspectRatio(Rational(5, 1))
                    val backIntent = Intent(this, MainActivity::class.java)
                        .setAction("com.teraphonia.breakmonster.BACK_FROM_AUDIO_PIP")
                        .addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    val pending = PendingIntent.getActivity(this, 9208, backIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    builder.setActions(listOf(RemoteAction(Icon.createWithResource(this, R.mipmap.ic_launcher), "BACK", "Back to BreakMonster", pending)))
                }
                enterPictureInPictureMode(builder.build())
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // Launching this singleTask activity from the PiP BACK action restores it to foreground.
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        pipMode = isInPictureInPictureMode
    }
}

@Composable
private fun BreakMonsterTheme(content: @Composable () -> Unit) {
    val colors = darkColorScheme(
        primary = Amber,
        secondary = MonsterGreen,
        background = DeepGreen,
        surface = DeepGreen,
        onPrimary = Color.Black,
        onSecondary = Color.Black,
        onBackground = Color.White,
        onSurface = Color.White
    )
    MaterialTheme(colorScheme = colors, content = content)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BreakMonsterApp(
    model: BreakMonsterModel,
    pipMode: Boolean,
    showReturnLogo: Boolean,
    moveTaskToBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? MainActivity
    var showYoutubeSearchInput by remember { mutableStateOf(false) }
    var youtubeQuery by remember { mutableStateOf("") }
    var localQuery by remember { mutableStateOf("") }
    var globalSearchHits by remember { mutableStateOf<List<GlobalSearchHit>>(emptyList()) }
    var showGlobalSearchResults by remember { mutableStateOf(false) }
    var globalSearchJob by remember { mutableStateOf<Job?>(null) }
    var globalSearchBusy by remember { mutableStateOf(false) }
    val globalSearchScope = rememberCoroutineScope()
    LaunchedEffect(localQuery) {
        globalSearchJob?.cancel()
        globalSearchJob = null
        globalSearchBusy = false
    }
    var speechTarget by remember { mutableStateOf("local") }
    var youtubeSearchUrl by remember { mutableStateOf<String?>(null) }
    var imeNumere by remember { mutableStateOf("") }
    var showExitConfirmation by remember { mutableStateOf(false) }
    var factoryVisible by remember { mutableStateOf(false) }
    var videoExpanded by remember { mutableStateOf(false) }
    LaunchedEffect(model.youtubeSession) { videoExpanded = false }
    LaunchedEffect(model.localTrackUri, model.youtubeVideoId) {
        if (model.localTrackUri != null || model.youtubeVideoId != null) activity?.stopIntro()
    }
    var selectedForMenu by remember { mutableStateOf<BreakItem?>(null) }
    var renameMode by remember { mutableStateOf(false) }
    var renameText by remember { mutableStateOf("") }
    var deleteFileConfirm by remember { mutableStateOf(false) }
    var playerRef by remember { mutableStateOf<YouTubePlayer?>(null) }
    val transitionClick = remember { TransitionMetronome() }
    // Seeking is a separate, explicitly requested exception to the last-five-seconds rule.
    var seekTargetSecond by remember { mutableStateOf<Float?>(null) }
    var seekInProgress by remember { mutableStateOf(false) }
    LaunchedEffect(seekTargetSecond) {
        if (seekTargetSecond != null) {
            kotlinx.coroutines.delay(6000L) // fail-safe for unavailable YouTube progress callbacks
            seekTargetSecond = null
            seekInProgress = false
            transitionClick.stop()
        }
    }
    DisposableEffect(Unit) { onDispose { transitionClick.stop() } }
    LaunchedEffect(model.localTrackUri) { if (model.localTrackUri != null) transitionClick.stop() }
    val playlists = remember { BreakPlaylistStore(context) }
    var pendingMediaDelete by remember { mutableStateOf<BreakItem?>(null) }
    val mediaDeleteLauncher=rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        val item=pendingMediaDelete
        if(result.resultCode==Activity.RESULT_OK && item!=null) { model.onMediaStoreDeleteApproved(item);playlists.removeMedia(item.file.uri.toString()) }
        pendingMediaDelete=null
    }
    var pendingMediaRename by remember { mutableStateOf<Pair<BreakItem,String>?>(null) }
    val mediaWriteLauncher=rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        val pending=pendingMediaRename
        if(result.resultCode==Activity.RESULT_OK && pending!=null) {
            model.rename(pending.first,pending.second);playlists.renameMedia(pending.first.file.uri.toString(),pending.second)
        }
        pendingMediaRename=null
    }
    fun renameConfirmed(item:BreakItem,name:String) {
        if(android.os.Build.VERSION.SDK_INT>=30 && item.file.uri.authority=="media") {
            runCatching {
                pendingMediaRename=item to name
                val request=MediaStore.createWriteRequest(context.contentResolver,listOf(item.file.uri))
                mediaWriteLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
            }.onFailure { pendingMediaRename=null;Toast.makeText(context,"Android could not authorize this rename.",Toast.LENGTH_LONG).show() }
        } else { model.rename(item,name);playlists.renameMedia(item.file.uri.toString(),name) }
    }
    fun deleteConfirmed(item:BreakItem) {
        if(android.os.Build.VERSION.SDK_INT>=30 && item.file.uri.authority=="media") {
            runCatching {
                pendingMediaDelete=item
                val request=MediaStore.createDeleteRequest(context.contentResolver,listOf(item.file.uri))
                mediaDeleteLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
            }.onFailure { pendingMediaDelete=null;Toast.makeText(context,"Android could not authorize this deletion.",Toast.LENGTH_LONG).show() }
        } else model.delete(item){playlists.removeMedia(item.file.uri.toString())}
    }
    var playlistVisible by remember { mutableStateOf(false) }
    var playlistTab by remember { mutableIntStateOf(playlists.activeIndex) }
    var queueSelectionMode by remember { mutableStateOf(false) }
    var showQueueExplanation by remember { mutableStateOf(false) }
    var playlistFocusUri by remember { mutableStateOf<String?>(null) }
    var browserSection by remember { mutableStateOf("ALL MUSIC") }
    var importUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var importCursor by remember { mutableIntStateOf(0) }
    var importConflict by remember { mutableStateOf<Uri?>(null) }
    var playlistImportSource by remember { mutableStateOf(false) }
    var zipImportTarget by remember { mutableIntStateOf(-1) }
    fun prepareImportDisplay() { (context as? MainActivity)?.setPlaylistPickerOpen(true) }
    fun restoreImportDisplay() { (context as? MainActivity)?.setPlaylistPickerOpen(false) }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken=result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
        if(spoken.isNotBlank()) {
            if(speechTarget=="youtube") { youtubeQuery=spoken; youtubeSearchUrl="https://www.youtube.com/results?search_query="+URLEncoder.encode(spoken,"UTF-8") }
            else localQuery=spoken
        }
    }
    fun startVoiceSearch(target:String) {
        speechTarget=target
        val intent=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak your search")
        runCatching { speechLauncher.launch(intent) }.onFailure { Toast.makeText(context,"Voice search is not available.",Toast.LENGTH_SHORT).show() }
    }
    fun playGlobalSearchHit(hit: GlobalSearchHit) {
        showGlobalSearchResults = false
        localQuery = ""
        if(queueSelectionMode && hit.kind=="PLAYLIST") {
            val entry=playlists.lists.getOrNull(hit.playlistIndex)?.firstOrNull { it.uri==hit.uri }
            if(entry!=null) playlists.toggleQueueEntry(entry.copy(sourceKind="USER_PLAYLIST",sourcePlaylistIndex=hit.playlistIndex,sourceContext=playlists.playbackContext(hit.playlistIndex)))
            return
        }
        if(queueSelectionMode && hit.kind=="FACTORY") {
            val item=hit.playlistItems.firstOrNull { it.file.uri.toString()==hit.uri }
            if(item!=null) playlists.toggleQueueEntry(BreakPlaylistEntry(item.name,item.file.uri.toString(),item.isYoutube,sourceKind="FACTORY",sourceContext="factory:${hit.factoryCategory}"))
            return
        }
        when (hit.kind) {
            "PLAYLIST" -> {
                val current = playlists.resolve(hit.playlistIndex)
                val exact = current.indexOfFirst { it.file.uri.toString() == hit.uri }
                if (exact < 0) {
                    Toast.makeText(context, "Song unavailable", Toast.LENGTH_SHORT).show()
                    return
                }
                playlistTab = hit.playlistIndex
                playlists.activate(hit.playlistIndex)
                playlistVisible = true
                factoryVisible = false
                youtubeSearchUrl = null
                model.startPlaylist(current, exact, playlistContext = playlists.playbackContext(hit.playlistIndex))
            }
            "FACTORY" -> {
                val exact = hit.playlistItems.indexOfFirst { it.file.uri.toString() == hit.uri }
                if (exact < 0) return
                model.selectFactoryPlaylist(hit.factoryCategory)
                playlistVisible = false
                factoryVisible = true
                youtubeSearchUrl = null
                model.startPlaylist(hit.playlistItems, exact, playlistContext = "factory:${hit.factoryCategory}")
            }
            else -> {
                val item = hit.item ?: model.searchableLocalItems.firstOrNull { it.file.uri.toString() == hit.uri }
                if (item == null) {
                    Toast.makeText(context, "Song unavailable", Toast.LENGTH_SHORT).show()
                    return
                }
                if(queueSelectionMode) {
                    playlists.toggleQueueEntry(BreakPlaylistEntry(item.name,item.file.uri.toString(),item.isYoutube,sourceKind="LOCAL_SEARCH",sourceContext="local-search"))
                    showGlobalSearchResults=false
                    return
                }
                playlistVisible = false
                factoryVisible = false
                youtubeSearchUrl = null
                val itemUri = Uri.parse(item.file.uri.toString())
                browserSection = when {
                    itemUri.scheme == "file" && itemUri.path.orEmpty().contains("/YT DOWNLOADS/") -> "YT DOWNLOADS"
                    itemUri.scheme == "file" && itemUri.path.orEmpty().contains("/brakemonster_media/") -> "BRAKEMONSTER"
                    else -> "ALL MUSIC"
                }
                model.navigateToLocalItem(item)
                model.startLocal(item)
            }
        }
    }
    val audioPermission = if(Build.VERSION.SDK_INT>=33) android.Manifest.permission.READ_MEDIA_AUDIO else android.Manifest.permission.READ_EXTERNAL_STORAGE
    val musicPermissionLauncher=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if(granted) model.scanMediaStore() else Toast.makeText(context,"Music access was not granted.",Toast.LENGTH_LONG).show()
    }
    fun findMyMusic() {
        BlackBox.log("UI FIND YOUR MUSIC")
        model.home()

        if(ContextCompat.checkSelfPermission(context,audioPermission)==PackageManager.PERMISSION_GRANTED) model.scanMediaStore()
        else musicPermissionLauncher.launch(audioPermission)
    }
    fun saveYoutubeToPlaylist(destination:Int, exactName:String, onPersisted:(Boolean)->Unit = {}) {
        model.saveYoutubeToPlaylist(destination, exactName) { name, uri, isYoutube ->
            val added=playlists.addUri(destination,name,uri,isYoutube,sourceKind=if(destination==playlists.queueIndex) "SEARCH_SAVE" else "EXISTING_SELECTION",sourcePlaylistIndex=destination.takeUnless { it==playlists.queueIndex } ?: -1,sourceContext=if(destination==playlists.queueIndex) "youtube-search" else playlists.playbackContext(destination))
            val persisted=added || playlists.lists.getOrNull(destination)?.any { it.uri==uri } == true || (destination==playlists.queueIndex && playlists.isInQueue(uri))
            onPersisted(persisted)
            persisted
        }
    }
    val prefs = remember { context.getSharedPreferences("breakmonster_ui", 0) }
    fun toggleQueueSelection() {
        if (!queueSelectionMode) {
            queueSelectionMode = true
            if (!prefs.getBoolean("queueExplanationDone", false)) showQueueExplanation = true
        } else {
            queueSelectionMode = false
            playlistTab = playlists.queueIndex
            playlists.activate(playlists.queueIndex)
            playlistVisible = true
            factoryVisible = false
            youtubeSearchUrl = null
            playlistFocusUri = null
        }
    }
    var swipeFeedback by remember { mutableStateOf<Pair<Int,Int>?>(null) }
    var swipeFeedbackSequence by remember { mutableIntStateOf(0) }
    var swipeBlinkUri by remember { mutableStateOf<String?>(null) }
    var folderSwipeHint by remember { mutableStateOf(false) }
    var playlistHint by remember { mutableStateOf(false) }
    var reorderHint by remember { mutableStateOf(false) }
    var playlistReorderHint by remember { mutableStateOf(false) }
    LaunchedEffect(model.allMusicItems.size, browserSection) {
        if(browserSection=="ALL MUSIC" && model.allMusicItems.isNotEmpty() && !prefs.getBoolean("folderSwipeHintDone", false)) {
            folderSwipeHint = true
        }
    }
    LaunchedEffect(model.tracks.size, model.rootUri, model.path, browserSection) {
        if(browserSection=="ALL MUSIC" && model.rootUri!=null && model.path.isEmpty() && model.tracks.size>1 && prefs.getBoolean("folderSwipeHintDone",false) && !prefs.getBoolean("reorderGestureHintDone",false)) reorderHint=true
    }
    LaunchedEffect(playlistVisible, playlistTab, playlists.lists.getOrNull(playlistTab)?.size) {
        if(playlistVisible && (playlists.lists.getOrNull(playlistTab)?.size ?: 0) > 1 && prefs.getBoolean("playlistHintDone",false) && !prefs.getBoolean("playlistReorderGestureHintDone",false)) playlistReorderHint=true
    }
    LaunchedEffect(folderSwipeHint){ if(folderSwipeHint){ delay(8000); folderSwipeHint=false } }
    LaunchedEffect(playlistVisible, playlists.lists.getOrNull(playlistTab)?.size){
        if (playlistVisible && !prefs.getBoolean("playlistHintDone", false)) {
            playlistHint = true
            // Mark on first display, not on gesture completion: show only once per installation.
            prefs.edit().putBoolean("playlistHintDone", true).apply()
        }
    }
    LaunchedEffect(playlistHint){ if(playlistHint){ delay(14000); playlistHint=false } }
    LaunchedEffect(swipeFeedback){ if(swipeFeedback!=null){ delay(2000); swipeFeedback=null } }
    LaunchedEffect(swipeFeedbackSequence){ if(swipeBlinkUri!=null){ delay(240); swipeBlinkUri=null } }
    fun showSwipeFeedback(added:Boolean, playlist:Int){
        swipeFeedbackSequence++; swipeFeedback = swipeFeedbackResource(added, playlist) to swipeFeedbackSequence
    }

    LaunchedEffect(model.youtubeVideoId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (context as? MainActivity)?.setPictureInPictureParams(
                PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .setAutoEnterEnabled(model.youtubeVideoId != null && !((context as? MainActivity)?.isPlaylistPickerOpen() ?: false))
                    .build()
            )
        }
    }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                runCatching { context.contentResolver.takePersistableUriPermission(uri, flags) }
                    .getOrElse { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                model.setRoot(uri)
            } catch (_: SecurityException) {
                Toast.makeText(context, "Folder permission nije sačuvan.", Toast.LENGTH_LONG).show()
            }
        }
    }
    val mediaImportPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        importUris = uris; importCursor = 0; importConflict = null
        if (uris.isNotEmpty()) {
            uris.forEach { uri -> runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
            browserSection = "BRAKEMONSTER"
        }
    }
    val playlistFilePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            playlistTab = importM3uPlaylist(context, uri, model.allMusicItems, playlists)
        }
        restoreImportDisplay()
    }

    val ytMonsterZipPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && zipImportTarget == -2) {
            globalSearchScope.launch {
                val result = importYtMonsterZip(context, uri, playlists, model)
                Toast.makeText(context, result, Toast.LENGTH_LONG).show()
                restoreImportDisplay()
            }
        } else restoreImportDisplay()
        zipImportTarget = -1
    }

    LaunchedEffect(model.rootUri, model.path, model.refreshSerial) { model.refresh() }

    LaunchedEffect(importUris, importCursor, importConflict) {
        if (importCursor < importUris.size && importConflict == null) {
            val uri = importUris[importCursor]
            val name = model.importName(uri)
            if (model.importedNameExists(name)) importConflict = uri
            else { model.copyImport(uri, "cancel"); importCursor++ }
        } else if (importCursor >= importUris.size) importUris = emptyList()
    }

    fun resolveImportConflict(choice: String) {
        val uri = importConflict ?: return
        if (choice != "cancel") model.copyImport(uri, choice)
        importConflict = null; importCursor++
    }

    LaunchedEffect(model.message) {
        model.message?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            model.consumeMessage()
        }
    }

    BackHandler(enabled = !pipMode) {
        when {
            youtubeSearchUrl != null -> youtubeSearchUrl = null
            showYoutubeSearchInput -> showYoutubeSearchInput = false
            factoryVisible -> factoryVisible = false
            selectedForMenu != null -> selectedForMenu = null
            model.back() -> Unit
            else -> moveTaskToBack()
        }
    }

    Box(Modifier.fillMaxSize()) {
        if (!pipMode) {
            Image(
                painter = painterResource(R.drawable.breakmonster_stage),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().offset(y = (-54).dp)
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .15f)))

            // Keep the original stage-art header visible: HOME / BACK / logo / folder ventilation.
            BoxWithConstraints(Modifier.align(Alignment.TopCenter).fillMaxWidth().height(136.dp)) {
                val w = maxWidth
                Image(
                    painter = painterResource(R.drawable.breakmonster_logo),
                    contentDescription = "BreakMonster",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 2.dp).width(w * (.43f * 4f / 3f)).heightIn(max = 136.dp)
                )
                Box(Modifier.offset(x = w * .012f).width(w * .12f).fillMaxHeight().combinedClickable(onClick = { BlackBox.log("UI HOME"); browserSection="ALL MUSIC"; playlistVisible=false; factoryVisible=false; youtubeSearchUrl=null; model.home() }, onLongClick = {}))
                Box(Modifier.offset(x = w * .125f).width(w * .14f).fillMaxHeight().combinedClickable(onClick = { BlackBox.log("UI BACK"); model.back() }, onLongClick = {}))

                // The folder is already painted into the stage artwork. Keep the art untouched
                // and make that painted ventilation/folder area itself the folder picker target.
                Box(
                    Modifier.offset(x = w * .655f, y = 30.dp).width(w * .19f).height(96.dp)
                        .semantics { contentDescription = "Folder decoration" }
                )
            }

            BreakBrowserArea(
                    model = model,
                    onYoutubeSearch = { val q=youtubeQuery.trim(); if(q.isNotBlank()) youtubeSearchUrl="https://www.youtube.com/results?search_query="+URLEncoder.encode(q,"UTF-8") else showYoutubeSearchInput=true },
                    onFindMusic = ::findMyMusic,
                    showFindMusic = !model.mediaScanComplete,
                    firstScanBusy = model.mediaScanInProgress,
                    localQuery = localQuery,
                    onLocalQuery = { localQuery = it },
                    youtubeQuery = youtubeQuery,
                    onYoutubeQuery = { youtubeQuery = it },
                    onLocalMic = { startVoiceSearch("local") },
                    onGlobalLocalSearch = {
                        val query = localQuery.trim()
                        if (query.isNotEmpty() && !globalSearchBusy) {
                            globalSearchJob?.cancel()
                            globalSearchBusy = true
                            val localSnapshot = model.searchableLocalItems.toList()
                            val playlistSnapshot = (0 until playlists.size).map { i ->
                                Triple(i, playlists.displayName(i), playlists.lists[i].toList())
                            }
                            globalSearchJob = globalSearchScope.launch {
                                val hits = try { withContext(Dispatchers.IO) {
                                    val found = mutableListOf<GlobalSearchHit>()
                                    val factorySnapshot = model.findFactorySongs(query)
                                    localSnapshot.filter { it.name.contains(query, true) }.forEach { item ->
                                        found += GlobalSearchHit(item.name, "LOCAL MUSIC", item.file.uri.toString(), "LOCAL", item=item)
                                    }
                                    playlistSnapshot.forEach { (index, name, entries) ->
                                        val resolved = entries.filterNot { it.missing }.mapNotNull { entry ->
                                            runCatching {
                                                val entryUri = Uri.parse(entry.uri)
                                                val document = if (entryUri.scheme == "file") DocumentFile.fromFile(java.io.File(entryUri.path.orEmpty())) else DocumentFile.fromSingleUri(context, entryUri)
                                                document?.let { BreakItem(it, entry.name, entry.youtube) }
                                            }.getOrNull()
                                        }
                                        entries.filter { !it.missing && it.name.contains(query, true) }.forEach { entry ->
                                            val selected = resolved.indexOfFirst { it.file.uri.toString() == entry.uri }
                                            if (selected >= 0) found += GlobalSearchHit(entry.name, name, entry.uri, "PLAYLIST", playlistIndex=index, playlistItems=resolved, selectedIndex=selected)
                                        }
                                    }
                                    factorySnapshot.forEach { (category, matchingItems) ->
                                        val source = model.factoryItemsForSearch(category)
                                        matchingItems.forEach { item ->
                                            val selected = source.indexOfFirst { it.file.uri.toString() == item.file.uri.toString() }
                                            if (selected >= 0) found += GlobalSearchHit(item.name, "MONSTER LIBRARY / $category", item.file.uri.toString(), "FACTORY", playlistItems=source, selectedIndex=selected, factoryCategory=category)
                                        }
                                    }
                                    found.distinctBy { "${it.kind}:${it.location}:${it.uri}" }.take(200)
                                } } catch (cancelled: CancellationException) { throw cancelled } catch (error: Throwable) {
                                    globalSearchBusy = false
                                    Toast.makeText(context, "Search failed: ${error.message ?: "unavailable"}", Toast.LENGTH_SHORT).show()
                                    return@launch
                                }
                                globalSearchBusy = false
                                if (hits.isEmpty()) Toast.makeText(context, "No matching song", Toast.LENGTH_SHORT).show()
                                else if (hits.size == 1) playGlobalSearchHit(hits.single())
                                else {
                                    globalSearchHits = hits
                                    showGlobalSearchResults = true
                                }
                            }
                        }
                    },
                    onYoutubeMic = { startVoiceSearch("youtube") },
                    onOpenFolder = { model.openFolder(it) },
                    onTrack = { item -> model.startLocal(item) },
                    selectedItem = selectedForMenu,
                    onSelect = { item -> selectedForMenu = item },
                    onDeselect = { selectedForMenu = null },
                    playlistVisible = playlistVisible,
                    playlistStore = playlists,
                    activePlaylistContext = model.activePlaybackPlaylistContext,
                    queueSelectionMode = queueSelectionMode,
                    onQueueTap = ::toggleQueueSelection,
                    random = model.random,
                    repeat = model.repeat,
                    onRandom = { model.updateRandom(!model.random) },
                    onRepeat = { model.updateRepeat(!model.repeat) },
                    onCreatePlaylist = { name -> val index=playlists.create(name); playlistTab=index },
                    playlistTab = playlistTab,
                    playlistFocusUri = playlistFocusUri,
                    onPlaylistTab = { playlistTab = it; playlistFocusUri=null; playlists.activate(it) },
                    onTogglePlaylist = { playlistVisible = !playlistVisible },
                    folderSwipeHint = folderSwipeHint,
                    playlistHint = playlistHint,
                    swipeBlinkUri = swipeBlinkUri,
                    onSwipeAdded = { item ->
                        if (!prefs.getBoolean("folderSwipeHintDone", false)) {
                            prefs.edit().putBoolean("folderSwipeHintDone", true).apply()
                            if(model.rootUri!=null && model.path.isEmpty() && model.tracks.size>1 && !prefs.getBoolean("reorderGestureHintDone",false)) reorderHint=true
                        }
                        folderSwipeHint = false
                        val added = playlists.add(item)
                        if (added) {
                            swipeBlinkUri=item.file.uri.toString(); showSwipeFeedback(true, playlists.activeIndex+1)
                            Toast.makeText(context,"ADDED TO ${playlists.displayName(playlists.activeIndex)}",Toast.LENGTH_SHORT).show()
                        }
                        else Toast.makeText(context, "Već je u ${playlists.displayName(playlists.activeIndex)}", Toast.LENGTH_SHORT).show()
                    },
                    onSwipeRemoved = { pl -> showSwipeFeedback(false, pl) },
                    onPlaylistGestureLearned = {
                        prefs.edit().putBoolean("playlistHintDone", true).apply(); playlistHint=false
                        if((playlists.lists.getOrNull(playlistTab)?.size ?: 0)>1 && !prefs.getBoolean("playlistReorderGestureHintDone",false)) playlistReorderHint=true
                    },
                    youtubeSearchUrl = youtubeSearchUrl,
                    onYoutubeSelected = { id, title, url ->
                        model.selectYoutube(id, title, url)
                        imeNumere = title.orEmpty()
                        youtubeSearchUrl = null
                    },
                    onYoutubeClose = { youtubeSearchUrl = null },
                    browserSection = browserSection,
                    onBrowserSection = { browserSection = it; factoryVisible=false; playlistVisible=false; model.home() },
                    onImportMedia = { mediaImportPicker.launch(arrayOf("*/*")) },
                    onImportPlaylist = { playlistImportSource = true },
                    onImportZipAt = { index -> prepareImportDisplay(); zipImportTarget=index; ytMonsterZipPicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                    reorderHint = reorderHint,
                    onReorderGestureLearned = { prefs.edit().putBoolean("reorderGestureHintDone",true).apply(); reorderHint=false },
                    playlistReorderHint = playlistReorderHint,
                    onPlaylistReorderLearned = { prefs.edit().putBoolean("playlistReorderGestureHintDone",true).apply(); playlistReorderHint=false },
                    factoryVisible = factoryVisible,
                    factoryName = model.factoryPlaylistName,
                    factoryCategories = model.factoryCategories,
                    factoryItems = model.factoryItems,
                    factoryLoading = model.factoryLibraryLoading,
                    onOpenUserPlaylists = { factoryVisible=false; youtubeSearchUrl=null; playlistVisible=!playlistVisible },
                    onToggleFactory = { factoryVisible=!factoryVisible; playlistVisible=false; youtubeSearchUrl=null },
                    factoryRandom = model.random, factoryRepeat = model.repeat,
                    onFactoryRandom = { model.updateRandom(!model.random) },
                    onFactoryRepeat = { model.updateRepeat(!model.repeat) },
                    onFactoryPlaylist = model::selectFactoryPlaylist,
                    onMoveFactoryPlaylist = model::moveFactoryCategory,
                    onPlayFactory = { index -> model.startPlaylist(model.factoryItems, index, playlistContext = "factory:${model.factoryPlaylistName}") }
                )

            swipeFeedback?.let { (resource, sequence) ->
                key(sequence) { GestureManual(resource, Modifier.align(Alignment.TopCenter).padding(top=188.dp).fillMaxWidth().height(128.dp).zIndex(110f)) }
            }

            PlaybackBar(
                model = model,
                youtubePlayer = playerRef,
                nameValue = imeNumere,
                onNameChange = { imeNumere = it },
                onSaveYoutube = { saveYoutubeToPlaylist(playlists.queueIndex, imeNumere) },
                onTransitionNext = { if (model.youtubeVideoId != null) transitionClick.start() },
                onTransitionStop = { transitionClick.stop() },
                onSeekPreview = { dragging ->
                    seekInProgress = dragging
                    if (dragging && model.youtubeVideoId != null) transitionClick.start()
                    else if (!dragging && seekTargetSecond == null && model.youtubePlaying) transitionClick.stop()
                },
                onSeekTarget = { target ->
                    if (model.youtubeVideoId != null) {
                        seekTargetSecond = target
                        transitionClick.start()
                    }
                },
                onFeedMonster = {
                    val target = FEED_MONSTER_URL.trim()
                    if (target.isNotBlank()) {
                        val uri = Uri.parse(target)
                        if ((uri.scheme == "https" || uri.scheme == "http") && !uri.host.isNullOrBlank()) {
                            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                        }
                    }
                },
                modifier = Modifier.align(Alignment.BottomCenter)
            )


        }

        if (pipMode && model.youtubeVideoId == null && model.localTrackUri != null) {
            LocalAudioMiniPip(model = model, modifier = Modifier.fillMaxSize())
        }

        val physicalRight = if (androidx.compose.ui.platform.LocalLayoutDirection.current == androidx.compose.ui.unit.LayoutDirection.Rtl) Alignment.BottomStart else Alignment.BottomEnd
        model.youtubeVideoId?.let { videoId ->
            YoutubeSurface(
                videoId = videoId,
                session = model.youtubeSession,
                pipMode = pipMode,
                onPlayer = { playerRef = it },
                onPlaying = { playing ->
                    if (playing && !seekInProgress && seekTargetSecond == null) transitionClick.stop()
                    model.onYoutubePlaying(playing)
                },
                onCurrentSecond = { second ->
                    model.onYoutubeCurrentSecond(second)
                    val target = seekTargetSecond
                    if (target != null && !seekInProgress && kotlin.math.abs(second - target) <= 1.5f && model.youtubePlaying) {
                        seekTargetSecond = null
                        transitionClick.stop()
                    }
                },
                onDuration = model::onYoutubeDuration,
                onTap = { if (!pipMode) videoExpanded = !videoExpanded },
                onPlaybackError = { error -> model.onYoutubePlaybackError(error.name) },
                onEnded = {
                    transitionClick.start()
                    model.onYoutubeEnded()
                },
                modifier = if (pipMode) Modifier.fillMaxSize() else if (videoExpanded) Modifier
                    .align(physicalRight)
                    .padding(end = 10.dp, bottom = 148.dp)
                    .fillMaxWidth(.72f)
                    .heightIn(max = (androidx.compose.ui.platform.LocalConfiguration.current.screenHeightDp.dp * .5f - 140.dp).coerceAtLeast(120.dp))
                    .aspectRatio(16f / 9f)
                else Modifier
                    .align(physicalRight)
                    .padding(end = 10.dp, bottom = 148.dp)
                    .fillMaxWidth(.38f)
                    .aspectRatio(16f / 9f)
            )
        }

        if (!pipMode && !showReturnLogo) {
            Box(
                Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top=4.dp,end=6.dp)
                    .size(64.dp).zIndex(200f)
                    .semantics { contentDescription = "Exit app" }
                    .clickable { showExitConfirmation = true },
                contentAlignment = Alignment.Center
            ) {
                Image(painterResource(R.drawable.exit_app_trex), null, contentScale=ContentScale.Fit, modifier=Modifier.size(35.dp))
            }
        }

    }

    if(showExitConfirmation) AlertDialog(
        onDismissRequest = { showExitConfirmation = false },
        title = { Text("ARE YOU SURE?", fontSize=23.sp, fontWeight=FontWeight.Black) },
        confirmButton = {
            TextButton(onClick={
                showExitConfirmation=false
                playerRef?.pause()
                model.stopPlayback()
                activity?.finish()
            }) { Text("YES", fontWeight=FontWeight.Black) }
        },
        dismissButton = { TextButton(onClick={showExitConfirmation=false}) { Text("NO", fontWeight=FontWeight.Black) } }
    )

    if(showQueueExplanation) AlertDialog(
        onDismissRequest={showQueueExplanation=false; prefs.edit().putBoolean("queueExplanationDone",true).apply()},
        title={Text("BUILD YOUR QUEUE",fontSize=24.sp,fontWeight=FontWeight.Black)},
        text={Text("Browse your playlists or search for songs.\n\nTap any song to add it to your QUEUE. Tap it again to remove it.\n\nPress QUEUE again when finished.",fontSize=19.sp)},
        confirmButton={Button(onClick={showQueueExplanation=false; prefs.edit().putBoolean("queueExplanationDone",true).apply()}){Text("GOT IT",fontWeight=FontWeight.Black)}}
    )

    if (showYoutubeSearchInput) {
        AlertDialog(
            onDismissRequest = { showYoutubeSearchInput = false },
            title = { Text("YOUTUBE SEARCH", fontSize = 24.sp, fontWeight = FontWeight.Black) },
            text = {
                OutlinedTextField(
                    value = youtubeQuery,
                    onValueChange = { youtubeQuery = it },
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 22.sp),
                    label = { Text("Search") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val q = youtubeQuery.trim()
                        if (q.isNotBlank()) {
                            youtubeSearchUrl = "https://www.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8")
                            showYoutubeSearchInput = false
                        }
                    },
                    enabled = youtubeQuery.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color.Black)
                ) { Text("SEARCH", fontWeight = FontWeight.Black) }
            },
            dismissButton = { TextButton(onClick = { showYoutubeSearchInput = false }) { Text("CANCEL") } }
        )
    }

    if (showGlobalSearchResults) AlertDialog(
        onDismissRequest = { showGlobalSearchResults = false },
        title = { Text("LOCAL SEARCH RESULTS", fontSize = 22.sp, fontWeight = FontWeight.Black) },
        text = {
            Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState())) {
                globalSearchHits.forEach { hit ->
                    TextButton(
                        onClick = { playGlobalSearchHit(hit) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp)
                    ) {
                        Column(Modifier.fillMaxWidth()) {
                            Text(hit.title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(hit.location, color = Color(0xFFB4D38E), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { showGlobalSearchResults = false }) { Text("CLOSE") } }
    )

    if (showReturnLogo && !pipMode) {
        Box(Modifier.fillMaxSize().background(DeepGreen).zIndex(100f), contentAlignment = Alignment.Center) {
            Image(
                painter = painterResource(R.drawable.breakmonster_logo),
                contentDescription = "BreakMonster",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxWidth(.72f).heightIn(max = 220.dp)
            )
        }
    }


    selectedForMenu?.let { item ->
        if(!renameMode && !deleteFileConfirm) AlertDialog(
            onDismissRequest={selectedForMenu=null},
            title={Text(item.name,fontSize=22.sp,fontWeight=FontWeight.Bold)},
            confirmButton={TextButton(onClick={renameMode=true;renameText=item.name}){Text("RENAME",fontSize=18.sp)}},
            dismissButton={Row { TextButton(onClick={deleteFileConfirm=true}){Text("DELETE",fontSize=18.sp,color=Color(0xFFFF7B72))}; TextButton(onClick={selectedForMenu=null}){Text("CANCEL",fontSize=18.sp)} }}
        )
        if (renameMode) AlertDialog(
            onDismissRequest = { renameMode = false },
            title = { Text("RENAME", fontSize = 22.sp, fontWeight = FontWeight.Bold) },
            text = { OutlinedTextField(value = renameText, onValueChange = { renameText = it }, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(fontSize = 22.sp), modifier = Modifier.fillMaxWidth()) },
            confirmButton = { Button(onClick = { renameConfirmed(item,renameText); renameMode = false; selectedForMenu = null }) { Text("SAVE") } },
            dismissButton = { TextButton(onClick = { renameMode = false }) { Text("CANCEL") } }
        )
        if(deleteFileConfirm) AlertDialog(
            onDismissRequest={deleteFileConfirm=false;selectedForMenu=null},
            title={Text("ARE YOU SURE?",fontSize=23.sp,fontWeight=FontWeight.Black)},
            text={Text("Delete ${item.name}? This removes the real media file.",fontSize=18.sp)},
            confirmButton={Button(onClick={deleteConfirmed(item);deleteFileConfirm=false;selectedForMenu=null}){Text("DELETE",fontWeight=FontWeight.Black)}},
            dismissButton={TextButton(onClick={deleteFileConfirm=false;selectedForMenu=null}){Text("CANCEL",fontSize=18.sp)}}
        )
    }

    importConflict?.let { uri ->
        val name = model.importName(uri)
        AlertDialog(onDismissRequest={resolveImportConflict("cancel")}, title={Text("FILE ALREADY EXISTS",fontWeight=FontWeight.Black)},
            text={Text("$name is already in BRAKEMONSTER. Choose how to copy this file.",fontSize=18.sp)},
            confirmButton={TextButton(onClick={resolveImportConflict("replace")}){Text("REPLACE",fontWeight=FontWeight.Bold)}},
            dismissButton={Row { TextButton(onClick={resolveImportConflict("keep")}){Text("KEEP BOTH")}; TextButton(onClick={resolveImportConflict("cancel")}){Text("CANCEL")} }})
    }

    if (playlistImportSource) AlertDialog(onDismissRequest={playlistImportSource=false}, title={Text("IMPORT PLAYLIST",fontWeight=FontWeight.Black)},
        text={Column { Text("Import a local M3U or M3U8 playlist. Online playlist sources need official API access, which is not configured in this project.",fontSize=17.sp); Spacer(Modifier.height(10.dp)); Text("YouTube · Spotify · Apple Music: unavailable until official API access is configured.",fontSize=15.sp,color=Color.LightGray) }},
        confirmButton={TextButton(onClick={playlistImportSource=false;prepareImportDisplay();playlistFilePicker.launch(arrayOf("*/*"))}){Text("CHOOSE M3U / M3U8")}},
        dismissButton={TextButton(onClick={playlistImportSource=false}){Text("CANCEL")} })

    if (importUris.isNotEmpty() && importConflict == null) {
        // Copy requests are handled one at a time; the source document is only read.
    }

}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BreakBrowserArea(
    model: BreakMonsterModel,
    onYoutubeSearch: () -> Unit,
    onFindMusic: () -> Unit,
    showFindMusic: Boolean,
    firstScanBusy: Boolean,
    localQuery: String,
    onLocalQuery: (String) -> Unit,
    youtubeQuery: String,
    onYoutubeQuery: (String) -> Unit,
    onLocalMic: () -> Unit,
    onGlobalLocalSearch: () -> Unit,
    onYoutubeMic: () -> Unit,
    onOpenFolder: (DocumentFile) -> Unit,
    onTrack: (BreakItem) -> Unit,
    selectedItem: BreakItem?,
    onSelect: (BreakItem) -> Unit,
    onDeselect: () -> Unit,
    playlistVisible: Boolean,
    playlistStore: BreakPlaylistStore,
    activePlaylistContext: String?,
    queueSelectionMode: Boolean,
    onQueueTap: () -> Unit,
    random: Boolean,
    repeat: Boolean,
    onRandom: () -> Unit,
    onRepeat: () -> Unit,
    onCreatePlaylist: (String) -> Unit,
    playlistTab: Int,
    playlistFocusUri: String?,
    onPlaylistTab: (Int) -> Unit,
    onTogglePlaylist: () -> Unit,
    folderSwipeHint: Boolean,
    playlistHint: Boolean,
    swipeBlinkUri: String?,
    onSwipeAdded: (BreakItem) -> Unit,
    onSwipeRemoved: (Int) -> Unit,
    onPlaylistGestureLearned: () -> Unit,
    youtubeSearchUrl: String?,
    onYoutubeSelected: (String, String?, String) -> Unit,
    onYoutubeClose: () -> Unit,
    browserSection: String,
    onBrowserSection: (String) -> Unit,
    onImportMedia: () -> Unit,
    onImportPlaylist: () -> Unit,
    onImportZipAt: (Int) -> Unit,
    reorderHint: Boolean,
    onReorderGestureLearned: () -> Unit,
    playlistReorderHint: Boolean,
    onPlaylistReorderLearned: () -> Unit,
    factoryVisible: Boolean,
    factoryName: String,
    factoryCategories: List<String>,
    factoryItems: List<BreakItem>,
    factoryLoading: Boolean,
    onOpenUserPlaylists: () -> Unit,
    onToggleFactory: () -> Unit,
    onFactoryPlaylist: (String) -> Unit,
    onPlayFactory: (Int) -> Unit,
    factoryRandom: Boolean, factoryRepeat: Boolean,
    onFactoryRandom: () -> Unit, onFactoryRepeat: () -> Unit,
    onMoveFactoryPlaylist: (Int, Int) -> Unit
) {
    val baseTracks = when (browserSection) {
        "YT DOWNLOADS" -> model.ytDownloadItems
        "BRAKEMONSTER" -> model.brakeMonsterItems
        else -> model.tracks
    }
    val visibleTracks = remember(baseTracks, model.allMusicItems, localQuery) {
        if(localQuery.isBlank()) baseTracks else model.allMusicItems.filter { it.name.contains(localQuery.trim(),true) }
    }
    val localListState = rememberLazyListState()
    val activeLocalUri = model.activePlaybackItemUri ?: model.localTrackUri
    LaunchedEffect(activeLocalUri, visibleTracks) {
        val activeIndex = visibleTracks.indexOfFirst { it.file.uri.toString() == activeLocalUri }
        if (activeIndex >= 0) {
            val info = localListState.layoutInfo
            val row = info.visibleItemsInfo.firstOrNull { it.index == activeIndex }
            val threshold = info.viewportStartOffset + (info.viewportEndOffset - info.viewportStartOffset) * 2 / 3
            if (row == null && activeIndex > (info.visibleItemsInfo.lastOrNull()?.index ?: -1)) localListState.animateScrollToItem((activeIndex - 2).coerceAtLeast(0))
            else if (row != null && row.offset + row.size > threshold) localListState.animateScrollToItem((activeIndex - 2).coerceAtLeast(0))
        }
    }
    val visibleFolders = remember(model.folders,localQuery,browserSection) { if(browserSection!="ALL MUSIC") emptyList() else model.folders.filterNot { it.name?.equals(".thumbnails",true)==true }.filter { localQuery.isBlank() || it.name.orEmpty().contains(localQuery.trim(),true) } }
    Column(
        modifier = Modifier
            .fillMaxSize()
            // Browser intentionally has no panel/window of its own. The stage bitmap
            // must remain fully visible behind folders and tracks.
            .background(Color.Transparent)
            .padding(top = 120.dp, bottom = 142.dp, start = 12.dp, end = 12.dp)
    ) {
        Row(Modifier.fillMaxWidth().height(66.dp),verticalAlignment=Alignment.CenterVertically) {
            SearchInputField(
                value = youtubeQuery,
                onValueChange = onYoutubeQuery,
                placeholder = "YOUTUBE SEARCH",
                onSearch = onYoutubeSearch,
                modifier = Modifier.weight(1f).height(62.dp)
            )
            StoneButton(onClick=onYoutubeMic,active=false,modifier=Modifier.size(54.dp)){ Text("🎙",fontSize=25.sp,color=MonsterGreen) }
        }
        Spacer(Modifier.height(3.dp))
        Row(Modifier.fillMaxWidth().height(66.dp),verticalAlignment=Alignment.CenterVertically) {
            SearchInputField(
                value = localQuery,
                onValueChange = onLocalQuery,
                placeholder = "LOCAL SEARCH",
                onSearch = onGlobalLocalSearch,
                modifier = Modifier.weight(1f).height(62.dp)
            )
            StoneButton(onClick=onLocalMic,active=false,modifier=Modifier.size(54.dp)){ Text("🎙",fontSize=25.sp,color=MonsterGreen) }
        }
        Spacer(Modifier.height(44.dp))
        Row(Modifier.fillMaxWidth().height(58.dp), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f).fillMaxHeight()) {
                PlaylistStoneButton(onClick=onOpenUserPlaylists,active=playlistVisible,modifier=Modifier.fillMaxSize()) {
                    Text(if(playlistVisible) "EXIT USER PLAY LIST" else "USER PLAYLIST • P1–P8",color=Color.White,fontSize=14.sp,fontWeight=FontWeight.Black,maxLines=1,overflow=TextOverflow.Ellipsis)
                }
                if(playlistVisible) { PterodactylPerches(); PterodactylBlink(Modifier.align(Alignment.TopCenter).offset(y=(-48).dp).size(86.dp).zIndex(5f)) }
            }
            Box(Modifier.weight(1f).fillMaxHeight()) {
                PlaylistStoneButton(onClick=onToggleFactory,active=factoryVisible,modifier=Modifier.fillMaxSize()) {
                    Text(if(factoryVisible) "EXIT MONSTER PLAY LIST" else "MONSTER PLAYLIST • ${factoryName.ifBlank { "..." }}",color=Color.White,fontSize=14.sp,fontWeight=FontWeight.Black,maxLines=1,overflow=TextOverflow.Ellipsis)
                }
                if(factoryVisible) { PterodactylPerches(); PterodactylBlink(Modifier.align(Alignment.TopCenter).offset(y=(-48).dp).size(86.dp).zIndex(5f)) }
            }
        }
        RopeVolumeSlider(Modifier.fillMaxWidth().height(30.dp).padding(horizontal = 2.dp))
        Spacer(Modifier.height(4.dp))

        Box(modifier = Modifier.fillMaxSize()) {
            Column {
                Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment=Alignment.CenterVertically) {
                    Text(
                        when {
                            youtubeSearchUrl != null -> "ALL MUSIC / YOUTUBE"
                            factoryVisible -> "MONSTER PLAYLIST / $factoryName"
                            playlistVisible -> "USER PLAYLISTS / ${playlistStore.displayName(playlistTab)}"
                            browserSection != "ALL MUSIC" -> browserSection
                            model.rootUri == null || model.path.isEmpty() -> "ALL MUSIC"
                            else -> "ALL MUSIC / " + model.path.joinToString(" / ")
                        },
                        color = Amber,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f).padding(start = 14.dp)
                    )
                    PlaylistStoneButton(
                        onClick=onQueueTap,
                        active=queueSelectionMode,
                        redActive=queueSelectionMode,
                        queueTone=true,
                        modifier=Modifier.weight(1f).height(42.dp)
                    ) {
                        Text("QUEUE",color=Color.White,fontSize=17.sp,fontWeight=FontWeight.Black,maxLines=1,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())
                    }
                }
                if (youtubeSearchUrl != null) {
                    YoutubeSearchPanel(
                        url = youtubeSearchUrl,
                        onSelected = onYoutubeSelected,
                        onClose = onYoutubeClose,
                        modifier = Modifier.fillMaxSize()
                    )
                } else if (playlistVisible) {
                    BreakPlaylistPanel(
                        store = playlistStore, selected = playlistTab, onSelected = onPlaylistTab, onImportPlaylist=onImportPlaylist, onImportZipAt=onImportZipAt,
                        playingPlaylistContext = activePlaylistContext,
                        queueSelectionMode=queueSelectionMode,
                        onQueueTap=onQueueTap,
                        onExportQueue={ name -> playlistStore.exportQueue(name) },
                        random=random, repeat=repeat, onRandom=onRandom, onRepeat=onRepeat,
                        localQuery=localQuery, onCreatePlaylist=onCreatePlaylist,
                        showHint = playlistHint, onGestureLearned = onPlaylistGestureLearned,
                        showReorderHint=playlistReorderHint, onReorderGestureLearned=onPlaylistReorderLearned,
                        onSwipeRemoved = onSwipeRemoved,
                        playingUri = model.activePlaybackItemUri ?: model.localTrackUri,
                        focusUri = playlistFocusUri,
                        onPlay = { uri ->
                            if(queueSelectionMode) return@BreakPlaylistPanel
                            val resolved=playlistStore.resolve(playlistTab)
                            val index=resolved.indexOfFirst { it.file.uri.toString()==uri }
                            if(index>=0) model.startPlaylist(resolved,index,playlistContext=playlistStore.playbackContext(playlistTab))
                        }
                    )
                } else if (factoryVisible) {
                    FactoryPlaylistPanel(
                        loading = factoryLoading,
                        categories = factoryCategories,
                        selected = factoryName,
                        songs = factoryItems,
                        queueSelectionMode = queueSelectionMode,
                        playlistStore = playlistStore,
                        onSelect = onFactoryPlaylist,
                        onMove = onMoveFactoryPlaylist,
                        onPlay = onPlayFactory,
                        playingUri = model.activePlaybackItemUri ?: model.localTrackUri,
                        playingPlaylistContext = activePlaylistContext,
                        random = factoryRandom, repeat = factoryRepeat,
                        onRandom = onFactoryRandom, onRepeat = onFactoryRepeat,
                        onRestoreFactory = model::restoreHiddenFactoryEntries,
                        onMoveSong = model::moveFactorySong,
                        modifier = Modifier.fillMaxSize()
                    )
                } else if (showFindMusic) {
                    Spacer(Modifier.weight(1f))
                    StoneButton(onClick=onFindMusic,active=!firstScanBusy,modifier=Modifier.fillMaxWidth().height(72.dp)){
                        Text(if(firstScanBusy) "WAIT..." else "FIND YOUR MUSIC",color=Color.White,fontSize=22.sp,fontWeight=FontWeight.Black)
                    }
                    Spacer(Modifier.weight(1f))
                } else {
                if (browserSection == "BRAKEMONSTER") {
                    Row(Modifier.fillMaxWidth().padding(horizontal=8.dp, vertical=2.dp), horizontalArrangement=Arrangement.End) {
                        PlaylistStoneButton(onClick=onImportMedia,active=true,modifier=Modifier.width(156.dp).height(38.dp)) { StoneLabel("IMPORT",Color.White,12.sp) }
                    }
                }
                if (model.loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = MonsterGreen)
                model.error?.let { Text(it, color = Color(0xFFFF8A80), fontSize = 18.sp, modifier = Modifier.padding(12.dp)) }
                LazyColumn(Modifier.fillMaxSize(), state=localListState) {
                    if(folderSwipeHint && visibleTracks.isNotEmpty() && browserSection=="ALL MUSIC") item { GestureManual(R.drawable.folder_swipe_hint, Modifier.fillMaxWidth().height(86.dp)) }
                    if(reorderHint && browserSection=="ALL MUSIC" && model.rootUri!=null && model.path.isEmpty() && visibleTracks.size>1) item { ReorderGestureHelp(Modifier.fillMaxWidth().height(44.dp)) }
                    // Defence-in-depth: never render Android/media thumbnail cache folders,
                    // even if a provider returns one between model refreshes.
                    items(visibleFolders, key = { it.uri.toString() }) { dir ->
                        Row(
                            Modifier.fillMaxWidth().heightIn(min = 54.dp)
                                .combinedClickable(onClick = { onOpenFolder(dir) }, onLongClick = {})
                                .padding(horizontal = 10.dp, vertical = 1.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(R.drawable.karamonster_folder),
                                contentDescription = null,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.padding(start = 6.dp).size((64f * 2f / 3f).dp)
                            )
                            Text(
                                dir.name ?: "Folder",
                                color = Color.White,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.weight(1f).padding(start = 8.dp)
                            )
                        }
                        HorizontalDivider(color = Color.White.copy(alpha = .08f))
                    }
                    itemsIndexed(visibleTracks, key = { _, it -> it.file.uri.toString() }) { index, item ->
                        val active = (model.activePlaybackItemUri ?: model.localTrackUri) == item.file.uri.toString()
                        val selected = selectedItem?.file?.uri == item.file.uri
                        Row(
                            Modifier.fillMaxWidth().heightIn(min = 54.dp)
                                .background(if(swipeBlinkUri == item.file.uri.toString()) MonsterGreen.copy(alpha=.55f) else if(queueSelectionMode && playlistStore.isInQueue(item.file.uri.toString())) Color.Transparent else if(queueSelectionMode) Color(0xB30A2417) else if(active) Amber.copy(alpha=.5f) else if (selected) Amber.copy(alpha=.20f) else Color.Transparent)
                                .pointerInput(item.file.uri, playlistStore.activeIndex) {
                                    var dx = 0f
                                    detectHorizontalDragGestures(onDragStart={dx=0f}, onHorizontalDrag={c,a->dx+=a;if(kotlin.math.abs(dx)>12f)c.consume()}, onDragEnd={ if(dx>90.dp.toPx()) onSwipeAdded(item); dx=0f }, onDragCancel={dx=0f})
                                }
                                .pointerInput(item.file.uri) {
                                    var dragTotal = 0f
                                    detectDragGesturesAfterLongPress(
                                        onDragStart = { onSelect(item); dragTotal = 0f },
                                        onDragEnd = { dragTotal = 0f }, onDragCancel = { dragTotal = 0f },
                                        onDrag = { change, amount ->
                                            change.consume(); dragTotal += amount.y
                                            val currentIndex = model.tracks.indexOfFirst { it.file.uri == item.file.uri }
                                            if (kotlin.math.abs(dragTotal) > 55f) {
                                                onReorderGestureLearned()
                                                if (dragTotal > 0f && currentIndex in 0 until model.tracks.lastIndex) model.moveTrack(currentIndex, currentIndex + 1)
                                                else if (dragTotal < 0f && currentIndex > 0) model.moveTrack(currentIndex, currentIndex - 1)
                                                dragTotal = 0f
                                            }
                                        }
                                    )
                                }
                                .combinedClickable(onClick = {
                                    if(queueSelectionMode) playlistStore.toggleQueueEntry(BreakPlaylistEntry(item.name,item.file.uri.toString(),item.isYoutube,sourceKind="LOCAL_BROWSER",sourceContext="browser:$browserSection"))
                                    else if (selected) onDeselect() else onTrack(item)
                                }, onLongClick = { onSelect(item) })
                                .padding(horizontal = 12.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(item.name, color = Color.White, fontSize = 22.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium, modifier = Modifier.weight(1f))
                            if (active) { Spacer(Modifier.width(8.dp)); Text(if (model.localPlaying) "▶" else "Ⅱ", color = MonsterGreen, fontSize = 20.sp) }
                            if (item.isYoutube) { Spacer(Modifier.width(8.dp)); YouTubeBadge(Modifier.size(34.dp)) }
                            else { Spacer(Modifier.width(8.dp)); MediaTypeBadge(item.file.extensionLower()) }
                        }
                        HorizontalDivider(color = Color.White.copy(alpha = .08f))
                    }
                    if (!model.loading && model.folders.isEmpty() && visibleTracks.isEmpty()) {
                        item {
                            Text("Folder je prazan.", color = Color.White.copy(alpha = .7f), fontSize = 20.sp, modifier = Modifier.padding(18.dp))
                        }
                    }
                }
                }
            }
        }
    }
}

@Composable
private fun SearchInputField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    onSearch: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Golf 4 / CdgLite search field: Material3 OutlinedTextField owns the
    // text layout, baseline and cursor; no nested full-height BasicTextField.
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        placeholder = {
            Text(placeholder, fontSize = 17.sp, fontWeight = FontWeight.Medium,
                color = Color(0xFFD9D6DE), maxLines = 1)
        },
        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 22.sp, color = Color.White),
        shape = RoundedCornerShape(9.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Amber,
            unfocusedBorderColor = Color(0xFF5F7A4D),
            cursorColor = Amber,
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White
        ),
        modifier = modifier,
        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
            imeAction = androidx.compose.ui.text.input.ImeAction.Search
        ),
        keyboardActions = androidx.compose.foundation.text.KeyboardActions(
            onSearch = { onSearch() }
        )
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FactoryPlaylistPanel(
    loading: Boolean,
    categories: List<String>,
    selected: String,
    songs: List<BreakItem>,
    queueSelectionMode: Boolean,
    playlistStore: BreakPlaylistStore,
    onSelect: (String) -> Unit,
    onMove: (Int, Int) -> Unit,
    onPlay: (Int) -> Unit,
    playingUri: String?,
    playingPlaylistContext: String?,
    random: Boolean, repeat: Boolean,
    onRandom: () -> Unit, onRepeat: () -> Unit,
    onRestoreFactory: () -> Unit,
    onMoveSong: (String,String,String,Boolean) -> Boolean,
    modifier: Modifier = Modifier
) {
    Column(modifier) {
        if (loading) {
            LinearProgressIndicator(Modifier.fillMaxWidth(), color = MonsterGreen)
            Text("Loading factory playlists…", color = Color.White, fontSize = 18.sp, modifier = Modifier.padding(12.dp))
            return@Column
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            categories.forEachIndexed { index, name ->
                val density = androidx.compose.ui.platform.LocalDensity.current
                val stepPx = with(density) { 138.dp.toPx() }
                var dragX by remember(name) { mutableFloatStateOf(0f) }
                Box(Modifier.width(132.dp).height(42.dp)
                    .pointerInput(name, index, categories) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = { dragX = 0f },
                            onDragCancel = { dragX = 0f },
                            onDragEnd = { dragX = 0f },
                            onDrag = { change, amount ->
                                change.consume()
                                dragX += amount.x
                                if (dragX >= stepPx && index < categories.lastIndex) {
                                    onMove(index, index + 1); dragX = 0f
                                } else if (dragX <= -stepPx && index > 0) {
                                    onMove(index, index - 1); dragX = 0f
                                }
                            }
                        )
                    }) {
                    PlaylistStoneButton(
                        onClick = { onSelect(name) }, active = name == selected,
                        modifier = Modifier.fillMaxSize()
                    ) { Text(name,color=Color.White,fontSize=14.sp,fontWeight=FontWeight.Black,maxLines=1,softWrap=false,overflow=TextOverflow.Clip,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth().padding(horizontal=5.dp).then(if(name==selected) Modifier.basicMarquee(iterations=Int.MAX_VALUE,initialDelayMillis=1100) else Modifier)) }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top=5.dp),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
            PlaylistStoneButton(onClick=onRandom,active=random,modifier=Modifier.width(95.dp).height(28.dp)) { ShuffleGlyph(crossed=random,Modifier.size(26.dp),if(random) MonsterGreen else Color.White) }
            PlaylistStoneButton(onClick=onRepeat,active=repeat,modifier=Modifier.width(95.dp).height(28.dp)) { StoneLabel(if(repeat) "REPEAT ALL ON" else "REPEAT ALL",Color.White,9.sp) }
            PlaylistStoneButton(onClick=onRestoreFactory,active=false,modifier=Modifier.width(110.dp).height(42.dp)) { StoneLabel("RESTORE",Color.White,11.sp) }
        }
        Text("${songs.size} SONGS", color = MonsterGreen, fontSize = 14.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(start = 12.dp, top = 7.dp, bottom = 4.dp))
        val listState = rememberLazyListState()
        val scope=rememberCoroutineScope()
        var draggingUri by remember(selected) { mutableStateOf<String?>(null) }
        var dragOffsetY by remember(selected) { mutableFloatStateOf(0f) }
        var lastAutoScrollAt by remember { mutableLongStateOf(0L) }
        LaunchedEffect(playingUri, playingPlaylistContext, selected, songs) {
        val activeIndex = if (playingPlaylistContext == "factory:$selected") songs.indexOfFirst { it.file.uri.toString() == playingUri } else -1
            if (activeIndex >= 0) {
                val info = listState.layoutInfo
                val row = info.visibleItemsInfo.firstOrNull { it.index == activeIndex }
                val threshold = info.viewportStartOffset + (info.viewportEndOffset - info.viewportStartOffset) * 2 / 3
                if (row == null && activeIndex > (info.visibleItemsInfo.lastOrNull()?.index ?: -1)) listState.animateScrollToItem((activeIndex - 2).coerceAtLeast(0))
                else if (row != null && row.offset + row.size > threshold) listState.animateScrollToItem((activeIndex - 2).coerceAtLeast(0))
            }
        }
        LazyColumn(Modifier.fillMaxSize(), state=listState) {
            itemsIndexed(songs, key = { _, item -> item.file.uri.toString() }) { index, item ->
                val active = playingPlaylistContext == "factory:$selected" && item.file.uri.toString() == playingUri
                val itemUri=item.file.uri.toString()
                val isDragging=draggingUri==itemUri
                Row(
                    Modifier.fillMaxWidth().heightIn(min = 52.dp)
                        .graphicsLayer { translationY=if(isDragging) dragOffsetY else 0f }
                        .zIndex(if(isDragging) 1f else 0f)
                        .background(if(queueSelectionMode) { if(playlistStore.isInQueue(itemUri)) Color.Transparent else Color(0xB30A2417) } else if(active) Amber.copy(alpha=.5f) else Color.Transparent)
                        .pointerInput(itemUri,selected) {
                            var lastTarget:String?=null
                            detectDragGesturesAfterLongPress(
                                onDragStart={ draggingUri=itemUri;dragOffsetY=0f;lastTarget=null },
                                onDragCancel={ draggingUri=null;dragOffsetY=0f },
                                onDragEnd={ draggingUri=null;dragOffsetY=0f },
                                onDrag={ change,amount ->
                                    change.consume();dragOffsetY+=amount.y
                                    val layout=listState.layoutInfo
                                    val moving=layout.visibleItemsInfo.firstOrNull { it.key==itemUri }
                                    if(moving!=null) {
                                        val center=moving.offset+dragOffsetY+moving.size/2f
                                        val neighbors=layout.visibleItemsInfo.filter { it.key is String && it.key!=itemUri }
                                        val target=neighbors.minByOrNull { kotlin.math.abs(center-(it.offset+it.size/2f)) }
                                        if(target!=null && target.key is String) {
                                            val movingUp=target.index<moving.index
                                            val crossed=if(movingUp) center<target.offset+target.size/2f else center>target.offset+target.size/2f
                                            val targetUri=target.key as String
                                            if(crossed && targetUri!=lastTarget && onMoveSong(selected,itemUri,targetUri,!movingUp)) {
                                                dragOffsetY+=if(movingUp) target.size.toFloat() else -target.size.toFloat()
                                                lastTarget=targetUri
                                            }
                                        }
                                        val edge=64f
                                        val now=SystemClock.elapsedRealtime()
                                        if(now-lastAutoScrollAt>70L && center<layout.viewportStartOffset+edge) {
                                            lastAutoScrollAt=now;scope.launch { listState.scrollBy(-24f) }
                                        } else if(now-lastAutoScrollAt>70L && center>layout.viewportEndOffset-edge) {
                                            lastAutoScrollAt=now;scope.launch { listState.scrollBy(24f) }
                                        }
                                    }
                                }
                            )
                        }
                        .clickable { if(queueSelectionMode) playlistStore.toggleQueueEntry(BreakPlaylistEntry(item.name,itemUri,item.isYoutube,sourceKind="FACTORY",sourceContext="factory:$selected")) else onPlay(index) }
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${index + 1}.", color = MonsterGreen, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines=1, softWrap=false, style=TextStyle(lineHeight=15.sp,platformStyle=PlatformTextStyle(includeFontPadding=false)), modifier = Modifier.width(64.dp))
                    Text(item.name, color = Color.White, fontSize = 20.sp, fontWeight = if(active) FontWeight.Bold else FontWeight.Medium, style=TextStyle(lineHeight=20.sp,platformStyle=PlatformTextStyle(includeFontPadding=false)), modifier = Modifier.weight(1f).then(if(active) Modifier.basicMarquee(iterations=Int.MAX_VALUE,initialDelayMillis=1100) else Modifier), maxLines = 1, softWrap=false, overflow = TextOverflow.Clip)
                    YouTubeBadge(Modifier.size(32.dp))
                }
                HorizontalDivider(color = Color.White.copy(alpha = .08f))
            }
        }
    }
}


@Composable
private fun BoxScope.PterodactylPerches() {
    // Two short stone posts on the top edge of each playlist button.
    Row(Modifier.align(Alignment.TopCenter).offset(y=(-12).dp).width(72.dp).height(16.dp), horizontalArrangement=Arrangement.SpaceBetween) {
        repeat(2) {
            Box(Modifier.width(13.dp).fillMaxHeight().border(1.dp, Color(0xFFB3AE83), RoundedCornerShape(3.dp)).background(Color(0xFF6D6B5B), RoundedCornerShape(3.dp)))
        }
    }
}

@Composable
private fun PterodactylBlink(modifier: Modifier = Modifier) {
    val transition = androidx.compose.animation.core.rememberInfiniteTransition(label="pterodactyl-blink")
    val phase by transition.animateFloat(0f, 2000f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(2000, easing=androidx.compose.animation.core.LinearEasing)), label="blink-clock")
    val closed = phase in 140f..260f
    Image(painterResource(if(closed) R.drawable.pterodactyl_closed else R.drawable.pterodactyl_open),
        contentDescription="Monster playlist pterodactyl", contentScale=ContentScale.Fit, modifier=modifier)
}

/** Preserve the original blinking Feed character; launcher art is independent. */
@Composable
private fun MonsterBlinkGif(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val frames = remember(context) {
        (0..8).mapNotNull { frame ->
            runCatching {
                context.assets.open("monster_blink/frame_%02d.png".format(frame)).use { stream ->
                    android.graphics.BitmapFactory.decodeStream(stream)?.asImageBitmap()
                }
            }.getOrNull()
        }
    }
    var frameIndex by remember { mutableIntStateOf(0) }
    LaunchedEffect(frames.size) {
        while (frames.isNotEmpty()) {
            delay(170)
            frameIndex = (frameIndex + 1) % frames.size
        }
    }
    frames.getOrNull(frameIndex)?.let { frame ->
        Image(bitmap = frame, contentDescription = "Blinking little monster", contentScale = ContentScale.Fit, modifier = modifier)
    }
}

@Composable
private fun FeedLittleMonster(onClick: () -> Unit, modifier: Modifier = Modifier) {
    StoneButton(onClick = onClick, modifier = modifier.height(78.dp)) {
        Row(
            modifier = Modifier.fillMaxSize().padding(start = 5.dp, end = 0.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text("❤️", fontSize = 21.sp)
            Text(
                "FEED A LITTLE MONSTER", color = Color.White,
                fontSize = 12.sp, fontWeight = FontWeight.Black,
                maxLines = 1, softWrap = false, overflow = TextOverflow.Visible,
                modifier = Modifier.weight(1f, fill = false)
            )
            MonsterBlinkGif(Modifier.size(76.dp))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BreakPlaylistPanel(
    store: BreakPlaylistStore, selected: Int, onSelected:(Int)->Unit,
    queueSelectionMode:Boolean, onQueueTap:()->Unit, onExportQueue:(String)->Int?,
    random:Boolean, repeat:Boolean, onRandom:()->Unit, onRepeat:()->Unit,
    localQuery:String, onCreatePlaylist:(String)->Unit,
    showHint:Boolean, onGestureLearned:()->Unit, showReorderHint:Boolean, onReorderGestureLearned:()->Unit, onSwipeRemoved:(Int)->Unit,
    onPlay:(String)->Unit, onImportPlaylist:()->Unit, onImportZipAt:(Int)->Unit, playingUri:String?, playingPlaylistContext:String?, focusUri:String?
) {
    val marked = remember(selected){ mutableStateListOf<String>() }
    val flashing = remember(selected){ mutableStateListOf<String>() }
    val scope = rememberCoroutineScope()
    val context= LocalContext.current
    val listState = rememberLazyListState()
    val visibleEntries = store.lists[selected]
    // Follow playback, not the current search or selected row. Scroll only when the
    // playing row passes two thirds of the visible playlist viewport.
    LaunchedEffect(playingUri, playingPlaylistContext, focusUri, selected, visibleEntries.size) {
        val contextMatches = playingPlaylistContext == store.playbackContext(selected)
        val activeUri = (playingUri.takeIf { contextMatches }) ?: focusUri?.takeIf { uri -> visibleEntries.any { it.uri == uri } }
        val activeIndex = visibleEntries.indexOfFirst { it.uri == activeUri }
        if (activeIndex >= 0) {
            val info = listState.layoutInfo
            val activeRow = info.visibleItemsInfo.firstOrNull { it.index == activeIndex }
            val threshold = info.viewportStartOffset + (info.viewportEndOffset - info.viewportStartOffset) * 2 / 3
            if (activeRow == null && activeIndex > (info.visibleItemsInfo.lastOrNull()?.index ?: -1)) {
                listState.animateScrollToItem((activeIndex - 2).coerceAtLeast(0))
            } else if (activeRow != null && activeRow.offset + activeRow.size > threshold) {
                listState.animateScrollToItem((activeIndex - 2).coerceAtLeast(0))
            }
        }
    }
    var draggingUri by remember(selected) { mutableStateOf<String?>(null) }
    var dragOffsetY by remember(selected) { mutableFloatStateOf(0f) }
    var lastAutoScrollAt by remember { mutableLongStateOf(0L) }
    var createPlaylist by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var entryMenu by remember { mutableStateOf<BreakPlaylistEntry?>(null) }
    var entryRename by remember { mutableStateOf<BreakPlaylistEntry?>(null) }
    var entryRenameText by remember { mutableStateOf("") }
    var entryMove by remember { mutableStateOf<BreakPlaylistEntry?>(null) }
    var entryDelete by remember { mutableStateOf<BreakPlaylistEntry?>(null) }
    var deletePlaylistConfirm by remember { mutableStateOf(false) }
    var exportDialog by remember { mutableStateOf(false) }
    var exportName by remember { mutableStateOf("") }
    var exportError by remember { mutableStateOf("") }
    var queueOptions by remember { mutableStateOf(false) }
    var clearQueueConfirm by remember { mutableStateOf(false) }
    var moveFromQueue by remember { mutableStateOf<BreakPlaylistEntry?>(null) }
    var moveError by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Color.Transparent)) {
        BreakPlaylistTabs(store, selected, onSelected, onImportPlaylist, onImportZipAt)
        // Compact stone controls: centered, recognizable symbols with accessible descriptions.
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(7.dp)) {
            PlaylistStoneButton(onClick=onRandom,active=random,modifier=Modifier.width(100.dp).height(30.dp)){
                ShuffleGlyph(crossed=random,Modifier.size(28.dp),if(random) MonsterGreen else Color.White)
            }
            PlaylistStoneButton(onClick=onRepeat,active=repeat,modifier=Modifier.width(100.dp).height(30.dp)){
                StoneLabel("↻",if(repeat) MonsterGreen else Color.White,16.sp)
            }

            PlaylistStoneButton(onClick={createPlaylist=true},active=false,modifier=Modifier.width(100.dp).height(30.dp)){
                StoneLabel("＋",Color.White,16.sp)
            }
            PlaylistStoneButton(onClick={onImportZipAt(-2)},active=false,modifier=Modifier.width(100.dp).height(30.dp)){
                StoneLabel("⇩ PL",Color.White,10.sp)
            }
            RoundModeButton(selected=marked.isNotEmpty(), contentDescription=if(selected==store.queueIndex) "Queue options" else "Delete playlist or remove selected", onClick={
                if(selected==store.queueIndex) queueOptions=true
                else deletePlaylistConfirm=true
            }, modifier=Modifier.width(79.dp).height(31.dp)) {
                StoneLabel("CLEAR",if(marked.isNotEmpty() || selected==store.queueIndex) MonsterGreen else Color.White,9.sp)
            }
        }

        val context = LocalContext.current
        val gesturePrefs = remember { context.getSharedPreferences("breakmonster_ui", 0) }
        var swipeDemo by remember { mutableStateOf(false) }
        LaunchedEffect(selected, queueSelectionMode) {
            if(!queueSelectionMode && selected!=store.queueIndex && !gesturePrefs.getBoolean("playlistSwipeRightHintDone",false)) {
                swipeDemo=true
                gesturePrefs.edit().putBoolean("playlistSwipeRightHintDone",true).apply()
                delay(2600)
                swipeDemo=false
            }
        }
        if(swipeDemo) {
            val transition=androidx.compose.animation.core.rememberInfiniteTransition(label="swipe-right-demo")
            val slide by transition.animateFloat(initialValue=0f,targetValue=54f,animationSpec=androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(500),androidx.compose.animation.core.RepeatMode.Reverse),label="swipe-right")
            Row(Modifier.fillMaxWidth().height(34.dp).padding(horizontal=12.dp),verticalAlignment=Alignment.CenterVertically) {
                Text("SWIPE RIGHT TO REMOVE",color=Amber,fontSize=13.sp,fontWeight=FontWeight.Black,modifier=Modifier.weight(1f))
                Text("♪  SONG  →",color=Color.White,fontSize=13.sp,fontWeight=FontWeight.Bold,modifier=Modifier.graphicsLayer { translationX=slide }.background(Color(0xAA113B25),RoundedCornerShape(7.dp)).border(1.dp,MonsterGreen.copy(alpha=.55f),RoundedCornerShape(7.dp)).padding(horizontal=10.dp,vertical=4.dp))
            }
        }
        if(showHint) GestureManual(R.drawable.playlist_gesture_hint, Modifier.fillMaxWidth().height(150.dp).padding(vertical=4.dp))
        if(showReorderHint && store.lists[selected].size>1) ReorderGestureHelp(Modifier.fillMaxWidth().height(42.dp))
        LazyColumn(Modifier.fillMaxSize().background(if(selected==store.queueIndex) Brush.verticalGradient(listOf(Color(0x665B3B05),Color(0x333A2708),Color.Transparent)) else Brush.verticalGradient(listOf(Color.Transparent,Color.Transparent))), state=listState) {
            itemsIndexed(visibleEntries, key={_,e->e.uri}) { index,e ->
                val isDragging = draggingUri == e.uri
                Row(Modifier.fillMaxWidth().heightIn(min=44.dp)
                    .graphicsLayer { translationY = if(isDragging) dragOffsetY else 0f }
                    .zIndex(if(isDragging) 1f else 0f)
                    .background(if(queueSelectionMode) { if(store.isInQueue(e.uri)) Color.Transparent else Color(0xB30A2417) } else if(e.uri in flashing) MonsterGreen.copy(alpha=.55f) else if(playingPlaylistContext == store.playbackContext(selected) && e.uri == playingUri) Amber.copy(alpha=.5f) else Color.Transparent)
                    .pointerInput(e.uri,selected,queueSelectionMode,e.sourceKind) {
                        if(selected==store.queueIndex || (!queueSelectionMode && selected!=store.queueIndex)) {
                            var totalX=0f
                            detectHorizontalDragGestures(
                                onHorizontalDrag={ change, amount -> totalX+=amount; change.consume() },
                                onDragEnd={ if(totalX >= 96.dp.toPx()) {
                                    if(selected==store.queueIndex) {
                                        if(e.sourceKind=="SEARCH_SAVE") { moveFromQueue=e; moveError="" }
                                        else { store.removeUris(store.queueIndex,setOf(e.uri)); onSwipeRemoved(store.queueIndex+1) }
                                    } else { store.removeUris(selected,setOf(e.uri)); onSwipeRemoved(selected+1) }
                                } },
                                onDragCancel={ totalX=0f }
                            )
                        }
                    }
                    .pointerInput(e.uri,selected,localQuery) {
                        var lastTarget: String? = null
                        detectDragGesturesAfterLongPress(
                            onDragStart = { draggingUri=e.uri; dragOffsetY=0f; lastTarget=null },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                dragOffsetY += dragAmount.y
                                val layout=listState.layoutInfo
                                val active=layout.visibleItemsInfo.firstOrNull { it.key==e.uri }
                                if(active!=null) {
                                    val center=active.offset+dragOffsetY+active.size/2f
                                    val neighbors=layout.visibleItemsInfo.filter { it.key is String && it.key!=e.uri }
                                    val target=neighbors.minByOrNull { kotlin.math.abs(center-(it.offset+it.size/2f)) }
                                    if(target!=null && target.key is String) {
                                        val targetCenter=target.offset+target.size/2f
                                        val movingUp=target.index<active.index
                                        val crossed=if(movingUp) center<targetCenter else center>targetCenter
                                        val targetUri=target.key as String
                                        if(crossed && targetUri!=lastTarget && store.moveRelative(selected,e.uri,targetUri,after=!movingUp)) {
                                            dragOffsetY += if(movingUp) target.size.toFloat() else -target.size.toFloat()
                                            lastTarget=targetUri
                                            onReorderGestureLearned()
                                        }
                                    }
                                    val edge=56f
                                    val now=SystemClock.elapsedRealtime()
                                    if(now-lastAutoScrollAt>70L && center<layout.viewportStartOffset+edge) {
                                        lastAutoScrollAt=now; scope.launch { listState.scrollBy(-24f) }
                                    } else if(now-lastAutoScrollAt>70L && center>layout.viewportEndOffset-edge) {
                                        lastAutoScrollAt=now; scope.launch { listState.scrollBy(24f) }
                                    }
                                }
                            },
                            onDragEnd = { draggingUri=null; dragOffsetY=0f },
                            onDragCancel = { draggingUri=null; dragOffsetY=0f }
                        )
                    }
                    .clickable {
                        if(queueSelectionMode && !e.missing) store.toggleQueueEntry(e.copy(sourceKind="USER_PLAYLIST",sourcePlaylistIndex=selected,sourceContext=store.playbackContext(selected)))
                        else if(marked.isNotEmpty()) { if(e.uri in marked) marked.remove(e.uri) else marked.add(e.uri) }
                        else if(!e.missing) onPlay(e.uri)
                    }
                    .padding(horizontal=12.dp,vertical=3.dp),verticalAlignment=Alignment.CenterVertically){
                    Text("${index+1}.",color=MonsterGreen,fontSize=15.sp,fontWeight=FontWeight.Bold,maxLines=1,softWrap=false,style=TextStyle(lineHeight=15.sp,platformStyle=PlatformTextStyle(includeFontPadding=false)),modifier=Modifier.width(64.dp))
                    val rowIsPlaying = playingPlaylistContext == store.playbackContext(selected) && e.uri == playingUri
                    Text(e.name,color=Color.White,fontSize=17.sp,fontWeight=FontWeight.Medium,maxLines=1,softWrap=false,overflow=TextOverflow.Clip,style=TextStyle(lineHeight=17.sp,platformStyle=PlatformTextStyle(includeFontPadding=false)),modifier=Modifier.weight(1f).then(if(rowIsPlaying) Modifier.basicMarquee(iterations=Int.MAX_VALUE,initialDelayMillis=1100) else Modifier))
                    if(e.missing){ Text("MISSING",color=Color(0xFFFF8A80),fontSize=12.sp,fontWeight=FontWeight.Black) } else { Text("MATCHED",color=MonsterGreen,fontSize=11.sp,fontWeight=FontWeight.Bold) }
                    Spacer(Modifier.width(5.dp))
                    Box(Modifier.widthIn(min=42.dp).height(28.dp).background(Color(0xFF00BFC4),RoundedCornerShape(6.dp)).clickable { entryMenu=e },contentAlignment=Alignment.Center) {
                        Text("EDIT",color=Color.White,fontSize=10.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(horizontal=4.dp))
                    }
                    if(e.youtube){Spacer(Modifier.width(5.dp));YouTubeBadge(Modifier.size(34.dp))}
                    else {Spacer(Modifier.width(5.dp));MediaTypeBadge(Uri.parse(e.uri).lastPathSegment.orEmpty().substringAfterLast('.', ""))}
                }
                HorizontalDivider(color=Color.White.copy(alpha=.05f))
            }
        }
    }
    if(entryMenu != null) {
        val entry = entryMenu!!
        AlertDialog(onDismissRequest={entryMenu=null}, title={Text(entry.name, maxLines=2)},
            text={Column {
                TextButton(onClick={entryRename=entry;entryRenameText=entry.name;entryMenu=null}){Text("RENAME")}
                TextButton(onClick={entryMove=entry;entryMenu=null}){Text("MOVE TO…")}
                TextButton(onClick={entryDelete=entry;entryMenu=null}){Text("DELETE",color=Color.Red)}
            }}, confirmButton={TextButton(onClick={entryMenu=null}){Text("CANCEL")}})
    }
    if(entryRename != null) AlertDialog(onDismissRequest={entryRename=null}, title={Text("RENAME")},
        text={OutlinedTextField(entryRenameText,{entryRenameText=it.take(120)},singleLine=true)},
        confirmButton={TextButton(onClick={store.renameEntry(selected,entryRename!!.uri,entryRenameText);entryRename=null}){Text("SAVE")}},
        dismissButton={TextButton(onClick={entryRename=null}){Text("CANCEL")}})
    if(entryMove != null) AlertDialog(onDismissRequest={entryMove=null}, title={Text("MOVE TO…")},
        text={Column(Modifier.heightIn(max=360.dp).verticalScroll(rememberScrollState())) {
            (0 until store.size).filter{it!=selected}.forEach { destination ->
                TextButton(onClick={
                    val entry=entryMove!!
                    if(store.moveEntryTo(selected,destination,entry.uri)) Toast.makeText(context,"MOVED TO ${store.displayName(destination)}",Toast.LENGTH_SHORT).show()
                    else Toast.makeText(context,"ALREADY IN ${store.displayName(destination)}",Toast.LENGTH_SHORT).show()
                    entryMove=null
                }){Text(store.displayName(destination),fontSize=19.sp)}
            }
        }}, confirmButton={TextButton(onClick={entryMove=null}){Text("CANCEL")}})
    if(entryDelete != null) AlertDialog(onDismissRequest={entryDelete=null},title={Text("REMOVE FROM PLAYLIST?")},
        text={Text("Original media file will not be deleted.")},
        confirmButton={TextButton(onClick={store.removeUris(selected,setOf(entryDelete!!.uri));entryDelete=null}){Text("DELETE",color=Color.Red)}},
        dismissButton={TextButton(onClick={entryDelete=null}){Text("CANCEL")}})
    if(deletePlaylistConfirm) AlertDialog(
        onDismissRequest={deletePlaylistConfirm=false},
        title={Text("ARE YOU SURE?",fontWeight=FontWeight.Black)},
        text={Text(if(marked.isNotEmpty()) "Delete the selected songs from ${store.displayName(selected)}? Original media files will stay untouched." else "Delete playlist ${store.displayName(selected)}? Media files will stay untouched.")},
        confirmButton={TextButton(onClick={
            if(marked.isNotEmpty()) { store.removeUris(selected,marked.toSet()); marked.clear() }
            else { store.delete(selected); onSelected(store.activeIndex) }
            deletePlaylistConfirm=false
        }){Text("YES")}},
        dismissButton={TextButton(onClick={deletePlaylistConfirm=false}){Text("CANCEL")}}
    )
    if(queueOptions) AlertDialog(onDismissRequest={queueOptions=false},title={Text("QUEUE OPTIONS",fontWeight=FontWeight.Black)},text={Column {
        TextButton(onClick={queueOptions=false;clearQueueConfirm=true}) { Text("CLEAR QUEUE",fontWeight=FontWeight.Bold) }
        TextButton(onClick={queueOptions=false;exportError="";exportName="";exportDialog=true}) { Text("EXPORT AS PLAYLIST",fontWeight=FontWeight.Bold) }
    }},confirmButton={})
    if(clearQueueConfirm) AlertDialog(onDismissRequest={clearQueueConfirm=false},title={Text("ARE YOU SURE?",fontWeight=FontWeight.Black)},text={Text("Clear all QUEUE entries? Original files and playlists will stay untouched.")},confirmButton={TextButton(onClick={
        if(store.clearQueue()) Toast.makeText(context,"QUEUE CLEARED",Toast.LENGTH_SHORT).show() else Toast.makeText(context,"Could not save the empty QUEUE.",Toast.LENGTH_LONG).show()
        clearQueueConfirm=false
    }){Text("YES")}},dismissButton={TextButton(onClick={clearQueueConfirm=false}){Text("CANCEL")}})
    if(moveFromQueue!=null) AlertDialog(onDismissRequest={moveFromQueue=null;moveError=""},title={Text("MOVE TO PLAYLIST",fontWeight=FontWeight.Black)},text={Column {
        Column(Modifier.fillMaxWidth().heightIn(max=380.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            store.lists.indices.filter { it!=store.queueIndex }.forEach { destination ->
                PlaylistStoneButton(onClick={
                    val moving=moveFromQueue!!
                    if(store.moveSearchSaveFromQueue(moving,destination)) { moveFromQueue=null;moveError="";Toast.makeText(context,"MOVED TO ${store.displayName(destination)}",Toast.LENGTH_SHORT).show() }
                    else moveError="Move failed. The song remains in QUEUE."
                },modifier=Modifier.fillMaxWidth().height(46.dp)) { Text(store.displayName(destination),color=Color.White,fontWeight=FontWeight.Black,maxLines=1,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth()) }
            }
        }
        if(moveError.isNotBlank()) Text(moveError,color=Color(0xFFFF8A80),fontSize=15.sp)
    }},confirmButton={TextButton(onClick={moveFromQueue=null;moveError=""}){Text("CANCEL")}})
    if(createPlaylist) AlertDialog(onDismissRequest={createPlaylist=false},title={Text("ADD NEW PL",fontWeight=FontWeight.Black)},text={OutlinedTextField(newName,{newName=it.take(24)},singleLine=true,label={Text("Playlist name")})},confirmButton={TextButton(onClick={onCreatePlaylist(newName);newName="";createPlaylist=false}){Text("CREATE")}},dismissButton={TextButton(onClick={createPlaylist=false}){Text("CANCEL")}})
    if(exportDialog) AlertDialog(onDismissRequest={exportDialog=false},title={Text("EXPORT AS PL",fontWeight=FontWeight.Black)},text={Column {
        OutlinedTextField(exportName,{exportName=it.take(24);exportError=""},singleLine=true,label={Text("Playlist name")})
        if(exportError.isNotBlank()) Text(exportError,color=Color(0xFFFF8A80),fontSize=15.sp)
    }},confirmButton={TextButton(onClick={
        val clean=exportName.trim()
        when {
            store.lists[store.queueIndex].isEmpty() -> exportError="QUEUE is empty."
            clean.isBlank() -> exportError="Enter a playlist name."
            store.lists.indices.any { store.displayName(it).equals(clean,true) } -> exportError="That name already exists. Choose another."
            else -> {
                val created=onExportQueue(clean)
                if(created!=null) { onSelected(created); exportName=""; exportError=""; exportDialog=false; Toast.makeText(context,"EXPORTED TO ${store.displayName(created)}",Toast.LENGTH_LONG).show() }
                else exportError="Export failed. QUEUE has been preserved."
            }
        }
    }){Text("EXPORT")}},dismissButton={TextButton(onClick={exportDialog=false}){Text("CANCEL")}})
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BreakPlaylistTabs(store: BreakPlaylistStore, selected:Int, onSelected:(Int)->Unit, onImportPlaylist:()->Unit, onImportZipAt:(Int)->Unit) {
    var renameIndex by remember { mutableIntStateOf(-1) }
    var renameValue by remember { mutableStateOf("") }
    var menuIndex by remember { mutableIntStateOf(-1) }
    var deleteIndex by remember { mutableIntStateOf(-1) }
    Row(Modifier.fillMaxWidth().height(58.dp).padding(horizontal=4.dp, vertical=4.dp), verticalAlignment=Alignment.CenterVertically) {
        Row(Modifier.fillMaxSize().horizontalScroll(rememberScrollState()), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(5.dp)) {
            repeat(store.size) { i ->
                if(i==store.queueIndex) return@repeat
                PlaylistStoneButton(
                    onClick={ store.activate(i); onSelected(i) },
                    onLongClick={ menuIndex=i; renameValue=store.names[i].value },
                    active=store.activeIndex==i,
                    modifier=Modifier.width(160.dp).height(50.dp)
                ) {
                    BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) {
                        val number = store.importedSplitNumber(i)
                        if (number != null) Text(number.toString(), color=Color.White.copy(alpha=0.17f), fontSize=(maxHeight.value * .85f).sp, fontWeight=FontWeight.Black, maxLines=1)
                        Text(store.displayName(i), color=Color.White, fontSize=16.sp, fontWeight=FontWeight.Black, maxLines=1, softWrap=false, overflow=TextOverflow.Clip, modifier=Modifier.fillMaxWidth().then(if(store.activeIndex==i) Modifier.basicMarquee(iterations=Int.MAX_VALUE,initialDelayMillis=1100) else Modifier))
                    }
                }
            }
        }
    }
    if(menuIndex>=0) AlertDialog(onDismissRequest={menuIndex=-1},title={Text(store.displayName(menuIndex),fontWeight=FontWeight.Black)},confirmButton={Row { TextButton(onClick={renameIndex=menuIndex;menuIndex=-1}){Text("RENAME")} }},dismissButton={Row{TextButton(onClick={deleteIndex=menuIndex;menuIndex=-1}){Text("DELETE PLAYLIST",color=Color(0xFFFF7B72))};TextButton(onClick={menuIndex=-1}){Text("CANCEL")}}})
    if(renameIndex>=0) AlertDialog(
        onDismissRequest={renameIndex=-1},
        title={Text("Rename playlist")},
        text={OutlinedTextField(renameValue,{renameValue=it.take(24)},singleLine=true)},
        confirmButton={TextButton(onClick={store.rename(renameIndex,renameValue);renameIndex=-1}){Text("SAVE")}},
        dismissButton={TextButton(onClick={renameIndex=-1}){Text("CANCEL")}}
    )
    if(deleteIndex>=0) AlertDialog(onDismissRequest={deleteIndex=-1},title={Text("ARE YOU SURE?",fontSize=23.sp,fontWeight=FontWeight.Black)},text={Text("Delete playlist ${store.displayName(deleteIndex)}? Media files will stay untouched.",fontSize=18.sp)},confirmButton={Button(onClick={store.delete(deleteIndex);deleteIndex=-1;onSelected(store.activeIndex)}){Text("DELETE PLAYLIST")}},dismissButton={TextButton(onClick={deleteIndex=-1}){Text("CANCEL")}})
}

@Composable
private fun GestureManual(resource:Int, modifier:Modifier=Modifier){
    AndroidView(modifier=modifier, factory={ context -> GestureGifView(context,resource) })
}
@Composable
private fun ReorderGestureHelp(modifier:Modifier=Modifier){
    val transition=androidx.compose.animation.core.rememberInfiniteTransition(label="reorder-help")
    val offset by transition.animateFloat(initialValue=0f,targetValue=8f,animationSpec=androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(550),androidx.compose.animation.core.RepeatMode.Reverse),label="drag-arrow")
    Row(modifier,verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.Center){
        Text("☝",fontSize=23.sp,color=MonsterGreen)
        Spacer(Modifier.width(8.dp))
        Text("LONG PRESS",fontSize=15.sp,fontWeight=FontWeight.Black,color=Color.White)
        Text("  ↕",fontSize=24.sp,fontWeight=FontWeight.Black,color=MonsterGreen,modifier=Modifier.offset(y=offset.dp))
        Text("  DRAG TO REORDER",fontSize=15.sp,fontWeight=FontWeight.Black,color=Color.White)
    }
}
@Suppress("DEPRECATION")
private class GestureGifView(context:Context, resource:Int):android.view.View(context){
    private val movie=context.resources.openRawResource(resource).use{android.graphics.Movie.decodeStream(it)}
    private val started=android.os.SystemClock.uptimeMillis()
    init{setLayerType(LAYER_TYPE_SOFTWARE,null)}
    override fun onDraw(canvas:android.graphics.Canvas){super.onDraw(canvas);val a=movie?:return;a.setTime(((android.os.SystemClock.uptimeMillis()-started)%a.duration().coerceAtLeast(1)).toInt());val scale=minOf(width.toFloat()/a.width(),height.toFloat()/a.height());canvas.save();canvas.translate((width-a.width()*scale)/2,(height-a.height()*scale)/2);canvas.scale(scale,scale);a.draw(canvas,0f,0f);canvas.restore();if(isAttachedToWindow)postInvalidateDelayed(40)}
}
private fun swipeFeedbackResource(added:Boolean, playlist:Int):Int{
    val r=if(added) listOf(R.drawable.swipe_added_p1,R.drawable.swipe_added_p2,R.drawable.swipe_added_p3,R.drawable.swipe_added_p4) else listOf(R.drawable.swipe_removed_p1,R.drawable.swipe_removed_p2,R.drawable.swipe_removed_p3,R.drawable.swipe_removed_p4)
    return r[(playlist-1).coerceIn(0,3)]
}

private fun importM3uPlaylist(context:Context, uri:Uri, library:List<BreakItem>, store:BreakPlaylistStore):Int {
    return runCatching {
        val displayName=runCatching { context.contentResolver.query(uri,arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),null,null,null)?.use { c -> if(c.moveToFirst()) c.getString(0) else null } }.getOrNull() ?: "Imported playlist.m3u"
        if(!displayName.endsWith(".m3u",true) && !displayName.endsWith(".m3u8",true)) error("Choose an M3U or M3U8 playlist.")
        val lines=context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readLines() } ?: error("Playlist file could not be read.")
        val entries=mutableListOf<BreakPlaylistEntry>(); var metadata:String?=null
        lines.forEachIndexed { index, raw ->
            val line=raw.trim().removePrefix("\uFEFF")
            if(line.isBlank()) return@forEachIndexed
            if(line.startsWith("#EXTINF",true)){ metadata=line.substringAfter(',',"").trim().takeIf{it.isNotBlank()}; return@forEachIndexed }
            if(line.startsWith('#')) return@forEachIndexed
            val pathName=line.substringAfterLast('/').substringAfterLast('\\').substringBeforeLast('.')
            val taggedTitle=metadata?.substringAfterLast(" - ")?.trim().orEmpty()
            val wanted=normalizePlaylistTitle(taggedTitle.ifBlank { pathName })
            val matched=library.firstOrNull { normalizePlaylistTitle(it.name)==wanted }
            val direct=if(line.startsWith("content://",true)) runCatching {
                val externalUri=Uri.parse(line)
                context.contentResolver.openInputStream(externalUri)?.use { } ?: error("playlist URI is not readable")
                runCatching { context.contentResolver.takePersistableUriPermission(externalUri,Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                androidx.documentfile.provider.DocumentFile.fromSingleUri(context,externalUri)?.let { BreakItem(it,metadata?.takeIf{it.isNotBlank()} ?: pathName,externalUri.toString().contains("youtube",true)) }
            }.getOrNull() else runCatching { java.io.File(line).takeIf { it.isFile }?.let { BreakItem(androidx.documentfile.provider.DocumentFile.fromFile(it),metadata?.takeIf{it.isNotBlank()} ?: pathName,false) } }.getOrNull()
            if(matched!=null) entries.add(BreakPlaylistEntry(matched.name,matched.file.uri.toString(),matched.isYoutube,false))
            else if(direct!=null) entries.add(BreakPlaylistEntry(direct.name,direct.file.uri.toString(),direct.isYoutube,false))
            else entries.add(BreakPlaylistEntry(metadata?.takeIf{it.isNotBlank()} ?: pathName,"missing://entry/$index?source="+Uri.encode(line),false,true))
            metadata=null
        }
        val index=store.createImported(displayName.substringBeforeLast('.'),entries)
        val matched=entries.count{!it.missing}; val missing=entries.size-matched
        android.widget.Toast.makeText(context,"PLAYLIST IMPORTED · $matched MATCHED · $missing MISSING",android.widget.Toast.LENGTH_LONG).show()
        index
    }.getOrElse {
        android.widget.Toast.makeText(context,it.message ?: "Playlist import failed.",android.widget.Toast.LENGTH_LONG).show()
        store.activeIndex
    }
}

private fun normalizePlaylistTitle(value:String):String = value.substringBeforeLast('.').lowercase(Locale.ROOT)
    .replace(Regex("\\([^)]*\\)|\\[[^\\]]*\\]"), " ")
    .replace(Regex("[^\\p{L}\\p{N}]+")," ").trim().replace(Regex("\\s+")," ")

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun StoneButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    onLongClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val stoneShape = GenericShape { size, _ ->
        moveTo(size.width * .06f, 0f)
        lineTo(size.width * .91f, size.height * .03f)
        lineTo(size.width, size.height * .18f)
        lineTo(size.width * .96f, size.height * .88f)
        lineTo(size.width * .84f, size.height)
        lineTo(size.width * .08f, size.height * .96f)
        lineTo(0f, size.height * .80f)
        lineTo(size.width * .02f, size.height * .12f)
        close()
    }
    val edge = if (active) MonsterGreen else Color(0xFF4A5147)
    val top = if (active) Color(0xFF345E3A) else Color(0xFF30332E)
    val bottom = if (active) Color(0xFF172B1B) else Color(0xFF20221F)
    Box(
        modifier = modifier
            .padding(2.dp)
            .heightIn(min = 48.dp)
            .background(Brush.verticalGradient(listOf(top, bottom)), stoneShape)
            .border(2.dp, edge, stoneShape)
            .drawBehind {
                val crack = Color.Black.copy(alpha = .28f)
                drawLine(crack, androidx.compose.ui.geometry.Offset(size.width * .17f, size.height * .18f), androidx.compose.ui.geometry.Offset(size.width * .28f, size.height * .31f), 1.3.dp.toPx())
                drawLine(crack, androidx.compose.ui.geometry.Offset(size.width * .74f, size.height * .70f), androidx.compose.ui.geometry.Offset(size.width * .84f, size.height * .61f), 1.2.dp.toPx())
                drawLine(edge.copy(alpha = .24f), androidx.compose.ui.geometry.Offset(size.width * .08f, size.height * .10f), androidx.compose.ui.geometry.Offset(size.width * .86f, size.height * .08f), 1.dp.toPx())
            }
            .then(if (onLongClick == null) Modifier.combinedClickable(onClick = onClick, onLongClick = {}) else Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick))
            .padding(horizontal = 8.dp, vertical = 0.dp),
        contentAlignment = Alignment.Center,
        content = { Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) { content() } }
    )
}

@Composable
private fun BoxScope.StoneLabel(text:String, color:Color, fontSize:TextUnit) {
    Text(
        text=text,
        modifier=Modifier.align(Alignment.Center).fillMaxWidth(),
        color=color,
        fontSize=fontSize,
        lineHeight=fontSize,
        fontWeight=FontWeight.Black,
        maxLines=1,
        softWrap=false,
        textAlign=TextAlign.Center,
        style=TextStyle(platformStyle=PlatformTextStyle(includeFontPadding=false))
    )
}

/** Carved, irregular stone used by the playlist controls only. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PlaylistStoneButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    redActive: Boolean = false,
    queueTone: Boolean = false,
    mySavesTone: Boolean = false,
    onLongClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val stoneShape = GenericShape { size, _ ->
        moveTo(size.width * .08f, size.height * .04f)
        lineTo(size.width * .43f, size.height * .01f)
        lineTo(size.width * .49f, size.height * .045f)
        lineTo(size.width * .91f, size.height * .025f)
        lineTo(size.width * .985f, size.height * .22f)
        lineTo(size.width * .96f, size.height * .76f)
        lineTo(size.width * .88f, size.height * .97f)
        lineTo(size.width * .57f, size.height * .94f)
        lineTo(size.width * .50f, size.height * .99f)
        lineTo(size.width * .12f, size.height * .96f)
        lineTo(size.width * .015f, size.height * .79f)
        lineTo(size.width * .04f, size.height * .25f)
        close()
    }
    val edge = if (redActive) Color(0xFFFFD45C) else if (queueTone) Color(0xFF55594F) else if (active) Color(0xFFB3C478) else if (mySavesTone) Color(0xFF8B8A6E) else Color(0xFF77796D)
    val light = if (redActive) Color(0xFF9E281C) else if (queueTone) Color(0xFF383A35) else if (active) Color(0xFF747B53) else if (mySavesTone) Color(0xFF707064) else Color(0xFF64665E)
    val dark = if (redActive) Color(0xFF300B08) else if (queueTone) Color(0xFF191B18) else if (active) Color(0xFF303522) else if (mySavesTone) Color(0xFF34352E) else Color(0xFF292B28)
    Box(
        modifier = modifier
            .padding(2.dp)
            .background(Brush.verticalGradient(listOf(light, Color(0xFF484A43), dark)), stoneShape)
            .border(if(redActive) 3.dp else 2.dp, edge, stoneShape)
            .drawBehind {
                val px = size.width
                val py = size.height
                // Shallow top/left relief and a darker lower edge give the stone depth.
                drawLine(Color.White.copy(alpha = .20f), androidx.compose.ui.geometry.Offset(px * .10f, py * .15f), androidx.compose.ui.geometry.Offset(px * .20f, py * .08f), 1.6.dp.toPx())
                drawLine(Color.Black.copy(alpha = .36f), androidx.compose.ui.geometry.Offset(px * .12f, py * .86f), androidx.compose.ui.geometry.Offset(px * .85f, py * .90f), 1.7.dp.toPx())
                val crack = Color.Black.copy(alpha = .48f)
                drawLine(crack, androidx.compose.ui.geometry.Offset(px * .22f, py * .20f), androidx.compose.ui.geometry.Offset(px * .29f, py * .43f), 1.3.dp.toPx())
                drawLine(crack, androidx.compose.ui.geometry.Offset(px * .29f, py * .43f), androidx.compose.ui.geometry.Offset(px * .24f, py * .55f), 1.1.dp.toPx())
                drawLine(crack, androidx.compose.ui.geometry.Offset(px * .78f, py * .53f), androidx.compose.ui.geometry.Offset(px * .70f, py * .69f), 1.3.dp.toPx())
                drawLine(edge.copy(alpha = .34f), androidx.compose.ui.geometry.Offset(px * .35f, py * .16f), androidx.compose.ui.geometry.Offset(px * .69f, py * .14f), 1.dp.toPx())
            }
            .then(if (onLongClick == null) Modifier.combinedClickable(onClick = onClick, onLongClick = {}) else Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick))
            .padding(horizontal = 8.dp, vertical = 0.dp),
        contentAlignment = Alignment.Center,
        content = { Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) { content() } }
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun RoundModeButton(
    selected: Boolean,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier.size(58.dp),
    content: @Composable BoxScope.() -> Unit
) {
    val bg = if (selected) Amber else MutedGreen
    val border = if (selected) Color.White.copy(alpha = .55f) else Color.Black.copy(alpha = .4f)
    Box(
        modifier = modifier.clip(RoundedCornerShape(18.dp))
            .background(bg)
            .border(2.dp, border, RoundedCornerShape(18.dp))
            .semantics { this.contentDescription = contentDescription }
            .combinedClickable(onClick = onClick, onLongClick = {}),
        contentAlignment = Alignment.Center,
        content = content
    )
}

@Composable
private fun RopeVolumeSlider(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val audio = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val max = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var level by remember { mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max) }
    fun setLevel(v: Float) {
        level = v.coerceIn(0f, 1f)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (level * max).toInt(), 0)
    }
    Canvas(
        modifier = modifier.pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { p -> setLevel(p.x / size.width.toFloat()) },
                onDrag = { change, _ -> setLevel(change.position.x / size.width.toFloat()); change.consume() }
            )
        }
    ) {
        val y = size.height / 2f
        // dark shadow under the rope
        drawLine(Color.Black.copy(alpha=.48f), androidx.compose.ui.geometry.Offset(0f, y + 2.dp.toPx()), androidx.compose.ui.geometry.Offset(size.width, y + 2.dp.toPx()), 9.dp.toPx())
        // old rope body, deliberately muted rather than fluorescent
        drawLine(Color(0xFF6B5635), androidx.compose.ui.geometry.Offset(0f, y), androidx.compose.ui.geometry.Offset(size.width, y), 8.dp.toPx())
        drawLine(Color(0xFF9A7B49).copy(alpha=.72f), androidx.compose.ui.geometry.Offset(0f, y - 1.dp.toPx()), androidx.compose.ui.geometry.Offset(size.width, y - 1.dp.toPx()), 2.dp.toPx())
        // rope twist marks
        var x = 8.dp.toPx()
        while (x < size.width) {
            drawLine(Color(0xFF3D3020).copy(alpha=.65f), androidx.compose.ui.geometry.Offset(x - 4.dp.toPx(), y - 4.dp.toPx()), androidx.compose.ui.geometry.Offset(x + 4.dp.toPx(), y + 4.dp.toPx()), 1.2.dp.toPx())
            x += 18.dp.toPx()
        }
        val cx = level * size.width
        val stone = Path().apply {
            moveTo(cx - 12.dp.toPx(), y - 9.dp.toPx()); lineTo(cx + 8.dp.toPx(), y - 11.dp.toPx())
            lineTo(cx + 13.dp.toPx(), y - 2.dp.toPx()); lineTo(cx + 10.dp.toPx(), y + 9.dp.toPx())
            lineTo(cx - 8.dp.toPx(), y + 11.dp.toPx()); lineTo(cx - 14.dp.toPx(), y + 3.dp.toPx()); close()
        }
        drawPath(stone, Color(0xFF5A5A50))
        drawPath(stone, Color(0xFF8A8979), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5.dp.toPx()))
        drawLine(Color.Black.copy(alpha=.35f), androidx.compose.ui.geometry.Offset(cx-5.dp.toPx(), y-4.dp.toPx()), androidx.compose.ui.geometry.Offset(cx+4.dp.toPx(), y+3.dp.toPx()), 1.dp.toPx())
    }
}

@Composable
private fun RopeSeekSlider(value: Float, enabled: Boolean, onPreview: (Float?) -> Unit, onSeek: (Float) -> Unit, modifier: Modifier = Modifier) {
    var dragValue by remember { mutableFloatStateOf(value) }
    fun fraction(x: Float, width: Float) = if(width<=0f) 0f else (x/width).coerceIn(0f,1f)
    Canvas(
        modifier = modifier
            .pointerInput(enabled) { if(enabled) detectTapGestures(onTap={ p -> val f=fraction(p.x,size.width.toFloat()); dragValue=f; onPreview(null); onSeek(f) }) }
            .pointerInput(enabled) {
                if(enabled) detectDragGestures(
                    onDragStart={ p -> dragValue=fraction(p.x,size.width.toFloat()); onPreview(dragValue) },
                    onDrag={ change, _ -> dragValue=fraction(change.position.x,size.width.toFloat()); onPreview(dragValue); change.consume() },
                    onDragEnd={ onSeek(dragValue); onPreview(null) },
                    onDragCancel={ onPreview(null) }
                )
            }
    ) {
        val y = size.height / 2f
        val ropeDark = Color(0xFF3B2A18)
        val rope = Color(0xFF8C6A3D)
        val ropeHi = Color(0xFFB99558)
        drawLine(Color.Black.copy(alpha=.55f), androidx.compose.ui.geometry.Offset(0f, y + 2.dp.toPx()), androidx.compose.ui.geometry.Offset(size.width, y + 2.dp.toPx()), 9.dp.toPx())
        drawLine(ropeDark, androidx.compose.ui.geometry.Offset(0f, y), androidx.compose.ui.geometry.Offset(size.width, y), 8.dp.toPx())
        drawLine(rope, androidx.compose.ui.geometry.Offset(0f, y), androidx.compose.ui.geometry.Offset(size.width, y), 6.dp.toPx())
        drawLine(ropeHi.copy(alpha=.65f), androidx.compose.ui.geometry.Offset(0f, y - 1.5.dp.toPx()), androidx.compose.ui.geometry.Offset(size.width, y - 1.5.dp.toPx()), 1.5.dp.toPx())
        var x = 8.dp.toPx()
        while (x < size.width) {
            drawLine(ropeDark.copy(alpha=.72f), androidx.compose.ui.geometry.Offset(x-4.dp.toPx(), y-3.dp.toPx()), androidx.compose.ui.geometry.Offset(x+4.dp.toPx(), y+3.dp.toPx()), 1.dp.toPx())
            x += 17.dp.toPx()
        }
        val cx = value.coerceIn(0f,1f) * size.width
        val r = 11.dp.toPx()
        drawCircle(Color.Black.copy(alpha=.5f), r + 2.dp.toPx(), androidx.compose.ui.geometry.Offset(cx, y + 2.dp.toPx()))
        drawCircle(Color(0xFF4A4B43), r, androidx.compose.ui.geometry.Offset(cx, y))
        drawCircle(Color(0xFF858574), r, androidx.compose.ui.geometry.Offset(cx, y), style = androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))
        drawCircle(Color.White.copy(alpha=.16f), r*.42f, androidx.compose.ui.geometry.Offset(cx-r*.25f, y-r*.28f))
    }
}

@Composable
private fun LocalAudioMiniPip(model: BreakMonsterModel, modifier: Modifier = Modifier) {
    val remaining = (model.localDuration - model.localPosition).coerceAtLeast(0)
    Surface(color = Color(0xF500140C), modifier = modifier) {
        Row(
            Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Image(painter = painterResource(R.mipmap.ic_launcher), contentDescription = "BreakMonster", modifier = Modifier.size(42.dp))
            Text("-${timeLabel(remaining)}", color = MonsterGreen, fontSize = 18.sp, fontWeight = FontWeight.Black)
            Text("BACK", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun PlaybackBar(model: BreakMonsterModel, youtubePlayer: YouTubePlayer?, nameValue:String, onNameChange:(String)->Unit, onSaveYoutube: () -> Unit, onTransitionNext: () -> Unit, onTransitionStop: () -> Unit, onSeekPreview: (Boolean) -> Unit, onSeekTarget: (Float) -> Unit, onFeedMonster: () -> Unit, modifier: Modifier = Modifier) {
    val ytActive = model.youtubeVideoId != null
    val localActive = model.localTrackUri != null
    var seekPreview by remember { mutableStateOf<Float?>(null) }
    Surface(
        color = Color(0xF500140C),
        tonalElevation = 4.dp,
        modifier = modifier.fillMaxWidth().height(158.dp).border(1.dp, Amber.copy(alpha = .65f))
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 6.dp)) {
            if (ytActive && model.youtubeCanSave) {
                OutlinedTextField(
                    value=nameValue,
                    onValueChange=onNameChange,
                    singleLine=true,
                    label={Text("IME NUMERE",fontSize=11.sp)},
                    textStyle=TextStyle(color=Color.White,fontSize=15.sp,fontWeight=FontWeight.Bold),
                    modifier=Modifier.fillMaxWidth().height(48.dp),
                    colors=androidx.compose.material3.OutlinedTextFieldDefaults.colors(focusedTextColor=Color.White,unfocusedTextColor=Color.White,focusedBorderColor=MonsterGreen,unfocusedBorderColor=MonsterGreen.copy(alpha=.6f),focusedLabelColor=MonsterGreen,unfocusedLabelColor=MonsterGreen)
                )
            } else Text(
                when { ytActive -> model.youtubeTitle ?: "YouTube"; localActive -> model.localTrackName ?: "BREAK"; else -> "BREAKMONSTER READY" },
                color=Color.White,fontSize=18.sp,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis
            )
            Row(
                Modifier.fillMaxWidth().height(72.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        if (ytActive) {
                            if (model.youtubePlaying) youtubePlayer?.pause() else youtubePlayer?.play()
                        } else model.toggleLocalPause()
                    },
                    enabled = ytActive || localActive,
                    modifier = Modifier.size(width = 60.dp, height = 52.dp),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color.Black)
                ) { Text(if (if (ytActive) model.youtubePlaying else model.localPlaying) "Ⅱ" else "▶", fontSize = 26.sp, fontWeight = FontWeight.Black) }

                Button(
                    onClick = {
                        onTransitionStop()
                        if (ytActive) {
                            youtubePlayer?.pause(); youtubePlayer?.seekTo(0f); model.stopPlayback()
                        } else model.stopPlayback()
                    },
                    enabled = ytActive || localActive,
                    modifier = Modifier.size(width = 60.dp, height = 52.dp),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MutedGreen, contentColor = Color.White)
                ) { Text("■", fontSize = 24.sp) }

                if (ytActive && model.youtubeCanSave && !model.youtubeSaved) {
                    Button(
                        onClick = onSaveYoutube,
                        modifier = Modifier.height(52.dp).weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MutedGreen, contentColor = Color.White)
                    ) { Text("SAVE YT", fontWeight = FontWeight.Black, fontSize = 17.sp) }
                } else {
                    PlaylistStoneButton(
                        onClick = {
                            if (ytActive) { youtubePlayer?.pause(); onTransitionNext() }
                            if (ytActive || localActive) model.nextLocal()
                        },
                        active = ytActive || localActive,
                        modifier = Modifier.width(125.dp).height(60.dp)
                    ) { Text("NEXT  ▶", color = Color.White, fontWeight = FontWeight.Black, fontSize = 19.sp) }
                }

                val pos = if (ytActive) (model.youtubeCurrentSecond * 1000).toInt() else model.localPosition
                val dur = if (ytActive) (model.youtubeDurationSecond * 1000).toInt() else model.localDuration
            val shownPos=seekPreview?.let { (it*dur).toInt() } ?: pos
            Text("${timeLabel(shownPos)} / ${timeLabel(dur)}", color = MonsterGreen, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                FeedLittleMonster(onClick = onFeedMonster, modifier = Modifier.weight(1f))
            }
            val pos = if (ytActive) (model.youtubeCurrentSecond * 1000).toInt() else model.localPosition
            val dur = if (ytActive) (model.youtubeDurationSecond * 1000).toInt() else model.localDuration
            RopeSeekSlider(
                value = seekPreview ?: if (dur > 0) pos.coerceIn(0, dur).toFloat() / dur else 0f,
                enabled = dur > 0,
                onPreview = {
                    val wasDragging = seekPreview != null
                    seekPreview = it
                    if ((it != null) != wasDragging && ytActive) onSeekPreview(it != null)
                },
                onSeek = { fraction ->
                    val target = (fraction * dur).toInt()
                    if (ytActive) {
                        onSeekTarget(target / 1000f)
                        youtubePlayer?.seekTo(target / 1000f)
                    } else model.seekLocal(target)
                },
                modifier = Modifier.fillMaxWidth().height(28.dp)
            )
        }
    }
}

private fun timeLabel(ms: Int): String = "%d:%02d".format(Locale.ROOT, ms / 60000, ms / 1000 % 60)

@Composable
private fun YouTubeBadge(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val radius = size.minDimension * .20f
        drawRoundRect(color = Color(0xFFFF0000), cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius))
        val p = Path().apply {
            moveTo(size.width * .42f, size.height * .30f)
            lineTo(size.width * .72f, size.height * .50f)
            lineTo(size.width * .42f, size.height * .70f)
            close()
        }
        drawPath(p, Color.White)
    }
}

@Composable
private fun ShuffleGlyph(crossed:Boolean, modifier:Modifier=Modifier, tint:Color=Color.White) {
    Canvas(modifier) {
        val w=size.width; val h=size.height
        val inset=w*.13f; val half=h*.5f; val stroke=(h*.095f).coerceAtLeast(1.5.dp.toPx())
        fun arrow(x1:Float,y1:Float,x2:Float,y2:Float) {
            drawLine(tint,androidx.compose.ui.geometry.Offset(x1,y1),androidx.compose.ui.geometry.Offset(x2,y2),stroke,cap=androidx.compose.ui.graphics.StrokeCap.Round)
            val direction=if(x2>=x1) 1f else -1f
            val back=x2-direction*w*.18f
            val head=h*.16f
            drawLine(tint,androidx.compose.ui.geometry.Offset(x2,y2),androidx.compose.ui.geometry.Offset(back,y2-head),stroke,cap=androidx.compose.ui.graphics.StrokeCap.Round)
            drawLine(tint,androidx.compose.ui.geometry.Offset(x2,y2),androidx.compose.ui.geometry.Offset(back,y2+head),stroke,cap=androidx.compose.ui.graphics.StrokeCap.Round)
        }
        if(crossed) {
            arrow(inset,h*.25f,w-inset,h*.75f)
            arrow(w-inset,h*.25f,inset,h*.75f)
        } else {
            arrow(inset,h*.31f,w-inset,h*.31f)
            arrow(w-inset,h*.69f,inset,h*.69f)
        }
    }
}

@Composable
private fun MediaTypeBadge(extension:String) {
    val ext=extension.uppercase(Locale.ROOT).ifBlank { "FILE" }
    val label=when(ext){"WAVE"->"WAV";"M4V"->"MP4";"3G2"->"3GP";"M2TS"->"TS";else->ext}
    val video=ext in setOf("MP4","M4V","MOV","3GP","3G2","MKV","WEBM","AVI","TS","M2TS","MPEG","MPG")
    Box(Modifier.widthIn(min=42.dp).height(28.dp).background(if(video)Color(0xFF34483A)else Color(0xFF263B2E),RoundedCornerShape(6.dp)).border(1.dp,MonsterGreen.copy(alpha=.6f),RoundedCornerShape(6.dp)),contentAlignment=Alignment.Center){
        Text(label,color=Color.White,fontSize=10.sp,fontWeight=FontWeight.Black,maxLines=1,modifier=Modifier.padding(horizontal=4.dp))
    }
}

@Composable
private fun YoutubeSurface(
    videoId: String,
    session: Int,
    pipMode: Boolean,
    onPlayer: (YouTubePlayer?) -> Unit,
    onPlaying: (Boolean) -> Unit,
    onCurrentSecond: (Float) -> Unit,
    onDuration: (Float) -> Unit,
    onPlaybackError: (PlayerConstants.PlayerError) -> Unit,
    onEnded: () -> Unit,
    onTap: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val latestOnPlaying by rememberUpdatedState(onPlaying)
    val latestOnSecond by rememberUpdatedState(onCurrentSecond)
    val latestOnDuration by rememberUpdatedState(onDuration)
    val latestOnError by rememberUpdatedState(onPlaybackError)
    val latestOnEnded by rememberUpdatedState(onEnded)
    Box(
            modifier = modifier.background(Color.Black, RoundedCornerShape(if (pipMode) 0.dp else 10.dp))
                .then(if (pipMode) Modifier else Modifier.border(2.dp, MonsterGreen, RoundedCornerShape(10.dp)))
        ) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { uiContext ->
                    val wrapped = MutableContextWrapper(uiContext)
                    YouTubePlayerView(wrapped).apply {
                        enableAutomaticInitialization = false
                        val options = IFramePlayerOptions.Builder(wrapped)
                            .controls(0)
                            .fullscreen(0)
                            .rel(0)
                            .ivLoadPolicy(3)
                            .ccLoadPolicy(0)
                            .autoplay(1)
                            .mute(0)
                            .build()
                        val listener = object : AbstractYouTubePlayerListener() {
                            override fun onReady(youTubePlayer: YouTubePlayer) {
                                setTag(0x7f0f0101, youTubePlayer)
                                onPlayer(youTubePlayer)
                                // One persistent iframe: switch tracks with the official loadVideo API.
                                val requested = getTag(0x7f0f0102) as? String ?: videoId
                                setTag(0x7f0f0103, requested)
                                youTubePlayer.loadVideo(requested, 0f)
                            }
                            override fun onStateChange(youTubePlayer: YouTubePlayer, state: PlayerConstants.PlayerState) {
                                latestOnPlaying(state == PlayerConstants.PlayerState.PLAYING)
                                if (state == PlayerConstants.PlayerState.ENDED) latestOnEnded()
                            }
                            override fun onCurrentSecond(youTubePlayer: YouTubePlayer, second: Float) { latestOnSecond(second) }
                            override fun onVideoDuration(youTubePlayer: YouTubePlayer, duration: Float) { latestOnDuration(duration) }
                            override fun onError(youTubePlayer: YouTubePlayer, error: PlayerConstants.PlayerError) { latestOnError(error) }
                        }
                        setTag(0x7f0f0102, videoId)
                        initialize(listener, false, options, videoId)
                    }
                },
                update = { view ->
                    (view.context as? MutableContextWrapper)?.baseContext = context
                    view.setTag(0x7f0f0102, videoId)
                    val player = view.getTag(0x7f0f0101) as? YouTubePlayer
                    if (player != null && view.getTag(0x7f0f0103) != videoId) {
                        view.setTag(0x7f0f0103, videoId)
                        // Explicitly stop the outgoing audio on manual track changes.
                        // Keep the same iframe; do not introduce a second player or timer.
                        player.pause()
                        // loadVideo maps to the YouTube IFrame API loadVideoById operation.
                        player.loadVideo(videoId, 0f)
                    }
                },
                onRelease = { view ->
                    // Release only when the YouTube surface actually leaves composition.
                    runCatching {
                        (view.getTag(0x7f0f0101) as? YouTubePlayer)?.let { outgoing ->
                            outgoing.mute()
                            outgoing.pause()
                        }
                    }
                    view.setTag(0x7f0f0101, null)
                    onPlayer(null)
                    runCatching { view.release() }
                }
            )
            if (!pipMode) {
                // The embedded player has controls disabled; this tap target cycles its size.
                // The AndroidView itself stays keyed only by session, so resizing preserves playback.
                Box(Modifier.matchParentSize().pointerInput(onTap) { detectTapGestures(onTap = { onTap() }) })
            }
        }
}

private class YoutubeJsBridge(
    private val web: WebView,
    private val onSelected: (String, String?, String) -> Unit
) {
    @JavascriptInterface
    fun select(url: String?, title: String?) {
        val id = BreakMonsterModel.extractYoutubeVideoId(url) ?: return
        val canonical = "https://www.youtube.com/watch?v=$id"
        web.post { onSelected(id, title?.trim(), canonical) }
    }
}

@Composable
private fun YoutubeSearchPanel(
    url: String,
    onSelected: (String, String?, String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var webView by remember { mutableStateOf<WebView?>(null) }

    Box(modifier.background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { uiContext ->
                val created = WebView(uiContext)
                webView = created
                CookieManager.getInstance().apply {
                    setAcceptCookie(true)
                    setAcceptThirdPartyCookies(created, true)
                }
                created.apply {
                    setBackgroundColor(AndroidColor.BLACK)
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = true
                    addJavascriptInterface(YoutubeJsBridge(this, onSelected), "BreakHost")
                    webChromeClient = WebChromeClient()
                    webViewClient = object : WebViewClient() {
                        private fun intercept(raw: String?): Boolean {
                            val id = BreakMonsterModel.extractYoutubeVideoId(raw) ?: return false
                            onSelected(id, null, "https://www.youtube.com/watch?v=$id")
                            return true
                        }
                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = intercept(request?.url?.toString())
                        @Suppress("DEPRECATION")
                        override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean = intercept(url)
                        override fun onPageFinished(view: WebView, pageUrl: String) {
                            super.onPageFinished(view, pageUrl)
                            // Search page stays silent; a selected result is handed to the official native embed player.
                            val js = """(function(){try{
                              document.querySelectorAll('video,audio').forEach(function(v){try{v.muted=true;v.pause();}catch(e){}});
                              if(window.__breakMonsterTap)return; window.__breakMonsterTap=true;
                              function pick(ev){try{
                                var el=ev.target; while(el&&el!==document){
                                  if(el.tagName==='A'&&el.href){
                                    var u=new URL(el.href,location.href),h=u.hostname.replace(/^www\\.|^m\\./,'');
                                    var id=null;
                                    if(h==='youtu.be') id=u.pathname.split('/').filter(Boolean)[0]||null;
                                    else if(h==='youtube.com'||h.endsWith('.youtube.com')){
                                      if(u.pathname==='/watch') id=u.searchParams.get('v');
                                      else if(u.pathname.indexOf('/shorts/')===0||u.pathname.indexOf('/live/')===0) id=u.pathname.split('/')[2]||null;
                                    }
                                    if(id&&/^[A-Za-z0-9_-]{6,20}$/.test(id)){
                                      ev.preventDefault();ev.stopPropagation();if(ev.stopImmediatePropagation)ev.stopImmediatePropagation();
                                      var t='';try{t=(el.getAttribute('title')||el.getAttribute('aria-label')||el.textContent||'').replace(/\\s+/g,' ').trim();}catch(e){}
                                      BreakHost.select('https://www.youtube.com/watch?v='+id,t);return false;
                                    }
                                  }
                                  el=el.parentElement;
                                }
                              }catch(e){}}
                              document.addEventListener('click',pick,true);
                            }catch(e){}})()"""
                            view.evaluateJavascript(js, null)
                        }
                    }
                    loadUrl(url)
                }
            },
            update = { }
        )

    }
}

/** Import ZIP contents off the UI thread; each root/folder collection becomes one playlist. */
private suspend fun importYtMonsterZip(context: Context, uri: Uri, store: BreakPlaylistStore, model: BreakMonsterModel): String = try {
    val groups = withContext(Dispatchers.IO) {
        val collected = linkedMapOf<String, MutableList<Pair<String, String>>>()
        var skipped = 0
        java.util.zip.ZipInputStream(context.contentResolver.openInputStream(uri) ?: error("Cannot open ZIP")).use { zip ->
            var count = 0
            while (true) {
                val entry = zip.nextEntry ?: break
                count++
                check(count <= 1_000_000) { "ZIP exceeds the 1,000,000-entry safety limit" }
                if (!entry.isDirectory && entry.name.endsWith(".yt", true)) {
                    val path = entry.name.replace('\\', '/')
                    val name = path.substringAfterLast('/').dropLast(3).trim()
                    val parent = path.substringBeforeLast('/', "").trim('/')
                    val collection = parent.replace("/", " • ").ifBlank { "YT IMPORT" }
                    val bytes = zip.readBytes()
                    if (bytes.size > 8192 || name.isBlank()) skipped++
                    else {
                        val content = bytes.toString(Charsets.UTF_8).removePrefix("\uFEFF").trim()
                        if (BreakMonsterModel.extractYoutubeVideoId(content) == null) skipped++
                        else collected.getOrPut(collection) { mutableListOf() }.add(name to content)
                    }
                }
                zip.closeEntry()
            }
        }
        Pair(collected, skipped)
    }
    val (collections, skippedAtRead) = groups
    if (collections.isEmpty()) "0 imported, $skippedAtRead skipped"
    else {
        val jobs = collections.mapNotNull { (name, links) ->
            store.createUnique(name)?.let { it to links }
        }
        if (jobs.isEmpty()) return "ZIP import failed: could not create playlists."
        var imported = 0
        var rejected = skippedAtRead + (collections.size - jobs.size)
        suspendCoroutine<String> { continuation ->
            fun runAt(index: Int) {
                if (index >= jobs.size) {
                    continuation.resume("ZIP: $imported imported, $rejected skipped in ${jobs.size} playlists")
                    return
                }
                val (destination, links) = jobs[index]
                model.importYoutubeLinksToPlaylist(destination, links,
                    { saved, failed ->
                        val entries=saved.map { (name,fileUri,videoId) -> BreakPlaylistEntry(name,fileUri,true,sourceKind="ZIP_IMPORT",videoId=videoId) }
                        if(store.addEntries(destination,entries)) entries.size to failed else 0 to (entries.size+failed)
                    }
                ) { added, failed ->
                    imported += added
                    rejected += failed
                    runAt(index + 1)
                }
            }
            runAt(0)
        }
    }
} catch (error: Throwable) {
    "ZIP import failed: ${error.message ?: error.javaClass.simpleName}"
}
