package com.teraphonia.breakmonster

import android.app.PictureInPictureParams
import android.app.Activity
import android.app.PendingIntent
import android.app.RemoteAction
import android.graphics.drawable.Icon
import android.os.Build
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.MutableContextWrapper
import android.content.res.Configuration
import android.graphics.Color as AndroidColor
import android.media.AudioManager
import android.net.Uri
import android.provider.MediaStore
import android.os.Bundle
import android.speech.RecognizerIntent
import android.content.pm.PackageManager
import android.util.Rational
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.IntentSenderRequest
import androidx.activity.viewModels
import androidx.compose.foundation.Canvas
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.zIndex
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.compose.ui.viewinterop.AndroidView
import androidx.documentfile.provider.DocumentFile
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.PlayerConstants
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.options.IFramePlayerOptions
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.net.URLEncoder
import java.util.Locale

private val DeepGreen = Color(0xFF001B10)
private val PanelGreen = Color(0xE5142E21)
private val Amber = Color(0xFFFFB52E)
private val MonsterGreen = Color(0xFF86F500)
private val MutedGreen = Color(0xFF294535)

class MainActivity : ComponentActivity() {
    private val model by viewModels<BreakMonsterModel>()
    private var pipMode by mutableStateOf(false)
    private var showReturnLogo by mutableStateOf(false)
    private var returnLogoPending = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = AndroidColor.rgb(0, 27, 16)
        window.navigationBarColor = AndroidColor.rgb(0, 27, 16)
        setContent {
            BreakMonsterTheme {
                BreakMonsterApp(model = model, pipMode = pipMode, showReturnLogo = showReturnLogo, moveTaskToBack = { moveTaskToBack(true) })
            }
        }
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) returnLogoPending = true
    }

    override fun onResume() {
        super.onResume()
        if (returnLogoPending && !isInPictureInPictureMode) {
            returnLogoPending = false
            showReturnLogo = true
            android.os.Handler(mainLooper).postDelayed({ showReturnLogo = false }, 650L)
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if ((model.youtubeVideoId != null || model.localTrackUri != null) && !isInPictureInPictureMode) {
            runCatching {
                val builder = PictureInPictureParams.Builder()
                if (model.youtubeVideoId != null) {
                    builder.setAspectRatio(Rational(16, 9))
                } else {
                    builder.setAspectRatio(Rational(5, 1))
                    val backIntent = Intent(this, MainActivity::class.java)
                        .setAction("com.teraphonia.breakmonster.BACK_FROM_AUDIO_PIP")
                        .addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    val pending = PendingIntent.getActivity(this, 9208, backIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    builder.setActions(listOf(RemoteAction(Icon.createWithResource(this, R.mipmap.ic_launcher), "BACK", "Back to BreakMonster", pending)))
                }
                enterPictureInPictureMode(builder.build())
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // Launching this singleTask activity from the PiP BACK action restores it to foreground.
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        pipMode = isInPictureInPictureMode
    }
}

@Composable
private fun BreakMonsterTheme(content: @Composable () -> Unit) {
    val colors = darkColorScheme(
        primary = Amber,
        secondary = MonsterGreen,
        background = DeepGreen,
        surface = DeepGreen,
        onPrimary = Color.Black,
        onSecondary = Color.Black,
        onBackground = Color.White,
        onSurface = Color.White
    )
    MaterialTheme(colorScheme = colors, content = content)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BreakMonsterApp(
    model: BreakMonsterModel,
    pipMode: Boolean,
    showReturnLogo: Boolean,
    moveTaskToBack: () -> Unit
) {
    val context = LocalContext.current
    var showYoutubeSearchInput by remember { mutableStateOf(false) }
    var youtubeQuery by remember { mutableStateOf("") }
    var localQuery by remember { mutableStateOf("") }
    var speechTarget by remember { mutableStateOf("local") }
    var youtubeSearchUrl by remember { mutableStateOf<String?>(null) }
    var selectedForMenu by remember { mutableStateOf<BreakItem?>(null) }
    var showSavePicker by remember { mutableStateOf(false) }
    var renameMode by remember { mutableStateOf(false) }
    var renameText by remember { mutableStateOf("") }
    var deleteFileConfirm by remember { mutableStateOf(false) }
    var playerRef by remember { mutableStateOf<YouTubePlayer?>(null) }
    val playlists = remember { BreakPlaylistStore(context) }
    var pendingMediaDelete by remember { mutableStateOf<BreakItem?>(null) }
    val mediaDeleteLauncher=rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        val item=pendingMediaDelete
        if(result.resultCode==Activity.RESULT_OK && item!=null) { model.onMediaStoreDeleteApproved(item);playlists.removeMedia(item.file.uri.toString()) }
        pendingMediaDelete=null
    }
    var pendingMediaRename by remember { mutableStateOf<Pair<BreakItem,String>?>(null) }
    val mediaWriteLauncher=rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        val pending=pendingMediaRename
        if(result.resultCode==Activity.RESULT_OK && pending!=null) {
            model.rename(pending.first,pending.second);playlists.renameMedia(pending.first.file.uri.toString(),pending.second)
        }
        pendingMediaRename=null
    }
    fun renameConfirmed(item:BreakItem,name:String) {
        if(android.os.Build.VERSION.SDK_INT>=30 && item.file.uri.authority=="media") {
            runCatching {
                pendingMediaRename=item to name
                val request=MediaStore.createWriteRequest(context.contentResolver,listOf(item.file.uri))
                mediaWriteLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
            }.onFailure { pendingMediaRename=null;Toast.makeText(context,"Android could not authorize this rename.",Toast.LENGTH_LONG).show() }
        } else { model.rename(item,name);playlists.renameMedia(item.file.uri.toString(),name) }
    }
    fun deleteConfirmed(item:BreakItem) {
        if(android.os.Build.VERSION.SDK_INT>=30 && item.file.uri.authority=="media") {
            runCatching {
                pendingMediaDelete=item
                val request=MediaStore.createDeleteRequest(context.contentResolver,listOf(item.file.uri))
                mediaDeleteLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
            }.onFailure { pendingMediaDelete=null;Toast.makeText(context,"Android could not authorize this deletion.",Toast.LENGTH_LONG).show() }
        } else model.delete(item){playlists.removeMedia(item.file.uri.toString())}
    }
    var playlistVisible by remember { mutableStateOf(false) }
    var playlistTab by remember { mutableIntStateOf(playlists.activeIndex) }
    var browserSection by remember { mutableStateOf("ALL MUSIC") }
    var importUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var importCursor by remember { mutableIntStateOf(0) }
    var importConflict by remember { mutableStateOf<Uri?>(null) }
    var playlistImportSource by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { playlists.ensureBundledP1(model.bundledP1Items()) }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken=result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
        if(spoken.isNotBlank()) {
            if(speechTarget=="youtube") { youtubeQuery=spoken; youtubeSearchUrl="https://www.youtube.com/results?search_query="+URLEncoder.encode(spoken,"UTF-8") }
            else localQuery=spoken
        }
    }
    fun startVoiceSearch(target:String) {
        speechTarget=target
        val intent=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak your search")
        runCatching { speechLauncher.launch(intent) }.onFailure { Toast.makeText(context,"Voice search is not available.",Toast.LENGTH_SHORT).show() }
    }
    val audioPermission = if(Build.VERSION.SDK_INT>=33) android.Manifest.permission.READ_MEDIA_AUDIO else android.Manifest.permission.READ_EXTERNAL_STORAGE
    val musicPermissionLauncher=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if(granted) model.scanMediaStore() else Toast.makeText(context,"Music access was not granted.",Toast.LENGTH_LONG).show()
    }
    fun findMyMusic() {
        BlackBox.log("UI FIND YOUR MUSIC")
        model.home()
        model.findInstalledWelcome()?.let { model.startPlaylist(listOf(it),0) }
        if(ContextCompat.checkSelfPermission(context,audioPermission)==PackageManager.PERMISSION_GRANTED) model.scanMediaStore()
        else musicPermissionLauncher.launch(audioPermission)
    }
    val prefs = remember { context.getSharedPreferences("breakmonster_ui", 0) }
    var swipeFeedback by remember { mutableStateOf<Pair<Int,Int>?>(null) }
    var swipeFeedbackSequence by remember { mutableIntStateOf(0) }
    var swipeBlinkUri by remember { mutableStateOf<String?>(null) }
    var folderSwipeHint by remember { mutableStateOf(false) }
    var playlistHint by remember { mutableStateOf(false) }
    var reorderHint by remember { mutableStateOf(false) }
    var playlistReorderHint by remember { mutableStateOf(false) }
    LaunchedEffect(model.allMusicItems.size, browserSection) {
        if(browserSection=="ALL MUSIC" && model.allMusicItems.isNotEmpty() && !prefs.getBoolean("folderSwipeHintDone", false)) {
            folderSwipeHint = true
        }
    }
    LaunchedEffect(model.tracks.size, model.rootUri, model.path, browserSection) {
        if(browserSection=="ALL MUSIC" && model.rootUri!=null && model.path.isEmpty() && model.tracks.size>1 && prefs.getBoolean("folderSwipeHintDone",false) && !prefs.getBoolean("reorderGestureHintDone",false)) reorderHint=true
    }
    LaunchedEffect(playlistVisible, playlistTab, playlists.lists.getOrNull(playlistTab)?.size) {
        if(playlistVisible && (playlists.lists.getOrNull(playlistTab)?.size ?: 0) > 1 && prefs.getBoolean("playlistHintDone",false) && !prefs.getBoolean("playlistReorderGestureHintDone",false)) playlistReorderHint=true
    }
    LaunchedEffect(folderSwipeHint){ if(folderSwipeHint){ delay(8000); folderSwipeHint=false } }
    LaunchedEffect(playlistVisible, playlists.lists.getOrNull(playlistTab)?.size){
        if(playlistVisible && playlists.lists.getOrNull(playlistTab)?.isNotEmpty()==true && !prefs.getBoolean("playlistHintDone", false)) playlistHint=true
    }
    LaunchedEffect(playlistHint){ if(playlistHint){ delay(14000); playlistHint=false } }
    LaunchedEffect(swipeFeedback){ if(swipeFeedback!=null){ delay(2000); swipeFeedback=null } }
    LaunchedEffect(swipeFeedbackSequence){ if(swipeBlinkUri!=null){ delay(240); swipeBlinkUri=null } }
    fun showSwipeFeedback(added:Boolean, playlist:Int){
        swipeFeedbackSequence++; swipeFeedback = swipeFeedbackResource(added, playlist) to swipeFeedbackSequence
    }

    LaunchedEffect(model.youtubeVideoId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (context as? MainActivity)?.setPictureInPictureParams(
                PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .setAutoEnterEnabled(model.youtubeVideoId != null)
                    .build()
            )
        }
    }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                runCatching { context.contentResolver.takePersistableUriPermission(uri, flags) }
                    .getOrElse { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                model.setRoot(uri)
            } catch (_: SecurityException) {
                Toast.makeText(context, "Folder permission nije sačuvan.", Toast.LENGTH_LONG).show()
            }
        }
    }
    val mediaImportPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        importUris = uris; importCursor = 0; importConflict = null
        if (uris.isNotEmpty()) {
            uris.forEach { uri -> runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
            browserSection = "BRAKEMONSTER"
        }
    }
    val playlistFilePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            playlistTab = importM3uPlaylist(context, uri, model.allMusicItems, playlists)
        }
    }

    LaunchedEffect(model.rootUri, model.path, model.refreshSerial) { model.refresh() }

    LaunchedEffect(importUris, importCursor, importConflict) {
        if (importCursor < importUris.size && importConflict == null) {
            val uri = importUris[importCursor]
            val name = model.importName(uri)
            if (model.importedNameExists(name)) importConflict = uri
            else { model.copyImport(uri, "cancel"); importCursor++ }
        } else if (importCursor >= importUris.size) importUris = emptyList()
    }

    fun resolveImportConflict(choice: String) {
        val uri = importConflict ?: return
        if (choice != "cancel") model.copyImport(uri, choice)
        importConflict = null; importCursor++
    }

    LaunchedEffect(model.message) {
        model.message?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            model.consumeMessage()
        }
    }

    BackHandler(enabled = !pipMode) {
        when {
            youtubeSearchUrl != null -> youtubeSearchUrl = null
            showYoutubeSearchInput -> showYoutubeSearchInput = false
            selectedForMenu != null -> selectedForMenu = null
            model.back() -> Unit
            else -> moveTaskToBack()
        }
    }

    Box(Modifier.fillMaxSize()) {
        if (!pipMode) {
            Image(
                painter = painterResource(R.drawable.breakmonster_stage),
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize()
            )

            // Keep the original stage-art header visible: HOME / BACK / logo / folder ventilation.
            Image(
                painter = painterResource(R.drawable.breakmonster_logo),
                contentDescription = "BreakMonster",
                contentScale = ContentScale.Fit,
                modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth(.50f).heightIn(max = 104.dp).padding(top = 2.dp)
            )
            BoxWithConstraints(Modifier.align(Alignment.TopCenter).fillMaxWidth().height(104.dp)) {
                val w = maxWidth
                Box(Modifier.offset(x = w * .012f).width(w * .12f).fillMaxHeight().combinedClickable(onClick = { BlackBox.log("UI HOME"); browserSection="ALL MUSIC"; playlistVisible=false; youtubeSearchUrl=null; model.home() }, onLongClick = {}))
                Box(Modifier.offset(x = w * .125f).width(w * .14f).fillMaxHeight().combinedClickable(onClick = { BlackBox.log("UI BACK"); model.back() }, onLongClick = {}))

                // The folder is already painted into the stage artwork. Keep the art untouched
                // and make that painted ventilation/folder area itself the folder picker target.
                Box(
                    Modifier.offset(x = w * .655f, y = 30.dp).width(w * .19f).height(96.dp)
                        .semantics { contentDescription = "Folder decoration" }
                )
            }

            BreakBrowserArea(
                    model = model,
                    onYoutubeSearch = { val q=youtubeQuery.trim(); if(q.isNotBlank()) youtubeSearchUrl="https://www.youtube.com/results?search_query="+URLEncoder.encode(q,"UTF-8") else showYoutubeSearchInput=true },
                    onFindMusic = ::findMyMusic,
                    showFindMusic = !model.mediaScanComplete,
                    firstScanBusy = model.mediaScanInProgress,
                    localQuery = localQuery,
                    onLocalQuery = { localQuery = it },
                    youtubeQuery = youtubeQuery,
                    onYoutubeQuery = { youtubeQuery = it },
                    onLocalMic = { startVoiceSearch("local") },
                    onYoutubeMic = { startVoiceSearch("youtube") },
                    onOpenFolder = { model.openFolder(it) },
                    onTrack = { item -> model.startLocal(item) },
                    selectedItem = selectedForMenu,
                    onSelect = { item -> selectedForMenu = item },
                    onDeselect = { selectedForMenu = null },
                    playlistVisible = playlistVisible,
                    playlistStore = playlists,
                    random = model.random,
                    repeat = model.repeat,
                    onRandom = { model.updateRandom(!model.random) },
                    onRepeat = { model.updateRepeat(!model.repeat) },
                    onCreatePlaylist = { name -> val index=playlists.create(name); playlistTab=index },
                    playlistTab = playlistTab,
                    onPlaylistTab = { playlistTab = it; playlists.activate(it) },
                    onTogglePlaylist = { playlistVisible = !playlistVisible },
                    folderSwipeHint = folderSwipeHint,
                    playlistHint = playlistHint,
                    swipeBlinkUri = swipeBlinkUri,
                    onSwipeAdded = { item ->
                        if (!prefs.getBoolean("folderSwipeHintDone", false)) {
                            prefs.edit().putBoolean("folderSwipeHintDone", true).apply()
                            if(model.rootUri!=null && model.path.isEmpty() && model.tracks.size>1 && !prefs.getBoolean("reorderGestureHintDone",false)) reorderHint=true
                        }
                        folderSwipeHint = false
                        val added = playlists.add(item)
                        if (added) {
                            swipeBlinkUri=item.file.uri.toString(); showSwipeFeedback(true, playlists.activeIndex+1)
                            Toast.makeText(context,"ADDED TO ${playlists.displayName(playlists.activeIndex)}",Toast.LENGTH_SHORT).show()
                        }
                        else Toast.makeText(context, "Već je u ${playlists.displayName(playlists.activeIndex)}", Toast.LENGTH_SHORT).show()
                    },
                    onSwipeRemoved = { pl -> showSwipeFeedback(false, pl) },
                    onPlaylistGestureLearned = {
                        prefs.edit().putBoolean("playlistHintDone", true).apply(); playlistHint=false
                        if((playlists.lists.getOrNull(playlistTab)?.size ?: 0)>1 && !prefs.getBoolean("playlistReorderGestureHintDone",false)) playlistReorderHint=true
                    },
                    youtubeSearchUrl = youtubeSearchUrl,
                    onYoutubeSelected = { id, title, url ->
                        model.selectYoutube(id, title, url)
                        youtubeSearchUrl = null
                    },
                    onYoutubeClose = { youtubeSearchUrl = null },
                    browserSection = browserSection,
                    onBrowserSection = { browserSection = it; model.home() },
                    onImportMedia = { mediaImportPicker.launch(arrayOf("*/*")) },
                    onImportPlaylist = { playlistImportSource = true },
                    reorderHint = reorderHint,
                    onReorderGestureLearned = { prefs.edit().putBoolean("reorderGestureHintDone",true).apply(); reorderHint=false },
                    playlistReorderHint = playlistReorderHint,
                    onPlaylistReorderLearned = { prefs.edit().putBoolean("playlistReorderGestureHintDone",true).apply(); playlistReorderHint=false }
                )

            swipeFeedback?.let { (resource, sequence) ->
                key(sequence) { GestureManual(resource, Modifier.align(Alignment.TopCenter).padding(top=188.dp).fillMaxWidth().height(128.dp).zIndex(110f)) }
            }

            PlaybackBar(
                model = model,
                youtubePlayer = playerRef,
                onSaveYoutube = { model.saveYoutubeToFolder() },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }

        if (pipMode && model.youtubeVideoId == null && model.localTrackUri != null) {
            LocalAudioMiniPip(model = model, modifier = Modifier.fillMaxSize())
        }

        model.youtubeVideoId?.let { videoId ->
            YoutubeSurface(
                videoId = videoId,
                session = model.youtubeSession,
                pipMode = pipMode,
                onPlayer = { playerRef = it },
                onPlaying = model::onYoutubePlaying,
                onCurrentSecond = model::onYoutubeCurrentSecond,
                onDuration = model::onYoutubeDuration,
                onPlaybackError = {
                    Toast.makeText(context, "YouTube video nije dostupan za embed.", Toast.LENGTH_LONG).show()
                },
                onEnded = model::onYoutubeEnded,
                modifier = if (pipMode) Modifier.fillMaxSize() else Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 10.dp, bottom = 148.dp)
                    .fillMaxWidth(.38f)
                    .aspectRatio(16f / 9f)
            )
        }
    }

    if (showYoutubeSearchInput) {
        AlertDialog(
            onDismissRequest = { showYoutubeSearchInput = false },
            title = { Text("YOUTUBE SEARCH", fontSize = 24.sp, fontWeight = FontWeight.Black) },
            text = {
                OutlinedTextField(
                    value = youtubeQuery,
                    onValueChange = { youtubeQuery = it },
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 22.sp),
                    label = { Text("Search") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val q = youtubeQuery.trim()
                        if (q.isNotBlank()) {
                            youtubeSearchUrl = "https://www.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8")
                            showYoutubeSearchInput = false
                        }
                    },
                    enabled = youtubeQuery.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color.Black)
                ) { Text("SEARCH", fontWeight = FontWeight.Black) }
            },
            dismissButton = { TextButton(onClick = { showYoutubeSearchInput = false }) { Text("CANCEL") } }
        )
    }

    if (showReturnLogo && !pipMode) {
        Box(Modifier.fillMaxSize().background(DeepGreen).zIndex(100f), contentAlignment = Alignment.Center) {
            Image(
                painter = painterResource(R.drawable.breakmonster_logo),
                contentDescription = "BreakMonster",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxWidth(.72f).heightIn(max = 220.dp)
            )
        }
    }


    selectedForMenu?.let { item ->
        if(!renameMode && !deleteFileConfirm) AlertDialog(
            onDismissRequest={selectedForMenu=null},
            title={Text(item.name,fontSize=22.sp,fontWeight=FontWeight.Bold)},
            confirmButton={TextButton(onClick={renameMode=true;renameText=item.name}){Text("RENAME",fontSize=18.sp)}},
            dismissButton={Row { TextButton(onClick={deleteFileConfirm=true}){Text("DELETE",fontSize=18.sp,color=Color(0xFFFF7B72))}; TextButton(onClick={selectedForMenu=null}){Text("CANCEL",fontSize=18.sp)} }}
        )
        if (renameMode) AlertDialog(
            onDismissRequest = { renameMode = false },
            title = { Text("RENAME", fontSize = 22.sp, fontWeight = FontWeight.Bold) },
            text = { OutlinedTextField(value = renameText, onValueChange = { renameText = it }, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(fontSize = 22.sp), modifier = Modifier.fillMaxWidth()) },
            confirmButton = { Button(onClick = { renameConfirmed(item,renameText); renameMode = false; selectedForMenu = null }) { Text("SAVE") } },
            dismissButton = { TextButton(onClick = { renameMode = false }) { Text("CANCEL") } }
        )
        if(deleteFileConfirm) AlertDialog(
            onDismissRequest={deleteFileConfirm=false;selectedForMenu=null},
            title={Text("ARE YOU SURE?",fontSize=23.sp,fontWeight=FontWeight.Black)},
            text={Text("Delete ${item.name}? This removes the real media file.",fontSize=18.sp)},
            confirmButton={Button(onClick={deleteConfirmed(item);deleteFileConfirm=false;selectedForMenu=null}){Text("DELETE",fontWeight=FontWeight.Black)}},
            dismissButton={TextButton(onClick={deleteFileConfirm=false;selectedForMenu=null}){Text("CANCEL",fontSize=18.sp)}}
        )
    }

    if (showSavePicker) {
        var savePath by remember { mutableStateOf(emptyList<String>()) }
        val dirs = remember(savePath, model.refreshSerial) { model.saveFolderChildren(savePath) }
        AlertDialog(
            onDismissRequest = { showSavePicker = false },
            title = { Text(if (savePath.isEmpty()) "SAVE YT" else savePath.joinToString(" / "), fontWeight = FontWeight.Bold) },
            text = { LazyColumn(Modifier.heightIn(max = 420.dp)) {
                if (savePath.isNotEmpty()) item { TextButton(onClick = { savePath = savePath.dropLast(1) }) { Text("⬅ BACK", fontSize = 20.sp) } }
                items(dirs, key = { it.uri.toString() }) { d -> TextButton(onClick = { d.name?.let { savePath = savePath + it } }, modifier = Modifier.fillMaxWidth()) { Text("📁  " + (d.name ?: "Folder"), fontSize = 20.sp, modifier = Modifier.fillMaxWidth()) } }
            } },
            confirmButton = { StoneButton(onClick = { model.saveYoutubeToFolder(savePath); showSavePicker = false }, active = true, modifier = Modifier.width(150.dp).height(52.dp)) { Text("SAVE HERE", color=Color.White, fontWeight = FontWeight.Black) } },
            dismissButton = { TextButton(onClick = { showSavePicker = false }) { Text("CANCEL") } }
        )
    }

    importConflict?.let { uri ->
        val name = model.importName(uri)
        AlertDialog(onDismissRequest={resolveImportConflict("cancel")}, title={Text("FILE ALREADY EXISTS",fontWeight=FontWeight.Black)},
            text={Text("$name is already in BRAKEMONSTER. Choose how to copy this file.",fontSize=18.sp)},
            confirmButton={TextButton(onClick={resolveImportConflict("replace")}){Text("REPLACE",fontWeight=FontWeight.Bold)}},
            dismissButton={Row { TextButton(onClick={resolveImportConflict("keep")}){Text("KEEP BOTH")}; TextButton(onClick={resolveImportConflict("cancel")}){Text("CANCEL")} }})
    }

    if (playlistImportSource) AlertDialog(onDismissRequest={playlistImportSource=false}, title={Text("IMPORT PLAYLIST",fontWeight=FontWeight.Black)},
        text={Column { Text("Import a local M3U or M3U8 playlist. Online playlist sources need official API access, which is not configured in this project.",fontSize=17.sp); Spacer(Modifier.height(10.dp)); Text("YouTube · Spotify · Apple Music: unavailable until official API access is configured.",fontSize=15.sp,color=Color.LightGray) }},
        confirmButton={TextButton(onClick={playlistImportSource=false;playlistFilePicker.launch(arrayOf("*/*"))}){Text("CHOOSE M3U / M3U8")}},
        dismissButton={TextButton(onClick={playlistImportSource=false}){Text("CANCEL")} })

    if (importUris.isNotEmpty() && importConflict == null) {
        // Copy requests are handled one at a time; the source document is only read.
    }

}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BreakBrowserArea(
    model: BreakMonsterModel,
    onYoutubeSearch: () -> Unit,
    onFindMusic: () -> Unit,
    showFindMusic: Boolean,
    firstScanBusy: Boolean,
    localQuery: String,
    onLocalQuery: (String) -> Unit,
    youtubeQuery: String,
    onYoutubeQuery: (String) -> Unit,
    onLocalMic: () -> Unit,
    onYoutubeMic: () -> Unit,
    onOpenFolder: (DocumentFile) -> Unit,
    onTrack: (BreakItem) -> Unit,
    selectedItem: BreakItem?,
    onSelect: (BreakItem) -> Unit,
    onDeselect: () -> Unit,
    playlistVisible: Boolean,
    playlistStore: BreakPlaylistStore,
    random: Boolean,
    repeat: Boolean,
    onRandom: () -> Unit,
    onRepeat: () -> Unit,
    onCreatePlaylist: (String) -> Unit,
    playlistTab: Int,
    onPlaylistTab: (Int) -> Unit,
    onTogglePlaylist: () -> Unit,
    folderSwipeHint: Boolean,
    playlistHint: Boolean,
    swipeBlinkUri: String?,
    onSwipeAdded: (BreakItem) -> Unit,
    onSwipeRemoved: (Int) -> Unit,
    onPlaylistGestureLearned: () -> Unit,
    youtubeSearchUrl: String?,
    onYoutubeSelected: (String, String?, String) -> Unit,
    onYoutubeClose: () -> Unit,
    browserSection: String,
    onBrowserSection: (String) -> Unit,
    onImportMedia: () -> Unit,
    onImportPlaylist: () -> Unit,
    reorderHint: Boolean,
    onReorderGestureLearned: () -> Unit,
    playlistReorderHint: Boolean,
    onPlaylistReorderLearned: () -> Unit
) {
    val baseTracks = when (browserSection) {
        "YT DOWNLOADS" -> model.ytDownloadItems
        "BRAKEMONSTER" -> model.brakeMonsterItems
        else -> model.tracks
    }
    val visibleTracks = remember(baseTracks, model.allMusicItems, localQuery) {
        if(localQuery.isBlank()) baseTracks else model.allMusicItems.filter { it.name.contains(localQuery.trim(),true) }
    }
    val visibleFolders = remember(model.folders,localQuery,browserSection) { if(browserSection!="ALL MUSIC") emptyList() else model.folders.filterNot { it.name?.equals(".thumbnails",true)==true }.filter { localQuery.isBlank() || it.name.orEmpty().contains(localQuery.trim(),true) } }
    Column(
        modifier = Modifier
            .fillMaxSize()
            // Browser intentionally has no panel/window of its own. The stage bitmap
            // must remain fully visible behind folders and tracks.
            .background(Color.Transparent)
            .padding(top = 196.dp, bottom = 142.dp, start = 12.dp, end = 12.dp)
    ) {
        if(showFindMusic) {
            Spacer(Modifier.weight(1f))
            StoneButton(onClick=onFindMusic,active=!firstScanBusy,modifier=Modifier.fillMaxWidth().height(72.dp)){
                Text(if(firstScanBusy) "WAIT..." else "FIND YOUR MUSIC",color=Color.White,fontSize=22.sp,fontWeight=FontWeight.Black)
            }
            Spacer(Modifier.weight(1f))
            return@Column
        }
        Row(Modifier.fillMaxWidth().height(54.dp),verticalAlignment=Alignment.CenterVertically) {
            OutlinedTextField(value=localQuery,onValueChange=onLocalQuery,singleLine=true,label={Text("LOCAL SEARCH")},modifier=Modifier.weight(1f),textStyle=androidx.compose.ui.text.TextStyle(fontSize=19.sp))
            StoneButton(onClick=onLocalMic,active=false,modifier=Modifier.size(54.dp)){ Text("🎙",fontSize=25.sp,color=MonsterGreen) }
        }
        Spacer(Modifier.height(3.dp))
        Row(Modifier.fillMaxWidth().height(54.dp),verticalAlignment=Alignment.CenterVertically) {
            OutlinedTextField(value=youtubeQuery,onValueChange=onYoutubeQuery,singleLine=true,label={Text("YOUTUBE SEARCH")},modifier=Modifier.weight(1f),textStyle=androidx.compose.ui.text.TextStyle(fontSize=19.sp),keyboardActions=androidx.compose.foundation.text.KeyboardActions(onSearch={onYoutubeSearch()}),keyboardOptions=androidx.compose.foundation.text.KeyboardOptions(imeAction=androidx.compose.ui.text.input.ImeAction.Search))
            StoneButton(onClick=onYoutubeMic,active=false,modifier=Modifier.size(54.dp)){ Text("🎙",fontSize=25.sp,color=MonsterGreen) }
            RoundModeButton(selected=true,contentDescription="YouTube search",onClick=onYoutubeSearch,modifier=Modifier.size(54.dp)){ YouTubeBadge(Modifier.size(30.dp)) }
        }
        Row(Modifier.fillMaxWidth().height(40.dp), horizontalArrangement=Arrangement.spacedBy(5.dp), verticalAlignment=Alignment.CenterVertically) {
            val choices = listOf("ALL MUSIC", "YT DOWNLOADS", "IMPORTS")
            choices.forEach { label ->
                val section = if(label=="IMPORTS") "BRAKEMONSTER" else label
                PlaylistStoneButton(onClick={onBrowserSection(section)},active=browserSection==section,modifier=Modifier.weight(1f).height(40.dp)) {
                    Text(label,color=Color.White,fontSize=14.sp,fontWeight=FontWeight.Black,maxLines=1,overflow=TextOverflow.Ellipsis)
                }
            }
        }
        RopeVolumeSlider(Modifier.fillMaxWidth().height(30.dp).padding(horizontal = 2.dp))
        Spacer(Modifier.height(4.dp))

        Box(modifier = Modifier.fillMaxSize()) {
            Column {
                Row(Modifier.fillMaxWidth().height(54.dp), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Text(
                        if (youtubeSearchUrl != null) "ALL MUSIC / YOUTUBE" else if (browserSection != "ALL MUSIC") browserSection else if (model.rootUri==null) "ALL MUSIC" else if (model.path.isEmpty()) "ALL MUSIC" else "ALL MUSIC / " + model.path.joinToString(" / "),
                        color = Amber,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f).padding(start = 14.dp)
                    )
                    PlaylistStoneButton(onClick=onTogglePlaylist,active=playlistVisible,modifier=Modifier.width(250.dp).height(48.dp)) {
                        Text(if(playlistVisible) "EXIT PLAYLIST" else "PLAYLISTS  •  ${playlistStore.displayName(playlistStore.activeIndex)}",color=Color.White,fontSize=14.sp,fontWeight=FontWeight.Black,maxLines=1,overflow=TextOverflow.Ellipsis)
                    }
                }
                if (youtubeSearchUrl != null) {
                    YoutubeSearchPanel(
                        url = youtubeSearchUrl,
                        onSelected = onYoutubeSelected,
                        onClose = onYoutubeClose,
                        modifier = Modifier.fillMaxSize()
                    )
                } else if (playlistVisible) {
                    BreakPlaylistPanel(
                        store = playlistStore, selected = playlistTab, onSelected = onPlaylistTab, onImportPlaylist=onImportPlaylist,
                        random=random, repeat=repeat, onRandom=onRandom, onRepeat=onRepeat,
                        localQuery=localQuery, onCreatePlaylist=onCreatePlaylist,
                        showHint = playlistHint, onGestureLearned = onPlaylistGestureLearned,
                        showReorderHint=playlistReorderHint, onReorderGestureLearned=onPlaylistReorderLearned,
                        onSwipeRemoved = onSwipeRemoved,
                        onPlay = { uri ->
                            val resolved=playlistStore.resolve(playlistTab)
                            val index=resolved.indexOfFirst { it.file.uri.toString()==uri }
                            if(index>=0) model.startPlaylist(resolved,index)
                        }
                    )
                } else {
                if (browserSection == "BRAKEMONSTER") {
                    Row(Modifier.fillMaxWidth().padding(horizontal=8.dp, vertical=2.dp), horizontalArrangement=Arrangement.End) {
                        PlaylistStoneButton(onClick=onImportMedia,active=true,modifier=Modifier.width(156.dp).height(38.dp)) { Text("IMPORT",color=Color.White,fontSize=16.sp,fontWeight=FontWeight.Black) }
                    }
                }
                if (model.loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = MonsterGreen)
                model.error?.let { Text(it, color = Color(0xFFFF8A80), fontSize = 18.sp, modifier = Modifier.padding(12.dp)) }
                LazyColumn(Modifier.fillMaxSize()) {
                    if(folderSwipeHint && visibleTracks.isNotEmpty() && browserSection=="ALL MUSIC") item { GestureManual(R.drawable.folder_swipe_hint, Modifier.fillMaxWidth().height(86.dp)) }
                    if(reorderHint && browserSection=="ALL MUSIC" && model.rootUri!=null && model.path.isEmpty() && visibleTracks.size>1) item { ReorderGestureHelp(Modifier.fillMaxWidth().height(44.dp)) }
                    // Defence-in-depth: never render Android/media thumbnail cache folders,
                    // even if a provider returns one between model refreshes.
                    items(visibleFolders, key = { it.uri.toString() }) { dir ->
                        Row(
                            Modifier.fillMaxWidth().heightIn(min = 54.dp)
                                .combinedClickable(onClick = { onOpenFolder(dir) }, onLongClick = {})
                                .padding(horizontal = 10.dp, vertical = 1.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(R.drawable.karamonster_folder),
                                contentDescription = null,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.padding(start = 6.dp).size((64f * 2f / 3f).dp)
                            )
                            Text(
                                dir.name ?: "Folder",
                                color = Color.White,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.weight(1f).padding(start = 8.dp)
                            )
                        }
                        HorizontalDivider(color = Color.White.copy(alpha = .08f))
                    }
                    itemsIndexed(visibleTracks, key = { _, it -> it.file.uri.toString() }) { index, item ->
                        val active = model.localTrackUri == item.file.uri.toString()
                        val selected = selectedItem?.file?.uri == item.file.uri
                        Row(
                            Modifier.fillMaxWidth().heightIn(min = 54.dp)
                                .background(if(swipeBlinkUri == item.file.uri.toString()) MonsterGreen.copy(alpha=.55f) else if (selected) Amber.copy(alpha=.20f) else if (active) Color(0x77383838) else Color.Transparent)
                                .pointerInput(item.file.uri, playlistStore.activeIndex) {
                                    var dx = 0f
                                    detectHorizontalDragGestures(onDragStart={dx=0f}, onHorizontalDrag={c,a->dx+=a;if(kotlin.math.abs(dx)>12f)c.consume()}, onDragEnd={ if(dx>90.dp.toPx()) onSwipeAdded(item); dx=0f }, onDragCancel={dx=0f})
                                }
                                .pointerInput(item.file.uri) {
                                    var dragTotal = 0f
                                    detectDragGesturesAfterLongPress(
                                        onDragStart = { onSelect(item); dragTotal = 0f },
                                        onDragEnd = { dragTotal = 0f }, onDragCancel = { dragTotal = 0f },
                                        onDrag = { change, amount ->
                                            change.consume(); dragTotal += amount.y
                                            val currentIndex = model.tracks.indexOfFirst { it.file.uri == item.file.uri }
                                            if (kotlin.math.abs(dragTotal) > 55f) {
                                                onReorderGestureLearned()
                                                if (dragTotal > 0f && currentIndex in 0 until model.tracks.lastIndex) model.moveTrack(currentIndex, currentIndex + 1)
                                                else if (dragTotal < 0f && currentIndex > 0) model.moveTrack(currentIndex, currentIndex - 1)
                                                dragTotal = 0f
                                            }
                                        }
                                    )
                                }
                                .combinedClickable(onClick = { if (selected) onDeselect() else onTrack(item) }, onLongClick = { onSelect(item) })
                                .padding(horizontal = 12.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(item.name, color = Color.White, fontSize = 22.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium, modifier = Modifier.weight(1f))
                            if (active) { Spacer(Modifier.width(8.dp)); Text(if (model.localPlaying) "▶" else "Ⅱ", color = MonsterGreen, fontSize = 20.sp) }
                            if (item.isYoutube) { Spacer(Modifier.width(8.dp)); YouTubeBadge(Modifier.size(34.dp)) }
                            else { Spacer(Modifier.width(8.dp)); MediaTypeBadge(item.file.extensionLower()) }
                        }
                        HorizontalDivider(color = Color.White.copy(alpha = .08f))
                    }
                    if (!model.loading && model.folders.isEmpty() && visibleTracks.isEmpty()) {
                        item {
                            Text("Folder je prazan.", color = Color.White.copy(alpha = .7f), fontSize = 20.sp, modifier = Modifier.padding(18.dp))
                        }
                    }
                }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BreakPlaylistPanel(
    store: BreakPlaylistStore, selected: Int, onSelected:(Int)->Unit,
    random:Boolean, repeat:Boolean, onRandom:()->Unit, onRepeat:()->Unit,
    localQuery:String, onCreatePlaylist:(String)->Unit,
    showHint:Boolean, onGestureLearned:()->Unit, showReorderHint:Boolean, onReorderGestureLearned:()->Unit, onSwipeRemoved:(Int)->Unit,
    onPlay:(String)->Unit, onImportPlaylist:()->Unit
) {
    val marked = remember(selected){ mutableStateListOf<String>() }
    val flashing = remember(selected){ mutableStateListOf<String>() }
    val scope = rememberCoroutineScope()
    val context= LocalContext.current
    var createPlaylist by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Color.Transparent)) {
        BreakPlaylistTabs(store, onSelected, onImportPlaylist)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(7.dp)) {
            PlaylistStoneButton(onClick=onRandom,active=random,modifier=Modifier.width(150.dp).height(44.dp)){Text(if(random)"RANDOMIZE ON" else "RANDOMIZE",color=Color.White,fontSize=13.sp,fontWeight=FontWeight.Black)}
            PlaylistStoneButton(onClick=onRepeat,active=repeat,modifier=Modifier.width(150.dp).height(44.dp)){Text(if(repeat)"REPEAT ALL ON" else "REPEAT ALL",color=Color.White,fontSize=13.sp,fontWeight=FontWeight.Black)}
            PlaylistStoneButton(onClick={createPlaylist=true},active=false,modifier=Modifier.width(150.dp).height(44.dp)){Text("ADD NEW PL",color=Color.White,fontSize=13.sp,fontWeight=FontWeight.Black)}
            RoundModeButton(selected=marked.isNotEmpty(), contentDescription="Remove selected", onClick={ if(marked.isNotEmpty()){ store.removeUris(selected,marked.toSet());marked.clear() } }, modifier=Modifier.width(118.dp).height(46.dp)) {
                Text("REMOVE", color=if(marked.isNotEmpty()) MonsterGreen else Color.Gray, fontSize=15.sp, fontWeight=FontWeight.Bold)
            }
        }
        if(showHint) GestureManual(R.drawable.playlist_gesture_hint, Modifier.fillMaxWidth().height(150.dp).padding(vertical=4.dp))
        if(showReorderHint && store.lists[selected].size>1) ReorderGestureHelp(Modifier.fillMaxWidth().height(42.dp))
        LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(store.lists[selected].filter { localQuery.isBlank() || it.name.contains(localQuery,true) }, key={_,e->e.uri}) { index,e ->
                var dx by remember(e.uri){ mutableFloatStateOf(0f) }
                var dy by remember(e.uri){ mutableFloatStateOf(0f) }
                val selectedForMove=e.uri in marked
                Row(Modifier.fillMaxWidth().heightIn(min=44.dp)
                    .background(if(e.uri in flashing) MonsterGreen.copy(alpha=.55f) else if(e.uri in marked) Color.White.copy(alpha=.12f) else Color.Transparent)
                    .pointerInput(e.uri,selected){ detectHorizontalDragGestures(onDragStart={dx=0f},onHorizontalDrag={c,a->c.consume();dx+=a},onDragEnd={
                        if(dx>80.dp.toPx() && e.uri !in flashing){ flashing.add(e.uri);onSwipeRemoved(selected+1);Toast.makeText(context,"REMOVED FROM ${store.displayName(selected)}",Toast.LENGTH_SHORT).show();onGestureLearned();scope.launch{delay(240);store.removeUris(selected,setOf(e.uri));marked.remove(e.uri);flashing.remove(e.uri)} };dx=0f
                    },onDragCancel={dx=0f}) }
                    .pointerInput(e.uri,selected,selectedForMove,marked.size){ if(!selectedForMove)return@pointerInput; val step=54.dp.toPx();detectVerticalDragGestures(onDragStart={dy=0f},onVerticalDrag={c,a->c.consume();dy+=a;while(dy<=-step){onReorderGestureLearned();if(store.moveUrisByStep(selected,marked.toSet(),-1))dy+=step else{dy=0f;break}};while(dy>=step){onReorderGestureLearned();if(store.moveUrisByStep(selected,marked.toSet(),1))dy-=step else{dy=0f;break}}},onDragEnd={dy=0f},onDragCancel={dy=0f}) }
                    .combinedClickable(onClick={if(marked.isNotEmpty()){if(e.uri in marked)marked.remove(e.uri)else marked.add(e.uri)}else if(!e.missing) onPlay(e.uri)},onLongClick={if(e.uri in marked)marked.remove(e.uri)else marked.add(e.uri)})
                    .padding(horizontal=12.dp,vertical=3.dp),verticalAlignment=Alignment.CenterVertically){
                    Text("${index+1}.",color=MonsterGreen,fontSize=15.sp,fontWeight=FontWeight.Bold,modifier=Modifier.width(34.dp))
                    Text(e.name,color=Color.White,fontSize=17.sp,fontWeight=FontWeight.Medium,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.weight(1f))
                    if(e.missing){ Text("MISSING",color=Color(0xFFFF8A80),fontSize=12.sp,fontWeight=FontWeight.Black) } else { Text("MATCHED",color=MonsterGreen,fontSize=11.sp,fontWeight=FontWeight.Bold) }
                    if(e.youtube){Spacer(Modifier.width(8.dp));YouTubeBadge(Modifier.size(34.dp))}
                    else {Spacer(Modifier.width(8.dp));MediaTypeBadge(Uri.parse(e.uri).lastPathSegment.orEmpty().substringAfterLast('.',""))}
                }
                HorizontalDivider(color=Color.White.copy(alpha=.05f))
            }
        }
    }
    if(createPlaylist) AlertDialog(onDismissRequest={createPlaylist=false},title={Text("ADD NEW PL",fontWeight=FontWeight.Black)},text={OutlinedTextField(newName,{newName=it.take(24)},singleLine=true,label={Text("Playlist name")})},confirmButton={TextButton(onClick={onCreatePlaylist(newName);newName="";createPlaylist=false}){Text("CREATE")}},dismissButton={TextButton(onClick={createPlaylist=false}){Text("CANCEL")}})
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BreakPlaylistTabs(store: BreakPlaylistStore, onSelected:(Int)->Unit, onImportPlaylist:()->Unit) {
    var renameIndex by remember { mutableIntStateOf(-1) }
    var renameValue by remember { mutableStateOf("") }
    var menuIndex by remember { mutableIntStateOf(-1) }
    var deleteIndex by remember { mutableIntStateOf(-1) }
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal=4.dp, vertical=4.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        repeat(store.size) { i ->
            PlaylistStoneButton(
                onClick={ store.activate(i); onSelected(i) },
                onLongClick={ menuIndex=i; renameValue=store.names[i].value },
                active=store.activeIndex==i,
                modifier=Modifier.width(160.dp).height(50.dp)
            ) {
                Text(store.displayName(i), color=Color.White, fontSize=16.sp, fontWeight=FontWeight.Black, maxLines=1, overflow=TextOverflow.Ellipsis)
            }
        }
        PlaylistStoneButton(onClick=onImportPlaylist,active=false,modifier=Modifier.width(190.dp).height(50.dp)) { Text("IMPORT PLAYLIST",color=Color.White,fontSize=15.sp,fontWeight=FontWeight.Black,maxLines=1) }
    }
    if(menuIndex>=0) AlertDialog(onDismissRequest={menuIndex=-1},title={Text(store.displayName(menuIndex),fontWeight=FontWeight.Black)},confirmButton={TextButton(onClick={renameIndex=menuIndex;menuIndex=-1}){Text("RENAME")}},dismissButton={Row{TextButton(onClick={deleteIndex=menuIndex;menuIndex=-1}){Text("DELETE PLAYLIST",color=Color(0xFFFF7B72))};TextButton(onClick={menuIndex=-1}){Text("CANCEL")}}})
    if(renameIndex in 0..3) AlertDialog(
        onDismissRequest={renameIndex=-1},
        title={Text("Rename playlist")},
        text={OutlinedTextField(renameValue,{renameValue=it.take(24)},singleLine=true)},
        confirmButton={TextButton(onClick={store.rename(renameIndex,renameValue);renameIndex=-1}){Text("SAVE")}},
        dismissButton={TextButton(onClick={renameIndex=-1}){Text("CANCEL")}}
    )
    if(renameIndex>=4) AlertDialog(onDismissRequest={renameIndex=-1},title={Text("Rename playlist")},text={OutlinedTextField(renameValue,{renameValue=it.take(24)},singleLine=true)},confirmButton={TextButton(onClick={store.rename(renameIndex,renameValue);renameIndex=-1}){Text("SAVE")}},dismissButton={TextButton(onClick={renameIndex=-1}){Text("CANCEL")}})
    if(deleteIndex>=0) AlertDialog(onDismissRequest={deleteIndex=-1},title={Text("ARE YOU SURE?",fontSize=23.sp,fontWeight=FontWeight.Black)},text={Text("Delete playlist ${store.displayName(deleteIndex)}? Media files will stay untouched.",fontSize=18.sp)},confirmButton={Button(onClick={store.delete(deleteIndex);deleteIndex=-1;onSelected(store.activeIndex)}){Text("DELETE PLAYLIST")}},dismissButton={TextButton(onClick={deleteIndex=-1}){Text("CANCEL")}})
}

@Composable
private fun GestureManual(resource:Int, modifier:Modifier=Modifier){
    AndroidView(modifier=modifier, factory={ context -> GestureGifView(context,resource) })
}
@Composable
private fun ReorderGestureHelp(modifier:Modifier=Modifier){
    val transition=androidx.compose.animation.core.rememberInfiniteTransition(label="reorder-help")
    val offset by transition.animateFloat(initialValue=0f,targetValue=8f,animationSpec=androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(550),androidx.compose.animation.core.RepeatMode.Reverse),label="drag-arrow")
    Row(modifier,verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.Center){
        Text("☝",fontSize=23.sp,color=MonsterGreen)
        Spacer(Modifier.width(8.dp))
        Text("LONG PRESS",fontSize=15.sp,fontWeight=FontWeight.Black,color=Color.White)
        Text("  ↕",fontSize=24.sp,fontWeight=FontWeight.Black,color=MonsterGreen,modifier=Modifier.offset(y=offset.dp))
        Text("  DRAG TO REORDER",fontSize=15.sp,fontWeight=FontWeight.Black,color=Color.White)
    }
}
@Suppress("DEPRECATION")
private class GestureGifView(context:Context, resource:Int):android.view.View(context){
    private val movie=context.resources.openRawResource(resource).use{android.graphics.Movie.decodeStream(it)}
    private val started=android.os.SystemClock.uptimeMillis()
    init{setLayerType(LAYER_TYPE_SOFTWARE,null)}
    override fun onDraw(canvas:android.graphics.Canvas){super.onDraw(canvas);val a=movie?:return;a.setTime(((android.os.SystemClock.uptimeMillis()-started)%a.duration().coerceAtLeast(1)).toInt());val scale=minOf(width.toFloat()/a.width(),height.toFloat()/a.height());canvas.save();canvas.translate((width-a.width()*scale)/2,(height-a.height()*scale)/2);canvas.scale(scale,scale);a.draw(canvas,0f,0f);canvas.restore();if(isAttachedToWindow)postInvalidateDelayed(40)}
}
private fun swipeFeedbackResource(added:Boolean, playlist:Int):Int{
    val r=if(added) listOf(R.drawable.swipe_added_p1,R.drawable.swipe_added_p2,R.drawable.swipe_added_p3,R.drawable.swipe_added_p4) else listOf(R.drawable.swipe_removed_p1,R.drawable.swipe_removed_p2,R.drawable.swipe_removed_p3,R.drawable.swipe_removed_p4)
    return r[(playlist-1).coerceIn(0,3)]
}

private fun importM3uPlaylist(context:Context, uri:Uri, library:List<BreakItem>, store:BreakPlaylistStore):Int {
    return runCatching {
        val displayName=runCatching { context.contentResolver.query(uri,arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),null,null,null)?.use { c -> if(c.moveToFirst()) c.getString(0) else null } }.getOrNull() ?: "Imported playlist.m3u"
        if(!displayName.endsWith(".m3u",true) && !displayName.endsWith(".m3u8",true)) error("Choose an M3U or M3U8 playlist.")
        val lines=context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readLines() } ?: error("Playlist file could not be read.")
        val entries=mutableListOf<BreakPlaylistEntry>(); var metadata:String?=null
        lines.forEachIndexed { index, raw ->
            val line=raw.trim().removePrefix("\uFEFF")
            if(line.isBlank()) return@forEachIndexed
            if(line.startsWith("#EXTINF",true)){ metadata=line.substringAfter(',',"").trim().takeIf{it.isNotBlank()}; return@forEachIndexed }
            if(line.startsWith('#')) return@forEachIndexed
            val pathName=line.substringAfterLast('/').substringAfterLast('\\').substringBeforeLast('.')
            val taggedTitle=metadata?.substringAfterLast(" - ")?.trim().orEmpty()
            val wanted=normalizePlaylistTitle(taggedTitle.ifBlank { pathName })
            val matched=library.firstOrNull { normalizePlaylistTitle(it.name)==wanted }
            val direct=if(line.startsWith("content://",true)) runCatching {
                val externalUri=Uri.parse(line)
                context.contentResolver.openInputStream(externalUri)?.use { } ?: error("playlist URI is not readable")
                runCatching { context.contentResolver.takePersistableUriPermission(externalUri,Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                androidx.documentfile.provider.DocumentFile.fromSingleUri(context,externalUri)?.let { BreakItem(it,metadata?.takeIf{it.isNotBlank()} ?: pathName,externalUri.toString().contains("youtube",true)) }
            }.getOrNull() else runCatching { java.io.File(line).takeIf { it.isFile }?.let { BreakItem(androidx.documentfile.provider.DocumentFile.fromFile(it),metadata?.takeIf{it.isNotBlank()} ?: pathName,false) } }.getOrNull()
            if(matched!=null) entries.add(BreakPlaylistEntry(matched.name,matched.file.uri.toString(),matched.isYoutube,false))
            else if(direct!=null) entries.add(BreakPlaylistEntry(direct.name,direct.file.uri.toString(),direct.isYoutube,false))
            else entries.add(BreakPlaylistEntry(metadata?.takeIf{it.isNotBlank()} ?: pathName,"missing://entry/$index?source="+Uri.encode(line),false,true))
            metadata=null
        }
        val index=store.createImported(displayName.substringBeforeLast('.'),entries)
        val matched=entries.count{!it.missing}; val missing=entries.size-matched
        android.widget.Toast.makeText(context,"PLAYLIST IMPORTED · $matched MATCHED · $missing MISSING",android.widget.Toast.LENGTH_LONG).show()
        index
    }.getOrElse {
        android.widget.Toast.makeText(context,it.message ?: "Playlist import failed.",android.widget.Toast.LENGTH_LONG).show()
        store.activeIndex
    }
}

private fun normalizePlaylistTitle(value:String):String = value.substringBeforeLast('.').lowercase(Locale.ROOT)
    .replace(Regex("\\([^)]*\\)|\\[[^]]*]")," ")
    .replace(Regex("[^\\p{L}\\p{N}]+")," ").trim().replace(Regex("\\s+")," ")

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun StoneButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    onLongClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val stoneShape = GenericShape { size, _ ->
        moveTo(size.width * .06f, 0f)
        lineTo(size.width * .91f, size.height * .03f)
        lineTo(size.width, size.height * .18f)
        lineTo(size.width * .96f, size.height * .88f)
        lineTo(size.width * .84f, size.height)
        lineTo(size.width * .08f, size.height * .96f)
        lineTo(0f, size.height * .80f)
        lineTo(size.width * .02f, size.height * .12f)
        close()
    }
    val edge = if (active) MonsterGreen else Color(0xFF4A5147)
    val top = if (active) Color(0xFF345E3A) else Color(0xFF30332E)
    val bottom = if (active) Color(0xFF172B1B) else Color(0xFF20221F)
    Box(
        modifier = modifier
            .padding(2.dp)
            .heightIn(min = 48.dp)
            .background(Brush.verticalGradient(listOf(top, bottom)), stoneShape)
            .border(2.dp, edge, stoneShape)
            .drawBehind {
                val crack = Color.Black.copy(alpha = .28f)
                drawLine(crack, androidx.compose.ui.geometry.Offset(size.width * .17f, size.height * .18f), androidx.compose.ui.geometry.Offset(size.width * .28f, size.height * .31f), 1.3.dp.toPx())
                drawLine(crack, androidx.compose.ui.geometry.Offset(size.width * .74f, size.height * .70f), androidx.compose.ui.geometry.Offset(size.width * .84f, size.height * .61f), 1.2.dp.toPx())
                drawLine(edge.copy(alpha = .24f), androidx.compose.ui.geometry.Offset(size.width * .08f, size.height * .10f), androidx.compose.ui.geometry.Offset(size.width * .86f, size.height * .08f), 1.dp.toPx())
            }
            .then(if (onLongClick == null) Modifier.combinedClickable(onClick = onClick, onLongClick = {}) else Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center,
        content = content
    )
}

/** Carved, irregular stone used by the playlist controls only. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PlaylistStoneButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    onLongClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val stoneShape = GenericShape { size, _ ->
        moveTo(size.width * .08f, size.height * .04f)
        lineTo(size.width * .43f, size.height * .01f)
        lineTo(size.width * .49f, size.height * .045f)
        lineTo(size.width * .91f, size.height * .025f)
        lineTo(size.width * .985f, size.height * .22f)
        lineTo(size.width * .96f, size.height * .76f)
        lineTo(size.width * .88f, size.height * .97f)
        lineTo(size.width * .57f, size.height * .94f)
        lineTo(size.width * .50f, size.height * .99f)
        lineTo(size.width * .12f, size.height * .96f)
        lineTo(size.width * .015f, size.height * .79f)
        lineTo(size.width * .04f, size.height * .25f)
        close()
    }
    val edge = if (active) Color(0xFFB3C478) else Color(0xFF77796D)
    val light = if (active) Color(0xFF747B53) else Color(0xFF64665E)
    val dark = if (active) Color(0xFF303522) else Color(0xFF292B28)
    Box(
        modifier = modifier
            .padding(2.dp)
            .background(Brush.verticalGradient(listOf(light, Color(0xFF484A43), dark)), stoneShape)
            .border(2.dp, edge, stoneShape)
            .drawBehind {
                val px = size.width
                val py = size.height
                // Shallow top/left relief and a darker lower edge give the stone depth.
                drawLine(Color.White.copy(alpha = .20f), androidx.compose.ui.geometry.Offset(px * .10f, py * .15f), androidx.compose.ui.geometry.Offset(px * .20f, py * .08f), 1.6.dp.toPx())
                drawLine(Color.Black.copy(alpha = .36f), androidx.compose.ui.geometry.Offset(px * .12f, py * .86f), androidx.compose.ui.geometry.Offset(px * .85f, py * .90f), 1.7.dp.toPx())
                val crack = Color.Black.copy(alpha = .48f)
                drawLine(crack, androidx.compose.ui.geometry.Offset(px * .22f, py * .20f), androidx.compose.ui.geometry.Offset(px * .29f, py * .43f), 1.3.dp.toPx())
                drawLine(crack, androidx.compose.ui.geometry.Offset(px * .29f, py * .43f), androidx.compose.ui.geometry.Offset(px * .24f, py * .55f), 1.1.dp.toPx())
                drawLine(crack, androidx.compose.ui.geometry.Offset(px * .78f, py * .53f), androidx.compose.ui.geometry.Offset(px * .70f, py * .69f), 1.3.dp.toPx())
                drawLine(edge.copy(alpha = .34f), androidx.compose.ui.geometry.Offset(px * .35f, py * .16f), androidx.compose.ui.geometry.Offset(px * .69f, py * .14f), 1.dp.toPx())
            }
            .then(if (onLongClick == null) Modifier.combinedClickable(onClick = onClick, onLongClick = {}) else Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center,
        content = content
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun RoundModeButton(
    selected: Boolean,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier.size(58.dp),
    content: @Composable BoxScope.() -> Unit
) {
    val bg = if (selected) Amber else MutedGreen
    val border = if (selected) Color.White.copy(alpha = .55f) else Color.Black.copy(alpha = .4f)
    Box(
        modifier = modifier.clip(RoundedCornerShape(18.dp))
            .background(bg)
            .border(2.dp, border, RoundedCornerShape(18.dp))
            .semantics { this.contentDescription = contentDescription }
            .combinedClickable(onClick = onClick, onLongClick = {}),
        contentAlignment = Alignment.Center,
        content = content
    )
}

@Composable
private fun RopeVolumeSlider(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val audio = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val max = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var level by remember { mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max) }
    fun setLevel(v: Float) {
        level = v.coerceIn(0f, 1f)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (level * max).toInt(), 0)
    }
    Canvas(
        modifier = modifier.pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { p -> setLevel(p.x / size.width.toFloat()) },
                onDrag = { change, _ -> setLevel(change.position.x / size.width.toFloat()); change.consume() }
            )
        }
    ) {
        val y = size.height / 2f
        // dark shadow under the rope
        drawLine(Color.Black.copy(alpha=.48f), androidx.compose.ui.geometry.Offset(0f, y + 2.dp.toPx()), androidx.compose.ui.geometry.Offset(size.width, y + 2.dp.toPx()), 9.dp.toPx())
        // old rope body, deliberately muted rather than fluorescent
        drawLine(Color(0xFF6B5635), androidx.compose.ui.geometry.Offset(0f, y), androidx.compose.ui.geometry.Offset(size.width, y), 8.dp.toPx())
        drawLine(Color(0xFF9A7B49).copy(alpha=.72f), androidx.compose.ui.geometry.Offset(0f, y - 1.dp.toPx()), androidx.compose.ui.geometry.Offset(size.width, y - 1.dp.toPx()), 2.dp.toPx())
        // rope twist marks
        var x = 8.dp.toPx()
        while (x < size.width) {
            drawLine(Color(0xFF3D3020).copy(alpha=.65f), androidx.compose.ui.geometry.Offset(x - 4.dp.toPx(), y - 4.dp.toPx()), androidx.compose.ui.geometry.Offset(x + 4.dp.toPx(), y + 4.dp.toPx()), 1.2.dp.toPx())
            x += 18.dp.toPx()
        }
        val cx = level * size.width
        val stone = Path().apply {
            moveTo(cx - 12.dp.toPx(), y - 9.dp.toPx()); lineTo(cx + 8.dp.toPx(), y - 11.dp.toPx())
            lineTo(cx + 13.dp.toPx(), y - 2.dp.toPx()); lineTo(cx + 10.dp.toPx(), y + 9.dp.toPx())
            lineTo(cx - 8.dp.toPx(), y + 11.dp.toPx()); lineTo(cx - 14.dp.toPx(), y + 3.dp.toPx()); close()
        }
        drawPath(stone, Color(0xFF5A5A50))
        drawPath(stone, Color(0xFF8A8979), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5.dp.toPx()))
        drawLine(Color.Black.copy(alpha=.35f), androidx.compose.ui.geometry.Offset(cx-5.dp.toPx(), y-4.dp.toPx()), androidx.compose.ui.geometry.Offset(cx+4.dp.toPx(), y+3.dp.toPx()), 1.dp.toPx())
    }
}

@Composable
private fun RopeSeekSlider(value: Float, enabled: Boolean, onValueChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    Canvas(
        modifier = modifier.pointerInput(enabled) {
            if (enabled) detectDragGestures(
                onDragStart = { p -> onValueChange((p.x / size.width.toFloat()).coerceIn(0f, 1f)) },
                onDrag = { change, _ -> onValueChange((change.position.x / size.width.toFloat()).coerceIn(0f, 1f)); change.consume() }
            )
        }
    ) {
        val y = size.height / 2f
        val ropeDark = Color(0xFF3B2A18)
        val rope = Color(0xFF8C6A3D)
        val ropeHi = Color(0xFFB99558)
        drawLine(Color.Black.copy(alpha=.55f), androidx.compose.ui.geometry.Offset(0f, y + 2.dp.toPx()), androidx.compose.ui.geometry.Offset(size.width, y + 2.dp.toPx()), 9.dp.toPx())
        drawLine(ropeDark, androidx.compose.ui.geometry.Offset(0f, y), androidx.compose.ui.geometry.Offset(size.width, y), 8.dp.toPx())
        drawLine(rope, androidx.compose.ui.geometry.Offset(0f, y), androidx.compose.ui.geometry.Offset(size.width, y), 6.dp.toPx())
        drawLine(ropeHi.copy(alpha=.65f), androidx.compose.ui.geometry.Offset(0f, y - 1.5.dp.toPx()), androidx.compose.ui.geometry.Offset(size.width, y - 1.5.dp.toPx()), 1.5.dp.toPx())
        var x = 8.dp.toPx()
        while (x < size.width) {
            drawLine(ropeDark.copy(alpha=.72f), androidx.compose.ui.geometry.Offset(x-4.dp.toPx(), y-3.dp.toPx()), androidx.compose.ui.geometry.Offset(x+4.dp.toPx(), y+3.dp.toPx()), 1.dp.toPx())
            x += 17.dp.toPx()
        }
        val cx = value.coerceIn(0f,1f) * size.width
        val r = 11.dp.toPx()
        drawCircle(Color.Black.copy(alpha=.5f), r + 2.dp.toPx(), androidx.compose.ui.geometry.Offset(cx, y + 2.dp.toPx()))
        drawCircle(Color(0xFF4A4B43), r, androidx.compose.ui.geometry.Offset(cx, y))
        drawCircle(Color(0xFF858574), r, androidx.compose.ui.geometry.Offset(cx, y), style = androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))
        drawCircle(Color.White.copy(alpha=.16f), r*.42f, androidx.compose.ui.geometry.Offset(cx-r*.25f, y-r*.28f))
    }
}

@Composable
private fun LocalAudioMiniPip(model: BreakMonsterModel, modifier: Modifier = Modifier) {
    val remaining = (model.localDuration - model.localPosition).coerceAtLeast(0)
    Surface(color = Color(0xF500140C), modifier = modifier) {
        Row(
            Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Image(painter = painterResource(R.mipmap.ic_launcher), contentDescription = "BreakMonster", modifier = Modifier.size(42.dp))
            Text("-${timeLabel(remaining)}", color = MonsterGreen, fontSize = 18.sp, fontWeight = FontWeight.Black)
            Text("BACK", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun PlaybackBar(model: BreakMonsterModel, youtubePlayer: YouTubePlayer?, onSaveYoutube: () -> Unit, modifier: Modifier = Modifier) {
    val ytActive = model.youtubeVideoId != null
    val localActive = model.localTrackUri != null
    Surface(
        color = Color(0xF500140C),
        tonalElevation = 4.dp,
        modifier = modifier.fillMaxWidth().height(140.dp).border(1.dp, Amber.copy(alpha = .65f))
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 6.dp)) {
            Text(
                when {
                    ytActive -> model.youtubeTitle ?: "YouTube"
                    localActive -> model.localTrackName ?: "BREAK"
                    else -> "BREAKMONSTER READY"
                },
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(
                Modifier.fillMaxWidth().height(58.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        if (ytActive) {
                            if (model.youtubePlaying) youtubePlayer?.pause() else youtubePlayer?.play()
                        } else model.toggleLocalPause()
                    },
                    enabled = ytActive || localActive,
                    modifier = Modifier.size(width = 70.dp, height = 52.dp),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color.Black)
                ) { Text(if (if (ytActive) model.youtubePlaying else model.localPlaying) "Ⅱ" else "▶", fontSize = 26.sp, fontWeight = FontWeight.Black) }

                Button(
                    onClick = {
                        if (ytActive) {
                            youtubePlayer?.pause(); youtubePlayer?.seekTo(0f); model.stopPlayback()
                        } else model.stopPlayback()
                    },
                    enabled = ytActive || localActive,
                    modifier = Modifier.size(width = 70.dp, height = 52.dp),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MutedGreen, contentColor = Color.White)
                ) { Text("■", fontSize = 24.sp) }

                if (ytActive && model.youtubeCanSave && !model.youtubeSaved) {
                    Button(
                        onClick = onSaveYoutube,
                        modifier = Modifier.height(52.dp).weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MutedGreen, contentColor = Color.White)
                    ) { Text("SAVE YT", fontWeight = FontWeight.Black, fontSize = 17.sp) }
                } else {
                    PlaylistStoneButton(
                        onClick = { if (ytActive || localActive) model.nextLocal() },
                        active = ytActive || localActive,
                        modifier = Modifier.height(52.dp).weight(1f)
                    ) { Text("NEXT  ▶", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp) }
                }

                val pos = if (ytActive) (model.youtubeCurrentSecond * 1000).toInt() else model.localPosition
                val dur = if (ytActive) (model.youtubeDurationSecond * 1000).toInt() else model.localDuration
                Text("${timeLabel(pos)} / ${timeLabel(dur)}", color = MonsterGreen, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            val pos = if (ytActive) (model.youtubeCurrentSecond * 1000).toInt() else model.localPosition
            val dur = if (ytActive) (model.youtubeDurationSecond * 1000).toInt() else model.localDuration
            RopeSeekSlider(
                value = if (dur > 0) pos.coerceIn(0, dur).toFloat() / dur else 0f,
                enabled = dur > 0,
                onValueChange = { fraction ->
                    val target = (fraction * dur).toInt()
                    if (ytActive) youtubePlayer?.seekTo(target / 1000f) else model.seekLocal(target)
                },
                modifier = Modifier.fillMaxWidth().height(32.dp)
            )
        }
    }
}

private fun timeLabel(ms: Int): String = "%d:%02d".format(Locale.ROOT, ms / 60000, ms / 1000 % 60)

@Composable
private fun YouTubeBadge(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val radius = size.minDimension * .20f
        drawRoundRect(color = Color(0xFFFF0000), cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius))
        val p = Path().apply {
            moveTo(size.width * .42f, size.height * .30f)
            lineTo(size.width * .72f, size.height * .50f)
            lineTo(size.width * .42f, size.height * .70f)
            close()
        }
        drawPath(p, Color.White)
    }
}

@Composable
private fun MediaTypeBadge(extension:String) {
    val ext=extension.uppercase(Locale.ROOT).ifBlank { "FILE" }
    val label=when(ext){"WAVE"->"WAV";"M4V"->"MP4";"3G2"->"3GP";"M2TS"->"TS";else->ext}
    val video=ext in setOf("MP4","M4V","MOV","3GP","3G2","MKV","WEBM","AVI","TS","M2TS","MPEG","MPG")
    Box(Modifier.widthIn(min=42.dp).height(28.dp).background(if(video)Color(0xFF34483A)else Color(0xFF263B2E),RoundedCornerShape(6.dp)).border(1.dp,MonsterGreen.copy(alpha=.6f),RoundedCornerShape(6.dp)),contentAlignment=Alignment.Center){
        Text(label,color=Color.White,fontSize=10.sp,fontWeight=FontWeight.Black,maxLines=1,modifier=Modifier.padding(horizontal=4.dp))
    }
}

@Composable
private fun YoutubeSurface(
    videoId: String,
    session: Int,
    pipMode: Boolean,
    onPlayer: (YouTubePlayer?) -> Unit,
    onPlaying: (Boolean) -> Unit,
    onCurrentSecond: (Float) -> Unit,
    onDuration: (Float) -> Unit,
    onPlaybackError: () -> Unit,
    onEnded: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    key(session) {
        Box(
            modifier = modifier.background(Color.Black, RoundedCornerShape(if (pipMode) 0.dp else 10.dp))
                .then(if (pipMode) Modifier else Modifier.border(2.dp, MonsterGreen, RoundedCornerShape(10.dp)))
        ) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { uiContext ->
                    val wrapped = MutableContextWrapper(uiContext)
                    YouTubePlayerView(wrapped).apply {
                        enableAutomaticInitialization = false
                        val options = IFramePlayerOptions.Builder(wrapped)
                            .controls(0)
                            .fullscreen(0)
                            .rel(0)
                            .ivLoadPolicy(3)
                            .ccLoadPolicy(0)
                            .autoplay(1)
                            .mute(0)
                            .build()
                        val listener = object : AbstractYouTubePlayerListener() {
                            override fun onReady(youTubePlayer: YouTubePlayer) {
                                onPlayer(youTubePlayer)
                                youTubePlayer.loadVideo(videoId, 0f)
                            }
                            override fun onStateChange(youTubePlayer: YouTubePlayer, state: PlayerConstants.PlayerState) {
                                onPlaying(state == PlayerConstants.PlayerState.PLAYING)
                                if (state == PlayerConstants.PlayerState.ENDED) onEnded()
                            }
                            override fun onCurrentSecond(youTubePlayer: YouTubePlayer, second: Float) { onCurrentSecond(second) }
                            override fun onVideoDuration(youTubePlayer: YouTubePlayer, duration: Float) { onDuration(duration) }
                            override fun onError(youTubePlayer: YouTubePlayer, error: PlayerConstants.PlayerError) { onPlaybackError() }
                        }
                        initialize(listener, false, options, videoId)
                    }
                },
                update = { view -> (view.context as? MutableContextWrapper)?.baseContext = context },
                onRelease = { view ->
                    onPlayer(null)
                    runCatching { view.release() }
                }
            )
            if (!pipMode) {
                // Mini preview is intentionally display-only. Transport stays in the bottom bar.
                Box(
                    Modifier.matchParentSize().pointerInput(Unit) {
                        awaitPointerEventScope {
                            while (true) {
                                awaitPointerEvent().changes.forEach { it.consume() }
                            }
                        }
                    }
                )
            }
        }
    }
}

private class YoutubeJsBridge(
    private val web: WebView,
    private val onSelected: (String, String?, String) -> Unit
) {
    @JavascriptInterface
    fun select(url: String?, title: String?) {
        val id = BreakMonsterModel.extractYoutubeVideoId(url) ?: return
        val canonical = "https://www.youtube.com/watch?v=$id"
        web.post { onSelected(id, title?.trim(), canonical) }
    }
}

@Composable
private fun YoutubeSearchPanel(
    url: String,
    onSelected: (String, String?, String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var webView by remember { mutableStateOf<WebView?>(null) }

    Box(modifier.background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { uiContext ->
                val created = WebView(uiContext)
                webView = created
                CookieManager.getInstance().apply {
                    setAcceptCookie(true)
                    setAcceptThirdPartyCookies(created, true)
                }
                created.apply {
                    setBackgroundColor(AndroidColor.BLACK)
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = true
                    addJavascriptInterface(YoutubeJsBridge(this, onSelected), "BreakHost")
                    webChromeClient = WebChromeClient()
                    webViewClient = object : WebViewClient() {
                        private fun intercept(raw: String?): Boolean {
                            val id = BreakMonsterModel.extractYoutubeVideoId(raw) ?: return false
                            onSelected(id, null, "https://www.youtube.com/watch?v=$id")
                            return true
                        }
                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = intercept(request?.url?.toString())
                        @Suppress("DEPRECATION")
                        override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean = intercept(url)
                        override fun onPageFinished(view: WebView, pageUrl: String) {
                            super.onPageFinished(view, pageUrl)
                            // Search page stays silent; a selected result is handed to the official native embed player.
                            val js = """(function(){try{
                              document.querySelectorAll('video,audio').forEach(function(v){try{v.muted=true;v.pause();}catch(e){}});
                              if(window.__breakMonsterTap)return; window.__breakMonsterTap=true;
                              function pick(ev){try{
                                var el=ev.target; while(el&&el!==document){
                                  if(el.tagName==='A'&&el.href){
                                    var u=new URL(el.href,location.href),h=u.hostname.replace(/^www\\.|^m\\./,'');
                                    var id=null;
                                    if(h==='youtu.be') id=u.pathname.split('/').filter(Boolean)[0]||null;
                                    else if(h==='youtube.com'||h.endsWith('.youtube.com')){
                                      if(u.pathname==='/watch') id=u.searchParams.get('v');
                                      else if(u.pathname.indexOf('/shorts/')===0||u.pathname.indexOf('/live/')===0) id=u.pathname.split('/')[2]||null;
                                    }
                                    if(id&&/^[A-Za-z0-9_-]{6,20}$/.test(id)){
                                      ev.preventDefault();ev.stopPropagation();if(ev.stopImmediatePropagation)ev.stopImmediatePropagation();
                                      var t='';try{t=(el.getAttribute('title')||el.getAttribute('aria-label')||el.textContent||'').replace(/\\s+/g,' ').trim();}catch(e){}
                                      BreakHost.select('https://www.youtube.com/watch?v='+id,t);return false;
                                    }
                                  }
                                  el=el.parentElement;
                                }
                              }catch(e){}}
                              document.addEventListener('click',pick,true);
                            }catch(e){}})()"""
                            view.evaluateJavascript(js, null)
                        }
                    }
                    loadUrl(url)
                }
            },
            update = { }
        )

    }
}
