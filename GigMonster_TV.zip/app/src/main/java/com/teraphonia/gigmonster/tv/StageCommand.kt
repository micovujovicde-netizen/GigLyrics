package com.teraphonia.gigmonster.tv

import android.graphics.Bitmap

sealed interface StageCommand {
    data object Logo : StageCommand
    data class Lyrics(val current: String, val next: String = "") : StageCommand
    data class Frame(val bitmap: Bitmap) : StageCommand
}
